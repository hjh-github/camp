"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

require('./npm/wepy-async-function/index.js');

var _WxUtils = require('./utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

var _wepyRedux = require('./npm/wepy-redux/lib/index.js');

var _store = require('./store/index.js');

var _store2 = _interopRequireDefault(_store);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var store = (0, _store2.default)();
(0, _wepyRedux.setStore)(store);

var _default = function (_wepy$app) {
  _inherits(_default, _wepy$app);

  function _default() {
    _classCallCheck(this, _default);

    // 注册中间件
    var _this = _possibleConstructorReturn(this, (_default.__proto__ || Object.getPrototypeOf(_default)).call(this));

    _this.globalData = {
      auth: {},
      scene: null,
      base_store_id: "",
      appCode: "",
      baseUrl: "https://wechat.hxqxly.com",
      // baseUrl: "https://test.hxqxly.com",
      themeColor: "#F4D000",
      cityCode: '',
      code: '',
      sessionId: '',
      courseInfo: {},
      orderInfo: {},
      childs: [],
      help: true,
      query: {}
    };
    _this.config = {
      pages: ["pages/home/index", "pages/home/search", "pages/home/web", "pages/home/share", "pages/meet/meet", "pages/my/my", "pages/my/orders", "pages/my/order", "pages/my/pintuan", "pages/my/bargaining", "pages/home/address", "pages/detaile/detaile", "pages/detaile/sureOrder", "pages/detaile/partners", "pages/meet/childs", "pages/meet/addChild", "pages/meet/addMan", "pages/meet/remarks", "pages/meet/commiRemarke", "pages/activity/bargain", "pages/activity/pintuan"],
      subPackages: [{
        root: "agent",
        pages: ["pages/index", "pages/share", "pages/sign"]
      }],
      window: {
        backgroundTextStyle: "dark",
        navigationBarBackgroundColor: "#F4D000",
        backgroundColor: "#fff",
        navigationBarTitleText: "",
        navigationBarTextStyle: "white"
      },
      navigateToMiniProgramAppIdList: [],
      permission: {
        "scope.userLocation": {
          desc: "你的位置信息将用于小程序位置的效果展示"
        }
      },
      "tabBar": {
        "color": "#a9b7b7",
        "selectedColor": "#F4D000",
        "borderStyle": "black",
        "list": [{
          "selectedIconPath": "static/images/icon_consult_press.png",
          "iconPath": "static/images/icon_consult.png",
          "pagePath": "pages/home/index",
          "text": "首页"
        }, {
          "selectedIconPath": "static/images/icon_invest_press.png",
          "iconPath": "static/images/icon_invest.png",
          "pagePath": "pages/meet/meet",
          "text": "互动"
        }, {
          "selectedIconPath": "static/images/icon_mine_press.png",
          "iconPath": "static/images/icon_mine.png",
          "pagePath": "pages/my/my",
          "text": "我的"
        }]
      }
    };
    _this.use("requestfix");
    _this.use("promisify");
    return _this;
  }

  _createClass(_default, [{
    key: "onLaunch",
    value: function () {
      var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(param) {
        var updateManager, ext;
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                // 获取当前小程序
                try {
                  _wepy2.default.$instance.globalData.appCode = wx.getAccountInfoSync().miniProgram.appId;
                } catch (res) {
                  if (wx.canIUse("getAccountInfoSync")) {
                    _wepy2.default.$instance.globalData.appCode = wx.getAccountInfoSync().miniProgram.appId;
                  } else {
                    // 如果希望用户在最新版本的客户端上体验您的小程序，可以这样子提示
                    wx.showModal({
                      title: "提示",
                      content: "当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。"
                    });
                  }
                }
                updateManager = wx.getUpdateManager();

                updateManager.onCheckForUpdate(function (res) {
                  // 请求完新版本信息的回调
                  console.log(res.hasUpdate);
                });
                updateManager.onUpdateReady(function () {
                  wx.showModal({
                    title: "更新提示",
                    content: "新版本已经准备好，是否重启应用？",
                    success: function success(res) {
                      if (res.confirm) {
                        // 新的版本已经下载好，调用 applyUpdate 应用新版本并重启
                        updateManager.applyUpdate();
                      }
                    }
                  });
                });
                updateManager.onUpdateFailed(function () {
                  // 新的版本下载失败
                  wx.showModal({
                    title: "更新提示",
                    content: "新版本下载失败",
                    showCancel: false
                  });
                });
                // 校验SDK
                _WxUtils2.default.checkSDK();
                // 同步开放平台EXT数据
                ext = _wepy2.default.getExtConfigSync();
                // console.info("[ext] init ext data", ext);

                if (ext.globalConfig) {
                  // console.info("[ext] init ext global config data", ext.globalConfig);
                  Object.assign(ext, ext.globalConfig);
                }
                Object.assign(_wepy2.default.$instance.globalData, ext);
                // auth.login();

              case 9:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function onLaunch(_x) {
        return _ref.apply(this, arguments);
      }

      return onLaunch;
    }()
  }, {
    key: "onShow",
    value: function onShow(param) {
      console.log(param);
      // 获取保存场景值
      if (param && param.scene) {
        _wepy2.default.$instance.globalData.scene = param.scene;
        if (param.query.scene) {
          _wepy2.default.$instance.globalData.query = this.getCodeBy1047(param.query.scene);
        }
      }
    }
  }, {
    key: "getCodeBy1047",
    value: function getCodeBy1047(str) {
      var query = {},
          strs = decodeURIComponent(str).split("&");
      console.log(strs);
      for (var i = 0, len = strs.length; i < len; i++) {
        query[strs[i].split("=")[0]] = strs[i].split("=")[1];
      }
      return query;
    }
  }, {
    key: "syncStoreConfig",
    value: function syncStoreConfig(key) {
      try {
        var value = _wepy2.default.getStorageSync(key);
        if (value !== "") {
          // console.info(`[auth]${key} sync success `);
          _wepy2.default.$instance.globalData.auth[key] = value;
        }
      } catch (e) {
        // console.warn(`[auth]${key} sync fail `);
      }
    }
  }, {
    key: "onShareAppMessage",
    value: function onShareAppMessage(res) {
      if (res.from === "button") {
        // 来自页面内转发按钮
        console.log(res.target);
      }
      return {
        title: "自定义转发标题",
        path: "/pages/home/index"
      };
    }
  }]);

  return _default;
}(_wepy2.default.app);


App(require('./npm/wepy/lib/wepy.js').default.$createApp(_default, {"noPromiseAPI":["createSelectorQuery"]}));
require('./_wepylogs.js')

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC5qcyJdLCJuYW1lcyI6WyJzdG9yZSIsImdsb2JhbERhdGEiLCJhdXRoIiwic2NlbmUiLCJiYXNlX3N0b3JlX2lkIiwiYXBwQ29kZSIsImJhc2VVcmwiLCJ0aGVtZUNvbG9yIiwiY2l0eUNvZGUiLCJjb2RlIiwic2Vzc2lvbklkIiwiY291cnNlSW5mbyIsIm9yZGVySW5mbyIsImNoaWxkcyIsImhlbHAiLCJxdWVyeSIsImNvbmZpZyIsInBhZ2VzIiwic3ViUGFja2FnZXMiLCJyb290Iiwid2luZG93IiwiYmFja2dyb3VuZFRleHRTdHlsZSIsIm5hdmlnYXRpb25CYXJCYWNrZ3JvdW5kQ29sb3IiLCJiYWNrZ3JvdW5kQ29sb3IiLCJuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0IiwibmF2aWdhdGlvbkJhclRleHRTdHlsZSIsIm5hdmlnYXRlVG9NaW5pUHJvZ3JhbUFwcElkTGlzdCIsInBlcm1pc3Npb24iLCJkZXNjIiwidXNlIiwicGFyYW0iLCJ3ZXB5IiwiJGluc3RhbmNlIiwid3giLCJnZXRBY2NvdW50SW5mb1N5bmMiLCJtaW5pUHJvZ3JhbSIsImFwcElkIiwicmVzIiwiY2FuSVVzZSIsInNob3dNb2RhbCIsInRpdGxlIiwiY29udGVudCIsInVwZGF0ZU1hbmFnZXIiLCJnZXRVcGRhdGVNYW5hZ2VyIiwib25DaGVja0ZvclVwZGF0ZSIsImNvbnNvbGUiLCJsb2ciLCJoYXNVcGRhdGUiLCJvblVwZGF0ZVJlYWR5Iiwic3VjY2VzcyIsImNvbmZpcm0iLCJhcHBseVVwZGF0ZSIsIm9uVXBkYXRlRmFpbGVkIiwic2hvd0NhbmNlbCIsIld4VXRpbHMiLCJjaGVja1NESyIsImV4dCIsImdldEV4dENvbmZpZ1N5bmMiLCJnbG9iYWxDb25maWciLCJPYmplY3QiLCJhc3NpZ24iLCJnZXRDb2RlQnkxMDQ3Iiwic3RyIiwic3RycyIsImRlY29kZVVSSUNvbXBvbmVudCIsInNwbGl0IiwiaSIsImxlbiIsImxlbmd0aCIsImtleSIsInZhbHVlIiwiZ2V0U3RvcmFnZVN5bmMiLCJlIiwiZnJvbSIsInRhcmdldCIsInBhdGgiLCJhcHAiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUNFOzs7O0FBQ0E7O0FBQ0E7Ozs7QUFDQTs7QUFHQTs7Ozs7Ozs7Ozs7Ozs7QUFDQSxJQUFNQSxRQUFRLHNCQUFkO0FBQ0EseUJBQVNBLEtBQVQ7Ozs7O0FBbUJFLHNCQUFjO0FBQUE7O0FBRVo7QUFGWTs7QUFBQSxVQWpCZEMsVUFpQmMsR0FqQkQ7QUFDWEMsWUFBTSxFQURLO0FBRVhDLGFBQU8sSUFGSTtBQUdYQyxxQkFBZSxFQUhKO0FBSVhDLGVBQVMsRUFKRTtBQUtYQyxlQUFTLDJCQUxFO0FBTVg7QUFDQUMsa0JBQVksU0FQRDtBQVFYQyxnQkFBVSxFQVJDO0FBU1hDLFlBQU0sRUFUSztBQVVYQyxpQkFBVyxFQVZBO0FBV1hDLGtCQUFZLEVBWEQ7QUFZWEMsaUJBQVcsRUFaQTtBQWFYQyxjQUFRLEVBYkc7QUFjWEMsWUFBTSxJQWRLO0FBZVhDLGFBQU07QUFmSyxLQWlCQztBQUFBLFVBa0dkQyxNQWxHYyxHQWtHTDtBQUNQQyxhQUFPLENBQ0wsa0JBREssRUFFTCxtQkFGSyxFQUdMLGdCQUhLLEVBSUwsa0JBSkssRUFLTCxpQkFMSyxFQU1MLGFBTkssRUFPTCxpQkFQSyxFQVFMLGdCQVJLLEVBU0wsa0JBVEssRUFVTCxxQkFWSyxFQVdMLG9CQVhLLEVBWUwsdUJBWkssRUFhTCx5QkFiSyxFQWNMLHdCQWRLLEVBZUwsbUJBZkssRUFnQkwscUJBaEJLLEVBaUJMLG1CQWpCSyxFQWtCTCxvQkFsQkssRUFtQkwseUJBbkJLLEVBb0JMLHdCQXBCSyxFQXFCTCx3QkFyQkssQ0FEQTtBQXdCUEMsbUJBQWEsQ0FBQztBQUNaQyxjQUFNLE9BRE07QUFFWkYsZUFBTyxDQUNMLGFBREssRUFFTCxhQUZLLEVBR0wsWUFISztBQUZLLE9BQUQsQ0F4Qk47QUFnQ1BHLGNBQVE7QUFDTkMsNkJBQXFCLE1BRGY7QUFFTkMsc0NBQThCLFNBRnhCO0FBR05DLHlCQUFpQixNQUhYO0FBSU5DLGdDQUF3QixFQUpsQjtBQUtOQyxnQ0FBd0I7QUFMbEIsT0FoQ0Q7QUF1Q1BDLHNDQUFnQyxFQXZDekI7QUF3Q1BDLGtCQUFZO0FBQ1YsOEJBQXNCO0FBQ3BCQyxnQkFBTTtBQURjO0FBRFosT0F4Q0w7QUE2Q1AsZ0JBQVU7QUFDUixpQkFBUyxTQUREO0FBRVIseUJBQWlCLFNBRlQ7QUFHUix1QkFBZSxPQUhQO0FBSVIsZ0JBQVEsQ0FBQztBQUNMLDhCQUFvQixzQ0FEZjtBQUVMLHNCQUFZLGdDQUZQO0FBR0wsc0JBQVksa0JBSFA7QUFJTCxrQkFBUTtBQUpILFNBQUQsRUFNTjtBQUNFLDhCQUFvQixxQ0FEdEI7QUFFRSxzQkFBWSwrQkFGZDtBQUdFLHNCQUFZLGlCQUhkO0FBSUUsa0JBQVE7QUFKVixTQU5NLEVBWU47QUFDRSw4QkFBb0IsbUNBRHRCO0FBRUUsc0JBQVksNkJBRmQ7QUFHRSxzQkFBWSxhQUhkO0FBSUUsa0JBQVE7QUFKVixTQVpNO0FBSkE7QUE3Q0gsS0FsR0s7QUFHWixVQUFLQyxHQUFMLENBQVMsWUFBVDtBQUNBLFVBQUtBLEdBQUwsQ0FBUyxXQUFUO0FBSlk7QUFLYjs7Ozs7MEZBQ2NDLEs7Ozs7OztBQUNiO0FBQ0Esb0JBQUk7QUFDRkMsaUNBQUtDLFNBQUwsQ0FBZS9CLFVBQWYsQ0FBMEJJLE9BQTFCLEdBQW9DNEIsR0FBR0Msa0JBQUgsR0FBd0JDLFdBQXhCLENBQW9DQyxLQUF4RTtBQUNELGlCQUZELENBRUUsT0FBT0MsR0FBUCxFQUFZO0FBQ1osc0JBQUlKLEdBQUdLLE9BQUgsQ0FBVyxvQkFBWCxDQUFKLEVBQXNDO0FBQ3BDUCxtQ0FBS0MsU0FBTCxDQUFlL0IsVUFBZixDQUEwQkksT0FBMUIsR0FBb0M0QixHQUFHQyxrQkFBSCxHQUF3QkMsV0FBeEIsQ0FBb0NDLEtBQXhFO0FBQ0QsbUJBRkQsTUFFTztBQUNMO0FBQ0FILHVCQUFHTSxTQUFILENBQWE7QUFDWEMsNkJBQU8sSUFESTtBQUVYQywrQkFBUztBQUZFLHFCQUFiO0FBSUQ7QUFDRjtBQUNLQyw2QixHQUFnQlQsR0FBR1UsZ0JBQUgsRTs7QUFDdEJELDhCQUFjRSxnQkFBZCxDQUErQixVQUFTUCxHQUFULEVBQWM7QUFDM0M7QUFDQVEsMEJBQVFDLEdBQVIsQ0FBWVQsSUFBSVUsU0FBaEI7QUFDRCxpQkFIRDtBQUlBTCw4QkFBY00sYUFBZCxDQUE0QixZQUFXO0FBQ3JDZixxQkFBR00sU0FBSCxDQUFhO0FBQ1hDLDJCQUFPLE1BREk7QUFFWEMsNkJBQVMsa0JBRkU7QUFHWFEsNkJBQVMsaUJBQVNaLEdBQVQsRUFBYztBQUNyQiwwQkFBSUEsSUFBSWEsT0FBUixFQUFpQjtBQUNmO0FBQ0FSLHNDQUFjUyxXQUFkO0FBQ0Q7QUFDRjtBQVJVLG1CQUFiO0FBVUQsaUJBWEQ7QUFZQVQsOEJBQWNVLGNBQWQsQ0FBNkIsWUFBVztBQUN0QztBQUNBbkIscUJBQUdNLFNBQUgsQ0FBYTtBQUNYQywyQkFBTyxNQURJO0FBRVhDLDZCQUFTLFNBRkU7QUFHWFksZ0NBQVk7QUFIRCxtQkFBYjtBQUtELGlCQVBEO0FBUUE7QUFDQUMsa0NBQVFDLFFBQVI7QUFDQTtBQUNNQyxtQixHQUFNekIsZUFBSzBCLGdCQUFMLEU7QUFDWjs7QUFDQSxvQkFBSUQsSUFBSUUsWUFBUixFQUFzQjtBQUNwQjtBQUNBQyx5QkFBT0MsTUFBUCxDQUFjSixHQUFkLEVBQW1CQSxJQUFJRSxZQUF2QjtBQUNEO0FBQ0RDLHVCQUFPQyxNQUFQLENBQWM3QixlQUFLQyxTQUFMLENBQWUvQixVQUE3QixFQUF5Q3VELEdBQXpDO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7OzsyQkFFSzFCLEssRUFBTztBQUNaZSxjQUFRQyxHQUFSLENBQVloQixLQUFaO0FBQ0E7QUFDQSxVQUFJQSxTQUFTQSxNQUFNM0IsS0FBbkIsRUFBMEI7QUFDeEI0Qix1QkFBS0MsU0FBTCxDQUFlL0IsVUFBZixDQUEwQkUsS0FBMUIsR0FBa0MyQixNQUFNM0IsS0FBeEM7QUFDQSxZQUFHMkIsTUFBTWYsS0FBTixDQUFZWixLQUFmLEVBQXNCO0FBQ3BCNEIseUJBQUtDLFNBQUwsQ0FBZS9CLFVBQWYsQ0FBMEJjLEtBQTFCLEdBQWtDLEtBQUs4QyxhQUFMLENBQW1CL0IsTUFBTWYsS0FBTixDQUFZWixLQUEvQixDQUFsQztBQUNEO0FBQ0Y7QUFDRjs7O2tDQUNhMkQsRyxFQUFLO0FBQ2pCLFVBQUkvQyxRQUFRLEVBQVo7QUFBQSxVQUNFZ0QsT0FBT0MsbUJBQW1CRixHQUFuQixFQUF3QkcsS0FBeEIsQ0FBOEIsR0FBOUIsQ0FEVDtBQUVBcEIsY0FBUUMsR0FBUixDQUFZaUIsSUFBWjtBQUNBLFdBQUssSUFBSUcsSUFBSSxDQUFSLEVBQVdDLE1BQU1KLEtBQUtLLE1BQTNCLEVBQW1DRixJQUFJQyxHQUF2QyxFQUE0Q0QsR0FBNUMsRUFBaUQ7QUFDL0NuRCxjQUFNZ0QsS0FBS0csQ0FBTCxFQUFRRCxLQUFSLENBQWMsR0FBZCxFQUFtQixDQUFuQixDQUFOLElBQStCRixLQUFLRyxDQUFMLEVBQVFELEtBQVIsQ0FBYyxHQUFkLEVBQW1CLENBQW5CLENBQS9CO0FBQ0Q7QUFDRCxhQUFPbEQsS0FBUDtBQUNEOzs7b0NBQ2VzRCxHLEVBQUs7QUFDbkIsVUFBSTtBQUNGLFlBQU1DLFFBQVF2QyxlQUFLd0MsY0FBTCxDQUFvQkYsR0FBcEIsQ0FBZDtBQUNBLFlBQUlDLFVBQVUsRUFBZCxFQUFrQjtBQUNoQjtBQUNBdkMseUJBQUtDLFNBQUwsQ0FBZS9CLFVBQWYsQ0FBMEJDLElBQTFCLENBQStCbUUsR0FBL0IsSUFBc0NDLEtBQXRDO0FBQ0Q7QUFDRixPQU5ELENBTUUsT0FBT0UsQ0FBUCxFQUFVO0FBQ1Y7QUFDRDtBQUNGOzs7c0NBQ2lCbkMsRyxFQUFLO0FBQ3JCLFVBQUlBLElBQUlvQyxJQUFKLEtBQWEsUUFBakIsRUFBMkI7QUFDekI7QUFDQTVCLGdCQUFRQyxHQUFSLENBQVlULElBQUlxQyxNQUFoQjtBQUNEO0FBQ0QsYUFBTztBQUNMbEMsZUFBTyxTQURGO0FBRUxtQyxjQUFNO0FBRkQsT0FBUDtBQUlEOzs7O0VBbkgwQjVDLGVBQUs2QyxHIiwiZmlsZSI6ImFwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4gIGltcG9ydCB3ZXB5IGZyb20gXCJ3ZXB5XCI7XHJcbiAgaW1wb3J0IFwid2VweS1hc3luYy1mdW5jdGlvblwiO1xyXG4gIGltcG9ydCBXeFV0aWxzIGZyb20gXCIuL3V0aWxzL1d4VXRpbHNcIjtcclxuICBpbXBvcnQge1xyXG4gICAgc2V0U3RvcmVcclxuICB9IGZyb20gXCJ3ZXB5LXJlZHV4XCI7XHJcbiAgaW1wb3J0IGNvbmZpZ1N0b3JlIGZyb20gXCIuL3N0b3JlXCI7XHJcbiAgY29uc3Qgc3RvcmUgPSBjb25maWdTdG9yZSgpO1xyXG4gIHNldFN0b3JlKHN0b3JlKTtcclxuICBleHBvcnQgZGVmYXVsdCBjbGFzcyBleHRlbmRzIHdlcHkuYXBwIHtcclxuICAgIGdsb2JhbERhdGEgPSB7XHJcbiAgICAgIGF1dGg6IHt9LFxyXG4gICAgICBzY2VuZTogbnVsbCxcclxuICAgICAgYmFzZV9zdG9yZV9pZDogXCJcIixcclxuICAgICAgYXBwQ29kZTogXCJcIixcclxuICAgICAgYmFzZVVybDogXCJodHRwczovL3dlY2hhdC5oeHF4bHkuY29tXCIsXHJcbiAgICAgIC8vIGJhc2VVcmw6IFwiaHR0cHM6Ly90ZXN0Lmh4cXhseS5jb21cIixcclxuICAgICAgdGhlbWVDb2xvcjogXCIjRjREMDAwXCIsXHJcbiAgICAgIGNpdHlDb2RlOiAnJyxcclxuICAgICAgY29kZTogJycsXHJcbiAgICAgIHNlc3Npb25JZDogJycsXHJcbiAgICAgIGNvdXJzZUluZm86IHt9LFxyXG4gICAgICBvcmRlckluZm86IHt9LFxyXG4gICAgICBjaGlsZHM6IFtdLFxyXG4gICAgICBoZWxwOiB0cnVlLFxyXG4gICAgICBxdWVyeTp7fVxyXG4gICAgfTtcclxuICAgIGNvbnN0cnVjdG9yKCkge1xyXG4gICAgICBzdXBlcigpO1xyXG4gICAgICAvLyDms6jlhozkuK3pl7Tku7ZcclxuICAgICAgdGhpcy51c2UoXCJyZXF1ZXN0Zml4XCIpO1xyXG4gICAgICB0aGlzLnVzZShcInByb21pc2lmeVwiKTtcclxuICAgIH1cclxuICAgIGFzeW5jIG9uTGF1bmNoKHBhcmFtKSB7XHJcbiAgICAgIC8vIOiOt+WPluW9k+WJjeWwj+eoi+W6j1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuYXBwQ29kZSA9IHd4LmdldEFjY291bnRJbmZvU3luYygpLm1pbmlQcm9ncmFtLmFwcElkO1xyXG4gICAgICB9IGNhdGNoIChyZXMpIHtcclxuICAgICAgICBpZiAod3guY2FuSVVzZShcImdldEFjY291bnRJbmZvU3luY1wiKSkge1xyXG4gICAgICAgICAgd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5hcHBDb2RlID0gd3guZ2V0QWNjb3VudEluZm9TeW5jKCkubWluaVByb2dyYW0uYXBwSWQ7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIC8vIOWmguaenOW4jOacm+eUqOaIt+WcqOacgOaWsOeJiOacrOeahOWuouaIt+err+S4iuS9k+mqjOaCqOeahOWwj+eoi+W6j++8jOWPr+S7pei/meagt+WtkOaPkOekulxyXG4gICAgICAgICAgd3guc2hvd01vZGFsKHtcclxuICAgICAgICAgICAgdGl0bGU6IFwi5o+Q56S6XCIsXHJcbiAgICAgICAgICAgIGNvbnRlbnQ6IFwi5b2T5YmN5b6u5L+h54mI5pys6L+H5L2O77yM5peg5rOV5L2/55So6K+l5Yqf6IO977yM6K+35Y2H57qn5Yiw5pyA5paw5b6u5L+h54mI5pys5ZCO6YeN6K+V44CCXCJcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgICBjb25zdCB1cGRhdGVNYW5hZ2VyID0gd3guZ2V0VXBkYXRlTWFuYWdlcigpO1xyXG4gICAgICB1cGRhdGVNYW5hZ2VyLm9uQ2hlY2tGb3JVcGRhdGUoZnVuY3Rpb24ocmVzKSB7XHJcbiAgICAgICAgLy8g6K+35rGC5a6M5paw54mI5pys5L+h5oGv55qE5Zue6LCDXHJcbiAgICAgICAgY29uc29sZS5sb2cocmVzLmhhc1VwZGF0ZSk7XHJcbiAgICAgIH0pO1xyXG4gICAgICB1cGRhdGVNYW5hZ2VyLm9uVXBkYXRlUmVhZHkoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgd3guc2hvd01vZGFsKHtcclxuICAgICAgICAgIHRpdGxlOiBcIuabtOaWsOaPkOekulwiLFxyXG4gICAgICAgICAgY29udGVudDogXCLmlrDniYjmnKzlt7Lnu4/lh4blpIflpb3vvIzmmK/lkKbph43lkK/lupTnlKjvvJ9cIixcclxuICAgICAgICAgIHN1Y2Nlc3M6IGZ1bmN0aW9uKHJlcykge1xyXG4gICAgICAgICAgICBpZiAocmVzLmNvbmZpcm0pIHtcclxuICAgICAgICAgICAgICAvLyDmlrDnmoTniYjmnKzlt7Lnu4/kuIvovb3lpb3vvIzosIPnlKggYXBwbHlVcGRhdGUg5bqU55So5paw54mI5pys5bm26YeN5ZCvXHJcbiAgICAgICAgICAgICAgdXBkYXRlTWFuYWdlci5hcHBseVVwZGF0ZSgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0pO1xyXG4gICAgICB1cGRhdGVNYW5hZ2VyLm9uVXBkYXRlRmFpbGVkKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgIC8vIOaWsOeahOeJiOacrOS4i+i9veWksei0pVxyXG4gICAgICAgIHd4LnNob3dNb2RhbCh7XHJcbiAgICAgICAgICB0aXRsZTogXCLmm7TmlrDmj5DnpLpcIixcclxuICAgICAgICAgIGNvbnRlbnQ6IFwi5paw54mI5pys5LiL6L295aSx6LSlXCIsXHJcbiAgICAgICAgICBzaG93Q2FuY2VsOiBmYWxzZVxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9KTtcclxuICAgICAgLy8g5qCh6aqMU0RLXHJcbiAgICAgIFd4VXRpbHMuY2hlY2tTREsoKTtcclxuICAgICAgLy8g5ZCM5q2l5byA5pS+5bmz5Y+wRVhU5pWw5o2uXHJcbiAgICAgIGNvbnN0IGV4dCA9IHdlcHkuZ2V0RXh0Q29uZmlnU3luYygpO1xyXG4gICAgICAvLyBjb25zb2xlLmluZm8oXCJbZXh0XSBpbml0IGV4dCBkYXRhXCIsIGV4dCk7XHJcbiAgICAgIGlmIChleHQuZ2xvYmFsQ29uZmlnKSB7XHJcbiAgICAgICAgLy8gY29uc29sZS5pbmZvKFwiW2V4dF0gaW5pdCBleHQgZ2xvYmFsIGNvbmZpZyBkYXRhXCIsIGV4dC5nbG9iYWxDb25maWcpO1xyXG4gICAgICAgIE9iamVjdC5hc3NpZ24oZXh0LCBleHQuZ2xvYmFsQ29uZmlnKTtcclxuICAgICAgfVxyXG4gICAgICBPYmplY3QuYXNzaWduKHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEsIGV4dCk7XHJcbiAgICAgIC8vIGF1dGgubG9naW4oKTtcclxuICAgIH1cclxuICAgIG9uU2hvdyhwYXJhbSkge1xyXG4gICAgICBjb25zb2xlLmxvZyhwYXJhbSk7XHJcbiAgICAgIC8vIOiOt+WPluS/neWtmOWcuuaZr+WAvFxyXG4gICAgICBpZiAocGFyYW0gJiYgcGFyYW0uc2NlbmUpIHtcclxuICAgICAgICB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnNjZW5lID0gcGFyYW0uc2NlbmU7XHJcbiAgICAgICAgaWYocGFyYW0ucXVlcnkuc2NlbmUpIHtcclxuICAgICAgICAgIHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEucXVlcnkgPSB0aGlzLmdldENvZGVCeTEwNDcocGFyYW0ucXVlcnkuc2NlbmUpXHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBnZXRDb2RlQnkxMDQ3KHN0cikge1xyXG4gICAgICB2YXIgcXVlcnkgPSB7fSxcclxuICAgICAgICBzdHJzID0gZGVjb2RlVVJJQ29tcG9uZW50KHN0cikuc3BsaXQoXCImXCIpO1xyXG4gICAgICBjb25zb2xlLmxvZyhzdHJzKTtcclxuICAgICAgZm9yICh2YXIgaSA9IDAsIGxlbiA9IHN0cnMubGVuZ3RoOyBpIDwgbGVuOyBpKyspIHtcclxuICAgICAgICBxdWVyeVtzdHJzW2ldLnNwbGl0KFwiPVwiKVswXV0gPSBzdHJzW2ldLnNwbGl0KFwiPVwiKVsxXTtcclxuICAgICAgfVxyXG4gICAgICByZXR1cm4gcXVlcnk7XHJcbiAgICB9XHJcbiAgICBzeW5jU3RvcmVDb25maWcoa2V5KSB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgdmFsdWUgPSB3ZXB5LmdldFN0b3JhZ2VTeW5jKGtleSk7XHJcbiAgICAgICAgaWYgKHZhbHVlICE9PSBcIlwiKSB7XHJcbiAgICAgICAgICAvLyBjb25zb2xlLmluZm8oYFthdXRoXSR7a2V5fSBzeW5jIHN1Y2Nlc3MgYCk7XHJcbiAgICAgICAgICB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLmF1dGhba2V5XSA9IHZhbHVlO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgIC8vIGNvbnNvbGUud2FybihgW2F1dGhdJHtrZXl9IHN5bmMgZmFpbCBgKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgb25TaGFyZUFwcE1lc3NhZ2UocmVzKSB7XHJcbiAgICAgIGlmIChyZXMuZnJvbSA9PT0gXCJidXR0b25cIikge1xyXG4gICAgICAgIC8vIOadpeiHqumhtemdouWGhei9rOWPkeaMiemSrlxyXG4gICAgICAgIGNvbnNvbGUubG9nKHJlcy50YXJnZXQpO1xyXG4gICAgICB9XHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAgdGl0bGU6IFwi6Ieq5a6a5LmJ6L2s5Y+R5qCH6aKYXCIsXHJcbiAgICAgICAgcGF0aDogXCIvcGFnZXMvaG9tZS9pbmRleFwiXHJcbiAgICAgIH07XHJcbiAgICB9XHJcbiAgICBjb25maWcgPSB7XHJcbiAgICAgIHBhZ2VzOiBbXHJcbiAgICAgICAgXCJwYWdlcy9ob21lL2luZGV4XCIsXHJcbiAgICAgICAgXCJwYWdlcy9ob21lL3NlYXJjaFwiLFxyXG4gICAgICAgIFwicGFnZXMvaG9tZS93ZWJcIixcclxuICAgICAgICBcInBhZ2VzL2hvbWUvc2hhcmVcIixcclxuICAgICAgICBcInBhZ2VzL21lZXQvbWVldFwiLFxyXG4gICAgICAgIFwicGFnZXMvbXkvbXlcIixcclxuICAgICAgICBcInBhZ2VzL215L29yZGVyc1wiLFxyXG4gICAgICAgIFwicGFnZXMvbXkvb3JkZXJcIixcclxuICAgICAgICBcInBhZ2VzL215L3BpbnR1YW5cIixcclxuICAgICAgICBcInBhZ2VzL215L2JhcmdhaW5pbmdcIixcclxuICAgICAgICBcInBhZ2VzL2hvbWUvYWRkcmVzc1wiLFxyXG4gICAgICAgIFwicGFnZXMvZGV0YWlsZS9kZXRhaWxlXCIsXHJcbiAgICAgICAgXCJwYWdlcy9kZXRhaWxlL3N1cmVPcmRlclwiLFxyXG4gICAgICAgIFwicGFnZXMvZGV0YWlsZS9wYXJ0bmVyc1wiLFxyXG4gICAgICAgIFwicGFnZXMvbWVldC9jaGlsZHNcIixcclxuICAgICAgICBcInBhZ2VzL21lZXQvYWRkQ2hpbGRcIixcclxuICAgICAgICBcInBhZ2VzL21lZXQvYWRkTWFuXCIsXHJcbiAgICAgICAgXCJwYWdlcy9tZWV0L3JlbWFya3NcIixcclxuICAgICAgICBcInBhZ2VzL21lZXQvY29tbWlSZW1hcmtlXCIsXHJcbiAgICAgICAgXCJwYWdlcy9hY3Rpdml0eS9iYXJnYWluXCIsXHJcbiAgICAgICAgXCJwYWdlcy9hY3Rpdml0eS9waW50dWFuXCIsXHJcbiAgICAgIF0sXHJcbiAgICAgIHN1YlBhY2thZ2VzOiBbe1xyXG4gICAgICAgIHJvb3Q6IFwiYWdlbnRcIixcclxuICAgICAgICBwYWdlczogW1xyXG4gICAgICAgICAgXCJwYWdlcy9pbmRleFwiLFxyXG4gICAgICAgICAgXCJwYWdlcy9zaGFyZVwiLFxyXG4gICAgICAgICAgXCJwYWdlcy9zaWduXCIsXHJcbiAgICAgICAgXVxyXG4gICAgICB9XSxcclxuICAgICAgd2luZG93OiB7XHJcbiAgICAgICAgYmFja2dyb3VuZFRleHRTdHlsZTogXCJkYXJrXCIsXHJcbiAgICAgICAgbmF2aWdhdGlvbkJhckJhY2tncm91bmRDb2xvcjogXCIjRjREMDAwXCIsXHJcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiBcIiNmZmZcIixcclxuICAgICAgICBuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0OiBcIlwiLFxyXG4gICAgICAgIG5hdmlnYXRpb25CYXJUZXh0U3R5bGU6IFwid2hpdGVcIlxyXG4gICAgICB9LFxyXG4gICAgICBuYXZpZ2F0ZVRvTWluaVByb2dyYW1BcHBJZExpc3Q6IFtdLFxyXG4gICAgICBwZXJtaXNzaW9uOiB7XHJcbiAgICAgICAgXCJzY29wZS51c2VyTG9jYXRpb25cIjoge1xyXG4gICAgICAgICAgZGVzYzogXCLkvaDnmoTkvY3nva7kv6Hmga/lsIbnlKjkuo7lsI/nqIvluo/kvY3nva7nmoTmlYjmnpzlsZXnpLpcIlxyXG4gICAgICAgIH1cclxuICAgICAgfSxcclxuICAgICAgXCJ0YWJCYXJcIjoge1xyXG4gICAgICAgIFwiY29sb3JcIjogXCIjYTliN2I3XCIsXHJcbiAgICAgICAgXCJzZWxlY3RlZENvbG9yXCI6IFwiI0Y0RDAwMFwiLFxyXG4gICAgICAgIFwiYm9yZGVyU3R5bGVcIjogXCJibGFja1wiLFxyXG4gICAgICAgIFwibGlzdFwiOiBbe1xyXG4gICAgICAgICAgICBcInNlbGVjdGVkSWNvblBhdGhcIjogXCJzdGF0aWMvaW1hZ2VzL2ljb25fY29uc3VsdF9wcmVzcy5wbmdcIixcclxuICAgICAgICAgICAgXCJpY29uUGF0aFwiOiBcInN0YXRpYy9pbWFnZXMvaWNvbl9jb25zdWx0LnBuZ1wiLFxyXG4gICAgICAgICAgICBcInBhZ2VQYXRoXCI6IFwicGFnZXMvaG9tZS9pbmRleFwiLFxyXG4gICAgICAgICAgICBcInRleHRcIjogXCLpppbpobVcIlxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgXCJzZWxlY3RlZEljb25QYXRoXCI6IFwic3RhdGljL2ltYWdlcy9pY29uX2ludmVzdF9wcmVzcy5wbmdcIixcclxuICAgICAgICAgICAgXCJpY29uUGF0aFwiOiBcInN0YXRpYy9pbWFnZXMvaWNvbl9pbnZlc3QucG5nXCIsXHJcbiAgICAgICAgICAgIFwicGFnZVBhdGhcIjogXCJwYWdlcy9tZWV0L21lZXRcIixcclxuICAgICAgICAgICAgXCJ0ZXh0XCI6IFwi5LqS5YqoXCJcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIFwic2VsZWN0ZWRJY29uUGF0aFwiOiBcInN0YXRpYy9pbWFnZXMvaWNvbl9taW5lX3ByZXNzLnBuZ1wiLFxyXG4gICAgICAgICAgICBcImljb25QYXRoXCI6IFwic3RhdGljL2ltYWdlcy9pY29uX21pbmUucG5nXCIsXHJcbiAgICAgICAgICAgIFwicGFnZVBhdGhcIjogXCJwYWdlcy9teS9teVwiLFxyXG4gICAgICAgICAgICBcInRleHRcIjogXCLmiJHnmoRcIlxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIF1cclxuICAgICAgfVxyXG4gICAgfTtcclxuICB9XHJcbiJdfQ==