"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

require('./npm/wepy-async-function/index.js');

var _WxUtils = require('./utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

var _wepyRedux = require('./npm/wepy-redux/lib/index.js');

var _store = require('./store/index.js');

var _store2 = _interopRequireDefault(_store);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var store = (0, _store2.default)();
(0, _wepyRedux.setStore)(store);

var _default = function (_wepy$app) {
  _inherits(_default, _wepy$app);

  function _default() {
    _classCallCheck(this, _default);

    // 注册中间件
    var _this = _possibleConstructorReturn(this, (_default.__proto__ || Object.getPrototypeOf(_default)).call(this));

    _this.globalData = {
      auth: {},
      scene: null,
      base_store_id: "",
      appCode: "",
      baseUrl: "https://wechat.hxqxly.com",
      // baseUrl: "http://10.0.3.150:8809",
      themeColor: "#F4D000",
      cityCode: '',
      code: '',
      sessionId: '',
      courseInfo: {},
      orderInfo: {},
      childs: []
    };
    _this.config = {
      pages: ["pages/home/index", "pages/home/search", "pages/home/web", "pages/meet/meet", "pages/my/my", "pages/my/orders", "pages/my/order", "pages/my/bargaining", "pages/home/address", "pages/detaile/detaile", "pages/detaile/sureOrder", "pages/detaile/partners", "pages/meet/childs", "pages/meet/addChild", "pages/meet/addMan", "pages/meet/remarks", "pages/meet/commiRemarke", "pages/activity/bargain", "pages/activity/pintuan"],
      window: {
        backgroundTextStyle: "dark",
        navigationBarBackgroundColor: "#F4D000",
        backgroundColor: "#fff",
        navigationBarTitleText: "",
        navigationBarTextStyle: "white"
      },
      navigateToMiniProgramAppIdList: [],
      permission: {
        "scope.userLocation": {
          desc: "你的位置信息将用于小程序位置的效果展示"
        }
      },
      "tabBar": {
        "color": "#a9b7b7",
        "selectedColor": "#F4D000",
        "borderStyle": "black",
        "list": [{
          "selectedIconPath": "static/images/icon_consult_press.png",
          "iconPath": "static/images/icon_consult.png",
          "pagePath": "pages/home/index",
          "text": "首页"
        }, {
          "selectedIconPath": "static/images/icon_invest_press.png",
          "iconPath": "static/images/icon_invest.png",
          "pagePath": "pages/meet/meet",
          "text": "互动"
        }, {
          "selectedIconPath": "static/images/icon_mine_press.png",
          "iconPath": "static/images/icon_mine.png",
          "pagePath": "pages/my/my",
          "text": "我的"
        }]
      }
    };
    _this.use("requestfix");
    _this.use("promisify");
    return _this;
  }

  _createClass(_default, [{
    key: "onLaunch",
    value: function () {
      var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(param) {
        var updateManager, ext;
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                // 获取当前小程序
                try {
                  _wepy2.default.$instance.globalData.appCode = wx.getAccountInfoSync().miniProgram.appId;
                } catch (res) {
                  if (wx.canIUse("getAccountInfoSync")) {
                    _wepy2.default.$instance.globalData.appCode = wx.getAccountInfoSync().miniProgram.appId;
                  } else {
                    // 如果希望用户在最新版本的客户端上体验您的小程序，可以这样子提示
                    wx.showModal({
                      title: "提示",
                      content: "当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。"
                    });
                  }
                }
                updateManager = wx.getUpdateManager();

                updateManager.onCheckForUpdate(function (res) {
                  // 请求完新版本信息的回调
                  console.log(res.hasUpdate);
                });
                updateManager.onUpdateReady(function () {
                  wx.showModal({
                    title: "更新提示",
                    content: "新版本已经准备好，是否重启应用？",
                    success: function success(res) {
                      if (res.confirm) {
                        // 新的版本已经下载好，调用 applyUpdate 应用新版本并重启
                        updateManager.applyUpdate();
                      }
                    }
                  });
                });
                updateManager.onUpdateFailed(function () {
                  // 新的版本下载失败
                  wx.showModal({
                    title: "更新提示",
                    content: "新版本下载失败",
                    showCancel: false
                  });
                });
                // 校验SDK
                _WxUtils2.default.checkSDK();
                // 同步开放平台EXT数据
                ext = _wepy2.default.getExtConfigSync();
                // console.info("[ext] init ext data", ext);

                if (ext.globalConfig) {
                  // console.info("[ext] init ext global config data", ext.globalConfig);
                  Object.assign(ext, ext.globalConfig);
                }
                Object.assign(_wepy2.default.$instance.globalData, ext);
                // auth.login();

              case 9:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function onLaunch(_x) {
        return _ref.apply(this, arguments);
      }

      return onLaunch;
    }()
  }, {
    key: "onShow",
    value: function onShow(param) {
      console.log(param);
      // 获取保存场景值
      if (param && param.scene) {
        _wepy2.default.$instance.globalData.scene = param.scene;
        if (param.query.s) _wepy2.default.$instance.globalData.base_store_id = param.query.s;
        switch (param.scene) {
          // 服务通知下
          case 1014:
            if (param.query.lid) _wepy2.default.setStorageSync("level_id", param.query.lid);
            break;
        }
      }
    }
  }, {
    key: "syncStoreConfig",
    value: function syncStoreConfig(key) {
      try {
        var value = _wepy2.default.getStorageSync(key);
        if (value !== "") {
          // console.info(`[auth]${key} sync success `);
          _wepy2.default.$instance.globalData.auth[key] = value;
        }
      } catch (e) {
        // console.warn(`[auth]${key} sync fail `);
      }
    }
  }, {
    key: "onShareAppMessage",
    value: function onShareAppMessage(res) {
      if (res.from === "button") {
        // 来自页面内转发按钮
        console.log(res.target);
      }
      return {
        title: "自定义转发标题",
        path: "/pages/home/index"
      };
    }
  }]);

  return _default;
}(_wepy2.default.app);


App(require('./npm/wepy/lib/wepy.js').default.$createApp(_default, {"noPromiseAPI":["createSelectorQuery"]}));
require('./_wepylogs.js')

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC5qcyJdLCJuYW1lcyI6WyJzdG9yZSIsImdsb2JhbERhdGEiLCJhdXRoIiwic2NlbmUiLCJiYXNlX3N0b3JlX2lkIiwiYXBwQ29kZSIsImJhc2VVcmwiLCJ0aGVtZUNvbG9yIiwiY2l0eUNvZGUiLCJjb2RlIiwic2Vzc2lvbklkIiwiY291cnNlSW5mbyIsIm9yZGVySW5mbyIsImNoaWxkcyIsImNvbmZpZyIsInBhZ2VzIiwid2luZG93IiwiYmFja2dyb3VuZFRleHRTdHlsZSIsIm5hdmlnYXRpb25CYXJCYWNrZ3JvdW5kQ29sb3IiLCJiYWNrZ3JvdW5kQ29sb3IiLCJuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0IiwibmF2aWdhdGlvbkJhclRleHRTdHlsZSIsIm5hdmlnYXRlVG9NaW5pUHJvZ3JhbUFwcElkTGlzdCIsInBlcm1pc3Npb24iLCJkZXNjIiwidXNlIiwicGFyYW0iLCJ3ZXB5IiwiJGluc3RhbmNlIiwid3giLCJnZXRBY2NvdW50SW5mb1N5bmMiLCJtaW5pUHJvZ3JhbSIsImFwcElkIiwicmVzIiwiY2FuSVVzZSIsInNob3dNb2RhbCIsInRpdGxlIiwiY29udGVudCIsInVwZGF0ZU1hbmFnZXIiLCJnZXRVcGRhdGVNYW5hZ2VyIiwib25DaGVja0ZvclVwZGF0ZSIsImNvbnNvbGUiLCJsb2ciLCJoYXNVcGRhdGUiLCJvblVwZGF0ZVJlYWR5Iiwic3VjY2VzcyIsImNvbmZpcm0iLCJhcHBseVVwZGF0ZSIsIm9uVXBkYXRlRmFpbGVkIiwic2hvd0NhbmNlbCIsIld4VXRpbHMiLCJjaGVja1NESyIsImV4dCIsImdldEV4dENvbmZpZ1N5bmMiLCJnbG9iYWxDb25maWciLCJPYmplY3QiLCJhc3NpZ24iLCJxdWVyeSIsInMiLCJsaWQiLCJzZXRTdG9yYWdlU3luYyIsImtleSIsInZhbHVlIiwiZ2V0U3RvcmFnZVN5bmMiLCJlIiwiZnJvbSIsInRhcmdldCIsInBhdGgiLCJhcHAiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUNFOzs7O0FBQ0E7O0FBQ0E7Ozs7QUFDQTs7QUFHQTs7Ozs7Ozs7Ozs7Ozs7QUFDQSxJQUFNQSxRQUFRLHNCQUFkO0FBQ0EseUJBQVNBLEtBQVQ7Ozs7O0FBaUJFLHNCQUFjO0FBQUE7O0FBRVo7QUFGWTs7QUFBQSxVQWZkQyxVQWVjLEdBZkQ7QUFDWEMsWUFBTSxFQURLO0FBRVhDLGFBQU8sSUFGSTtBQUdYQyxxQkFBZSxFQUhKO0FBSVhDLGVBQVMsRUFKRTtBQUtYQyxlQUFTLDJCQUxFO0FBTVg7QUFDQUMsa0JBQVksU0FQRDtBQVFYQyxnQkFBUyxFQVJFO0FBU1hDLFlBQUssRUFUTTtBQVVYQyxpQkFBVSxFQVZDO0FBV1hDLGtCQUFXLEVBWEE7QUFZWEMsaUJBQVUsRUFaQztBQWFYQyxjQUFPO0FBYkksS0FlQztBQUFBLFVBNkZkQyxNQTdGYyxHQTZGTDtBQUNQQyxhQUFPLENBQ1Asa0JBRE8sRUFFUCxtQkFGTyxFQUdQLGdCQUhPLEVBSVAsaUJBSk8sRUFLUCxhQUxPLEVBTVAsaUJBTk8sRUFPUCxnQkFQTyxFQVFQLHFCQVJPLEVBU1Asb0JBVE8sRUFVUCx1QkFWTyxFQVdQLHlCQVhPLEVBWVAsd0JBWk8sRUFhUCxtQkFiTyxFQWNQLHFCQWRPLEVBZVAsbUJBZk8sRUFnQlAsb0JBaEJPLEVBaUJQLHlCQWpCTyxFQWtCUCx3QkFsQk8sRUFtQlAsd0JBbkJPLENBREE7QUFzQlBDLGNBQVE7QUFDTkMsNkJBQXFCLE1BRGY7QUFFTkMsc0NBQThCLFNBRnhCO0FBR05DLHlCQUFpQixNQUhYO0FBSU5DLGdDQUF3QixFQUpsQjtBQUtOQyxnQ0FBd0I7QUFMbEIsT0F0QkQ7QUE2QlBDLHNDQUFnQyxFQTdCekI7QUE4QlBDLGtCQUFZO0FBQ1YsOEJBQXNCO0FBQ3BCQyxnQkFBTTtBQURjO0FBRFosT0E5Qkw7QUFtQ1AsZ0JBQVU7QUFDUixpQkFBUyxTQUREO0FBRVIseUJBQWlCLFNBRlQ7QUFHUix1QkFBZSxPQUhQO0FBSVIsZ0JBQVEsQ0FDTjtBQUNFLDhCQUFvQixzQ0FEdEI7QUFFRSxzQkFBWSxnQ0FGZDtBQUdFLHNCQUFZLGtCQUhkO0FBSUUsa0JBQVE7QUFKVixTQURNLEVBT047QUFDRSw4QkFBb0IscUNBRHRCO0FBRUUsc0JBQVksK0JBRmQ7QUFHRSxzQkFBWSxpQkFIZDtBQUlFLGtCQUFRO0FBSlYsU0FQTSxFQWFOO0FBQ0UsOEJBQW9CLG1DQUR0QjtBQUVFLHNCQUFZLDZCQUZkO0FBR0Usc0JBQVksYUFIZDtBQUlFLGtCQUFRO0FBSlYsU0FiTTtBQUpBO0FBbkNILEtBN0ZLO0FBR1osVUFBS0MsR0FBTCxDQUFTLFlBQVQ7QUFDQSxVQUFLQSxHQUFMLENBQVMsV0FBVDtBQUpZO0FBS2I7Ozs7OzBGQUNjQyxLOzs7Ozs7QUFDYjtBQUNBLG9CQUFJO0FBQ0ZDLGlDQUFLQyxTQUFMLENBQWUzQixVQUFmLENBQTBCSSxPQUExQixHQUFvQ3dCLEdBQUdDLGtCQUFILEdBQXdCQyxXQUF4QixDQUFvQ0MsS0FBeEU7QUFDRCxpQkFGRCxDQUVFLE9BQU9DLEdBQVAsRUFBWTtBQUNaLHNCQUFJSixHQUFHSyxPQUFILENBQVcsb0JBQVgsQ0FBSixFQUFzQztBQUNwQ1AsbUNBQUtDLFNBQUwsQ0FBZTNCLFVBQWYsQ0FBMEJJLE9BQTFCLEdBQW9Dd0IsR0FBR0Msa0JBQUgsR0FBd0JDLFdBQXhCLENBQW9DQyxLQUF4RTtBQUNELG1CQUZELE1BRU87QUFDTDtBQUNBSCx1QkFBR00sU0FBSCxDQUFhO0FBQ1hDLDZCQUFPLElBREk7QUFFWEMsK0JBQVM7QUFGRSxxQkFBYjtBQUlEO0FBQ0Y7QUFDS0MsNkIsR0FBZ0JULEdBQUdVLGdCQUFILEU7O0FBQ3RCRCw4QkFBY0UsZ0JBQWQsQ0FBK0IsVUFBU1AsR0FBVCxFQUFjO0FBQzNDO0FBQ0FRLDBCQUFRQyxHQUFSLENBQVlULElBQUlVLFNBQWhCO0FBQ0QsaUJBSEQ7QUFJQUwsOEJBQWNNLGFBQWQsQ0FBNEIsWUFBVztBQUNyQ2YscUJBQUdNLFNBQUgsQ0FBYTtBQUNYQywyQkFBTyxNQURJO0FBRVhDLDZCQUFTLGtCQUZFO0FBR1hRLDZCQUFTLGlCQUFTWixHQUFULEVBQWM7QUFDckIsMEJBQUlBLElBQUlhLE9BQVIsRUFBaUI7QUFDZjtBQUNBUixzQ0FBY1MsV0FBZDtBQUNEO0FBQ0Y7QUFSVSxtQkFBYjtBQVVELGlCQVhEO0FBWUFULDhCQUFjVSxjQUFkLENBQTZCLFlBQVc7QUFDdEM7QUFDQW5CLHFCQUFHTSxTQUFILENBQWE7QUFDWEMsMkJBQU8sTUFESTtBQUVYQyw2QkFBUyxTQUZFO0FBR1hZLGdDQUFZO0FBSEQsbUJBQWI7QUFLRCxpQkFQRDtBQVFBO0FBQ0FDLGtDQUFRQyxRQUFSO0FBQ0E7QUFDTUMsbUIsR0FBTXpCLGVBQUswQixnQkFBTCxFO0FBQ1o7O0FBQ0Esb0JBQUlELElBQUlFLFlBQVIsRUFBc0I7QUFDcEI7QUFDQUMseUJBQU9DLE1BQVAsQ0FBY0osR0FBZCxFQUFtQkEsSUFBSUUsWUFBdkI7QUFDRDtBQUNEQyx1QkFBT0MsTUFBUCxDQUFjN0IsZUFBS0MsU0FBTCxDQUFlM0IsVUFBN0IsRUFBeUNtRCxHQUF6QztBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7MkJBRUsxQixLLEVBQU87QUFDWmUsY0FBUUMsR0FBUixDQUFZaEIsS0FBWjtBQUNBO0FBQ0EsVUFBSUEsU0FBU0EsTUFBTXZCLEtBQW5CLEVBQTBCO0FBQ3hCd0IsdUJBQUtDLFNBQUwsQ0FBZTNCLFVBQWYsQ0FBMEJFLEtBQTFCLEdBQWtDdUIsTUFBTXZCLEtBQXhDO0FBQ0EsWUFBSXVCLE1BQU0rQixLQUFOLENBQVlDLENBQWhCLEVBQW1CL0IsZUFBS0MsU0FBTCxDQUFlM0IsVUFBZixDQUEwQkcsYUFBMUIsR0FBMENzQixNQUFNK0IsS0FBTixDQUFZQyxDQUF0RDtBQUNuQixnQkFBUWhDLE1BQU12QixLQUFkO0FBQ0U7QUFDQSxlQUFLLElBQUw7QUFDRSxnQkFBSXVCLE1BQU0rQixLQUFOLENBQVlFLEdBQWhCLEVBQXFCaEMsZUFBS2lDLGNBQUwsQ0FBb0IsVUFBcEIsRUFBZ0NsQyxNQUFNK0IsS0FBTixDQUFZRSxHQUE1QztBQUNyQjtBQUpKO0FBTUQ7QUFDRjs7O29DQUNlRSxHLEVBQUs7QUFDbkIsVUFBSTtBQUNGLFlBQU1DLFFBQVFuQyxlQUFLb0MsY0FBTCxDQUFvQkYsR0FBcEIsQ0FBZDtBQUNBLFlBQUlDLFVBQVUsRUFBZCxFQUFrQjtBQUNoQjtBQUNBbkMseUJBQUtDLFNBQUwsQ0FBZTNCLFVBQWYsQ0FBMEJDLElBQTFCLENBQStCMkQsR0FBL0IsSUFBc0NDLEtBQXRDO0FBQ0Q7QUFDRixPQU5ELENBTUUsT0FBT0UsQ0FBUCxFQUFVO0FBQ1Y7QUFDRDtBQUNGOzs7c0NBQ2lCL0IsRyxFQUFLO0FBQ3JCLFVBQUlBLElBQUlnQyxJQUFKLEtBQWEsUUFBakIsRUFBMkI7QUFDekI7QUFDQXhCLGdCQUFRQyxHQUFSLENBQVlULElBQUlpQyxNQUFoQjtBQUNEO0FBQ0QsYUFBTztBQUNMOUIsZUFBTyxTQURGO0FBRUwrQixjQUFNO0FBRkQsT0FBUDtBQUlEOzs7O0VBNUcwQnhDLGVBQUt5QyxHIiwiZmlsZSI6ImFwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4gIGltcG9ydCB3ZXB5IGZyb20gXCJ3ZXB5XCI7XHJcbiAgaW1wb3J0IFwid2VweS1hc3luYy1mdW5jdGlvblwiO1xyXG4gIGltcG9ydCBXeFV0aWxzIGZyb20gXCIuL3V0aWxzL1d4VXRpbHNcIjtcclxuICBpbXBvcnQge1xyXG4gICAgc2V0U3RvcmVcclxuICB9IGZyb20gXCJ3ZXB5LXJlZHV4XCI7XHJcbiAgaW1wb3J0IGNvbmZpZ1N0b3JlIGZyb20gXCIuL3N0b3JlXCI7XHJcbiAgY29uc3Qgc3RvcmUgPSBjb25maWdTdG9yZSgpO1xyXG4gIHNldFN0b3JlKHN0b3JlKTtcclxuICBleHBvcnQgZGVmYXVsdCBjbGFzcyBleHRlbmRzIHdlcHkuYXBwIHtcclxuICAgIGdsb2JhbERhdGEgPSB7XHJcbiAgICAgIGF1dGg6IHt9LFxyXG4gICAgICBzY2VuZTogbnVsbCxcclxuICAgICAgYmFzZV9zdG9yZV9pZDogXCJcIixcclxuICAgICAgYXBwQ29kZTogXCJcIixcclxuICAgICAgYmFzZVVybDogXCJodHRwczovL3dlY2hhdC5oeHF4bHkuY29tXCIsXHJcbiAgICAgIC8vIGJhc2VVcmw6IFwiaHR0cDovLzEwLjAuMy4xNTA6ODgwOVwiLFxyXG4gICAgICB0aGVtZUNvbG9yOiBcIiNGNEQwMDBcIixcclxuICAgICAgY2l0eUNvZGU6JycsXHJcbiAgICAgIGNvZGU6JycsXHJcbiAgICAgIHNlc3Npb25JZDonJyxcclxuICAgICAgY291cnNlSW5mbzp7fSxcclxuICAgICAgb3JkZXJJbmZvOnt9LFxyXG4gICAgICBjaGlsZHM6W11cclxuICAgIH07XHJcbiAgICBjb25zdHJ1Y3RvcigpIHtcclxuICAgICAgc3VwZXIoKTtcclxuICAgICAgLy8g5rOo5YaM5Lit6Ze05Lu2XHJcbiAgICAgIHRoaXMudXNlKFwicmVxdWVzdGZpeFwiKTtcclxuICAgICAgdGhpcy51c2UoXCJwcm9taXNpZnlcIik7XHJcbiAgICB9XHJcbiAgICBhc3luYyBvbkxhdW5jaChwYXJhbSkge1xyXG4gICAgICAvLyDojrflj5blvZPliY3lsI/nqIvluo9cclxuICAgICAgdHJ5IHtcclxuICAgICAgICB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLmFwcENvZGUgPSB3eC5nZXRBY2NvdW50SW5mb1N5bmMoKS5taW5pUHJvZ3JhbS5hcHBJZDtcclxuICAgICAgfSBjYXRjaCAocmVzKSB7XHJcbiAgICAgICAgaWYgKHd4LmNhbklVc2UoXCJnZXRBY2NvdW50SW5mb1N5bmNcIikpIHtcclxuICAgICAgICAgIHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuYXBwQ29kZSA9IHd4LmdldEFjY291bnRJbmZvU3luYygpLm1pbmlQcm9ncmFtLmFwcElkO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAvLyDlpoLmnpzluIzmnJvnlKjmiLflnKjmnIDmlrDniYjmnKznmoTlrqLmiLfnq6/kuIrkvZPpqozmgqjnmoTlsI/nqIvluo/vvIzlj6/ku6Xov5nmoLflrZDmj5DnpLpcclxuICAgICAgICAgIHd4LnNob3dNb2RhbCh7XHJcbiAgICAgICAgICAgIHRpdGxlOiBcIuaPkOekulwiLFxyXG4gICAgICAgICAgICBjb250ZW50OiBcIuW9k+WJjeW+ruS/oeeJiOacrOi/h+S9ju+8jOaXoOazleS9v+eUqOivpeWKn+iDve+8jOivt+WNh+e6p+WIsOacgOaWsOW+ruS/oeeJiOacrOWQjumHjeivleOAglwiXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgICAgY29uc3QgdXBkYXRlTWFuYWdlciA9IHd4LmdldFVwZGF0ZU1hbmFnZXIoKTtcclxuICAgICAgdXBkYXRlTWFuYWdlci5vbkNoZWNrRm9yVXBkYXRlKGZ1bmN0aW9uKHJlcykge1xyXG4gICAgICAgIC8vIOivt+axguWujOaWsOeJiOacrOS/oeaBr+eahOWbnuiwg1xyXG4gICAgICAgIGNvbnNvbGUubG9nKHJlcy5oYXNVcGRhdGUpO1xyXG4gICAgICB9KTtcclxuICAgICAgdXBkYXRlTWFuYWdlci5vblVwZGF0ZVJlYWR5KGZ1bmN0aW9uKCkge1xyXG4gICAgICAgIHd4LnNob3dNb2RhbCh7XHJcbiAgICAgICAgICB0aXRsZTogXCLmm7TmlrDmj5DnpLpcIixcclxuICAgICAgICAgIGNvbnRlbnQ6IFwi5paw54mI5pys5bey57uP5YeG5aSH5aW977yM5piv5ZCm6YeN5ZCv5bqU55So77yfXCIsXHJcbiAgICAgICAgICBzdWNjZXNzOiBmdW5jdGlvbihyZXMpIHtcclxuICAgICAgICAgICAgaWYgKHJlcy5jb25maXJtKSB7XHJcbiAgICAgICAgICAgICAgLy8g5paw55qE54mI5pys5bey57uP5LiL6L295aW977yM6LCD55SoIGFwcGx5VXBkYXRlIOW6lOeUqOaWsOeJiOacrOW5tumHjeWQr1xyXG4gICAgICAgICAgICAgIHVwZGF0ZU1hbmFnZXIuYXBwbHlVcGRhdGUoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9KTtcclxuICAgICAgdXBkYXRlTWFuYWdlci5vblVwZGF0ZUZhaWxlZChmdW5jdGlvbigpIHtcclxuICAgICAgICAvLyDmlrDnmoTniYjmnKzkuIvovb3lpLHotKVcclxuICAgICAgICB3eC5zaG93TW9kYWwoe1xyXG4gICAgICAgICAgdGl0bGU6IFwi5pu05paw5o+Q56S6XCIsXHJcbiAgICAgICAgICBjb250ZW50OiBcIuaWsOeJiOacrOS4i+i9veWksei0pVwiLFxyXG4gICAgICAgICAgc2hvd0NhbmNlbDogZmFsc2VcclxuICAgICAgICB9KTtcclxuICAgICAgfSk7XHJcbiAgICAgIC8vIOagoemqjFNES1xyXG4gICAgICBXeFV0aWxzLmNoZWNrU0RLKCk7XHJcbiAgICAgIC8vIOWQjOatpeW8gOaUvuW5s+WPsEVYVOaVsOaNrlxyXG4gICAgICBjb25zdCBleHQgPSB3ZXB5LmdldEV4dENvbmZpZ1N5bmMoKTtcclxuICAgICAgLy8gY29uc29sZS5pbmZvKFwiW2V4dF0gaW5pdCBleHQgZGF0YVwiLCBleHQpO1xyXG4gICAgICBpZiAoZXh0Lmdsb2JhbENvbmZpZykge1xyXG4gICAgICAgIC8vIGNvbnNvbGUuaW5mbyhcIltleHRdIGluaXQgZXh0IGdsb2JhbCBjb25maWcgZGF0YVwiLCBleHQuZ2xvYmFsQ29uZmlnKTtcclxuICAgICAgICBPYmplY3QuYXNzaWduKGV4dCwgZXh0Lmdsb2JhbENvbmZpZyk7XHJcbiAgICAgIH1cclxuICAgICAgT2JqZWN0LmFzc2lnbih3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLCBleHQpO1xyXG4gICAgICAvLyBhdXRoLmxvZ2luKCk7XHJcbiAgICB9XHJcbiAgICBvblNob3cocGFyYW0pIHtcclxuICAgICAgY29uc29sZS5sb2cocGFyYW0pO1xyXG4gICAgICAvLyDojrflj5bkv53lrZjlnLrmma/lgLxcclxuICAgICAgaWYgKHBhcmFtICYmIHBhcmFtLnNjZW5lKSB7XHJcbiAgICAgICAgd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5zY2VuZSA9IHBhcmFtLnNjZW5lO1xyXG4gICAgICAgIGlmIChwYXJhbS5xdWVyeS5zKSB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLmJhc2Vfc3RvcmVfaWQgPSBwYXJhbS5xdWVyeS5zXHJcbiAgICAgICAgc3dpdGNoIChwYXJhbS5zY2VuZSkge1xyXG4gICAgICAgICAgLy8g5pyN5Yqh6YCa55+l5LiLXHJcbiAgICAgICAgICBjYXNlIDEwMTQ6XHJcbiAgICAgICAgICAgIGlmIChwYXJhbS5xdWVyeS5saWQpIHdlcHkuc2V0U3RvcmFnZVN5bmMoXCJsZXZlbF9pZFwiLCBwYXJhbS5xdWVyeS5saWQpO1xyXG4gICAgICAgICAgICBicmVhaztcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIHN5bmNTdG9yZUNvbmZpZyhrZXkpIHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCB2YWx1ZSA9IHdlcHkuZ2V0U3RvcmFnZVN5bmMoa2V5KTtcclxuICAgICAgICBpZiAodmFsdWUgIT09IFwiXCIpIHtcclxuICAgICAgICAgIC8vIGNvbnNvbGUuaW5mbyhgW2F1dGhdJHtrZXl9IHN5bmMgc3VjY2VzcyBgKTtcclxuICAgICAgICAgIHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuYXV0aFtrZXldID0gdmFsdWU7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgLy8gY29uc29sZS53YXJuKGBbYXV0aF0ke2tleX0gc3luYyBmYWlsIGApO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBvblNoYXJlQXBwTWVzc2FnZShyZXMpIHtcclxuICAgICAgaWYgKHJlcy5mcm9tID09PSBcImJ1dHRvblwiKSB7XHJcbiAgICAgICAgLy8g5p2l6Ieq6aG16Z2i5YaF6L2s5Y+R5oyJ6ZKuXHJcbiAgICAgICAgY29uc29sZS5sb2cocmVzLnRhcmdldCk7XHJcbiAgICAgIH1cclxuICAgICAgcmV0dXJuIHtcclxuICAgICAgICB0aXRsZTogXCLoh6rlrprkuYnovazlj5HmoIfpophcIixcclxuICAgICAgICBwYXRoOiBcIi9wYWdlcy9ob21lL2luZGV4XCJcclxuICAgICAgfTtcclxuICAgIH1cclxuICAgIGNvbmZpZyA9IHtcclxuICAgICAgcGFnZXM6IFtcclxuICAgICAgXCJwYWdlcy9ob21lL2luZGV4XCIsXHJcbiAgICAgIFwicGFnZXMvaG9tZS9zZWFyY2hcIixcclxuICAgICAgXCJwYWdlcy9ob21lL3dlYlwiLFxyXG4gICAgICBcInBhZ2VzL21lZXQvbWVldFwiLFxyXG4gICAgICBcInBhZ2VzL215L215XCIsXHJcbiAgICAgIFwicGFnZXMvbXkvb3JkZXJzXCIsXHJcbiAgICAgIFwicGFnZXMvbXkvb3JkZXJcIixcclxuICAgICAgXCJwYWdlcy9teS9iYXJnYWluaW5nXCIsXHJcbiAgICAgIFwicGFnZXMvaG9tZS9hZGRyZXNzXCIsXHJcbiAgICAgIFwicGFnZXMvZGV0YWlsZS9kZXRhaWxlXCIsXHJcbiAgICAgIFwicGFnZXMvZGV0YWlsZS9zdXJlT3JkZXJcIixcclxuICAgICAgXCJwYWdlcy9kZXRhaWxlL3BhcnRuZXJzXCIsXHJcbiAgICAgIFwicGFnZXMvbWVldC9jaGlsZHNcIixcclxuICAgICAgXCJwYWdlcy9tZWV0L2FkZENoaWxkXCIsXHJcbiAgICAgIFwicGFnZXMvbWVldC9hZGRNYW5cIixcclxuICAgICAgXCJwYWdlcy9tZWV0L3JlbWFya3NcIixcclxuICAgICAgXCJwYWdlcy9tZWV0L2NvbW1pUmVtYXJrZVwiLFxyXG4gICAgICBcInBhZ2VzL2FjdGl2aXR5L2JhcmdhaW5cIixcclxuICAgICAgXCJwYWdlcy9hY3Rpdml0eS9waW50dWFuXCIsXHJcbiAgICAgIF0sXHJcbiAgICAgIHdpbmRvdzoge1xyXG4gICAgICAgIGJhY2tncm91bmRUZXh0U3R5bGU6IFwiZGFya1wiLFxyXG4gICAgICAgIG5hdmlnYXRpb25CYXJCYWNrZ3JvdW5kQ29sb3I6IFwiI0Y0RDAwMFwiLFxyXG4gICAgICAgIGJhY2tncm91bmRDb2xvcjogXCIjZmZmXCIsXHJcbiAgICAgICAgbmF2aWdhdGlvbkJhclRpdGxlVGV4dDogXCJcIixcclxuICAgICAgICBuYXZpZ2F0aW9uQmFyVGV4dFN0eWxlOiBcIndoaXRlXCJcclxuICAgICAgfSxcclxuICAgICAgbmF2aWdhdGVUb01pbmlQcm9ncmFtQXBwSWRMaXN0OiBbXSxcclxuICAgICAgcGVybWlzc2lvbjoge1xyXG4gICAgICAgIFwic2NvcGUudXNlckxvY2F0aW9uXCI6IHtcclxuICAgICAgICAgIGRlc2M6IFwi5L2g55qE5L2N572u5L+h5oGv5bCG55So5LqO5bCP56iL5bqP5L2N572u55qE5pWI5p6c5bGV56S6XCJcclxuICAgICAgICB9XHJcbiAgICAgIH0sXHJcbiAgICAgIFwidGFiQmFyXCI6IHtcclxuICAgICAgICBcImNvbG9yXCI6IFwiI2E5YjdiN1wiLFxyXG4gICAgICAgIFwic2VsZWN0ZWRDb2xvclwiOiBcIiNGNEQwMDBcIixcclxuICAgICAgICBcImJvcmRlclN0eWxlXCI6IFwiYmxhY2tcIixcclxuICAgICAgICBcImxpc3RcIjogW1xyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBcInNlbGVjdGVkSWNvblBhdGhcIjogXCJzdGF0aWMvaW1hZ2VzL2ljb25fY29uc3VsdF9wcmVzcy5wbmdcIixcclxuICAgICAgICAgICAgXCJpY29uUGF0aFwiOiBcInN0YXRpYy9pbWFnZXMvaWNvbl9jb25zdWx0LnBuZ1wiLFxyXG4gICAgICAgICAgICBcInBhZ2VQYXRoXCI6IFwicGFnZXMvaG9tZS9pbmRleFwiLFxyXG4gICAgICAgICAgICBcInRleHRcIjogXCLpppbpobVcIlxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgXCJzZWxlY3RlZEljb25QYXRoXCI6IFwic3RhdGljL2ltYWdlcy9pY29uX2ludmVzdF9wcmVzcy5wbmdcIixcclxuICAgICAgICAgICAgXCJpY29uUGF0aFwiOiBcInN0YXRpYy9pbWFnZXMvaWNvbl9pbnZlc3QucG5nXCIsXHJcbiAgICAgICAgICAgIFwicGFnZVBhdGhcIjogXCJwYWdlcy9tZWV0L21lZXRcIixcclxuICAgICAgICAgICAgXCJ0ZXh0XCI6IFwi5LqS5YqoXCJcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIFwic2VsZWN0ZWRJY29uUGF0aFwiOiBcInN0YXRpYy9pbWFnZXMvaWNvbl9taW5lX3ByZXNzLnBuZ1wiLFxyXG4gICAgICAgICAgICBcImljb25QYXRoXCI6IFwic3RhdGljL2ltYWdlcy9pY29uX21pbmUucG5nXCIsXHJcbiAgICAgICAgICAgIFwicGFnZVBhdGhcIjogXCJwYWdlcy9teS9teVwiLFxyXG4gICAgICAgICAgICBcInRleHRcIjogXCLmiJHnmoRcIlxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIF1cclxuICAgICAgfVxyXG4gICAgfTtcclxuICB9XHJcbiJdfQ==