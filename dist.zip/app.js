"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

require('./npm/wepy-async-function/index.js');

var _WxUtils = require('./utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

var _wepyRedux = require('./npm/wepy-redux/lib/index.js');

var _store = require('./store/index.js');

var _store2 = _interopRequireDefault(_store);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var store = (0, _store2.default)();
(0, _wepyRedux.setStore)(store);

var _default = function (_wepy$app) {
  _inherits(_default, _wepy$app);

  function _default() {
    _classCallCheck(this, _default);

    // 注册中间件
    var _this = _possibleConstructorReturn(this, (_default.__proto__ || Object.getPrototypeOf(_default)).call(this));

    _this.globalData = {
      auth: {},
      scene: null,
      base_store_id: "",
      appCode: "",
      // baseUrl: "https://wechat.hxqxly.com",
      baseUrl: "https://test.hxqxly.com",
      themeColor: "#215E21",
      cityCode: "",
      code: "",
      sessionId: "",
      courseInfo: {},
      orderInfo: {},
      childs: [],
      help: true,
      query: {},
      picView: ''
    };
    _this.config = {
      pages: ["pages/home/index", "pages/home/auth", "pages/home/search", "pages/home/web", "pages/home/share", "pages/home/picView", "pages/meet/meet", "pages/my/my", "pages/my/orders", "pages/my/order", "pages/my/pintuan", "pages/my/bargaining", "pages/home/address", "pages/detaile/detaile", "pages/detaile/sureOrder", "pages/detaile/partners", "pages/meet/childs", "pages/meet/addChild", "pages/meet/addMan", "pages/meet/remarks", "pages/meet/commiRemarke", "pages/activity/bargain", "pages/activity/pintuan"],
      subPackages: [{
        root: "agent",
        pages: ["pages/index", "pages/share", "pages/sign", "pages/buyVip", "pages/my", "pages/orders", "pages/fans"]
      }, {
        root: "actPages",
        pages: ["pages/answer", "pages/answerAct", "pages/index", "pages/rank"]
      }, {
        root: "coupons",
        pages: ["pages/cangets", "pages/myCoupons"]
      }, {
        root: "piaoju",
        pages: ["pages/page"]
      }, {
        root: "video",
        pages: ["pages/page"]
      }, {
        root: "crowdfund",
        pages: ["pages/page", "pages/sureOrder", "pages/help", "pages/orders"]
      }, {
        root: "student",
        pages: ["pages/index"]
      }],
      window: {
        backgroundTextStyle: "dark",
        navigationBarBackgroundColor: "#215E21",
        backgroundColor: "#fff",
        navigationBarTitleText: "",
        navigationBarTextStyle: "white"
      },
      navigateToMiniProgramAppIdList: [],
      permission: {
        "scope.userLocation": {
          desc: "你的位置信息将用于小程序位置的效果展示"
        }
      },
      tabBar: {
        color: "#a9b7b7",
        selectedColor: "#F4D000",
        borderStyle: "black",
        list: [{
          selectedIconPath: "static/images/icon_consult_press.png",
          iconPath: "static/images/icon_consult.png",
          pagePath: "pages/home/index",
          text: "首页"
        }, {
          selectedIconPath: "static/images/icon_invest_press.png",
          iconPath: "static/images/icon_invest.png",
          pagePath: "pages/meet/meet",
          text: "互动"
        }, {
          selectedIconPath: "static/images/icon_mine_press.png",
          iconPath: "static/images/icon_mine.png",
          pagePath: "pages/my/my",
          text: "我的"
        }]
      }
    };
    _this.use("requestfix");
    _this.use("promisify");
    return _this;
  }

  _createClass(_default, [{
    key: "onLaunch",
    value: function () {
      var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(param) {
        var updateManager, ext;
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                // 获取当前小程序
                try {
                  _wepy2.default.$instance.globalData.appCode = wx.getAccountInfoSync().miniProgram.appId;
                } catch (res) {
                  if (wx.canIUse("getAccountInfoSync")) {
                    _wepy2.default.$instance.globalData.appCode = wx.getAccountInfoSync().miniProgram.appId;
                  } else {
                    // 如果希望用户在最新版本的客户端上体验您的小程序，可以这样子提示
                    wx.showModal({
                      title: "提示",
                      content: "当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。"
                    });
                  }
                }
                updateManager = wx.getUpdateManager();

                updateManager.onCheckForUpdate(function (res) {
                  // 请求完新版本信息的回调
                  console.log(res.hasUpdate);
                });
                updateManager.onUpdateReady(function () {
                  wx.showModal({
                    title: "更新提示",
                    content: "新版本已经准备好，是否重启应用？",
                    success: function success(res) {
                      if (res.confirm) {
                        // 新的版本已经下载好，调用 applyUpdate 应用新版本并重启
                        updateManager.applyUpdate();
                      }
                    }
                  });
                });
                updateManager.onUpdateFailed(function () {
                  // 新的版本下载失败
                  wx.showModal({
                    title: "更新提示",
                    content: "新版本下载失败",
                    showCancel: false
                  });
                });
                // 校验SDK
                _WxUtils2.default.checkSDK();
                // 同步开放平台EXT数据
                ext = _wepy2.default.getExtConfigSync();
                // console.info("[ext] init ext data", ext);

                if (ext.globalConfig) {
                  // console.info("[ext] init ext global config data", ext.globalConfig);
                  Object.assign(ext, ext.globalConfig);
                }
                Object.assign(_wepy2.default.$instance.globalData, ext);
                // auth.login();

              case 9:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function onLaunch(_x) {
        return _ref.apply(this, arguments);
      }

      return onLaunch;
    }()
  }, {
    key: "onShow",
    value: function onShow(param) {
      console.log(param);
      // 获取保存场景值
      if (param && param.scene) {
        _wepy2.default.$instance.globalData.scene = param.scene;
        console.log();
        if (param.query.scene) {
          _wepy2.default.$instance.globalData.query = this.getCodeBy1047(param.query.scene);
        } else if (param.query.agentId) {
          _wepy2.default.$instance.globalData.query["agentId"] = param.query.agentId;
        }
      }
    }
  }, {
    key: "getCodeBy1047",
    value: function getCodeBy1047(str) {
      var query = {},
          strs = decodeURIComponent(str).split("&");

      for (var i = 0, len = strs.length; i < len; i++) {
        query[strs[i].split("=")[0]] = strs[i].split("=")[1];
      }
      return query;
    }
  }, {
    key: "syncStoreConfig",
    value: function syncStoreConfig(key) {
      try {
        var value = _wepy2.default.getStorageSync(key);
        if (value !== "") {
          // console.info(`[auth]${key} sync success `);
          _wepy2.default.$instance.globalData.auth[key] = value;
        }
      } catch (e) {
        // console.warn(`[auth]${key} sync fail `);
      }
    }
  }, {
    key: "onShareAppMessage",
    value: function onShareAppMessage(res) {
      if (res.from === "button") {
        // 来自页面内转发按钮
        console.log(res.target);
      }
      return {
        title: "自定义转发标题",
        path: "/pages/home/index"
      };
    }
  }]);

  return _default;
}(_wepy2.default.app);


App(require('./npm/wepy/lib/wepy.js').default.$createApp(_default, {"noPromiseAPI":["createSelectorQuery"]}));
require('./_wepylogs.js')

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC5qcyJdLCJuYW1lcyI6WyJzdG9yZSIsImdsb2JhbERhdGEiLCJhdXRoIiwic2NlbmUiLCJiYXNlX3N0b3JlX2lkIiwiYXBwQ29kZSIsImJhc2VVcmwiLCJ0aGVtZUNvbG9yIiwiY2l0eUNvZGUiLCJjb2RlIiwic2Vzc2lvbklkIiwiY291cnNlSW5mbyIsIm9yZGVySW5mbyIsImNoaWxkcyIsImhlbHAiLCJxdWVyeSIsInBpY1ZpZXciLCJjb25maWciLCJwYWdlcyIsInN1YlBhY2thZ2VzIiwicm9vdCIsIndpbmRvdyIsImJhY2tncm91bmRUZXh0U3R5bGUiLCJuYXZpZ2F0aW9uQmFyQmFja2dyb3VuZENvbG9yIiwiYmFja2dyb3VuZENvbG9yIiwibmF2aWdhdGlvbkJhclRpdGxlVGV4dCIsIm5hdmlnYXRpb25CYXJUZXh0U3R5bGUiLCJuYXZpZ2F0ZVRvTWluaVByb2dyYW1BcHBJZExpc3QiLCJwZXJtaXNzaW9uIiwiZGVzYyIsInRhYkJhciIsImNvbG9yIiwic2VsZWN0ZWRDb2xvciIsImJvcmRlclN0eWxlIiwibGlzdCIsInNlbGVjdGVkSWNvblBhdGgiLCJpY29uUGF0aCIsInBhZ2VQYXRoIiwidGV4dCIsInVzZSIsInBhcmFtIiwid2VweSIsIiRpbnN0YW5jZSIsInd4IiwiZ2V0QWNjb3VudEluZm9TeW5jIiwibWluaVByb2dyYW0iLCJhcHBJZCIsInJlcyIsImNhbklVc2UiLCJzaG93TW9kYWwiLCJ0aXRsZSIsImNvbnRlbnQiLCJ1cGRhdGVNYW5hZ2VyIiwiZ2V0VXBkYXRlTWFuYWdlciIsIm9uQ2hlY2tGb3JVcGRhdGUiLCJjb25zb2xlIiwibG9nIiwiaGFzVXBkYXRlIiwib25VcGRhdGVSZWFkeSIsInN1Y2Nlc3MiLCJjb25maXJtIiwiYXBwbHlVcGRhdGUiLCJvblVwZGF0ZUZhaWxlZCIsInNob3dDYW5jZWwiLCJXeFV0aWxzIiwiY2hlY2tTREsiLCJleHQiLCJnZXRFeHRDb25maWdTeW5jIiwiZ2xvYmFsQ29uZmlnIiwiT2JqZWN0IiwiYXNzaWduIiwiZ2V0Q29kZUJ5MTA0NyIsImFnZW50SWQiLCJzdHIiLCJzdHJzIiwiZGVjb2RlVVJJQ29tcG9uZW50Iiwic3BsaXQiLCJpIiwibGVuIiwibGVuZ3RoIiwia2V5IiwidmFsdWUiLCJnZXRTdG9yYWdlU3luYyIsImUiLCJmcm9tIiwidGFyZ2V0IiwicGF0aCIsImFwcCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQ0U7Ozs7QUFDQTs7QUFDQTs7OztBQUNBOztBQUdBOzs7Ozs7Ozs7Ozs7OztBQUNBLElBQU1BLFFBQVEsc0JBQWQ7QUFDQSx5QkFBU0EsS0FBVDs7Ozs7QUFvQkUsc0JBQWM7QUFBQTs7QUFFWjtBQUZZOztBQUFBLFVBbEJkQyxVQWtCYyxHQWxCRDtBQUNYQyxZQUFNLEVBREs7QUFFWEMsYUFBTyxJQUZJO0FBR1hDLHFCQUFlLEVBSEo7QUFJWEMsZUFBUyxFQUpFO0FBS1g7QUFDQUMsZUFBUyx5QkFORTtBQU9YQyxrQkFBWSxTQVBEO0FBUVhDLGdCQUFVLEVBUkM7QUFTWEMsWUFBTSxFQVRLO0FBVVhDLGlCQUFXLEVBVkE7QUFXWEMsa0JBQVksRUFYRDtBQVlYQyxpQkFBVyxFQVpBO0FBYVhDLGNBQVEsRUFiRztBQWNYQyxZQUFNLElBZEs7QUFlWEMsYUFBTyxFQWZJO0FBZ0JYQyxlQUFTO0FBaEJFLEtBa0JDO0FBQUEsVUFxR2RDLE1BckdjLEdBcUdMO0FBQ1BDLGFBQU8sQ0FDTCxrQkFESyxFQUVMLGlCQUZLLEVBR0wsbUJBSEssRUFJTCxnQkFKSyxFQUtMLGtCQUxLLEVBTUwsb0JBTkssRUFPTCxpQkFQSyxFQVFMLGFBUkssRUFTTCxpQkFUSyxFQVVMLGdCQVZLLEVBV0wsa0JBWEssRUFZTCxxQkFaSyxFQWFMLG9CQWJLLEVBY0wsdUJBZEssRUFlTCx5QkFmSyxFQWdCTCx3QkFoQkssRUFpQkwsbUJBakJLLEVBa0JMLHFCQWxCSyxFQW1CTCxtQkFuQkssRUFvQkwsb0JBcEJLLEVBcUJMLHlCQXJCSyxFQXNCTCx3QkF0QkssRUF1Qkwsd0JBdkJLLENBREE7QUEwQlBDLG1CQUFhLENBQUM7QUFDVkMsY0FBTSxPQURJO0FBRVZGLGVBQU8sQ0FBQyxhQUFELEVBQWdCLGFBQWhCLEVBQStCLFlBQS9CLEVBQTZDLGNBQTdDLEVBQTZELFVBQTdELEVBQXlFLGNBQXpFLEVBQ0wsWUFESztBQUZHLE9BQUQsRUFNWDtBQUNFRSxjQUFNLFVBRFI7QUFFRUYsZUFBTyxDQUFDLGNBQUQsRUFBaUIsaUJBQWpCLEVBQW9DLGFBQXBDLEVBQW1ELFlBQW5EO0FBRlQsT0FOVyxFQVVYO0FBQ0VFLGNBQU0sU0FEUjtBQUVFRixlQUFPLENBQUMsZUFBRCxFQUFrQixpQkFBbEI7QUFGVCxPQVZXLEVBY1g7QUFDRUUsY0FBTSxRQURSO0FBRUVGLGVBQU8sQ0FBQyxZQUFEO0FBRlQsT0FkVyxFQWtCWDtBQUNFRSxjQUFNLE9BRFI7QUFFRUYsZUFBTyxDQUFDLFlBQUQ7QUFGVCxPQWxCVyxFQXNCWDtBQUNFRSxjQUFNLFdBRFI7QUFFRUYsZUFBTyxDQUFDLFlBQUQsRUFBZSxpQkFBZixFQUFrQyxZQUFsQyxFQUFnRCxjQUFoRDtBQUZULE9BdEJXLEVBMEJYO0FBQ0VFLGNBQU0sU0FEUjtBQUVFRixlQUFPLENBQUMsYUFBRDtBQUZULE9BMUJXLENBMUJOO0FBMERQRyxjQUFRO0FBQ05DLDZCQUFxQixNQURmO0FBRU5DLHNDQUE4QixTQUZ4QjtBQUdOQyx5QkFBaUIsTUFIWDtBQUlOQyxnQ0FBd0IsRUFKbEI7QUFLTkMsZ0NBQXdCO0FBTGxCLE9BMUREO0FBaUVQQyxzQ0FBZ0MsRUFqRXpCO0FBa0VQQyxrQkFBWTtBQUNWLDhCQUFzQjtBQUNwQkMsZ0JBQU07QUFEYztBQURaLE9BbEVMO0FBdUVQQyxjQUFRO0FBQ05DLGVBQU8sU0FERDtBQUVOQyx1QkFBZSxTQUZUO0FBR05DLHFCQUFhLE9BSFA7QUFJTkMsY0FBTSxDQUFDO0FBQ0hDLDRCQUFrQixzQ0FEZjtBQUVIQyxvQkFBVSxnQ0FGUDtBQUdIQyxvQkFBVSxrQkFIUDtBQUlIQyxnQkFBTTtBQUpILFNBQUQsRUFNSjtBQUNFSCw0QkFBa0IscUNBRHBCO0FBRUVDLG9CQUFVLCtCQUZaO0FBR0VDLG9CQUFVLGlCQUhaO0FBSUVDLGdCQUFNO0FBSlIsU0FOSSxFQVlKO0FBQ0VILDRCQUFrQixtQ0FEcEI7QUFFRUMsb0JBQVUsNkJBRlo7QUFHRUMsb0JBQVUsYUFIWjtBQUlFQyxnQkFBTTtBQUpSLFNBWkk7QUFKQTtBQXZFRCxLQXJHSztBQUdaLFVBQUtDLEdBQUwsQ0FBUyxZQUFUO0FBQ0EsVUFBS0EsR0FBTCxDQUFTLFdBQVQ7QUFKWTtBQUtiOzs7OzswRkFDY0MsSzs7Ozs7O0FBQ2I7QUFDQSxvQkFBSTtBQUNGQyxpQ0FBS0MsU0FBTCxDQUFlekMsVUFBZixDQUEwQkksT0FBMUIsR0FBb0NzQyxHQUFHQyxrQkFBSCxHQUF3QkMsV0FBeEIsQ0FBb0NDLEtBQXhFO0FBQ0QsaUJBRkQsQ0FFRSxPQUFPQyxHQUFQLEVBQVk7QUFDWixzQkFBSUosR0FBR0ssT0FBSCxDQUFXLG9CQUFYLENBQUosRUFBc0M7QUFDcENQLG1DQUFLQyxTQUFMLENBQWV6QyxVQUFmLENBQTBCSSxPQUExQixHQUFvQ3NDLEdBQUdDLGtCQUFILEdBQXdCQyxXQUF4QixDQUFvQ0MsS0FBeEU7QUFDRCxtQkFGRCxNQUVPO0FBQ0w7QUFDQUgsdUJBQUdNLFNBQUgsQ0FBYTtBQUNYQyw2QkFBTyxJQURJO0FBRVhDLCtCQUFTO0FBRkUscUJBQWI7QUFJRDtBQUNGO0FBQ0tDLDZCLEdBQWdCVCxHQUFHVSxnQkFBSCxFOztBQUN0QkQsOEJBQWNFLGdCQUFkLENBQStCLFVBQVNQLEdBQVQsRUFBYztBQUMzQztBQUNBUSwwQkFBUUMsR0FBUixDQUFZVCxJQUFJVSxTQUFoQjtBQUNELGlCQUhEO0FBSUFMLDhCQUFjTSxhQUFkLENBQTRCLFlBQVc7QUFDckNmLHFCQUFHTSxTQUFILENBQWE7QUFDWEMsMkJBQU8sTUFESTtBQUVYQyw2QkFBUyxrQkFGRTtBQUdYUSw2QkFBUyxpQkFBU1osR0FBVCxFQUFjO0FBQ3JCLDBCQUFJQSxJQUFJYSxPQUFSLEVBQWlCO0FBQ2Y7QUFDQVIsc0NBQWNTLFdBQWQ7QUFDRDtBQUNGO0FBUlUsbUJBQWI7QUFVRCxpQkFYRDtBQVlBVCw4QkFBY1UsY0FBZCxDQUE2QixZQUFXO0FBQ3RDO0FBQ0FuQixxQkFBR00sU0FBSCxDQUFhO0FBQ1hDLDJCQUFPLE1BREk7QUFFWEMsNkJBQVMsU0FGRTtBQUdYWSxnQ0FBWTtBQUhELG1CQUFiO0FBS0QsaUJBUEQ7QUFRQTtBQUNBQyxrQ0FBUUMsUUFBUjtBQUNBO0FBQ01DLG1CLEdBQU16QixlQUFLMEIsZ0JBQUwsRTtBQUNaOztBQUNBLG9CQUFJRCxJQUFJRSxZQUFSLEVBQXNCO0FBQ3BCO0FBQ0FDLHlCQUFPQyxNQUFQLENBQWNKLEdBQWQsRUFBbUJBLElBQUlFLFlBQXZCO0FBQ0Q7QUFDREMsdUJBQU9DLE1BQVAsQ0FBYzdCLGVBQUtDLFNBQUwsQ0FBZXpDLFVBQTdCLEVBQXlDaUUsR0FBekM7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7OzJCQUVLMUIsSyxFQUFPO0FBQ1plLGNBQVFDLEdBQVIsQ0FBWWhCLEtBQVo7QUFDQTtBQUNBLFVBQUlBLFNBQVNBLE1BQU1yQyxLQUFuQixFQUEwQjtBQUN4QnNDLHVCQUFLQyxTQUFMLENBQWV6QyxVQUFmLENBQTBCRSxLQUExQixHQUFrQ3FDLE1BQU1yQyxLQUF4QztBQUNBb0QsZ0JBQVFDLEdBQVI7QUFDQSxZQUFJaEIsTUFBTXpCLEtBQU4sQ0FBWVosS0FBaEIsRUFBdUI7QUFDckJzQyx5QkFBS0MsU0FBTCxDQUFlekMsVUFBZixDQUEwQmMsS0FBMUIsR0FBa0MsS0FBS3dELGFBQUwsQ0FBbUIvQixNQUFNekIsS0FBTixDQUFZWixLQUEvQixDQUFsQztBQUNELFNBRkQsTUFFTyxJQUFJcUMsTUFBTXpCLEtBQU4sQ0FBWXlELE9BQWhCLEVBQXlCO0FBQzlCL0IseUJBQUtDLFNBQUwsQ0FBZXpDLFVBQWYsQ0FBMEJjLEtBQTFCLENBQWdDLFNBQWhDLElBQTZDeUIsTUFBTXpCLEtBQU4sQ0FBWXlELE9BQXpEO0FBQ0Q7QUFDRjtBQUNGOzs7a0NBQ2FDLEcsRUFBSztBQUNqQixVQUFJMUQsUUFBUSxFQUFaO0FBQUEsVUFDRTJELE9BQU9DLG1CQUFtQkYsR0FBbkIsRUFBd0JHLEtBQXhCLENBQThCLEdBQTlCLENBRFQ7O0FBR0EsV0FBSyxJQUFJQyxJQUFJLENBQVIsRUFBV0MsTUFBTUosS0FBS0ssTUFBM0IsRUFBbUNGLElBQUlDLEdBQXZDLEVBQTRDRCxHQUE1QyxFQUFpRDtBQUMvQzlELGNBQU0yRCxLQUFLRyxDQUFMLEVBQVFELEtBQVIsQ0FBYyxHQUFkLEVBQW1CLENBQW5CLENBQU4sSUFBK0JGLEtBQUtHLENBQUwsRUFBUUQsS0FBUixDQUFjLEdBQWQsRUFBbUIsQ0FBbkIsQ0FBL0I7QUFDRDtBQUNELGFBQU83RCxLQUFQO0FBQ0Q7OztvQ0FDZWlFLEcsRUFBSztBQUNuQixVQUFJO0FBQ0YsWUFBTUMsUUFBUXhDLGVBQUt5QyxjQUFMLENBQW9CRixHQUFwQixDQUFkO0FBQ0EsWUFBSUMsVUFBVSxFQUFkLEVBQWtCO0FBQ2hCO0FBQ0F4Qyx5QkFBS0MsU0FBTCxDQUFlekMsVUFBZixDQUEwQkMsSUFBMUIsQ0FBK0I4RSxHQUEvQixJQUFzQ0MsS0FBdEM7QUFDRDtBQUNGLE9BTkQsQ0FNRSxPQUFPRSxDQUFQLEVBQVU7QUFDVjtBQUNEO0FBQ0Y7OztzQ0FDaUJwQyxHLEVBQUs7QUFDckIsVUFBSUEsSUFBSXFDLElBQUosS0FBYSxRQUFqQixFQUEyQjtBQUN6QjtBQUNBN0IsZ0JBQVFDLEdBQVIsQ0FBWVQsSUFBSXNDLE1BQWhCO0FBQ0Q7QUFDRCxhQUFPO0FBQ0xuQyxlQUFPLFNBREY7QUFFTG9DLGNBQU07QUFGRCxPQUFQO0FBSUQ7Ozs7RUF2SDBCN0MsZUFBSzhDLEciLCJmaWxlIjoiYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbiAgaW1wb3J0IHdlcHkgZnJvbSBcIndlcHlcIjtcclxuICBpbXBvcnQgXCJ3ZXB5LWFzeW5jLWZ1bmN0aW9uXCI7XHJcbiAgaW1wb3J0IFd4VXRpbHMgZnJvbSBcIi4vdXRpbHMvV3hVdGlsc1wiO1xyXG4gIGltcG9ydCB7XHJcbiAgICBzZXRTdG9yZVxyXG4gIH0gZnJvbSBcIndlcHktcmVkdXhcIjtcclxuICBpbXBvcnQgY29uZmlnU3RvcmUgZnJvbSBcIi4vc3RvcmVcIjtcclxuICBjb25zdCBzdG9yZSA9IGNvbmZpZ1N0b3JlKCk7XHJcbiAgc2V0U3RvcmUoc3RvcmUpO1xyXG4gIGV4cG9ydCBkZWZhdWx0IGNsYXNzIGV4dGVuZHMgd2VweS5hcHAge1xyXG4gICAgZ2xvYmFsRGF0YSA9IHtcclxuICAgICAgYXV0aDoge30sXHJcbiAgICAgIHNjZW5lOiBudWxsLFxyXG4gICAgICBiYXNlX3N0b3JlX2lkOiBcIlwiLFxyXG4gICAgICBhcHBDb2RlOiBcIlwiLFxyXG4gICAgICAvLyBiYXNlVXJsOiBcImh0dHBzOi8vd2VjaGF0Lmh4cXhseS5jb21cIixcclxuICAgICAgYmFzZVVybDogXCJodHRwczovL3Rlc3QuaHhxeGx5LmNvbVwiLFxyXG4gICAgICB0aGVtZUNvbG9yOiBcIiMyMTVFMjFcIixcclxuICAgICAgY2l0eUNvZGU6IFwiXCIsXHJcbiAgICAgIGNvZGU6IFwiXCIsXHJcbiAgICAgIHNlc3Npb25JZDogXCJcIixcclxuICAgICAgY291cnNlSW5mbzoge30sXHJcbiAgICAgIG9yZGVySW5mbzoge30sXHJcbiAgICAgIGNoaWxkczogW10sXHJcbiAgICAgIGhlbHA6IHRydWUsXHJcbiAgICAgIHF1ZXJ5OiB7fSxcclxuICAgICAgcGljVmlldzogJydcclxuICAgIH07XHJcbiAgICBjb25zdHJ1Y3RvcigpIHtcclxuICAgICAgc3VwZXIoKTtcclxuICAgICAgLy8g5rOo5YaM5Lit6Ze05Lu2XHJcbiAgICAgIHRoaXMudXNlKFwicmVxdWVzdGZpeFwiKTtcclxuICAgICAgdGhpcy51c2UoXCJwcm9taXNpZnlcIik7XHJcbiAgICB9XHJcbiAgICBhc3luYyBvbkxhdW5jaChwYXJhbSkge1xyXG4gICAgICAvLyDojrflj5blvZPliY3lsI/nqIvluo9cclxuICAgICAgdHJ5IHtcclxuICAgICAgICB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLmFwcENvZGUgPSB3eC5nZXRBY2NvdW50SW5mb1N5bmMoKS5taW5pUHJvZ3JhbS5hcHBJZDtcclxuICAgICAgfSBjYXRjaCAocmVzKSB7XHJcbiAgICAgICAgaWYgKHd4LmNhbklVc2UoXCJnZXRBY2NvdW50SW5mb1N5bmNcIikpIHtcclxuICAgICAgICAgIHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuYXBwQ29kZSA9IHd4LmdldEFjY291bnRJbmZvU3luYygpLm1pbmlQcm9ncmFtLmFwcElkO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAvLyDlpoLmnpzluIzmnJvnlKjmiLflnKjmnIDmlrDniYjmnKznmoTlrqLmiLfnq6/kuIrkvZPpqozmgqjnmoTlsI/nqIvluo/vvIzlj6/ku6Xov5nmoLflrZDmj5DnpLpcclxuICAgICAgICAgIHd4LnNob3dNb2RhbCh7XHJcbiAgICAgICAgICAgIHRpdGxlOiBcIuaPkOekulwiLFxyXG4gICAgICAgICAgICBjb250ZW50OiBcIuW9k+WJjeW+ruS/oeeJiOacrOi/h+S9ju+8jOaXoOazleS9v+eUqOivpeWKn+iDve+8jOivt+WNh+e6p+WIsOacgOaWsOW+ruS/oeeJiOacrOWQjumHjeivleOAglwiXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgICAgY29uc3QgdXBkYXRlTWFuYWdlciA9IHd4LmdldFVwZGF0ZU1hbmFnZXIoKTtcclxuICAgICAgdXBkYXRlTWFuYWdlci5vbkNoZWNrRm9yVXBkYXRlKGZ1bmN0aW9uKHJlcykge1xyXG4gICAgICAgIC8vIOivt+axguWujOaWsOeJiOacrOS/oeaBr+eahOWbnuiwg1xyXG4gICAgICAgIGNvbnNvbGUubG9nKHJlcy5oYXNVcGRhdGUpO1xyXG4gICAgICB9KTtcclxuICAgICAgdXBkYXRlTWFuYWdlci5vblVwZGF0ZVJlYWR5KGZ1bmN0aW9uKCkge1xyXG4gICAgICAgIHd4LnNob3dNb2RhbCh7XHJcbiAgICAgICAgICB0aXRsZTogXCLmm7TmlrDmj5DnpLpcIixcclxuICAgICAgICAgIGNvbnRlbnQ6IFwi5paw54mI5pys5bey57uP5YeG5aSH5aW977yM5piv5ZCm6YeN5ZCv5bqU55So77yfXCIsXHJcbiAgICAgICAgICBzdWNjZXNzOiBmdW5jdGlvbihyZXMpIHtcclxuICAgICAgICAgICAgaWYgKHJlcy5jb25maXJtKSB7XHJcbiAgICAgICAgICAgICAgLy8g5paw55qE54mI5pys5bey57uP5LiL6L295aW977yM6LCD55SoIGFwcGx5VXBkYXRlIOW6lOeUqOaWsOeJiOacrOW5tumHjeWQr1xyXG4gICAgICAgICAgICAgIHVwZGF0ZU1hbmFnZXIuYXBwbHlVcGRhdGUoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9KTtcclxuICAgICAgdXBkYXRlTWFuYWdlci5vblVwZGF0ZUZhaWxlZChmdW5jdGlvbigpIHtcclxuICAgICAgICAvLyDmlrDnmoTniYjmnKzkuIvovb3lpLHotKVcclxuICAgICAgICB3eC5zaG93TW9kYWwoe1xyXG4gICAgICAgICAgdGl0bGU6IFwi5pu05paw5o+Q56S6XCIsXHJcbiAgICAgICAgICBjb250ZW50OiBcIuaWsOeJiOacrOS4i+i9veWksei0pVwiLFxyXG4gICAgICAgICAgc2hvd0NhbmNlbDogZmFsc2VcclxuICAgICAgICB9KTtcclxuICAgICAgfSk7XHJcbiAgICAgIC8vIOagoemqjFNES1xyXG4gICAgICBXeFV0aWxzLmNoZWNrU0RLKCk7XHJcbiAgICAgIC8vIOWQjOatpeW8gOaUvuW5s+WPsEVYVOaVsOaNrlxyXG4gICAgICBjb25zdCBleHQgPSB3ZXB5LmdldEV4dENvbmZpZ1N5bmMoKTtcclxuICAgICAgLy8gY29uc29sZS5pbmZvKFwiW2V4dF0gaW5pdCBleHQgZGF0YVwiLCBleHQpO1xyXG4gICAgICBpZiAoZXh0Lmdsb2JhbENvbmZpZykge1xyXG4gICAgICAgIC8vIGNvbnNvbGUuaW5mbyhcIltleHRdIGluaXQgZXh0IGdsb2JhbCBjb25maWcgZGF0YVwiLCBleHQuZ2xvYmFsQ29uZmlnKTtcclxuICAgICAgICBPYmplY3QuYXNzaWduKGV4dCwgZXh0Lmdsb2JhbENvbmZpZyk7XHJcbiAgICAgIH1cclxuICAgICAgT2JqZWN0LmFzc2lnbih3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLCBleHQpO1xyXG4gICAgICAvLyBhdXRoLmxvZ2luKCk7XHJcbiAgICB9XHJcbiAgICBvblNob3cocGFyYW0pIHtcclxuICAgICAgY29uc29sZS5sb2cocGFyYW0pO1xyXG4gICAgICAvLyDojrflj5bkv53lrZjlnLrmma/lgLxcclxuICAgICAgaWYgKHBhcmFtICYmIHBhcmFtLnNjZW5lKSB7XHJcbiAgICAgICAgd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5zY2VuZSA9IHBhcmFtLnNjZW5lO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCk7XHJcbiAgICAgICAgaWYgKHBhcmFtLnF1ZXJ5LnNjZW5lKSB7XHJcbiAgICAgICAgICB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnF1ZXJ5ID0gdGhpcy5nZXRDb2RlQnkxMDQ3KHBhcmFtLnF1ZXJ5LnNjZW5lKTtcclxuICAgICAgICB9IGVsc2UgaWYgKHBhcmFtLnF1ZXJ5LmFnZW50SWQpIHtcclxuICAgICAgICAgIHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEucXVlcnlbXCJhZ2VudElkXCJdID0gcGFyYW0ucXVlcnkuYWdlbnRJZDtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIGdldENvZGVCeTEwNDcoc3RyKSB7XHJcbiAgICAgIHZhciBxdWVyeSA9IHt9LFxyXG4gICAgICAgIHN0cnMgPSBkZWNvZGVVUklDb21wb25lbnQoc3RyKS5zcGxpdChcIiZcIik7XHJcblxyXG4gICAgICBmb3IgKHZhciBpID0gMCwgbGVuID0gc3Rycy5sZW5ndGg7IGkgPCBsZW47IGkrKykge1xyXG4gICAgICAgIHF1ZXJ5W3N0cnNbaV0uc3BsaXQoXCI9XCIpWzBdXSA9IHN0cnNbaV0uc3BsaXQoXCI9XCIpWzFdO1xyXG4gICAgICB9XHJcbiAgICAgIHJldHVybiBxdWVyeTtcclxuICAgIH1cclxuICAgIHN5bmNTdG9yZUNvbmZpZyhrZXkpIHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCB2YWx1ZSA9IHdlcHkuZ2V0U3RvcmFnZVN5bmMoa2V5KTtcclxuICAgICAgICBpZiAodmFsdWUgIT09IFwiXCIpIHtcclxuICAgICAgICAgIC8vIGNvbnNvbGUuaW5mbyhgW2F1dGhdJHtrZXl9IHN5bmMgc3VjY2VzcyBgKTtcclxuICAgICAgICAgIHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuYXV0aFtrZXldID0gdmFsdWU7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgLy8gY29uc29sZS53YXJuKGBbYXV0aF0ke2tleX0gc3luYyBmYWlsIGApO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBvblNoYXJlQXBwTWVzc2FnZShyZXMpIHtcclxuICAgICAgaWYgKHJlcy5mcm9tID09PSBcImJ1dHRvblwiKSB7XHJcbiAgICAgICAgLy8g5p2l6Ieq6aG16Z2i5YaF6L2s5Y+R5oyJ6ZKuXHJcbiAgICAgICAgY29uc29sZS5sb2cocmVzLnRhcmdldCk7XHJcbiAgICAgIH1cclxuICAgICAgcmV0dXJuIHtcclxuICAgICAgICB0aXRsZTogXCLoh6rlrprkuYnovazlj5HmoIfpophcIixcclxuICAgICAgICBwYXRoOiBcIi9wYWdlcy9ob21lL2luZGV4XCJcclxuICAgICAgfTtcclxuICAgIH1cclxuICAgIGNvbmZpZyA9IHtcclxuICAgICAgcGFnZXM6IFtcclxuICAgICAgICBcInBhZ2VzL2hvbWUvaW5kZXhcIixcclxuICAgICAgICBcInBhZ2VzL2hvbWUvYXV0aFwiLFxyXG4gICAgICAgIFwicGFnZXMvaG9tZS9zZWFyY2hcIixcclxuICAgICAgICBcInBhZ2VzL2hvbWUvd2ViXCIsXHJcbiAgICAgICAgXCJwYWdlcy9ob21lL3NoYXJlXCIsXHJcbiAgICAgICAgXCJwYWdlcy9ob21lL3BpY1ZpZXdcIixcclxuICAgICAgICBcInBhZ2VzL21lZXQvbWVldFwiLFxyXG4gICAgICAgIFwicGFnZXMvbXkvbXlcIixcclxuICAgICAgICBcInBhZ2VzL215L29yZGVyc1wiLFxyXG4gICAgICAgIFwicGFnZXMvbXkvb3JkZXJcIixcclxuICAgICAgICBcInBhZ2VzL215L3BpbnR1YW5cIixcclxuICAgICAgICBcInBhZ2VzL215L2JhcmdhaW5pbmdcIixcclxuICAgICAgICBcInBhZ2VzL2hvbWUvYWRkcmVzc1wiLFxyXG4gICAgICAgIFwicGFnZXMvZGV0YWlsZS9kZXRhaWxlXCIsXHJcbiAgICAgICAgXCJwYWdlcy9kZXRhaWxlL3N1cmVPcmRlclwiLFxyXG4gICAgICAgIFwicGFnZXMvZGV0YWlsZS9wYXJ0bmVyc1wiLFxyXG4gICAgICAgIFwicGFnZXMvbWVldC9jaGlsZHNcIixcclxuICAgICAgICBcInBhZ2VzL21lZXQvYWRkQ2hpbGRcIixcclxuICAgICAgICBcInBhZ2VzL21lZXQvYWRkTWFuXCIsXHJcbiAgICAgICAgXCJwYWdlcy9tZWV0L3JlbWFya3NcIixcclxuICAgICAgICBcInBhZ2VzL21lZXQvY29tbWlSZW1hcmtlXCIsXHJcbiAgICAgICAgXCJwYWdlcy9hY3Rpdml0eS9iYXJnYWluXCIsXHJcbiAgICAgICAgXCJwYWdlcy9hY3Rpdml0eS9waW50dWFuXCJcclxuICAgICAgXSxcclxuICAgICAgc3ViUGFja2FnZXM6IFt7XHJcbiAgICAgICAgICByb290OiBcImFnZW50XCIsXHJcbiAgICAgICAgICBwYWdlczogW1wicGFnZXMvaW5kZXhcIiwgXCJwYWdlcy9zaGFyZVwiLCBcInBhZ2VzL3NpZ25cIiwgXCJwYWdlcy9idXlWaXBcIiwgXCJwYWdlcy9teVwiLCBcInBhZ2VzL29yZGVyc1wiLFxyXG4gICAgICAgICAgICBcInBhZ2VzL2ZhbnNcIlxyXG4gICAgICAgICAgXVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgcm9vdDogXCJhY3RQYWdlc1wiLFxyXG4gICAgICAgICAgcGFnZXM6IFtcInBhZ2VzL2Fuc3dlclwiLCBcInBhZ2VzL2Fuc3dlckFjdFwiLCBcInBhZ2VzL2luZGV4XCIsIFwicGFnZXMvcmFua1wiXVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgcm9vdDogXCJjb3Vwb25zXCIsXHJcbiAgICAgICAgICBwYWdlczogW1wicGFnZXMvY2FuZ2V0c1wiLCBcInBhZ2VzL215Q291cG9uc1wiXVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgcm9vdDogXCJwaWFvanVcIixcclxuICAgICAgICAgIHBhZ2VzOiBbXCJwYWdlcy9wYWdlXCJdXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICByb290OiBcInZpZGVvXCIsXHJcbiAgICAgICAgICBwYWdlczogW1wicGFnZXMvcGFnZVwiXVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgcm9vdDogXCJjcm93ZGZ1bmRcIixcclxuICAgICAgICAgIHBhZ2VzOiBbXCJwYWdlcy9wYWdlXCIsIFwicGFnZXMvc3VyZU9yZGVyXCIsIFwicGFnZXMvaGVscFwiLCBcInBhZ2VzL29yZGVyc1wiXVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgcm9vdDogXCJzdHVkZW50XCIsXHJcbiAgICAgICAgICBwYWdlczogW1wicGFnZXMvaW5kZXhcIl1cclxuICAgICAgICB9XHJcblxyXG4gICAgICBdLFxyXG4gICAgICB3aW5kb3c6IHtcclxuICAgICAgICBiYWNrZ3JvdW5kVGV4dFN0eWxlOiBcImRhcmtcIixcclxuICAgICAgICBuYXZpZ2F0aW9uQmFyQmFja2dyb3VuZENvbG9yOiBcIiMyMTVFMjFcIixcclxuICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IFwiI2ZmZlwiLFxyXG4gICAgICAgIG5hdmlnYXRpb25CYXJUaXRsZVRleHQ6IFwiXCIsXHJcbiAgICAgICAgbmF2aWdhdGlvbkJhclRleHRTdHlsZTogXCJ3aGl0ZVwiXHJcbiAgICAgIH0sXHJcbiAgICAgIG5hdmlnYXRlVG9NaW5pUHJvZ3JhbUFwcElkTGlzdDogW10sXHJcbiAgICAgIHBlcm1pc3Npb246IHtcclxuICAgICAgICBcInNjb3BlLnVzZXJMb2NhdGlvblwiOiB7XHJcbiAgICAgICAgICBkZXNjOiBcIuS9oOeahOS9jee9ruS/oeaBr+WwhueUqOS6juWwj+eoi+W6j+S9jee9rueahOaViOaenOWxleekulwiXHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG4gICAgICB0YWJCYXI6IHtcclxuICAgICAgICBjb2xvcjogXCIjYTliN2I3XCIsXHJcbiAgICAgICAgc2VsZWN0ZWRDb2xvcjogXCIjRjREMDAwXCIsXHJcbiAgICAgICAgYm9yZGVyU3R5bGU6IFwiYmxhY2tcIixcclxuICAgICAgICBsaXN0OiBbe1xyXG4gICAgICAgICAgICBzZWxlY3RlZEljb25QYXRoOiBcInN0YXRpYy9pbWFnZXMvaWNvbl9jb25zdWx0X3ByZXNzLnBuZ1wiLFxyXG4gICAgICAgICAgICBpY29uUGF0aDogXCJzdGF0aWMvaW1hZ2VzL2ljb25fY29uc3VsdC5wbmdcIixcclxuICAgICAgICAgICAgcGFnZVBhdGg6IFwicGFnZXMvaG9tZS9pbmRleFwiLFxyXG4gICAgICAgICAgICB0ZXh0OiBcIummlumhtVwiXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBzZWxlY3RlZEljb25QYXRoOiBcInN0YXRpYy9pbWFnZXMvaWNvbl9pbnZlc3RfcHJlc3MucG5nXCIsXHJcbiAgICAgICAgICAgIGljb25QYXRoOiBcInN0YXRpYy9pbWFnZXMvaWNvbl9pbnZlc3QucG5nXCIsXHJcbiAgICAgICAgICAgIHBhZ2VQYXRoOiBcInBhZ2VzL21lZXQvbWVldFwiLFxyXG4gICAgICAgICAgICB0ZXh0OiBcIuS6kuWKqFwiXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBzZWxlY3RlZEljb25QYXRoOiBcInN0YXRpYy9pbWFnZXMvaWNvbl9taW5lX3ByZXNzLnBuZ1wiLFxyXG4gICAgICAgICAgICBpY29uUGF0aDogXCJzdGF0aWMvaW1hZ2VzL2ljb25fbWluZS5wbmdcIixcclxuICAgICAgICAgICAgcGFnZVBhdGg6IFwicGFnZXMvbXkvbXlcIixcclxuICAgICAgICAgICAgdGV4dDogXCLmiJHnmoRcIlxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIF1cclxuICAgICAgfVxyXG4gICAgfTtcclxuICB9XHJcbiJdfQ==