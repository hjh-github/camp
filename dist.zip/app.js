"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

require('./npm/wepy-async-function/index.js');

var _WxUtils = require('./utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

var _wepyRedux = require('./npm/wepy-redux/lib/index.js');

var _store = require('./store/index.js');

var _store2 = _interopRequireDefault(_store);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var store = (0, _store2.default)();
(0, _wepyRedux.setStore)(store);

var _default = function (_wepy$app) {
  _inherits(_default, _wepy$app);

  function _default() {
    _classCallCheck(this, _default);

    // 注册中间件
    var _this = _possibleConstructorReturn(this, (_default.__proto__ || Object.getPrototypeOf(_default)).call(this));

    _this.globalData = {
      auth: {},
      scene: null,
      base_store_id: "",
      appCode: "",
      // baseUrl: "https://wechat.hxqxly.com",
      baseUrl: "https://test.hxqxly.com",
      themeColor: "#F4D000",
      cityCode: "",
      code: "",
      sessionId: "",
      courseInfo: {},
      orderInfo: {},
      childs: [],
      help: true,
      query: {}
    };
    _this.config = {
      pages: ["pages/home/index", "pages/home/auth", "pages/home/search", "pages/home/web", "pages/home/share", "pages/meet/meet", "pages/my/my", "pages/my/orders", "pages/my/order", "pages/my/pintuan", "pages/my/bargaining", "pages/home/address", "pages/detaile/detaile", "pages/detaile/sureOrder", "pages/detaile/partners", "pages/meet/childs", "pages/meet/addChild", "pages/meet/addMan", "pages/meet/remarks", "pages/meet/commiRemarke", "pages/activity/bargain", "pages/activity/pintuan"],
      subPackages: [{
        root: "agent",
        pages: ["pages/index", "pages/share", "pages/sign", "pages/buyVip", "pages/my", "pages/orders", "pages/fans"]
      }, {
        root: "actPages",
        pages: ["pages/answer", "pages/answerAct", "pages/index", "pages/rank"]
      }, {
        root: "coupons",
        pages: ["pages/cangets", "pages/myCoupons"]
      }],
      window: {
        backgroundTextStyle: "dark",
        navigationBarBackgroundColor: "#F4D000",
        backgroundColor: "#fff",
        navigationBarTitleText: "",
        navigationBarTextStyle: "white"
      },
      navigateToMiniProgramAppIdList: [],
      permission: {
        "scope.userLocation": {
          desc: "你的位置信息将用于小程序位置的效果展示"
        }
      },
      tabBar: {
        color: "#a9b7b7",
        selectedColor: "#F4D000",
        borderStyle: "black",
        list: [{
          selectedIconPath: "static/images/icon_consult_press.png",
          iconPath: "static/images/icon_consult.png",
          pagePath: "pages/home/index",
          text: "首页"
        }, {
          selectedIconPath: "static/images/icon_invest_press.png",
          iconPath: "static/images/icon_invest.png",
          pagePath: "pages/meet/meet",
          text: "互动"
        }, {
          selectedIconPath: "static/images/icon_mine_press.png",
          iconPath: "static/images/icon_mine.png",
          pagePath: "pages/my/my",
          text: "我的"
        }]
      }
    };
    _this.use("requestfix");
    _this.use("promisify");
    return _this;
  }

  _createClass(_default, [{
    key: "onLaunch",
    value: function () {
      var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(param) {
        var updateManager, ext;
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                // 获取当前小程序
                try {
                  _wepy2.default.$instance.globalData.appCode = wx.getAccountInfoSync().miniProgram.appId;
                } catch (res) {
                  if (wx.canIUse("getAccountInfoSync")) {
                    _wepy2.default.$instance.globalData.appCode = wx.getAccountInfoSync().miniProgram.appId;
                  } else {
                    // 如果希望用户在最新版本的客户端上体验您的小程序，可以这样子提示
                    wx.showModal({
                      title: "提示",
                      content: "当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。"
                    });
                  }
                }
                updateManager = wx.getUpdateManager();

                updateManager.onCheckForUpdate(function (res) {
                  // 请求完新版本信息的回调
                  console.log(res.hasUpdate);
                });
                updateManager.onUpdateReady(function () {
                  wx.showModal({
                    title: "更新提示",
                    content: "新版本已经准备好，是否重启应用？",
                    success: function success(res) {
                      if (res.confirm) {
                        // 新的版本已经下载好，调用 applyUpdate 应用新版本并重启
                        updateManager.applyUpdate();
                      }
                    }
                  });
                });
                updateManager.onUpdateFailed(function () {
                  // 新的版本下载失败
                  wx.showModal({
                    title: "更新提示",
                    content: "新版本下载失败",
                    showCancel: false
                  });
                });
                // 校验SDK
                _WxUtils2.default.checkSDK();
                // 同步开放平台EXT数据
                ext = _wepy2.default.getExtConfigSync();
                // console.info("[ext] init ext data", ext);

                if (ext.globalConfig) {
                  // console.info("[ext] init ext global config data", ext.globalConfig);
                  Object.assign(ext, ext.globalConfig);
                }
                Object.assign(_wepy2.default.$instance.globalData, ext);
                // auth.login();

              case 9:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function onLaunch(_x) {
        return _ref.apply(this, arguments);
      }

      return onLaunch;
    }()
  }, {
    key: "onShow",
    value: function onShow(param) {
      console.log(param);
      // 获取保存场景值
      if (param && param.scene) {
        _wepy2.default.$instance.globalData.scene = param.scene;
        console.log();
        if (param.query.scene) {
          _wepy2.default.$instance.globalData.query = this.getCodeBy1047(param.query.scene);
        } else if (param.query.agentId) {
          _wepy2.default.$instance.globalData.query["agentId"] = param.query.agentId;
        }
      }
    }
  }, {
    key: "getCodeBy1047",
    value: function getCodeBy1047(str) {
      var query = {},
          strs = decodeURIComponent(str).split("&");
      console.log(strs);
      for (var i = 0, len = strs.length; i < len; i++) {
        query[strs[i].split("=")[0]] = strs[i].split("=")[1];
      }
      return query;
    }
  }, {
    key: "syncStoreConfig",
    value: function syncStoreConfig(key) {
      try {
        var value = _wepy2.default.getStorageSync(key);
        if (value !== "") {
          // console.info(`[auth]${key} sync success `);
          _wepy2.default.$instance.globalData.auth[key] = value;
        }
      } catch (e) {
        // console.warn(`[auth]${key} sync fail `);
      }
    }
  }, {
    key: "onShareAppMessage",
    value: function onShareAppMessage(res) {
      if (res.from === "button") {
        // 来自页面内转发按钮
        console.log(res.target);
      }
      return {
        title: "自定义转发标题",
        path: "/pages/home/index"
      };
    }
  }]);

  return _default;
}(_wepy2.default.app);


App(require('./npm/wepy/lib/wepy.js').default.$createApp(_default, {"noPromiseAPI":["createSelectorQuery"]}));
require('./_wepylogs.js')

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC5qcyJdLCJuYW1lcyI6WyJzdG9yZSIsImdsb2JhbERhdGEiLCJhdXRoIiwic2NlbmUiLCJiYXNlX3N0b3JlX2lkIiwiYXBwQ29kZSIsImJhc2VVcmwiLCJ0aGVtZUNvbG9yIiwiY2l0eUNvZGUiLCJjb2RlIiwic2Vzc2lvbklkIiwiY291cnNlSW5mbyIsIm9yZGVySW5mbyIsImNoaWxkcyIsImhlbHAiLCJxdWVyeSIsImNvbmZpZyIsInBhZ2VzIiwic3ViUGFja2FnZXMiLCJyb290Iiwid2luZG93IiwiYmFja2dyb3VuZFRleHRTdHlsZSIsIm5hdmlnYXRpb25CYXJCYWNrZ3JvdW5kQ29sb3IiLCJiYWNrZ3JvdW5kQ29sb3IiLCJuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0IiwibmF2aWdhdGlvbkJhclRleHRTdHlsZSIsIm5hdmlnYXRlVG9NaW5pUHJvZ3JhbUFwcElkTGlzdCIsInBlcm1pc3Npb24iLCJkZXNjIiwidGFiQmFyIiwiY29sb3IiLCJzZWxlY3RlZENvbG9yIiwiYm9yZGVyU3R5bGUiLCJsaXN0Iiwic2VsZWN0ZWRJY29uUGF0aCIsImljb25QYXRoIiwicGFnZVBhdGgiLCJ0ZXh0IiwidXNlIiwicGFyYW0iLCJ3ZXB5IiwiJGluc3RhbmNlIiwid3giLCJnZXRBY2NvdW50SW5mb1N5bmMiLCJtaW5pUHJvZ3JhbSIsImFwcElkIiwicmVzIiwiY2FuSVVzZSIsInNob3dNb2RhbCIsInRpdGxlIiwiY29udGVudCIsInVwZGF0ZU1hbmFnZXIiLCJnZXRVcGRhdGVNYW5hZ2VyIiwib25DaGVja0ZvclVwZGF0ZSIsImNvbnNvbGUiLCJsb2ciLCJoYXNVcGRhdGUiLCJvblVwZGF0ZVJlYWR5Iiwic3VjY2VzcyIsImNvbmZpcm0iLCJhcHBseVVwZGF0ZSIsIm9uVXBkYXRlRmFpbGVkIiwic2hvd0NhbmNlbCIsIld4VXRpbHMiLCJjaGVja1NESyIsImV4dCIsImdldEV4dENvbmZpZ1N5bmMiLCJnbG9iYWxDb25maWciLCJPYmplY3QiLCJhc3NpZ24iLCJnZXRDb2RlQnkxMDQ3IiwiYWdlbnRJZCIsInN0ciIsInN0cnMiLCJkZWNvZGVVUklDb21wb25lbnQiLCJzcGxpdCIsImkiLCJsZW4iLCJsZW5ndGgiLCJrZXkiLCJ2YWx1ZSIsImdldFN0b3JhZ2VTeW5jIiwiZSIsImZyb20iLCJ0YXJnZXQiLCJwYXRoIiwiYXBwIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFDRTs7OztBQUNBOztBQUNBOzs7O0FBQ0E7O0FBR0E7Ozs7Ozs7Ozs7Ozs7O0FBQ0EsSUFBTUEsUUFBUSxzQkFBZDtBQUNBLHlCQUFTQSxLQUFUOzs7OztBQW1CRSxzQkFBYztBQUFBOztBQUVaO0FBRlk7O0FBQUEsVUFqQmRDLFVBaUJjLEdBakJEO0FBQ1hDLFlBQU0sRUFESztBQUVYQyxhQUFPLElBRkk7QUFHWEMscUJBQWUsRUFISjtBQUlYQyxlQUFTLEVBSkU7QUFLWDtBQUNBQyxlQUFTLHlCQU5FO0FBT1hDLGtCQUFZLFNBUEQ7QUFRWEMsZ0JBQVUsRUFSQztBQVNYQyxZQUFNLEVBVEs7QUFVWEMsaUJBQVcsRUFWQTtBQVdYQyxrQkFBWSxFQVhEO0FBWVhDLGlCQUFXLEVBWkE7QUFhWEMsY0FBUSxFQWJHO0FBY1hDLFlBQU0sSUFkSztBQWVYQyxhQUFPO0FBZkksS0FpQkM7QUFBQSxVQXFHZEMsTUFyR2MsR0FxR0w7QUFDUEMsYUFBTyxDQUNMLGtCQURLLEVBRUwsaUJBRkssRUFHTCxtQkFISyxFQUlMLGdCQUpLLEVBS0wsa0JBTEssRUFNTCxpQkFOSyxFQU9MLGFBUEssRUFRTCxpQkFSSyxFQVNMLGdCQVRLLEVBVUwsa0JBVkssRUFXTCxxQkFYSyxFQVlMLG9CQVpLLEVBYUwsdUJBYkssRUFjTCx5QkFkSyxFQWVMLHdCQWZLLEVBZ0JMLG1CQWhCSyxFQWlCTCxxQkFqQkssRUFrQkwsbUJBbEJLLEVBbUJMLG9CQW5CSyxFQW9CTCx5QkFwQkssRUFxQkwsd0JBckJLLEVBc0JMLHdCQXRCSyxDQURBO0FBeUJQQyxtQkFBYSxDQUFDO0FBQ1ZDLGNBQU0sT0FESTtBQUVWRixlQUFPLENBQUMsYUFBRCxFQUFnQixhQUFoQixFQUErQixZQUEvQixFQUE2QyxjQUE3QyxFQUE2RCxVQUE3RCxFQUF5RSxjQUF6RSxFQUF5RixZQUF6RjtBQUZHLE9BQUQsRUFJWDtBQUNFRSxjQUFNLFVBRFI7QUFFRUYsZUFBTyxDQUFDLGNBQUQsRUFBaUIsaUJBQWpCLEVBQW9DLGFBQXBDLEVBQW1ELFlBQW5EO0FBRlQsT0FKVyxFQVFYO0FBQ0VFLGNBQU0sU0FEUjtBQUVFRixlQUFPLENBQUMsZUFBRCxFQUFpQixpQkFBakI7QUFGVCxPQVJXLENBekJOO0FBc0NQRyxjQUFRO0FBQ05DLDZCQUFxQixNQURmO0FBRU5DLHNDQUE4QixTQUZ4QjtBQUdOQyx5QkFBaUIsTUFIWDtBQUlOQyxnQ0FBd0IsRUFKbEI7QUFLTkMsZ0NBQXdCO0FBTGxCLE9BdENEO0FBNkNQQyxzQ0FBZ0MsRUE3Q3pCO0FBOENQQyxrQkFBWTtBQUNWLDhCQUFzQjtBQUNwQkMsZ0JBQU07QUFEYztBQURaLE9BOUNMO0FBbURQQyxjQUFRO0FBQ05DLGVBQU8sU0FERDtBQUVOQyx1QkFBZSxTQUZUO0FBR05DLHFCQUFhLE9BSFA7QUFJTkMsY0FBTSxDQUFDO0FBQ0hDLDRCQUFrQixzQ0FEZjtBQUVIQyxvQkFBVSxnQ0FGUDtBQUdIQyxvQkFBVSxrQkFIUDtBQUlIQyxnQkFBTTtBQUpILFNBQUQsRUFNSjtBQUNFSCw0QkFBa0IscUNBRHBCO0FBRUVDLG9CQUFVLCtCQUZaO0FBR0VDLG9CQUFVLGlCQUhaO0FBSUVDLGdCQUFNO0FBSlIsU0FOSSxFQVlKO0FBQ0VILDRCQUFrQixtQ0FEcEI7QUFFRUMsb0JBQVUsNkJBRlo7QUFHRUMsb0JBQVUsYUFIWjtBQUlFQyxnQkFBTTtBQUpSLFNBWkk7QUFKQTtBQW5ERCxLQXJHSztBQUdaLFVBQUtDLEdBQUwsQ0FBUyxZQUFUO0FBQ0EsVUFBS0EsR0FBTCxDQUFTLFdBQVQ7QUFKWTtBQUtiOzs7OzswRkFDY0MsSzs7Ozs7O0FBQ2I7QUFDQSxvQkFBSTtBQUNGQyxpQ0FBS0MsU0FBTCxDQUFleEMsVUFBZixDQUEwQkksT0FBMUIsR0FBb0NxQyxHQUFHQyxrQkFBSCxHQUF3QkMsV0FBeEIsQ0FBb0NDLEtBQXhFO0FBQ0QsaUJBRkQsQ0FFRSxPQUFPQyxHQUFQLEVBQVk7QUFDWixzQkFBSUosR0FBR0ssT0FBSCxDQUFXLG9CQUFYLENBQUosRUFBc0M7QUFDcENQLG1DQUFLQyxTQUFMLENBQWV4QyxVQUFmLENBQTBCSSxPQUExQixHQUFvQ3FDLEdBQUdDLGtCQUFILEdBQXdCQyxXQUF4QixDQUFvQ0MsS0FBeEU7QUFDRCxtQkFGRCxNQUVPO0FBQ0w7QUFDQUgsdUJBQUdNLFNBQUgsQ0FBYTtBQUNYQyw2QkFBTyxJQURJO0FBRVhDLCtCQUFTO0FBRkUscUJBQWI7QUFJRDtBQUNGO0FBQ0tDLDZCLEdBQWdCVCxHQUFHVSxnQkFBSCxFOztBQUN0QkQsOEJBQWNFLGdCQUFkLENBQStCLFVBQVNQLEdBQVQsRUFBYztBQUMzQztBQUNBUSwwQkFBUUMsR0FBUixDQUFZVCxJQUFJVSxTQUFoQjtBQUNELGlCQUhEO0FBSUFMLDhCQUFjTSxhQUFkLENBQTRCLFlBQVc7QUFDckNmLHFCQUFHTSxTQUFILENBQWE7QUFDWEMsMkJBQU8sTUFESTtBQUVYQyw2QkFBUyxrQkFGRTtBQUdYUSw2QkFBUyxpQkFBU1osR0FBVCxFQUFjO0FBQ3JCLDBCQUFJQSxJQUFJYSxPQUFSLEVBQWlCO0FBQ2Y7QUFDQVIsc0NBQWNTLFdBQWQ7QUFDRDtBQUNGO0FBUlUsbUJBQWI7QUFVRCxpQkFYRDtBQVlBVCw4QkFBY1UsY0FBZCxDQUE2QixZQUFXO0FBQ3RDO0FBQ0FuQixxQkFBR00sU0FBSCxDQUFhO0FBQ1hDLDJCQUFPLE1BREk7QUFFWEMsNkJBQVMsU0FGRTtBQUdYWSxnQ0FBWTtBQUhELG1CQUFiO0FBS0QsaUJBUEQ7QUFRQTtBQUNBQyxrQ0FBUUMsUUFBUjtBQUNBO0FBQ01DLG1CLEdBQU16QixlQUFLMEIsZ0JBQUwsRTtBQUNaOztBQUNBLG9CQUFJRCxJQUFJRSxZQUFSLEVBQXNCO0FBQ3BCO0FBQ0FDLHlCQUFPQyxNQUFQLENBQWNKLEdBQWQsRUFBbUJBLElBQUlFLFlBQXZCO0FBQ0Q7QUFDREMsdUJBQU9DLE1BQVAsQ0FBYzdCLGVBQUtDLFNBQUwsQ0FBZXhDLFVBQTdCLEVBQXlDZ0UsR0FBekM7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7OzJCQUVLMUIsSyxFQUFPO0FBQ1plLGNBQVFDLEdBQVIsQ0FBWWhCLEtBQVo7QUFDQTtBQUNBLFVBQUlBLFNBQVNBLE1BQU1wQyxLQUFuQixFQUEwQjtBQUN4QnFDLHVCQUFLQyxTQUFMLENBQWV4QyxVQUFmLENBQTBCRSxLQUExQixHQUFrQ29DLE1BQU1wQyxLQUF4QztBQUNBbUQsZ0JBQVFDLEdBQVI7QUFDQSxZQUFJaEIsTUFBTXhCLEtBQU4sQ0FBWVosS0FBaEIsRUFBdUI7QUFDckJxQyx5QkFBS0MsU0FBTCxDQUFleEMsVUFBZixDQUEwQmMsS0FBMUIsR0FBa0MsS0FBS3VELGFBQUwsQ0FBbUIvQixNQUFNeEIsS0FBTixDQUFZWixLQUEvQixDQUFsQztBQUNELFNBRkQsTUFFTyxJQUFJb0MsTUFBTXhCLEtBQU4sQ0FBWXdELE9BQWhCLEVBQXlCO0FBQzlCL0IseUJBQUtDLFNBQUwsQ0FBZXhDLFVBQWYsQ0FBMEJjLEtBQTFCLENBQWdDLFNBQWhDLElBQTZDd0IsTUFBTXhCLEtBQU4sQ0FBWXdELE9BQXpEO0FBQ0Q7QUFDRjtBQUNGOzs7a0NBQ2FDLEcsRUFBSztBQUNqQixVQUFJekQsUUFBUSxFQUFaO0FBQUEsVUFDRTBELE9BQU9DLG1CQUFtQkYsR0FBbkIsRUFBd0JHLEtBQXhCLENBQThCLEdBQTlCLENBRFQ7QUFFQXJCLGNBQVFDLEdBQVIsQ0FBWWtCLElBQVo7QUFDQSxXQUFLLElBQUlHLElBQUksQ0FBUixFQUFXQyxNQUFNSixLQUFLSyxNQUEzQixFQUFtQ0YsSUFBSUMsR0FBdkMsRUFBNENELEdBQTVDLEVBQWlEO0FBQy9DN0QsY0FBTTBELEtBQUtHLENBQUwsRUFBUUQsS0FBUixDQUFjLEdBQWQsRUFBbUIsQ0FBbkIsQ0FBTixJQUErQkYsS0FBS0csQ0FBTCxFQUFRRCxLQUFSLENBQWMsR0FBZCxFQUFtQixDQUFuQixDQUEvQjtBQUNEO0FBQ0QsYUFBTzVELEtBQVA7QUFDRDs7O29DQUNlZ0UsRyxFQUFLO0FBQ25CLFVBQUk7QUFDRixZQUFNQyxRQUFReEMsZUFBS3lDLGNBQUwsQ0FBb0JGLEdBQXBCLENBQWQ7QUFDQSxZQUFJQyxVQUFVLEVBQWQsRUFBa0I7QUFDaEI7QUFDQXhDLHlCQUFLQyxTQUFMLENBQWV4QyxVQUFmLENBQTBCQyxJQUExQixDQUErQjZFLEdBQS9CLElBQXNDQyxLQUF0QztBQUNEO0FBQ0YsT0FORCxDQU1FLE9BQU9FLENBQVAsRUFBVTtBQUNWO0FBQ0Q7QUFDRjs7O3NDQUNpQnBDLEcsRUFBSztBQUNyQixVQUFJQSxJQUFJcUMsSUFBSixLQUFhLFFBQWpCLEVBQTJCO0FBQ3pCO0FBQ0E3QixnQkFBUUMsR0FBUixDQUFZVCxJQUFJc0MsTUFBaEI7QUFDRDtBQUNELGFBQU87QUFDTG5DLGVBQU8sU0FERjtBQUVMb0MsY0FBTTtBQUZELE9BQVA7QUFJRDs7OztFQXRIMEI3QyxlQUFLOEMsRyIsImZpbGUiOiJhcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuICBpbXBvcnQgd2VweSBmcm9tIFwid2VweVwiO1xyXG4gIGltcG9ydCBcIndlcHktYXN5bmMtZnVuY3Rpb25cIjtcclxuICBpbXBvcnQgV3hVdGlscyBmcm9tIFwiLi91dGlscy9XeFV0aWxzXCI7XHJcbiAgaW1wb3J0IHtcclxuICAgIHNldFN0b3JlXHJcbiAgfSBmcm9tIFwid2VweS1yZWR1eFwiO1xyXG4gIGltcG9ydCBjb25maWdTdG9yZSBmcm9tIFwiLi9zdG9yZVwiO1xyXG4gIGNvbnN0IHN0b3JlID0gY29uZmlnU3RvcmUoKTtcclxuICBzZXRTdG9yZShzdG9yZSk7XHJcbiAgZXhwb3J0IGRlZmF1bHQgY2xhc3MgZXh0ZW5kcyB3ZXB5LmFwcCB7XHJcbiAgICBnbG9iYWxEYXRhID0ge1xyXG4gICAgICBhdXRoOiB7fSxcclxuICAgICAgc2NlbmU6IG51bGwsXHJcbiAgICAgIGJhc2Vfc3RvcmVfaWQ6IFwiXCIsXHJcbiAgICAgIGFwcENvZGU6IFwiXCIsXHJcbiAgICAgIC8vIGJhc2VVcmw6IFwiaHR0cHM6Ly93ZWNoYXQuaHhxeGx5LmNvbVwiLFxyXG4gICAgICBiYXNlVXJsOiBcImh0dHBzOi8vdGVzdC5oeHF4bHkuY29tXCIsXHJcbiAgICAgIHRoZW1lQ29sb3I6IFwiI0Y0RDAwMFwiLFxyXG4gICAgICBjaXR5Q29kZTogXCJcIixcclxuICAgICAgY29kZTogXCJcIixcclxuICAgICAgc2Vzc2lvbklkOiBcIlwiLFxyXG4gICAgICBjb3Vyc2VJbmZvOiB7fSxcclxuICAgICAgb3JkZXJJbmZvOiB7fSxcclxuICAgICAgY2hpbGRzOiBbXSxcclxuICAgICAgaGVscDogdHJ1ZSxcclxuICAgICAgcXVlcnk6IHt9XHJcbiAgICB9O1xyXG4gICAgY29uc3RydWN0b3IoKSB7XHJcbiAgICAgIHN1cGVyKCk7XHJcbiAgICAgIC8vIOazqOWGjOS4remXtOS7tlxyXG4gICAgICB0aGlzLnVzZShcInJlcXVlc3RmaXhcIik7XHJcbiAgICAgIHRoaXMudXNlKFwicHJvbWlzaWZ5XCIpO1xyXG4gICAgfVxyXG4gICAgYXN5bmMgb25MYXVuY2gocGFyYW0pIHtcclxuICAgICAgLy8g6I635Y+W5b2T5YmN5bCP56iL5bqPXHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5hcHBDb2RlID0gd3guZ2V0QWNjb3VudEluZm9TeW5jKCkubWluaVByb2dyYW0uYXBwSWQ7XHJcbiAgICAgIH0gY2F0Y2ggKHJlcykge1xyXG4gICAgICAgIGlmICh3eC5jYW5JVXNlKFwiZ2V0QWNjb3VudEluZm9TeW5jXCIpKSB7XHJcbiAgICAgICAgICB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLmFwcENvZGUgPSB3eC5nZXRBY2NvdW50SW5mb1N5bmMoKS5taW5pUHJvZ3JhbS5hcHBJZDtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgLy8g5aaC5p6c5biM5pyb55So5oi35Zyo5pyA5paw54mI5pys55qE5a6i5oi356uv5LiK5L2T6aqM5oKo55qE5bCP56iL5bqP77yM5Y+v5Lul6L+Z5qC35a2Q5o+Q56S6XHJcbiAgICAgICAgICB3eC5zaG93TW9kYWwoe1xyXG4gICAgICAgICAgICB0aXRsZTogXCLmj5DnpLpcIixcclxuICAgICAgICAgICAgY29udGVudDogXCLlvZPliY3lvq7kv6HniYjmnKzov4fkvY7vvIzml6Dms5Xkvb/nlKjor6Xlip/og73vvIzor7fljYfnuqfliLDmnIDmlrDlvq7kv6HniYjmnKzlkI7ph43or5XjgIJcIlxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICAgIGNvbnN0IHVwZGF0ZU1hbmFnZXIgPSB3eC5nZXRVcGRhdGVNYW5hZ2VyKCk7XHJcbiAgICAgIHVwZGF0ZU1hbmFnZXIub25DaGVja0ZvclVwZGF0ZShmdW5jdGlvbihyZXMpIHtcclxuICAgICAgICAvLyDor7fmsYLlrozmlrDniYjmnKzkv6Hmga/nmoTlm57osINcclxuICAgICAgICBjb25zb2xlLmxvZyhyZXMuaGFzVXBkYXRlKTtcclxuICAgICAgfSk7XHJcbiAgICAgIHVwZGF0ZU1hbmFnZXIub25VcGRhdGVSZWFkeShmdW5jdGlvbigpIHtcclxuICAgICAgICB3eC5zaG93TW9kYWwoe1xyXG4gICAgICAgICAgdGl0bGU6IFwi5pu05paw5o+Q56S6XCIsXHJcbiAgICAgICAgICBjb250ZW50OiBcIuaWsOeJiOacrOW3sue7j+WHhuWkh+Wlve+8jOaYr+WQpumHjeWQr+W6lOeUqO+8n1wiLFxyXG4gICAgICAgICAgc3VjY2VzczogZnVuY3Rpb24ocmVzKSB7XHJcbiAgICAgICAgICAgIGlmIChyZXMuY29uZmlybSkge1xyXG4gICAgICAgICAgICAgIC8vIOaWsOeahOeJiOacrOW3sue7j+S4i+i9veWlve+8jOiwg+eUqCBhcHBseVVwZGF0ZSDlupTnlKjmlrDniYjmnKzlubbph43lkK9cclxuICAgICAgICAgICAgICB1cGRhdGVNYW5hZ2VyLmFwcGx5VXBkYXRlKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgICAgfSk7XHJcbiAgICAgIHVwZGF0ZU1hbmFnZXIub25VcGRhdGVGYWlsZWQoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgLy8g5paw55qE54mI5pys5LiL6L295aSx6LSlXHJcbiAgICAgICAgd3guc2hvd01vZGFsKHtcclxuICAgICAgICAgIHRpdGxlOiBcIuabtOaWsOaPkOekulwiLFxyXG4gICAgICAgICAgY29udGVudDogXCLmlrDniYjmnKzkuIvovb3lpLHotKVcIixcclxuICAgICAgICAgIHNob3dDYW5jZWw6IGZhbHNlXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0pO1xyXG4gICAgICAvLyDmoKHpqoxTREtcclxuICAgICAgV3hVdGlscy5jaGVja1NESygpO1xyXG4gICAgICAvLyDlkIzmraXlvIDmlL7lubPlj7BFWFTmlbDmja5cclxuICAgICAgY29uc3QgZXh0ID0gd2VweS5nZXRFeHRDb25maWdTeW5jKCk7XHJcbiAgICAgIC8vIGNvbnNvbGUuaW5mbyhcIltleHRdIGluaXQgZXh0IGRhdGFcIiwgZXh0KTtcclxuICAgICAgaWYgKGV4dC5nbG9iYWxDb25maWcpIHtcclxuICAgICAgICAvLyBjb25zb2xlLmluZm8oXCJbZXh0XSBpbml0IGV4dCBnbG9iYWwgY29uZmlnIGRhdGFcIiwgZXh0Lmdsb2JhbENvbmZpZyk7XHJcbiAgICAgICAgT2JqZWN0LmFzc2lnbihleHQsIGV4dC5nbG9iYWxDb25maWcpO1xyXG4gICAgICB9XHJcbiAgICAgIE9iamVjdC5hc3NpZ24od2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YSwgZXh0KTtcclxuICAgICAgLy8gYXV0aC5sb2dpbigpO1xyXG4gICAgfVxyXG4gICAgb25TaG93KHBhcmFtKSB7XHJcbiAgICAgIGNvbnNvbGUubG9nKHBhcmFtKTtcclxuICAgICAgLy8g6I635Y+W5L+d5a2Y5Zy65pmv5YC8XHJcbiAgICAgIGlmIChwYXJhbSAmJiBwYXJhbS5zY2VuZSkge1xyXG4gICAgICAgIHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuc2NlbmUgPSBwYXJhbS5zY2VuZTtcclxuICAgICAgICBjb25zb2xlLmxvZygpO1xyXG4gICAgICAgIGlmIChwYXJhbS5xdWVyeS5zY2VuZSkge1xyXG4gICAgICAgICAgd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5xdWVyeSA9IHRoaXMuZ2V0Q29kZUJ5MTA0NyhwYXJhbS5xdWVyeS5zY2VuZSk7XHJcbiAgICAgICAgfSBlbHNlIGlmIChwYXJhbS5xdWVyeS5hZ2VudElkKSB7XHJcbiAgICAgICAgICB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnF1ZXJ5W1wiYWdlbnRJZFwiXSA9IHBhcmFtLnF1ZXJ5LmFnZW50SWQ7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBnZXRDb2RlQnkxMDQ3KHN0cikge1xyXG4gICAgICB2YXIgcXVlcnkgPSB7fSxcclxuICAgICAgICBzdHJzID0gZGVjb2RlVVJJQ29tcG9uZW50KHN0cikuc3BsaXQoXCImXCIpO1xyXG4gICAgICBjb25zb2xlLmxvZyhzdHJzKTtcclxuICAgICAgZm9yICh2YXIgaSA9IDAsIGxlbiA9IHN0cnMubGVuZ3RoOyBpIDwgbGVuOyBpKyspIHtcclxuICAgICAgICBxdWVyeVtzdHJzW2ldLnNwbGl0KFwiPVwiKVswXV0gPSBzdHJzW2ldLnNwbGl0KFwiPVwiKVsxXTtcclxuICAgICAgfVxyXG4gICAgICByZXR1cm4gcXVlcnk7XHJcbiAgICB9XHJcbiAgICBzeW5jU3RvcmVDb25maWcoa2V5KSB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgdmFsdWUgPSB3ZXB5LmdldFN0b3JhZ2VTeW5jKGtleSk7XHJcbiAgICAgICAgaWYgKHZhbHVlICE9PSBcIlwiKSB7XHJcbiAgICAgICAgICAvLyBjb25zb2xlLmluZm8oYFthdXRoXSR7a2V5fSBzeW5jIHN1Y2Nlc3MgYCk7XHJcbiAgICAgICAgICB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLmF1dGhba2V5XSA9IHZhbHVlO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgIC8vIGNvbnNvbGUud2FybihgW2F1dGhdJHtrZXl9IHN5bmMgZmFpbCBgKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgb25TaGFyZUFwcE1lc3NhZ2UocmVzKSB7XHJcbiAgICAgIGlmIChyZXMuZnJvbSA9PT0gXCJidXR0b25cIikge1xyXG4gICAgICAgIC8vIOadpeiHqumhtemdouWGhei9rOWPkeaMiemSrlxyXG4gICAgICAgIGNvbnNvbGUubG9nKHJlcy50YXJnZXQpO1xyXG4gICAgICB9XHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAgdGl0bGU6IFwi6Ieq5a6a5LmJ6L2s5Y+R5qCH6aKYXCIsXHJcbiAgICAgICAgcGF0aDogXCIvcGFnZXMvaG9tZS9pbmRleFwiXHJcbiAgICAgIH07XHJcbiAgICB9XHJcbiAgICBjb25maWcgPSB7XHJcbiAgICAgIHBhZ2VzOiBbXHJcbiAgICAgICAgXCJwYWdlcy9ob21lL2luZGV4XCIsXHJcbiAgICAgICAgXCJwYWdlcy9ob21lL2F1dGhcIixcclxuICAgICAgICBcInBhZ2VzL2hvbWUvc2VhcmNoXCIsXHJcbiAgICAgICAgXCJwYWdlcy9ob21lL3dlYlwiLFxyXG4gICAgICAgIFwicGFnZXMvaG9tZS9zaGFyZVwiLFxyXG4gICAgICAgIFwicGFnZXMvbWVldC9tZWV0XCIsXHJcbiAgICAgICAgXCJwYWdlcy9teS9teVwiLFxyXG4gICAgICAgIFwicGFnZXMvbXkvb3JkZXJzXCIsXHJcbiAgICAgICAgXCJwYWdlcy9teS9vcmRlclwiLFxyXG4gICAgICAgIFwicGFnZXMvbXkvcGludHVhblwiLFxyXG4gICAgICAgIFwicGFnZXMvbXkvYmFyZ2FpbmluZ1wiLFxyXG4gICAgICAgIFwicGFnZXMvaG9tZS9hZGRyZXNzXCIsXHJcbiAgICAgICAgXCJwYWdlcy9kZXRhaWxlL2RldGFpbGVcIixcclxuICAgICAgICBcInBhZ2VzL2RldGFpbGUvc3VyZU9yZGVyXCIsXHJcbiAgICAgICAgXCJwYWdlcy9kZXRhaWxlL3BhcnRuZXJzXCIsXHJcbiAgICAgICAgXCJwYWdlcy9tZWV0L2NoaWxkc1wiLFxyXG4gICAgICAgIFwicGFnZXMvbWVldC9hZGRDaGlsZFwiLFxyXG4gICAgICAgIFwicGFnZXMvbWVldC9hZGRNYW5cIixcclxuICAgICAgICBcInBhZ2VzL21lZXQvcmVtYXJrc1wiLFxyXG4gICAgICAgIFwicGFnZXMvbWVldC9jb21taVJlbWFya2VcIixcclxuICAgICAgICBcInBhZ2VzL2FjdGl2aXR5L2JhcmdhaW5cIixcclxuICAgICAgICBcInBhZ2VzL2FjdGl2aXR5L3BpbnR1YW5cIlxyXG4gICAgICBdLFxyXG4gICAgICBzdWJQYWNrYWdlczogW3tcclxuICAgICAgICAgIHJvb3Q6IFwiYWdlbnRcIixcclxuICAgICAgICAgIHBhZ2VzOiBbXCJwYWdlcy9pbmRleFwiLCBcInBhZ2VzL3NoYXJlXCIsIFwicGFnZXMvc2lnblwiLCBcInBhZ2VzL2J1eVZpcFwiLCBcInBhZ2VzL215XCIsIFwicGFnZXMvb3JkZXJzXCIsIFwicGFnZXMvZmFuc1wiXVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgcm9vdDogXCJhY3RQYWdlc1wiLFxyXG4gICAgICAgICAgcGFnZXM6IFtcInBhZ2VzL2Fuc3dlclwiLCBcInBhZ2VzL2Fuc3dlckFjdFwiLCBcInBhZ2VzL2luZGV4XCIsIFwicGFnZXMvcmFua1wiXVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgcm9vdDogXCJjb3Vwb25zXCIsXHJcbiAgICAgICAgICBwYWdlczogW1wicGFnZXMvY2FuZ2V0c1wiLFwicGFnZXMvbXlDb3Vwb25zXCJdXHJcbiAgICAgICAgfVxyXG4gICAgICBdLFxyXG4gICAgICB3aW5kb3c6IHtcclxuICAgICAgICBiYWNrZ3JvdW5kVGV4dFN0eWxlOiBcImRhcmtcIixcclxuICAgICAgICBuYXZpZ2F0aW9uQmFyQmFja2dyb3VuZENvbG9yOiBcIiNGNEQwMDBcIixcclxuICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IFwiI2ZmZlwiLFxyXG4gICAgICAgIG5hdmlnYXRpb25CYXJUaXRsZVRleHQ6IFwiXCIsXHJcbiAgICAgICAgbmF2aWdhdGlvbkJhclRleHRTdHlsZTogXCJ3aGl0ZVwiXHJcbiAgICAgIH0sXHJcbiAgICAgIG5hdmlnYXRlVG9NaW5pUHJvZ3JhbUFwcElkTGlzdDogW10sXHJcbiAgICAgIHBlcm1pc3Npb246IHtcclxuICAgICAgICBcInNjb3BlLnVzZXJMb2NhdGlvblwiOiB7XHJcbiAgICAgICAgICBkZXNjOiBcIuS9oOeahOS9jee9ruS/oeaBr+WwhueUqOS6juWwj+eoi+W6j+S9jee9rueahOaViOaenOWxleekulwiXHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG4gICAgICB0YWJCYXI6IHtcclxuICAgICAgICBjb2xvcjogXCIjYTliN2I3XCIsXHJcbiAgICAgICAgc2VsZWN0ZWRDb2xvcjogXCIjRjREMDAwXCIsXHJcbiAgICAgICAgYm9yZGVyU3R5bGU6IFwiYmxhY2tcIixcclxuICAgICAgICBsaXN0OiBbe1xyXG4gICAgICAgICAgICBzZWxlY3RlZEljb25QYXRoOiBcInN0YXRpYy9pbWFnZXMvaWNvbl9jb25zdWx0X3ByZXNzLnBuZ1wiLFxyXG4gICAgICAgICAgICBpY29uUGF0aDogXCJzdGF0aWMvaW1hZ2VzL2ljb25fY29uc3VsdC5wbmdcIixcclxuICAgICAgICAgICAgcGFnZVBhdGg6IFwicGFnZXMvaG9tZS9pbmRleFwiLFxyXG4gICAgICAgICAgICB0ZXh0OiBcIummlumhtVwiXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBzZWxlY3RlZEljb25QYXRoOiBcInN0YXRpYy9pbWFnZXMvaWNvbl9pbnZlc3RfcHJlc3MucG5nXCIsXHJcbiAgICAgICAgICAgIGljb25QYXRoOiBcInN0YXRpYy9pbWFnZXMvaWNvbl9pbnZlc3QucG5nXCIsXHJcbiAgICAgICAgICAgIHBhZ2VQYXRoOiBcInBhZ2VzL21lZXQvbWVldFwiLFxyXG4gICAgICAgICAgICB0ZXh0OiBcIuS6kuWKqFwiXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBzZWxlY3RlZEljb25QYXRoOiBcInN0YXRpYy9pbWFnZXMvaWNvbl9taW5lX3ByZXNzLnBuZ1wiLFxyXG4gICAgICAgICAgICBpY29uUGF0aDogXCJzdGF0aWMvaW1hZ2VzL2ljb25fbWluZS5wbmdcIixcclxuICAgICAgICAgICAgcGFnZVBhdGg6IFwicGFnZXMvbXkvbXlcIixcclxuICAgICAgICAgICAgdGV4dDogXCLmiJHnmoRcIlxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIF1cclxuICAgICAgfVxyXG4gICAgfTtcclxuICB9XHJcbiJdfQ==