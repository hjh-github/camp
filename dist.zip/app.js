"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

require('./npm/wepy-async-function/index.js');

var _WxUtils = require('./utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

var _wepyRedux = require('./npm/wepy-redux/lib/index.js');

var _store = require('./store/index.js');

var _store2 = _interopRequireDefault(_store);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var store = (0, _store2.default)();
(0, _wepyRedux.setStore)(store);

var _default = function (_wepy$app) {
  _inherits(_default, _wepy$app);

  function _default() {
    _classCallCheck(this, _default);

    // 注册中间件
    var _this = _possibleConstructorReturn(this, (_default.__proto__ || Object.getPrototypeOf(_default)).call(this));

    _this.globalData = {
      auth: {},
      scene: null,
      base_store_id: "",
      appCode: "",
      baseUrl: "https://wechat.hxqxly.com",
      // baseUrl: "http://10.0.3.150:8809",
      themeColor: "#F4D000",
      cityCode: '',
      code: '',
      sessionId: '',
      courseInfo: {},
      orderInfo: {},
      childs: [],
      help: true
    };
    _this.config = {
      pages: ["pages/home/index", "pages/home/search", "pages/home/web", "pages/home/share", "pages/meet/meet", "pages/my/my", "pages/my/orders", "pages/my/order", "pages/my/pintuan", "pages/my/bargaining", "pages/home/address", "pages/detaile/detaile", "pages/detaile/sureOrder", "pages/detaile/partners", "pages/meet/childs", "pages/meet/addChild", "pages/meet/addMan", "pages/meet/remarks", "pages/meet/commiRemarke", "pages/activity/bargain", "pages/activity/pintuan"],
      window: {
        backgroundTextStyle: "dark",
        navigationBarBackgroundColor: "#F4D000",
        backgroundColor: "#fff",
        navigationBarTitleText: "",
        navigationBarTextStyle: "white"
      },
      navigateToMiniProgramAppIdList: [],
      permission: {
        "scope.userLocation": {
          desc: "你的位置信息将用于小程序位置的效果展示"
        }
      },
      "tabBar": {
        "color": "#a9b7b7",
        "selectedColor": "#F4D000",
        "borderStyle": "black",
        "list": [{
          "selectedIconPath": "static/images/icon_consult_press.png",
          "iconPath": "static/images/icon_consult.png",
          "pagePath": "pages/home/index",
          "text": "首页"
        }, {
          "selectedIconPath": "static/images/icon_invest_press.png",
          "iconPath": "static/images/icon_invest.png",
          "pagePath": "pages/meet/meet",
          "text": "互动"
        }, {
          "selectedIconPath": "static/images/icon_mine_press.png",
          "iconPath": "static/images/icon_mine.png",
          "pagePath": "pages/my/my",
          "text": "我的"
        }]
      }
    };
    _this.use("requestfix");
    _this.use("promisify");
    return _this;
  }

  _createClass(_default, [{
    key: "onLaunch",
    value: function () {
      var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(param) {
        var updateManager, ext;
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                // 获取当前小程序
                try {
                  _wepy2.default.$instance.globalData.appCode = wx.getAccountInfoSync().miniProgram.appId;
                } catch (res) {
                  if (wx.canIUse("getAccountInfoSync")) {
                    _wepy2.default.$instance.globalData.appCode = wx.getAccountInfoSync().miniProgram.appId;
                  } else {
                    // 如果希望用户在最新版本的客户端上体验您的小程序，可以这样子提示
                    wx.showModal({
                      title: "提示",
                      content: "当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。"
                    });
                  }
                }
                updateManager = wx.getUpdateManager();

                updateManager.onCheckForUpdate(function (res) {
                  // 请求完新版本信息的回调
                  console.log(res.hasUpdate);
                });
                updateManager.onUpdateReady(function () {
                  wx.showModal({
                    title: "更新提示",
                    content: "新版本已经准备好，是否重启应用？",
                    success: function success(res) {
                      if (res.confirm) {
                        // 新的版本已经下载好，调用 applyUpdate 应用新版本并重启
                        updateManager.applyUpdate();
                      }
                    }
                  });
                });
                updateManager.onUpdateFailed(function () {
                  // 新的版本下载失败
                  wx.showModal({
                    title: "更新提示",
                    content: "新版本下载失败",
                    showCancel: false
                  });
                });
                // 校验SDK
                _WxUtils2.default.checkSDK();
                // 同步开放平台EXT数据
                ext = _wepy2.default.getExtConfigSync();
                // console.info("[ext] init ext data", ext);

                if (ext.globalConfig) {
                  // console.info("[ext] init ext global config data", ext.globalConfig);
                  Object.assign(ext, ext.globalConfig);
                }
                Object.assign(_wepy2.default.$instance.globalData, ext);
                // auth.login();

              case 9:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function onLaunch(_x) {
        return _ref.apply(this, arguments);
      }

      return onLaunch;
    }()
  }, {
    key: "onShow",
    value: function onShow(param) {
      console.log(param);
      // 获取保存场景值
      if (param && param.scene) {
        _wepy2.default.$instance.globalData.scene = param.scene;
        if (param.query.s) _wepy2.default.$instance.globalData.base_store_id = param.query.s;
        switch (param.scene) {
          // 服务通知下
          case 1014:
            if (param.query.lid) _wepy2.default.setStorageSync("level_id", param.query.lid);
            break;
        }
      }
    }
  }, {
    key: "syncStoreConfig",
    value: function syncStoreConfig(key) {
      try {
        var value = _wepy2.default.getStorageSync(key);
        if (value !== "") {
          // console.info(`[auth]${key} sync success `);
          _wepy2.default.$instance.globalData.auth[key] = value;
        }
      } catch (e) {
        // console.warn(`[auth]${key} sync fail `);
      }
    }
  }, {
    key: "onShareAppMessage",
    value: function onShareAppMessage(res) {
      if (res.from === "button") {
        // 来自页面内转发按钮
        console.log(res.target);
      }
      return {
        title: "自定义转发标题",
        path: "/pages/home/index"
      };
    }
  }]);

  return _default;
}(_wepy2.default.app);


App(require('./npm/wepy/lib/wepy.js').default.$createApp(_default, {"noPromiseAPI":["createSelectorQuery"]}));
require('./_wepylogs.js')

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC5qcyJdLCJuYW1lcyI6WyJzdG9yZSIsImdsb2JhbERhdGEiLCJhdXRoIiwic2NlbmUiLCJiYXNlX3N0b3JlX2lkIiwiYXBwQ29kZSIsImJhc2VVcmwiLCJ0aGVtZUNvbG9yIiwiY2l0eUNvZGUiLCJjb2RlIiwic2Vzc2lvbklkIiwiY291cnNlSW5mbyIsIm9yZGVySW5mbyIsImNoaWxkcyIsImhlbHAiLCJjb25maWciLCJwYWdlcyIsIndpbmRvdyIsImJhY2tncm91bmRUZXh0U3R5bGUiLCJuYXZpZ2F0aW9uQmFyQmFja2dyb3VuZENvbG9yIiwiYmFja2dyb3VuZENvbG9yIiwibmF2aWdhdGlvbkJhclRpdGxlVGV4dCIsIm5hdmlnYXRpb25CYXJUZXh0U3R5bGUiLCJuYXZpZ2F0ZVRvTWluaVByb2dyYW1BcHBJZExpc3QiLCJwZXJtaXNzaW9uIiwiZGVzYyIsInVzZSIsInBhcmFtIiwid2VweSIsIiRpbnN0YW5jZSIsInd4IiwiZ2V0QWNjb3VudEluZm9TeW5jIiwibWluaVByb2dyYW0iLCJhcHBJZCIsInJlcyIsImNhbklVc2UiLCJzaG93TW9kYWwiLCJ0aXRsZSIsImNvbnRlbnQiLCJ1cGRhdGVNYW5hZ2VyIiwiZ2V0VXBkYXRlTWFuYWdlciIsIm9uQ2hlY2tGb3JVcGRhdGUiLCJjb25zb2xlIiwibG9nIiwiaGFzVXBkYXRlIiwib25VcGRhdGVSZWFkeSIsInN1Y2Nlc3MiLCJjb25maXJtIiwiYXBwbHlVcGRhdGUiLCJvblVwZGF0ZUZhaWxlZCIsInNob3dDYW5jZWwiLCJXeFV0aWxzIiwiY2hlY2tTREsiLCJleHQiLCJnZXRFeHRDb25maWdTeW5jIiwiZ2xvYmFsQ29uZmlnIiwiT2JqZWN0IiwiYXNzaWduIiwicXVlcnkiLCJzIiwibGlkIiwic2V0U3RvcmFnZVN5bmMiLCJrZXkiLCJ2YWx1ZSIsImdldFN0b3JhZ2VTeW5jIiwiZSIsImZyb20iLCJ0YXJnZXQiLCJwYXRoIiwiYXBwIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFDRTs7OztBQUNBOztBQUNBOzs7O0FBQ0E7O0FBR0E7Ozs7Ozs7Ozs7Ozs7O0FBQ0EsSUFBTUEsUUFBUSxzQkFBZDtBQUNBLHlCQUFTQSxLQUFUOzs7OztBQWtCRSxzQkFBYztBQUFBOztBQUVaO0FBRlk7O0FBQUEsVUFoQmRDLFVBZ0JjLEdBaEJEO0FBQ1hDLFlBQU0sRUFESztBQUVYQyxhQUFPLElBRkk7QUFHWEMscUJBQWUsRUFISjtBQUlYQyxlQUFTLEVBSkU7QUFLWEMsZUFBUywyQkFMRTtBQU1YO0FBQ0FDLGtCQUFZLFNBUEQ7QUFRWEMsZ0JBQVMsRUFSRTtBQVNYQyxZQUFLLEVBVE07QUFVWEMsaUJBQVUsRUFWQztBQVdYQyxrQkFBVyxFQVhBO0FBWVhDLGlCQUFVLEVBWkM7QUFhWEMsY0FBTyxFQWJJO0FBY1hDLFlBQUs7QUFkTSxLQWdCQztBQUFBLFVBNkZkQyxNQTdGYyxHQTZGTDtBQUNQQyxhQUFPLENBQ1Asa0JBRE8sRUFFUCxtQkFGTyxFQUdQLGdCQUhPLEVBSVAsa0JBSk8sRUFLUCxpQkFMTyxFQU1QLGFBTk8sRUFPUCxpQkFQTyxFQVFQLGdCQVJPLEVBU1Asa0JBVE8sRUFVUCxxQkFWTyxFQVdQLG9CQVhPLEVBWVAsdUJBWk8sRUFhUCx5QkFiTyxFQWNQLHdCQWRPLEVBZVAsbUJBZk8sRUFnQlAscUJBaEJPLEVBaUJQLG1CQWpCTyxFQWtCUCxvQkFsQk8sRUFtQlAseUJBbkJPLEVBb0JQLHdCQXBCTyxFQXFCUCx3QkFyQk8sQ0FEQTtBQXlCUEMsY0FBUTtBQUNOQyw2QkFBcUIsTUFEZjtBQUVOQyxzQ0FBOEIsU0FGeEI7QUFHTkMseUJBQWlCLE1BSFg7QUFJTkMsZ0NBQXdCLEVBSmxCO0FBS05DLGdDQUF3QjtBQUxsQixPQXpCRDtBQWdDUEMsc0NBQWdDLEVBaEN6QjtBQWlDUEMsa0JBQVk7QUFDViw4QkFBc0I7QUFDcEJDLGdCQUFNO0FBRGM7QUFEWixPQWpDTDtBQXNDUCxnQkFBVTtBQUNSLGlCQUFTLFNBREQ7QUFFUix5QkFBaUIsU0FGVDtBQUdSLHVCQUFlLE9BSFA7QUFJUixnQkFBUSxDQUNOO0FBQ0UsOEJBQW9CLHNDQUR0QjtBQUVFLHNCQUFZLGdDQUZkO0FBR0Usc0JBQVksa0JBSGQ7QUFJRSxrQkFBUTtBQUpWLFNBRE0sRUFPTjtBQUNFLDhCQUFvQixxQ0FEdEI7QUFFRSxzQkFBWSwrQkFGZDtBQUdFLHNCQUFZLGlCQUhkO0FBSUUsa0JBQVE7QUFKVixTQVBNLEVBYU47QUFDRSw4QkFBb0IsbUNBRHRCO0FBRUUsc0JBQVksNkJBRmQ7QUFHRSxzQkFBWSxhQUhkO0FBSUUsa0JBQVE7QUFKVixTQWJNO0FBSkE7QUF0Q0gsS0E3Rks7QUFHWixVQUFLQyxHQUFMLENBQVMsWUFBVDtBQUNBLFVBQUtBLEdBQUwsQ0FBUyxXQUFUO0FBSlk7QUFLYjs7Ozs7MEZBQ2NDLEs7Ozs7OztBQUNiO0FBQ0Esb0JBQUk7QUFDRkMsaUNBQUtDLFNBQUwsQ0FBZTVCLFVBQWYsQ0FBMEJJLE9BQTFCLEdBQW9DeUIsR0FBR0Msa0JBQUgsR0FBd0JDLFdBQXhCLENBQW9DQyxLQUF4RTtBQUNELGlCQUZELENBRUUsT0FBT0MsR0FBUCxFQUFZO0FBQ1osc0JBQUlKLEdBQUdLLE9BQUgsQ0FBVyxvQkFBWCxDQUFKLEVBQXNDO0FBQ3BDUCxtQ0FBS0MsU0FBTCxDQUFlNUIsVUFBZixDQUEwQkksT0FBMUIsR0FBb0N5QixHQUFHQyxrQkFBSCxHQUF3QkMsV0FBeEIsQ0FBb0NDLEtBQXhFO0FBQ0QsbUJBRkQsTUFFTztBQUNMO0FBQ0FILHVCQUFHTSxTQUFILENBQWE7QUFDWEMsNkJBQU8sSUFESTtBQUVYQywrQkFBUztBQUZFLHFCQUFiO0FBSUQ7QUFDRjtBQUNLQyw2QixHQUFnQlQsR0FBR1UsZ0JBQUgsRTs7QUFDdEJELDhCQUFjRSxnQkFBZCxDQUErQixVQUFTUCxHQUFULEVBQWM7QUFDM0M7QUFDQVEsMEJBQVFDLEdBQVIsQ0FBWVQsSUFBSVUsU0FBaEI7QUFDRCxpQkFIRDtBQUlBTCw4QkFBY00sYUFBZCxDQUE0QixZQUFXO0FBQ3JDZixxQkFBR00sU0FBSCxDQUFhO0FBQ1hDLDJCQUFPLE1BREk7QUFFWEMsNkJBQVMsa0JBRkU7QUFHWFEsNkJBQVMsaUJBQVNaLEdBQVQsRUFBYztBQUNyQiwwQkFBSUEsSUFBSWEsT0FBUixFQUFpQjtBQUNmO0FBQ0FSLHNDQUFjUyxXQUFkO0FBQ0Q7QUFDRjtBQVJVLG1CQUFiO0FBVUQsaUJBWEQ7QUFZQVQsOEJBQWNVLGNBQWQsQ0FBNkIsWUFBVztBQUN0QztBQUNBbkIscUJBQUdNLFNBQUgsQ0FBYTtBQUNYQywyQkFBTyxNQURJO0FBRVhDLDZCQUFTLFNBRkU7QUFHWFksZ0NBQVk7QUFIRCxtQkFBYjtBQUtELGlCQVBEO0FBUUE7QUFDQUMsa0NBQVFDLFFBQVI7QUFDQTtBQUNNQyxtQixHQUFNekIsZUFBSzBCLGdCQUFMLEU7QUFDWjs7QUFDQSxvQkFBSUQsSUFBSUUsWUFBUixFQUFzQjtBQUNwQjtBQUNBQyx5QkFBT0MsTUFBUCxDQUFjSixHQUFkLEVBQW1CQSxJQUFJRSxZQUF2QjtBQUNEO0FBQ0RDLHVCQUFPQyxNQUFQLENBQWM3QixlQUFLQyxTQUFMLENBQWU1QixVQUE3QixFQUF5Q29ELEdBQXpDO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7OzsyQkFFSzFCLEssRUFBTztBQUNaZSxjQUFRQyxHQUFSLENBQVloQixLQUFaO0FBQ0E7QUFDQSxVQUFJQSxTQUFTQSxNQUFNeEIsS0FBbkIsRUFBMEI7QUFDeEJ5Qix1QkFBS0MsU0FBTCxDQUFlNUIsVUFBZixDQUEwQkUsS0FBMUIsR0FBa0N3QixNQUFNeEIsS0FBeEM7QUFDQSxZQUFJd0IsTUFBTStCLEtBQU4sQ0FBWUMsQ0FBaEIsRUFBbUIvQixlQUFLQyxTQUFMLENBQWU1QixVQUFmLENBQTBCRyxhQUExQixHQUEwQ3VCLE1BQU0rQixLQUFOLENBQVlDLENBQXREO0FBQ25CLGdCQUFRaEMsTUFBTXhCLEtBQWQ7QUFDRTtBQUNBLGVBQUssSUFBTDtBQUNFLGdCQUFJd0IsTUFBTStCLEtBQU4sQ0FBWUUsR0FBaEIsRUFBcUJoQyxlQUFLaUMsY0FBTCxDQUFvQixVQUFwQixFQUFnQ2xDLE1BQU0rQixLQUFOLENBQVlFLEdBQTVDO0FBQ3JCO0FBSko7QUFNRDtBQUNGOzs7b0NBQ2VFLEcsRUFBSztBQUNuQixVQUFJO0FBQ0YsWUFBTUMsUUFBUW5DLGVBQUtvQyxjQUFMLENBQW9CRixHQUFwQixDQUFkO0FBQ0EsWUFBSUMsVUFBVSxFQUFkLEVBQWtCO0FBQ2hCO0FBQ0FuQyx5QkFBS0MsU0FBTCxDQUFlNUIsVUFBZixDQUEwQkMsSUFBMUIsQ0FBK0I0RCxHQUEvQixJQUFzQ0MsS0FBdEM7QUFDRDtBQUNGLE9BTkQsQ0FNRSxPQUFPRSxDQUFQLEVBQVU7QUFDVjtBQUNEO0FBQ0Y7OztzQ0FDaUIvQixHLEVBQUs7QUFDckIsVUFBSUEsSUFBSWdDLElBQUosS0FBYSxRQUFqQixFQUEyQjtBQUN6QjtBQUNBeEIsZ0JBQVFDLEdBQVIsQ0FBWVQsSUFBSWlDLE1BQWhCO0FBQ0Q7QUFDRCxhQUFPO0FBQ0w5QixlQUFPLFNBREY7QUFFTCtCLGNBQU07QUFGRCxPQUFQO0FBSUQ7Ozs7RUE3RzBCeEMsZUFBS3lDLEciLCJmaWxlIjoiYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbiAgaW1wb3J0IHdlcHkgZnJvbSBcIndlcHlcIjtcclxuICBpbXBvcnQgXCJ3ZXB5LWFzeW5jLWZ1bmN0aW9uXCI7XHJcbiAgaW1wb3J0IFd4VXRpbHMgZnJvbSBcIi4vdXRpbHMvV3hVdGlsc1wiO1xyXG4gIGltcG9ydCB7XHJcbiAgICBzZXRTdG9yZVxyXG4gIH0gZnJvbSBcIndlcHktcmVkdXhcIjtcclxuICBpbXBvcnQgY29uZmlnU3RvcmUgZnJvbSBcIi4vc3RvcmVcIjtcclxuICBjb25zdCBzdG9yZSA9IGNvbmZpZ1N0b3JlKCk7XHJcbiAgc2V0U3RvcmUoc3RvcmUpO1xyXG4gIGV4cG9ydCBkZWZhdWx0IGNsYXNzIGV4dGVuZHMgd2VweS5hcHAge1xyXG4gICAgZ2xvYmFsRGF0YSA9IHtcclxuICAgICAgYXV0aDoge30sXHJcbiAgICAgIHNjZW5lOiBudWxsLFxyXG4gICAgICBiYXNlX3N0b3JlX2lkOiBcIlwiLFxyXG4gICAgICBhcHBDb2RlOiBcIlwiLFxyXG4gICAgICBiYXNlVXJsOiBcImh0dHBzOi8vd2VjaGF0Lmh4cXhseS5jb21cIixcclxuICAgICAgLy8gYmFzZVVybDogXCJodHRwOi8vMTAuMC4zLjE1MDo4ODA5XCIsXHJcbiAgICAgIHRoZW1lQ29sb3I6IFwiI0Y0RDAwMFwiLFxyXG4gICAgICBjaXR5Q29kZTonJyxcclxuICAgICAgY29kZTonJyxcclxuICAgICAgc2Vzc2lvbklkOicnLFxyXG4gICAgICBjb3Vyc2VJbmZvOnt9LFxyXG4gICAgICBvcmRlckluZm86e30sXHJcbiAgICAgIGNoaWxkczpbXSxcclxuICAgICAgaGVscDp0cnVlXHJcbiAgICB9O1xyXG4gICAgY29uc3RydWN0b3IoKSB7XHJcbiAgICAgIHN1cGVyKCk7XHJcbiAgICAgIC8vIOazqOWGjOS4remXtOS7tlxyXG4gICAgICB0aGlzLnVzZShcInJlcXVlc3RmaXhcIik7XHJcbiAgICAgIHRoaXMudXNlKFwicHJvbWlzaWZ5XCIpO1xyXG4gICAgfVxyXG4gICAgYXN5bmMgb25MYXVuY2gocGFyYW0pIHtcclxuICAgICAgLy8g6I635Y+W5b2T5YmN5bCP56iL5bqPXHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5hcHBDb2RlID0gd3guZ2V0QWNjb3VudEluZm9TeW5jKCkubWluaVByb2dyYW0uYXBwSWQ7XHJcbiAgICAgIH0gY2F0Y2ggKHJlcykge1xyXG4gICAgICAgIGlmICh3eC5jYW5JVXNlKFwiZ2V0QWNjb3VudEluZm9TeW5jXCIpKSB7XHJcbiAgICAgICAgICB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLmFwcENvZGUgPSB3eC5nZXRBY2NvdW50SW5mb1N5bmMoKS5taW5pUHJvZ3JhbS5hcHBJZDtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgLy8g5aaC5p6c5biM5pyb55So5oi35Zyo5pyA5paw54mI5pys55qE5a6i5oi356uv5LiK5L2T6aqM5oKo55qE5bCP56iL5bqP77yM5Y+v5Lul6L+Z5qC35a2Q5o+Q56S6XHJcbiAgICAgICAgICB3eC5zaG93TW9kYWwoe1xyXG4gICAgICAgICAgICB0aXRsZTogXCLmj5DnpLpcIixcclxuICAgICAgICAgICAgY29udGVudDogXCLlvZPliY3lvq7kv6HniYjmnKzov4fkvY7vvIzml6Dms5Xkvb/nlKjor6Xlip/og73vvIzor7fljYfnuqfliLDmnIDmlrDlvq7kv6HniYjmnKzlkI7ph43or5XjgIJcIlxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICAgIGNvbnN0IHVwZGF0ZU1hbmFnZXIgPSB3eC5nZXRVcGRhdGVNYW5hZ2VyKCk7XHJcbiAgICAgIHVwZGF0ZU1hbmFnZXIub25DaGVja0ZvclVwZGF0ZShmdW5jdGlvbihyZXMpIHtcclxuICAgICAgICAvLyDor7fmsYLlrozmlrDniYjmnKzkv6Hmga/nmoTlm57osINcclxuICAgICAgICBjb25zb2xlLmxvZyhyZXMuaGFzVXBkYXRlKTtcclxuICAgICAgfSk7XHJcbiAgICAgIHVwZGF0ZU1hbmFnZXIub25VcGRhdGVSZWFkeShmdW5jdGlvbigpIHtcclxuICAgICAgICB3eC5zaG93TW9kYWwoe1xyXG4gICAgICAgICAgdGl0bGU6IFwi5pu05paw5o+Q56S6XCIsXHJcbiAgICAgICAgICBjb250ZW50OiBcIuaWsOeJiOacrOW3sue7j+WHhuWkh+Wlve+8jOaYr+WQpumHjeWQr+W6lOeUqO+8n1wiLFxyXG4gICAgICAgICAgc3VjY2VzczogZnVuY3Rpb24ocmVzKSB7XHJcbiAgICAgICAgICAgIGlmIChyZXMuY29uZmlybSkge1xyXG4gICAgICAgICAgICAgIC8vIOaWsOeahOeJiOacrOW3sue7j+S4i+i9veWlve+8jOiwg+eUqCBhcHBseVVwZGF0ZSDlupTnlKjmlrDniYjmnKzlubbph43lkK9cclxuICAgICAgICAgICAgICB1cGRhdGVNYW5hZ2VyLmFwcGx5VXBkYXRlKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgICAgfSk7XHJcbiAgICAgIHVwZGF0ZU1hbmFnZXIub25VcGRhdGVGYWlsZWQoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgLy8g5paw55qE54mI5pys5LiL6L295aSx6LSlXHJcbiAgICAgICAgd3guc2hvd01vZGFsKHtcclxuICAgICAgICAgIHRpdGxlOiBcIuabtOaWsOaPkOekulwiLFxyXG4gICAgICAgICAgY29udGVudDogXCLmlrDniYjmnKzkuIvovb3lpLHotKVcIixcclxuICAgICAgICAgIHNob3dDYW5jZWw6IGZhbHNlXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0pO1xyXG4gICAgICAvLyDmoKHpqoxTREtcclxuICAgICAgV3hVdGlscy5jaGVja1NESygpO1xyXG4gICAgICAvLyDlkIzmraXlvIDmlL7lubPlj7BFWFTmlbDmja5cclxuICAgICAgY29uc3QgZXh0ID0gd2VweS5nZXRFeHRDb25maWdTeW5jKCk7XHJcbiAgICAgIC8vIGNvbnNvbGUuaW5mbyhcIltleHRdIGluaXQgZXh0IGRhdGFcIiwgZXh0KTtcclxuICAgICAgaWYgKGV4dC5nbG9iYWxDb25maWcpIHtcclxuICAgICAgICAvLyBjb25zb2xlLmluZm8oXCJbZXh0XSBpbml0IGV4dCBnbG9iYWwgY29uZmlnIGRhdGFcIiwgZXh0Lmdsb2JhbENvbmZpZyk7XHJcbiAgICAgICAgT2JqZWN0LmFzc2lnbihleHQsIGV4dC5nbG9iYWxDb25maWcpO1xyXG4gICAgICB9XHJcbiAgICAgIE9iamVjdC5hc3NpZ24od2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YSwgZXh0KTtcclxuICAgICAgLy8gYXV0aC5sb2dpbigpO1xyXG4gICAgfVxyXG4gICAgb25TaG93KHBhcmFtKSB7XHJcbiAgICAgIGNvbnNvbGUubG9nKHBhcmFtKTtcclxuICAgICAgLy8g6I635Y+W5L+d5a2Y5Zy65pmv5YC8XHJcbiAgICAgIGlmIChwYXJhbSAmJiBwYXJhbS5zY2VuZSkge1xyXG4gICAgICAgIHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuc2NlbmUgPSBwYXJhbS5zY2VuZTtcclxuICAgICAgICBpZiAocGFyYW0ucXVlcnkucykgd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5iYXNlX3N0b3JlX2lkID0gcGFyYW0ucXVlcnkuc1xyXG4gICAgICAgIHN3aXRjaCAocGFyYW0uc2NlbmUpIHtcclxuICAgICAgICAgIC8vIOacjeWKoemAmuefpeS4i1xyXG4gICAgICAgICAgY2FzZSAxMDE0OlxyXG4gICAgICAgICAgICBpZiAocGFyYW0ucXVlcnkubGlkKSB3ZXB5LnNldFN0b3JhZ2VTeW5jKFwibGV2ZWxfaWRcIiwgcGFyYW0ucXVlcnkubGlkKTtcclxuICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBzeW5jU3RvcmVDb25maWcoa2V5KSB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgdmFsdWUgPSB3ZXB5LmdldFN0b3JhZ2VTeW5jKGtleSk7XHJcbiAgICAgICAgaWYgKHZhbHVlICE9PSBcIlwiKSB7XHJcbiAgICAgICAgICAvLyBjb25zb2xlLmluZm8oYFthdXRoXSR7a2V5fSBzeW5jIHN1Y2Nlc3MgYCk7XHJcbiAgICAgICAgICB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLmF1dGhba2V5XSA9IHZhbHVlO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgIC8vIGNvbnNvbGUud2FybihgW2F1dGhdJHtrZXl9IHN5bmMgZmFpbCBgKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgb25TaGFyZUFwcE1lc3NhZ2UocmVzKSB7XHJcbiAgICAgIGlmIChyZXMuZnJvbSA9PT0gXCJidXR0b25cIikge1xyXG4gICAgICAgIC8vIOadpeiHqumhtemdouWGhei9rOWPkeaMiemSrlxyXG4gICAgICAgIGNvbnNvbGUubG9nKHJlcy50YXJnZXQpO1xyXG4gICAgICB9XHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAgdGl0bGU6IFwi6Ieq5a6a5LmJ6L2s5Y+R5qCH6aKYXCIsXHJcbiAgICAgICAgcGF0aDogXCIvcGFnZXMvaG9tZS9pbmRleFwiXHJcbiAgICAgIH07XHJcbiAgICB9XHJcbiAgICBjb25maWcgPSB7XHJcbiAgICAgIHBhZ2VzOiBbXHJcbiAgICAgIFwicGFnZXMvaG9tZS9pbmRleFwiLFxyXG4gICAgICBcInBhZ2VzL2hvbWUvc2VhcmNoXCIsXHJcbiAgICAgIFwicGFnZXMvaG9tZS93ZWJcIixcclxuICAgICAgXCJwYWdlcy9ob21lL3NoYXJlXCIsXHJcbiAgICAgIFwicGFnZXMvbWVldC9tZWV0XCIsXHJcbiAgICAgIFwicGFnZXMvbXkvbXlcIixcclxuICAgICAgXCJwYWdlcy9teS9vcmRlcnNcIixcclxuICAgICAgXCJwYWdlcy9teS9vcmRlclwiLFxyXG4gICAgICBcInBhZ2VzL215L3BpbnR1YW5cIixcclxuICAgICAgXCJwYWdlcy9teS9iYXJnYWluaW5nXCIsXHJcbiAgICAgIFwicGFnZXMvaG9tZS9hZGRyZXNzXCIsXHJcbiAgICAgIFwicGFnZXMvZGV0YWlsZS9kZXRhaWxlXCIsXHJcbiAgICAgIFwicGFnZXMvZGV0YWlsZS9zdXJlT3JkZXJcIixcclxuICAgICAgXCJwYWdlcy9kZXRhaWxlL3BhcnRuZXJzXCIsXHJcbiAgICAgIFwicGFnZXMvbWVldC9jaGlsZHNcIixcclxuICAgICAgXCJwYWdlcy9tZWV0L2FkZENoaWxkXCIsXHJcbiAgICAgIFwicGFnZXMvbWVldC9hZGRNYW5cIixcclxuICAgICAgXCJwYWdlcy9tZWV0L3JlbWFya3NcIixcclxuICAgICAgXCJwYWdlcy9tZWV0L2NvbW1pUmVtYXJrZVwiLFxyXG4gICAgICBcInBhZ2VzL2FjdGl2aXR5L2JhcmdhaW5cIixcclxuICAgICAgXCJwYWdlcy9hY3Rpdml0eS9waW50dWFuXCIsXHJcbiAgICAgIFxyXG4gICAgICBdLFxyXG4gICAgICB3aW5kb3c6IHtcclxuICAgICAgICBiYWNrZ3JvdW5kVGV4dFN0eWxlOiBcImRhcmtcIixcclxuICAgICAgICBuYXZpZ2F0aW9uQmFyQmFja2dyb3VuZENvbG9yOiBcIiNGNEQwMDBcIixcclxuICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IFwiI2ZmZlwiLFxyXG4gICAgICAgIG5hdmlnYXRpb25CYXJUaXRsZVRleHQ6IFwiXCIsXHJcbiAgICAgICAgbmF2aWdhdGlvbkJhclRleHRTdHlsZTogXCJ3aGl0ZVwiXHJcbiAgICAgIH0sXHJcbiAgICAgIG5hdmlnYXRlVG9NaW5pUHJvZ3JhbUFwcElkTGlzdDogW10sXHJcbiAgICAgIHBlcm1pc3Npb246IHtcclxuICAgICAgICBcInNjb3BlLnVzZXJMb2NhdGlvblwiOiB7XHJcbiAgICAgICAgICBkZXNjOiBcIuS9oOeahOS9jee9ruS/oeaBr+WwhueUqOS6juWwj+eoi+W6j+S9jee9rueahOaViOaenOWxleekulwiXHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG4gICAgICBcInRhYkJhclwiOiB7XHJcbiAgICAgICAgXCJjb2xvclwiOiBcIiNhOWI3YjdcIixcclxuICAgICAgICBcInNlbGVjdGVkQ29sb3JcIjogXCIjRjREMDAwXCIsXHJcbiAgICAgICAgXCJib3JkZXJTdHlsZVwiOiBcImJsYWNrXCIsXHJcbiAgICAgICAgXCJsaXN0XCI6IFtcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgXCJzZWxlY3RlZEljb25QYXRoXCI6IFwic3RhdGljL2ltYWdlcy9pY29uX2NvbnN1bHRfcHJlc3MucG5nXCIsXHJcbiAgICAgICAgICAgIFwiaWNvblBhdGhcIjogXCJzdGF0aWMvaW1hZ2VzL2ljb25fY29uc3VsdC5wbmdcIixcclxuICAgICAgICAgICAgXCJwYWdlUGF0aFwiOiBcInBhZ2VzL2hvbWUvaW5kZXhcIixcclxuICAgICAgICAgICAgXCJ0ZXh0XCI6IFwi6aaW6aG1XCJcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIFwic2VsZWN0ZWRJY29uUGF0aFwiOiBcInN0YXRpYy9pbWFnZXMvaWNvbl9pbnZlc3RfcHJlc3MucG5nXCIsXHJcbiAgICAgICAgICAgIFwiaWNvblBhdGhcIjogXCJzdGF0aWMvaW1hZ2VzL2ljb25faW52ZXN0LnBuZ1wiLFxyXG4gICAgICAgICAgICBcInBhZ2VQYXRoXCI6IFwicGFnZXMvbWVldC9tZWV0XCIsXHJcbiAgICAgICAgICAgIFwidGV4dFwiOiBcIuS6kuWKqFwiXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBcInNlbGVjdGVkSWNvblBhdGhcIjogXCJzdGF0aWMvaW1hZ2VzL2ljb25fbWluZV9wcmVzcy5wbmdcIixcclxuICAgICAgICAgICAgXCJpY29uUGF0aFwiOiBcInN0YXRpYy9pbWFnZXMvaWNvbl9taW5lLnBuZ1wiLFxyXG4gICAgICAgICAgICBcInBhZ2VQYXRoXCI6IFwicGFnZXMvbXkvbXlcIixcclxuICAgICAgICAgICAgXCJ0ZXh0XCI6IFwi5oiR55qEXCJcclxuICAgICAgICAgIH1cclxuICAgICAgICBdXHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgfVxyXG4iXX0=