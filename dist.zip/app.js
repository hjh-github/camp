"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

require('./npm/wepy-async-function/index.js');

var _WxUtils = require('./utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

var _wepyRedux = require('./npm/wepy-redux/lib/index.js');

var _store = require('./store/index.js');

var _store2 = _interopRequireDefault(_store);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var store = (0, _store2.default)();
(0, _wepyRedux.setStore)(store);

var _default = function (_wepy$app) {
  _inherits(_default, _wepy$app);

  function _default() {
    _classCallCheck(this, _default);

    // 注册中间件
    var _this = _possibleConstructorReturn(this, (_default.__proto__ || Object.getPrototypeOf(_default)).call(this));

    _this.globalData = {
      auth: {},
      scene: null,
      base_store_id: "",
      appCode: "",
      baseUrl: "https://wechat.hxqxly.com",
      // baseUrl: "https://test.hxqxly.com",
      themeColor: "#F4D000",
      cityCode: '',
      code: '',
      sessionId: '',
      courseInfo: {},
      orderInfo: {},
      childs: [],
      help: true,
      query: {}
    };
    _this.config = {
      pages: ["pages/home/index", "pages/home/auth", "pages/home/search", "pages/home/web", "pages/home/share", "pages/meet/meet", "pages/my/my", "pages/my/orders", "pages/my/order", "pages/my/pintuan", "pages/my/bargaining", "pages/home/address", "pages/detaile/detaile", "pages/detaile/sureOrder", "pages/detaile/partners", "pages/meet/childs", "pages/meet/addChild", "pages/meet/addMan", "pages/meet/remarks", "pages/meet/commiRemarke", "pages/activity/bargain", "pages/activity/pintuan"],
      subPackages: [{
        root: "agent",
        pages: ["pages/index", "pages/share", "pages/sign"]
      }],
      window: {
        backgroundTextStyle: "dark",
        navigationBarBackgroundColor: "#F4D000",
        backgroundColor: "#fff",
        navigationBarTitleText: "",
        navigationBarTextStyle: "white"
      },
      navigateToMiniProgramAppIdList: [],
      permission: {
        "scope.userLocation": {
          desc: "你的位置信息将用于小程序位置的效果展示"
        }
      },
      "tabBar": {
        "color": "#a9b7b7",
        "selectedColor": "#F4D000",
        "borderStyle": "black",
        "list": [{
          "selectedIconPath": "static/images/icon_consult_press.png",
          "iconPath": "static/images/icon_consult.png",
          "pagePath": "pages/home/index",
          "text": "首页"
        }, {
          "selectedIconPath": "static/images/icon_invest_press.png",
          "iconPath": "static/images/icon_invest.png",
          "pagePath": "pages/meet/meet",
          "text": "互动"
        }, {
          "selectedIconPath": "static/images/icon_mine_press.png",
          "iconPath": "static/images/icon_mine.png",
          "pagePath": "pages/my/my",
          "text": "我的"
        }]
      }
    };
    _this.use("requestfix");
    _this.use("promisify");
    return _this;
  }

  _createClass(_default, [{
    key: "onLaunch",
    value: function () {
      var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(param) {
        var updateManager, ext;
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                // 获取当前小程序
                try {
                  _wepy2.default.$instance.globalData.appCode = wx.getAccountInfoSync().miniProgram.appId;
                } catch (res) {
                  if (wx.canIUse("getAccountInfoSync")) {
                    _wepy2.default.$instance.globalData.appCode = wx.getAccountInfoSync().miniProgram.appId;
                  } else {
                    // 如果希望用户在最新版本的客户端上体验您的小程序，可以这样子提示
                    wx.showModal({
                      title: "提示",
                      content: "当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。"
                    });
                  }
                }
                updateManager = wx.getUpdateManager();

                updateManager.onCheckForUpdate(function (res) {
                  // 请求完新版本信息的回调
                  console.log(res.hasUpdate);
                });
                updateManager.onUpdateReady(function () {
                  wx.showModal({
                    title: "更新提示",
                    content: "新版本已经准备好，是否重启应用？",
                    success: function success(res) {
                      if (res.confirm) {
                        // 新的版本已经下载好，调用 applyUpdate 应用新版本并重启
                        updateManager.applyUpdate();
                      }
                    }
                  });
                });
                updateManager.onUpdateFailed(function () {
                  // 新的版本下载失败
                  wx.showModal({
                    title: "更新提示",
                    content: "新版本下载失败",
                    showCancel: false
                  });
                });
                // 校验SDK
                _WxUtils2.default.checkSDK();
                // 同步开放平台EXT数据
                ext = _wepy2.default.getExtConfigSync();
                // console.info("[ext] init ext data", ext);

                if (ext.globalConfig) {
                  // console.info("[ext] init ext global config data", ext.globalConfig);
                  Object.assign(ext, ext.globalConfig);
                }
                Object.assign(_wepy2.default.$instance.globalData, ext);
                // auth.login();

              case 9:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function onLaunch(_x) {
        return _ref.apply(this, arguments);
      }

      return onLaunch;
    }()
  }, {
    key: "onShow",
    value: function onShow(param) {
      console.log(param);
      // 获取保存场景值
      if (param && param.scene) {
        _wepy2.default.$instance.globalData.scene = param.scene;
        console.log();
        if (param.query.scene) {
          _wepy2.default.$instance.globalData.query = this.getCodeBy1047(param.query.scene);
        } else if (param.query.agentId) {
          _wepy2.default.$instance.globalData.query['agentId'] = param.query.agentId;
        }
      }
    }
  }, {
    key: "getCodeBy1047",
    value: function getCodeBy1047(str) {
      var query = {},
          strs = decodeURIComponent(str).split("&");
      console.log(strs);
      for (var i = 0, len = strs.length; i < len; i++) {
        query[strs[i].split("=")[0]] = strs[i].split("=")[1];
      }
      return query;
    }
  }, {
    key: "syncStoreConfig",
    value: function syncStoreConfig(key) {
      try {
        var value = _wepy2.default.getStorageSync(key);
        if (value !== "") {
          // console.info(`[auth]${key} sync success `);
          _wepy2.default.$instance.globalData.auth[key] = value;
        }
      } catch (e) {
        // console.warn(`[auth]${key} sync fail `);
      }
    }
  }, {
    key: "onShareAppMessage",
    value: function onShareAppMessage(res) {
      if (res.from === "button") {
        // 来自页面内转发按钮
        console.log(res.target);
      }
      return {
        title: "自定义转发标题",
        path: "/pages/home/index"
      };
    }
  }]);

  return _default;
}(_wepy2.default.app);


App(require('./npm/wepy/lib/wepy.js').default.$createApp(_default, {"noPromiseAPI":["createSelectorQuery"]}));
require('./_wepylogs.js')

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC5qcyJdLCJuYW1lcyI6WyJzdG9yZSIsImdsb2JhbERhdGEiLCJhdXRoIiwic2NlbmUiLCJiYXNlX3N0b3JlX2lkIiwiYXBwQ29kZSIsImJhc2VVcmwiLCJ0aGVtZUNvbG9yIiwiY2l0eUNvZGUiLCJjb2RlIiwic2Vzc2lvbklkIiwiY291cnNlSW5mbyIsIm9yZGVySW5mbyIsImNoaWxkcyIsImhlbHAiLCJxdWVyeSIsImNvbmZpZyIsInBhZ2VzIiwic3ViUGFja2FnZXMiLCJyb290Iiwid2luZG93IiwiYmFja2dyb3VuZFRleHRTdHlsZSIsIm5hdmlnYXRpb25CYXJCYWNrZ3JvdW5kQ29sb3IiLCJiYWNrZ3JvdW5kQ29sb3IiLCJuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0IiwibmF2aWdhdGlvbkJhclRleHRTdHlsZSIsIm5hdmlnYXRlVG9NaW5pUHJvZ3JhbUFwcElkTGlzdCIsInBlcm1pc3Npb24iLCJkZXNjIiwidXNlIiwicGFyYW0iLCJ3ZXB5IiwiJGluc3RhbmNlIiwid3giLCJnZXRBY2NvdW50SW5mb1N5bmMiLCJtaW5pUHJvZ3JhbSIsImFwcElkIiwicmVzIiwiY2FuSVVzZSIsInNob3dNb2RhbCIsInRpdGxlIiwiY29udGVudCIsInVwZGF0ZU1hbmFnZXIiLCJnZXRVcGRhdGVNYW5hZ2VyIiwib25DaGVja0ZvclVwZGF0ZSIsImNvbnNvbGUiLCJsb2ciLCJoYXNVcGRhdGUiLCJvblVwZGF0ZVJlYWR5Iiwic3VjY2VzcyIsImNvbmZpcm0iLCJhcHBseVVwZGF0ZSIsIm9uVXBkYXRlRmFpbGVkIiwic2hvd0NhbmNlbCIsIld4VXRpbHMiLCJjaGVja1NESyIsImV4dCIsImdldEV4dENvbmZpZ1N5bmMiLCJnbG9iYWxDb25maWciLCJPYmplY3QiLCJhc3NpZ24iLCJnZXRDb2RlQnkxMDQ3IiwiYWdlbnRJZCIsInN0ciIsInN0cnMiLCJkZWNvZGVVUklDb21wb25lbnQiLCJzcGxpdCIsImkiLCJsZW4iLCJsZW5ndGgiLCJrZXkiLCJ2YWx1ZSIsImdldFN0b3JhZ2VTeW5jIiwiZSIsImZyb20iLCJ0YXJnZXQiLCJwYXRoIiwiYXBwIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFDRTs7OztBQUNBOztBQUNBOzs7O0FBQ0E7O0FBR0E7Ozs7Ozs7Ozs7Ozs7O0FBQ0EsSUFBTUEsUUFBUSxzQkFBZDtBQUNBLHlCQUFTQSxLQUFUOzs7OztBQW1CRSxzQkFBYztBQUFBOztBQUVaO0FBRlk7O0FBQUEsVUFqQmRDLFVBaUJjLEdBakJEO0FBQ1hDLFlBQU0sRUFESztBQUVYQyxhQUFPLElBRkk7QUFHWEMscUJBQWUsRUFISjtBQUlYQyxlQUFTLEVBSkU7QUFLWEMsZUFBUywyQkFMRTtBQU1YO0FBQ0FDLGtCQUFZLFNBUEQ7QUFRWEMsZ0JBQVUsRUFSQztBQVNYQyxZQUFNLEVBVEs7QUFVWEMsaUJBQVcsRUFWQTtBQVdYQyxrQkFBWSxFQVhEO0FBWVhDLGlCQUFXLEVBWkE7QUFhWEMsY0FBUSxFQWJHO0FBY1hDLFlBQU0sSUFkSztBQWVYQyxhQUFPO0FBZkksS0FpQkM7QUFBQSxVQXFHZEMsTUFyR2MsR0FxR0w7QUFDUEMsYUFBTyxDQUNMLGtCQURLLEVBRUwsaUJBRkssRUFHTCxtQkFISyxFQUlMLGdCQUpLLEVBS0wsa0JBTEssRUFNTCxpQkFOSyxFQU9MLGFBUEssRUFRTCxpQkFSSyxFQVNMLGdCQVRLLEVBVUwsa0JBVkssRUFXTCxxQkFYSyxFQVlMLG9CQVpLLEVBYUwsdUJBYkssRUFjTCx5QkFkSyxFQWVMLHdCQWZLLEVBZ0JMLG1CQWhCSyxFQWlCTCxxQkFqQkssRUFrQkwsbUJBbEJLLEVBbUJMLG9CQW5CSyxFQW9CTCx5QkFwQkssRUFxQkwsd0JBckJLLEVBc0JMLHdCQXRCSyxDQURBO0FBeUJQQyxtQkFBYSxDQUFDO0FBQ1pDLGNBQU0sT0FETTtBQUVaRixlQUFPLENBQ0wsYUFESyxFQUVMLGFBRkssRUFHTCxZQUhLO0FBRkssT0FBRCxDQXpCTjtBQWlDUEcsY0FBUTtBQUNOQyw2QkFBcUIsTUFEZjtBQUVOQyxzQ0FBOEIsU0FGeEI7QUFHTkMseUJBQWlCLE1BSFg7QUFJTkMsZ0NBQXdCLEVBSmxCO0FBS05DLGdDQUF3QjtBQUxsQixPQWpDRDtBQXdDUEMsc0NBQWdDLEVBeEN6QjtBQXlDUEMsa0JBQVk7QUFDViw4QkFBc0I7QUFDcEJDLGdCQUFNO0FBRGM7QUFEWixPQXpDTDtBQThDUCxnQkFBVTtBQUNSLGlCQUFTLFNBREQ7QUFFUix5QkFBaUIsU0FGVDtBQUdSLHVCQUFlLE9BSFA7QUFJUixnQkFBUSxDQUFDO0FBQ0wsOEJBQW9CLHNDQURmO0FBRUwsc0JBQVksZ0NBRlA7QUFHTCxzQkFBWSxrQkFIUDtBQUlMLGtCQUFRO0FBSkgsU0FBRCxFQU1OO0FBQ0UsOEJBQW9CLHFDQUR0QjtBQUVFLHNCQUFZLCtCQUZkO0FBR0Usc0JBQVksaUJBSGQ7QUFJRSxrQkFBUTtBQUpWLFNBTk0sRUFZTjtBQUNFLDhCQUFvQixtQ0FEdEI7QUFFRSxzQkFBWSw2QkFGZDtBQUdFLHNCQUFZLGFBSGQ7QUFJRSxrQkFBUTtBQUpWLFNBWk07QUFKQTtBQTlDSCxLQXJHSztBQUdaLFVBQUtDLEdBQUwsQ0FBUyxZQUFUO0FBQ0EsVUFBS0EsR0FBTCxDQUFTLFdBQVQ7QUFKWTtBQUtiOzs7OzswRkFDY0MsSzs7Ozs7O0FBQ2I7QUFDQSxvQkFBSTtBQUNGQyxpQ0FBS0MsU0FBTCxDQUFlL0IsVUFBZixDQUEwQkksT0FBMUIsR0FBb0M0QixHQUFHQyxrQkFBSCxHQUF3QkMsV0FBeEIsQ0FBb0NDLEtBQXhFO0FBQ0QsaUJBRkQsQ0FFRSxPQUFPQyxHQUFQLEVBQVk7QUFDWixzQkFBSUosR0FBR0ssT0FBSCxDQUFXLG9CQUFYLENBQUosRUFBc0M7QUFDcENQLG1DQUFLQyxTQUFMLENBQWUvQixVQUFmLENBQTBCSSxPQUExQixHQUFvQzRCLEdBQUdDLGtCQUFILEdBQXdCQyxXQUF4QixDQUFvQ0MsS0FBeEU7QUFDRCxtQkFGRCxNQUVPO0FBQ0w7QUFDQUgsdUJBQUdNLFNBQUgsQ0FBYTtBQUNYQyw2QkFBTyxJQURJO0FBRVhDLCtCQUFTO0FBRkUscUJBQWI7QUFJRDtBQUNGO0FBQ0tDLDZCLEdBQWdCVCxHQUFHVSxnQkFBSCxFOztBQUN0QkQsOEJBQWNFLGdCQUFkLENBQStCLFVBQVNQLEdBQVQsRUFBYztBQUMzQztBQUNBUSwwQkFBUUMsR0FBUixDQUFZVCxJQUFJVSxTQUFoQjtBQUNELGlCQUhEO0FBSUFMLDhCQUFjTSxhQUFkLENBQTRCLFlBQVc7QUFDckNmLHFCQUFHTSxTQUFILENBQWE7QUFDWEMsMkJBQU8sTUFESTtBQUVYQyw2QkFBUyxrQkFGRTtBQUdYUSw2QkFBUyxpQkFBU1osR0FBVCxFQUFjO0FBQ3JCLDBCQUFJQSxJQUFJYSxPQUFSLEVBQWlCO0FBQ2Y7QUFDQVIsc0NBQWNTLFdBQWQ7QUFDRDtBQUNGO0FBUlUsbUJBQWI7QUFVRCxpQkFYRDtBQVlBVCw4QkFBY1UsY0FBZCxDQUE2QixZQUFXO0FBQ3RDO0FBQ0FuQixxQkFBR00sU0FBSCxDQUFhO0FBQ1hDLDJCQUFPLE1BREk7QUFFWEMsNkJBQVMsU0FGRTtBQUdYWSxnQ0FBWTtBQUhELG1CQUFiO0FBS0QsaUJBUEQ7QUFRQTtBQUNBQyxrQ0FBUUMsUUFBUjtBQUNBO0FBQ01DLG1CLEdBQU16QixlQUFLMEIsZ0JBQUwsRTtBQUNaOztBQUNBLG9CQUFJRCxJQUFJRSxZQUFSLEVBQXNCO0FBQ3BCO0FBQ0FDLHlCQUFPQyxNQUFQLENBQWNKLEdBQWQsRUFBbUJBLElBQUlFLFlBQXZCO0FBQ0Q7QUFDREMsdUJBQU9DLE1BQVAsQ0FBYzdCLGVBQUtDLFNBQUwsQ0FBZS9CLFVBQTdCLEVBQXlDdUQsR0FBekM7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7OzJCQUVLMUIsSyxFQUFPO0FBQ1plLGNBQVFDLEdBQVIsQ0FBWWhCLEtBQVo7QUFDQTtBQUNBLFVBQUlBLFNBQVNBLE1BQU0zQixLQUFuQixFQUEwQjtBQUN4QjRCLHVCQUFLQyxTQUFMLENBQWUvQixVQUFmLENBQTBCRSxLQUExQixHQUFrQzJCLE1BQU0zQixLQUF4QztBQUNBMEMsZ0JBQVFDLEdBQVI7QUFDQSxZQUFJaEIsTUFBTWYsS0FBTixDQUFZWixLQUFoQixFQUF1QjtBQUNyQjRCLHlCQUFLQyxTQUFMLENBQWUvQixVQUFmLENBQTBCYyxLQUExQixHQUFrQyxLQUFLOEMsYUFBTCxDQUFtQi9CLE1BQU1mLEtBQU4sQ0FBWVosS0FBL0IsQ0FBbEM7QUFDRCxTQUZELE1BRU8sSUFBSTJCLE1BQU1mLEtBQU4sQ0FBWStDLE9BQWhCLEVBQXlCO0FBQzlCL0IseUJBQUtDLFNBQUwsQ0FBZS9CLFVBQWYsQ0FBMEJjLEtBQTFCLENBQWdDLFNBQWhDLElBQTZDZSxNQUFNZixLQUFOLENBQVkrQyxPQUF6RDtBQUNEO0FBQ0Y7QUFDRjs7O2tDQUNhQyxHLEVBQUs7QUFDakIsVUFBSWhELFFBQVEsRUFBWjtBQUFBLFVBQ0VpRCxPQUFPQyxtQkFBbUJGLEdBQW5CLEVBQXdCRyxLQUF4QixDQUE4QixHQUE5QixDQURUO0FBRUFyQixjQUFRQyxHQUFSLENBQVlrQixJQUFaO0FBQ0EsV0FBSyxJQUFJRyxJQUFJLENBQVIsRUFBV0MsTUFBTUosS0FBS0ssTUFBM0IsRUFBbUNGLElBQUlDLEdBQXZDLEVBQTRDRCxHQUE1QyxFQUFpRDtBQUMvQ3BELGNBQU1pRCxLQUFLRyxDQUFMLEVBQVFELEtBQVIsQ0FBYyxHQUFkLEVBQW1CLENBQW5CLENBQU4sSUFBK0JGLEtBQUtHLENBQUwsRUFBUUQsS0FBUixDQUFjLEdBQWQsRUFBbUIsQ0FBbkIsQ0FBL0I7QUFDRDtBQUNELGFBQU9uRCxLQUFQO0FBQ0Q7OztvQ0FDZXVELEcsRUFBSztBQUNuQixVQUFJO0FBQ0YsWUFBTUMsUUFBUXhDLGVBQUt5QyxjQUFMLENBQW9CRixHQUFwQixDQUFkO0FBQ0EsWUFBSUMsVUFBVSxFQUFkLEVBQWtCO0FBQ2hCO0FBQ0F4Qyx5QkFBS0MsU0FBTCxDQUFlL0IsVUFBZixDQUEwQkMsSUFBMUIsQ0FBK0JvRSxHQUEvQixJQUFzQ0MsS0FBdEM7QUFDRDtBQUNGLE9BTkQsQ0FNRSxPQUFPRSxDQUFQLEVBQVU7QUFDVjtBQUNEO0FBQ0Y7OztzQ0FDaUJwQyxHLEVBQUs7QUFDckIsVUFBSUEsSUFBSXFDLElBQUosS0FBYSxRQUFqQixFQUEyQjtBQUN6QjtBQUNBN0IsZ0JBQVFDLEdBQVIsQ0FBWVQsSUFBSXNDLE1BQWhCO0FBQ0Q7QUFDRCxhQUFPO0FBQ0xuQyxlQUFPLFNBREY7QUFFTG9DLGNBQU07QUFGRCxPQUFQO0FBSUQ7Ozs7RUF0SDBCN0MsZUFBSzhDLEciLCJmaWxlIjoiYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbiAgaW1wb3J0IHdlcHkgZnJvbSBcIndlcHlcIjtcclxuICBpbXBvcnQgXCJ3ZXB5LWFzeW5jLWZ1bmN0aW9uXCI7XHJcbiAgaW1wb3J0IFd4VXRpbHMgZnJvbSBcIi4vdXRpbHMvV3hVdGlsc1wiO1xyXG4gIGltcG9ydCB7XHJcbiAgICBzZXRTdG9yZVxyXG4gIH0gZnJvbSBcIndlcHktcmVkdXhcIjtcclxuICBpbXBvcnQgY29uZmlnU3RvcmUgZnJvbSBcIi4vc3RvcmVcIjtcclxuICBjb25zdCBzdG9yZSA9IGNvbmZpZ1N0b3JlKCk7XHJcbiAgc2V0U3RvcmUoc3RvcmUpO1xyXG4gIGV4cG9ydCBkZWZhdWx0IGNsYXNzIGV4dGVuZHMgd2VweS5hcHAge1xyXG4gICAgZ2xvYmFsRGF0YSA9IHtcclxuICAgICAgYXV0aDoge30sXHJcbiAgICAgIHNjZW5lOiBudWxsLFxyXG4gICAgICBiYXNlX3N0b3JlX2lkOiBcIlwiLFxyXG4gICAgICBhcHBDb2RlOiBcIlwiLFxyXG4gICAgICBiYXNlVXJsOiBcImh0dHBzOi8vd2VjaGF0Lmh4cXhseS5jb21cIixcclxuICAgICAgLy8gYmFzZVVybDogXCJodHRwczovL3Rlc3QuaHhxeGx5LmNvbVwiLFxyXG4gICAgICB0aGVtZUNvbG9yOiBcIiNGNEQwMDBcIixcclxuICAgICAgY2l0eUNvZGU6ICcnLFxyXG4gICAgICBjb2RlOiAnJyxcclxuICAgICAgc2Vzc2lvbklkOiAnJyxcclxuICAgICAgY291cnNlSW5mbzoge30sXHJcbiAgICAgIG9yZGVySW5mbzoge30sXHJcbiAgICAgIGNoaWxkczogW10sXHJcbiAgICAgIGhlbHA6IHRydWUsXHJcbiAgICAgIHF1ZXJ5OiB7fVxyXG4gICAgfTtcclxuICAgIGNvbnN0cnVjdG9yKCkge1xyXG4gICAgICBzdXBlcigpO1xyXG4gICAgICAvLyDms6jlhozkuK3pl7Tku7ZcclxuICAgICAgdGhpcy51c2UoXCJyZXF1ZXN0Zml4XCIpO1xyXG4gICAgICB0aGlzLnVzZShcInByb21pc2lmeVwiKTtcclxuICAgIH1cclxuICAgIGFzeW5jIG9uTGF1bmNoKHBhcmFtKSB7XHJcbiAgICAgIC8vIOiOt+WPluW9k+WJjeWwj+eoi+W6j1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuYXBwQ29kZSA9IHd4LmdldEFjY291bnRJbmZvU3luYygpLm1pbmlQcm9ncmFtLmFwcElkO1xyXG4gICAgICB9IGNhdGNoIChyZXMpIHtcclxuICAgICAgICBpZiAod3guY2FuSVVzZShcImdldEFjY291bnRJbmZvU3luY1wiKSkge1xyXG4gICAgICAgICAgd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5hcHBDb2RlID0gd3guZ2V0QWNjb3VudEluZm9TeW5jKCkubWluaVByb2dyYW0uYXBwSWQ7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIC8vIOWmguaenOW4jOacm+eUqOaIt+WcqOacgOaWsOeJiOacrOeahOWuouaIt+err+S4iuS9k+mqjOaCqOeahOWwj+eoi+W6j++8jOWPr+S7pei/meagt+WtkOaPkOekulxyXG4gICAgICAgICAgd3guc2hvd01vZGFsKHtcclxuICAgICAgICAgICAgdGl0bGU6IFwi5o+Q56S6XCIsXHJcbiAgICAgICAgICAgIGNvbnRlbnQ6IFwi5b2T5YmN5b6u5L+h54mI5pys6L+H5L2O77yM5peg5rOV5L2/55So6K+l5Yqf6IO977yM6K+35Y2H57qn5Yiw5pyA5paw5b6u5L+h54mI5pys5ZCO6YeN6K+V44CCXCJcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgICBjb25zdCB1cGRhdGVNYW5hZ2VyID0gd3guZ2V0VXBkYXRlTWFuYWdlcigpO1xyXG4gICAgICB1cGRhdGVNYW5hZ2VyLm9uQ2hlY2tGb3JVcGRhdGUoZnVuY3Rpb24ocmVzKSB7XHJcbiAgICAgICAgLy8g6K+35rGC5a6M5paw54mI5pys5L+h5oGv55qE5Zue6LCDXHJcbiAgICAgICAgY29uc29sZS5sb2cocmVzLmhhc1VwZGF0ZSk7XHJcbiAgICAgIH0pO1xyXG4gICAgICB1cGRhdGVNYW5hZ2VyLm9uVXBkYXRlUmVhZHkoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgd3guc2hvd01vZGFsKHtcclxuICAgICAgICAgIHRpdGxlOiBcIuabtOaWsOaPkOekulwiLFxyXG4gICAgICAgICAgY29udGVudDogXCLmlrDniYjmnKzlt7Lnu4/lh4blpIflpb3vvIzmmK/lkKbph43lkK/lupTnlKjvvJ9cIixcclxuICAgICAgICAgIHN1Y2Nlc3M6IGZ1bmN0aW9uKHJlcykge1xyXG4gICAgICAgICAgICBpZiAocmVzLmNvbmZpcm0pIHtcclxuICAgICAgICAgICAgICAvLyDmlrDnmoTniYjmnKzlt7Lnu4/kuIvovb3lpb3vvIzosIPnlKggYXBwbHlVcGRhdGUg5bqU55So5paw54mI5pys5bm26YeN5ZCvXHJcbiAgICAgICAgICAgICAgdXBkYXRlTWFuYWdlci5hcHBseVVwZGF0ZSgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0pO1xyXG4gICAgICB1cGRhdGVNYW5hZ2VyLm9uVXBkYXRlRmFpbGVkKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgIC8vIOaWsOeahOeJiOacrOS4i+i9veWksei0pVxyXG4gICAgICAgIHd4LnNob3dNb2RhbCh7XHJcbiAgICAgICAgICB0aXRsZTogXCLmm7TmlrDmj5DnpLpcIixcclxuICAgICAgICAgIGNvbnRlbnQ6IFwi5paw54mI5pys5LiL6L295aSx6LSlXCIsXHJcbiAgICAgICAgICBzaG93Q2FuY2VsOiBmYWxzZVxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9KTtcclxuICAgICAgLy8g5qCh6aqMU0RLXHJcbiAgICAgIFd4VXRpbHMuY2hlY2tTREsoKTtcclxuICAgICAgLy8g5ZCM5q2l5byA5pS+5bmz5Y+wRVhU5pWw5o2uXHJcbiAgICAgIGNvbnN0IGV4dCA9IHdlcHkuZ2V0RXh0Q29uZmlnU3luYygpO1xyXG4gICAgICAvLyBjb25zb2xlLmluZm8oXCJbZXh0XSBpbml0IGV4dCBkYXRhXCIsIGV4dCk7XHJcbiAgICAgIGlmIChleHQuZ2xvYmFsQ29uZmlnKSB7XHJcbiAgICAgICAgLy8gY29uc29sZS5pbmZvKFwiW2V4dF0gaW5pdCBleHQgZ2xvYmFsIGNvbmZpZyBkYXRhXCIsIGV4dC5nbG9iYWxDb25maWcpO1xyXG4gICAgICAgIE9iamVjdC5hc3NpZ24oZXh0LCBleHQuZ2xvYmFsQ29uZmlnKTtcclxuICAgICAgfVxyXG4gICAgICBPYmplY3QuYXNzaWduKHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEsIGV4dCk7XHJcbiAgICAgIC8vIGF1dGgubG9naW4oKTtcclxuICAgIH1cclxuICAgIG9uU2hvdyhwYXJhbSkge1xyXG4gICAgICBjb25zb2xlLmxvZyhwYXJhbSk7XHJcbiAgICAgIC8vIOiOt+WPluS/neWtmOWcuuaZr+WAvFxyXG4gICAgICBpZiAocGFyYW0gJiYgcGFyYW0uc2NlbmUpIHtcclxuICAgICAgICB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnNjZW5lID0gcGFyYW0uc2NlbmU7XHJcbiAgICAgICAgY29uc29sZS5sb2coKVxyXG4gICAgICAgIGlmIChwYXJhbS5xdWVyeS5zY2VuZSkge1xyXG4gICAgICAgICAgd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5xdWVyeSA9IHRoaXMuZ2V0Q29kZUJ5MTA0NyhwYXJhbS5xdWVyeS5zY2VuZSlcclxuICAgICAgICB9IGVsc2UgaWYgKHBhcmFtLnF1ZXJ5LmFnZW50SWQpIHtcclxuICAgICAgICAgIHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEucXVlcnlbJ2FnZW50SWQnXSA9IHBhcmFtLnF1ZXJ5LmFnZW50SWRcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIGdldENvZGVCeTEwNDcoc3RyKSB7XHJcbiAgICAgIHZhciBxdWVyeSA9IHt9LFxyXG4gICAgICAgIHN0cnMgPSBkZWNvZGVVUklDb21wb25lbnQoc3RyKS5zcGxpdChcIiZcIik7XHJcbiAgICAgIGNvbnNvbGUubG9nKHN0cnMpO1xyXG4gICAgICBmb3IgKHZhciBpID0gMCwgbGVuID0gc3Rycy5sZW5ndGg7IGkgPCBsZW47IGkrKykge1xyXG4gICAgICAgIHF1ZXJ5W3N0cnNbaV0uc3BsaXQoXCI9XCIpWzBdXSA9IHN0cnNbaV0uc3BsaXQoXCI9XCIpWzFdO1xyXG4gICAgICB9XHJcbiAgICAgIHJldHVybiBxdWVyeTtcclxuICAgIH1cclxuICAgIHN5bmNTdG9yZUNvbmZpZyhrZXkpIHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCB2YWx1ZSA9IHdlcHkuZ2V0U3RvcmFnZVN5bmMoa2V5KTtcclxuICAgICAgICBpZiAodmFsdWUgIT09IFwiXCIpIHtcclxuICAgICAgICAgIC8vIGNvbnNvbGUuaW5mbyhgW2F1dGhdJHtrZXl9IHN5bmMgc3VjY2VzcyBgKTtcclxuICAgICAgICAgIHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuYXV0aFtrZXldID0gdmFsdWU7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgLy8gY29uc29sZS53YXJuKGBbYXV0aF0ke2tleX0gc3luYyBmYWlsIGApO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBvblNoYXJlQXBwTWVzc2FnZShyZXMpIHtcclxuICAgICAgaWYgKHJlcy5mcm9tID09PSBcImJ1dHRvblwiKSB7XHJcbiAgICAgICAgLy8g5p2l6Ieq6aG16Z2i5YaF6L2s5Y+R5oyJ6ZKuXHJcbiAgICAgICAgY29uc29sZS5sb2cocmVzLnRhcmdldCk7XHJcbiAgICAgIH1cclxuICAgICAgcmV0dXJuIHtcclxuICAgICAgICB0aXRsZTogXCLoh6rlrprkuYnovazlj5HmoIfpophcIixcclxuICAgICAgICBwYXRoOiBcIi9wYWdlcy9ob21lL2luZGV4XCJcclxuICAgICAgfTtcclxuICAgIH1cclxuICAgIGNvbmZpZyA9IHtcclxuICAgICAgcGFnZXM6IFtcclxuICAgICAgICBcInBhZ2VzL2hvbWUvaW5kZXhcIixcclxuICAgICAgICBcInBhZ2VzL2hvbWUvYXV0aFwiLFxyXG4gICAgICAgIFwicGFnZXMvaG9tZS9zZWFyY2hcIixcclxuICAgICAgICBcInBhZ2VzL2hvbWUvd2ViXCIsXHJcbiAgICAgICAgXCJwYWdlcy9ob21lL3NoYXJlXCIsXHJcbiAgICAgICAgXCJwYWdlcy9tZWV0L21lZXRcIixcclxuICAgICAgICBcInBhZ2VzL215L215XCIsXHJcbiAgICAgICAgXCJwYWdlcy9teS9vcmRlcnNcIixcclxuICAgICAgICBcInBhZ2VzL215L29yZGVyXCIsXHJcbiAgICAgICAgXCJwYWdlcy9teS9waW50dWFuXCIsXHJcbiAgICAgICAgXCJwYWdlcy9teS9iYXJnYWluaW5nXCIsXHJcbiAgICAgICAgXCJwYWdlcy9ob21lL2FkZHJlc3NcIixcclxuICAgICAgICBcInBhZ2VzL2RldGFpbGUvZGV0YWlsZVwiLFxyXG4gICAgICAgIFwicGFnZXMvZGV0YWlsZS9zdXJlT3JkZXJcIixcclxuICAgICAgICBcInBhZ2VzL2RldGFpbGUvcGFydG5lcnNcIixcclxuICAgICAgICBcInBhZ2VzL21lZXQvY2hpbGRzXCIsXHJcbiAgICAgICAgXCJwYWdlcy9tZWV0L2FkZENoaWxkXCIsXHJcbiAgICAgICAgXCJwYWdlcy9tZWV0L2FkZE1hblwiLFxyXG4gICAgICAgIFwicGFnZXMvbWVldC9yZW1hcmtzXCIsXHJcbiAgICAgICAgXCJwYWdlcy9tZWV0L2NvbW1pUmVtYXJrZVwiLFxyXG4gICAgICAgIFwicGFnZXMvYWN0aXZpdHkvYmFyZ2FpblwiLFxyXG4gICAgICAgIFwicGFnZXMvYWN0aXZpdHkvcGludHVhblwiLFxyXG4gICAgICBdLFxyXG4gICAgICBzdWJQYWNrYWdlczogW3tcclxuICAgICAgICByb290OiBcImFnZW50XCIsXHJcbiAgICAgICAgcGFnZXM6IFtcclxuICAgICAgICAgIFwicGFnZXMvaW5kZXhcIixcclxuICAgICAgICAgIFwicGFnZXMvc2hhcmVcIixcclxuICAgICAgICAgIFwicGFnZXMvc2lnblwiLFxyXG4gICAgICAgIF1cclxuICAgICAgfV0sXHJcbiAgICAgIHdpbmRvdzoge1xyXG4gICAgICAgIGJhY2tncm91bmRUZXh0U3R5bGU6IFwiZGFya1wiLFxyXG4gICAgICAgIG5hdmlnYXRpb25CYXJCYWNrZ3JvdW5kQ29sb3I6IFwiI0Y0RDAwMFwiLFxyXG4gICAgICAgIGJhY2tncm91bmRDb2xvcjogXCIjZmZmXCIsXHJcbiAgICAgICAgbmF2aWdhdGlvbkJhclRpdGxlVGV4dDogXCJcIixcclxuICAgICAgICBuYXZpZ2F0aW9uQmFyVGV4dFN0eWxlOiBcIndoaXRlXCJcclxuICAgICAgfSxcclxuICAgICAgbmF2aWdhdGVUb01pbmlQcm9ncmFtQXBwSWRMaXN0OiBbXSxcclxuICAgICAgcGVybWlzc2lvbjoge1xyXG4gICAgICAgIFwic2NvcGUudXNlckxvY2F0aW9uXCI6IHtcclxuICAgICAgICAgIGRlc2M6IFwi5L2g55qE5L2N572u5L+h5oGv5bCG55So5LqO5bCP56iL5bqP5L2N572u55qE5pWI5p6c5bGV56S6XCJcclxuICAgICAgICB9XHJcbiAgICAgIH0sXHJcbiAgICAgIFwidGFiQmFyXCI6IHtcclxuICAgICAgICBcImNvbG9yXCI6IFwiI2E5YjdiN1wiLFxyXG4gICAgICAgIFwic2VsZWN0ZWRDb2xvclwiOiBcIiNGNEQwMDBcIixcclxuICAgICAgICBcImJvcmRlclN0eWxlXCI6IFwiYmxhY2tcIixcclxuICAgICAgICBcImxpc3RcIjogW3tcclxuICAgICAgICAgICAgXCJzZWxlY3RlZEljb25QYXRoXCI6IFwic3RhdGljL2ltYWdlcy9pY29uX2NvbnN1bHRfcHJlc3MucG5nXCIsXHJcbiAgICAgICAgICAgIFwiaWNvblBhdGhcIjogXCJzdGF0aWMvaW1hZ2VzL2ljb25fY29uc3VsdC5wbmdcIixcclxuICAgICAgICAgICAgXCJwYWdlUGF0aFwiOiBcInBhZ2VzL2hvbWUvaW5kZXhcIixcclxuICAgICAgICAgICAgXCJ0ZXh0XCI6IFwi6aaW6aG1XCJcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIFwic2VsZWN0ZWRJY29uUGF0aFwiOiBcInN0YXRpYy9pbWFnZXMvaWNvbl9pbnZlc3RfcHJlc3MucG5nXCIsXHJcbiAgICAgICAgICAgIFwiaWNvblBhdGhcIjogXCJzdGF0aWMvaW1hZ2VzL2ljb25faW52ZXN0LnBuZ1wiLFxyXG4gICAgICAgICAgICBcInBhZ2VQYXRoXCI6IFwicGFnZXMvbWVldC9tZWV0XCIsXHJcbiAgICAgICAgICAgIFwidGV4dFwiOiBcIuS6kuWKqFwiXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBcInNlbGVjdGVkSWNvblBhdGhcIjogXCJzdGF0aWMvaW1hZ2VzL2ljb25fbWluZV9wcmVzcy5wbmdcIixcclxuICAgICAgICAgICAgXCJpY29uUGF0aFwiOiBcInN0YXRpYy9pbWFnZXMvaWNvbl9taW5lLnBuZ1wiLFxyXG4gICAgICAgICAgICBcInBhZ2VQYXRoXCI6IFwicGFnZXMvbXkvbXlcIixcclxuICAgICAgICAgICAgXCJ0ZXh0XCI6IFwi5oiR55qEXCJcclxuICAgICAgICAgIH1cclxuICAgICAgICBdXHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgfVxyXG4iXX0=