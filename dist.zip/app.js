"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

require('./npm/wepy-async-function/index.js');

var _WxUtils = require('./utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

var _wepyRedux = require('./npm/wepy-redux/lib/index.js');

var _store = require('./store/index.js');

var _store2 = _interopRequireDefault(_store);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var store = (0, _store2.default)();
(0, _wepyRedux.setStore)(store);

var _default = function (_wepy$app) {
  _inherits(_default, _wepy$app);

  function _default() {
    _classCallCheck(this, _default);

    // 注册中间件
    var _this = _possibleConstructorReturn(this, (_default.__proto__ || Object.getPrototypeOf(_default)).call(this));

    _this.globalData = {
      auth: {},
      scene: null,
      base_store_id: "",
      appCode: "",
      // baseUrl: "https://wechat.hxqxly.com",
      baseUrl: "https://test.hxqxly.com",
      themeColor: "#F4D000",
      cityCode: "",
      code: "",
      sessionId: "",
      courseInfo: {},
      orderInfo: {},
      childs: [],
      help: true,
      query: {}
    };
    _this.config = {
      pages: ["pages/home/index", "pages/home/auth", "pages/home/search", "pages/home/web", "pages/home/share", "pages/meet/meet", "pages/my/my", "pages/my/orders", "pages/my/order", "pages/my/pintuan", "pages/my/bargaining", "pages/home/address", "pages/detaile/detaile", "pages/detaile/sureOrder", "pages/detaile/partners", "pages/meet/childs", "pages/meet/addChild", "pages/meet/addMan", "pages/meet/remarks", "pages/meet/commiRemarke", "pages/activity/bargain", "pages/activity/pintuan"],
      subPackages: [{
        root: "agent",
        pages: ["pages/index", "pages/share", "pages/sign", "pages/buyVip", "pages/my", "pages/orders", "pages/fans"]
      }, {
        root: "actPages",
        pages: ["pages/answer", "pages/answerAct", "pages/index", "pages/rank"]
      }, {
        root: "coupons",
        pages: ["pages/cangets", "pages/myCoupons"]
      }, {
        root: "video",
        pages: ["pages/page"]
      }, {
        root: "crowdfund",
        pages: ["pages/page", "pages/sureOrder"]
      }],
      window: {
        backgroundTextStyle: "dark",
        navigationBarBackgroundColor: "#F4D000",
        backgroundColor: "#fff",
        navigationBarTitleText: "",
        navigationBarTextStyle: "white"
      },
      navigateToMiniProgramAppIdList: [],
      permission: {
        "scope.userLocation": {
          desc: "你的位置信息将用于小程序位置的效果展示"
        }
      },
      tabBar: {
        color: "#a9b7b7",
        selectedColor: "#F4D000",
        borderStyle: "black",
        list: [{
          selectedIconPath: "static/images/icon_consult_press.png",
          iconPath: "static/images/icon_consult.png",
          pagePath: "pages/home/index",
          text: "首页"
        }, {
          selectedIconPath: "static/images/icon_invest_press.png",
          iconPath: "static/images/icon_invest.png",
          pagePath: "pages/meet/meet",
          text: "互动"
        }, {
          selectedIconPath: "static/images/icon_mine_press.png",
          iconPath: "static/images/icon_mine.png",
          pagePath: "pages/my/my",
          text: "我的"
        }]
      }
    };
    _this.use("requestfix");
    _this.use("promisify");
    return _this;
  }

  _createClass(_default, [{
    key: "onLaunch",
    value: function () {
      var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(param) {
        var updateManager, ext;
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                // 获取当前小程序
                try {
                  _wepy2.default.$instance.globalData.appCode = wx.getAccountInfoSync().miniProgram.appId;
                } catch (res) {
                  if (wx.canIUse("getAccountInfoSync")) {
                    _wepy2.default.$instance.globalData.appCode = wx.getAccountInfoSync().miniProgram.appId;
                  } else {
                    // 如果希望用户在最新版本的客户端上体验您的小程序，可以这样子提示
                    wx.showModal({
                      title: "提示",
                      content: "当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。"
                    });
                  }
                }
                updateManager = wx.getUpdateManager();

                updateManager.onCheckForUpdate(function (res) {
                  // 请求完新版本信息的回调
                  console.log(res.hasUpdate);
                });
                updateManager.onUpdateReady(function () {
                  wx.showModal({
                    title: "更新提示",
                    content: "新版本已经准备好，是否重启应用？",
                    success: function success(res) {
                      if (res.confirm) {
                        // 新的版本已经下载好，调用 applyUpdate 应用新版本并重启
                        updateManager.applyUpdate();
                      }
                    }
                  });
                });
                updateManager.onUpdateFailed(function () {
                  // 新的版本下载失败
                  wx.showModal({
                    title: "更新提示",
                    content: "新版本下载失败",
                    showCancel: false
                  });
                });
                // 校验SDK
                _WxUtils2.default.checkSDK();
                // 同步开放平台EXT数据
                ext = _wepy2.default.getExtConfigSync();
                // console.info("[ext] init ext data", ext);

                if (ext.globalConfig) {
                  // console.info("[ext] init ext global config data", ext.globalConfig);
                  Object.assign(ext, ext.globalConfig);
                }
                Object.assign(_wepy2.default.$instance.globalData, ext);
                // auth.login();

              case 9:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function onLaunch(_x) {
        return _ref.apply(this, arguments);
      }

      return onLaunch;
    }()
  }, {
    key: "onShow",
    value: function onShow(param) {
      console.log(param);
      // 获取保存场景值
      if (param && param.scene) {
        _wepy2.default.$instance.globalData.scene = param.scene;
        console.log();
        if (param.query.scene) {
          _wepy2.default.$instance.globalData.query = this.getCodeBy1047(param.query.scene);
        } else if (param.query.agentId) {
          _wepy2.default.$instance.globalData.query["agentId"] = param.query.agentId;
        }
      }
    }
  }, {
    key: "getCodeBy1047",
    value: function getCodeBy1047(str) {
      var query = {},
          strs = decodeURIComponent(str).split("&");

      for (var i = 0, len = strs.length; i < len; i++) {
        query[strs[i].split("=")[0]] = strs[i].split("=")[1];
      }
      return query;
    }
  }, {
    key: "syncStoreConfig",
    value: function syncStoreConfig(key) {
      try {
        var value = _wepy2.default.getStorageSync(key);
        if (value !== "") {
          // console.info(`[auth]${key} sync success `);
          _wepy2.default.$instance.globalData.auth[key] = value;
        }
      } catch (e) {
        // console.warn(`[auth]${key} sync fail `);
      }
    }
  }, {
    key: "onShareAppMessage",
    value: function onShareAppMessage(res) {
      if (res.from === "button") {
        // 来自页面内转发按钮
        console.log(res.target);
      }
      return {
        title: "自定义转发标题",
        path: "/pages/home/index"
      };
    }
  }]);

  return _default;
}(_wepy2.default.app);


App(require('./npm/wepy/lib/wepy.js').default.$createApp(_default, {"noPromiseAPI":["createSelectorQuery"]}));
require('./_wepylogs.js')

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC5qcyJdLCJuYW1lcyI6WyJzdG9yZSIsImdsb2JhbERhdGEiLCJhdXRoIiwic2NlbmUiLCJiYXNlX3N0b3JlX2lkIiwiYXBwQ29kZSIsImJhc2VVcmwiLCJ0aGVtZUNvbG9yIiwiY2l0eUNvZGUiLCJjb2RlIiwic2Vzc2lvbklkIiwiY291cnNlSW5mbyIsIm9yZGVySW5mbyIsImNoaWxkcyIsImhlbHAiLCJxdWVyeSIsImNvbmZpZyIsInBhZ2VzIiwic3ViUGFja2FnZXMiLCJyb290Iiwid2luZG93IiwiYmFja2dyb3VuZFRleHRTdHlsZSIsIm5hdmlnYXRpb25CYXJCYWNrZ3JvdW5kQ29sb3IiLCJiYWNrZ3JvdW5kQ29sb3IiLCJuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0IiwibmF2aWdhdGlvbkJhclRleHRTdHlsZSIsIm5hdmlnYXRlVG9NaW5pUHJvZ3JhbUFwcElkTGlzdCIsInBlcm1pc3Npb24iLCJkZXNjIiwidGFiQmFyIiwiY29sb3IiLCJzZWxlY3RlZENvbG9yIiwiYm9yZGVyU3R5bGUiLCJsaXN0Iiwic2VsZWN0ZWRJY29uUGF0aCIsImljb25QYXRoIiwicGFnZVBhdGgiLCJ0ZXh0IiwidXNlIiwicGFyYW0iLCJ3ZXB5IiwiJGluc3RhbmNlIiwid3giLCJnZXRBY2NvdW50SW5mb1N5bmMiLCJtaW5pUHJvZ3JhbSIsImFwcElkIiwicmVzIiwiY2FuSVVzZSIsInNob3dNb2RhbCIsInRpdGxlIiwiY29udGVudCIsInVwZGF0ZU1hbmFnZXIiLCJnZXRVcGRhdGVNYW5hZ2VyIiwib25DaGVja0ZvclVwZGF0ZSIsImNvbnNvbGUiLCJsb2ciLCJoYXNVcGRhdGUiLCJvblVwZGF0ZVJlYWR5Iiwic3VjY2VzcyIsImNvbmZpcm0iLCJhcHBseVVwZGF0ZSIsIm9uVXBkYXRlRmFpbGVkIiwic2hvd0NhbmNlbCIsIld4VXRpbHMiLCJjaGVja1NESyIsImV4dCIsImdldEV4dENvbmZpZ1N5bmMiLCJnbG9iYWxDb25maWciLCJPYmplY3QiLCJhc3NpZ24iLCJnZXRDb2RlQnkxMDQ3IiwiYWdlbnRJZCIsInN0ciIsInN0cnMiLCJkZWNvZGVVUklDb21wb25lbnQiLCJzcGxpdCIsImkiLCJsZW4iLCJsZW5ndGgiLCJrZXkiLCJ2YWx1ZSIsImdldFN0b3JhZ2VTeW5jIiwiZSIsImZyb20iLCJ0YXJnZXQiLCJwYXRoIiwiYXBwIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFDRTs7OztBQUNBOztBQUNBOzs7O0FBQ0E7O0FBR0E7Ozs7Ozs7Ozs7Ozs7O0FBQ0EsSUFBTUEsUUFBUSxzQkFBZDtBQUNBLHlCQUFTQSxLQUFUOzs7OztBQW1CRSxzQkFBYztBQUFBOztBQUVaO0FBRlk7O0FBQUEsVUFqQmRDLFVBaUJjLEdBakJEO0FBQ1hDLFlBQU0sRUFESztBQUVYQyxhQUFPLElBRkk7QUFHWEMscUJBQWUsRUFISjtBQUlYQyxlQUFTLEVBSkU7QUFLWDtBQUNBQyxlQUFTLHlCQU5FO0FBT1hDLGtCQUFZLFNBUEQ7QUFRWEMsZ0JBQVUsRUFSQztBQVNYQyxZQUFNLEVBVEs7QUFVWEMsaUJBQVcsRUFWQTtBQVdYQyxrQkFBWSxFQVhEO0FBWVhDLGlCQUFXLEVBWkE7QUFhWEMsY0FBUSxFQWJHO0FBY1hDLFlBQU0sSUFkSztBQWVYQyxhQUFPO0FBZkksS0FpQkM7QUFBQSxVQXFHZEMsTUFyR2MsR0FxR0w7QUFDUEMsYUFBTyxDQUNMLGtCQURLLEVBRUwsaUJBRkssRUFHTCxtQkFISyxFQUlMLGdCQUpLLEVBS0wsa0JBTEssRUFNTCxpQkFOSyxFQU9MLGFBUEssRUFRTCxpQkFSSyxFQVNMLGdCQVRLLEVBVUwsa0JBVkssRUFXTCxxQkFYSyxFQVlMLG9CQVpLLEVBYUwsdUJBYkssRUFjTCx5QkFkSyxFQWVMLHdCQWZLLEVBZ0JMLG1CQWhCSyxFQWlCTCxxQkFqQkssRUFrQkwsbUJBbEJLLEVBbUJMLG9CQW5CSyxFQW9CTCx5QkFwQkssRUFxQkwsd0JBckJLLEVBc0JMLHdCQXRCSyxDQURBO0FBeUJQQyxtQkFBYSxDQUFDO0FBQ1ZDLGNBQU0sT0FESTtBQUVWRixlQUFPLENBQUMsYUFBRCxFQUFnQixhQUFoQixFQUErQixZQUEvQixFQUE2QyxjQUE3QyxFQUE2RCxVQUE3RCxFQUF5RSxjQUF6RSxFQUF5RixZQUF6RjtBQUZHLE9BQUQsRUFJWDtBQUNFRSxjQUFNLFVBRFI7QUFFRUYsZUFBTyxDQUFDLGNBQUQsRUFBaUIsaUJBQWpCLEVBQW9DLGFBQXBDLEVBQW1ELFlBQW5EO0FBRlQsT0FKVyxFQVFYO0FBQ0VFLGNBQU0sU0FEUjtBQUVFRixlQUFPLENBQUMsZUFBRCxFQUFpQixpQkFBakI7QUFGVCxPQVJXLEVBWVg7QUFDRUUsY0FBTSxPQURSO0FBRUVGLGVBQU8sQ0FBQyxZQUFEO0FBRlQsT0FaVyxFQWdCWDtBQUNFRSxjQUFNLFdBRFI7QUFFRUYsZUFBTyxDQUFDLFlBQUQsRUFBYyxpQkFBZDtBQUZULE9BaEJXLENBekJOO0FBK0NQRyxjQUFRO0FBQ05DLDZCQUFxQixNQURmO0FBRU5DLHNDQUE4QixTQUZ4QjtBQUdOQyx5QkFBaUIsTUFIWDtBQUlOQyxnQ0FBd0IsRUFKbEI7QUFLTkMsZ0NBQXdCO0FBTGxCLE9BL0NEO0FBc0RQQyxzQ0FBZ0MsRUF0RHpCO0FBdURQQyxrQkFBWTtBQUNWLDhCQUFzQjtBQUNwQkMsZ0JBQU07QUFEYztBQURaLE9BdkRMO0FBNERQQyxjQUFRO0FBQ05DLGVBQU8sU0FERDtBQUVOQyx1QkFBZSxTQUZUO0FBR05DLHFCQUFhLE9BSFA7QUFJTkMsY0FBTSxDQUFDO0FBQ0hDLDRCQUFrQixzQ0FEZjtBQUVIQyxvQkFBVSxnQ0FGUDtBQUdIQyxvQkFBVSxrQkFIUDtBQUlIQyxnQkFBTTtBQUpILFNBQUQsRUFNSjtBQUNFSCw0QkFBa0IscUNBRHBCO0FBRUVDLG9CQUFVLCtCQUZaO0FBR0VDLG9CQUFVLGlCQUhaO0FBSUVDLGdCQUFNO0FBSlIsU0FOSSxFQVlKO0FBQ0VILDRCQUFrQixtQ0FEcEI7QUFFRUMsb0JBQVUsNkJBRlo7QUFHRUMsb0JBQVUsYUFIWjtBQUlFQyxnQkFBTTtBQUpSLFNBWkk7QUFKQTtBQTVERCxLQXJHSztBQUdaLFVBQUtDLEdBQUwsQ0FBUyxZQUFUO0FBQ0EsVUFBS0EsR0FBTCxDQUFTLFdBQVQ7QUFKWTtBQUtiOzs7OzswRkFDY0MsSzs7Ozs7O0FBQ2I7QUFDQSxvQkFBSTtBQUNGQyxpQ0FBS0MsU0FBTCxDQUFleEMsVUFBZixDQUEwQkksT0FBMUIsR0FBb0NxQyxHQUFHQyxrQkFBSCxHQUF3QkMsV0FBeEIsQ0FBb0NDLEtBQXhFO0FBQ0QsaUJBRkQsQ0FFRSxPQUFPQyxHQUFQLEVBQVk7QUFDWixzQkFBSUosR0FBR0ssT0FBSCxDQUFXLG9CQUFYLENBQUosRUFBc0M7QUFDcENQLG1DQUFLQyxTQUFMLENBQWV4QyxVQUFmLENBQTBCSSxPQUExQixHQUFvQ3FDLEdBQUdDLGtCQUFILEdBQXdCQyxXQUF4QixDQUFvQ0MsS0FBeEU7QUFDRCxtQkFGRCxNQUVPO0FBQ0w7QUFDQUgsdUJBQUdNLFNBQUgsQ0FBYTtBQUNYQyw2QkFBTyxJQURJO0FBRVhDLCtCQUFTO0FBRkUscUJBQWI7QUFJRDtBQUNGO0FBQ0tDLDZCLEdBQWdCVCxHQUFHVSxnQkFBSCxFOztBQUN0QkQsOEJBQWNFLGdCQUFkLENBQStCLFVBQVNQLEdBQVQsRUFBYztBQUMzQztBQUNBUSwwQkFBUUMsR0FBUixDQUFZVCxJQUFJVSxTQUFoQjtBQUNELGlCQUhEO0FBSUFMLDhCQUFjTSxhQUFkLENBQTRCLFlBQVc7QUFDckNmLHFCQUFHTSxTQUFILENBQWE7QUFDWEMsMkJBQU8sTUFESTtBQUVYQyw2QkFBUyxrQkFGRTtBQUdYUSw2QkFBUyxpQkFBU1osR0FBVCxFQUFjO0FBQ3JCLDBCQUFJQSxJQUFJYSxPQUFSLEVBQWlCO0FBQ2Y7QUFDQVIsc0NBQWNTLFdBQWQ7QUFDRDtBQUNGO0FBUlUsbUJBQWI7QUFVRCxpQkFYRDtBQVlBVCw4QkFBY1UsY0FBZCxDQUE2QixZQUFXO0FBQ3RDO0FBQ0FuQixxQkFBR00sU0FBSCxDQUFhO0FBQ1hDLDJCQUFPLE1BREk7QUFFWEMsNkJBQVMsU0FGRTtBQUdYWSxnQ0FBWTtBQUhELG1CQUFiO0FBS0QsaUJBUEQ7QUFRQTtBQUNBQyxrQ0FBUUMsUUFBUjtBQUNBO0FBQ01DLG1CLEdBQU16QixlQUFLMEIsZ0JBQUwsRTtBQUNaOztBQUNBLG9CQUFJRCxJQUFJRSxZQUFSLEVBQXNCO0FBQ3BCO0FBQ0FDLHlCQUFPQyxNQUFQLENBQWNKLEdBQWQsRUFBbUJBLElBQUlFLFlBQXZCO0FBQ0Q7QUFDREMsdUJBQU9DLE1BQVAsQ0FBYzdCLGVBQUtDLFNBQUwsQ0FBZXhDLFVBQTdCLEVBQXlDZ0UsR0FBekM7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7OzJCQUVLMUIsSyxFQUFPO0FBQ1plLGNBQVFDLEdBQVIsQ0FBWWhCLEtBQVo7QUFDQTtBQUNBLFVBQUlBLFNBQVNBLE1BQU1wQyxLQUFuQixFQUEwQjtBQUN4QnFDLHVCQUFLQyxTQUFMLENBQWV4QyxVQUFmLENBQTBCRSxLQUExQixHQUFrQ29DLE1BQU1wQyxLQUF4QztBQUNBbUQsZ0JBQVFDLEdBQVI7QUFDQSxZQUFJaEIsTUFBTXhCLEtBQU4sQ0FBWVosS0FBaEIsRUFBdUI7QUFDckJxQyx5QkFBS0MsU0FBTCxDQUFleEMsVUFBZixDQUEwQmMsS0FBMUIsR0FBa0MsS0FBS3VELGFBQUwsQ0FBbUIvQixNQUFNeEIsS0FBTixDQUFZWixLQUEvQixDQUFsQztBQUNELFNBRkQsTUFFTyxJQUFJb0MsTUFBTXhCLEtBQU4sQ0FBWXdELE9BQWhCLEVBQXlCO0FBQzlCL0IseUJBQUtDLFNBQUwsQ0FBZXhDLFVBQWYsQ0FBMEJjLEtBQTFCLENBQWdDLFNBQWhDLElBQTZDd0IsTUFBTXhCLEtBQU4sQ0FBWXdELE9BQXpEO0FBQ0Q7QUFDRjtBQUNGOzs7a0NBQ2FDLEcsRUFBSztBQUNqQixVQUFJekQsUUFBUSxFQUFaO0FBQUEsVUFDRTBELE9BQU9DLG1CQUFtQkYsR0FBbkIsRUFBd0JHLEtBQXhCLENBQThCLEdBQTlCLENBRFQ7O0FBR0EsV0FBSyxJQUFJQyxJQUFJLENBQVIsRUFBV0MsTUFBTUosS0FBS0ssTUFBM0IsRUFBbUNGLElBQUlDLEdBQXZDLEVBQTRDRCxHQUE1QyxFQUFpRDtBQUMvQzdELGNBQU0wRCxLQUFLRyxDQUFMLEVBQVFELEtBQVIsQ0FBYyxHQUFkLEVBQW1CLENBQW5CLENBQU4sSUFBK0JGLEtBQUtHLENBQUwsRUFBUUQsS0FBUixDQUFjLEdBQWQsRUFBbUIsQ0FBbkIsQ0FBL0I7QUFDRDtBQUNELGFBQU81RCxLQUFQO0FBQ0Q7OztvQ0FDZWdFLEcsRUFBSztBQUNuQixVQUFJO0FBQ0YsWUFBTUMsUUFBUXhDLGVBQUt5QyxjQUFMLENBQW9CRixHQUFwQixDQUFkO0FBQ0EsWUFBSUMsVUFBVSxFQUFkLEVBQWtCO0FBQ2hCO0FBQ0F4Qyx5QkFBS0MsU0FBTCxDQUFleEMsVUFBZixDQUEwQkMsSUFBMUIsQ0FBK0I2RSxHQUEvQixJQUFzQ0MsS0FBdEM7QUFDRDtBQUNGLE9BTkQsQ0FNRSxPQUFPRSxDQUFQLEVBQVU7QUFDVjtBQUNEO0FBQ0Y7OztzQ0FDaUJwQyxHLEVBQUs7QUFDckIsVUFBSUEsSUFBSXFDLElBQUosS0FBYSxRQUFqQixFQUEyQjtBQUN6QjtBQUNBN0IsZ0JBQVFDLEdBQVIsQ0FBWVQsSUFBSXNDLE1BQWhCO0FBQ0Q7QUFDRCxhQUFPO0FBQ0xuQyxlQUFPLFNBREY7QUFFTG9DLGNBQU07QUFGRCxPQUFQO0FBSUQ7Ozs7RUF0SDBCN0MsZUFBSzhDLEciLCJmaWxlIjoiYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbiAgaW1wb3J0IHdlcHkgZnJvbSBcIndlcHlcIjtcclxuICBpbXBvcnQgXCJ3ZXB5LWFzeW5jLWZ1bmN0aW9uXCI7XHJcbiAgaW1wb3J0IFd4VXRpbHMgZnJvbSBcIi4vdXRpbHMvV3hVdGlsc1wiO1xyXG4gIGltcG9ydCB7XHJcbiAgICBzZXRTdG9yZVxyXG4gIH0gZnJvbSBcIndlcHktcmVkdXhcIjtcclxuICBpbXBvcnQgY29uZmlnU3RvcmUgZnJvbSBcIi4vc3RvcmVcIjtcclxuICBjb25zdCBzdG9yZSA9IGNvbmZpZ1N0b3JlKCk7XHJcbiAgc2V0U3RvcmUoc3RvcmUpO1xyXG4gIGV4cG9ydCBkZWZhdWx0IGNsYXNzIGV4dGVuZHMgd2VweS5hcHAge1xyXG4gICAgZ2xvYmFsRGF0YSA9IHtcclxuICAgICAgYXV0aDoge30sXHJcbiAgICAgIHNjZW5lOiBudWxsLFxyXG4gICAgICBiYXNlX3N0b3JlX2lkOiBcIlwiLFxyXG4gICAgICBhcHBDb2RlOiBcIlwiLFxyXG4gICAgICAvLyBiYXNlVXJsOiBcImh0dHBzOi8vd2VjaGF0Lmh4cXhseS5jb21cIixcclxuICAgICAgYmFzZVVybDogXCJodHRwczovL3Rlc3QuaHhxeGx5LmNvbVwiLFxyXG4gICAgICB0aGVtZUNvbG9yOiBcIiNGNEQwMDBcIixcclxuICAgICAgY2l0eUNvZGU6IFwiXCIsXHJcbiAgICAgIGNvZGU6IFwiXCIsXHJcbiAgICAgIHNlc3Npb25JZDogXCJcIixcclxuICAgICAgY291cnNlSW5mbzoge30sXHJcbiAgICAgIG9yZGVySW5mbzoge30sXHJcbiAgICAgIGNoaWxkczogW10sXHJcbiAgICAgIGhlbHA6IHRydWUsXHJcbiAgICAgIHF1ZXJ5OiB7fVxyXG4gICAgfTtcclxuICAgIGNvbnN0cnVjdG9yKCkge1xyXG4gICAgICBzdXBlcigpO1xyXG4gICAgICAvLyDms6jlhozkuK3pl7Tku7ZcclxuICAgICAgdGhpcy51c2UoXCJyZXF1ZXN0Zml4XCIpO1xyXG4gICAgICB0aGlzLnVzZShcInByb21pc2lmeVwiKTtcclxuICAgIH1cclxuICAgIGFzeW5jIG9uTGF1bmNoKHBhcmFtKSB7XHJcbiAgICAgIC8vIOiOt+WPluW9k+WJjeWwj+eoi+W6j1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuYXBwQ29kZSA9IHd4LmdldEFjY291bnRJbmZvU3luYygpLm1pbmlQcm9ncmFtLmFwcElkO1xyXG4gICAgICB9IGNhdGNoIChyZXMpIHtcclxuICAgICAgICBpZiAod3guY2FuSVVzZShcImdldEFjY291bnRJbmZvU3luY1wiKSkge1xyXG4gICAgICAgICAgd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5hcHBDb2RlID0gd3guZ2V0QWNjb3VudEluZm9TeW5jKCkubWluaVByb2dyYW0uYXBwSWQ7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIC8vIOWmguaenOW4jOacm+eUqOaIt+WcqOacgOaWsOeJiOacrOeahOWuouaIt+err+S4iuS9k+mqjOaCqOeahOWwj+eoi+W6j++8jOWPr+S7pei/meagt+WtkOaPkOekulxyXG4gICAgICAgICAgd3guc2hvd01vZGFsKHtcclxuICAgICAgICAgICAgdGl0bGU6IFwi5o+Q56S6XCIsXHJcbiAgICAgICAgICAgIGNvbnRlbnQ6IFwi5b2T5YmN5b6u5L+h54mI5pys6L+H5L2O77yM5peg5rOV5L2/55So6K+l5Yqf6IO977yM6K+35Y2H57qn5Yiw5pyA5paw5b6u5L+h54mI5pys5ZCO6YeN6K+V44CCXCJcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgICBjb25zdCB1cGRhdGVNYW5hZ2VyID0gd3guZ2V0VXBkYXRlTWFuYWdlcigpO1xyXG4gICAgICB1cGRhdGVNYW5hZ2VyLm9uQ2hlY2tGb3JVcGRhdGUoZnVuY3Rpb24ocmVzKSB7XHJcbiAgICAgICAgLy8g6K+35rGC5a6M5paw54mI5pys5L+h5oGv55qE5Zue6LCDXHJcbiAgICAgICAgY29uc29sZS5sb2cocmVzLmhhc1VwZGF0ZSk7XHJcbiAgICAgIH0pO1xyXG4gICAgICB1cGRhdGVNYW5hZ2VyLm9uVXBkYXRlUmVhZHkoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgd3guc2hvd01vZGFsKHtcclxuICAgICAgICAgIHRpdGxlOiBcIuabtOaWsOaPkOekulwiLFxyXG4gICAgICAgICAgY29udGVudDogXCLmlrDniYjmnKzlt7Lnu4/lh4blpIflpb3vvIzmmK/lkKbph43lkK/lupTnlKjvvJ9cIixcclxuICAgICAgICAgIHN1Y2Nlc3M6IGZ1bmN0aW9uKHJlcykge1xyXG4gICAgICAgICAgICBpZiAocmVzLmNvbmZpcm0pIHtcclxuICAgICAgICAgICAgICAvLyDmlrDnmoTniYjmnKzlt7Lnu4/kuIvovb3lpb3vvIzosIPnlKggYXBwbHlVcGRhdGUg5bqU55So5paw54mI5pys5bm26YeN5ZCvXHJcbiAgICAgICAgICAgICAgdXBkYXRlTWFuYWdlci5hcHBseVVwZGF0ZSgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0pO1xyXG4gICAgICB1cGRhdGVNYW5hZ2VyLm9uVXBkYXRlRmFpbGVkKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgIC8vIOaWsOeahOeJiOacrOS4i+i9veWksei0pVxyXG4gICAgICAgIHd4LnNob3dNb2RhbCh7XHJcbiAgICAgICAgICB0aXRsZTogXCLmm7TmlrDmj5DnpLpcIixcclxuICAgICAgICAgIGNvbnRlbnQ6IFwi5paw54mI5pys5LiL6L295aSx6LSlXCIsXHJcbiAgICAgICAgICBzaG93Q2FuY2VsOiBmYWxzZVxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9KTtcclxuICAgICAgLy8g5qCh6aqMU0RLXHJcbiAgICAgIFd4VXRpbHMuY2hlY2tTREsoKTtcclxuICAgICAgLy8g5ZCM5q2l5byA5pS+5bmz5Y+wRVhU5pWw5o2uXHJcbiAgICAgIGNvbnN0IGV4dCA9IHdlcHkuZ2V0RXh0Q29uZmlnU3luYygpO1xyXG4gICAgICAvLyBjb25zb2xlLmluZm8oXCJbZXh0XSBpbml0IGV4dCBkYXRhXCIsIGV4dCk7XHJcbiAgICAgIGlmIChleHQuZ2xvYmFsQ29uZmlnKSB7XHJcbiAgICAgICAgLy8gY29uc29sZS5pbmZvKFwiW2V4dF0gaW5pdCBleHQgZ2xvYmFsIGNvbmZpZyBkYXRhXCIsIGV4dC5nbG9iYWxDb25maWcpO1xyXG4gICAgICAgIE9iamVjdC5hc3NpZ24oZXh0LCBleHQuZ2xvYmFsQ29uZmlnKTtcclxuICAgICAgfVxyXG4gICAgICBPYmplY3QuYXNzaWduKHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEsIGV4dCk7XHJcbiAgICAgIC8vIGF1dGgubG9naW4oKTtcclxuICAgIH1cclxuICAgIG9uU2hvdyhwYXJhbSkge1xyXG4gICAgICBjb25zb2xlLmxvZyhwYXJhbSk7XHJcbiAgICAgIC8vIOiOt+WPluS/neWtmOWcuuaZr+WAvFxyXG4gICAgICBpZiAocGFyYW0gJiYgcGFyYW0uc2NlbmUpIHtcclxuICAgICAgICB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnNjZW5lID0gcGFyYW0uc2NlbmU7XHJcbiAgICAgICAgY29uc29sZS5sb2coKTtcclxuICAgICAgICBpZiAocGFyYW0ucXVlcnkuc2NlbmUpIHtcclxuICAgICAgICAgIHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEucXVlcnkgPSB0aGlzLmdldENvZGVCeTEwNDcocGFyYW0ucXVlcnkuc2NlbmUpO1xyXG4gICAgICAgIH0gZWxzZSBpZiAocGFyYW0ucXVlcnkuYWdlbnRJZCkge1xyXG4gICAgICAgICAgd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5xdWVyeVtcImFnZW50SWRcIl0gPSBwYXJhbS5xdWVyeS5hZ2VudElkO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgZ2V0Q29kZUJ5MTA0NyhzdHIpIHtcclxuICAgICAgdmFyIHF1ZXJ5ID0ge30sXHJcbiAgICAgICAgc3RycyA9IGRlY29kZVVSSUNvbXBvbmVudChzdHIpLnNwbGl0KFwiJlwiKTtcclxuXHJcbiAgICAgIGZvciAodmFyIGkgPSAwLCBsZW4gPSBzdHJzLmxlbmd0aDsgaSA8IGxlbjsgaSsrKSB7XHJcbiAgICAgICAgcXVlcnlbc3Ryc1tpXS5zcGxpdChcIj1cIilbMF1dID0gc3Ryc1tpXS5zcGxpdChcIj1cIilbMV07XHJcbiAgICAgIH1cclxuICAgICAgcmV0dXJuIHF1ZXJ5O1xyXG4gICAgfVxyXG4gICAgc3luY1N0b3JlQ29uZmlnKGtleSkge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHZhbHVlID0gd2VweS5nZXRTdG9yYWdlU3luYyhrZXkpO1xyXG4gICAgICAgIGlmICh2YWx1ZSAhPT0gXCJcIikge1xyXG4gICAgICAgICAgLy8gY29uc29sZS5pbmZvKGBbYXV0aF0ke2tleX0gc3luYyBzdWNjZXNzIGApO1xyXG4gICAgICAgICAgd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5hdXRoW2tleV0gPSB2YWx1ZTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAvLyBjb25zb2xlLndhcm4oYFthdXRoXSR7a2V5fSBzeW5jIGZhaWwgYCk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIG9uU2hhcmVBcHBNZXNzYWdlKHJlcykge1xyXG4gICAgICBpZiAocmVzLmZyb20gPT09IFwiYnV0dG9uXCIpIHtcclxuICAgICAgICAvLyDmnaXoh6rpobXpnaLlhoXovazlj5HmjInpkq5cclxuICAgICAgICBjb25zb2xlLmxvZyhyZXMudGFyZ2V0KTtcclxuICAgICAgfVxyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIHRpdGxlOiBcIuiHquWumuS5iei9rOWPkeagh+mimFwiLFxyXG4gICAgICAgIHBhdGg6IFwiL3BhZ2VzL2hvbWUvaW5kZXhcIlxyXG4gICAgICB9O1xyXG4gICAgfVxyXG4gICAgY29uZmlnID0ge1xyXG4gICAgICBwYWdlczogW1xyXG4gICAgICAgIFwicGFnZXMvaG9tZS9pbmRleFwiLFxyXG4gICAgICAgIFwicGFnZXMvaG9tZS9hdXRoXCIsXHJcbiAgICAgICAgXCJwYWdlcy9ob21lL3NlYXJjaFwiLFxyXG4gICAgICAgIFwicGFnZXMvaG9tZS93ZWJcIixcclxuICAgICAgICBcInBhZ2VzL2hvbWUvc2hhcmVcIixcclxuICAgICAgICBcInBhZ2VzL21lZXQvbWVldFwiLFxyXG4gICAgICAgIFwicGFnZXMvbXkvbXlcIixcclxuICAgICAgICBcInBhZ2VzL215L29yZGVyc1wiLFxyXG4gICAgICAgIFwicGFnZXMvbXkvb3JkZXJcIixcclxuICAgICAgICBcInBhZ2VzL215L3BpbnR1YW5cIixcclxuICAgICAgICBcInBhZ2VzL215L2JhcmdhaW5pbmdcIixcclxuICAgICAgICBcInBhZ2VzL2hvbWUvYWRkcmVzc1wiLFxyXG4gICAgICAgIFwicGFnZXMvZGV0YWlsZS9kZXRhaWxlXCIsXHJcbiAgICAgICAgXCJwYWdlcy9kZXRhaWxlL3N1cmVPcmRlclwiLFxyXG4gICAgICAgIFwicGFnZXMvZGV0YWlsZS9wYXJ0bmVyc1wiLFxyXG4gICAgICAgIFwicGFnZXMvbWVldC9jaGlsZHNcIixcclxuICAgICAgICBcInBhZ2VzL21lZXQvYWRkQ2hpbGRcIixcclxuICAgICAgICBcInBhZ2VzL21lZXQvYWRkTWFuXCIsXHJcbiAgICAgICAgXCJwYWdlcy9tZWV0L3JlbWFya3NcIixcclxuICAgICAgICBcInBhZ2VzL21lZXQvY29tbWlSZW1hcmtlXCIsXHJcbiAgICAgICAgXCJwYWdlcy9hY3Rpdml0eS9iYXJnYWluXCIsXHJcbiAgICAgICAgXCJwYWdlcy9hY3Rpdml0eS9waW50dWFuXCJcclxuICAgICAgXSxcclxuICAgICAgc3ViUGFja2FnZXM6IFt7XHJcbiAgICAgICAgICByb290OiBcImFnZW50XCIsXHJcbiAgICAgICAgICBwYWdlczogW1wicGFnZXMvaW5kZXhcIiwgXCJwYWdlcy9zaGFyZVwiLCBcInBhZ2VzL3NpZ25cIiwgXCJwYWdlcy9idXlWaXBcIiwgXCJwYWdlcy9teVwiLCBcInBhZ2VzL29yZGVyc1wiLCBcInBhZ2VzL2ZhbnNcIl1cclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIHJvb3Q6IFwiYWN0UGFnZXNcIixcclxuICAgICAgICAgIHBhZ2VzOiBbXCJwYWdlcy9hbnN3ZXJcIiwgXCJwYWdlcy9hbnN3ZXJBY3RcIiwgXCJwYWdlcy9pbmRleFwiLCBcInBhZ2VzL3JhbmtcIl1cclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIHJvb3Q6IFwiY291cG9uc1wiLFxyXG4gICAgICAgICAgcGFnZXM6IFtcInBhZ2VzL2NhbmdldHNcIixcInBhZ2VzL215Q291cG9uc1wiXVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgcm9vdDogXCJ2aWRlb1wiLFxyXG4gICAgICAgICAgcGFnZXM6IFtcInBhZ2VzL3BhZ2VcIl1cclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIHJvb3Q6IFwiY3Jvd2RmdW5kXCIsXHJcbiAgICAgICAgICBwYWdlczogW1wicGFnZXMvcGFnZVwiLFwicGFnZXMvc3VyZU9yZGVyXCJdXHJcbiAgICAgICAgfVxuXHJcbiAgICAgIF0sXHJcbiAgICAgIHdpbmRvdzoge1xyXG4gICAgICAgIGJhY2tncm91bmRUZXh0U3R5bGU6IFwiZGFya1wiLFxyXG4gICAgICAgIG5hdmlnYXRpb25CYXJCYWNrZ3JvdW5kQ29sb3I6IFwiI0Y0RDAwMFwiLFxyXG4gICAgICAgIGJhY2tncm91bmRDb2xvcjogXCIjZmZmXCIsXHJcbiAgICAgICAgbmF2aWdhdGlvbkJhclRpdGxlVGV4dDogXCJcIixcclxuICAgICAgICBuYXZpZ2F0aW9uQmFyVGV4dFN0eWxlOiBcIndoaXRlXCJcclxuICAgICAgfSxcclxuICAgICAgbmF2aWdhdGVUb01pbmlQcm9ncmFtQXBwSWRMaXN0OiBbXSxcclxuICAgICAgcGVybWlzc2lvbjoge1xyXG4gICAgICAgIFwic2NvcGUudXNlckxvY2F0aW9uXCI6IHtcclxuICAgICAgICAgIGRlc2M6IFwi5L2g55qE5L2N572u5L+h5oGv5bCG55So5LqO5bCP56iL5bqP5L2N572u55qE5pWI5p6c5bGV56S6XCJcclxuICAgICAgICB9XHJcbiAgICAgIH0sXHJcbiAgICAgIHRhYkJhcjoge1xyXG4gICAgICAgIGNvbG9yOiBcIiNhOWI3YjdcIixcclxuICAgICAgICBzZWxlY3RlZENvbG9yOiBcIiNGNEQwMDBcIixcclxuICAgICAgICBib3JkZXJTdHlsZTogXCJibGFja1wiLFxyXG4gICAgICAgIGxpc3Q6IFt7XHJcbiAgICAgICAgICAgIHNlbGVjdGVkSWNvblBhdGg6IFwic3RhdGljL2ltYWdlcy9pY29uX2NvbnN1bHRfcHJlc3MucG5nXCIsXHJcbiAgICAgICAgICAgIGljb25QYXRoOiBcInN0YXRpYy9pbWFnZXMvaWNvbl9jb25zdWx0LnBuZ1wiLFxyXG4gICAgICAgICAgICBwYWdlUGF0aDogXCJwYWdlcy9ob21lL2luZGV4XCIsXHJcbiAgICAgICAgICAgIHRleHQ6IFwi6aaW6aG1XCJcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIHNlbGVjdGVkSWNvblBhdGg6IFwic3RhdGljL2ltYWdlcy9pY29uX2ludmVzdF9wcmVzcy5wbmdcIixcclxuICAgICAgICAgICAgaWNvblBhdGg6IFwic3RhdGljL2ltYWdlcy9pY29uX2ludmVzdC5wbmdcIixcclxuICAgICAgICAgICAgcGFnZVBhdGg6IFwicGFnZXMvbWVldC9tZWV0XCIsXHJcbiAgICAgICAgICAgIHRleHQ6IFwi5LqS5YqoXCJcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIHNlbGVjdGVkSWNvblBhdGg6IFwic3RhdGljL2ltYWdlcy9pY29uX21pbmVfcHJlc3MucG5nXCIsXHJcbiAgICAgICAgICAgIGljb25QYXRoOiBcInN0YXRpYy9pbWFnZXMvaWNvbl9taW5lLnBuZ1wiLFxyXG4gICAgICAgICAgICBwYWdlUGF0aDogXCJwYWdlcy9teS9teVwiLFxyXG4gICAgICAgICAgICB0ZXh0OiBcIuaIkeeahFwiXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgXVxyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gIH1cclxuIl19