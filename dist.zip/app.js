"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

require('./npm/wepy-async-function/index.js');

var _WxUtils = require('./utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

var _wepyRedux = require('./npm/wepy-redux/lib/index.js');

var _store = require('./store/index.js');

var _store2 = _interopRequireDefault(_store);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var store = (0, _store2.default)();
(0, _wepyRedux.setStore)(store);

var _default = function (_wepy$app) {
  _inherits(_default, _wepy$app);

  function _default() {
    _classCallCheck(this, _default);

    // 注册中间件
    var _this = _possibleConstructorReturn(this, (_default.__proto__ || Object.getPrototypeOf(_default)).call(this));

    _this.globalData = {
      auth: {},
      scene: null,
      base_store_id: "",
      appCode: "",
      // baseUrl: "https://wechat.hxqxly.com",
      baseUrl: "https://test.hxqxly.com",
      themeColor: "#F4D000",
      cityCode: '',
      code: '',
      sessionId: '',
      courseInfo: {},
      orderInfo: {},
      childs: [],
      help: true,
      query: {}
    };
    _this.config = {
      pages: ["pages/home/index", "pages/home/search", "pages/home/web", "pages/home/share", "pages/meet/meet", "pages/my/my", "pages/my/orders", "pages/my/order", "pages/my/pintuan", "pages/my/bargaining", "pages/home/address", "pages/detaile/detaile", "pages/detaile/sureOrder", "pages/detaile/partners", "pages/meet/childs", "pages/meet/addChild", "pages/meet/addMan", "pages/meet/remarks", "pages/meet/commiRemarke", "pages/activity/bargain", "pages/activity/pintuan"],
      subPackages: [{
        root: "agent",
        pages: ["pages/index", "pages/share", "pages/sign"]
      }],
      window: {
        backgroundTextStyle: "dark",
        navigationBarBackgroundColor: "#F4D000",
        backgroundColor: "#fff",
        navigationBarTitleText: "",
        navigationBarTextStyle: "white"
      },
      navigateToMiniProgramAppIdList: [],
      permission: {
        "scope.userLocation": {
          desc: "你的位置信息将用于小程序位置的效果展示"
        }
      },
      "tabBar": {
        "color": "#a9b7b7",
        "selectedColor": "#F4D000",
        "borderStyle": "black",
        "list": [{
          "selectedIconPath": "static/images/icon_consult_press.png",
          "iconPath": "static/images/icon_consult.png",
          "pagePath": "pages/home/index",
          "text": "首页"
        }, {
          "selectedIconPath": "static/images/icon_invest_press.png",
          "iconPath": "static/images/icon_invest.png",
          "pagePath": "pages/meet/meet",
          "text": "互动"
        }, {
          "selectedIconPath": "static/images/icon_mine_press.png",
          "iconPath": "static/images/icon_mine.png",
          "pagePath": "pages/my/my",
          "text": "我的"
        }]
      }
    };
    _this.use("requestfix");
    _this.use("promisify");
    return _this;
  }

  _createClass(_default, [{
    key: "onLaunch",
    value: function () {
      var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(param) {
        var updateManager, ext;
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                // 获取当前小程序
                try {
                  _wepy2.default.$instance.globalData.appCode = wx.getAccountInfoSync().miniProgram.appId;
                } catch (res) {
                  if (wx.canIUse("getAccountInfoSync")) {
                    _wepy2.default.$instance.globalData.appCode = wx.getAccountInfoSync().miniProgram.appId;
                  } else {
                    // 如果希望用户在最新版本的客户端上体验您的小程序，可以这样子提示
                    wx.showModal({
                      title: "提示",
                      content: "当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。"
                    });
                  }
                }
                updateManager = wx.getUpdateManager();

                updateManager.onCheckForUpdate(function (res) {
                  // 请求完新版本信息的回调
                  console.log(res.hasUpdate);
                });
                updateManager.onUpdateReady(function () {
                  wx.showModal({
                    title: "更新提示",
                    content: "新版本已经准备好，是否重启应用？",
                    success: function success(res) {
                      if (res.confirm) {
                        // 新的版本已经下载好，调用 applyUpdate 应用新版本并重启
                        updateManager.applyUpdate();
                      }
                    }
                  });
                });
                updateManager.onUpdateFailed(function () {
                  // 新的版本下载失败
                  wx.showModal({
                    title: "更新提示",
                    content: "新版本下载失败",
                    showCancel: false
                  });
                });
                // 校验SDK
                _WxUtils2.default.checkSDK();
                // 同步开放平台EXT数据
                ext = _wepy2.default.getExtConfigSync();
                // console.info("[ext] init ext data", ext);

                if (ext.globalConfig) {
                  // console.info("[ext] init ext global config data", ext.globalConfig);
                  Object.assign(ext, ext.globalConfig);
                }
                Object.assign(_wepy2.default.$instance.globalData, ext);
                // auth.login();

              case 9:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function onLaunch(_x) {
        return _ref.apply(this, arguments);
      }

      return onLaunch;
    }()
  }, {
    key: "onShow",
    value: function onShow(param) {
      console.log(param);
      // 获取保存场景值
      if (param && param.scene) {
        _wepy2.default.$instance.globalData.scene = param.scene;
        console.log();
        if (param.query.scene) {
          _wepy2.default.$instance.globalData.query = this.getCodeBy1047(param.query.scene);
        } else if (param.query.agentId) {
          _wepy2.default.$instance.globalData.query['agentId'] = param.query.agentId;
        }
      }
    }
  }, {
    key: "getCodeBy1047",
    value: function getCodeBy1047(str) {
      var query = {},
          strs = decodeURIComponent(str).split("&");
      console.log(strs);
      for (var i = 0, len = strs.length; i < len; i++) {
        query[strs[i].split("=")[0]] = strs[i].split("=")[1];
      }
      return query;
    }
  }, {
    key: "syncStoreConfig",
    value: function syncStoreConfig(key) {
      try {
        var value = _wepy2.default.getStorageSync(key);
        if (value !== "") {
          // console.info(`[auth]${key} sync success `);
          _wepy2.default.$instance.globalData.auth[key] = value;
        }
      } catch (e) {
        // console.warn(`[auth]${key} sync fail `);
      }
    }
  }, {
    key: "onShareAppMessage",
    value: function onShareAppMessage(res) {
      if (res.from === "button") {
        // 来自页面内转发按钮
        console.log(res.target);
      }
      return {
        title: "自定义转发标题",
        path: "/pages/home/index"
      };
    }
  }]);

  return _default;
}(_wepy2.default.app);


App(require('./npm/wepy/lib/wepy.js').default.$createApp(_default, {"noPromiseAPI":["createSelectorQuery"]}));
require('./_wepylogs.js')

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC5qcyJdLCJuYW1lcyI6WyJzdG9yZSIsImdsb2JhbERhdGEiLCJhdXRoIiwic2NlbmUiLCJiYXNlX3N0b3JlX2lkIiwiYXBwQ29kZSIsImJhc2VVcmwiLCJ0aGVtZUNvbG9yIiwiY2l0eUNvZGUiLCJjb2RlIiwic2Vzc2lvbklkIiwiY291cnNlSW5mbyIsIm9yZGVySW5mbyIsImNoaWxkcyIsImhlbHAiLCJxdWVyeSIsImNvbmZpZyIsInBhZ2VzIiwic3ViUGFja2FnZXMiLCJyb290Iiwid2luZG93IiwiYmFja2dyb3VuZFRleHRTdHlsZSIsIm5hdmlnYXRpb25CYXJCYWNrZ3JvdW5kQ29sb3IiLCJiYWNrZ3JvdW5kQ29sb3IiLCJuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0IiwibmF2aWdhdGlvbkJhclRleHRTdHlsZSIsIm5hdmlnYXRlVG9NaW5pUHJvZ3JhbUFwcElkTGlzdCIsInBlcm1pc3Npb24iLCJkZXNjIiwidXNlIiwicGFyYW0iLCJ3ZXB5IiwiJGluc3RhbmNlIiwid3giLCJnZXRBY2NvdW50SW5mb1N5bmMiLCJtaW5pUHJvZ3JhbSIsImFwcElkIiwicmVzIiwiY2FuSVVzZSIsInNob3dNb2RhbCIsInRpdGxlIiwiY29udGVudCIsInVwZGF0ZU1hbmFnZXIiLCJnZXRVcGRhdGVNYW5hZ2VyIiwib25DaGVja0ZvclVwZGF0ZSIsImNvbnNvbGUiLCJsb2ciLCJoYXNVcGRhdGUiLCJvblVwZGF0ZVJlYWR5Iiwic3VjY2VzcyIsImNvbmZpcm0iLCJhcHBseVVwZGF0ZSIsIm9uVXBkYXRlRmFpbGVkIiwic2hvd0NhbmNlbCIsIld4VXRpbHMiLCJjaGVja1NESyIsImV4dCIsImdldEV4dENvbmZpZ1N5bmMiLCJnbG9iYWxDb25maWciLCJPYmplY3QiLCJhc3NpZ24iLCJnZXRDb2RlQnkxMDQ3IiwiYWdlbnRJZCIsInN0ciIsInN0cnMiLCJkZWNvZGVVUklDb21wb25lbnQiLCJzcGxpdCIsImkiLCJsZW4iLCJsZW5ndGgiLCJrZXkiLCJ2YWx1ZSIsImdldFN0b3JhZ2VTeW5jIiwiZSIsImZyb20iLCJ0YXJnZXQiLCJwYXRoIiwiYXBwIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFDRTs7OztBQUNBOztBQUNBOzs7O0FBQ0E7O0FBR0E7Ozs7Ozs7Ozs7Ozs7O0FBQ0EsSUFBTUEsUUFBUSxzQkFBZDtBQUNBLHlCQUFTQSxLQUFUOzs7OztBQW1CRSxzQkFBYztBQUFBOztBQUVaO0FBRlk7O0FBQUEsVUFqQmRDLFVBaUJjLEdBakJEO0FBQ1hDLFlBQU0sRUFESztBQUVYQyxhQUFPLElBRkk7QUFHWEMscUJBQWUsRUFISjtBQUlYQyxlQUFTLEVBSkU7QUFLWDtBQUNBQyxlQUFTLHlCQU5FO0FBT1hDLGtCQUFZLFNBUEQ7QUFRWEMsZ0JBQVUsRUFSQztBQVNYQyxZQUFNLEVBVEs7QUFVWEMsaUJBQVcsRUFWQTtBQVdYQyxrQkFBWSxFQVhEO0FBWVhDLGlCQUFXLEVBWkE7QUFhWEMsY0FBUSxFQWJHO0FBY1hDLFlBQU0sSUFkSztBQWVYQyxhQUFPO0FBZkksS0FpQkM7QUFBQSxVQXFHZEMsTUFyR2MsR0FxR0w7QUFDUEMsYUFBTyxDQUNMLGtCQURLLEVBRUwsbUJBRkssRUFHTCxnQkFISyxFQUlMLGtCQUpLLEVBS0wsaUJBTEssRUFNTCxhQU5LLEVBT0wsaUJBUEssRUFRTCxnQkFSSyxFQVNMLGtCQVRLLEVBVUwscUJBVkssRUFXTCxvQkFYSyxFQVlMLHVCQVpLLEVBYUwseUJBYkssRUFjTCx3QkFkSyxFQWVMLG1CQWZLLEVBZ0JMLHFCQWhCSyxFQWlCTCxtQkFqQkssRUFrQkwsb0JBbEJLLEVBbUJMLHlCQW5CSyxFQW9CTCx3QkFwQkssRUFxQkwsd0JBckJLLENBREE7QUF3QlBDLG1CQUFhLENBQUM7QUFDWkMsY0FBTSxPQURNO0FBRVpGLGVBQU8sQ0FDTCxhQURLLEVBRUwsYUFGSyxFQUdMLFlBSEs7QUFGSyxPQUFELENBeEJOO0FBZ0NQRyxjQUFRO0FBQ05DLDZCQUFxQixNQURmO0FBRU5DLHNDQUE4QixTQUZ4QjtBQUdOQyx5QkFBaUIsTUFIWDtBQUlOQyxnQ0FBd0IsRUFKbEI7QUFLTkMsZ0NBQXdCO0FBTGxCLE9BaENEO0FBdUNQQyxzQ0FBZ0MsRUF2Q3pCO0FBd0NQQyxrQkFBWTtBQUNWLDhCQUFzQjtBQUNwQkMsZ0JBQU07QUFEYztBQURaLE9BeENMO0FBNkNQLGdCQUFVO0FBQ1IsaUJBQVMsU0FERDtBQUVSLHlCQUFpQixTQUZUO0FBR1IsdUJBQWUsT0FIUDtBQUlSLGdCQUFRLENBQUM7QUFDTCw4QkFBb0Isc0NBRGY7QUFFTCxzQkFBWSxnQ0FGUDtBQUdMLHNCQUFZLGtCQUhQO0FBSUwsa0JBQVE7QUFKSCxTQUFELEVBTU47QUFDRSw4QkFBb0IscUNBRHRCO0FBRUUsc0JBQVksK0JBRmQ7QUFHRSxzQkFBWSxpQkFIZDtBQUlFLGtCQUFRO0FBSlYsU0FOTSxFQVlOO0FBQ0UsOEJBQW9CLG1DQUR0QjtBQUVFLHNCQUFZLDZCQUZkO0FBR0Usc0JBQVksYUFIZDtBQUlFLGtCQUFRO0FBSlYsU0FaTTtBQUpBO0FBN0NILEtBckdLO0FBR1osVUFBS0MsR0FBTCxDQUFTLFlBQVQ7QUFDQSxVQUFLQSxHQUFMLENBQVMsV0FBVDtBQUpZO0FBS2I7Ozs7OzBGQUNjQyxLOzs7Ozs7QUFDYjtBQUNBLG9CQUFJO0FBQ0ZDLGlDQUFLQyxTQUFMLENBQWUvQixVQUFmLENBQTBCSSxPQUExQixHQUFvQzRCLEdBQUdDLGtCQUFILEdBQXdCQyxXQUF4QixDQUFvQ0MsS0FBeEU7QUFDRCxpQkFGRCxDQUVFLE9BQU9DLEdBQVAsRUFBWTtBQUNaLHNCQUFJSixHQUFHSyxPQUFILENBQVcsb0JBQVgsQ0FBSixFQUFzQztBQUNwQ1AsbUNBQUtDLFNBQUwsQ0FBZS9CLFVBQWYsQ0FBMEJJLE9BQTFCLEdBQW9DNEIsR0FBR0Msa0JBQUgsR0FBd0JDLFdBQXhCLENBQW9DQyxLQUF4RTtBQUNELG1CQUZELE1BRU87QUFDTDtBQUNBSCx1QkFBR00sU0FBSCxDQUFhO0FBQ1hDLDZCQUFPLElBREk7QUFFWEMsK0JBQVM7QUFGRSxxQkFBYjtBQUlEO0FBQ0Y7QUFDS0MsNkIsR0FBZ0JULEdBQUdVLGdCQUFILEU7O0FBQ3RCRCw4QkFBY0UsZ0JBQWQsQ0FBK0IsVUFBU1AsR0FBVCxFQUFjO0FBQzNDO0FBQ0FRLDBCQUFRQyxHQUFSLENBQVlULElBQUlVLFNBQWhCO0FBQ0QsaUJBSEQ7QUFJQUwsOEJBQWNNLGFBQWQsQ0FBNEIsWUFBVztBQUNyQ2YscUJBQUdNLFNBQUgsQ0FBYTtBQUNYQywyQkFBTyxNQURJO0FBRVhDLDZCQUFTLGtCQUZFO0FBR1hRLDZCQUFTLGlCQUFTWixHQUFULEVBQWM7QUFDckIsMEJBQUlBLElBQUlhLE9BQVIsRUFBaUI7QUFDZjtBQUNBUixzQ0FBY1MsV0FBZDtBQUNEO0FBQ0Y7QUFSVSxtQkFBYjtBQVVELGlCQVhEO0FBWUFULDhCQUFjVSxjQUFkLENBQTZCLFlBQVc7QUFDdEM7QUFDQW5CLHFCQUFHTSxTQUFILENBQWE7QUFDWEMsMkJBQU8sTUFESTtBQUVYQyw2QkFBUyxTQUZFO0FBR1hZLGdDQUFZO0FBSEQsbUJBQWI7QUFLRCxpQkFQRDtBQVFBO0FBQ0FDLGtDQUFRQyxRQUFSO0FBQ0E7QUFDTUMsbUIsR0FBTXpCLGVBQUswQixnQkFBTCxFO0FBQ1o7O0FBQ0Esb0JBQUlELElBQUlFLFlBQVIsRUFBc0I7QUFDcEI7QUFDQUMseUJBQU9DLE1BQVAsQ0FBY0osR0FBZCxFQUFtQkEsSUFBSUUsWUFBdkI7QUFDRDtBQUNEQyx1QkFBT0MsTUFBUCxDQUFjN0IsZUFBS0MsU0FBTCxDQUFlL0IsVUFBN0IsRUFBeUN1RCxHQUF6QztBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7MkJBRUsxQixLLEVBQU87QUFDWmUsY0FBUUMsR0FBUixDQUFZaEIsS0FBWjtBQUNBO0FBQ0EsVUFBSUEsU0FBU0EsTUFBTTNCLEtBQW5CLEVBQTBCO0FBQ3hCNEIsdUJBQUtDLFNBQUwsQ0FBZS9CLFVBQWYsQ0FBMEJFLEtBQTFCLEdBQWtDMkIsTUFBTTNCLEtBQXhDO0FBQ0EwQyxnQkFBUUMsR0FBUjtBQUNBLFlBQUloQixNQUFNZixLQUFOLENBQVlaLEtBQWhCLEVBQXVCO0FBQ3JCNEIseUJBQUtDLFNBQUwsQ0FBZS9CLFVBQWYsQ0FBMEJjLEtBQTFCLEdBQWtDLEtBQUs4QyxhQUFMLENBQW1CL0IsTUFBTWYsS0FBTixDQUFZWixLQUEvQixDQUFsQztBQUNELFNBRkQsTUFFTyxJQUFJMkIsTUFBTWYsS0FBTixDQUFZK0MsT0FBaEIsRUFBeUI7QUFDOUIvQix5QkFBS0MsU0FBTCxDQUFlL0IsVUFBZixDQUEwQmMsS0FBMUIsQ0FBZ0MsU0FBaEMsSUFBNkNlLE1BQU1mLEtBQU4sQ0FBWStDLE9BQXpEO0FBQ0Q7QUFDRjtBQUNGOzs7a0NBQ2FDLEcsRUFBSztBQUNqQixVQUFJaEQsUUFBUSxFQUFaO0FBQUEsVUFDRWlELE9BQU9DLG1CQUFtQkYsR0FBbkIsRUFBd0JHLEtBQXhCLENBQThCLEdBQTlCLENBRFQ7QUFFQXJCLGNBQVFDLEdBQVIsQ0FBWWtCLElBQVo7QUFDQSxXQUFLLElBQUlHLElBQUksQ0FBUixFQUFXQyxNQUFNSixLQUFLSyxNQUEzQixFQUFtQ0YsSUFBSUMsR0FBdkMsRUFBNENELEdBQTVDLEVBQWlEO0FBQy9DcEQsY0FBTWlELEtBQUtHLENBQUwsRUFBUUQsS0FBUixDQUFjLEdBQWQsRUFBbUIsQ0FBbkIsQ0FBTixJQUErQkYsS0FBS0csQ0FBTCxFQUFRRCxLQUFSLENBQWMsR0FBZCxFQUFtQixDQUFuQixDQUEvQjtBQUNEO0FBQ0QsYUFBT25ELEtBQVA7QUFDRDs7O29DQUNldUQsRyxFQUFLO0FBQ25CLFVBQUk7QUFDRixZQUFNQyxRQUFReEMsZUFBS3lDLGNBQUwsQ0FBb0JGLEdBQXBCLENBQWQ7QUFDQSxZQUFJQyxVQUFVLEVBQWQsRUFBa0I7QUFDaEI7QUFDQXhDLHlCQUFLQyxTQUFMLENBQWUvQixVQUFmLENBQTBCQyxJQUExQixDQUErQm9FLEdBQS9CLElBQXNDQyxLQUF0QztBQUNEO0FBQ0YsT0FORCxDQU1FLE9BQU9FLENBQVAsRUFBVTtBQUNWO0FBQ0Q7QUFDRjs7O3NDQUNpQnBDLEcsRUFBSztBQUNyQixVQUFJQSxJQUFJcUMsSUFBSixLQUFhLFFBQWpCLEVBQTJCO0FBQ3pCO0FBQ0E3QixnQkFBUUMsR0FBUixDQUFZVCxJQUFJc0MsTUFBaEI7QUFDRDtBQUNELGFBQU87QUFDTG5DLGVBQU8sU0FERjtBQUVMb0MsY0FBTTtBQUZELE9BQVA7QUFJRDs7OztFQXRIMEI3QyxlQUFLOEMsRyIsImZpbGUiOiJhcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuICBpbXBvcnQgd2VweSBmcm9tIFwid2VweVwiO1xyXG4gIGltcG9ydCBcIndlcHktYXN5bmMtZnVuY3Rpb25cIjtcclxuICBpbXBvcnQgV3hVdGlscyBmcm9tIFwiLi91dGlscy9XeFV0aWxzXCI7XHJcbiAgaW1wb3J0IHtcclxuICAgIHNldFN0b3JlXHJcbiAgfSBmcm9tIFwid2VweS1yZWR1eFwiO1xyXG4gIGltcG9ydCBjb25maWdTdG9yZSBmcm9tIFwiLi9zdG9yZVwiO1xyXG4gIGNvbnN0IHN0b3JlID0gY29uZmlnU3RvcmUoKTtcclxuICBzZXRTdG9yZShzdG9yZSk7XHJcbiAgZXhwb3J0IGRlZmF1bHQgY2xhc3MgZXh0ZW5kcyB3ZXB5LmFwcCB7XHJcbiAgICBnbG9iYWxEYXRhID0ge1xyXG4gICAgICBhdXRoOiB7fSxcclxuICAgICAgc2NlbmU6IG51bGwsXHJcbiAgICAgIGJhc2Vfc3RvcmVfaWQ6IFwiXCIsXHJcbiAgICAgIGFwcENvZGU6IFwiXCIsXHJcbiAgICAgIC8vIGJhc2VVcmw6IFwiaHR0cHM6Ly93ZWNoYXQuaHhxeGx5LmNvbVwiLFxyXG4gICAgICBiYXNlVXJsOiBcImh0dHBzOi8vdGVzdC5oeHF4bHkuY29tXCIsXHJcbiAgICAgIHRoZW1lQ29sb3I6IFwiI0Y0RDAwMFwiLFxyXG4gICAgICBjaXR5Q29kZTogJycsXHJcbiAgICAgIGNvZGU6ICcnLFxyXG4gICAgICBzZXNzaW9uSWQ6ICcnLFxyXG4gICAgICBjb3Vyc2VJbmZvOiB7fSxcclxuICAgICAgb3JkZXJJbmZvOiB7fSxcclxuICAgICAgY2hpbGRzOiBbXSxcclxuICAgICAgaGVscDogdHJ1ZSxcclxuICAgICAgcXVlcnk6IHt9XHJcbiAgICB9O1xyXG4gICAgY29uc3RydWN0b3IoKSB7XHJcbiAgICAgIHN1cGVyKCk7XHJcbiAgICAgIC8vIOazqOWGjOS4remXtOS7tlxyXG4gICAgICB0aGlzLnVzZShcInJlcXVlc3RmaXhcIik7XHJcbiAgICAgIHRoaXMudXNlKFwicHJvbWlzaWZ5XCIpO1xyXG4gICAgfVxyXG4gICAgYXN5bmMgb25MYXVuY2gocGFyYW0pIHtcclxuICAgICAgLy8g6I635Y+W5b2T5YmN5bCP56iL5bqPXHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5hcHBDb2RlID0gd3guZ2V0QWNjb3VudEluZm9TeW5jKCkubWluaVByb2dyYW0uYXBwSWQ7XHJcbiAgICAgIH0gY2F0Y2ggKHJlcykge1xyXG4gICAgICAgIGlmICh3eC5jYW5JVXNlKFwiZ2V0QWNjb3VudEluZm9TeW5jXCIpKSB7XHJcbiAgICAgICAgICB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLmFwcENvZGUgPSB3eC5nZXRBY2NvdW50SW5mb1N5bmMoKS5taW5pUHJvZ3JhbS5hcHBJZDtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgLy8g5aaC5p6c5biM5pyb55So5oi35Zyo5pyA5paw54mI5pys55qE5a6i5oi356uv5LiK5L2T6aqM5oKo55qE5bCP56iL5bqP77yM5Y+v5Lul6L+Z5qC35a2Q5o+Q56S6XHJcbiAgICAgICAgICB3eC5zaG93TW9kYWwoe1xyXG4gICAgICAgICAgICB0aXRsZTogXCLmj5DnpLpcIixcclxuICAgICAgICAgICAgY29udGVudDogXCLlvZPliY3lvq7kv6HniYjmnKzov4fkvY7vvIzml6Dms5Xkvb/nlKjor6Xlip/og73vvIzor7fljYfnuqfliLDmnIDmlrDlvq7kv6HniYjmnKzlkI7ph43or5XjgIJcIlxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICAgIGNvbnN0IHVwZGF0ZU1hbmFnZXIgPSB3eC5nZXRVcGRhdGVNYW5hZ2VyKCk7XHJcbiAgICAgIHVwZGF0ZU1hbmFnZXIub25DaGVja0ZvclVwZGF0ZShmdW5jdGlvbihyZXMpIHtcclxuICAgICAgICAvLyDor7fmsYLlrozmlrDniYjmnKzkv6Hmga/nmoTlm57osINcclxuICAgICAgICBjb25zb2xlLmxvZyhyZXMuaGFzVXBkYXRlKTtcclxuICAgICAgfSk7XHJcbiAgICAgIHVwZGF0ZU1hbmFnZXIub25VcGRhdGVSZWFkeShmdW5jdGlvbigpIHtcclxuICAgICAgICB3eC5zaG93TW9kYWwoe1xyXG4gICAgICAgICAgdGl0bGU6IFwi5pu05paw5o+Q56S6XCIsXHJcbiAgICAgICAgICBjb250ZW50OiBcIuaWsOeJiOacrOW3sue7j+WHhuWkh+Wlve+8jOaYr+WQpumHjeWQr+W6lOeUqO+8n1wiLFxyXG4gICAgICAgICAgc3VjY2VzczogZnVuY3Rpb24ocmVzKSB7XHJcbiAgICAgICAgICAgIGlmIChyZXMuY29uZmlybSkge1xyXG4gICAgICAgICAgICAgIC8vIOaWsOeahOeJiOacrOW3sue7j+S4i+i9veWlve+8jOiwg+eUqCBhcHBseVVwZGF0ZSDlupTnlKjmlrDniYjmnKzlubbph43lkK9cclxuICAgICAgICAgICAgICB1cGRhdGVNYW5hZ2VyLmFwcGx5VXBkYXRlKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgICAgfSk7XHJcbiAgICAgIHVwZGF0ZU1hbmFnZXIub25VcGRhdGVGYWlsZWQoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgLy8g5paw55qE54mI5pys5LiL6L295aSx6LSlXHJcbiAgICAgICAgd3guc2hvd01vZGFsKHtcclxuICAgICAgICAgIHRpdGxlOiBcIuabtOaWsOaPkOekulwiLFxyXG4gICAgICAgICAgY29udGVudDogXCLmlrDniYjmnKzkuIvovb3lpLHotKVcIixcclxuICAgICAgICAgIHNob3dDYW5jZWw6IGZhbHNlXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0pO1xyXG4gICAgICAvLyDmoKHpqoxTREtcclxuICAgICAgV3hVdGlscy5jaGVja1NESygpO1xyXG4gICAgICAvLyDlkIzmraXlvIDmlL7lubPlj7BFWFTmlbDmja5cclxuICAgICAgY29uc3QgZXh0ID0gd2VweS5nZXRFeHRDb25maWdTeW5jKCk7XHJcbiAgICAgIC8vIGNvbnNvbGUuaW5mbyhcIltleHRdIGluaXQgZXh0IGRhdGFcIiwgZXh0KTtcclxuICAgICAgaWYgKGV4dC5nbG9iYWxDb25maWcpIHtcclxuICAgICAgICAvLyBjb25zb2xlLmluZm8oXCJbZXh0XSBpbml0IGV4dCBnbG9iYWwgY29uZmlnIGRhdGFcIiwgZXh0Lmdsb2JhbENvbmZpZyk7XHJcbiAgICAgICAgT2JqZWN0LmFzc2lnbihleHQsIGV4dC5nbG9iYWxDb25maWcpO1xyXG4gICAgICB9XHJcbiAgICAgIE9iamVjdC5hc3NpZ24od2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YSwgZXh0KTtcclxuICAgICAgLy8gYXV0aC5sb2dpbigpO1xyXG4gICAgfVxyXG4gICAgb25TaG93KHBhcmFtKSB7XHJcbiAgICAgIGNvbnNvbGUubG9nKHBhcmFtKTtcclxuICAgICAgLy8g6I635Y+W5L+d5a2Y5Zy65pmv5YC8XHJcbiAgICAgIGlmIChwYXJhbSAmJiBwYXJhbS5zY2VuZSkge1xyXG4gICAgICAgIHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuc2NlbmUgPSBwYXJhbS5zY2VuZTtcclxuICAgICAgICBjb25zb2xlLmxvZygpXHJcbiAgICAgICAgaWYgKHBhcmFtLnF1ZXJ5LnNjZW5lKSB7XHJcbiAgICAgICAgICB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnF1ZXJ5ID0gdGhpcy5nZXRDb2RlQnkxMDQ3KHBhcmFtLnF1ZXJ5LnNjZW5lKVxyXG4gICAgICAgIH0gZWxzZSBpZiAocGFyYW0ucXVlcnkuYWdlbnRJZCkge1xyXG4gICAgICAgICAgd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5xdWVyeVsnYWdlbnRJZCddID0gcGFyYW0ucXVlcnkuYWdlbnRJZFxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgZ2V0Q29kZUJ5MTA0NyhzdHIpIHtcclxuICAgICAgdmFyIHF1ZXJ5ID0ge30sXHJcbiAgICAgICAgc3RycyA9IGRlY29kZVVSSUNvbXBvbmVudChzdHIpLnNwbGl0KFwiJlwiKTtcclxuICAgICAgY29uc29sZS5sb2coc3Rycyk7XHJcbiAgICAgIGZvciAodmFyIGkgPSAwLCBsZW4gPSBzdHJzLmxlbmd0aDsgaSA8IGxlbjsgaSsrKSB7XHJcbiAgICAgICAgcXVlcnlbc3Ryc1tpXS5zcGxpdChcIj1cIilbMF1dID0gc3Ryc1tpXS5zcGxpdChcIj1cIilbMV07XHJcbiAgICAgIH1cclxuICAgICAgcmV0dXJuIHF1ZXJ5O1xyXG4gICAgfVxyXG4gICAgc3luY1N0b3JlQ29uZmlnKGtleSkge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHZhbHVlID0gd2VweS5nZXRTdG9yYWdlU3luYyhrZXkpO1xyXG4gICAgICAgIGlmICh2YWx1ZSAhPT0gXCJcIikge1xyXG4gICAgICAgICAgLy8gY29uc29sZS5pbmZvKGBbYXV0aF0ke2tleX0gc3luYyBzdWNjZXNzIGApO1xyXG4gICAgICAgICAgd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5hdXRoW2tleV0gPSB2YWx1ZTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAvLyBjb25zb2xlLndhcm4oYFthdXRoXSR7a2V5fSBzeW5jIGZhaWwgYCk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIG9uU2hhcmVBcHBNZXNzYWdlKHJlcykge1xyXG4gICAgICBpZiAocmVzLmZyb20gPT09IFwiYnV0dG9uXCIpIHtcclxuICAgICAgICAvLyDmnaXoh6rpobXpnaLlhoXovazlj5HmjInpkq5cclxuICAgICAgICBjb25zb2xlLmxvZyhyZXMudGFyZ2V0KTtcclxuICAgICAgfVxyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIHRpdGxlOiBcIuiHquWumuS5iei9rOWPkeagh+mimFwiLFxyXG4gICAgICAgIHBhdGg6IFwiL3BhZ2VzL2hvbWUvaW5kZXhcIlxyXG4gICAgICB9O1xyXG4gICAgfVxyXG4gICAgY29uZmlnID0ge1xyXG4gICAgICBwYWdlczogW1xyXG4gICAgICAgIFwicGFnZXMvaG9tZS9pbmRleFwiLFxyXG4gICAgICAgIFwicGFnZXMvaG9tZS9zZWFyY2hcIixcclxuICAgICAgICBcInBhZ2VzL2hvbWUvd2ViXCIsXHJcbiAgICAgICAgXCJwYWdlcy9ob21lL3NoYXJlXCIsXHJcbiAgICAgICAgXCJwYWdlcy9tZWV0L21lZXRcIixcclxuICAgICAgICBcInBhZ2VzL215L215XCIsXHJcbiAgICAgICAgXCJwYWdlcy9teS9vcmRlcnNcIixcclxuICAgICAgICBcInBhZ2VzL215L29yZGVyXCIsXHJcbiAgICAgICAgXCJwYWdlcy9teS9waW50dWFuXCIsXHJcbiAgICAgICAgXCJwYWdlcy9teS9iYXJnYWluaW5nXCIsXHJcbiAgICAgICAgXCJwYWdlcy9ob21lL2FkZHJlc3NcIixcclxuICAgICAgICBcInBhZ2VzL2RldGFpbGUvZGV0YWlsZVwiLFxyXG4gICAgICAgIFwicGFnZXMvZGV0YWlsZS9zdXJlT3JkZXJcIixcclxuICAgICAgICBcInBhZ2VzL2RldGFpbGUvcGFydG5lcnNcIixcclxuICAgICAgICBcInBhZ2VzL21lZXQvY2hpbGRzXCIsXHJcbiAgICAgICAgXCJwYWdlcy9tZWV0L2FkZENoaWxkXCIsXHJcbiAgICAgICAgXCJwYWdlcy9tZWV0L2FkZE1hblwiLFxyXG4gICAgICAgIFwicGFnZXMvbWVldC9yZW1hcmtzXCIsXHJcbiAgICAgICAgXCJwYWdlcy9tZWV0L2NvbW1pUmVtYXJrZVwiLFxyXG4gICAgICAgIFwicGFnZXMvYWN0aXZpdHkvYmFyZ2FpblwiLFxyXG4gICAgICAgIFwicGFnZXMvYWN0aXZpdHkvcGludHVhblwiLFxyXG4gICAgICBdLFxyXG4gICAgICBzdWJQYWNrYWdlczogW3tcclxuICAgICAgICByb290OiBcImFnZW50XCIsXHJcbiAgICAgICAgcGFnZXM6IFtcclxuICAgICAgICAgIFwicGFnZXMvaW5kZXhcIixcclxuICAgICAgICAgIFwicGFnZXMvc2hhcmVcIixcclxuICAgICAgICAgIFwicGFnZXMvc2lnblwiLFxyXG4gICAgICAgIF1cclxuICAgICAgfV0sXHJcbiAgICAgIHdpbmRvdzoge1xyXG4gICAgICAgIGJhY2tncm91bmRUZXh0U3R5bGU6IFwiZGFya1wiLFxyXG4gICAgICAgIG5hdmlnYXRpb25CYXJCYWNrZ3JvdW5kQ29sb3I6IFwiI0Y0RDAwMFwiLFxyXG4gICAgICAgIGJhY2tncm91bmRDb2xvcjogXCIjZmZmXCIsXHJcbiAgICAgICAgbmF2aWdhdGlvbkJhclRpdGxlVGV4dDogXCJcIixcclxuICAgICAgICBuYXZpZ2F0aW9uQmFyVGV4dFN0eWxlOiBcIndoaXRlXCJcclxuICAgICAgfSxcclxuICAgICAgbmF2aWdhdGVUb01pbmlQcm9ncmFtQXBwSWRMaXN0OiBbXSxcclxuICAgICAgcGVybWlzc2lvbjoge1xyXG4gICAgICAgIFwic2NvcGUudXNlckxvY2F0aW9uXCI6IHtcclxuICAgICAgICAgIGRlc2M6IFwi5L2g55qE5L2N572u5L+h5oGv5bCG55So5LqO5bCP56iL5bqP5L2N572u55qE5pWI5p6c5bGV56S6XCJcclxuICAgICAgICB9XHJcbiAgICAgIH0sXHJcbiAgICAgIFwidGFiQmFyXCI6IHtcclxuICAgICAgICBcImNvbG9yXCI6IFwiI2E5YjdiN1wiLFxyXG4gICAgICAgIFwic2VsZWN0ZWRDb2xvclwiOiBcIiNGNEQwMDBcIixcclxuICAgICAgICBcImJvcmRlclN0eWxlXCI6IFwiYmxhY2tcIixcclxuICAgICAgICBcImxpc3RcIjogW3tcclxuICAgICAgICAgICAgXCJzZWxlY3RlZEljb25QYXRoXCI6IFwic3RhdGljL2ltYWdlcy9pY29uX2NvbnN1bHRfcHJlc3MucG5nXCIsXHJcbiAgICAgICAgICAgIFwiaWNvblBhdGhcIjogXCJzdGF0aWMvaW1hZ2VzL2ljb25fY29uc3VsdC5wbmdcIixcclxuICAgICAgICAgICAgXCJwYWdlUGF0aFwiOiBcInBhZ2VzL2hvbWUvaW5kZXhcIixcclxuICAgICAgICAgICAgXCJ0ZXh0XCI6IFwi6aaW6aG1XCJcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIFwic2VsZWN0ZWRJY29uUGF0aFwiOiBcInN0YXRpYy9pbWFnZXMvaWNvbl9pbnZlc3RfcHJlc3MucG5nXCIsXHJcbiAgICAgICAgICAgIFwiaWNvblBhdGhcIjogXCJzdGF0aWMvaW1hZ2VzL2ljb25faW52ZXN0LnBuZ1wiLFxyXG4gICAgICAgICAgICBcInBhZ2VQYXRoXCI6IFwicGFnZXMvbWVldC9tZWV0XCIsXHJcbiAgICAgICAgICAgIFwidGV4dFwiOiBcIuS6kuWKqFwiXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBcInNlbGVjdGVkSWNvblBhdGhcIjogXCJzdGF0aWMvaW1hZ2VzL2ljb25fbWluZV9wcmVzcy5wbmdcIixcclxuICAgICAgICAgICAgXCJpY29uUGF0aFwiOiBcInN0YXRpYy9pbWFnZXMvaWNvbl9taW5lLnBuZ1wiLFxyXG4gICAgICAgICAgICBcInBhZ2VQYXRoXCI6IFwicGFnZXMvbXkvbXlcIixcclxuICAgICAgICAgICAgXCJ0ZXh0XCI6IFwi5oiR55qEXCJcclxuICAgICAgICAgIH1cclxuICAgICAgICBdXHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgfVxyXG4iXX0=