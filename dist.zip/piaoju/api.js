'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = undefined;

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _base2 = require('./../api/base.js');

var _base3 = _interopRequireDefault(_base2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var config = function (_base) {
  _inherits(config, _base);

  function config() {
    _classCallCheck(this, config);

    return _possibleConstructorReturn(this, (config.__proto__ || Object.getPrototypeOf(config)).apply(this, arguments));
  }

  _createClass(config, null, [{
    key: 'videoIndex',

    // 获取首页数据
    value: function () {
      var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(opt) {
        var url, params;
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                url = this.baseUrl + '/member/receipt';
                params = {
                  sessionId: _wepy2.default.$instance.globalData.sessionId
                };
                return _context.abrupt('return', this.post(url, params, true).then(function (res) {
                  return res;
                }));

              case 3:
              case 'end':
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function videoIndex(_x) {
        return _ref.apply(this, arguments);
      }

      return videoIndex;
    }()
    // 获取更多视频数据

  }, {
    key: 'videoList',
    value: function () {
      var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(opt) {
        var url, params;
        return regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                url = this.baseUrl + '/video/list';
                params = _extends({}, opt, {
                  sessionId: _wepy2.default.$instance.globalData.sessionId
                });
                return _context2.abrupt('return', this.post(url, params, true).then(function (res) {
                  return res;
                }));

              case 3:
              case 'end':
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));

      function videoList(_x2) {
        return _ref2.apply(this, arguments);
      }

      return videoList;
    }()
  }]);

  return config;
}(_base3.default);

exports.default = config;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwaS5qcyJdLCJuYW1lcyI6WyJjb25maWciLCJvcHQiLCJ1cmwiLCJiYXNlVXJsIiwicGFyYW1zIiwic2Vzc2lvbklkIiwid2VweSIsIiRpbnN0YW5jZSIsImdsb2JhbERhdGEiLCJwb3N0IiwidGhlbiIsInJlcyIsImJhc2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7O0FBQUE7Ozs7QUFDQTs7Ozs7Ozs7Ozs7Ozs7SUFFcUJBLE07Ozs7Ozs7Ozs7OztBQUNuQjs7MEZBQ3dCQyxHOzs7Ozs7QUFDbEJDLG1CLEdBQVMsS0FBS0MsTztBQUNkQyxzQixHQUFTO0FBQ1hDLDZCQUFXQyxlQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJIO0FBRDFCLGlCO2lEQUdOLEtBQUtJLElBQUwsQ0FBVVAsR0FBVixFQUFlRSxNQUFmLEVBQXVCLElBQXZCLEVBQTZCTSxJQUE3QixDQUFrQyxlQUFPO0FBQzlDLHlCQUFPQyxHQUFQO0FBQ0QsaUJBRk0sQzs7Ozs7Ozs7Ozs7Ozs7OztBQUlUOzs7Ozs0RkFDdUJWLEc7Ozs7OztBQUNqQkMsbUIsR0FBUyxLQUFLQyxPO0FBQ2RDLHNCLGdCQUNDSCxHO0FBQ0hJLDZCQUFXQyxlQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJIOztrREFFaEMsS0FBS0ksSUFBTCxDQUFVUCxHQUFWLEVBQWVFLE1BQWYsRUFBdUIsSUFBdkIsRUFBNkJNLElBQTdCLENBQWtDLGVBQU87QUFDOUMseUJBQU9DLEdBQVA7QUFDRCxpQkFGTSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBbEJ5QkMsYzs7a0JBQWZaLE0iLCJmaWxlIjoiYXBpLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHdlcHkgZnJvbSAnd2VweSdcclxuaW1wb3J0IGJhc2UgZnJvbSAnQC9hcGkvYmFzZSdcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIGNvbmZpZyBleHRlbmRzIGJhc2Uge1xyXG4gIC8vIOiOt+WPlummlumhteaVsOaNrlxyXG4gIHN0YXRpYyBhc3luYyB2aWRlb0luZGV4KG9wdCkge1xyXG4gICAgbGV0IHVybCA9IGAke3RoaXMuYmFzZVVybH0vbWVtYmVyL3JlY2VpcHRgO1xyXG4gICAgbGV0IHBhcmFtcyA9IHtcclxuICAgICAgc2Vzc2lvbklkOiB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnNlc3Npb25JZFxyXG4gICAgfVxyXG4gICAgcmV0dXJuIHRoaXMucG9zdCh1cmwsIHBhcmFtcywgdHJ1ZSkudGhlbihyZXMgPT4ge1xyXG4gICAgICByZXR1cm4gcmVzO1xyXG4gICAgfSlcclxuICB9XG4gIC8vIOiOt+WPluabtOWkmuinhumikeaVsOaNrlxuICBzdGF0aWMgYXN5bmMgdmlkZW9MaXN0KG9wdCkge1xuICAgIGxldCB1cmwgPSBgJHt0aGlzLmJhc2VVcmx9L3ZpZGVvL2xpc3RgO1xuICAgIGxldCBwYXJhbXMgPSB7XG4gICAgICAuLi5vcHQsXG4gICAgICBzZXNzaW9uSWQ6IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuc2Vzc2lvbklkXG4gICAgfVxuICAgIHJldHVybiB0aGlzLnBvc3QodXJsLCBwYXJhbXMsIHRydWUpLnRoZW4ocmVzID0+IHtcbiAgICAgIHJldHVybiByZXM7XG4gICAgfSlcbiAgfVxyXG59XG4iXX0=