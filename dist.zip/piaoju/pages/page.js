"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _api = require('./../api.js');

var _api2 = _interopRequireDefault(_api);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

var _Lang = require('./../../utils/Lang.js');

var _Lang2 = _interopRequireDefault(_Lang);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
  _inherits(Dialog, _wepy$page);

  function Dialog() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, Dialog);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
      navigationBarTitleText: "我的票据"
    }, _this.data = {
      close: "/static/images/close.png",
      homeData: [],
      videoData: [],
      videoIndex: '-1',
      isLoad: false,
      typeId: '',
      pageIndex: 1

    }, _this.methods = {
      proview: function proview(item) {
        if (!item.url) return;
        wx.previewImage({
          current: item.url, // 当前显示图片的http链接
          urls: [item.url] // 需要预览的图片http链接列表
        });
      },
      downLoad: function downLoad(item) {
        if (!item.url) return;
        _Lang2.default.downImg(item.url, function () {});
      }
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(Dialog, [{
    key: "onLoad",
    value: function () {
      var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return _auth2.default.login();

              case 2:
                this.load();

              case 3:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function onLoad() {
        return _ref2.apply(this, arguments);
      }

      return onLoad;
    }()
    // 转发暂时先不开启

  }, {
    key: "onShareAppMessage",
    value: function onShareAppMessage(res) {
      if (res.from === 'button') {
        // 来自页面内转发按钮
        console.log(res.target);
      }
      return {
        title: '',
        path: '/piaoju/pages/page'
      };
    }
  }, {
    key: "load",
    value: function () {
      var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
        return regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                this.loadmore();
                this.$apply();

              case 2:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));

      function load() {
        return _ref3.apply(this, arguments);
      }

      return load;
    }()
  }, {
    key: "showMore",
    value: function showMore() {
      this.isLoad = false;
    }
  }, {
    key: "noMore",
    value: function noMore() {
      this.isLoad = true;
    }
  }, {
    key: "loadmore",
    value: function () {
      var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
        var pageIndex = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 1;
        var params, video;
        return regeneratorRuntime.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                params = {
                  pageIndex: pageIndex
                };
                _context3.next = 3;
                return _api2.default.videoIndex(params);

              case 3:
                video = _context3.sent;

                if (video.receipts.length) {
                  _context3.next = 12;
                  break;
                }

                if (pageIndex == 1) {
                  this.videoData = video.receipts;
                }
                this.pageIndex = pageIndex - 1;
                this.noMore();
                this.$apply();
                return _context3.abrupt("return", false);

              case 12:
                if (pageIndex > 1) this.pageIndex = pageIndex;
                if (pageIndex == 1) {
                  this.videoData = video.receipts;
                  this.noMore();
                } else {
                  this.videoData = this.video.concat(video.receipts);
                }

              case 14:
                this.$apply();

              case 15:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this);
      }));

      function loadmore() {
        return _ref4.apply(this, arguments);
      }

      return loadmore;
    }()
  }, {
    key: "onPullDownRefresh",
    value: function () {
      var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
        return regeneratorRuntime.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                _context4.next = 2;
                return this.loadmore(1);

              case 2:
                this.pageIndex = 1;
                this.$apply();
                wx.stopPullDownRefresh();

              case 5:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, this);
      }));

      function onPullDownRefresh() {
        return _ref5.apply(this, arguments);
      }

      return onPullDownRefresh;
    }()
  }, {
    key: "onReachBottom",
    value: function onReachBottom() {
      this.getMore();
    }
  }, {
    key: "getMore",
    value: function () {
      var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
        return regeneratorRuntime.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                if (!this.loadmoring) {
                  _context5.next = 2;
                  break;
                }

                return _context5.abrupt("return", false);

              case 2:
                this.loadmoring = true;
                this.showMore();
                _context5.next = 6;
                return this.loadmore(this.pageIndex + 1);

              case 6:
                this.loadmoring = false;
                this.$apply();

              case 8:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5, this);
      }));

      function getMore() {
        return _ref6.apply(this, arguments);
      }

      return getMore;
    }()
  }]);

  return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'piaoju/pages/page'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBhZ2UuanMiXSwibmFtZXMiOlsiRGlhbG9nIiwiY29uZmlnIiwibmF2aWdhdGlvbkJhclRpdGxlVGV4dCIsImRhdGEiLCJjbG9zZSIsImhvbWVEYXRhIiwidmlkZW9EYXRhIiwidmlkZW9JbmRleCIsImlzTG9hZCIsInR5cGVJZCIsInBhZ2VJbmRleCIsIm1ldGhvZHMiLCJwcm92aWV3IiwiaXRlbSIsInVybCIsInd4IiwicHJldmlld0ltYWdlIiwiY3VycmVudCIsInVybHMiLCJkb3duTG9hZCIsIkxhbmciLCJkb3duSW1nIiwiYXV0aCIsImxvZ2luIiwibG9hZCIsInJlcyIsImZyb20iLCJjb25zb2xlIiwibG9nIiwidGFyZ2V0IiwidGl0bGUiLCJwYXRoIiwibG9hZG1vcmUiLCIkYXBwbHkiLCJwYXJhbXMiLCJhcGkiLCJ2aWRlbyIsInJlY2VpcHRzIiwibGVuZ3RoIiwibm9Nb3JlIiwiY29uY2F0Iiwic3RvcFB1bGxEb3duUmVmcmVzaCIsImdldE1vcmUiLCJsb2FkbW9yaW5nIiwic2hvd01vcmUiLCJ3ZXB5IiwicGFnZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQ0U7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7Ozs7Ozs7Ozs7O0lBRXFCQSxNOzs7Ozs7Ozs7Ozs7OztzTEFDbkJDLE0sR0FBUztBQUNQQyw4QkFBd0I7QUFEakIsSyxRQUdUQyxJLEdBQU87QUFDTEMsYUFBTywwQkFERjtBQUVMQyxnQkFBVSxFQUZMO0FBR0xDLGlCQUFXLEVBSE47QUFJTEMsa0JBQVksSUFKUDtBQUtMQyxjQUFPLEtBTEY7QUFNTEMsY0FBTyxFQU5GO0FBT0xDLGlCQUFVOztBQVBMLEssUUE4RVBDLE8sR0FBVTtBQUNSQyxhQURRLG1CQUNBQyxJQURBLEVBQ0s7QUFDWCxZQUFHLENBQUNBLEtBQUtDLEdBQVQsRUFBYztBQUNkQyxXQUFHQyxZQUFILENBQWdCO0FBQ2RDLG1CQUFTSixLQUFLQyxHQURBLEVBQ0s7QUFDbkJJLGdCQUFNLENBQUNMLEtBQUtDLEdBQU4sQ0FGUSxDQUVHO0FBRkgsU0FBaEI7QUFJRCxPQVBPO0FBUVJLLGNBUlEsb0JBUUNOLElBUkQsRUFRTTtBQUNaLFlBQUcsQ0FBQ0EsS0FBS0MsR0FBVCxFQUFjO0FBQ2RNLHVCQUFLQyxPQUFMLENBQWFSLEtBQUtDLEdBQWxCLEVBQXNCLFlBQUksQ0FFekIsQ0FGRDtBQUdEO0FBYk8sSzs7Ozs7Ozs7Ozs7O3VCQW5FRlEsZUFBS0MsS0FBTCxFOzs7QUFDTixxQkFBS0MsSUFBTDs7Ozs7Ozs7Ozs7Ozs7OztBQUVGOzs7O3NDQUNrQkMsRyxFQUFLO0FBQ3JCLFVBQUlBLElBQUlDLElBQUosS0FBYSxRQUFqQixFQUEyQjtBQUN6QjtBQUNBQyxnQkFBUUMsR0FBUixDQUFZSCxJQUFJSSxNQUFoQjtBQUNEO0FBQ0QsYUFBTztBQUNMQyxlQUFPLEVBREY7QUFFTEMsY0FBTTtBQUZELE9BQVA7QUFJRDs7Ozs7Ozs7O0FBRUMscUJBQUtDLFFBQUw7QUFDQSxxQkFBS0MsTUFBTDs7Ozs7Ozs7Ozs7Ozs7Ozs7OytCQUVTO0FBQ1QsV0FBS3pCLE1BQUwsR0FBYyxLQUFkO0FBQ0Q7Ozs2QkFDUTtBQUNQLFdBQUtBLE1BQUwsR0FBYyxJQUFkO0FBQ0Q7Ozs7O1lBQ2NFLFMsdUVBQVksQzs7Ozs7O0FBQ3JCd0Isc0IsR0FBUztBQUNYeEIsNkJBQVdBO0FBREEsaUI7O3VCQUdLeUIsY0FBSTVCLFVBQUosQ0FBZTJCLE1BQWYsQzs7O0FBQWRFLHFCOztvQkFDQ0EsTUFBTUMsUUFBTixDQUFlQyxNOzs7OztBQUNsQixvQkFBSTVCLGFBQWEsQ0FBakIsRUFBb0I7QUFDbEIsdUJBQUtKLFNBQUwsR0FBaUI4QixNQUFNQyxRQUF2QjtBQUNEO0FBQ0QscUJBQUszQixTQUFMLEdBQWlCQSxZQUFZLENBQTdCO0FBQ0EscUJBQUs2QixNQUFMO0FBQ0EscUJBQUtOLE1BQUw7a0RBQ08sSzs7O0FBRVAsb0JBQUl2QixZQUFZLENBQWhCLEVBQW1CLEtBQUtBLFNBQUwsR0FBaUJBLFNBQWpCO0FBQ25CLG9CQUFJQSxhQUFhLENBQWpCLEVBQW9CO0FBQ2xCLHVCQUFLSixTQUFMLEdBQWlCOEIsTUFBTUMsUUFBdkI7QUFDQSx1QkFBS0UsTUFBTDtBQUNELGlCQUhELE1BR087QUFDTCx1QkFBS2pDLFNBQUwsR0FBaUIsS0FBSzhCLEtBQUwsQ0FBV0ksTUFBWCxDQUFrQkosTUFBTUMsUUFBeEIsQ0FBakI7QUFDRDs7O0FBRUgscUJBQUtKLE1BQUw7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7dUJBR00sS0FBS0QsUUFBTCxDQUFjLENBQWQsQzs7O0FBQ04scUJBQUt0QixTQUFMLEdBQWlCLENBQWpCO0FBQ0EscUJBQUt1QixNQUFMO0FBQ0FsQixtQkFBRzBCLG1CQUFIOzs7Ozs7Ozs7Ozs7Ozs7Ozs7b0NBRWM7QUFDZCxXQUFLQyxPQUFMO0FBQ0Q7Ozs7Ozs7OztxQkFFSyxLQUFLQyxVOzs7OztrREFDQSxLOzs7QUFFVCxxQkFBS0EsVUFBTCxHQUFrQixJQUFsQjtBQUNBLHFCQUFLQyxRQUFMOzt1QkFDTSxLQUFLWixRQUFMLENBQWMsS0FBS3RCLFNBQUwsR0FBaUIsQ0FBL0IsQzs7O0FBQ04scUJBQUtpQyxVQUFMLEdBQWtCLEtBQWxCO0FBQ0EscUJBQUtWLE1BQUw7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUFoRmdDWSxlQUFLQyxJOztrQkFBcEI5QyxNIiwiZmlsZSI6InBhZ2UuanMiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuICBpbXBvcnQgd2VweSBmcm9tIFwid2VweVwiO1xyXG4gIGltcG9ydCBhcGkgZnJvbSBcIi4uL2FwaS5qc1wiXHJcbiAgaW1wb3J0IGF1dGggZnJvbSBcIkAvYXBpL2F1dGhcIlxuICBpbXBvcnQgTGFuZyBmcm9tIFwiQC91dGlscy9MYW5nXCJcclxuXHJcbiAgZXhwb3J0IGRlZmF1bHQgY2xhc3MgRGlhbG9nIGV4dGVuZHMgd2VweS5wYWdlIHtcclxuICAgIGNvbmZpZyA9IHtcclxuICAgICAgbmF2aWdhdGlvbkJhclRpdGxlVGV4dDogXCLmiJHnmoTnpajmja5cIlxyXG4gICAgfTtcclxuICAgIGRhdGEgPSB7XHJcbiAgICAgIGNsb3NlOiBcIi9zdGF0aWMvaW1hZ2VzL2Nsb3NlLnBuZ1wiLFxyXG4gICAgICBob21lRGF0YTogW10sXHJcbiAgICAgIHZpZGVvRGF0YTogW10sXHJcbiAgICAgIHZpZGVvSW5kZXg6ICctMScsXHJcbiAgICAgIGlzTG9hZDpmYWxzZSxcclxuICAgICAgdHlwZUlkOicnLFxyXG4gICAgICBwYWdlSW5kZXg6MVxyXG5cclxuICAgIH07XHJcbiAgICBhc3luYyBvbkxvYWQoKSB7XHJcbiAgICAgIGF3YWl0IGF1dGgubG9naW4oKVxyXG4gICAgICB0aGlzLmxvYWQoKVxyXG4gICAgfVxyXG4gICAgLy8g6L2s5Y+R5pqC5pe25YWI5LiN5byA5ZCvXHJcbiAgICBvblNoYXJlQXBwTWVzc2FnZShyZXMpIHtcclxuICAgICAgaWYgKHJlcy5mcm9tID09PSAnYnV0dG9uJykge1xyXG4gICAgICAgIC8vIOadpeiHqumhtemdouWGhei9rOWPkeaMiemSrlxyXG4gICAgICAgIGNvbnNvbGUubG9nKHJlcy50YXJnZXQpXHJcbiAgICAgIH1cclxuICAgICAgcmV0dXJuIHtcclxuICAgICAgICB0aXRsZTogJycsXHJcbiAgICAgICAgcGF0aDogJy9waWFvanUvcGFnZXMvcGFnZSdcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgYXN5bmMgbG9hZCgpIHtcclxuICAgICAgdGhpcy5sb2FkbW9yZSgpXHJcbiAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgIH1cclxuICAgIHNob3dNb3JlKCkge1xyXG4gICAgICB0aGlzLmlzTG9hZCA9IGZhbHNlXHJcbiAgICB9XHJcbiAgICBub01vcmUoKSB7XHJcbiAgICAgIHRoaXMuaXNMb2FkID0gdHJ1ZVxyXG4gICAgfVxyXG4gICAgYXN5bmMgbG9hZG1vcmUocGFnZUluZGV4ID0gMSkge1xyXG4gICAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICAgIHBhZ2VJbmRleDogcGFnZUluZGV4XHJcbiAgICAgIH1cclxuICAgICAgbGV0IHZpZGVvID0gYXdhaXQgYXBpLnZpZGVvSW5kZXgocGFyYW1zKVxyXG4gICAgICBpZiAoIXZpZGVvLnJlY2VpcHRzLmxlbmd0aCkge1xyXG4gICAgICAgIGlmIChwYWdlSW5kZXggPT0gMSkge1xyXG4gICAgICAgICAgdGhpcy52aWRlb0RhdGEgPSB2aWRlby5yZWNlaXB0c1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLnBhZ2VJbmRleCA9IHBhZ2VJbmRleCAtIDFcclxuICAgICAgICB0aGlzLm5vTW9yZSgpXHJcbiAgICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgICAgIHJldHVybiBmYWxzZVxyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGlmIChwYWdlSW5kZXggPiAxKSB0aGlzLnBhZ2VJbmRleCA9IHBhZ2VJbmRleFxyXG4gICAgICAgIGlmIChwYWdlSW5kZXggPT0gMSkge1xyXG4gICAgICAgICAgdGhpcy52aWRlb0RhdGEgPSB2aWRlby5yZWNlaXB0c1xuICAgICAgICAgIHRoaXMubm9Nb3JlKClcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgdGhpcy52aWRlb0RhdGEgPSB0aGlzLnZpZGVvLmNvbmNhdCh2aWRlby5yZWNlaXB0cylcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgfVxyXG4gICAgYXN5bmMgb25QdWxsRG93blJlZnJlc2goKSB7XHJcbiAgICAgIGF3YWl0IHRoaXMubG9hZG1vcmUoMSlcclxuICAgICAgdGhpcy5wYWdlSW5kZXggPSAxXHJcbiAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgd3guc3RvcFB1bGxEb3duUmVmcmVzaCgpXHJcbiAgICB9XHJcbiAgICBvblJlYWNoQm90dG9tKCkge1xyXG4gICAgICB0aGlzLmdldE1vcmUoKVxyXG4gICAgfVxyXG4gICAgYXN5bmMgZ2V0TW9yZSgpIHtcclxuICAgICAgaWYgKHRoaXMubG9hZG1vcmluZykge1xyXG4gICAgICAgIHJldHVybiBmYWxzZVxyXG4gICAgICB9XHJcbiAgICAgIHRoaXMubG9hZG1vcmluZyA9IHRydWVcclxuICAgICAgdGhpcy5zaG93TW9yZSgpXHJcbiAgICAgIGF3YWl0IHRoaXMubG9hZG1vcmUodGhpcy5wYWdlSW5kZXggKyAxKVxyXG4gICAgICB0aGlzLmxvYWRtb3JpbmcgPSBmYWxzZVxyXG4gICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICB9XHJcbiAgICBtZXRob2RzID0ge1xyXG4gICAgICBwcm92aWV3KGl0ZW0pe1xuICAgICAgICBpZighaXRlbS51cmwpIHJldHVyblxuICAgICAgICB3eC5wcmV2aWV3SW1hZ2Uoe1xuICAgICAgICAgIGN1cnJlbnQ6IGl0ZW0udXJsLCAvLyDlvZPliY3mmL7npLrlm77niYfnmoRodHRw6ZO+5o6lXG4gICAgICAgICAgdXJsczogW2l0ZW0udXJsXSAvLyDpnIDopoHpooTop4jnmoTlm77niYdodHRw6ZO+5o6l5YiX6KGoXG4gICAgICAgIH0pXG4gICAgICB9LFxuICAgICAgZG93bkxvYWQoaXRlbSl7XG4gICAgICAgIGlmKCFpdGVtLnVybCkgcmV0dXJuXG4gICAgICAgIExhbmcuZG93bkltZyhpdGVtLnVybCwoKT0+e1xuXG4gICAgICAgIH0pXG4gICAgICB9XHJcbiAgICB9O1xyXG4gIH1cclxuIl19