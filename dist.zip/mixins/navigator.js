'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = undefined;

var _wepy = require('./../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var location = function (_wepy$mixin) {
    _inherits(location, _wepy$mixin);

    function location() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, location);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = location.__proto__ || Object.getPrototypeOf(location)).call.apply(_ref, [this].concat(args))), _this), _this.methods = {
            navigator: function navigator(url, type) {
                console.log(url, type);
                if (type == 'none' || !type) {
                    return false;
                }
                if (type == 'navigateTo') {
                    _wepy2.default.navigateTo({
                        url: url
                    });
                } else if (type == 'redirectTo') {
                    _wepy2.default.redirectTo({
                        url: url
                    });
                } else if (type == 'switchTab') {
                    _wepy2.default.switchTab({
                        url: url
                    });
                } else if (type == 'reLaunch') {
                    _wepy2.default.reLaunch({
                        url: url
                    });
                } else if (type == 'web') {
                    _wepy2.default.navigateTo({ url: '/pages/home/web?src=' + encodeURIComponent(url) });
                }
            }
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    return location;
}(_wepy2.default.mixin);

exports.default = location;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5hdmlnYXRvci5qcyJdLCJuYW1lcyI6WyJsb2NhdGlvbiIsIm1ldGhvZHMiLCJuYXZpZ2F0b3IiLCJ1cmwiLCJ0eXBlIiwiY29uc29sZSIsImxvZyIsIndlcHkiLCJuYXZpZ2F0ZVRvIiwicmVkaXJlY3RUbyIsInN3aXRjaFRhYiIsInJlTGF1bmNoIiwiZW5jb2RlVVJJQ29tcG9uZW50IiwibWl4aW4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFBQTs7Ozs7Ozs7Ozs7O0lBQ3FCQSxROzs7Ozs7Ozs7Ozs7Ozs4TEFDakJDLE8sR0FBVTtBQUNOQyxxQkFETSxxQkFDSUMsR0FESixFQUNTQyxJQURULEVBQ2U7QUFDakJDLHdCQUFRQyxHQUFSLENBQVlILEdBQVosRUFBaUJDLElBQWpCO0FBQ0Esb0JBQUlBLFFBQVEsTUFBUixJQUFrQixDQUFDQSxJQUF2QixFQUE2QjtBQUN6QiwyQkFBTyxLQUFQO0FBQ0g7QUFDRCxvQkFBSUEsUUFBUSxZQUFaLEVBQTBCO0FBQ3RCRyxtQ0FBS0MsVUFBTCxDQUFnQjtBQUNaTDtBQURZLHFCQUFoQjtBQUdILGlCQUpELE1BSU8sSUFBSUMsUUFBUSxZQUFaLEVBQTBCO0FBQzdCRyxtQ0FBS0UsVUFBTCxDQUFnQjtBQUNaTjtBQURZLHFCQUFoQjtBQUdILGlCQUpNLE1BSUEsSUFBSUMsUUFBUSxXQUFaLEVBQXlCO0FBQzVCRyxtQ0FBS0csU0FBTCxDQUFlO0FBQ1hQO0FBRFcscUJBQWY7QUFHSCxpQkFKTSxNQUlBLElBQUlDLFFBQVEsVUFBWixFQUF3QjtBQUMzQkcsbUNBQUtJLFFBQUwsQ0FBYztBQUNWUjtBQURVLHFCQUFkO0FBR0gsaUJBSk0sTUFJQSxJQUFJQyxRQUFRLEtBQVosRUFBbUI7QUFDdEJHLG1DQUFLQyxVQUFMLENBQWdCLEVBQUVMLEtBQUsseUJBQXlCUyxtQkFBbUJULEdBQW5CLENBQWhDLEVBQWhCO0FBRUg7QUFDSjtBQTFCSyxTOzs7O0VBRHdCSSxlQUFLTSxLOztrQkFBdEJiLFEiLCJmaWxlIjoibmF2aWdhdG9yLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHdlcHkgZnJvbSAnd2VweSdcclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgbG9jYXRpb24gZXh0ZW5kcyB3ZXB5Lm1peGluIHtcclxuICAgIG1ldGhvZHMgPSB7XHJcbiAgICAgICAgbmF2aWdhdG9yKHVybCwgdHlwZSkge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyh1cmwsIHR5cGUpXHJcbiAgICAgICAgICAgIGlmICh0eXBlID09ICdub25lJyB8fCAhdHlwZSkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKHR5cGUgPT0gJ25hdmlnYXRlVG8nKSB7XHJcbiAgICAgICAgICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICAgICAgICAgIHVybFxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH0gZWxzZSBpZiAodHlwZSA9PSAncmVkaXJlY3RUbycpIHtcclxuICAgICAgICAgICAgICAgIHdlcHkucmVkaXJlY3RUbyh7XHJcbiAgICAgICAgICAgICAgICAgICAgdXJsXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfSBlbHNlIGlmICh0eXBlID09ICdzd2l0Y2hUYWInKSB7XHJcbiAgICAgICAgICAgICAgICB3ZXB5LnN3aXRjaFRhYih7XHJcbiAgICAgICAgICAgICAgICAgICAgdXJsXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfSBlbHNlIGlmICh0eXBlID09ICdyZUxhdW5jaCcpIHtcclxuICAgICAgICAgICAgICAgIHdlcHkucmVMYXVuY2goe1xyXG4gICAgICAgICAgICAgICAgICAgIHVybFxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH0gZWxzZSBpZiAodHlwZSA9PSAnd2ViJykge1xyXG4gICAgICAgICAgICAgICAgd2VweS5uYXZpZ2F0ZVRvKHsgdXJsOiAnL3BhZ2VzL2hvbWUvd2ViP3NyYz0nICsgZW5jb2RlVVJJQ29tcG9uZW50KHVybCkgfSk7XHJcblxyXG4gICAgICAgICAgICB9IFxyXG4gICAgICAgIH1cclxuICAgIH07XHJcbn0iXX0=