"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _api = require('./../api.js');

var _api2 = _interopRequireDefault(_api);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
  _inherits(Dialog, _wepy$page);

  function Dialog() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, Dialog);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
      navigationBarTitleText: "视频中心"
    }, _this.data = {
      close: "/static/images/close.png",
      ColorList: ['red', 'orange', 'yellow', 'olive', 'green', 'cyan', 'blue', 'purple', 'mauve', 'pink', 'brown'],
      homeData: [],
      videoData: [],
      videoIndex: '-1',
      isLoad: false,
      typeId: '',
      pageIndex: 1

    }, _this.methods = {
      startVideo: function startVideo(index) {
        this.startVideo(index);
      },
      TypeFn: function TypeFn(id) {
        this.typeId = id;
        this.loadmore(1);
      }
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(Dialog, [{
    key: "onLoad",
    value: function () {
      var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return _auth2.default.login();

              case 2:
                this.load();

              case 3:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function onLoad() {
        return _ref2.apply(this, arguments);
      }

      return onLoad;
    }()
    // 转发暂时先不开启

  }, {
    key: "onShareAppMessage",
    value: function onShareAppMessage(res) {
      if (res.from === 'button') {
        // 来自页面内转发按钮
        console.log(res.target);
      }
      return {
        title: '',
        path: '/vidio/pages/page'
      };
    }
  }, {
    key: "load",
    value: function () {
      var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
        return regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _context2.next = 2;
                return _api2.default.videoIndex();

              case 2:
                this.homeData = _context2.sent;

                this.videoData = this.homeData.video;
                this.startVideo();
                this.$apply();

              case 6:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));

      function load() {
        return _ref3.apply(this, arguments);
      }

      return load;
    }()
  }, {
    key: "showMore",
    value: function showMore() {
      this.isLoad = false;
    }
  }, {
    key: "noMore",
    value: function noMore() {
      this.isLoad = true;
    }
  }, {
    key: "loadmore",
    value: function () {
      var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(pageIndex) {
        var params, video;
        return regeneratorRuntime.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                params = {
                  typeId: this.typeId,
                  pageIndex: pageIndex
                };
                _context3.next = 3;
                return _api2.default.videoList(params);

              case 3:
                video = _context3.sent;

                if (video.video.length) {
                  _context3.next = 12;
                  break;
                }

                if (pageIndex == 1) {
                  this.videoData = video.video;
                }
                this.pageIndex = pageIndex - 1;
                this.noMore();
                this.$apply();
                return _context3.abrupt("return", false);

              case 12:
                if (pageIndex > 1) this.pageIndex = pageIndex;
                if (pageIndex == 1) {
                  this.videoData = video.video;
                } else {
                  this.videoData = this.video.concat(video.video);
                }

              case 14:
                this.$apply();

              case 15:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this);
      }));

      function loadmore(_x) {
        return _ref4.apply(this, arguments);
      }

      return loadmore;
    }()
  }, {
    key: "startVideo",
    value: function startVideo(index) {
      var _this2 = this;

      if (this.videoIndex != '-1') {
        var videoContextPrev = wx.createVideoContext('video' + this.videoIndex);
        videoContextPrev.stop();
      }
      this.videoIndex = index;
      setTimeout(function () {
        var videoContextCurrent = wx.createVideoContext('video' + index);
        videoContextCurrent.play();
        _this2.$apply();
      }, 100);
    }
  }, {
    key: "onPullDownRefresh",
    value: function () {
      var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
        return regeneratorRuntime.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                _context4.next = 2;
                return this.loadmore(1);

              case 2:
                this.pageIndex = 1;
                this.$apply();
                wx.stopPullDownRefresh();

              case 5:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, this);
      }));

      function onPullDownRefresh() {
        return _ref5.apply(this, arguments);
      }

      return onPullDownRefresh;
    }()
  }, {
    key: "onReachBottom",
    value: function onReachBottom() {
      this.getMore();
    }
  }, {
    key: "getMore",
    value: function () {
      var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
        return regeneratorRuntime.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                if (!this.loadmoring) {
                  _context5.next = 2;
                  break;
                }

                return _context5.abrupt("return", false);

              case 2:
                this.loadmoring = true;
                this.showMore();
                _context5.next = 6;
                return this.loadmore(this.pageIndex + 1);

              case 6:
                this.loadmoring = false;
                this.$apply();

              case 8:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5, this);
      }));

      function getMore() {
        return _ref6.apply(this, arguments);
      }

      return getMore;
    }()
  }]);

  return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'video/pages/page'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBhZ2UuanMiXSwibmFtZXMiOlsiRGlhbG9nIiwiY29uZmlnIiwibmF2aWdhdGlvbkJhclRpdGxlVGV4dCIsImRhdGEiLCJjbG9zZSIsIkNvbG9yTGlzdCIsImhvbWVEYXRhIiwidmlkZW9EYXRhIiwidmlkZW9JbmRleCIsImlzTG9hZCIsInR5cGVJZCIsInBhZ2VJbmRleCIsIm1ldGhvZHMiLCJzdGFydFZpZGVvIiwiaW5kZXgiLCJUeXBlRm4iLCJpZCIsImxvYWRtb3JlIiwiYXV0aCIsImxvZ2luIiwibG9hZCIsInJlcyIsImZyb20iLCJjb25zb2xlIiwibG9nIiwidGFyZ2V0IiwidGl0bGUiLCJwYXRoIiwiYXBpIiwidmlkZW8iLCIkYXBwbHkiLCJwYXJhbXMiLCJ2aWRlb0xpc3QiLCJsZW5ndGgiLCJub01vcmUiLCJjb25jYXQiLCJ2aWRlb0NvbnRleHRQcmV2Iiwid3giLCJjcmVhdGVWaWRlb0NvbnRleHQiLCJzdG9wIiwic2V0VGltZW91dCIsInZpZGVvQ29udGV4dEN1cnJlbnQiLCJwbGF5Iiwic3RvcFB1bGxEb3duUmVmcmVzaCIsImdldE1vcmUiLCJsb2FkbW9yaW5nIiwic2hvd01vcmUiLCJ3ZXB5IiwicGFnZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQ0U7Ozs7QUFDQTs7OztBQUNBOzs7Ozs7Ozs7Ozs7OztJQUVxQkEsTTs7Ozs7Ozs7Ozs7Ozs7c0xBQ25CQyxNLEdBQVM7QUFDUEMsOEJBQXdCO0FBRGpCLEssUUFHVEMsSSxHQUFPO0FBQ0xDLGFBQU8sMEJBREY7QUFFTEMsaUJBQVcsQ0FBQyxLQUFELEVBQ1QsUUFEUyxFQUVULFFBRlMsRUFHVCxPQUhTLEVBSVQsT0FKUyxFQUtULE1BTFMsRUFNVCxNQU5TLEVBT1QsUUFQUyxFQVFULE9BUlMsRUFTVCxNQVRTLEVBVVQsT0FWUyxDQUZOO0FBY0xDLGdCQUFVLEVBZEw7QUFlTEMsaUJBQVcsRUFmTjtBQWdCTEMsa0JBQVksSUFoQlA7QUFpQkxDLGNBQU8sS0FqQkY7QUFrQkxDLGNBQU8sRUFsQkY7QUFtQkxDLGlCQUFVOztBQW5CTCxLLFFBd0dQQyxPLEdBQVU7QUFDUkMsZ0JBRFEsc0JBQ0dDLEtBREgsRUFDVTtBQUNoQixhQUFLRCxVQUFMLENBQWdCQyxLQUFoQjtBQUNELE9BSE87QUFJUkMsWUFKUSxrQkFJREMsRUFKQyxFQUlFO0FBQ1IsYUFBS04sTUFBTCxHQUFjTSxFQUFkO0FBQ0EsYUFBS0MsUUFBTCxDQUFjLENBQWQ7QUFDRDtBQVBPLEs7Ozs7Ozs7Ozs7Ozt1QkFqRkZDLGVBQUtDLEtBQUwsRTs7O0FBQ04scUJBQUtDLElBQUw7Ozs7Ozs7Ozs7Ozs7Ozs7QUFFRjs7OztzQ0FDa0JDLEcsRUFBSztBQUNyQixVQUFJQSxJQUFJQyxJQUFKLEtBQWEsUUFBakIsRUFBMkI7QUFDekI7QUFDQUMsZ0JBQVFDLEdBQVIsQ0FBWUgsSUFBSUksTUFBaEI7QUFDRDtBQUNELGFBQU87QUFDTEMsZUFBTyxFQURGO0FBRUxDLGNBQU07QUFGRCxPQUFQO0FBSUQ7Ozs7Ozs7Ozs7dUJBRXVCQyxjQUFJcEIsVUFBSixFOzs7QUFBdEIscUJBQUtGLFE7O0FBQ0wscUJBQUtDLFNBQUwsR0FBaUIsS0FBS0QsUUFBTCxDQUFjdUIsS0FBL0I7QUFDQSxxQkFBS2hCLFVBQUw7QUFDQSxxQkFBS2lCLE1BQUw7Ozs7Ozs7Ozs7Ozs7Ozs7OzsrQkFFUztBQUNULFdBQUtyQixNQUFMLEdBQWMsS0FBZDtBQUNEOzs7NkJBQ1E7QUFDUCxXQUFLQSxNQUFMLEdBQWMsSUFBZDtBQUNEOzs7OzRGQUNjRSxTOzs7Ozs7QUFDVG9CLHNCLEdBQVM7QUFDWHJCLDBCQUFRLEtBQUtBLE1BREY7QUFFWEMsNkJBQVdBO0FBRkEsaUI7O3VCQUlLaUIsY0FBSUksU0FBSixDQUFjRCxNQUFkLEM7OztBQUFkRixxQjs7b0JBQ0NBLE1BQU1BLEtBQU4sQ0FBWUksTTs7Ozs7QUFDZixvQkFBSXRCLGFBQWEsQ0FBakIsRUFBb0I7QUFDbEIsdUJBQUtKLFNBQUwsR0FBaUJzQixNQUFNQSxLQUF2QjtBQUNEO0FBQ0QscUJBQUtsQixTQUFMLEdBQWlCQSxZQUFZLENBQTdCO0FBQ0EscUJBQUt1QixNQUFMO0FBQ0EscUJBQUtKLE1BQUw7a0RBQ08sSzs7O0FBRVAsb0JBQUluQixZQUFZLENBQWhCLEVBQW1CLEtBQUtBLFNBQUwsR0FBaUJBLFNBQWpCO0FBQ25CLG9CQUFJQSxhQUFhLENBQWpCLEVBQW9CO0FBQ2xCLHVCQUFLSixTQUFMLEdBQWlCc0IsTUFBTUEsS0FBdkI7QUFDRCxpQkFGRCxNQUVPO0FBQ0wsdUJBQUt0QixTQUFMLEdBQWlCLEtBQUtzQixLQUFMLENBQVdNLE1BQVgsQ0FBa0JOLE1BQU1BLEtBQXhCLENBQWpCO0FBQ0Q7OztBQUVILHFCQUFLQyxNQUFMOzs7Ozs7Ozs7Ozs7Ozs7Ozs7K0JBRVNoQixLLEVBQU87QUFBQTs7QUFDaEIsVUFBSSxLQUFLTixVQUFMLElBQW1CLElBQXZCLEVBQTZCO0FBQzNCLFlBQUk0QixtQkFBbUJDLEdBQUdDLGtCQUFILENBQXNCLFVBQVUsS0FBSzlCLFVBQXJDLENBQXZCO0FBQ0E0Qix5QkFBaUJHLElBQWpCO0FBQ0Q7QUFDRCxXQUFLL0IsVUFBTCxHQUFrQk0sS0FBbEI7QUFDQTBCLGlCQUFXLFlBQU07QUFDZixZQUFJQyxzQkFBc0JKLEdBQUdDLGtCQUFILENBQXNCLFVBQVV4QixLQUFoQyxDQUExQjtBQUNBMkIsNEJBQW9CQyxJQUFwQjtBQUNBLGVBQUtaLE1BQUw7QUFDRCxPQUpELEVBSUcsR0FKSDtBQUtEOzs7Ozs7Ozs7O3VCQUVPLEtBQUtiLFFBQUwsQ0FBYyxDQUFkLEM7OztBQUNOLHFCQUFLTixTQUFMLEdBQWlCLENBQWpCO0FBQ0EscUJBQUttQixNQUFMO0FBQ0FPLG1CQUFHTSxtQkFBSDs7Ozs7Ozs7Ozs7Ozs7Ozs7O29DQUVjO0FBQ2QsV0FBS0MsT0FBTDtBQUNEOzs7Ozs7Ozs7cUJBRUssS0FBS0MsVTs7Ozs7a0RBQ0EsSzs7O0FBRVQscUJBQUtBLFVBQUwsR0FBa0IsSUFBbEI7QUFDQSxxQkFBS0MsUUFBTDs7dUJBQ00sS0FBSzdCLFFBQUwsQ0FBYyxLQUFLTixTQUFMLEdBQWlCLENBQS9CLEM7OztBQUNOLHFCQUFLa0MsVUFBTCxHQUFrQixLQUFsQjtBQUNBLHFCQUFLZixNQUFMOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBMUdnQ2lCLGVBQUtDLEk7O2tCQUFwQmhELE0iLCJmaWxlIjoicGFnZS5qcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4gIGltcG9ydCB3ZXB5IGZyb20gXCJ3ZXB5XCI7XHJcbiAgaW1wb3J0IGFwaSBmcm9tIFwiLi4vYXBpLmpzXCJcclxuICBpbXBvcnQgYXV0aCBmcm9tIFwiQC9hcGkvYXV0aFwiXHJcblxyXG4gIGV4cG9ydCBkZWZhdWx0IGNsYXNzIERpYWxvZyBleHRlbmRzIHdlcHkucGFnZSB7XHJcbiAgICBjb25maWcgPSB7XHJcbiAgICAgIG5hdmlnYXRpb25CYXJUaXRsZVRleHQ6IFwi6KeG6aKR5Lit5b+DXCJcclxuICAgIH07XHJcbiAgICBkYXRhID0ge1xyXG4gICAgICBjbG9zZTogXCIvc3RhdGljL2ltYWdlcy9jbG9zZS5wbmdcIixcclxuICAgICAgQ29sb3JMaXN0OiBbJ3JlZCcsXHJcbiAgICAgICAgJ29yYW5nZScsXHJcbiAgICAgICAgJ3llbGxvdycsXHJcbiAgICAgICAgJ29saXZlJyxcclxuICAgICAgICAnZ3JlZW4nLFxyXG4gICAgICAgICdjeWFuJyxcclxuICAgICAgICAnYmx1ZScsXHJcbiAgICAgICAgJ3B1cnBsZScsXHJcbiAgICAgICAgJ21hdXZlJyxcclxuICAgICAgICAncGluaycsXHJcbiAgICAgICAgJ2Jyb3duJ1xyXG4gICAgICBdLFxyXG4gICAgICBob21lRGF0YTogW10sXHJcbiAgICAgIHZpZGVvRGF0YTogW10sXHJcbiAgICAgIHZpZGVvSW5kZXg6ICctMScsXG4gICAgICBpc0xvYWQ6ZmFsc2UsXG4gICAgICB0eXBlSWQ6JycsXG4gICAgICBwYWdlSW5kZXg6MVxyXG5cclxuICAgIH07XHJcbiAgICBhc3luYyBvbkxvYWQoKSB7XHJcbiAgICAgIGF3YWl0IGF1dGgubG9naW4oKVxyXG4gICAgICB0aGlzLmxvYWQoKVxyXG4gICAgfVxuICAgIC8vIOi9rOWPkeaaguaXtuWFiOS4jeW8gOWQr1xuICAgIG9uU2hhcmVBcHBNZXNzYWdlKHJlcykge1xuICAgICAgaWYgKHJlcy5mcm9tID09PSAnYnV0dG9uJykge1xuICAgICAgICAvLyDmnaXoh6rpobXpnaLlhoXovazlj5HmjInpkq5cbiAgICAgICAgY29uc29sZS5sb2cocmVzLnRhcmdldClcbiAgICAgIH1cbiAgICAgIHJldHVybiB7XG4gICAgICAgIHRpdGxlOiAnJyxcbiAgICAgICAgcGF0aDogJy92aWRpby9wYWdlcy9wYWdlJ1xuICAgICAgfVxuICAgIH1cclxuICAgIGFzeW5jIGxvYWQoKSB7XHJcbiAgICAgIHRoaXMuaG9tZURhdGEgPSBhd2FpdCBhcGkudmlkZW9JbmRleCgpXHJcbiAgICAgIHRoaXMudmlkZW9EYXRhID0gdGhpcy5ob21lRGF0YS52aWRlb1xyXG4gICAgICB0aGlzLnN0YXJ0VmlkZW8oKVxyXG4gICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICB9XG4gICAgc2hvd01vcmUoKSB7XG4gICAgICB0aGlzLmlzTG9hZCA9IGZhbHNlXG4gICAgfVxuICAgIG5vTW9yZSgpIHtcbiAgICAgIHRoaXMuaXNMb2FkID0gdHJ1ZVxuICAgIH1cclxuICAgIGFzeW5jIGxvYWRtb3JlKHBhZ2VJbmRleCkge1xyXG4gICAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICAgIHR5cGVJZDogdGhpcy50eXBlSWQsXHJcbiAgICAgICAgcGFnZUluZGV4OiBwYWdlSW5kZXhcclxuICAgICAgfVxyXG4gICAgICBsZXQgdmlkZW8gPSBhd2FpdCBhcGkudmlkZW9MaXN0KHBhcmFtcylcclxuICAgICAgaWYgKCF2aWRlby52aWRlby5sZW5ndGgpIHtcclxuICAgICAgICBpZiAocGFnZUluZGV4ID09IDEpIHtcclxuICAgICAgICAgIHRoaXMudmlkZW9EYXRhID0gdmlkZW8udmlkZW9cclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5wYWdlSW5kZXggPSBwYWdlSW5kZXggLSAxXHJcbiAgICAgICAgdGhpcy5ub01vcmUoKVxyXG4gICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBpZiAocGFnZUluZGV4ID4gMSkgdGhpcy5wYWdlSW5kZXggPSBwYWdlSW5kZXhcclxuICAgICAgICBpZiAocGFnZUluZGV4ID09IDEpIHtcclxuICAgICAgICAgIHRoaXMudmlkZW9EYXRhID0gdmlkZW8udmlkZW9cclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgdGhpcy52aWRlb0RhdGEgPSB0aGlzLnZpZGVvLmNvbmNhdCh2aWRlby52aWRlbylcclxuICAgICAgICB9XHJcbiAgICAgIH1cbiAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgIH1cclxuICAgIHN0YXJ0VmlkZW8oaW5kZXgpIHtcclxuICAgICAgaWYgKHRoaXMudmlkZW9JbmRleCAhPSAnLTEnKSB7XHJcbiAgICAgICAgdmFyIHZpZGVvQ29udGV4dFByZXYgPSB3eC5jcmVhdGVWaWRlb0NvbnRleHQoJ3ZpZGVvJyArIHRoaXMudmlkZW9JbmRleClcclxuICAgICAgICB2aWRlb0NvbnRleHRQcmV2LnN0b3AoKVxyXG4gICAgICB9XHJcbiAgICAgIHRoaXMudmlkZW9JbmRleCA9IGluZGV4XHJcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgIHZhciB2aWRlb0NvbnRleHRDdXJyZW50ID0gd3guY3JlYXRlVmlkZW9Db250ZXh0KCd2aWRlbycgKyBpbmRleClcclxuICAgICAgICB2aWRlb0NvbnRleHRDdXJyZW50LnBsYXkoKVxyXG4gICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgfSwgMTAwKVxyXG4gICAgfVxuICAgIGFzeW5jIG9uUHVsbERvd25SZWZyZXNoKCkge1xuICAgICAgYXdhaXQgdGhpcy5sb2FkbW9yZSgxKVxuICAgICAgdGhpcy5wYWdlSW5kZXggPSAxXG4gICAgICB0aGlzLiRhcHBseSgpXG4gICAgICB3eC5zdG9wUHVsbERvd25SZWZyZXNoKClcbiAgICB9XG4gICAgb25SZWFjaEJvdHRvbSgpIHtcbiAgICAgIHRoaXMuZ2V0TW9yZSgpXG4gICAgfVxuICAgIGFzeW5jIGdldE1vcmUoKSB7XG4gICAgICBpZiAodGhpcy5sb2FkbW9yaW5nKSB7XG4gICAgICAgIHJldHVybiBmYWxzZVxuICAgICAgfVxuICAgICAgdGhpcy5sb2FkbW9yaW5nID0gdHJ1ZVxuICAgICAgdGhpcy5zaG93TW9yZSgpXG4gICAgICBhd2FpdCB0aGlzLmxvYWRtb3JlKHRoaXMucGFnZUluZGV4ICsgMSlcbiAgICAgIHRoaXMubG9hZG1vcmluZyA9IGZhbHNlXG4gICAgICB0aGlzLiRhcHBseSgpXG4gICAgfVxyXG4gICAgbWV0aG9kcyA9IHtcclxuICAgICAgc3RhcnRWaWRlbyhpbmRleCkge1xyXG4gICAgICAgIHRoaXMuc3RhcnRWaWRlbyhpbmRleClcclxuICAgICAgfSxcbiAgICAgIFR5cGVGbihpZCl7XG4gICAgICAgIHRoaXMudHlwZUlkID0gaWRcbiAgICAgICAgdGhpcy5sb2FkbW9yZSgxKVxuICAgICAgfVxyXG4gICAgfTtcclxuICB9XHJcbiJdfQ==