console.log('WePY开启错误监控');
