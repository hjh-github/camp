'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
var SAVE = exports.SAVE = 'SAVE';
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNhY2hlLmpzIl0sIm5hbWVzIjpbIlNBVkUiXSwibWFwcGluZ3MiOiI7Ozs7O0FBQU8sSUFBTUEsc0JBQU8sTUFBYiIsImZpbGUiOiJjYWNoZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBjb25zdCBTQVZFID0gJ1NBVkUnO1xyXG4iXX0=