'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _wepyRedux = require('./../npm/wepy-redux/lib/index.js');

var _cache = require('./types/cache.js');

var _config = require('./../api/config.js');

var _config2 = _interopRequireDefault(_config);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var store = (0, _wepyRedux.getStore)();
// 是否调试
var IS_DEBUG = true;

/**
 * 构造取值器
 */
var get = function get(key) {
  return function (state) {
    return state.cache[key];
  };
};

/**
 * 保存数据
 */
var save = function save(key, data) {
  if (IS_DEBUG) {
    console.info('[store] save key=' + key + ', data=', data);
  }
  store.dispatch({
    type: _cache.SAVE,
    payload: {
      key: key,
      value: data
    }
  });
};

exports.default = { get: get, save: save };
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInV0aWxzLmpzIl0sIm5hbWVzIjpbInN0b3JlIiwiSVNfREVCVUciLCJnZXQiLCJzdGF0ZSIsImNhY2hlIiwia2V5Iiwic2F2ZSIsImRhdGEiLCJjb25zb2xlIiwiaW5mbyIsImRpc3BhdGNoIiwidHlwZSIsIlNBVkUiLCJwYXlsb2FkIiwidmFsdWUiXSwibWFwcGluZ3MiOiI7Ozs7OztBQUFBOztBQUNBOztBQUNBOzs7Ozs7QUFHQSxJQUFNQSxRQUFRLDBCQUFkO0FBQ0E7QUFDQSxJQUFNQyxXQUFXLElBQWpCOztBQUdBOzs7QUFHQSxJQUFNQyxNQUFNLFNBQU5BLEdBQU0sTUFBTztBQUNqQixTQUFPLFVBQUNDLEtBQUQsRUFBVztBQUNoQixXQUFPQSxNQUFNQyxLQUFOLENBQVlDLEdBQVosQ0FBUDtBQUNELEdBRkQ7QUFHRCxDQUpEOztBQU1BOzs7QUFHQSxJQUFNQyxPQUFPLFNBQVBBLElBQU8sQ0FBQ0QsR0FBRCxFQUFNRSxJQUFOLEVBQWU7QUFDMUIsTUFBSU4sUUFBSixFQUFjO0FBQ1pPLFlBQVFDLElBQVIsdUJBQWlDSixHQUFqQyxjQUErQ0UsSUFBL0M7QUFDRDtBQUNEUCxRQUFNVSxRQUFOLENBQWU7QUFDYkMsVUFBTUMsV0FETztBQUViQyxhQUFTO0FBQ1BSLFdBQUtBLEdBREU7QUFFUFMsYUFBT1A7QUFGQTtBQUZJLEdBQWY7QUFPRCxDQVhEOztrQkFjZSxFQUFDTCxRQUFELEVBQU1JLFVBQU4sRSIsImZpbGUiOiJ1dGlscy5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGdldFN0b3JlIH0gZnJvbSAnd2VweS1yZWR1eCc7XHJcbmltcG9ydCB7IFNBVkUgfSBmcm9tICcuL3R5cGVzL2NhY2hlJztcclxuaW1wb3J0IGNvbmZpZyBmcm9tICcuLi9hcGkvY29uZmlnJztcclxuXHJcblxyXG5jb25zdCBzdG9yZSA9IGdldFN0b3JlKCk7XHJcbi8vIOaYr+WQpuiwg+ivlVxyXG5jb25zdCBJU19ERUJVRyA9IHRydWU7XHJcblxyXG5cclxuLyoqXHJcbiAqIOaehOmAoOWPluWAvOWZqFxyXG4gKi9cclxuY29uc3QgZ2V0ID0ga2V5ID0+IHtcclxuICByZXR1cm4gKHN0YXRlKSA9PiB7XHJcbiAgICByZXR1cm4gc3RhdGUuY2FjaGVba2V5XVxyXG4gIH1cclxufTtcclxuXHJcbi8qKlxyXG4gKiDkv53lrZjmlbDmja5cclxuICovXHJcbmNvbnN0IHNhdmUgPSAoa2V5LCBkYXRhKSA9PiB7XHJcbiAgaWYgKElTX0RFQlVHKSB7XHJcbiAgICBjb25zb2xlLmluZm8oYFtzdG9yZV0gc2F2ZSBrZXk9JHtrZXl9LCBkYXRhPWAsIGRhdGEpO1xyXG4gIH1cclxuICBzdG9yZS5kaXNwYXRjaCh7XHJcbiAgICB0eXBlOiBTQVZFLFxyXG4gICAgcGF5bG9hZDoge1xyXG4gICAgICBrZXk6IGtleSxcclxuICAgICAgdmFsdWU6IGRhdGFcclxuICAgIH1cclxuICB9KTtcclxufTtcclxuXHJcblxyXG5leHBvcnQgZGVmYXVsdCB7Z2V0LCBzYXZlfVxyXG4iXX0=