'use strict';

module.exports = Behavior({
    behaviors: [],
    properties: {
        onlyTime: {
            type: Boolean,
            value: false
        },
        instyle: {
            type: String,
            value: ''
        },
        time: {
            type: Date,
            value: new Date().getTime() + 86400000
        },
        status: {
            type: Boolean,
            value: true,
            observer: function observer(newVal, oldVal, changedPath) {
                if (newVal) {
                    this.init();
                } else if (!newVal) {
                    clearInterval(this.data.timer);
                }
            }
        },
        timeType: {
            type: String,
            value: 'datetime'
        },
        format: {
            type: String,
            value: '{%d}天{%h}时{%m}分{%s}秒'
        },
        isZeroPadd: {
            type: Boolean,
            value: true
        }
    },
    data: {
        initAddTime: 0,
        timer: null,
        date: [],
        diffSecond: 0,
        refresh: false
    },
    ready: function ready() {
        this.getLatestTime();
    },

    detached: function detached() {
        clearInterval(this.data.timer);
    },

    pageLifetimes: {
        hide: function hide() {
            clearInterval(this.data.timer);
        }
    },

    methods: {
        // 自动补零
        zeroPadding: function zeroPadding(num) {
            num = num.toString();
            return num[1] ? num : '0' + num;
        },
        init: function init() {
            var _this = this;

            clearInterval(this.data.timer);
            var timer = setTimeout(function () {
                _this.getLatestTime.call(_this);
            }, 1000);
            this.setData({
                timer: timer
            });
        },
        getLatestTime: function getLatestTime() {
            var _data = this.data,
                time = _data.time,
                status = _data.status,
                timeType = _data.timeType,
                initAddTime = _data.initAddTime;

            console.log(time);
            // 兼容ios
            if (!new Date(time).getTime()) {
                time = time.replace(/-/g, '/');
                // console.log(new Date(time).getTime())
            }
            var countDownTime = timeType === 'second' ? time : Math.ceil((new Date(time).getTime() - new Date().getTime()) / 1000);
            if (countDownTime < 0 && timeType !== 'second') {
                this._getTimeValue(0);
                this.CountdownEnd();
                return;
            }
            if (countDownTime - initAddTime > 0) {
                this.getLatestForCountDown(countDownTime);
            } else if (countDownTime - initAddTime < 0) {
                this.getLatestForAddTime(countDownTime);
            } else if (countDownTime - initAddTime === 0) {
                if (initAddTime <= 0) {
                    this._getTimeValue(countDownTime);
                }
                this.CountdownEnd();
            }
            if (status && countDownTime - initAddTime !== 0) {
                this.init.call(this);
            }
        },
        getLatestForAddTime: function getLatestForAddTime(countDownTime) {
            var initAddTime = this.data.initAddTime;

            if (initAddTime !== Math.abs(countDownTime)) {
                initAddTime++;
                this._getTimeValue(initAddTime);
                this.setData({
                    initAddTime: initAddTime
                });
            }
        },
        getLatestForCountDown: function getLatestForCountDown(countDownTime) {
            this._getTimeValue(countDownTime);
            this.setData({
                time: this.data.timeType === 'second' ? --countDownTime : this.data.time
            });
        },
        _getTimeValue: function _getTimeValue(countDownTime) {
            var _this2 = this;

            var format = this.data.format;

            var date = [];
            var fomatArray = format.split(/(\{.*?\})/);
            var formatType = [{
                key: '{%d}',
                type: 'day',
                count: 86400
            }, {
                key: '{%h}',
                type: 'hour',
                count: 3600
            }, {
                key: '{%m}',
                type: 'minute',
                count: 60
            }, {
                key: '{%s}',
                type: 'second',
                count: 1
            }];
            var diffSecond = countDownTime,
                lastTime = 0;

            formatType.forEach(function (format) {
                var index = _this2._findTimeName(fomatArray, format.key);
                if (index === -1) return;
                var name = fomatArray[index];
                var formatItem = {
                    type: format.type,
                    name: name,
                    value: parseInt(diffSecond / format.count)
                };
                lastTime = lastTime + parseInt(diffSecond / format.count);
                if (_this2.data.isZeroPadd) {
                    formatItem.value = _this2.zeroPadding(formatItem.value);
                }
                diffSecond %= format.count;
                date.push(formatItem);
            });
            if (lastTime > 0) {
                this.setData({
                    refresh: true
                });
            }
            if (lastTime == 0 && this.data.refresh) {
                setTimeout(function () {
                    wx.startPullDownRefresh();
                }, 3000);
            }
            this.setData({
                date: date,
                diffSecond: lastTime
            });
            return date;
        },
        _findTimeName: function _findTimeName(fomatArray, str) {
            var index = fomatArray.indexOf(str);
            if (index === -1) return -1;
            return index + 1;
        },
        CountdownEnd: function CountdownEnd() {
            this.triggerEvent("linend", {});
        }
    }
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvdW50ZG93bi5qcyJdLCJuYW1lcyI6WyJtb2R1bGUiLCJleHBvcnRzIiwiQmVoYXZpb3IiLCJiZWhhdmlvcnMiLCJwcm9wZXJ0aWVzIiwib25seVRpbWUiLCJ0eXBlIiwiQm9vbGVhbiIsInZhbHVlIiwiaW5zdHlsZSIsIlN0cmluZyIsInRpbWUiLCJEYXRlIiwiZ2V0VGltZSIsInN0YXR1cyIsIm9ic2VydmVyIiwibmV3VmFsIiwib2xkVmFsIiwiY2hhbmdlZFBhdGgiLCJpbml0IiwiY2xlYXJJbnRlcnZhbCIsImRhdGEiLCJ0aW1lciIsInRpbWVUeXBlIiwiZm9ybWF0IiwiaXNaZXJvUGFkZCIsImluaXRBZGRUaW1lIiwiZGF0ZSIsImRpZmZTZWNvbmQiLCJyZWZyZXNoIiwicmVhZHkiLCJnZXRMYXRlc3RUaW1lIiwiZGV0YWNoZWQiLCJwYWdlTGlmZXRpbWVzIiwiaGlkZSIsIm1ldGhvZHMiLCJ6ZXJvUGFkZGluZyIsIm51bSIsInRvU3RyaW5nIiwic2V0VGltZW91dCIsImNhbGwiLCJzZXREYXRhIiwiY29uc29sZSIsImxvZyIsInJlcGxhY2UiLCJjb3VudERvd25UaW1lIiwiTWF0aCIsImNlaWwiLCJfZ2V0VGltZVZhbHVlIiwiQ291bnRkb3duRW5kIiwiZ2V0TGF0ZXN0Rm9yQ291bnREb3duIiwiZ2V0TGF0ZXN0Rm9yQWRkVGltZSIsImFicyIsImZvbWF0QXJyYXkiLCJzcGxpdCIsImZvcm1hdFR5cGUiLCJrZXkiLCJjb3VudCIsImxhc3RUaW1lIiwiZm9yRWFjaCIsImluZGV4IiwiX2ZpbmRUaW1lTmFtZSIsIm5hbWUiLCJmb3JtYXRJdGVtIiwicGFyc2VJbnQiLCJwdXNoIiwid3giLCJzdGFydFB1bGxEb3duUmVmcmVzaCIsInN0ciIsImluZGV4T2YiLCJ0cmlnZ2VyRXZlbnQiXSwibWFwcGluZ3MiOiI7O0FBQUFBLE9BQU9DLE9BQVAsR0FBaUJDLFNBQVM7QUFDdEJDLGVBQVcsRUFEVztBQUV0QkMsZ0JBQVk7QUFDUkMsa0JBQVM7QUFDTEMsa0JBQU1DLE9BREQ7QUFFTEMsbUJBQU87QUFGRixTQUREO0FBS1JDLGlCQUFRO0FBQ0pILGtCQUFNSSxNQURGO0FBRUpGLG1CQUFPO0FBRkgsU0FMQTtBQVNSRyxjQUFNO0FBQ0ZMLGtCQUFNTSxJQURKO0FBRUZKLG1CQUFPLElBQUlJLElBQUosR0FBV0MsT0FBWCxLQUF1QjtBQUY1QixTQVRFO0FBYVJDLGdCQUFRO0FBQ0pSLGtCQUFNQyxPQURGO0FBRUpDLG1CQUFPLElBRkg7QUFHSk8sc0JBQVUsa0JBQVVDLE1BQVYsRUFBa0JDLE1BQWxCLEVBQTBCQyxXQUExQixFQUF1QztBQUM3QyxvQkFBSUYsTUFBSixFQUFZO0FBQ1IseUJBQUtHLElBQUw7QUFDSCxpQkFGRCxNQUVPLElBQUksQ0FBQ0gsTUFBTCxFQUFhO0FBQ2hCSSxrQ0FBYyxLQUFLQyxJQUFMLENBQVVDLEtBQXhCO0FBQ0g7QUFDSjtBQVRHLFNBYkE7QUF3QlJDLGtCQUFVO0FBQ05qQixrQkFBTUksTUFEQTtBQUVORixtQkFBTztBQUZELFNBeEJGO0FBNEJSZ0IsZ0JBQVE7QUFDSmxCLGtCQUFNSSxNQURGO0FBRUpGLG1CQUFPO0FBRkgsU0E1QkE7QUFnQ1JpQixvQkFBWTtBQUNSbkIsa0JBQU1DLE9BREU7QUFFUkMsbUJBQU87QUFGQztBQWhDSixLQUZVO0FBdUN0QmEsVUFBTTtBQUNGSyxxQkFBYSxDQURYO0FBRUZKLGVBQU8sSUFGTDtBQUdGSyxjQUFNLEVBSEo7QUFJRkMsb0JBQVksQ0FKVjtBQUtGQyxpQkFBUztBQUxQLEtBdkNnQjtBQThDdEJDLFdBQU8saUJBQVk7QUFDZixhQUFLQyxhQUFMO0FBQ0gsS0FoRHFCOztBQWtEdEJDLGNBQVUsb0JBQVk7QUFDbEJaLHNCQUFjLEtBQUtDLElBQUwsQ0FBVUMsS0FBeEI7QUFDSCxLQXBEcUI7O0FBc0R0QlcsbUJBQWU7QUFDWEMsWUFEVyxrQkFDSjtBQUNIZCwwQkFBYyxLQUFLQyxJQUFMLENBQVVDLEtBQXhCO0FBQ0g7QUFIVSxLQXRETzs7QUE0RHRCYSxhQUFTO0FBQ0w7QUFDQUMsbUJBRkssdUJBRU9DLEdBRlAsRUFFWTtBQUNiQSxrQkFBTUEsSUFBSUMsUUFBSixFQUFOO0FBQ0EsbUJBQU9ELElBQUksQ0FBSixJQUFTQSxHQUFULEdBQWUsTUFBTUEsR0FBNUI7QUFDSCxTQUxJO0FBT0xsQixZQVBLLGtCQU9FO0FBQUE7O0FBQ0hDLDBCQUFjLEtBQUtDLElBQUwsQ0FBVUMsS0FBeEI7QUFDQSxnQkFBTUEsUUFBUWlCLFdBQVcsWUFBTTtBQUMzQixzQkFBS1IsYUFBTCxDQUFtQlMsSUFBbkIsQ0FBd0IsS0FBeEI7QUFDSCxhQUZhLEVBRVgsSUFGVyxDQUFkO0FBR0EsaUJBQUtDLE9BQUwsQ0FBYTtBQUNUbkI7QUFEUyxhQUFiO0FBR0gsU0FmSTtBQWlCTFMscUJBakJLLDJCQWlCVztBQUFBLHdCQU1SLEtBQUtWLElBTkc7QUFBQSxnQkFFUlYsSUFGUSxTQUVSQSxJQUZRO0FBQUEsZ0JBR1JHLE1BSFEsU0FHUkEsTUFIUTtBQUFBLGdCQUlSUyxRQUpRLFNBSVJBLFFBSlE7QUFBQSxnQkFLUkcsV0FMUSxTQUtSQSxXQUxROztBQU9aZ0Isb0JBQVFDLEdBQVIsQ0FBWWhDLElBQVo7QUFDQTtBQUNBLGdCQUFJLENBQUMsSUFBSUMsSUFBSixDQUFTRCxJQUFULEVBQWVFLE9BQWYsRUFBTCxFQUErQjtBQUMzQkYsdUJBQU9BLEtBQUtpQyxPQUFMLENBQWEsSUFBYixFQUFtQixHQUFuQixDQUFQO0FBQ0E7QUFDSDtBQUNELGdCQUFJQyxnQkFBZ0J0QixhQUFhLFFBQWIsR0FDaEJaLElBRGdCLEdBRWhCbUMsS0FBS0MsSUFBTCxDQUFVLENBQUMsSUFBSW5DLElBQUosQ0FBU0QsSUFBVCxFQUFlRSxPQUFmLEtBQTJCLElBQUlELElBQUosR0FBV0MsT0FBWCxFQUE1QixJQUFvRCxJQUE5RCxDQUZKO0FBR0EsZ0JBQUlnQyxnQkFBZ0IsQ0FBaEIsSUFBcUJ0QixhQUFhLFFBQXRDLEVBQWdEO0FBQzVDLHFCQUFLeUIsYUFBTCxDQUFtQixDQUFuQjtBQUNBLHFCQUFLQyxZQUFMO0FBQ0E7QUFDSDtBQUNELGdCQUFJSixnQkFBZ0JuQixXQUFoQixHQUE4QixDQUFsQyxFQUFxQztBQUNqQyxxQkFBS3dCLHFCQUFMLENBQTJCTCxhQUEzQjtBQUNILGFBRkQsTUFFTyxJQUFJQSxnQkFBZ0JuQixXQUFoQixHQUE4QixDQUFsQyxFQUFxQztBQUN4QyxxQkFBS3lCLG1CQUFMLENBQXlCTixhQUF6QjtBQUNILGFBRk0sTUFFQSxJQUFJQSxnQkFBZ0JuQixXQUFoQixLQUFnQyxDQUFwQyxFQUF1QztBQUMxQyxvQkFBSUEsZUFBZSxDQUFuQixFQUFzQjtBQUNsQix5QkFBS3NCLGFBQUwsQ0FBbUJILGFBQW5CO0FBQ0g7QUFDRCxxQkFBS0ksWUFBTDtBQUNIO0FBQ0QsZ0JBQUluQyxVQUFVK0IsZ0JBQWdCbkIsV0FBaEIsS0FBZ0MsQ0FBOUMsRUFBaUQ7QUFDN0MscUJBQUtQLElBQUwsQ0FBVXFCLElBQVYsQ0FBZSxJQUFmO0FBQ0g7QUFDSixTQW5ESTtBQXFETFcsMkJBckRLLCtCQXFEZU4sYUFyRGYsRUFxRDhCO0FBQUEsZ0JBRTNCbkIsV0FGMkIsR0FHM0IsS0FBS0wsSUFIc0IsQ0FFM0JLLFdBRjJCOztBQUkvQixnQkFBSUEsZ0JBQWdCb0IsS0FBS00sR0FBTCxDQUFTUCxhQUFULENBQXBCLEVBQTZDO0FBQ3pDbkI7QUFDQSxxQkFBS3NCLGFBQUwsQ0FBbUJ0QixXQUFuQjtBQUNBLHFCQUFLZSxPQUFMLENBQWE7QUFDVGY7QUFEUyxpQkFBYjtBQUdIO0FBQ0osU0FoRUk7QUFrRUx3Qiw2QkFsRUssaUNBa0VpQkwsYUFsRWpCLEVBa0VnQztBQUNqQyxpQkFBS0csYUFBTCxDQUFtQkgsYUFBbkI7QUFDQSxpQkFBS0osT0FBTCxDQUFhO0FBQ1Q5QixzQkFBTSxLQUFLVSxJQUFMLENBQVVFLFFBQVYsS0FBdUIsUUFBdkIsR0FBa0MsRUFBRXNCLGFBQXBDLEdBQW9ELEtBQUt4QixJQUFMLENBQVVWO0FBRDNELGFBQWI7QUFHSCxTQXZFSTtBQXlFTHFDLHFCQXpFSyx5QkF5RVNILGFBekVULEVBeUV3QjtBQUFBOztBQUFBLGdCQUVyQnJCLE1BRnFCLEdBR3JCLEtBQUtILElBSGdCLENBRXJCRyxNQUZxQjs7QUFJekIsZ0JBQU1HLE9BQU8sRUFBYjtBQUNBLGdCQUFNMEIsYUFBYTdCLE9BQU84QixLQUFQLENBQWEsV0FBYixDQUFuQjtBQUNBLGdCQUFNQyxhQUFhLENBQUM7QUFDaEJDLHFCQUFLLE1BRFc7QUFFaEJsRCxzQkFBTSxLQUZVO0FBR2hCbUQsdUJBQU87QUFIUyxhQUFELEVBSWhCO0FBQ0NELHFCQUFLLE1BRE47QUFFQ2xELHNCQUFNLE1BRlA7QUFHQ21ELHVCQUFPO0FBSFIsYUFKZ0IsRUFRaEI7QUFDQ0QscUJBQUssTUFETjtBQUVDbEQsc0JBQU0sUUFGUDtBQUdDbUQsdUJBQU87QUFIUixhQVJnQixFQVloQjtBQUNDRCxxQkFBSyxNQUROO0FBRUNsRCxzQkFBTSxRQUZQO0FBR0NtRCx1QkFBTztBQUhSLGFBWmdCLENBQW5CO0FBaUJBLGdCQUFJN0IsYUFBYWlCLGFBQWpCO0FBQUEsZ0JBQ0lhLFdBQVcsQ0FEZjs7QUFHQUgsdUJBQVdJLE9BQVgsQ0FBbUIsa0JBQVU7QUFDekIsb0JBQU1DLFFBQVEsT0FBS0MsYUFBTCxDQUFtQlIsVUFBbkIsRUFBK0I3QixPQUFPZ0MsR0FBdEMsQ0FBZDtBQUNBLG9CQUFJSSxVQUFVLENBQUMsQ0FBZixFQUFrQjtBQUNsQixvQkFBTUUsT0FBT1QsV0FBV08sS0FBWCxDQUFiO0FBQ0Esb0JBQU1HLGFBQWE7QUFDZnpELDBCQUFNa0IsT0FBT2xCLElBREU7QUFFZndELDhCQUZlO0FBR2Z0RCwyQkFBT3dELFNBQVNwQyxhQUFhSixPQUFPaUMsS0FBN0I7QUFIUSxpQkFBbkI7QUFLQUMsMkJBQVdBLFdBQVdNLFNBQVNwQyxhQUFhSixPQUFPaUMsS0FBN0IsQ0FBdEI7QUFDQSxvQkFBSSxPQUFLcEMsSUFBTCxDQUFVSSxVQUFkLEVBQTBCO0FBQ3RCc0MsK0JBQVd2RCxLQUFYLEdBQW1CLE9BQUs0QixXQUFMLENBQWlCMkIsV0FBV3ZELEtBQTVCLENBQW5CO0FBQ0g7QUFDRG9CLDhCQUFjSixPQUFPaUMsS0FBckI7QUFDQTlCLHFCQUFLc0MsSUFBTCxDQUFVRixVQUFWO0FBQ0gsYUFmRDtBQWdCQSxnQkFBSUwsV0FBVyxDQUFmLEVBQWtCO0FBQ2QscUJBQUtqQixPQUFMLENBQWE7QUFDVFosNkJBQVM7QUFEQSxpQkFBYjtBQUdIO0FBQ0QsZ0JBQUk2QixZQUFZLENBQVosSUFBaUIsS0FBS3JDLElBQUwsQ0FBVVEsT0FBL0IsRUFBd0M7QUFDcENVLDJCQUFXLFlBQUk7QUFDWDJCLHVCQUFHQyxvQkFBSDtBQUNILGlCQUZELEVBRUUsSUFGRjtBQUlIO0FBQ0QsaUJBQUsxQixPQUFMLENBQWE7QUFDVGQsMEJBRFM7QUFFVEMsNEJBQVk4QjtBQUZILGFBQWI7QUFJQSxtQkFBTy9CLElBQVA7QUFDSCxTQW5JSTtBQXFJTGtDLHFCQXJJSyx5QkFxSVNSLFVBcklULEVBcUlxQmUsR0FySXJCLEVBcUkwQjtBQUMzQixnQkFBTVIsUUFBUVAsV0FBV2dCLE9BQVgsQ0FBbUJELEdBQW5CLENBQWQ7QUFDQSxnQkFBSVIsVUFBVSxDQUFDLENBQWYsRUFBa0IsT0FBTyxDQUFDLENBQVI7QUFDbEIsbUJBQU9BLFFBQVEsQ0FBZjtBQUNILFNBeklJO0FBMklMWCxvQkEzSUssMEJBMklVO0FBQ1gsaUJBQUtxQixZQUFMLENBQWtCLFFBQWxCLEVBQTRCLEVBQTVCO0FBQ0g7QUE3SUk7QUE1RGEsQ0FBVCxDQUFqQiIsImZpbGUiOiJjb3VudGRvd24uanMiLCJzb3VyY2VzQ29udGVudCI6WyJtb2R1bGUuZXhwb3J0cyA9IEJlaGF2aW9yKHtcclxuICAgIGJlaGF2aW9yczogW10sXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgb25seVRpbWU6e1xyXG4gICAgICAgICAgICB0eXBlOiBCb29sZWFuLFxyXG4gICAgICAgICAgICB2YWx1ZTogZmFsc2UsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBpbnN0eWxlOntcclxuICAgICAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICAgICAgICB2YWx1ZTogJycsXHJcbiAgICAgICAgfSxcclxuICAgICAgICB0aW1lOiB7XHJcbiAgICAgICAgICAgIHR5cGU6IERhdGUsXHJcbiAgICAgICAgICAgIHZhbHVlOiBuZXcgRGF0ZSgpLmdldFRpbWUoKSArIDg2NDAwMDAwXHJcbiAgICAgICAgfSxcclxuICAgICAgICBzdGF0dXM6IHtcclxuICAgICAgICAgICAgdHlwZTogQm9vbGVhbixcclxuICAgICAgICAgICAgdmFsdWU6IHRydWUsXHJcbiAgICAgICAgICAgIG9ic2VydmVyOiBmdW5jdGlvbiAobmV3VmFsLCBvbGRWYWwsIGNoYW5nZWRQYXRoKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAobmV3VmFsKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5pbml0KCk7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKCFuZXdWYWwpIHtcclxuICAgICAgICAgICAgICAgICAgICBjbGVhckludGVydmFsKHRoaXMuZGF0YS50aW1lcik7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LFxyXG4gICAgICAgIHRpbWVUeXBlOiB7XHJcbiAgICAgICAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgICAgICAgdmFsdWU6ICdkYXRldGltZSdcclxuICAgICAgICB9LFxyXG4gICAgICAgIGZvcm1hdDoge1xyXG4gICAgICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgICAgICAgIHZhbHVlOiAneyVkfeWkqXslaH3ml7Z7JW195YiGeyVzfeenkidcclxuICAgICAgICB9LFxyXG4gICAgICAgIGlzWmVyb1BhZGQ6IHtcclxuICAgICAgICAgICAgdHlwZTogQm9vbGVhbixcclxuICAgICAgICAgICAgdmFsdWU6IHRydWUsXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIGRhdGE6IHtcclxuICAgICAgICBpbml0QWRkVGltZTogMCxcclxuICAgICAgICB0aW1lcjogbnVsbCxcclxuICAgICAgICBkYXRlOiBbXSxcclxuICAgICAgICBkaWZmU2Vjb25kOiAwLFxyXG4gICAgICAgIHJlZnJlc2g6IGZhbHNlXHJcbiAgICB9LFxyXG4gICAgcmVhZHk6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICB0aGlzLmdldExhdGVzdFRpbWUoKTtcclxuICAgIH0sXHJcblxyXG4gICAgZGV0YWNoZWQ6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICBjbGVhckludGVydmFsKHRoaXMuZGF0YS50aW1lcik7XHJcbiAgICB9LFxyXG5cclxuICAgIHBhZ2VMaWZldGltZXM6IHtcclxuICAgICAgICBoaWRlKCkge1xyXG4gICAgICAgICAgICBjbGVhckludGVydmFsKHRoaXMuZGF0YS50aW1lcik7XHJcbiAgICAgICAgfSxcclxuICAgIH0sXHJcblxyXG4gICAgbWV0aG9kczoge1xyXG4gICAgICAgIC8vIOiHquWKqOihpembtlxyXG4gICAgICAgIHplcm9QYWRkaW5nKG51bSkge1xyXG4gICAgICAgICAgICBudW0gPSBudW0udG9TdHJpbmcoKVxyXG4gICAgICAgICAgICByZXR1cm4gbnVtWzFdID8gbnVtIDogJzAnICsgbnVtXHJcbiAgICAgICAgfSxcclxuXHJcbiAgICAgICAgaW5pdCgpIHtcclxuICAgICAgICAgICAgY2xlYXJJbnRlcnZhbCh0aGlzLmRhdGEudGltZXIpO1xyXG4gICAgICAgICAgICBjb25zdCB0aW1lciA9IHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5nZXRMYXRlc3RUaW1lLmNhbGwodGhpcyk7XHJcbiAgICAgICAgICAgIH0sIDEwMDApO1xyXG4gICAgICAgICAgICB0aGlzLnNldERhdGEoe1xyXG4gICAgICAgICAgICAgICAgdGltZXJcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICB9LFxyXG5cclxuICAgICAgICBnZXRMYXRlc3RUaW1lKCkge1xyXG4gICAgICAgICAgICBsZXQge1xyXG4gICAgICAgICAgICAgICAgdGltZSxcclxuICAgICAgICAgICAgICAgIHN0YXR1cyxcclxuICAgICAgICAgICAgICAgIHRpbWVUeXBlLFxyXG4gICAgICAgICAgICAgICAgaW5pdEFkZFRpbWVcclxuICAgICAgICAgICAgfSA9IHRoaXMuZGF0YTtcclxuICAgICAgICAgICAgY29uc29sZS5sb2codGltZSlcclxuICAgICAgICAgICAgLy8g5YW85a65aW9zXHJcbiAgICAgICAgICAgIGlmICghbmV3IERhdGUodGltZSkuZ2V0VGltZSgpKSB7XHJcbiAgICAgICAgICAgICAgICB0aW1lID0gdGltZS5yZXBsYWNlKC8tL2csICcvJyk7XHJcbiAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhuZXcgRGF0ZSh0aW1lKS5nZXRUaW1lKCkpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgbGV0IGNvdW50RG93blRpbWUgPSB0aW1lVHlwZSA9PT0gJ3NlY29uZCcgP1xyXG4gICAgICAgICAgICAgICAgdGltZSA6XHJcbiAgICAgICAgICAgICAgICBNYXRoLmNlaWwoKG5ldyBEYXRlKHRpbWUpLmdldFRpbWUoKSAtIG5ldyBEYXRlKCkuZ2V0VGltZSgpKSAvIDEwMDApO1xyXG4gICAgICAgICAgICBpZiAoY291bnREb3duVGltZSA8IDAgJiYgdGltZVR5cGUgIT09ICdzZWNvbmQnKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9nZXRUaW1lVmFsdWUoMCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLkNvdW50ZG93bkVuZCgpO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKGNvdW50RG93blRpbWUgLSBpbml0QWRkVGltZSA+IDApIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuZ2V0TGF0ZXN0Rm9yQ291bnREb3duKGNvdW50RG93blRpbWUpO1xyXG4gICAgICAgICAgICB9IGVsc2UgaWYgKGNvdW50RG93blRpbWUgLSBpbml0QWRkVGltZSA8IDApIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuZ2V0TGF0ZXN0Rm9yQWRkVGltZShjb3VudERvd25UaW1lKTtcclxuICAgICAgICAgICAgfSBlbHNlIGlmIChjb3VudERvd25UaW1lIC0gaW5pdEFkZFRpbWUgPT09IDApIHtcclxuICAgICAgICAgICAgICAgIGlmIChpbml0QWRkVGltZSA8PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fZ2V0VGltZVZhbHVlKGNvdW50RG93blRpbWUpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgdGhpcy5Db3VudGRvd25FbmQoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoc3RhdHVzICYmIGNvdW50RG93blRpbWUgLSBpbml0QWRkVGltZSAhPT0gMCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5pbml0LmNhbGwodGhpcyk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LFxyXG5cclxuICAgICAgICBnZXRMYXRlc3RGb3JBZGRUaW1lKGNvdW50RG93blRpbWUpIHtcclxuICAgICAgICAgICAgbGV0IHtcclxuICAgICAgICAgICAgICAgIGluaXRBZGRUaW1lXHJcbiAgICAgICAgICAgIH0gPSB0aGlzLmRhdGE7XHJcbiAgICAgICAgICAgIGlmIChpbml0QWRkVGltZSAhPT0gTWF0aC5hYnMoY291bnREb3duVGltZSkpIHtcclxuICAgICAgICAgICAgICAgIGluaXRBZGRUaW1lKys7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9nZXRUaW1lVmFsdWUoaW5pdEFkZFRpbWUpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zZXREYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICBpbml0QWRkVGltZVxyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcblxyXG4gICAgICAgIGdldExhdGVzdEZvckNvdW50RG93bihjb3VudERvd25UaW1lKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2dldFRpbWVWYWx1ZShjb3VudERvd25UaW1lKTtcclxuICAgICAgICAgICAgdGhpcy5zZXREYXRhKHtcclxuICAgICAgICAgICAgICAgIHRpbWU6IHRoaXMuZGF0YS50aW1lVHlwZSA9PT0gJ3NlY29uZCcgPyAtLWNvdW50RG93blRpbWUgOiB0aGlzLmRhdGEudGltZSxcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfSxcclxuXHJcbiAgICAgICAgX2dldFRpbWVWYWx1ZShjb3VudERvd25UaW1lKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IHtcclxuICAgICAgICAgICAgICAgIGZvcm1hdFxyXG4gICAgICAgICAgICB9ID0gdGhpcy5kYXRhO1xyXG4gICAgICAgICAgICBjb25zdCBkYXRlID0gW107XHJcbiAgICAgICAgICAgIGNvbnN0IGZvbWF0QXJyYXkgPSBmb3JtYXQuc3BsaXQoLyhcXHsuKj9cXH0pLyk7XHJcbiAgICAgICAgICAgIGNvbnN0IGZvcm1hdFR5cGUgPSBbe1xyXG4gICAgICAgICAgICAgICAga2V5OiAneyVkfScsXHJcbiAgICAgICAgICAgICAgICB0eXBlOiAnZGF5JyxcclxuICAgICAgICAgICAgICAgIGNvdW50OiA4NjQwMFxyXG4gICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICBrZXk6ICd7JWh9JyxcclxuICAgICAgICAgICAgICAgIHR5cGU6ICdob3VyJyxcclxuICAgICAgICAgICAgICAgIGNvdW50OiAzNjAwXHJcbiAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgIGtleTogJ3slbX0nLFxyXG4gICAgICAgICAgICAgICAgdHlwZTogJ21pbnV0ZScsXHJcbiAgICAgICAgICAgICAgICBjb3VudDogNjBcclxuICAgICAgICAgICAgfSwge1xyXG4gICAgICAgICAgICAgICAga2V5OiAneyVzfScsXHJcbiAgICAgICAgICAgICAgICB0eXBlOiAnc2Vjb25kJyxcclxuICAgICAgICAgICAgICAgIGNvdW50OiAxLFxyXG4gICAgICAgICAgICB9XTtcclxuICAgICAgICAgICAgbGV0IGRpZmZTZWNvbmQgPSBjb3VudERvd25UaW1lLFxyXG4gICAgICAgICAgICAgICAgbGFzdFRpbWUgPSAwO1xyXG5cclxuICAgICAgICAgICAgZm9ybWF0VHlwZS5mb3JFYWNoKGZvcm1hdCA9PiB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBpbmRleCA9IHRoaXMuX2ZpbmRUaW1lTmFtZShmb21hdEFycmF5LCBmb3JtYXQua2V5KTtcclxuICAgICAgICAgICAgICAgIGlmIChpbmRleCA9PT0gLTEpIHJldHVybjtcclxuICAgICAgICAgICAgICAgIGNvbnN0IG5hbWUgPSBmb21hdEFycmF5W2luZGV4XTtcclxuICAgICAgICAgICAgICAgIGNvbnN0IGZvcm1hdEl0ZW0gPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogZm9ybWF0LnR5cGUsXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZSxcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZTogcGFyc2VJbnQoZGlmZlNlY29uZCAvIGZvcm1hdC5jb3VudClcclxuICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgICAgICBsYXN0VGltZSA9IGxhc3RUaW1lICsgcGFyc2VJbnQoZGlmZlNlY29uZCAvIGZvcm1hdC5jb3VudCk7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5kYXRhLmlzWmVyb1BhZGQpIHtcclxuICAgICAgICAgICAgICAgICAgICBmb3JtYXRJdGVtLnZhbHVlID0gdGhpcy56ZXJvUGFkZGluZyhmb3JtYXRJdGVtLnZhbHVlKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGRpZmZTZWNvbmQgJT0gZm9ybWF0LmNvdW50O1xyXG4gICAgICAgICAgICAgICAgZGF0ZS5wdXNoKGZvcm1hdEl0ZW0pO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgaWYgKGxhc3RUaW1lID4gMCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zZXREYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICByZWZyZXNoOiB0cnVlXHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChsYXN0VGltZSA9PSAwICYmIHRoaXMuZGF0YS5yZWZyZXNoKSB7XHJcbiAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KCgpPT57XHJcbiAgICAgICAgICAgICAgICAgICAgd3guc3RhcnRQdWxsRG93blJlZnJlc2goKTtcclxuICAgICAgICAgICAgICAgIH0sMzAwMClcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRoaXMuc2V0RGF0YSh7XHJcbiAgICAgICAgICAgICAgICBkYXRlLFxyXG4gICAgICAgICAgICAgICAgZGlmZlNlY29uZDogbGFzdFRpbWVcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIHJldHVybiBkYXRlO1xyXG4gICAgICAgIH0sXHJcblxyXG4gICAgICAgIF9maW5kVGltZU5hbWUoZm9tYXRBcnJheSwgc3RyKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGluZGV4ID0gZm9tYXRBcnJheS5pbmRleE9mKHN0cik7XHJcbiAgICAgICAgICAgIGlmIChpbmRleCA9PT0gLTEpIHJldHVybiAtMTtcclxuICAgICAgICAgICAgcmV0dXJuIGluZGV4ICsgMVxyXG4gICAgICAgIH0sXHJcblxyXG4gICAgICAgIENvdW50ZG93bkVuZCgpIHtcclxuICAgICAgICAgICAgdGhpcy50cmlnZ2VyRXZlbnQoXCJsaW5lbmRcIiwge30pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufSk7Il19