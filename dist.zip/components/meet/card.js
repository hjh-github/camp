'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = undefined;

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$component) {
    _inherits(Dialog, _wepy$component);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.props = ['remark'], _this.data = {
            close: "/static/images/close.png"
        }, _this.methods = {
            toCourse: function toCourse(id) {
                _wepy2.default.navigateTo({
                    url: '/pages/detaile/detaile?id=' + this.remark.courseId
                });
            },
            targgetLike: function () {
                var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(e) {
                    var res;
                    return regeneratorRuntime.wrap(function _callee$(_context) {
                        while (1) {
                            switch (_context.prev = _context.next) {
                                case 0:
                                    if (!(e.detail.errMsg == "getUserInfo:ok")) {
                                        _context.next = 10;
                                        break;
                                    }

                                    _context.next = 3;
                                    return _auth2.default.getUserinfo(e.detail);

                                case 3:
                                    this.remark.isLike = this.remark.isLike ? 0 : 1;
                                    _context.next = 6;
                                    return _config2.default.dolike({
                                        commentId: this.remark.commentId,
                                        state: this.remark.isLike
                                    });

                                case 6:
                                    res = _context.sent;

                                    this.remark.likePhotos = res.likePhotos;
                                    this.remark.likeCount = res.likeCount;
                                    this.$apply();

                                case 10:
                                case 'end':
                                    return _context.stop();
                            }
                        }
                    }, _callee, this);
                }));

                function targgetLike(_x) {
                    return _ref2.apply(this, arguments);
                }

                return targgetLike;
            }()
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    return Dialog;
}(_wepy2.default.component);

exports.default = Dialog;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNhcmQuanMiXSwibmFtZXMiOlsiRGlhbG9nIiwicHJvcHMiLCJkYXRhIiwiY2xvc2UiLCJtZXRob2RzIiwidG9Db3Vyc2UiLCJpZCIsIndlcHkiLCJuYXZpZ2F0ZVRvIiwidXJsIiwicmVtYXJrIiwiY291cnNlSWQiLCJ0YXJnZ2V0TGlrZSIsImUiLCJkZXRhaWwiLCJlcnJNc2ciLCJhdXRoIiwiZ2V0VXNlcmluZm8iLCJpc0xpa2UiLCJjb25maWciLCJkb2xpa2UiLCJjb21tZW50SWQiLCJzdGF0ZSIsInJlcyIsImxpa2VQaG90b3MiLCJsaWtlQ291bnQiLCIkYXBwbHkiLCJjb21wb25lbnQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFDSTs7OztBQUNBOzs7O0FBQ0E7Ozs7Ozs7Ozs7Ozs7O0lBQ3FCQSxNOzs7Ozs7Ozs7Ozs7OzswTEFDakJDLEssR0FBUSxDQUFDLFFBQUQsQyxRQUNSQyxJLEdBQU87QUFDSEMsbUJBQU87QUFESixTLFFBR1BDLE8sR0FBVTtBQUNOQyxvQkFETSxvQkFDR0MsRUFESCxFQUNPO0FBQ1RDLCtCQUFLQyxVQUFMLENBQWdCO0FBQ1pDLHlCQUFLLCtCQUErQixLQUFLQyxNQUFMLENBQVlDO0FBRHBDLGlCQUFoQjtBQUdILGFBTEs7QUFNQUMsdUJBTkE7QUFBQSxxR0FNWUMsQ0FOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQ0FPRUEsRUFBRUMsTUFBRixDQUFTQyxNQUFULElBQW1CLGdCQVByQjtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBLDJDQVFRQyxlQUFLQyxXQUFMLENBQWlCSixFQUFFQyxNQUFuQixDQVJSOztBQUFBO0FBU0UseUNBQUtKLE1BQUwsQ0FBWVEsTUFBWixHQUFxQixLQUFLUixNQUFMLENBQVlRLE1BQVosR0FBcUIsQ0FBckIsR0FBeUIsQ0FBOUM7QUFURjtBQUFBLDJDQVVrQkMsaUJBQU9DLE1BQVAsQ0FBYztBQUMxQkMsbURBQVcsS0FBS1gsTUFBTCxDQUFZVyxTQURHO0FBRTFCQywrQ0FBTyxLQUFLWixNQUFMLENBQVlRO0FBRk8scUNBQWQsQ0FWbEI7O0FBQUE7QUFVTUssdUNBVk47O0FBY0UseUNBQUtiLE1BQUwsQ0FBWWMsVUFBWixHQUF5QkQsSUFBSUMsVUFBN0I7QUFDQSx5Q0FBS2QsTUFBTCxDQUFZZSxTQUFaLEdBQXdCRixJQUFJRSxTQUE1QjtBQUNBLHlDQUFLQyxNQUFMOztBQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBLFM7Ozs7RUFMc0JuQixlQUFLb0IsUzs7a0JBQXBCM0IsTSIsImZpbGUiOiJjYXJkLmpzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbiAgICBpbXBvcnQgd2VweSBmcm9tIFwid2VweVwiO1xyXG4gICAgaW1wb3J0IGNvbmZpZyBmcm9tICdAL2FwaS9jb25maWcnXHJcbiAgICBpbXBvcnQgYXV0aCBmcm9tICdAL2FwaS9hdXRoJ1xyXG4gICAgZXhwb3J0IGRlZmF1bHQgY2xhc3MgRGlhbG9nIGV4dGVuZHMgd2VweS5jb21wb25lbnQge1xyXG4gICAgICAgIHByb3BzID0gWydyZW1hcmsnXVxyXG4gICAgICAgIGRhdGEgPSB7XHJcbiAgICAgICAgICAgIGNsb3NlOiBcIi9zdGF0aWMvaW1hZ2VzL2Nsb3NlLnBuZ1wiXHJcbiAgICAgICAgfTtcclxuICAgICAgICBtZXRob2RzID0ge1xyXG4gICAgICAgICAgICB0b0NvdXJzZShpZCkge1xyXG4gICAgICAgICAgICAgICAgd2VweS5uYXZpZ2F0ZVRvKHtcclxuICAgICAgICAgICAgICAgICAgICB1cmw6ICcvcGFnZXMvZGV0YWlsZS9kZXRhaWxlP2lkPScgKyB0aGlzLnJlbWFyay5jb3Vyc2VJZFxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGFzeW5jIHRhcmdnZXRMaWtlKGUpIHtcclxuICAgICAgICAgICAgICAgIGlmIChlLmRldGFpbC5lcnJNc2cgPT0gXCJnZXRVc2VySW5mbzpva1wiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYXdhaXQgYXV0aC5nZXRVc2VyaW5mbyhlLmRldGFpbClcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnJlbWFyay5pc0xpa2UgPSB0aGlzLnJlbWFyay5pc0xpa2UgPyAwIDogMVxyXG4gICAgICAgICAgICAgICAgICAgIGxldCByZXMgPSBhd2FpdCBjb25maWcuZG9saWtlKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29tbWVudElkOiB0aGlzLnJlbWFyay5jb21tZW50SWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0YXRlOiB0aGlzLnJlbWFyay5pc0xpa2VcclxuICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMucmVtYXJrLmxpa2VQaG90b3MgPSByZXMubGlrZVBob3Rvc1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMucmVtYXJrLmxpa2VDb3VudCA9IHJlcy5saWtlQ291bnRcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuIl19