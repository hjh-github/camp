"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = undefined;

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _Lang = require('./../../utils/Lang.js');

var _Lang2 = _interopRequireDefault(_Lang);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$component) {
    _inherits(Dialog, _wepy$component);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.props = ['statistics', 'CourseComment', 'model'], _this.data = {
            close: "/static/images/close.png"
        }, _this.methods = {
            toMore: function toMore(e) {
                var id = e.currentTarget.dataset.id || e.target.dataset.id;
                _wepy2.default.navigateTo({
                    url: '/pages/meet/remarks?tag=' + id + '&courseId=' + this.model.id
                });
            },
            previewImage: function previewImage(url, urls) {
                _Lang2.default.previewImage(url, urls);
            }
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    return Dialog;
}(_wepy2.default.component);

exports.default = Dialog;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJlbWFrZS5qcyJdLCJuYW1lcyI6WyJEaWFsb2ciLCJwcm9wcyIsImRhdGEiLCJjbG9zZSIsIm1ldGhvZHMiLCJ0b01vcmUiLCJlIiwiaWQiLCJjdXJyZW50VGFyZ2V0IiwiZGF0YXNldCIsInRhcmdldCIsIndlcHkiLCJuYXZpZ2F0ZVRvIiwidXJsIiwibW9kZWwiLCJwcmV2aWV3SW1hZ2UiLCJ1cmxzIiwiTGFuZyIsImNvbXBvbmVudCJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUNJOzs7O0FBQ0E7Ozs7Ozs7Ozs7OztJQUNxQkEsTTs7Ozs7Ozs7Ozs7Ozs7MExBQ2pCQyxLLEdBQVEsQ0FBQyxZQUFELEVBQWMsZUFBZCxFQUE4QixPQUE5QixDLFFBQ1JDLEksR0FBTztBQUNIQyxtQkFBTztBQURKLFMsUUFHUEMsTyxHQUFVO0FBQ05DLGtCQURNLGtCQUNDQyxDQURELEVBQ0k7QUFDTixvQkFBSUMsS0FBS0QsRUFBRUUsYUFBRixDQUFnQkMsT0FBaEIsQ0FBd0JGLEVBQXhCLElBQThCRCxFQUFFSSxNQUFGLENBQVNELE9BQVQsQ0FBaUJGLEVBQXhEO0FBQ0FJLCtCQUFLQyxVQUFMLENBQWdCO0FBQ1pDLHlCQUFLLDZCQUE2Qk4sRUFBN0IsR0FBa0MsWUFBbEMsR0FBaUQsS0FBS08sS0FBTCxDQUFXUDtBQURyRCxpQkFBaEI7QUFJSCxhQVBLO0FBUU5RLHdCQVJNLHdCQVFPRixHQVJQLEVBUVdHLElBUlgsRUFRZ0I7QUFDbEJDLCtCQUFLRixZQUFMLENBQWtCRixHQUFsQixFQUFzQkcsSUFBdEI7QUFDSDtBQVZLLFM7Ozs7RUFMc0JMLGVBQUtPLFM7O2tCQUFwQmxCLE0iLCJmaWxlIjoicmVtYWtlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbiAgICBpbXBvcnQgd2VweSBmcm9tIFwid2VweVwiO1xyXG4gICAgaW1wb3J0IExhbmcgZnJvbSBcIkAvdXRpbHMvTGFuZ1wiXHJcbiAgICBleHBvcnQgZGVmYXVsdCBjbGFzcyBEaWFsb2cgZXh0ZW5kcyB3ZXB5LmNvbXBvbmVudCB7XHJcbiAgICAgICAgcHJvcHMgPSBbJ3N0YXRpc3RpY3MnLCdDb3Vyc2VDb21tZW50JywnbW9kZWwnXVxyXG4gICAgICAgIGRhdGEgPSB7XHJcbiAgICAgICAgICAgIGNsb3NlOiBcIi9zdGF0aWMvaW1hZ2VzL2Nsb3NlLnBuZ1wiXHJcbiAgICAgICAgfTtcclxuICAgICAgICBtZXRob2RzID0ge1xyXG4gICAgICAgICAgICB0b01vcmUoZSkge1xyXG4gICAgICAgICAgICAgICAgbGV0IGlkID0gZS5jdXJyZW50VGFyZ2V0LmRhdGFzZXQuaWQgfHwgZS50YXJnZXQuZGF0YXNldC5pZFxyXG4gICAgICAgICAgICAgICAgd2VweS5uYXZpZ2F0ZVRvKHtcclxuICAgICAgICAgICAgICAgICAgICB1cmw6ICcvcGFnZXMvbWVldC9yZW1hcmtzP3RhZz0nICsgaWQgKyAnJmNvdXJzZUlkPScgKyB0aGlzLm1vZGVsLmlkXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBwcmV2aWV3SW1hZ2UodXJsLHVybHMpe1xyXG4gICAgICAgICAgICAgICAgTGFuZy5wcmV2aWV3SW1hZ2UodXJsLHVybHMpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9O1xyXG4gICAgfVxyXG4iXX0=