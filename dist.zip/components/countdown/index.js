'use strict';

var _countdown = require('./../countdown.js');

var _countdown2 = _interopRequireDefault(_countdown);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

Component({
    externalClasses: ['l-class', 'l-class-time'],
    behaviors: [_countdown2.default],
    properties: {
        doneText: {
            type: String,
            value: '已结束'
        }
    },
    methods: {}
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LmpzIl0sIm5hbWVzIjpbIkNvbXBvbmVudCIsImV4dGVybmFsQ2xhc3NlcyIsImJlaGF2aW9ycyIsImNvdW50RG93bkJlaGF2aW9zIiwicHJvcGVydGllcyIsImRvbmVUZXh0IiwidHlwZSIsIlN0cmluZyIsInZhbHVlIiwibWV0aG9kcyJdLCJtYXBwaW5ncyI6Ijs7QUFBQTs7Ozs7O0FBQ0FBLFVBQVU7QUFDTkMscUJBQWlCLENBQUMsU0FBRCxFQUFXLGNBQVgsQ0FEWDtBQUVOQyxlQUFVLENBQUNDLG1CQUFELENBRko7QUFHTkMsZ0JBQVk7QUFDUkMsa0JBQVM7QUFDTEMsa0JBQUtDLE1BREE7QUFFTEMsbUJBQU07QUFGRDtBQURELEtBSE47QUFTTkMsYUFBUztBQVRILENBQVYiLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgY291bnREb3duQmVoYXZpb3MgZnJvbSAnLi4vY291bnRkb3duJztcclxuQ29tcG9uZW50KHtcclxuICAgIGV4dGVybmFsQ2xhc3NlczogWydsLWNsYXNzJywnbC1jbGFzcy10aW1lJ10sXHJcbiAgICBiZWhhdmlvcnM6W2NvdW50RG93bkJlaGF2aW9zXSxcclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBkb25lVGV4dDp7XHJcbiAgICAgICAgICAgIHR5cGU6U3RyaW5nLFxyXG4gICAgICAgICAgICB2YWx1ZTon5bey57uT5p2fJ1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICBtZXRob2RzOiB7XHJcbiAgICAgICAgXHJcbiAgICB9XHJcbn0pOyJdfQ==