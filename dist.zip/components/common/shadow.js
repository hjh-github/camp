"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$component) {
  _inherits(Dialog, _wepy$component);

  function Dialog() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, Dialog);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.data = {
      close: "/static/images/close.png",
      pops: [],
      step: 0,
      show: false
    }, _this.methods = {
      load: function load(pops) {
        this.step = 0;
        this.pops = pops;
        this.show = true;
        this.$apply();
      },
      close: function close() {
        if (this.step < this.pops.length - 1) {
          this.step = this.step + 1;
        } else {
          this.show = false;
        }
      },
      navigator: function navigator(url, type) {
        this.step = this.step + 1;
        if (this.step > this.pops.length - 1) {
          this.show = false;
        }
        this.navigator(url, type);
      }
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(Dialog, [{
    key: "navigator",
    value: function navigator(url, type) {
      if (type == 'none' || !type) {
        return false;
      }
      if (type == 'navigateTo') {
        _wepy2.default.navigateTo({
          url: url
        });
      } else if (type == 'redirectTo') {
        _wepy2.default.redirectTo({
          url: url
        });
      } else if (type == 'switchTab') {
        _wepy2.default.switchTab({
          url: url
        });
      } else if (type == 'reLaunch') {
        _wepy2.default.reLaunch({
          url: url
        });
      } else if (type == 'web') {
        _wepy2.default.navigateTo({
          url: '/pages/home/web?src=' + encodeURIComponent(url)
        });
      }
    }
  }]);

  return Dialog;
}(_wepy2.default.component);

exports.default = Dialog;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNoYWRvdy5qcyJdLCJuYW1lcyI6WyJEaWFsb2ciLCJkYXRhIiwiY2xvc2UiLCJwb3BzIiwic3RlcCIsInNob3ciLCJtZXRob2RzIiwibG9hZCIsIiRhcHBseSIsImxlbmd0aCIsIm5hdmlnYXRvciIsInVybCIsInR5cGUiLCJ3ZXB5IiwibmF2aWdhdGVUbyIsInJlZGlyZWN0VG8iLCJzd2l0Y2hUYWIiLCJyZUxhdW5jaCIsImVuY29kZVVSSUNvbXBvbmVudCIsImNvbXBvbmVudCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQ0U7Ozs7Ozs7Ozs7OztJQUNxQkEsTTs7Ozs7Ozs7Ozs7Ozs7c0xBQ25CQyxJLEdBQU87QUFDTEMsYUFBTywwQkFERjtBQUVMQyxZQUFNLEVBRkQ7QUFHTEMsWUFBTSxDQUhEO0FBSUxDLFlBQU07QUFKRCxLLFFBZ0NQQyxPLEdBQVU7QUFDUkMsVUFEUSxnQkFDSEosSUFERyxFQUNHO0FBQ1QsYUFBS0MsSUFBTCxHQUFZLENBQVo7QUFDQSxhQUFLRCxJQUFMLEdBQVlBLElBQVo7QUFDQSxhQUFLRSxJQUFMLEdBQVksSUFBWjtBQUNBLGFBQUtHLE1BQUw7QUFDRCxPQU5PO0FBT1JOLFdBUFEsbUJBT0E7QUFDTixZQUFJLEtBQUtFLElBQUwsR0FBWSxLQUFLRCxJQUFMLENBQVVNLE1BQVYsR0FBbUIsQ0FBbkMsRUFBc0M7QUFDcEMsZUFBS0wsSUFBTCxHQUFZLEtBQUtBLElBQUwsR0FBWSxDQUF4QjtBQUNELFNBRkQsTUFFTztBQUNMLGVBQUtDLElBQUwsR0FBWSxLQUFaO0FBQ0Q7QUFDRixPQWJPO0FBY1JLLGVBZFEscUJBY0VDLEdBZEYsRUFjT0MsSUFkUCxFQWNhO0FBQ25CLGFBQUtSLElBQUwsR0FBWSxLQUFLQSxJQUFMLEdBQVksQ0FBeEI7QUFDQSxZQUFJLEtBQUtBLElBQUwsR0FBWSxLQUFLRCxJQUFMLENBQVVNLE1BQVYsR0FBbUIsQ0FBbkMsRUFBc0M7QUFDcEMsZUFBS0osSUFBTCxHQUFZLEtBQVo7QUFDRDtBQUNELGFBQUtLLFNBQUwsQ0FBZUMsR0FBZixFQUFvQkMsSUFBcEI7QUFDRDtBQXBCTyxLOzs7Ozs4QkExQkFELEcsRUFBS0MsSSxFQUFNO0FBQ25CLFVBQUlBLFFBQVEsTUFBUixJQUFrQixDQUFDQSxJQUF2QixFQUE2QjtBQUMzQixlQUFPLEtBQVA7QUFDRDtBQUNELFVBQUlBLFFBQVEsWUFBWixFQUEwQjtBQUN4QkMsdUJBQUtDLFVBQUwsQ0FBZ0I7QUFDZEg7QUFEYyxTQUFoQjtBQUdELE9BSkQsTUFJTyxJQUFJQyxRQUFRLFlBQVosRUFBMEI7QUFDL0JDLHVCQUFLRSxVQUFMLENBQWdCO0FBQ2RKO0FBRGMsU0FBaEI7QUFHRCxPQUpNLE1BSUEsSUFBSUMsUUFBUSxXQUFaLEVBQXlCO0FBQzlCQyx1QkFBS0csU0FBTCxDQUFlO0FBQ2JMO0FBRGEsU0FBZjtBQUdELE9BSk0sTUFJQSxJQUFJQyxRQUFRLFVBQVosRUFBd0I7QUFDN0JDLHVCQUFLSSxRQUFMLENBQWM7QUFDWk47QUFEWSxTQUFkO0FBR0QsT0FKTSxNQUlBLElBQUlDLFFBQVEsS0FBWixFQUFtQjtBQUN4QkMsdUJBQUtDLFVBQUwsQ0FBZ0I7QUFDZEgsZUFBSyx5QkFBeUJPLG1CQUFtQlAsR0FBbkI7QUFEaEIsU0FBaEI7QUFHRDtBQUNGOzs7O0VBaENpQ0UsZUFBS00sUzs7a0JBQXBCbkIsTSIsImZpbGUiOiJzaGFkb3cuanMiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuICBpbXBvcnQgd2VweSBmcm9tIFwid2VweVwiO1xyXG4gIGV4cG9ydCBkZWZhdWx0IGNsYXNzIERpYWxvZyBleHRlbmRzIHdlcHkuY29tcG9uZW50IHtcclxuICAgIGRhdGEgPSB7XHJcbiAgICAgIGNsb3NlOiBcIi9zdGF0aWMvaW1hZ2VzL2Nsb3NlLnBuZ1wiLFxyXG4gICAgICBwb3BzOiBbXSxcclxuICAgICAgc3RlcDogMCxcclxuICAgICAgc2hvdzogZmFsc2VcclxuICAgIH07XHJcbiAgICBuYXZpZ2F0b3IodXJsLCB0eXBlKSB7XHJcbiAgICAgIGlmICh0eXBlID09ICdub25lJyB8fCAhdHlwZSkge1xyXG4gICAgICAgIHJldHVybiBmYWxzZVxyXG4gICAgICB9XHJcbiAgICAgIGlmICh0eXBlID09ICduYXZpZ2F0ZVRvJykge1xyXG4gICAgICAgIHdlcHkubmF2aWdhdGVUbyh7XHJcbiAgICAgICAgICB1cmxcclxuICAgICAgICB9KTtcclxuICAgICAgfSBlbHNlIGlmICh0eXBlID09ICdyZWRpcmVjdFRvJykge1xyXG4gICAgICAgIHdlcHkucmVkaXJlY3RUbyh7XHJcbiAgICAgICAgICB1cmxcclxuICAgICAgICB9KTtcclxuICAgICAgfSBlbHNlIGlmICh0eXBlID09ICdzd2l0Y2hUYWInKSB7XHJcbiAgICAgICAgd2VweS5zd2l0Y2hUYWIoe1xyXG4gICAgICAgICAgdXJsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gZWxzZSBpZiAodHlwZSA9PSAncmVMYXVuY2gnKSB7XHJcbiAgICAgICAgd2VweS5yZUxhdW5jaCh7XHJcbiAgICAgICAgICB1cmxcclxuICAgICAgICB9KTtcclxuICAgICAgfSBlbHNlIGlmICh0eXBlID09ICd3ZWInKSB7XHJcbiAgICAgICAgd2VweS5uYXZpZ2F0ZVRvKHtcclxuICAgICAgICAgIHVybDogJy9wYWdlcy9ob21lL3dlYj9zcmM9JyArIGVuY29kZVVSSUNvbXBvbmVudCh1cmwpXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIG1ldGhvZHMgPSB7XHJcbiAgICAgIGxvYWQocG9wcykge1xyXG4gICAgICAgIHRoaXMuc3RlcCA9IDBcclxuICAgICAgICB0aGlzLnBvcHMgPSBwb3BzXHJcbiAgICAgICAgdGhpcy5zaG93ID0gdHJ1ZVxyXG4gICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgfSxcclxuICAgICAgY2xvc2UoKSB7XHJcbiAgICAgICAgaWYgKHRoaXMuc3RlcCA8IHRoaXMucG9wcy5sZW5ndGggLSAxKSB7XHJcbiAgICAgICAgICB0aGlzLnN0ZXAgPSB0aGlzLnN0ZXAgKyAxXHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHRoaXMuc2hvdyA9IGZhbHNlXHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG4gICAgICBuYXZpZ2F0b3IodXJsLCB0eXBlKSB7XHJcbiAgICAgICAgdGhpcy5zdGVwID0gdGhpcy5zdGVwICsgMVxyXG4gICAgICAgIGlmICh0aGlzLnN0ZXAgPiB0aGlzLnBvcHMubGVuZ3RoIC0gMSkge1xyXG4gICAgICAgICAgdGhpcy5zaG93ID0gZmFsc2VcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5uYXZpZ2F0b3IodXJsLCB0eXBlKVxyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gIH1cclxuIl19