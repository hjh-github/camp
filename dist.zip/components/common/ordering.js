"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var help = function (_wepy$component) {
    _inherits(help, _wepy$component);

    function help() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, help);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = help.__proto__ || Object.getPrototypeOf(help)).call.apply(_ref, [this].concat(args))), _this), _this.data = {
            orderings: [],
            inx: 0,
            timer: null
        }, _this.methods = {
            load: function load(orderings) {
                if (!orderings) return;
                this.orderings = orderings;
                this.slider();
            }
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(help, [{
        key: "slider",
        value: function slider() {
            var _this2 = this;

            setInterval(function () {
                if (_this2.inx < _this2.orderings.length) {
                    _this2.inx = _this2.inx + 1;
                } else {
                    _this2.inx = 0;
                }
                _this2.$apply();
            }, 3200);
        }
    }]);

    return help;
}(_wepy2.default.component);

exports.default = help;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm9yZGVyaW5nLmpzIl0sIm5hbWVzIjpbImhlbHAiLCJkYXRhIiwib3JkZXJpbmdzIiwiaW54IiwidGltZXIiLCJtZXRob2RzIiwibG9hZCIsInNsaWRlciIsInNldEludGVydmFsIiwibGVuZ3RoIiwiJGFwcGx5Iiwid2VweSIsImNvbXBvbmVudCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQ0k7Ozs7Ozs7Ozs7OztJQUNxQkEsSTs7Ozs7Ozs7Ozs7Ozs7c0xBQ2pCQyxJLEdBQU87QUFDSEMsdUJBQVcsRUFEUjtBQUVIQyxpQkFBSyxDQUZGO0FBR0hDLG1CQUFPO0FBSEosUyxRQWVQQyxPLEdBQVU7QUFDTkMsZ0JBRE0sZ0JBQ0RKLFNBREMsRUFDVTtBQUNaLG9CQUFHLENBQUNBLFNBQUosRUFBZTtBQUNmLHFCQUFLQSxTQUFMLEdBQWlCQSxTQUFqQjtBQUNBLHFCQUFLSyxNQUFMO0FBQ0g7QUFMSyxTOzs7OztpQ0FWRDtBQUFBOztBQUNMQyx3QkFBWSxZQUFNO0FBQ2Qsb0JBQUcsT0FBS0wsR0FBTCxHQUFXLE9BQUtELFNBQUwsQ0FBZU8sTUFBN0IsRUFBb0M7QUFDaEMsMkJBQUtOLEdBQUwsR0FBVyxPQUFLQSxHQUFMLEdBQVcsQ0FBdEI7QUFDSCxpQkFGRCxNQUVLO0FBQ0QsMkJBQUtBLEdBQUwsR0FBVyxDQUFYO0FBQ0g7QUFDRCx1QkFBS08sTUFBTDtBQUNILGFBUEQsRUFPRyxJQVBIO0FBUUg7Ozs7RUFmNkJDLGVBQUtDLFM7O2tCQUFsQlosSSIsImZpbGUiOiJvcmRlcmluZy5qcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4gICAgaW1wb3J0IHdlcHkgZnJvbSBcIndlcHlcIjtcclxuICAgIGV4cG9ydCBkZWZhdWx0IGNsYXNzIGhlbHAgZXh0ZW5kcyB3ZXB5LmNvbXBvbmVudCB7XHJcbiAgICAgICAgZGF0YSA9IHtcclxuICAgICAgICAgICAgb3JkZXJpbmdzOiBbXSxcclxuICAgICAgICAgICAgaW54OiAwLFxyXG4gICAgICAgICAgICB0aW1lcjogbnVsbFxyXG4gICAgICAgIH07XHJcbiAgICAgICAgc2xpZGVyKCkge1xyXG4gICAgICAgICAgICBzZXRJbnRlcnZhbCgoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZih0aGlzLmlueCA8IHRoaXMub3JkZXJpbmdzLmxlbmd0aCl7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5pbnggPSB0aGlzLmlueCArIDFcclxuICAgICAgICAgICAgICAgIH1lbHNle1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuaW54ID0gMFxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgICAgICAgICB9LCAzMjAwKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgbWV0aG9kcyA9IHtcclxuICAgICAgICAgICAgbG9hZChvcmRlcmluZ3MpIHtcclxuICAgICAgICAgICAgICAgIGlmKCFvcmRlcmluZ3MpIHJldHVyblxyXG4gICAgICAgICAgICAgICAgdGhpcy5vcmRlcmluZ3MgPSBvcmRlcmluZ3NcclxuICAgICAgICAgICAgICAgIHRoaXMuc2xpZGVyKClcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuIl19