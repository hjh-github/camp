'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = undefined;

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _navigator = require('./../../mixins/navigator.js');

var _navigator2 = _interopRequireDefault(_navigator);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Swiper = function (_wepy$component) {
    _inherits(Swiper, _wepy$component);

    function Swiper() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Swiper);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Swiper.__proto__ || Object.getPrototypeOf(Swiper)).call.apply(_ref, [this].concat(args))), _this), _this.props = ['model'], _this.data = {
            cardCur: 0
        }, _this.mixins = [_navigator2.default], _this.methods = {
            cardSwiper: function cardSwiper(e) {
                this.cardCur = e.detail.current;
            }
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    return Swiper;
}(_wepy2.default.component);

exports.default = Swiper;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN3aXBlci5qcyJdLCJuYW1lcyI6WyJTd2lwZXIiLCJwcm9wcyIsImRhdGEiLCJjYXJkQ3VyIiwibWl4aW5zIiwibmF2aWdhdG9yIiwibWV0aG9kcyIsImNhcmRTd2lwZXIiLCJlIiwiZGV0YWlsIiwiY3VycmVudCIsIndlcHkiLCJjb21wb25lbnQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFDSTs7OztBQUNBOzs7Ozs7Ozs7Ozs7SUFDcUJBLE07Ozs7Ozs7Ozs7Ozs7OzBMQUNqQkMsSyxHQUFNLENBQUMsT0FBRCxDLFFBQ05DLEksR0FBTztBQUNIQyxxQkFBUztBQUROLFMsUUFHUEMsTSxHQUFTLENBQUNDLG1CQUFELEMsUUFDVEMsTyxHQUFVO0FBQ05DLHNCQURNLHNCQUNLQyxDQURMLEVBQ1E7QUFDVixxQkFBS0wsT0FBTCxHQUFlSyxFQUFFQyxNQUFGLENBQVNDLE9BQXhCO0FBRUg7QUFKSyxTOzs7O0VBTnNCQyxlQUFLQyxTOztrQkFBcEJaLE0iLCJmaWxlIjoic3dpcGVyLmpzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbiAgICBpbXBvcnQgd2VweSBmcm9tIFwid2VweVwiO1xyXG4gICAgaW1wb3J0IG5hdmlnYXRvciBmcm9tICdAL21peGlucy9uYXZpZ2F0b3InXHJcbiAgICBleHBvcnQgZGVmYXVsdCBjbGFzcyBTd2lwZXIgZXh0ZW5kcyB3ZXB5LmNvbXBvbmVudCB7XHJcbiAgICAgICAgcHJvcHM9Wydtb2RlbCddXHJcbiAgICAgICAgZGF0YSA9IHtcclxuICAgICAgICAgICAgY2FyZEN1cjogMFxyXG4gICAgICAgIH07XHJcbiAgICAgICAgbWl4aW5zID0gW25hdmlnYXRvcl1cclxuICAgICAgICBtZXRob2RzID0ge1xyXG4gICAgICAgICAgICBjYXJkU3dpcGVyKGUpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuY2FyZEN1ciA9IGUuZGV0YWlsLmN1cnJlbnRcclxuXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9O1xyXG4gICAgfVxyXG4iXX0=