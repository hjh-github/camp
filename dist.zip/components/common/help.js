"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = undefined;

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var help = function (_wepy$component) {
    _inherits(help, _wepy$component);

    function help() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, help);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = help.__proto__ || Object.getPrototypeOf(help)).call.apply(_ref, [this].concat(args))), _this), _this.props = {
            init: {}
        }, _this.data = {
            help: _wepy2.default.$instance.globalData.help
        }, _this.methods = {
            close: function close() {
                this.help = _wepy2.default.$instance.globalData.help = false;
            }
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    return help;
}(_wepy2.default.component);

exports.default = help;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhlbHAuanMiXSwibmFtZXMiOlsiaGVscCIsInByb3BzIiwiaW5pdCIsImRhdGEiLCJ3ZXB5IiwiJGluc3RhbmNlIiwiZ2xvYmFsRGF0YSIsIm1ldGhvZHMiLCJjbG9zZSIsImNvbXBvbmVudCJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUNJOzs7Ozs7Ozs7Ozs7SUFDcUJBLEk7Ozs7Ozs7Ozs7Ozs7O3NMQUNqQkMsSyxHQUFRO0FBQ0pDLGtCQUFNO0FBREYsUyxRQUdSQyxJLEdBQU87QUFDSEgsa0JBQU1JLGVBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQk47QUFEN0IsUyxRQUdQTyxPLEdBQVU7QUFDTkMsaUJBRE0sbUJBQ0U7QUFDTCxxQkFBS1IsSUFBTCxHQUFhSSxlQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJOLElBQTFCLEdBQWlDLEtBQTlDO0FBQ0Y7QUFISyxTOzs7O0VBUG9CSSxlQUFLSyxTOztrQkFBbEJULEkiLCJmaWxlIjoiaGVscC5qcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4gICAgaW1wb3J0IHdlcHkgZnJvbSBcIndlcHlcIjtcclxuICAgIGV4cG9ydCBkZWZhdWx0IGNsYXNzIGhlbHAgZXh0ZW5kcyB3ZXB5LmNvbXBvbmVudCB7XHJcbiAgICAgICAgcHJvcHMgPSB7XHJcbiAgICAgICAgICAgIGluaXQ6IHt9XHJcbiAgICAgICAgfTtcclxuICAgICAgICBkYXRhID0ge1xyXG4gICAgICAgICAgICBoZWxwOiB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLmhlbHAsXHJcbiAgICAgICAgfTtcclxuICAgICAgICBtZXRob2RzID0ge1xyXG4gICAgICAgICAgICBjbG9zZSgpIHtcclxuICAgICAgICAgICAgICAgdGhpcy5oZWxwID0gIHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuaGVscCA9IGZhbHNlXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbiJdfQ==