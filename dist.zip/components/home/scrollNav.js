'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = undefined;

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$component) {
    _inherits(Dialog, _wepy$component);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.props = ['model', 'isfixed'], _this.data = {
            TabCur: 0,
            scrollLeft: 0,
            theme: _wepy2.default.$instance.globalData.themeColor,
            hasScreen: false,
            screens: [{
                id: 0,
                name: '默认',
                content: '默认排序'
            }, {
                id: 1,
                name: '时间',
                content: '开始时间由近到远'
            }, {
                id: 2,
                name: '人气',
                content: '人气从高到低'
            }],
            screenKey: '0'
        }, _this.methods = {
            tabSelect: function tabSelect(id, e) {
                if (this.TabCur == e.currentTarget.dataset.id) return false;
                this.TabCur = e.currentTarget.dataset.id;
                this.scrollLeft = (e.currentTarget.dataset.id - 1) * 60;
                this.$emit('ret', id, this.screenKey);
            },
            screen: function screen() {
                this.hasScreen = !this.hasScreen;
            },
            che_screen: function che_screen(screenKey) {
                if (this.screenKey == screenKey) return false;
                this.hasScreen = false;
                this.screenKey = screenKey;
                this.$emit('ret', this.model[this.TabCur].id, screenKey);
            }
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    return Dialog;
}(_wepy2.default.component);

exports.default = Dialog;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNjcm9sbE5hdi5qcyJdLCJuYW1lcyI6WyJEaWFsb2ciLCJwcm9wcyIsImRhdGEiLCJUYWJDdXIiLCJzY3JvbGxMZWZ0IiwidGhlbWUiLCJ3ZXB5IiwiJGluc3RhbmNlIiwiZ2xvYmFsRGF0YSIsInRoZW1lQ29sb3IiLCJoYXNTY3JlZW4iLCJzY3JlZW5zIiwiaWQiLCJuYW1lIiwiY29udGVudCIsInNjcmVlbktleSIsIm1ldGhvZHMiLCJ0YWJTZWxlY3QiLCJlIiwiY3VycmVudFRhcmdldCIsImRhdGFzZXQiLCIkZW1pdCIsInNjcmVlbiIsImNoZV9zY3JlZW4iLCJtb2RlbCIsImNvbXBvbmVudCJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUNJOzs7Ozs7Ozs7Ozs7SUFDcUJBLE07Ozs7Ozs7Ozs7Ozs7OzBMQUNqQkMsSyxHQUFRLENBQUMsT0FBRCxFQUFVLFNBQVYsQyxRQUNSQyxJLEdBQU87QUFDSEMsb0JBQVEsQ0FETDtBQUVIQyx3QkFBWSxDQUZUO0FBR0hDLG1CQUFPQyxlQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJDLFVBSDlCO0FBSUhDLHVCQUFXLEtBSlI7QUFLSEMscUJBQVEsQ0FBQztBQUNMQyxvQkFBRyxDQURFO0FBRUxDLHNCQUFLLElBRkE7QUFHTEMseUJBQVE7QUFISCxhQUFELEVBSU47QUFDRUYsb0JBQUcsQ0FETDtBQUVFQyxzQkFBSyxJQUZQO0FBR0VDLHlCQUFRO0FBSFYsYUFKTSxFQVFOO0FBQ0VGLG9CQUFHLENBREw7QUFFRUMsc0JBQUssSUFGUDtBQUdFQyx5QkFBUTtBQUhWLGFBUk0sQ0FMTDtBQWtCSEMsdUJBQVc7QUFsQlIsUyxRQW9CUEMsTyxHQUFVO0FBQ05DLHFCQURNLHFCQUNJTCxFQURKLEVBQ1FNLENBRFIsRUFDVztBQUNiLG9CQUFHLEtBQUtmLE1BQUwsSUFBZWUsRUFBRUMsYUFBRixDQUFnQkMsT0FBaEIsQ0FBd0JSLEVBQTFDLEVBQThDLE9BQU8sS0FBUDtBQUM5QyxxQkFBS1QsTUFBTCxHQUFjZSxFQUFFQyxhQUFGLENBQWdCQyxPQUFoQixDQUF3QlIsRUFBdEM7QUFDQSxxQkFBS1IsVUFBTCxHQUFrQixDQUFDYyxFQUFFQyxhQUFGLENBQWdCQyxPQUFoQixDQUF3QlIsRUFBeEIsR0FBNkIsQ0FBOUIsSUFBbUMsRUFBckQ7QUFDQSxxQkFBS1MsS0FBTCxDQUFXLEtBQVgsRUFBa0JULEVBQWxCLEVBQXNCLEtBQUtHLFNBQTNCO0FBQ0gsYUFOSztBQU9OTyxrQkFQTSxvQkFPRztBQUNMLHFCQUFLWixTQUFMLEdBQWlCLENBQUMsS0FBS0EsU0FBdkI7QUFDSCxhQVRLO0FBVU5hLHNCQVZNLHNCQVVLUixTQVZMLEVBVWdCO0FBQ2xCLG9CQUFHLEtBQUtBLFNBQUwsSUFBa0JBLFNBQXJCLEVBQWdDLE9BQU8sS0FBUDtBQUNoQyxxQkFBS0wsU0FBTCxHQUFpQixLQUFqQjtBQUNBLHFCQUFLSyxTQUFMLEdBQWlCQSxTQUFqQjtBQUNBLHFCQUFLTSxLQUFMLENBQVcsS0FBWCxFQUFrQixLQUFLRyxLQUFMLENBQVcsS0FBS3JCLE1BQWhCLEVBQXdCUyxFQUExQyxFQUE4Q0csU0FBOUM7QUFDSDtBQWZLLFM7Ozs7RUF0QnNCVCxlQUFLbUIsUzs7a0JBQXBCekIsTSIsImZpbGUiOiJzY3JvbGxOYXYuanMiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuICAgIGltcG9ydCB3ZXB5IGZyb20gXCJ3ZXB5XCI7XHJcbiAgICBleHBvcnQgZGVmYXVsdCBjbGFzcyBEaWFsb2cgZXh0ZW5kcyB3ZXB5LmNvbXBvbmVudCB7XHJcbiAgICAgICAgcHJvcHMgPSBbJ21vZGVsJywgJ2lzZml4ZWQnXVxyXG4gICAgICAgIGRhdGEgPSB7XHJcbiAgICAgICAgICAgIFRhYkN1cjogMCxcclxuICAgICAgICAgICAgc2Nyb2xsTGVmdDogMCxcclxuICAgICAgICAgICAgdGhlbWU6IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEudGhlbWVDb2xvcixcclxuICAgICAgICAgICAgaGFzU2NyZWVuOiBmYWxzZSxcclxuICAgICAgICAgICAgc2NyZWVuczpbe1xyXG4gICAgICAgICAgICAgICAgaWQ6MCxcclxuICAgICAgICAgICAgICAgIG5hbWU6J+m7mOiupCcsXHJcbiAgICAgICAgICAgICAgICBjb250ZW50Oifpu5jorqTmjpLluo8nXHJcbiAgICAgICAgICAgIH0se1xyXG4gICAgICAgICAgICAgICAgaWQ6MSxcclxuICAgICAgICAgICAgICAgIG5hbWU6J+aXtumXtCcsXHJcbiAgICAgICAgICAgICAgICBjb250ZW50OiflvIDlp4vml7bpl7TnlLHov5HliLDov5wnXHJcbiAgICAgICAgICAgIH0se1xyXG4gICAgICAgICAgICAgICAgaWQ6MixcclxuICAgICAgICAgICAgICAgIG5hbWU6J+S6uuawlCcsXHJcbiAgICAgICAgICAgICAgICBjb250ZW50OifkurrmsJTku47pq5jliLDkvY4nXHJcbiAgICAgICAgICAgIH1dLFxyXG4gICAgICAgICAgICBzY3JlZW5LZXk6ICcwJ1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgbWV0aG9kcyA9IHtcclxuICAgICAgICAgICAgdGFiU2VsZWN0KGlkLCBlKSB7XHJcbiAgICAgICAgICAgICAgICBpZih0aGlzLlRhYkN1ciA9PSBlLmN1cnJlbnRUYXJnZXQuZGF0YXNldC5pZCkgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgICAgICAgICB0aGlzLlRhYkN1ciA9IGUuY3VycmVudFRhcmdldC5kYXRhc2V0LmlkO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zY3JvbGxMZWZ0ID0gKGUuY3VycmVudFRhcmdldC5kYXRhc2V0LmlkIC0gMSkgKiA2MFxyXG4gICAgICAgICAgICAgICAgdGhpcy4kZW1pdCgncmV0JywgaWQsIHRoaXMuc2NyZWVuS2V5KVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBzY3JlZW4oKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmhhc1NjcmVlbiA9ICF0aGlzLmhhc1NjcmVlblxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBjaGVfc2NyZWVuKHNjcmVlbktleSkge1xyXG4gICAgICAgICAgICAgICAgaWYodGhpcy5zY3JlZW5LZXkgPT0gc2NyZWVuS2V5KSByZXR1cm4gZmFsc2VcclxuICAgICAgICAgICAgICAgIHRoaXMuaGFzU2NyZWVuID0gZmFsc2VcclxuICAgICAgICAgICAgICAgIHRoaXMuc2NyZWVuS2V5ID0gc2NyZWVuS2V5XHJcbiAgICAgICAgICAgICAgICB0aGlzLiRlbWl0KCdyZXQnLCB0aGlzLm1vZGVsW3RoaXMuVGFiQ3VyXS5pZCwgc2NyZWVuS2V5KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuIl19