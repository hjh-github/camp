'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = undefined;

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var card = function (_wepy$component) {
    _inherits(card, _wepy$component);

    function card() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, card);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = card.__proto__ || Object.getPrototypeOf(card)).call.apply(_ref, [this].concat(args))), _this), _this.props = ['model'], _this.data = {
            theme: _wepy2.default.$instance.globalData.themeColor
        }, _this.methods = {
            toDetaile: function toDetaile(id) {
                _wepy2.default.navigateTo({ url: '/pages/detaile/detaile?id=' + id });
            }
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    return card;
}(_wepy2.default.component);

exports.default = card;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNDYXJkLmpzIl0sIm5hbWVzIjpbImNhcmQiLCJwcm9wcyIsImRhdGEiLCJ0aGVtZSIsIndlcHkiLCIkaW5zdGFuY2UiLCJnbG9iYWxEYXRhIiwidGhlbWVDb2xvciIsIm1ldGhvZHMiLCJ0b0RldGFpbGUiLCJpZCIsIm5hdmlnYXRlVG8iLCJ1cmwiLCJjb21wb25lbnQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFDSTs7Ozs7Ozs7Ozs7O0lBQ3FCQSxJOzs7Ozs7Ozs7Ozs7OztzTEFDakJDLEssR0FBTSxDQUFDLE9BQUQsQyxRQUNOQyxJLEdBQU87QUFDSEMsbUJBQU9DLGVBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQkM7QUFEOUIsUyxRQUdQQyxPLEdBQVU7QUFDTkMscUJBRE0scUJBQ0lDLEVBREosRUFDTztBQUNUTiwrQkFBS08sVUFBTCxDQUFnQixFQUFFQyxLQUFLLCtCQUErQkYsRUFBdEMsRUFBaEI7QUFFSDtBQUpLLFM7Ozs7RUFMb0JOLGVBQUtTLFM7O2tCQUFsQmIsSSIsImZpbGUiOiJjQ2FyZC5qcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4gICAgaW1wb3J0IHdlcHkgZnJvbSBcIndlcHlcIjtcclxuICAgIGV4cG9ydCBkZWZhdWx0IGNsYXNzIGNhcmQgZXh0ZW5kcyB3ZXB5LmNvbXBvbmVudCB7XHJcbiAgICAgICAgcHJvcHM9Wydtb2RlbCddXHJcbiAgICAgICAgZGF0YSA9IHtcclxuICAgICAgICAgICAgdGhlbWU6IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEudGhlbWVDb2xvclxyXG4gICAgICAgIH07XHJcbiAgICAgICAgbWV0aG9kcyA9IHtcclxuICAgICAgICAgICAgdG9EZXRhaWxlKGlkKXtcclxuICAgICAgICAgICAgICAgIHdlcHkubmF2aWdhdGVUbyh7IHVybDogJy9wYWdlcy9kZXRhaWxlL2RldGFpbGU/aWQ9JyArIGlkIH0pO1xyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9O1xyXG4gICAgfVxyXG4iXX0=