"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = undefined;

var _dec, _class;

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _wepyRedux = require('./../../npm/wepy-redux/lib/index.js');

var _utils = require('./../../store/utils.js');

var _utils2 = _interopRequireDefault(_utils);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = (_dec = (0, _wepyRedux.connect)({
    city: _utils2.default.get("city")
}), _dec(_class = function (_wepy$component) {
    _inherits(Dialog, _wepy$component);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.data = {
            theme: _wepy2.default.$instance.globalData.themeColor
        }, _this.methods = {
            navigator: function navigator() {
                _wepy2.default.navigateTo({
                    url: '/pages/home/address'
                });
            },
            toser: function toser() {
                _wepy2.default.navigateTo({
                    url: '/pages/home/search'
                });
            }
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    return Dialog;
}(_wepy2.default.component)) || _class);
exports.default = Dialog;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhlYWRlci5qcyJdLCJuYW1lcyI6WyJEaWFsb2ciLCJjaXR5Iiwic3RvcmUiLCJnZXQiLCJkYXRhIiwidGhlbWUiLCJ3ZXB5IiwiJGluc3RhbmNlIiwiZ2xvYmFsRGF0YSIsInRoZW1lQ29sb3IiLCJtZXRob2RzIiwibmF2aWdhdG9yIiwibmF2aWdhdGVUbyIsInVybCIsInRvc2VyIiwiY29tcG9uZW50Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFDSTs7OztBQUNBOztBQUdBOzs7Ozs7Ozs7Ozs7SUFJcUJBLE0sV0FIcEIsd0JBQVE7QUFDTEMsVUFBTUMsZ0JBQU1DLEdBQU4sQ0FBVSxNQUFWO0FBREQsQ0FBUixDOzs7Ozs7Ozs7Ozs7OzswTEFJR0MsSSxHQUFPO0FBQ0hDLG1CQUFPQyxlQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJDO0FBRDlCLFMsUUFHUEMsTyxHQUFVO0FBQ05DLHFCQURNLHVCQUNNO0FBQ1JMLCtCQUFLTSxVQUFMLENBQWdCO0FBQ1pDLHlCQUFLO0FBRE8saUJBQWhCO0FBR0gsYUFMSztBQU1OQyxpQkFOTSxtQkFNRTtBQUNKUiwrQkFBS00sVUFBTCxDQUFnQjtBQUNaQyx5QkFBSztBQURPLGlCQUFoQjtBQUdIO0FBVkssUzs7OztFQUpzQlAsZUFBS1MsUztrQkFBcEJmLE0iLCJmaWxlIjoiaGVhZGVyLmpzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbiAgICBpbXBvcnQgd2VweSBmcm9tIFwid2VweVwiO1xyXG4gICAgaW1wb3J0IHtcclxuICAgICAgICBjb25uZWN0XHJcbiAgICB9IGZyb20gXCJ3ZXB5LXJlZHV4XCJcclxuICAgIGltcG9ydCBzdG9yZSBmcm9tIFwiQC9zdG9yZS91dGlsc1wiXHJcbiAgICBAY29ubmVjdCh7XHJcbiAgICAgICAgY2l0eTogc3RvcmUuZ2V0KFwiY2l0eVwiKVxyXG4gICAgfSlcclxuICAgIGV4cG9ydCBkZWZhdWx0IGNsYXNzIERpYWxvZyBleHRlbmRzIHdlcHkuY29tcG9uZW50IHtcclxuICAgICAgICBkYXRhID0ge1xyXG4gICAgICAgICAgICB0aGVtZTogd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS50aGVtZUNvbG9yXHJcbiAgICAgICAgfTtcclxuICAgICAgICBtZXRob2RzID0ge1xyXG4gICAgICAgICAgICBuYXZpZ2F0b3IoKSB7XHJcbiAgICAgICAgICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICAgICAgICAgIHVybDogJy9wYWdlcy9ob21lL2FkZHJlc3MnXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgdG9zZXIoKSB7XHJcbiAgICAgICAgICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICAgICAgICAgIHVybDogJy9wYWdlcy9ob21lL3NlYXJjaCdcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuIl19