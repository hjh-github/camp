'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = undefined;

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _Tips = require('./Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

var _wepy = require('./../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var WxUtils = function () {
  function WxUtils() {
    _classCallCheck(this, WxUtils);
  }

  _createClass(WxUtils, null, [{
    key: 'isTab',
    value: function isTab(url) {
      var type = _wepy2.default.$instance.globalData.shopType;
      return this.tabUrls.some(function (path) {
        return path == url;
      });
    }
  }, {
    key: 'mapUrl',
    value: function mapUrl(url) {
      var type = _wepy2.default.$instance.globalData.shopType;
      if (type == 1 && this.mapUrls[url]) {
        return this.mapUrls[url];
      } else {
        return url;
      }
    }

    /**
     * 如果能够后退（多层），则navigaetBack，否则调用redirectTo
     */

  }, {
    key: 'backOrRedirect',
    value: function backOrRedirect(url) {
      url = this.mapUrl(url);
      if (this.isTab(url)) {
        wx.switchTab({
          url: url
        });
      } else {
        var pages = getCurrentPages();
        // route在低版本不兼容
        var index = pages.findIndex(function (item) {
          return '/' + item.__route__ == url;
        });
        if (pages.length < 2 || index < 0) {
          wx.redirectTo({
            url: url
          });
        } else {
          var delta = pages.length - 1 - index;
          wx.navigateBack({
            delta: delta
          });
        }
      }
    }
    /**
     * 如果能够后退（多层），则navigaetBack，否则调用navigateTo
     */

  }, {
    key: 'backOrNavigate',
    value: function backOrNavigate(url) {
      url = this.mapUrl(url);
      if (this.isTab(url)) {
        wx.switchTab({
          url: url
        });
      } else {
        var pages = getCurrentPages();
        // route在低版本不兼容
        var index = pages.findIndex(function (item) {
          return '/' + item.__route__ == url;
        });
        if (pages.length < 2 || index < 0) {
          wx.navigateTo({
            url: url
          });
        } else {
          var delta = pages.length - 1 - index;
          wx.navigateBack({
            delta: delta
          });
        }
      }
    }
  }, {
    key: 'wxPay',
    value: function wxPay(param) {
      console.log(param);
      return new Promise(function (resolve, reject) {
        wx.requestPayment(_extends({}, param, {
          complete: function complete(res) {
            if (res.errMsg == 'requestPayment:ok') {
              resolve(res);
            } else {
              reject(res);
            }
          }
        }));
      });
    }

    /**
     * 兼容性判断
     */

  }, {
    key: 'canIUse',
    value: function canIUse(str) {
      if (wx.canIUse) {
        return wx.canIUse(str);
      } else {
        return false;
      }
    }
    /**
     * 检查SDK版本
     */

  }, {
    key: 'isSDKExipred',
    value: function isSDKExipred() {
      var _wx$getSystemInfoSync = wx.getSystemInfoSync(),
          SDKVersion = _wx$getSystemInfoSync.SDKVersion;
      // console.info(`[version]sdk ${SDKVersion}`);


      return SDKVersion == null || SDKVersion < '1.2.0';
    }
    /**
     * 检查SDK版本
     */

  }, {
    key: 'checkSDK',
    value: function checkSDK() {
      if (this.isSDKExipred()) {
        _Tips2.default.modal('您的微信版本太低，为确保正常使用，请尽快升级');
      }
    }
  }]);

  return WxUtils;
}();

WxUtils.tabUrls = ['/pages/home/index'];
WxUtils.mapUrls = {
  '/pages/shop/index': '/pages/home/template',
  '/pages/home/home': '/pages/home/template'
};
exports.default = WxUtils;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIld4VXRpbHMuanMiXSwibmFtZXMiOlsiV3hVdGlscyIsInVybCIsInR5cGUiLCJ3ZXB5IiwiJGluc3RhbmNlIiwiZ2xvYmFsRGF0YSIsInNob3BUeXBlIiwidGFiVXJscyIsInNvbWUiLCJwYXRoIiwibWFwVXJscyIsIm1hcFVybCIsImlzVGFiIiwid3giLCJzd2l0Y2hUYWIiLCJwYWdlcyIsImdldEN1cnJlbnRQYWdlcyIsImluZGV4IiwiZmluZEluZGV4IiwiaXRlbSIsIl9fcm91dGVfXyIsImxlbmd0aCIsInJlZGlyZWN0VG8iLCJkZWx0YSIsIm5hdmlnYXRlQmFjayIsIm5hdmlnYXRlVG8iLCJwYXJhbSIsImNvbnNvbGUiLCJsb2ciLCJQcm9taXNlIiwicmVzb2x2ZSIsInJlamVjdCIsInJlcXVlc3RQYXltZW50IiwiY29tcGxldGUiLCJyZXMiLCJlcnJNc2ciLCJzdHIiLCJjYW5JVXNlIiwiZ2V0U3lzdGVtSW5mb1N5bmMiLCJTREtWZXJzaW9uIiwiaXNTREtFeGlwcmVkIiwiVGlwcyIsIm1vZGFsIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUFBOzs7O0FBQ0E7Ozs7Ozs7O0lBRXFCQSxPOzs7Ozs7OzBCQU9MQyxHLEVBQUs7QUFDakIsVUFBTUMsT0FBT0MsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCQyxRQUF2QztBQUNBLGFBQU8sS0FBS0MsT0FBTCxDQUFhQyxJQUFiLENBQWtCO0FBQUEsZUFBUUMsUUFBUVIsR0FBaEI7QUFBQSxPQUFsQixDQUFQO0FBQ0Q7OzsyQkFDY0EsRyxFQUFLO0FBQ2xCLFVBQU1DLE9BQU9DLGVBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQkMsUUFBdkM7QUFDQSxVQUFJSixRQUFRLENBQVIsSUFBYSxLQUFLUSxPQUFMLENBQWFULEdBQWIsQ0FBakIsRUFBb0M7QUFDbEMsZUFBTyxLQUFLUyxPQUFMLENBQWFULEdBQWIsQ0FBUDtBQUNELE9BRkQsTUFFTztBQUNMLGVBQU9BLEdBQVA7QUFDRDtBQUNGOztBQUVEOzs7Ozs7bUNBR3NCQSxHLEVBQUs7QUFDekJBLFlBQU0sS0FBS1UsTUFBTCxDQUFZVixHQUFaLENBQU47QUFDQSxVQUFJLEtBQUtXLEtBQUwsQ0FBV1gsR0FBWCxDQUFKLEVBQXFCO0FBQ25CWSxXQUFHQyxTQUFILENBQWE7QUFDWGIsZUFBS0E7QUFETSxTQUFiO0FBR0QsT0FKRCxNQUlPO0FBQ0wsWUFBTWMsUUFBUUMsaUJBQWQ7QUFDQTtBQUNBLFlBQU1DLFFBQVFGLE1BQU1HLFNBQU4sQ0FBZ0I7QUFBQSxpQkFBUyxNQUFNQyxLQUFLQyxTQUFaLElBQTBCbkIsR0FBbEM7QUFBQSxTQUFoQixDQUFkO0FBQ0EsWUFBSWMsTUFBTU0sTUFBTixHQUFlLENBQWYsSUFBb0JKLFFBQVEsQ0FBaEMsRUFBbUM7QUFDakNKLGFBQUdTLFVBQUgsQ0FBYztBQUNackIsaUJBQUtBO0FBRE8sV0FBZDtBQUdELFNBSkQsTUFJTztBQUNMLGNBQU1zQixRQUFRUixNQUFNTSxNQUFOLEdBQWUsQ0FBZixHQUFtQkosS0FBakM7QUFDQUosYUFBR1csWUFBSCxDQUFnQjtBQUNkRCxtQkFBT0E7QUFETyxXQUFoQjtBQUdEO0FBQ0Y7QUFDRjtBQUNEOzs7Ozs7bUNBR3NCdEIsRyxFQUFLO0FBQ3pCQSxZQUFNLEtBQUtVLE1BQUwsQ0FBWVYsR0FBWixDQUFOO0FBQ0EsVUFBSSxLQUFLVyxLQUFMLENBQVdYLEdBQVgsQ0FBSixFQUFxQjtBQUNuQlksV0FBR0MsU0FBSCxDQUFhO0FBQ1hiLGVBQUtBO0FBRE0sU0FBYjtBQUdELE9BSkQsTUFJTztBQUNMLFlBQU1jLFFBQVFDLGlCQUFkO0FBQ0E7QUFDQSxZQUFNQyxRQUFRRixNQUFNRyxTQUFOLENBQWdCO0FBQUEsaUJBQVMsTUFBTUMsS0FBS0MsU0FBWixJQUEwQm5CLEdBQWxDO0FBQUEsU0FBaEIsQ0FBZDtBQUNBLFlBQUljLE1BQU1NLE1BQU4sR0FBZSxDQUFmLElBQW9CSixRQUFRLENBQWhDLEVBQW1DO0FBQ2pDSixhQUFHWSxVQUFILENBQWM7QUFDWnhCLGlCQUFLQTtBQURPLFdBQWQ7QUFHRCxTQUpELE1BSU87QUFDTCxjQUFNc0IsUUFBUVIsTUFBTU0sTUFBTixHQUFlLENBQWYsR0FBbUJKLEtBQWpDO0FBQ0FKLGFBQUdXLFlBQUgsQ0FBZ0I7QUFDZEQsbUJBQU9BO0FBRE8sV0FBaEI7QUFHRDtBQUNGO0FBQ0Y7OzswQkFFWUcsSyxFQUFPO0FBQ2xCQyxjQUFRQyxHQUFSLENBQVlGLEtBQVo7QUFDQSxhQUFPLElBQUlHLE9BQUosQ0FBWSxVQUFDQyxPQUFELEVBQVVDLE1BQVYsRUFBcUI7QUFDdENsQixXQUFHbUIsY0FBSCxjQUNLTixLQURMO0FBRUVPLG9CQUFVLHVCQUFPO0FBQ2YsZ0JBQUlDLElBQUlDLE1BQUosSUFBYyxtQkFBbEIsRUFBdUM7QUFDckNMLHNCQUFRSSxHQUFSO0FBQ0QsYUFGRCxNQUVPO0FBQ0xILHFCQUFPRyxHQUFQO0FBQ0Q7QUFDRjtBQVJIO0FBVUQsT0FYTSxDQUFQO0FBWUQ7O0FBRUQ7Ozs7Ozs0QkFHZUUsRyxFQUFLO0FBQ2xCLFVBQUl2QixHQUFHd0IsT0FBUCxFQUFnQjtBQUNkLGVBQU94QixHQUFHd0IsT0FBSCxDQUFXRCxHQUFYLENBQVA7QUFDRCxPQUZELE1BRU87QUFDTCxlQUFPLEtBQVA7QUFDRDtBQUNGO0FBQ0Q7Ozs7OzttQ0FHc0I7QUFBQSxrQ0FDQ3ZCLEdBQUd5QixpQkFBSCxFQUREO0FBQUEsVUFDYkMsVUFEYSx5QkFDYkEsVUFEYTtBQUVwQjs7O0FBQ0EsYUFBT0EsY0FBYyxJQUFkLElBQXNCQSxhQUFhLE9BQTFDO0FBQ0Q7QUFDRDs7Ozs7OytCQUdrQjtBQUNoQixVQUFJLEtBQUtDLFlBQUwsRUFBSixFQUF5QjtBQUN2QkMsdUJBQUtDLEtBQUwsQ0FBVyx3QkFBWDtBQUNEO0FBQ0Y7Ozs7OztBQWhIa0IxQyxPLENBQ1pPLE8sR0FBVSxDQUFDLG1CQUFELEM7QUFERVAsTyxDQUVaVSxPLEdBQVU7QUFDZix1QkFBcUIsc0JBRE47QUFFZixzQkFBb0I7QUFGTCxDO2tCQUZFVixPIiwiZmlsZSI6Ild4VXRpbHMuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgVGlwcyBmcm9tICcuL1RpcHMnO1xyXG5pbXBvcnQgd2VweSBmcm9tICd3ZXB5JztcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFd4VXRpbHMge1xyXG4gIHN0YXRpYyB0YWJVcmxzID0gWycvcGFnZXMvaG9tZS9pbmRleCddO1xyXG4gIHN0YXRpYyBtYXBVcmxzID0ge1xyXG4gICAgJy9wYWdlcy9zaG9wL2luZGV4JzogJy9wYWdlcy9ob21lL3RlbXBsYXRlJyxcclxuICAgICcvcGFnZXMvaG9tZS9ob21lJzogJy9wYWdlcy9ob21lL3RlbXBsYXRlJ1xyXG4gIH07XHJcblxyXG4gIHN0YXRpYyBpc1RhYiAodXJsKSB7XHJcbiAgICBjb25zdCB0eXBlID0gd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5zaG9wVHlwZTtcclxuICAgIHJldHVybiB0aGlzLnRhYlVybHMuc29tZShwYXRoID0+IHBhdGggPT0gdXJsKTtcclxuICB9XHJcbiAgc3RhdGljIG1hcFVybCAodXJsKSB7XHJcbiAgICBjb25zdCB0eXBlID0gd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5zaG9wVHlwZTtcclxuICAgIGlmICh0eXBlID09IDEgJiYgdGhpcy5tYXBVcmxzW3VybF0pIHtcclxuICAgICAgcmV0dXJuIHRoaXMubWFwVXJsc1t1cmxdO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIHVybDtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIOWmguaenOiDveWkn+WQjumAgO+8iOWkmuWxgu+8ie+8jOWImW5hdmlnYWV0QmFja++8jOWQpuWImeiwg+eUqHJlZGlyZWN0VG9cclxuICAgKi9cclxuICBzdGF0aWMgYmFja09yUmVkaXJlY3QodXJsKSB7XHJcbiAgICB1cmwgPSB0aGlzLm1hcFVybCh1cmwpO1xyXG4gICAgaWYgKHRoaXMuaXNUYWIodXJsKSkge1xyXG4gICAgICB3eC5zd2l0Y2hUYWIoe1xyXG4gICAgICAgIHVybDogdXJsXHJcbiAgICAgIH0pXHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBjb25zdCBwYWdlcyA9IGdldEN1cnJlbnRQYWdlcygpO1xyXG4gICAgICAvLyByb3V0ZeWcqOS9jueJiOacrOS4jeWFvOWuuVxyXG4gICAgICBjb25zdCBpbmRleCA9IHBhZ2VzLmZpbmRJbmRleChpdGVtID0+ICgnLycgKyBpdGVtLl9fcm91dGVfXykgPT0gdXJsKTtcclxuICAgICAgaWYgKHBhZ2VzLmxlbmd0aCA8IDIgfHwgaW5kZXggPCAwKSB7XHJcbiAgICAgICAgd3gucmVkaXJlY3RUbyh7XHJcbiAgICAgICAgICB1cmw6IHVybFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGNvbnN0IGRlbHRhID0gcGFnZXMubGVuZ3RoIC0gMSAtIGluZGV4O1xyXG4gICAgICAgIHd4Lm5hdmlnYXRlQmFjayh7XHJcbiAgICAgICAgICBkZWx0YTogZGVsdGFcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuICAvKipcclxuICAgKiDlpoLmnpzog73lpJ/lkI7pgIDvvIjlpJrlsYLvvInvvIzliJluYXZpZ2FldEJhY2vvvIzlkKbliJnosIPnlKhuYXZpZ2F0ZVRvXHJcbiAgICovXHJcbiAgc3RhdGljIGJhY2tPck5hdmlnYXRlKHVybCkge1xyXG4gICAgdXJsID0gdGhpcy5tYXBVcmwodXJsKTtcclxuICAgIGlmICh0aGlzLmlzVGFiKHVybCkpIHtcclxuICAgICAgd3guc3dpdGNoVGFiKHtcclxuICAgICAgICB1cmw6IHVybFxyXG4gICAgICB9KVxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgY29uc3QgcGFnZXMgPSBnZXRDdXJyZW50UGFnZXMoKTtcclxuICAgICAgLy8gcm91dGXlnKjkvY7niYjmnKzkuI3lhbzlrrlcclxuICAgICAgY29uc3QgaW5kZXggPSBwYWdlcy5maW5kSW5kZXgoaXRlbSA9PiAoJy8nICsgaXRlbS5fX3JvdXRlX18pID09IHVybCk7XHJcbiAgICAgIGlmIChwYWdlcy5sZW5ndGggPCAyIHx8IGluZGV4IDwgMCkge1xyXG4gICAgICAgIHd4Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgdXJsOiB1cmxcclxuICAgICAgICB9KTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBjb25zdCBkZWx0YSA9IHBhZ2VzLmxlbmd0aCAtIDEgLSBpbmRleDtcclxuICAgICAgICB3eC5uYXZpZ2F0ZUJhY2soe1xyXG4gICAgICAgICAgZGVsdGE6IGRlbHRhXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcblxyXG4gIHN0YXRpYyB3eFBheShwYXJhbSkge1xyXG4gICAgY29uc29sZS5sb2cocGFyYW0pXHJcbiAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICB3eC5yZXF1ZXN0UGF5bWVudCh7XHJcbiAgICAgICAgLi4ucGFyYW0sXHJcbiAgICAgICAgY29tcGxldGU6IHJlcyA9PiB7XHJcbiAgICAgICAgICBpZiAocmVzLmVyck1zZyA9PSAncmVxdWVzdFBheW1lbnQ6b2snKSB7XHJcbiAgICAgICAgICAgIHJlc29sdmUocmVzKTtcclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJlamVjdChyZXMpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIOWFvOWuueaAp+WIpOaWrVxyXG4gICAqL1xyXG4gIHN0YXRpYyBjYW5JVXNlKHN0cikge1xyXG4gICAgaWYgKHd4LmNhbklVc2UpIHtcclxuICAgICAgcmV0dXJuIHd4LmNhbklVc2Uoc3RyKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJldHVybiBmYWxzZTtcclxuICAgIH1cclxuICB9XHJcbiAgLyoqXHJcbiAgICog5qOA5p+lU0RL54mI5pysXHJcbiAgICovXHJcbiAgc3RhdGljIGlzU0RLRXhpcHJlZCgpIHtcclxuICAgIGNvbnN0IHtTREtWZXJzaW9ufSA9IHd4LmdldFN5c3RlbUluZm9TeW5jKCk7XHJcbiAgICAvLyBjb25zb2xlLmluZm8oYFt2ZXJzaW9uXXNkayAke1NES1ZlcnNpb259YCk7XHJcbiAgICByZXR1cm4gU0RLVmVyc2lvbiA9PSBudWxsIHx8IFNES1ZlcnNpb24gPCAnMS4yLjAnXHJcbiAgfVxyXG4gIC8qKlxyXG4gICAqIOajgOafpVNES+eJiOacrFxyXG4gICAqL1xyXG4gIHN0YXRpYyBjaGVja1NESygpIHtcclxuICAgIGlmICh0aGlzLmlzU0RLRXhpcHJlZCgpKSB7XHJcbiAgICAgIFRpcHMubW9kYWwoJ+aCqOeahOW+ruS/oeeJiOacrOWkquS9ju+8jOS4uuehruS/neato+W4uOS9v+eUqO+8jOivt+WwveW/q+WNh+e6pycpO1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG4iXX0=