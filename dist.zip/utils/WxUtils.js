'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = undefined;

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _Tips = require('./Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

var _wepy = require('./../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var WxUtils = function () {
  function WxUtils() {
    _classCallCheck(this, WxUtils);
  }

  _createClass(WxUtils, null, [{
    key: 'isTab',
    value: function isTab(url) {
      var type = _wepy2.default.$instance.globalData.shopType;
      return type == 1 && this.tabUrls.some(function (path) {
        return path == url;
      });
    }
  }, {
    key: 'mapUrl',
    value: function mapUrl(url) {
      var type = _wepy2.default.$instance.globalData.shopType;
      if (type == 1 && this.mapUrls[url]) {
        return this.mapUrls[url];
      } else {
        return url;
      }
    }

    /**
     * 如果能够后退（多层），则navigaetBack，否则调用redirectTo
     */

  }, {
    key: 'backOrRedirect',
    value: function backOrRedirect(url) {
      url = this.mapUrl(url);
      if (this.isTab(url)) {
        wx.switchTab({
          url: url
        });
      } else {
        var pages = getCurrentPages();
        // route在低版本不兼容
        var index = pages.findIndex(function (item) {
          return '/' + item.__route__ == url;
        });
        if (pages.length < 2 || index < 0) {
          wx.redirectTo({
            url: url
          });
        } else {
          var delta = pages.length - 1 - index;
          wx.navigateBack({
            delta: delta
          });
        }
      }
    }
    /**
     * 如果能够后退（多层），则navigaetBack，否则调用navigateTo
     */

  }, {
    key: 'backOrNavigate',
    value: function backOrNavigate(url) {
      url = this.mapUrl(url);
      if (this.isTab(url)) {
        wx.switchTab({
          url: url
        });
      } else {
        var pages = getCurrentPages();
        // route在低版本不兼容
        var index = pages.findIndex(function (item) {
          return '/' + item.__route__ == url;
        });
        if (pages.length < 2 || index < 0) {
          wx.navigateTo({
            url: url
          });
        } else {
          var delta = pages.length - 1 - index;
          wx.navigateBack({
            delta: delta
          });
        }
      }
    }
  }, {
    key: 'wxPay',
    value: function wxPay(param) {
      console.log(param);
      return new Promise(function (resolve, reject) {
        wx.requestPayment(_extends({}, param, {
          complete: function complete(res) {
            if (res.errMsg == 'requestPayment:ok') {
              resolve(res);
            } else {
              reject(res);
            }
          }
        }));
      });
    }

    /**
     * 兼容性判断
     */

  }, {
    key: 'canIUse',
    value: function canIUse(str) {
      if (wx.canIUse) {
        return wx.canIUse(str);
      } else {
        return false;
      }
    }
    /**
     * 检查SDK版本
     */

  }, {
    key: 'isSDKExipred',
    value: function isSDKExipred() {
      var _wx$getSystemInfoSync = wx.getSystemInfoSync(),
          SDKVersion = _wx$getSystemInfoSync.SDKVersion;
      // console.info(`[version]sdk ${SDKVersion}`);


      return SDKVersion == null || SDKVersion < '1.2.0';
    }
    /**
     * 检查SDK版本
     */

  }, {
    key: 'checkSDK',
    value: function checkSDK() {
      if (this.isSDKExipred()) {
        _Tips2.default.modal('您的微信版本太低，为确保正常使用，请尽快升级');
      }
    }
  }]);

  return WxUtils;
}();

WxUtils.tabUrls = ['/pages/home/template', '/pages/goods/category', '/pages/goods/cart', '/pages/customer/index', '/pages/customer/index_template'];
WxUtils.mapUrls = {
  '/pages/shop/index': '/pages/home/template',
  '/pages/home/home': '/pages/home/template'
};
exports.default = WxUtils;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIld4VXRpbHMuanMiXSwibmFtZXMiOlsiV3hVdGlscyIsInVybCIsInR5cGUiLCJ3ZXB5IiwiJGluc3RhbmNlIiwiZ2xvYmFsRGF0YSIsInNob3BUeXBlIiwidGFiVXJscyIsInNvbWUiLCJwYXRoIiwibWFwVXJscyIsIm1hcFVybCIsImlzVGFiIiwid3giLCJzd2l0Y2hUYWIiLCJwYWdlcyIsImdldEN1cnJlbnRQYWdlcyIsImluZGV4IiwiZmluZEluZGV4IiwiaXRlbSIsIl9fcm91dGVfXyIsImxlbmd0aCIsInJlZGlyZWN0VG8iLCJkZWx0YSIsIm5hdmlnYXRlQmFjayIsIm5hdmlnYXRlVG8iLCJwYXJhbSIsImNvbnNvbGUiLCJsb2ciLCJQcm9taXNlIiwicmVzb2x2ZSIsInJlamVjdCIsInJlcXVlc3RQYXltZW50IiwiY29tcGxldGUiLCJyZXMiLCJlcnJNc2ciLCJzdHIiLCJjYW5JVXNlIiwiZ2V0U3lzdGVtSW5mb1N5bmMiLCJTREtWZXJzaW9uIiwiaXNTREtFeGlwcmVkIiwiVGlwcyIsIm1vZGFsIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUFBOzs7O0FBQ0E7Ozs7Ozs7O0lBRXFCQSxPOzs7Ozs7OzBCQU9MQyxHLEVBQUs7QUFDakIsVUFBTUMsT0FBT0MsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCQyxRQUF2QztBQUNBLGFBQU9KLFFBQVEsQ0FBUixJQUFhLEtBQUtLLE9BQUwsQ0FBYUMsSUFBYixDQUFrQjtBQUFBLGVBQVFDLFFBQVFSLEdBQWhCO0FBQUEsT0FBbEIsQ0FBcEI7QUFDRDs7OzJCQUNjQSxHLEVBQUs7QUFDbEIsVUFBTUMsT0FBT0MsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCQyxRQUF2QztBQUNBLFVBQUlKLFFBQVEsQ0FBUixJQUFhLEtBQUtRLE9BQUwsQ0FBYVQsR0FBYixDQUFqQixFQUFvQztBQUNsQyxlQUFPLEtBQUtTLE9BQUwsQ0FBYVQsR0FBYixDQUFQO0FBQ0QsT0FGRCxNQUVPO0FBQ0wsZUFBT0EsR0FBUDtBQUNEO0FBQ0Y7O0FBRUQ7Ozs7OzttQ0FHc0JBLEcsRUFBSztBQUN6QkEsWUFBTSxLQUFLVSxNQUFMLENBQVlWLEdBQVosQ0FBTjtBQUNBLFVBQUksS0FBS1csS0FBTCxDQUFXWCxHQUFYLENBQUosRUFBcUI7QUFDbkJZLFdBQUdDLFNBQUgsQ0FBYTtBQUNYYixlQUFLQTtBQURNLFNBQWI7QUFHRCxPQUpELE1BSU87QUFDTCxZQUFNYyxRQUFRQyxpQkFBZDtBQUNBO0FBQ0EsWUFBTUMsUUFBUUYsTUFBTUcsU0FBTixDQUFnQjtBQUFBLGlCQUFTLE1BQU1DLEtBQUtDLFNBQVosSUFBMEJuQixHQUFsQztBQUFBLFNBQWhCLENBQWQ7QUFDQSxZQUFJYyxNQUFNTSxNQUFOLEdBQWUsQ0FBZixJQUFvQkosUUFBUSxDQUFoQyxFQUFtQztBQUNqQ0osYUFBR1MsVUFBSCxDQUFjO0FBQ1pyQixpQkFBS0E7QUFETyxXQUFkO0FBR0QsU0FKRCxNQUlPO0FBQ0wsY0FBTXNCLFFBQVFSLE1BQU1NLE1BQU4sR0FBZSxDQUFmLEdBQW1CSixLQUFqQztBQUNBSixhQUFHVyxZQUFILENBQWdCO0FBQ2RELG1CQUFPQTtBQURPLFdBQWhCO0FBR0Q7QUFDRjtBQUNGO0FBQ0Q7Ozs7OzttQ0FHc0J0QixHLEVBQUs7QUFDekJBLFlBQU0sS0FBS1UsTUFBTCxDQUFZVixHQUFaLENBQU47QUFDQSxVQUFJLEtBQUtXLEtBQUwsQ0FBV1gsR0FBWCxDQUFKLEVBQXFCO0FBQ25CWSxXQUFHQyxTQUFILENBQWE7QUFDWGIsZUFBS0E7QUFETSxTQUFiO0FBR0QsT0FKRCxNQUlPO0FBQ0wsWUFBTWMsUUFBUUMsaUJBQWQ7QUFDQTtBQUNBLFlBQU1DLFFBQVFGLE1BQU1HLFNBQU4sQ0FBZ0I7QUFBQSxpQkFBUyxNQUFNQyxLQUFLQyxTQUFaLElBQTBCbkIsR0FBbEM7QUFBQSxTQUFoQixDQUFkO0FBQ0EsWUFBSWMsTUFBTU0sTUFBTixHQUFlLENBQWYsSUFBb0JKLFFBQVEsQ0FBaEMsRUFBbUM7QUFDakNKLGFBQUdZLFVBQUgsQ0FBYztBQUNaeEIsaUJBQUtBO0FBRE8sV0FBZDtBQUdELFNBSkQsTUFJTztBQUNMLGNBQU1zQixRQUFRUixNQUFNTSxNQUFOLEdBQWUsQ0FBZixHQUFtQkosS0FBakM7QUFDQUosYUFBR1csWUFBSCxDQUFnQjtBQUNkRCxtQkFBT0E7QUFETyxXQUFoQjtBQUdEO0FBQ0Y7QUFDRjs7OzBCQUVZRyxLLEVBQU87QUFDbEJDLGNBQVFDLEdBQVIsQ0FBWUYsS0FBWjtBQUNBLGFBQU8sSUFBSUcsT0FBSixDQUFZLFVBQUNDLE9BQUQsRUFBVUMsTUFBVixFQUFxQjtBQUN0Q2xCLFdBQUdtQixjQUFILGNBQ0tOLEtBREw7QUFFRU8sb0JBQVUsdUJBQU87QUFDZixnQkFBSUMsSUFBSUMsTUFBSixJQUFjLG1CQUFsQixFQUF1QztBQUNyQ0wsc0JBQVFJLEdBQVI7QUFDRCxhQUZELE1BRU87QUFDTEgscUJBQU9HLEdBQVA7QUFDRDtBQUNGO0FBUkg7QUFVRCxPQVhNLENBQVA7QUFZRDs7QUFFRDs7Ozs7OzRCQUdlRSxHLEVBQUs7QUFDbEIsVUFBSXZCLEdBQUd3QixPQUFQLEVBQWdCO0FBQ2QsZUFBT3hCLEdBQUd3QixPQUFILENBQVdELEdBQVgsQ0FBUDtBQUNELE9BRkQsTUFFTztBQUNMLGVBQU8sS0FBUDtBQUNEO0FBQ0Y7QUFDRDs7Ozs7O21DQUdzQjtBQUFBLGtDQUNDdkIsR0FBR3lCLGlCQUFILEVBREQ7QUFBQSxVQUNiQyxVQURhLHlCQUNiQSxVQURhO0FBRXBCOzs7QUFDQSxhQUFPQSxjQUFjLElBQWQsSUFBc0JBLGFBQWEsT0FBMUM7QUFDRDtBQUNEOzs7Ozs7K0JBR2tCO0FBQ2hCLFVBQUksS0FBS0MsWUFBTCxFQUFKLEVBQXlCO0FBQ3ZCQyx1QkFBS0MsS0FBTCxDQUFXLHdCQUFYO0FBQ0Q7QUFDRjs7Ozs7O0FBaEhrQjFDLE8sQ0FDWk8sTyxHQUFVLENBQUMsc0JBQUQsRUFBeUIsdUJBQXpCLEVBQWtELG1CQUFsRCxFQUF1RSx1QkFBdkUsRUFBZ0csZ0NBQWhHLEM7QUFERVAsTyxDQUVaVSxPLEdBQVU7QUFDZix1QkFBcUIsc0JBRE47QUFFZixzQkFBb0I7QUFGTCxDO2tCQUZFVixPIiwiZmlsZSI6Ild4VXRpbHMuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgVGlwcyBmcm9tICcuL1RpcHMnO1xyXG5pbXBvcnQgd2VweSBmcm9tICd3ZXB5JztcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFd4VXRpbHMge1xyXG4gIHN0YXRpYyB0YWJVcmxzID0gWycvcGFnZXMvaG9tZS90ZW1wbGF0ZScsICcvcGFnZXMvZ29vZHMvY2F0ZWdvcnknLCAnL3BhZ2VzL2dvb2RzL2NhcnQnLCAnL3BhZ2VzL2N1c3RvbWVyL2luZGV4JywgJy9wYWdlcy9jdXN0b21lci9pbmRleF90ZW1wbGF0ZSddO1xyXG4gIHN0YXRpYyBtYXBVcmxzID0ge1xyXG4gICAgJy9wYWdlcy9zaG9wL2luZGV4JzogJy9wYWdlcy9ob21lL3RlbXBsYXRlJyxcclxuICAgICcvcGFnZXMvaG9tZS9ob21lJzogJy9wYWdlcy9ob21lL3RlbXBsYXRlJ1xyXG4gIH07XHJcblxyXG4gIHN0YXRpYyBpc1RhYiAodXJsKSB7XHJcbiAgICBjb25zdCB0eXBlID0gd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5zaG9wVHlwZTtcclxuICAgIHJldHVybiB0eXBlID09IDEgJiYgdGhpcy50YWJVcmxzLnNvbWUocGF0aCA9PiBwYXRoID09IHVybCk7XHJcbiAgfVxyXG4gIHN0YXRpYyBtYXBVcmwgKHVybCkge1xyXG4gICAgY29uc3QgdHlwZSA9IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuc2hvcFR5cGU7XHJcbiAgICBpZiAodHlwZSA9PSAxICYmIHRoaXMubWFwVXJsc1t1cmxdKSB7XHJcbiAgICAgIHJldHVybiB0aGlzLm1hcFVybHNbdXJsXTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJldHVybiB1cmw7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiDlpoLmnpzog73lpJ/lkI7pgIDvvIjlpJrlsYLvvInvvIzliJluYXZpZ2FldEJhY2vvvIzlkKbliJnosIPnlKhyZWRpcmVjdFRvXHJcbiAgICovXHJcbiAgc3RhdGljIGJhY2tPclJlZGlyZWN0KHVybCkge1xyXG4gICAgdXJsID0gdGhpcy5tYXBVcmwodXJsKTtcclxuICAgIGlmICh0aGlzLmlzVGFiKHVybCkpIHtcclxuICAgICAgd3guc3dpdGNoVGFiKHtcclxuICAgICAgICB1cmw6IHVybFxyXG4gICAgICB9KVxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgY29uc3QgcGFnZXMgPSBnZXRDdXJyZW50UGFnZXMoKTtcclxuICAgICAgLy8gcm91dGXlnKjkvY7niYjmnKzkuI3lhbzlrrlcclxuICAgICAgY29uc3QgaW5kZXggPSBwYWdlcy5maW5kSW5kZXgoaXRlbSA9PiAoJy8nICsgaXRlbS5fX3JvdXRlX18pID09IHVybCk7XHJcbiAgICAgIGlmIChwYWdlcy5sZW5ndGggPCAyIHx8IGluZGV4IDwgMCkge1xyXG4gICAgICAgIHd4LnJlZGlyZWN0VG8oe1xyXG4gICAgICAgICAgdXJsOiB1cmxcclxuICAgICAgICB9KTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBjb25zdCBkZWx0YSA9IHBhZ2VzLmxlbmd0aCAtIDEgLSBpbmRleDtcclxuICAgICAgICB3eC5uYXZpZ2F0ZUJhY2soe1xyXG4gICAgICAgICAgZGVsdGE6IGRlbHRhXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbiAgLyoqXHJcbiAgICog5aaC5p6c6IO95aSf5ZCO6YCA77yI5aSa5bGC77yJ77yM5YiZbmF2aWdhZXRCYWNr77yM5ZCm5YiZ6LCD55SobmF2aWdhdGVUb1xyXG4gICAqL1xyXG4gIHN0YXRpYyBiYWNrT3JOYXZpZ2F0ZSh1cmwpIHtcclxuICAgIHVybCA9IHRoaXMubWFwVXJsKHVybCk7XHJcbiAgICBpZiAodGhpcy5pc1RhYih1cmwpKSB7XHJcbiAgICAgIHd4LnN3aXRjaFRhYih7XHJcbiAgICAgICAgdXJsOiB1cmxcclxuICAgICAgfSlcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGNvbnN0IHBhZ2VzID0gZ2V0Q3VycmVudFBhZ2VzKCk7XHJcbiAgICAgIC8vIHJvdXRl5Zyo5L2O54mI5pys5LiN5YW85a65XHJcbiAgICAgIGNvbnN0IGluZGV4ID0gcGFnZXMuZmluZEluZGV4KGl0ZW0gPT4gKCcvJyArIGl0ZW0uX19yb3V0ZV9fKSA9PSB1cmwpO1xyXG4gICAgICBpZiAocGFnZXMubGVuZ3RoIDwgMiB8fCBpbmRleCA8IDApIHtcclxuICAgICAgICB3eC5uYXZpZ2F0ZVRvKHtcclxuICAgICAgICAgIHVybDogdXJsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgY29uc3QgZGVsdGEgPSBwYWdlcy5sZW5ndGggLSAxIC0gaW5kZXg7XHJcbiAgICAgICAgd3gubmF2aWdhdGVCYWNrKHtcclxuICAgICAgICAgIGRlbHRhOiBkZWx0YVxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBzdGF0aWMgd3hQYXkocGFyYW0pIHtcclxuICAgIGNvbnNvbGUubG9nKHBhcmFtKVxyXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgd3gucmVxdWVzdFBheW1lbnQoe1xyXG4gICAgICAgIC4uLnBhcmFtLFxyXG4gICAgICAgIGNvbXBsZXRlOiByZXMgPT4ge1xyXG4gICAgICAgICAgaWYgKHJlcy5lcnJNc2cgPT0gJ3JlcXVlc3RQYXltZW50Om9rJykge1xyXG4gICAgICAgICAgICByZXNvbHZlKHJlcyk7XHJcbiAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICByZWplY3QocmVzKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiDlhbzlrrnmgKfliKTmlq1cclxuICAgKi9cclxuICBzdGF0aWMgY2FuSVVzZShzdHIpIHtcclxuICAgIGlmICh3eC5jYW5JVXNlKSB7XHJcbiAgICAgIHJldHVybiB3eC5jYW5JVXNlKHN0cik7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICB9XHJcbiAgfVxyXG4gIC8qKlxyXG4gICAqIOajgOafpVNES+eJiOacrFxyXG4gICAqL1xyXG4gIHN0YXRpYyBpc1NES0V4aXByZWQoKSB7XHJcbiAgICBjb25zdCB7U0RLVmVyc2lvbn0gPSB3eC5nZXRTeXN0ZW1JbmZvU3luYygpO1xyXG4gICAgLy8gY29uc29sZS5pbmZvKGBbdmVyc2lvbl1zZGsgJHtTREtWZXJzaW9ufWApO1xyXG4gICAgcmV0dXJuIFNES1ZlcnNpb24gPT0gbnVsbCB8fCBTREtWZXJzaW9uIDwgJzEuMi4wJ1xyXG4gIH1cclxuICAvKipcclxuICAgKiDmo4Dmn6VTREvniYjmnKxcclxuICAgKi9cclxuICBzdGF0aWMgY2hlY2tTREsoKSB7XHJcbiAgICBpZiAodGhpcy5pc1NES0V4aXByZWQoKSkge1xyXG4gICAgICBUaXBzLm1vZGFsKCfmgqjnmoTlvq7kv6HniYjmnKzlpKrkvY7vvIzkuLrnoa7kv53mraPluLjkvb/nlKjvvIzor7flsL3lv6vljYfnuqcnKTtcclxuICAgIH1cclxuICB9XHJcbn1cclxuIl19