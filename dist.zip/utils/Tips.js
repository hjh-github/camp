'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/**
 * 提示与加载工具类
 */
var Tips = function () {
  function Tips() {
    _classCallCheck(this, Tips);
  }

  _createClass(Tips, null, [{
    key: 'success',


    /**
     * 弹出提示框
     */

    value: function success(title) {
      var duration = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 500;

      wx.showToast({
        title: title,
        icon: 'success',
        mask: true,
        duration: duration
      });
      if (duration > 0) {
        return new Promise(function (resolve, reject) {
          setTimeout(function () {
            resolve();
          }, duration);
        });
      }
    }

    /**
     * 弹出确认窗口
     */

  }, {
    key: 'modal',
    value: function modal(text) {
      var title = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '提示';

      return new Promise(function (resolve, reject) {
        wx.showModal({
          title: title,
          content: text,
          showCancel: false,
          success: function success(res) {
            resolve(res);
          },
          fail: function fail(res) {
            reject(res);
          }
        });
      });
    }

    /**
     * 弹出确认窗口
     */

  }, {
    key: 'confirm',
    value: function confirm(text) {
      var payload = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
      var title = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : '提示';

      return new Promise(function (resolve, reject) {
        wx.showModal({
          title: title,
          content: text,
          showCancel: true,
          success: function success(res) {
            if (res.confirm) {
              resolve(payload);
            } else if (res.cancel) {
              reject(payload);
            }
          },
          fail: function fail(res) {
            reject(payload);
          }
        });
      });
    }
  }, {
    key: 'toast',
    value: function toast(title, onHide) {
      var icon = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 'success';

      wx.showToast({
        title: title,
        icon: icon,
        mask: true,
        duration: 1500
      });
      // 隐藏结束回调
      if (onHide) {
        setTimeout(function () {
          onHide();
        }, 2000);
      }
    }

    /**
     * 警告框
     */

  }, {
    key: 'alert',
    value: function alert(title) {
      wx.showToast({
        title: title,
        image: '/images/icons/alert.png',
        mask: true,
        duration: 500
      });
      return new Promise(function (resolve, reject) {
        setTimeout(function () {
          resolve();
        }, 500);
      });
    }

    /**
     * 错误框
     */

  }, {
    key: 'error',
    value: function error(title, onHide) {
      wx.showToast({
        title: title,
        image: '/images/icons/error.png',
        mask: true,
        duration: 500
      });
      // 隐藏结束回调
      if (onHide) {
        setTimeout(function () {
          onHide();
        }, 500);
      }
    }

    /**
     * 弹出加载提示
     */

  }, {
    key: 'loading',
    value: function loading() {
      var title = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '加载中';

      if (this.isLoading) {
        return;
      }
      this.isLoading = true;
      if (wx.showLoading) {
        wx.showLoading({
          title: title,
          mask: true
        });
      } else {
        wx.showNavigationBarLoading();
      }
    }

    /**
     * 加载完毕
     */

  }, {
    key: 'loaded',
    value: function loaded() {

      this.isLoading = false;
      if (wx.hideLoading) {
        wx.hideLoading();
      } else {
        wx.hideNavigationBarLoading();
      }
    }

    /**
     * 弹出下拉动作栏
     */

  }, {
    key: 'action',
    value: function action() {
      for (var _len = arguments.length, items = Array(_len), _key = 0; _key < _len; _key++) {
        items[_key] = arguments[_key];
      }

      return new Promise(function (resolve, reject) {
        wx.showActionSheet({
          itemList: items,
          success: function success(res) {
            var result = {
              index: res.tapIndex,
              text: items[res.tapIndex]
            };
            resolve(result);
          },
          fail: function fail(res) {
            reject(res.errMsg);
          }
        });
      });
    }
  }, {
    key: 'actionWithFunc',
    value: function actionWithFunc(items) {
      for (var _len2 = arguments.length, functions = Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {
        functions[_key2 - 1] = arguments[_key2];
      }

      wx.showActionSheet({
        itemList: items,
        success: function success(res) {
          var index = res.tapIndex;
          if (index >= 0 && index < functions.length) {
            functions[index]();
          }
        }
      });
    }
  }, {
    key: 'share',
    value: function share(title, url, desc) {
      return {
        title: title,
        path: url,
        desc: desc,
        success: function success(res) {
          Tips.toast('分享成功');
        }
      };
    }
  }, {
    key: 'setLoading',
    value: function setLoading() {
      this.isLoading = true;
    }
  }]);

  return Tips;
}();

Tips.isLoading = false;
Tips.pause = false;
exports.default = Tips;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIlRpcHMuanMiXSwibmFtZXMiOlsiVGlwcyIsInRpdGxlIiwiZHVyYXRpb24iLCJ3eCIsInNob3dUb2FzdCIsImljb24iLCJtYXNrIiwiUHJvbWlzZSIsInJlc29sdmUiLCJyZWplY3QiLCJzZXRUaW1lb3V0IiwidGV4dCIsInNob3dNb2RhbCIsImNvbnRlbnQiLCJzaG93Q2FuY2VsIiwic3VjY2VzcyIsInJlcyIsImZhaWwiLCJwYXlsb2FkIiwiY29uZmlybSIsImNhbmNlbCIsIm9uSGlkZSIsImltYWdlIiwiaXNMb2FkaW5nIiwic2hvd0xvYWRpbmciLCJzaG93TmF2aWdhdGlvbkJhckxvYWRpbmciLCJoaWRlTG9hZGluZyIsImhpZGVOYXZpZ2F0aW9uQmFyTG9hZGluZyIsIml0ZW1zIiwic2hvd0FjdGlvblNoZWV0IiwiaXRlbUxpc3QiLCJyZXN1bHQiLCJpbmRleCIsInRhcEluZGV4IiwiZXJyTXNnIiwiZnVuY3Rpb25zIiwibGVuZ3RoIiwidXJsIiwiZGVzYyIsInBhdGgiLCJ0b2FzdCIsInBhdXNlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQUE7OztJQUdxQkEsSTs7Ozs7Ozs7O0FBSW5COzs7OzRCQUllQyxLLEVBQXVCO0FBQUEsVUFBaEJDLFFBQWdCLHVFQUFMLEdBQUs7O0FBQ3BDQyxTQUFHQyxTQUFILENBQWE7QUFDWEgsZUFBT0EsS0FESTtBQUVYSSxjQUFNLFNBRks7QUFHWEMsY0FBTSxJQUhLO0FBSVhKLGtCQUFVQTtBQUpDLE9BQWI7QUFNQSxVQUFJQSxXQUFXLENBQWYsRUFBa0I7QUFDaEIsZUFBTyxJQUFJSyxPQUFKLENBQVksVUFBQ0MsT0FBRCxFQUFVQyxNQUFWLEVBQXFCO0FBQ3RDQyxxQkFBVyxZQUFNO0FBQ2ZGO0FBQ0QsV0FGRCxFQUVHTixRQUZIO0FBR0QsU0FKTSxDQUFQO0FBS0Q7QUFDRjs7QUFFRDs7Ozs7OzBCQUdhUyxJLEVBQW9CO0FBQUEsVUFBZFYsS0FBYyx1RUFBTixJQUFNOztBQUMvQixhQUFPLElBQUlNLE9BQUosQ0FBWSxVQUFDQyxPQUFELEVBQVVDLE1BQVYsRUFBcUI7QUFDdENOLFdBQUdTLFNBQUgsQ0FBYTtBQUNYWCxpQkFBT0EsS0FESTtBQUVYWSxtQkFBU0YsSUFGRTtBQUdYRyxzQkFBWSxLQUhEO0FBSVhDLG1CQUFTLHNCQUFPO0FBQ2RQLG9CQUFRUSxHQUFSO0FBQ0QsV0FOVTtBQU9YQyxnQkFBTSxtQkFBTztBQUNYUixtQkFBT08sR0FBUDtBQUNEO0FBVFUsU0FBYjtBQVdELE9BWk0sQ0FBUDtBQWFEOztBQUVEOzs7Ozs7NEJBR2VMLEksRUFBa0M7QUFBQSxVQUE1Qk8sT0FBNEIsdUVBQWxCLEVBQWtCO0FBQUEsVUFBZGpCLEtBQWMsdUVBQU4sSUFBTTs7QUFDL0MsYUFBTyxJQUFJTSxPQUFKLENBQVksVUFBQ0MsT0FBRCxFQUFVQyxNQUFWLEVBQXFCO0FBQ3RDTixXQUFHUyxTQUFILENBQWE7QUFDWFgsaUJBQU9BLEtBREk7QUFFWFksbUJBQVNGLElBRkU7QUFHWEcsc0JBQVksSUFIRDtBQUlYQyxtQkFBUyxzQkFBTztBQUNkLGdCQUFJQyxJQUFJRyxPQUFSLEVBQWlCO0FBQ2ZYLHNCQUFRVSxPQUFSO0FBQ0QsYUFGRCxNQUVPLElBQUlGLElBQUlJLE1BQVIsRUFBZ0I7QUFDckJYLHFCQUFPUyxPQUFQO0FBQ0Q7QUFDRixXQVZVO0FBV1hELGdCQUFNLG1CQUFPO0FBQ1hSLG1CQUFPUyxPQUFQO0FBQ0Q7QUFiVSxTQUFiO0FBZUQsT0FoQk0sQ0FBUDtBQWlCRDs7OzBCQUVZakIsSyxFQUFPb0IsTSxFQUEwQjtBQUFBLFVBQWxCaEIsSUFBa0IsdUVBQVgsU0FBVzs7QUFDNUNGLFNBQUdDLFNBQUgsQ0FBYTtBQUNYSCxlQUFPQSxLQURJO0FBRVhJLGNBQU1BLElBRks7QUFHWEMsY0FBTSxJQUhLO0FBSVhKLGtCQUFVO0FBSkMsT0FBYjtBQU1BO0FBQ0EsVUFBSW1CLE1BQUosRUFBWTtBQUNWWCxtQkFBVyxZQUFNO0FBQ2ZXO0FBQ0QsU0FGRCxFQUVHLElBRkg7QUFHRDtBQUNGOztBQUVEOzs7Ozs7MEJBR2FwQixLLEVBQU87QUFDbEJFLFNBQUdDLFNBQUgsQ0FBYTtBQUNYSCxlQUFPQSxLQURJO0FBRVhxQixlQUFPLHlCQUZJO0FBR1hoQixjQUFNLElBSEs7QUFJWEosa0JBQVU7QUFKQyxPQUFiO0FBTUEsYUFBTyxJQUFJSyxPQUFKLENBQVksVUFBQ0MsT0FBRCxFQUFVQyxNQUFWLEVBQXFCO0FBQ3RDQyxtQkFBVyxZQUFNO0FBQ2ZGO0FBQ0QsU0FGRCxFQUVHLEdBRkg7QUFHRCxPQUpNLENBQVA7QUFLRDs7QUFFRDs7Ozs7OzBCQUlhUCxLLEVBQU9vQixNLEVBQVE7QUFDMUJsQixTQUFHQyxTQUFILENBQWE7QUFDWEgsZUFBT0EsS0FESTtBQUVYcUIsZUFBTyx5QkFGSTtBQUdYaEIsY0FBTSxJQUhLO0FBSVhKLGtCQUFVO0FBSkMsT0FBYjtBQU1BO0FBQ0EsVUFBSW1CLE1BQUosRUFBWTtBQUNWWCxtQkFBVyxZQUFNO0FBQ2ZXO0FBQ0QsU0FGRCxFQUVHLEdBRkg7QUFHRDtBQUNGOztBQUVEOzs7Ozs7OEJBRzhCO0FBQUEsVUFBZnBCLEtBQWUsdUVBQVAsS0FBTzs7QUFDNUIsVUFBSSxLQUFLc0IsU0FBVCxFQUFvQjtBQUNsQjtBQUNEO0FBQ0QsV0FBS0EsU0FBTCxHQUFpQixJQUFqQjtBQUNBLFVBQUlwQixHQUFHcUIsV0FBUCxFQUFvQjtBQUNsQnJCLFdBQUdxQixXQUFILENBQWU7QUFDYnZCLGlCQUFPQSxLQURNO0FBRWJLLGdCQUFNO0FBRk8sU0FBZjtBQUlELE9BTEQsTUFLTztBQUNMSCxXQUFHc0Isd0JBQUg7QUFDRDtBQUNGOztBQUVEOzs7Ozs7NkJBR2dCOztBQUVkLFdBQUtGLFNBQUwsR0FBaUIsS0FBakI7QUFDQSxVQUFJcEIsR0FBR3VCLFdBQVAsRUFBb0I7QUFDbEJ2QixXQUFHdUIsV0FBSDtBQUNELE9BRkQsTUFFTztBQUNMdkIsV0FBR3dCLHdCQUFIO0FBQ0Q7QUFFRjs7QUFFRDs7Ozs7OzZCQUd3QjtBQUFBLHdDQUFQQyxLQUFPO0FBQVBBLGFBQU87QUFBQTs7QUFDdEIsYUFBTyxJQUFJckIsT0FBSixDQUFZLFVBQUNDLE9BQUQsRUFBVUMsTUFBVixFQUFxQjtBQUN0Q04sV0FBRzBCLGVBQUgsQ0FBbUI7QUFDakJDLG9CQUFVRixLQURPO0FBRWpCYixtQkFBUyxpQkFBVUMsR0FBVixFQUFlO0FBQ3RCLGdCQUFNZSxTQUFTO0FBQ2JDLHFCQUFPaEIsSUFBSWlCLFFBREU7QUFFYnRCLG9CQUFNaUIsTUFBTVosSUFBSWlCLFFBQVY7QUFGTyxhQUFmO0FBSUF6QixvQkFBUXVCLE1BQVI7QUFDRCxXQVJnQjtBQVNqQmQsZ0JBQU0sY0FBVUQsR0FBVixFQUFlO0FBQ25CUCxtQkFBT08sSUFBSWtCLE1BQVg7QUFDRDtBQVhnQixTQUFuQjtBQWFELE9BZE0sQ0FBUDtBQWVEOzs7bUNBRXFCTixLLEVBQXFCO0FBQUEseUNBQVhPLFNBQVc7QUFBWEEsaUJBQVc7QUFBQTs7QUFDekNoQyxTQUFHMEIsZUFBSCxDQUFtQjtBQUNqQkMsa0JBQVVGLEtBRE87QUFFakJiLGlCQUFTLGlCQUFVQyxHQUFWLEVBQWU7QUFDdEIsY0FBTWdCLFFBQVFoQixJQUFJaUIsUUFBbEI7QUFDQSxjQUFJRCxTQUFTLENBQVQsSUFBY0EsUUFBUUcsVUFBVUMsTUFBcEMsRUFBNEM7QUFDMUNELHNCQUFVSCxLQUFWO0FBQ0Q7QUFDRjtBQVBnQixPQUFuQjtBQVNEOzs7MEJBRVkvQixLLEVBQU9vQyxHLEVBQUtDLEksRUFBTTtBQUM3QixhQUFPO0FBQ0xyQyxlQUFPQSxLQURGO0FBRUxzQyxjQUFNRixHQUZEO0FBR0xDLGNBQU1BLElBSEQ7QUFJTHZCLGlCQUFTLGlCQUFVQyxHQUFWLEVBQWU7QUFDdEJoQixlQUFLd0MsS0FBTCxDQUFXLE1BQVg7QUFDRDtBQU5JLE9BQVA7QUFRRDs7O2lDQUVtQjtBQUNsQixXQUFLakIsU0FBTCxHQUFpQixJQUFqQjtBQUNEOzs7Ozs7QUFuTWtCdkIsSSxDQUNadUIsUyxHQUFZLEs7QUFEQXZCLEksQ0FFWnlDLEssR0FBUSxLO2tCQUZJekMsSSIsImZpbGUiOiJUaXBzLmpzIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXHJcbiAqIOaPkOekuuS4juWKoOi9veW3peWFt+exu1xyXG4gKi9cclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgVGlwcyB7XHJcbiAgc3RhdGljIGlzTG9hZGluZyA9IGZhbHNlO1xyXG4gIHN0YXRpYyBwYXVzZSA9IGZhbHNlO1xyXG5cclxuICAvKipcclxuICAgKiDlvLnlh7rmj5DnpLrmoYZcclxuICAgKi9cclxuXHJcbiAgc3RhdGljIHN1Y2Nlc3ModGl0bGUsIGR1cmF0aW9uID0gNTAwKSB7XHJcbiAgICB3eC5zaG93VG9hc3Qoe1xyXG4gICAgICB0aXRsZTogdGl0bGUsXHJcbiAgICAgIGljb246ICdzdWNjZXNzJyxcclxuICAgICAgbWFzazogdHJ1ZSxcclxuICAgICAgZHVyYXRpb246IGR1cmF0aW9uXHJcbiAgICB9KTtcclxuICAgIGlmIChkdXJhdGlvbiA+IDApIHtcclxuICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICAgIHJlc29sdmUoKTtcclxuICAgICAgICB9LCBkdXJhdGlvbik7XHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICog5by55Ye656Gu6K6k56qX5Y+jXHJcbiAgICovXHJcbiAgc3RhdGljIG1vZGFsKHRleHQsIHRpdGxlID0gJ+aPkOekuicpIHtcclxuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICAgIHd4LnNob3dNb2RhbCh7XHJcbiAgICAgICAgdGl0bGU6IHRpdGxlLFxyXG4gICAgICAgIGNvbnRlbnQ6IHRleHQsXHJcbiAgICAgICAgc2hvd0NhbmNlbDogZmFsc2UsXHJcbiAgICAgICAgc3VjY2VzczogcmVzID0+IHtcclxuICAgICAgICAgIHJlc29sdmUocmVzKTtcclxuICAgICAgICB9LFxyXG4gICAgICAgIGZhaWw6IHJlcyA9PiB7XHJcbiAgICAgICAgICByZWplY3QocmVzKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiDlvLnlh7rnoa7orqTnqpflj6NcclxuICAgKi9cclxuICBzdGF0aWMgY29uZmlybSh0ZXh0LCBwYXlsb2FkID0ge30sIHRpdGxlID0gJ+aPkOekuicpIHtcclxuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICAgIHd4LnNob3dNb2RhbCh7XHJcbiAgICAgICAgdGl0bGU6IHRpdGxlLFxyXG4gICAgICAgIGNvbnRlbnQ6IHRleHQsXHJcbiAgICAgICAgc2hvd0NhbmNlbDogdHJ1ZSxcclxuICAgICAgICBzdWNjZXNzOiByZXMgPT4ge1xyXG4gICAgICAgICAgaWYgKHJlcy5jb25maXJtKSB7XHJcbiAgICAgICAgICAgIHJlc29sdmUocGF5bG9hZCk7XHJcbiAgICAgICAgICB9IGVsc2UgaWYgKHJlcy5jYW5jZWwpIHtcclxuICAgICAgICAgICAgcmVqZWN0KHBheWxvYWQpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgZmFpbDogcmVzID0+IHtcclxuICAgICAgICAgIHJlamVjdChwYXlsb2FkKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICBzdGF0aWMgdG9hc3QodGl0bGUsIG9uSGlkZSwgaWNvbiA9ICdzdWNjZXNzJykge1xyXG4gICAgd3guc2hvd1RvYXN0KHtcclxuICAgICAgdGl0bGU6IHRpdGxlLFxyXG4gICAgICBpY29uOiBpY29uLFxyXG4gICAgICBtYXNrOiB0cnVlLFxyXG4gICAgICBkdXJhdGlvbjogMTUwMFxyXG4gICAgfSk7XHJcbiAgICAvLyDpmpDol4/nu5PmnZ/lm57osINcclxuICAgIGlmIChvbkhpZGUpIHtcclxuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgb25IaWRlKCk7XHJcbiAgICAgIH0sIDIwMDApO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICog6K2m5ZGK5qGGXHJcbiAgICovXHJcbiAgc3RhdGljIGFsZXJ0KHRpdGxlKSB7XHJcbiAgICB3eC5zaG93VG9hc3Qoe1xyXG4gICAgICB0aXRsZTogdGl0bGUsXHJcbiAgICAgIGltYWdlOiAnL2ltYWdlcy9pY29ucy9hbGVydC5wbmcnLFxyXG4gICAgICBtYXNrOiB0cnVlLFxyXG4gICAgICBkdXJhdGlvbjogNTAwXHJcbiAgICB9KTtcclxuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgIHJlc29sdmUoKTtcclxuICAgICAgfSwgNTAwKTtcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICog6ZSZ6K+v5qGGXHJcbiAgICovXHJcblxyXG4gIHN0YXRpYyBlcnJvcih0aXRsZSwgb25IaWRlKSB7XHJcbiAgICB3eC5zaG93VG9hc3Qoe1xyXG4gICAgICB0aXRsZTogdGl0bGUsXHJcbiAgICAgIGltYWdlOiAnL2ltYWdlcy9pY29ucy9lcnJvci5wbmcnLFxyXG4gICAgICBtYXNrOiB0cnVlLFxyXG4gICAgICBkdXJhdGlvbjogNTAwXHJcbiAgICB9KTtcclxuICAgIC8vIOmakOiXj+e7k+adn+Wbnuiwg1xyXG4gICAgaWYgKG9uSGlkZSkge1xyXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICBvbkhpZGUoKTtcclxuICAgICAgfSwgNTAwKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIOW8ueWHuuWKoOi9veaPkOekulxyXG4gICAqL1xyXG4gIHN0YXRpYyBsb2FkaW5nKHRpdGxlID0gJ+WKoOi9veS4rScpIHtcclxuICAgIGlmICh0aGlzLmlzTG9hZGluZykge1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcbiAgICB0aGlzLmlzTG9hZGluZyA9IHRydWU7XHJcbiAgICBpZiAod3guc2hvd0xvYWRpbmcpIHtcclxuICAgICAgd3guc2hvd0xvYWRpbmcoe1xyXG4gICAgICAgIHRpdGxlOiB0aXRsZSxcclxuICAgICAgICBtYXNrOiB0cnVlXHJcbiAgICAgIH0pO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgd3guc2hvd05hdmlnYXRpb25CYXJMb2FkaW5nKCk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiDliqDovb3lrozmr5VcclxuICAgKi9cclxuICBzdGF0aWMgbG9hZGVkKCkge1xyXG5cclxuICAgIHRoaXMuaXNMb2FkaW5nID0gZmFsc2U7XHJcbiAgICBpZiAod3guaGlkZUxvYWRpbmcpIHtcclxuICAgICAgd3guaGlkZUxvYWRpbmcoKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHd4LmhpZGVOYXZpZ2F0aW9uQmFyTG9hZGluZygpO1xyXG4gICAgfVxyXG5cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIOW8ueWHuuS4i+aLieWKqOS9nOagj1xyXG4gICAqL1xyXG4gIHN0YXRpYyBhY3Rpb24oLi4uaXRlbXMpIHtcclxuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICAgIHd4LnNob3dBY3Rpb25TaGVldCh7XHJcbiAgICAgICAgaXRlbUxpc3Q6IGl0ZW1zLFxyXG4gICAgICAgIHN1Y2Nlc3M6IGZ1bmN0aW9uIChyZXMpIHtcclxuICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IHtcclxuICAgICAgICAgICAgaW5kZXg6IHJlcy50YXBJbmRleCxcclxuICAgICAgICAgICAgdGV4dDogaXRlbXNbcmVzLnRhcEluZGV4XVxyXG4gICAgICAgICAgfTtcclxuICAgICAgICAgIHJlc29sdmUocmVzdWx0KTtcclxuICAgICAgICB9LFxyXG4gICAgICAgIGZhaWw6IGZ1bmN0aW9uIChyZXMpIHtcclxuICAgICAgICAgIHJlamVjdChyZXMuZXJyTXNnKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICBzdGF0aWMgYWN0aW9uV2l0aEZ1bmMoaXRlbXMsIC4uLmZ1bmN0aW9ucykge1xyXG4gICAgd3guc2hvd0FjdGlvblNoZWV0KHtcclxuICAgICAgaXRlbUxpc3Q6IGl0ZW1zLFxyXG4gICAgICBzdWNjZXNzOiBmdW5jdGlvbiAocmVzKSB7XHJcbiAgICAgICAgY29uc3QgaW5kZXggPSByZXMudGFwSW5kZXg7XHJcbiAgICAgICAgaWYgKGluZGV4ID49IDAgJiYgaW5kZXggPCBmdW5jdGlvbnMubGVuZ3RoKSB7XHJcbiAgICAgICAgICBmdW5jdGlvbnNbaW5kZXhdKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIHN0YXRpYyBzaGFyZSh0aXRsZSwgdXJsLCBkZXNjKSB7XHJcbiAgICByZXR1cm4ge1xyXG4gICAgICB0aXRsZTogdGl0bGUsXHJcbiAgICAgIHBhdGg6IHVybCxcclxuICAgICAgZGVzYzogZGVzYyxcclxuICAgICAgc3VjY2VzczogZnVuY3Rpb24gKHJlcykge1xyXG4gICAgICAgIFRpcHMudG9hc3QoJ+WIhuS6q+aIkOWKnycpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gIH1cclxuXHJcbiAgc3RhdGljIHNldExvYWRpbmcoKSB7XHJcbiAgICB0aGlzLmlzTG9hZGluZyA9IHRydWU7XHJcbiAgfVxyXG59XHJcbiJdfQ==