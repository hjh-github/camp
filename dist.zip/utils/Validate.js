'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Validate = function () {
  function Validate() {
    _classCallCheck(this, Validate);
  }

  _createClass(Validate, null, [{
    key: 'required',

    /**
     * 验证必填元素
     */
    value: function required(value) {
      if (typeof value === 'number') {
        value = value.toString();
      } else if (typeof value === 'boolean') {
        return !0;
      }

      return value && value.length > 0;
    }

    /**
     * 重复验证
     */

  }, {
    key: 'noDuplicate',
    value: function noDuplicate(values) {
      for (var i = 0; i < values.length; i++) {
        for (var j = 0; j < values.length; j++) {
          if (values[i] == values[j] && i != j) {
            return false;
          }
        }
      }
      return true;
    }
    /**
     * 验证电子邮箱格式
     */

  }, {
    key: 'email',
    value: function email(value) {
      return this.optional(value) || /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/.test(value);
    }
    /**
     * 验证手机格式
     */

  }, {
    key: 'tel',
    value: function tel(value) {
      return (/^1[3456789]\d{9}$/.test(value)
      );
    }
    /**
     * 验证URL格式
     */

  }, {
    key: 'url',
    value: function url(value) {
      return this.optional(value) || /^(?:(?:(?:https?|ftp):)?\/\/)(?:\S+(?::\S*)?@)?(?:(?!(?:10|127)(?:\.\d{1,3}){3})(?!(?:169\.254|192\.168)(?:\.\d{1,3}){2})(?!172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){2}(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))|(?:(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)(?:\.(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)*(?:\.(?:[a-z\u00a1-\uffff]{2,})).?)(?::\d{2,5})?(?:[/?#]\S*)?$/i.test(value);
    }
    /**
     * 验证日期格式
     */

  }, {
    key: 'date',
    value: function date(value) {
      return this.optional(value) || !/Invalid|NaN/.test(new Date(value).toString());
    }
    /**
     * 验证ISO类型的日期格式
     */

  }, {
    key: 'dateISO',
    value: function dateISO(value) {
      return this.optional(value) || /^\d{4}[\/\-](0?[1-9]|1[012])[\/\-](0?[1-9]|[12][0-9]|3[01])$/.test(value);
    }
    /**
     * 验证十进制数字
     */

  }, {
    key: 'number',
    value: function number(value) {
      return this.optional(value) || /^(?:-?\d+|-?\d{1,3}(?:,\d{3})+)?(?:\.\d+)?$/.test(value);
    }
    /**
     * 验证整数
     */

  }, {
    key: 'digits',
    value: function digits(value) {
      return this.optional(value) || /^\d+$/.test(value);
    }
    /**
     * 验证身份证号码
     */

  }, {
    key: 'idcard',
    value: function idcard(value) {
      return this.optional(value) || /^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}([0-9]|X)$/.test(value);
    }
    /**
     * 验证两个输入框的内容是否相同
     */

  }, {
    key: 'equalTo',
    value: function equalTo(value, param) {
      return this.optional(value) || value === that.scope.detail.value[param];
    }
    /**
     * 验证是否包含某个值
     */

  }, {
    key: 'contains',
    value: function contains(value, param) {
      return this.optional(value) || value.indexOf(param) >= 0;
    }
    /**
     * 验证最小长度
     */

  }, {
    key: 'minlength',
    value: function minlength(value, param) {
      return this.optional(value) || value.length >= param;
    }
    /**
     * 验证最大长度
     */

  }, {
    key: 'maxlength',
    value: function maxlength(value, param) {
      return this.optional(value) || value.length <= param;
    }
    /**
     * 验证一个长度范围[min, max]
     */

  }, {
    key: 'rangelength',
    value: function rangelength(value, param) {
      return this.optional(value) || value.length >= param[0] && value.length <= param[1];
    }
    /**
     * 验证最小值
     */

  }, {
    key: 'min',
    value: function min(value, param) {
      return this.optional(value) || Number(value) >= Number(param);
    }
    /**
     * 验证最大值
     */

  }, {
    key: 'max',
    value: function max(value, param) {
      return this.optional(value) || Number(value) <= Number(param);
    }

    /**
     * 验证时间
     */

  }, {
    key: 'after',
    value: function after(value, param) {
      return this.optional(value) || value >= param;
    }
    /**
     * 验证时间
     */

  }, {
    key: 'before',
    value: function before(value, param) {
      return this.optional(value) || value <= param;
    }

    /**
     * 验证一个值范围[min, max]
     */

  }, {
    key: 'range',
    value: function range(value, param) {
      return this.optional(value) || value >= param[0] && value <= param[1];
    }
    /**
     * 判断输入值是否为空
     */

  }, {
    key: 'optional',
    value: function optional(value) {
      return !this.required(value) && 'dependency-mismatch';
    }

    /***
     * 验证金额
     */

  }, {
    key: 'money',
    value: function money(value) {
      return this.optional(value) || /(^[1-9]([0-9]+)?(\.[0-9]{1,2})?$)|(^(0){1}$)|(^[0-9]\.[0-9]([0-9])?$)/.test(value);
    }
  }]);

  return Validate;
}();

exports.default = Validate;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIlZhbGlkYXRlLmpzIl0sIm5hbWVzIjpbIlZhbGlkYXRlIiwidmFsdWUiLCJ0b1N0cmluZyIsImxlbmd0aCIsInZhbHVlcyIsImkiLCJqIiwib3B0aW9uYWwiLCJ0ZXN0IiwiRGF0ZSIsInBhcmFtIiwidGhhdCIsInNjb3BlIiwiZGV0YWlsIiwiaW5kZXhPZiIsIk51bWJlciIsInJlcXVpcmVkIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0lBQXFCQSxROzs7Ozs7OztBQUNuQjs7OzZCQUdnQkMsSyxFQUFPO0FBQ3JCLFVBQUksT0FBT0EsS0FBUCxLQUFpQixRQUFyQixFQUErQjtBQUM3QkEsZ0JBQVFBLE1BQU1DLFFBQU4sRUFBUjtBQUNELE9BRkQsTUFFTyxJQUFJLE9BQU9ELEtBQVAsS0FBaUIsU0FBckIsRUFBZ0M7QUFDckMsZUFBTyxDQUFDLENBQVI7QUFDRDs7QUFFRCxhQUFPQSxTQUFTQSxNQUFNRSxNQUFOLEdBQWUsQ0FBL0I7QUFDRDs7QUFFRDs7Ozs7O2dDQUdtQkMsTSxFQUFRO0FBQ3pCLFdBQUssSUFBSUMsSUFBSSxDQUFiLEVBQWdCQSxJQUFJRCxPQUFPRCxNQUEzQixFQUFtQ0UsR0FBbkMsRUFBd0M7QUFDdEMsYUFBSyxJQUFJQyxJQUFJLENBQWIsRUFBZ0JBLElBQUlGLE9BQU9ELE1BQTNCLEVBQW1DRyxHQUFuQyxFQUF3QztBQUN0QyxjQUFJRixPQUFPQyxDQUFQLEtBQWFELE9BQU9FLENBQVAsQ0FBYixJQUEwQkQsS0FBS0MsQ0FBbkMsRUFBc0M7QUFDcEMsbUJBQU8sS0FBUDtBQUNEO0FBQ0Y7QUFDRjtBQUNELGFBQU8sSUFBUDtBQUNEO0FBQ0Q7Ozs7OzswQkFHYUwsSyxFQUFPO0FBQ2xCLGFBQU8sS0FBS00sUUFBTCxDQUFjTixLQUFkLEtBQXdCLHdJQUF3SU8sSUFBeEksQ0FBNklQLEtBQTdJLENBQS9CO0FBQ0Q7QUFDRDs7Ozs7O3dCQUdXQSxLLEVBQU87QUFDaEIsYUFBUSxxQkFBb0JPLElBQXBCLENBQXlCUCxLQUF6QjtBQUFSO0FBQ0Q7QUFDRDs7Ozs7O3dCQUdXQSxLLEVBQU87QUFDaEIsYUFBTyxLQUFLTSxRQUFMLENBQWNOLEtBQWQsS0FBd0IsMmNBQTJjTyxJQUEzYyxDQUFnZFAsS0FBaGQsQ0FBL0I7QUFDRDtBQUNEOzs7Ozs7eUJBR1lBLEssRUFBTztBQUNqQixhQUFPLEtBQUtNLFFBQUwsQ0FBY04sS0FBZCxLQUF3QixDQUFDLGNBQWNPLElBQWQsQ0FBbUIsSUFBSUMsSUFBSixDQUFTUixLQUFULEVBQWdCQyxRQUFoQixFQUFuQixDQUFoQztBQUNEO0FBQ0Q7Ozs7Ozs0QkFHZUQsSyxFQUFPO0FBQ3BCLGFBQU8sS0FBS00sUUFBTCxDQUFjTixLQUFkLEtBQXdCLCtEQUErRE8sSUFBL0QsQ0FBb0VQLEtBQXBFLENBQS9CO0FBQ0Q7QUFDRDs7Ozs7OzJCQUdjQSxLLEVBQU87QUFDbkIsYUFBTyxLQUFLTSxRQUFMLENBQWNOLEtBQWQsS0FBd0IsOENBQThDTyxJQUE5QyxDQUFtRFAsS0FBbkQsQ0FBL0I7QUFDRDtBQUNEOzs7Ozs7MkJBR2NBLEssRUFBTztBQUNuQixhQUFPLEtBQUtNLFFBQUwsQ0FBY04sS0FBZCxLQUF3QixRQUFRTyxJQUFSLENBQWFQLEtBQWIsQ0FBL0I7QUFDRDtBQUNEOzs7Ozs7MkJBR2NBLEssRUFBTztBQUNuQixhQUFPLEtBQUtNLFFBQUwsQ0FBY04sS0FBZCxLQUF3QiwyRUFBMkVPLElBQTNFLENBQWdGUCxLQUFoRixDQUEvQjtBQUNEO0FBQ0Q7Ozs7Ozs0QkFHZUEsSyxFQUFPUyxLLEVBQU87QUFDM0IsYUFBTyxLQUFLSCxRQUFMLENBQWNOLEtBQWQsS0FBd0JBLFVBQVVVLEtBQUtDLEtBQUwsQ0FBV0MsTUFBWCxDQUFrQlosS0FBbEIsQ0FBd0JTLEtBQXhCLENBQXpDO0FBQ0Q7QUFDRDs7Ozs7OzZCQUdnQlQsSyxFQUFPUyxLLEVBQU87QUFDNUIsYUFBTyxLQUFLSCxRQUFMLENBQWNOLEtBQWQsS0FBd0JBLE1BQU1hLE9BQU4sQ0FBY0osS0FBZCxLQUF3QixDQUF2RDtBQUNEO0FBQ0Q7Ozs7Ozs4QkFHaUJULEssRUFBT1MsSyxFQUFPO0FBQzdCLGFBQU8sS0FBS0gsUUFBTCxDQUFjTixLQUFkLEtBQXdCQSxNQUFNRSxNQUFOLElBQWdCTyxLQUEvQztBQUNEO0FBQ0Q7Ozs7Ozs4QkFHaUJULEssRUFBT1MsSyxFQUFPO0FBQzdCLGFBQU8sS0FBS0gsUUFBTCxDQUFjTixLQUFkLEtBQXdCQSxNQUFNRSxNQUFOLElBQWdCTyxLQUEvQztBQUNEO0FBQ0Q7Ozs7OztnQ0FHbUJULEssRUFBT1MsSyxFQUFPO0FBQy9CLGFBQU8sS0FBS0gsUUFBTCxDQUFjTixLQUFkLEtBQXlCQSxNQUFNRSxNQUFOLElBQWdCTyxNQUFNLENBQU4sQ0FBaEIsSUFBNEJULE1BQU1FLE1BQU4sSUFBZ0JPLE1BQU0sQ0FBTixDQUE1RTtBQUNEO0FBQ0Q7Ozs7Ozt3QkFHV1QsSyxFQUFPUyxLLEVBQU87QUFDdkIsYUFBTyxLQUFLSCxRQUFMLENBQWNOLEtBQWQsS0FBd0JjLE9BQU9kLEtBQVAsS0FBaUJjLE9BQU9MLEtBQVAsQ0FBaEQ7QUFDRDtBQUNEOzs7Ozs7d0JBR1dULEssRUFBT1MsSyxFQUFPO0FBQ3ZCLGFBQU8sS0FBS0gsUUFBTCxDQUFjTixLQUFkLEtBQXdCYyxPQUFPZCxLQUFQLEtBQWlCYyxPQUFPTCxLQUFQLENBQWhEO0FBQ0Q7O0FBRUQ7Ozs7OzswQkFHYVQsSyxFQUFPUyxLLEVBQU87QUFDekIsYUFBTyxLQUFLSCxRQUFMLENBQWNOLEtBQWQsS0FBd0JBLFNBQVNTLEtBQXhDO0FBQ0Q7QUFDRDs7Ozs7OzJCQUdjVCxLLEVBQU9TLEssRUFBTztBQUMxQixhQUFPLEtBQUtILFFBQUwsQ0FBY04sS0FBZCxLQUF3QkEsU0FBU1MsS0FBeEM7QUFDRDs7QUFFRDs7Ozs7OzBCQUdhVCxLLEVBQU9TLEssRUFBTztBQUN6QixhQUFPLEtBQUtILFFBQUwsQ0FBY04sS0FBZCxLQUF5QkEsU0FBU1MsTUFBTSxDQUFOLENBQVQsSUFBcUJULFNBQVNTLE1BQU0sQ0FBTixDQUE5RDtBQUNEO0FBQ0Q7Ozs7Ozs2QkFHZ0JULEssRUFBTztBQUNyQixhQUFPLENBQUMsS0FBS2UsUUFBTCxDQUFjZixLQUFkLENBQUQsSUFBeUIscUJBQWhDO0FBQ0Q7O0FBRUQ7Ozs7OzswQkFHYUEsSyxFQUFPO0FBQ2xCLGFBQU8sS0FBS00sUUFBTCxDQUFjTixLQUFkLEtBQXdCLHdFQUF3RU8sSUFBeEUsQ0FBNkVQLEtBQTdFLENBQS9CO0FBQ0Q7Ozs7OztrQkFySmtCRCxRIiwiZmlsZSI6IlZhbGlkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGRlZmF1bHQgY2xhc3MgVmFsaWRhdGUge1xyXG4gIC8qKlxyXG4gICAqIOmqjOivgeW/heWhq+WFg+e0oFxyXG4gICAqL1xyXG4gIHN0YXRpYyByZXF1aXJlZCh2YWx1ZSkge1xyXG4gICAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ251bWJlcicpIHtcclxuICAgICAgdmFsdWUgPSB2YWx1ZS50b1N0cmluZygpXHJcbiAgICB9IGVsc2UgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ2Jvb2xlYW4nKSB7XHJcbiAgICAgIHJldHVybiAhMFxyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiB2YWx1ZSAmJiB2YWx1ZS5sZW5ndGggPiAwXHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiDph43lpI3pqozor4FcclxuICAgKi9cclxuICBzdGF0aWMgbm9EdXBsaWNhdGUodmFsdWVzKSB7XHJcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHZhbHVlcy5sZW5ndGg7IGkrKykge1xyXG4gICAgICBmb3IgKGxldCBqID0gMDsgaiA8IHZhbHVlcy5sZW5ndGg7IGorKykge1xyXG4gICAgICAgIGlmICh2YWx1ZXNbaV0gPT0gdmFsdWVzW2pdICYmIGkgIT0gaikge1xyXG4gICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgcmV0dXJuIHRydWU7XHJcbiAgfVxyXG4gIC8qKlxyXG4gICAqIOmqjOivgeeUteWtkOmCrueuseagvOW8j1xyXG4gICAqL1xyXG4gIHN0YXRpYyBlbWFpbCh2YWx1ZSkge1xyXG4gICAgcmV0dXJuIHRoaXMub3B0aW9uYWwodmFsdWUpIHx8IC9eW2EtekEtWjAtOS4hIyQlJicqK1xcLz0/Xl9ge3x9fi1dK0BbYS16QS1aMC05XSg/OlthLXpBLVowLTktXXswLDYxfVthLXpBLVowLTldKT8oPzpcXC5bYS16QS1aMC05XSg/OlthLXpBLVowLTktXXswLDYxfVthLXpBLVowLTldKT8pKiQvLnRlc3QodmFsdWUpXHJcbiAgfVxyXG4gIC8qKlxyXG4gICAqIOmqjOivgeaJi+acuuagvOW8j1xyXG4gICAqL1xyXG4gIHN0YXRpYyB0ZWwodmFsdWUpIHtcclxuICAgIHJldHVybiAgL14xWzM0NTY3ODldXFxkezl9JC8udGVzdCh2YWx1ZSlcclxuICB9XHJcbiAgLyoqXHJcbiAgICog6aqM6K+BVVJM5qC85byPXHJcbiAgICovXHJcbiAgc3RhdGljIHVybCh2YWx1ZSkge1xyXG4gICAgcmV0dXJuIHRoaXMub3B0aW9uYWwodmFsdWUpIHx8IC9eKD86KD86KD86aHR0cHM/fGZ0cCk6KT9cXC9cXC8pKD86XFxTKyg/OjpcXFMqKT9AKT8oPzooPyEoPzoxMHwxMjcpKD86XFwuXFxkezEsM30pezN9KSg/ISg/OjE2OVxcLjI1NHwxOTJcXC4xNjgpKD86XFwuXFxkezEsM30pezJ9KSg/ITE3MlxcLig/OjFbNi05XXwyXFxkfDNbMC0xXSkoPzpcXC5cXGR7MSwzfSl7Mn0pKD86WzEtOV1cXGQ/fDFcXGRcXGR8MlswMV1cXGR8MjJbMC0zXSkoPzpcXC4oPzoxP1xcZHsxLDJ9fDJbMC00XVxcZHwyNVswLTVdKSl7Mn0oPzpcXC4oPzpbMS05XVxcZD98MVxcZFxcZHwyWzAtNF1cXGR8MjVbMC00XSkpfCg/Oig/OlthLXpcXHUwMGExLVxcdWZmZmYwLTldLSopKlthLXpcXHUwMGExLVxcdWZmZmYwLTldKykoPzpcXC4oPzpbYS16XFx1MDBhMS1cXHVmZmZmMC05XS0qKSpbYS16XFx1MDBhMS1cXHVmZmZmMC05XSspKig/OlxcLig/OlthLXpcXHUwMGExLVxcdWZmZmZdezIsfSkpLj8pKD86OlxcZHsyLDV9KT8oPzpbLz8jXVxcUyopPyQvaS50ZXN0KHZhbHVlKVxyXG4gIH1cclxuICAvKipcclxuICAgKiDpqozor4Hml6XmnJ/moLzlvI9cclxuICAgKi9cclxuICBzdGF0aWMgZGF0ZSh2YWx1ZSkge1xyXG4gICAgcmV0dXJuIHRoaXMub3B0aW9uYWwodmFsdWUpIHx8ICEvSW52YWxpZHxOYU4vLnRlc3QobmV3IERhdGUodmFsdWUpLnRvU3RyaW5nKCkpXHJcbiAgfVxyXG4gIC8qKlxyXG4gICAqIOmqjOivgUlTT+exu+Wei+eahOaXpeacn+agvOW8j1xyXG4gICAqL1xyXG4gIHN0YXRpYyBkYXRlSVNPKHZhbHVlKSB7XHJcbiAgICByZXR1cm4gdGhpcy5vcHRpb25hbCh2YWx1ZSkgfHwgL15cXGR7NH1bXFwvXFwtXSgwP1sxLTldfDFbMDEyXSlbXFwvXFwtXSgwP1sxLTldfFsxMl1bMC05XXwzWzAxXSkkLy50ZXN0KHZhbHVlKVxyXG4gIH1cclxuICAvKipcclxuICAgKiDpqozor4HljYHov5vliLbmlbDlrZdcclxuICAgKi9cclxuICBzdGF0aWMgbnVtYmVyKHZhbHVlKSB7XHJcbiAgICByZXR1cm4gdGhpcy5vcHRpb25hbCh2YWx1ZSkgfHwgL14oPzotP1xcZCt8LT9cXGR7MSwzfSg/OixcXGR7M30pKyk/KD86XFwuXFxkKyk/JC8udGVzdCh2YWx1ZSlcclxuICB9XHJcbiAgLyoqXHJcbiAgICog6aqM6K+B5pW05pWwXHJcbiAgICovXHJcbiAgc3RhdGljIGRpZ2l0cyh2YWx1ZSkge1xyXG4gICAgcmV0dXJuIHRoaXMub3B0aW9uYWwodmFsdWUpIHx8IC9eXFxkKyQvLnRlc3QodmFsdWUpXHJcbiAgfVxyXG4gIC8qKlxyXG4gICAqIOmqjOivgei6q+S7veivgeWPt+eggVxyXG4gICAqL1xyXG4gIHN0YXRpYyBpZGNhcmQodmFsdWUpIHtcclxuICAgIHJldHVybiB0aGlzLm9wdGlvbmFsKHZhbHVlKSB8fCAvXlsxLTldXFxkezV9WzEtOV1cXGR7M30oKDBcXGQpfCgxWzAtMl0pKSgoWzB8MXwyXVxcZCl8M1swLTFdKVxcZHszfShbMC05XXxYKSQvLnRlc3QodmFsdWUpXHJcbiAgfVxyXG4gIC8qKlxyXG4gICAqIOmqjOivgeS4pOS4qui+k+WFpeahhueahOWGheWuueaYr+WQpuebuOWQjFxyXG4gICAqL1xyXG4gIHN0YXRpYyBlcXVhbFRvKHZhbHVlLCBwYXJhbSkge1xyXG4gICAgcmV0dXJuIHRoaXMub3B0aW9uYWwodmFsdWUpIHx8IHZhbHVlID09PSB0aGF0LnNjb3BlLmRldGFpbC52YWx1ZVtwYXJhbV1cclxuICB9XHJcbiAgLyoqXHJcbiAgICog6aqM6K+B5piv5ZCm5YyF5ZCr5p+Q5Liq5YC8XHJcbiAgICovXHJcbiAgc3RhdGljIGNvbnRhaW5zKHZhbHVlLCBwYXJhbSkge1xyXG4gICAgcmV0dXJuIHRoaXMub3B0aW9uYWwodmFsdWUpIHx8IHZhbHVlLmluZGV4T2YocGFyYW0pID49IDBcclxuICB9XHJcbiAgLyoqXHJcbiAgICog6aqM6K+B5pyA5bCP6ZW/5bqmXHJcbiAgICovXHJcbiAgc3RhdGljIG1pbmxlbmd0aCh2YWx1ZSwgcGFyYW0pIHtcclxuICAgIHJldHVybiB0aGlzLm9wdGlvbmFsKHZhbHVlKSB8fCB2YWx1ZS5sZW5ndGggPj0gcGFyYW1cclxuICB9XHJcbiAgLyoqXHJcbiAgICog6aqM6K+B5pyA5aSn6ZW/5bqmXHJcbiAgICovXHJcbiAgc3RhdGljIG1heGxlbmd0aCh2YWx1ZSwgcGFyYW0pIHtcclxuICAgIHJldHVybiB0aGlzLm9wdGlvbmFsKHZhbHVlKSB8fCB2YWx1ZS5sZW5ndGggPD0gcGFyYW1cclxuICB9XHJcbiAgLyoqXHJcbiAgICog6aqM6K+B5LiA5Liq6ZW/5bqm6IyD5Zu0W21pbiwgbWF4XVxyXG4gICAqL1xyXG4gIHN0YXRpYyByYW5nZWxlbmd0aCh2YWx1ZSwgcGFyYW0pIHtcclxuICAgIHJldHVybiB0aGlzLm9wdGlvbmFsKHZhbHVlKSB8fCAodmFsdWUubGVuZ3RoID49IHBhcmFtWzBdICYmIHZhbHVlLmxlbmd0aCA8PSBwYXJhbVsxXSlcclxuICB9XHJcbiAgLyoqXHJcbiAgICog6aqM6K+B5pyA5bCP5YC8XHJcbiAgICovXHJcbiAgc3RhdGljIG1pbih2YWx1ZSwgcGFyYW0pIHtcclxuICAgIHJldHVybiB0aGlzLm9wdGlvbmFsKHZhbHVlKSB8fCBOdW1iZXIodmFsdWUpID49IE51bWJlcihwYXJhbSk7XHJcbiAgfVxyXG4gIC8qKlxyXG4gICAqIOmqjOivgeacgOWkp+WAvFxyXG4gICAqL1xyXG4gIHN0YXRpYyBtYXgodmFsdWUsIHBhcmFtKSB7XHJcbiAgICByZXR1cm4gdGhpcy5vcHRpb25hbCh2YWx1ZSkgfHwgTnVtYmVyKHZhbHVlKSA8PSBOdW1iZXIocGFyYW0pO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICog6aqM6K+B5pe26Ze0XHJcbiAgICovXHJcbiAgc3RhdGljIGFmdGVyKHZhbHVlLCBwYXJhbSkge1xyXG4gICAgcmV0dXJuIHRoaXMub3B0aW9uYWwodmFsdWUpIHx8IHZhbHVlID49IHBhcmFtO1xyXG4gIH1cclxuICAvKipcclxuICAgKiDpqozor4Hml7bpl7RcclxuICAgKi9cclxuICBzdGF0aWMgYmVmb3JlKHZhbHVlLCBwYXJhbSkge1xyXG4gICAgcmV0dXJuIHRoaXMub3B0aW9uYWwodmFsdWUpIHx8IHZhbHVlIDw9IHBhcmFtO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICog6aqM6K+B5LiA5Liq5YC86IyD5Zu0W21pbiwgbWF4XVxyXG4gICAqL1xyXG4gIHN0YXRpYyByYW5nZSh2YWx1ZSwgcGFyYW0pIHtcclxuICAgIHJldHVybiB0aGlzLm9wdGlvbmFsKHZhbHVlKSB8fCAodmFsdWUgPj0gcGFyYW1bMF0gJiYgdmFsdWUgPD0gcGFyYW1bMV0pXHJcbiAgfVxyXG4gIC8qKlxyXG4gICAqIOWIpOaWrei+k+WFpeWAvOaYr+WQpuS4uuepulxyXG4gICAqL1xyXG4gIHN0YXRpYyBvcHRpb25hbCh2YWx1ZSkge1xyXG4gICAgcmV0dXJuICF0aGlzLnJlcXVpcmVkKHZhbHVlKSAmJiAnZGVwZW5kZW5jeS1taXNtYXRjaCdcclxuICB9XHJcblxyXG4gIC8qKipcclxuICAgKiDpqozor4Hph5Hpop1cclxuICAgKi9cclxuICBzdGF0aWMgbW9uZXkodmFsdWUpIHtcclxuICAgIHJldHVybiB0aGlzLm9wdGlvbmFsKHZhbHVlKSB8fCAvKF5bMS05XShbMC05XSspPyhcXC5bMC05XXsxLDJ9KT8kKXwoXigwKXsxfSQpfCheWzAtOV1cXC5bMC05XShbMC05XSk/JCkvLnRlc3QodmFsdWUpXHJcbiAgfVxyXG59XHJcbiJdfQ==