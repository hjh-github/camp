"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Lang = function () {
  function Lang() {
    _classCallCheck(this, Lang);
  }

  _createClass(Lang, null, [{
    key: "downImg",
    value: function downImg(url) {
      var callback = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;

      console.log(url);
      //图片保存到本地
      wx.saveImageToPhotosAlbum({
        filePath: url,
        success: function () {
          var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(data) {
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    if (callback) callback(data);

                  case 1:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));

          function success(_x2) {
            return _ref.apply(this, arguments);
          }

          return success;
        }(),
        fail: function fail(err) {
          console.log(err);
          if (err.errMsg === "saveImageToPhotosAlbum:fail auth deny") {
            console.log("当初用户拒绝，再次发起授权");
            wx.openSetting({
              success: function success(settingdata) {
                console.log(settingdata);
                if (settingdata.authSetting['scope.writePhotosAlbum']) {
                  console.log('获取权限成功，给出再次点击图片保存到相册的提示。');
                } else {
                  console.log('获取权限失败，给出不给权限就无法正常使用的提示');
                }
              }
            });
          }
        },
        complete: function complete(res) {
          console.log(res);
        }
      });
    }
    // 判断字符串是否为空

  }, {
    key: "isEmpty",
    value: function isEmpty(str) {
      return str == '' || str == null || str == 'null';
    }
    // 判断字符串是否不为空

  }, {
    key: "isNotEmpty",
    value: function isNotEmpty(str) {
      return !this.isEmpty(str);
    }
    // 浮点求和

  }, {
    key: "sum",
    value: function sum(numbers) {
      var toFixed = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 2;

      var sum = 0;
      var _iteratorNormalCompletion = true;
      var _didIteratorError = false;
      var _iteratorError = undefined;

      try {
        for (var _iterator = numbers[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
          var str = _step.value;

          if (!this.isNumber(str)) {
            return NaN;
          }
          var num = parseFloat(str);
          if (isNaN(num)) {
            return NaN;
          }
          sum += num;
        }
      } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion && _iterator.return) {
            _iterator.return();
          }
        } finally {
          if (_didIteratorError) {
            throw _iteratorError;
          }
        }
      }

      return sum.toFixed(toFixed);
    }
    // 数字判断

  }, {
    key: "isNumber",
    value: function isNumber(value) {
      var patrn = /^[-+]?\d+(\.\d+)?$/;
      return patrn.test(value);
    }

    // 数字判断

  }, {
    key: "isPositiveNumber",
    value: function isPositiveNumber(value) {
      var patrn = /^[1-9]\d*$|^\.\d*$|^0\.\d*$|^[1-9]\d*\.\d*$|^0$/;
      return patrn.test(value);
    }
    // 数组判断

  }, {
    key: "isArray",
    value: function isArray(o) {
      return Object.prototype.toString.call(o) === '[object Array]';
    }
    // 事件转日期

  }, {
    key: "convertTimestapeToDay",
    value: function convertTimestapeToDay(timestape) {
      return timestape.substring(0, timestape.indexOf(' ')).replace(/-/g, '.');
    }

    // 格式化日期

  }, {
    key: "dateFormate",
    value: function dateFormate(date, fmt) {
      var o = {
        'M+': date.getMonth() + 1,
        'd+': date.getDate(),
        'h+': date.getHours(),
        'm+': date.getMinutes(),
        's+': date.getSeconds(),
        'q+': Math.floor((date.getMonth() + 3) / 3),
        'S': date.getMilliseconds()
      };
      if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length));
      for (var k in o) {
        if (new RegExp('(' + k + ')').test(fmt)) fmt = fmt.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ('00' + o[k]).substr(('' + o[k]).length));
      }
      return fmt;
    }
    /**
      * 获取距离当前日期第n天的日期
      * @param {n} day 
      */

  }, {
    key: "getDay",
    value: function getDay(day) {
      var today = new Date();
      var targetday_milliseconds = today.getTime() + 1000 * 60 * 60 * 24 * day;
      today.setTime(targetday_milliseconds); //注意，这行是关键代码
      var tYear = today.getFullYear();
      var tMonth = today.getMonth();
      var tDate = today.getDate();
      tMonth = this.doHandleMonth(tMonth + 1);
      tDate = this.doHandleMonth(tDate);
      return tYear + "-" + tMonth + "-" + tDate;
    }
  }, {
    key: "doHandleMonth",
    value: function doHandleMonth(month) {
      var m = month;
      if (month.toString().length == 1) {
        m = "0" + month;
      }
      return m;
    }
    // 检验身份证

  }, {
    key: "checkIdCard",
    value: function checkIdCard(IDCard) {
      var iSum = 0;
      var info = "";
      if (!/^\d{17}(\d|x)$/i.test(IDCard)) return {
        status: false,
        message: '输入的身份证长度或格式错误!'
      };
      IDCard = IDCard.replace(/x$/i, "a");
      // if (areaID[parseInt(IDCard.substr(0, 2))] == null)
      //   return {
      //     status: false,
      //     message: '输入的身份证有误!'
      //   };
      var sBirthday = IDCard.substr(6, 4) + "-" + Number(IDCard.substr(10, 2)) + "-" + Number(IDCard.substr(12, 2));
      var d = new Date(sBirthday.replace(/-/g, "/"));
      if (sBirthday != d.getFullYear() + "-" + (d.getMonth() + 1) + "-" + d.getDate()) return {
        status: false,
        message: '输入的身份证有误!'
      };
      for (var i = 17; i >= 0; i--) {
        iSum += Math.pow(2, i) % 11 * parseInt(IDCard.charAt(17 - i), 11);
      }if (iSum % 11 != 1) return {
        status: false,
        message: '输入的身份证有误!'
      };
      //aCity[parseInt(sId.substr(0,2))]+","+sBirthday+","+(sId.substr(16,1)%2?"男":"女");//此次还可以判断出输入的身份证号的人性别
      return {
        status: true,
        message: '校验成功！'
      };
    }
    // 身份证获取出生年月日

  }, {
    key: "getBirthdayByIdCard",
    value: function getBirthdayByIdCard(idCard) {
      // 校验身份证是否合法
      var _r = this.checkIdCard(idCard);
      if (!_r.status) {
        return _extends({}, _r);
      }
      var birthStr;
      if (15 == idCard.length) {
        birthStr = idCard.charAt(6) + idCard.charAt(7);
        if (parseInt(birthStr) < 10) {
          birthStr = '20' + birthStr;
        } else {
          birthStr = '19' + birthStr;
        }
        birthStr = birthStr + '-' + idCard.charAt(8) + idCard.charAt(9) + '-' + idCard.charAt(10) + idCard.charAt(11);
      } else if (18 == idCard.length) {
        birthStr = idCard.charAt(6) + idCard.charAt(7) + idCard.charAt(8) + idCard.charAt(9) + '-' + idCard.charAt(10) + idCard.charAt(11) + '-' + idCard.charAt(12) + idCard.charAt(13);
      }
      return birthStr;
    }
  }, {
    key: "getSexByIdCard",
    value: function getSexByIdCard(idCard) {
      if (idCard.length == 15) {
        return idCard.substring(14, 15) % 2;
      } else if (idCard.length == 18) {
        return idCard.substring(14, 17) % 2;
      } else {
        //不是15或者18,null
        return '';
      }
    }
  }]);

  return Lang;
}();

exports.default = Lang;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkxhbmcuanMiXSwibmFtZXMiOlsiTGFuZyIsInVybCIsImNhbGxiYWNrIiwiY29uc29sZSIsImxvZyIsInd4Iiwic2F2ZUltYWdlVG9QaG90b3NBbGJ1bSIsImZpbGVQYXRoIiwic3VjY2VzcyIsImRhdGEiLCJmYWlsIiwiZXJyIiwiZXJyTXNnIiwib3BlblNldHRpbmciLCJzZXR0aW5nZGF0YSIsImF1dGhTZXR0aW5nIiwiY29tcGxldGUiLCJyZXMiLCJzdHIiLCJpc0VtcHR5IiwibnVtYmVycyIsInRvRml4ZWQiLCJzdW0iLCJpc051bWJlciIsIk5hTiIsIm51bSIsInBhcnNlRmxvYXQiLCJpc05hTiIsInZhbHVlIiwicGF0cm4iLCJ0ZXN0IiwibyIsIk9iamVjdCIsInByb3RvdHlwZSIsInRvU3RyaW5nIiwiY2FsbCIsInRpbWVzdGFwZSIsInN1YnN0cmluZyIsImluZGV4T2YiLCJyZXBsYWNlIiwiZGF0ZSIsImZtdCIsImdldE1vbnRoIiwiZ2V0RGF0ZSIsImdldEhvdXJzIiwiZ2V0TWludXRlcyIsImdldFNlY29uZHMiLCJNYXRoIiwiZmxvb3IiLCJnZXRNaWxsaXNlY29uZHMiLCJSZWdFeHAiLCIkMSIsImdldEZ1bGxZZWFyIiwic3Vic3RyIiwibGVuZ3RoIiwiayIsImRheSIsInRvZGF5IiwiRGF0ZSIsInRhcmdldGRheV9taWxsaXNlY29uZHMiLCJnZXRUaW1lIiwic2V0VGltZSIsInRZZWFyIiwidE1vbnRoIiwidERhdGUiLCJkb0hhbmRsZU1vbnRoIiwibW9udGgiLCJtIiwiSURDYXJkIiwiaVN1bSIsImluZm8iLCJzdGF0dXMiLCJtZXNzYWdlIiwic0JpcnRoZGF5IiwiTnVtYmVyIiwiZCIsImkiLCJwb3ciLCJwYXJzZUludCIsImNoYXJBdCIsImlkQ2FyZCIsIl9yIiwiY2hlY2tJZENhcmQiLCJiaXJ0aFN0ciJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7SUFBcUJBLEk7Ozs7Ozs7NEJBQ0pDLEcsRUFBcUI7QUFBQSxVQUFqQkMsUUFBaUIsdUVBQU4sSUFBTTs7QUFDbENDLGNBQVFDLEdBQVIsQ0FBWUgsR0FBWjtBQUNBO0FBQ0FJLFNBQUdDLHNCQUFILENBQTBCO0FBQ3hCQyxrQkFBVU4sR0FEYztBQUV4Qk87QUFBQSw2RUFBUyxpQkFBZ0JDLElBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDUix3QkFBR1AsUUFBSCxFQUFhQSxTQUFTTyxJQUFUOztBQURMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVQ7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUEsV0FGd0I7QUFLeEJDLGNBQU0sY0FBVUMsR0FBVixFQUFlO0FBQ25CUixrQkFBUUMsR0FBUixDQUFZTyxHQUFaO0FBQ0EsY0FBSUEsSUFBSUMsTUFBSixLQUFlLHVDQUFuQixFQUE0RDtBQUMxRFQsb0JBQVFDLEdBQVIsQ0FBWSxlQUFaO0FBQ0FDLGVBQUdRLFdBQUgsQ0FBZTtBQUNiTCxxQkFEYSxtQkFDTE0sV0FESyxFQUNRO0FBQ25CWCx3QkFBUUMsR0FBUixDQUFZVSxXQUFaO0FBQ0Esb0JBQUlBLFlBQVlDLFdBQVosQ0FBd0Isd0JBQXhCLENBQUosRUFBdUQ7QUFDckRaLDBCQUFRQyxHQUFSLENBQVksMEJBQVo7QUFDRCxpQkFGRCxNQUVPO0FBQ0xELDBCQUFRQyxHQUFSLENBQVkseUJBQVo7QUFDRDtBQUNGO0FBUlksYUFBZjtBQVVEO0FBQ0YsU0FwQnVCO0FBcUJ4QlksZ0JBckJ3QixvQkFxQmZDLEdBckJlLEVBcUJWO0FBQ1pkLGtCQUFRQyxHQUFSLENBQVlhLEdBQVo7QUFDRDtBQXZCdUIsT0FBMUI7QUF5QkQ7QUFDRDs7Ozs0QkFDZUMsRyxFQUFLO0FBQ2xCLGFBQU9BLE9BQU8sRUFBUCxJQUFhQSxPQUFPLElBQXBCLElBQTRCQSxPQUFPLE1BQTFDO0FBQ0Q7QUFDRDs7OzsrQkFDa0JBLEcsRUFBSztBQUNyQixhQUFPLENBQUMsS0FBS0MsT0FBTCxDQUFhRCxHQUFiLENBQVI7QUFDRDtBQUNEOzs7O3dCQUNXRSxPLEVBQXNCO0FBQUEsVUFBYkMsT0FBYSx1RUFBSCxDQUFHOztBQUMvQixVQUFJQyxNQUFNLENBQVY7QUFEK0I7QUFBQTtBQUFBOztBQUFBO0FBRS9CLDZCQUFrQkYsT0FBbEIsOEhBQTJCO0FBQUEsY0FBaEJGLEdBQWdCOztBQUN6QixjQUFJLENBQUMsS0FBS0ssUUFBTCxDQUFjTCxHQUFkLENBQUwsRUFBeUI7QUFDdkIsbUJBQU9NLEdBQVA7QUFDRDtBQUNELGNBQU1DLE1BQU1DLFdBQVdSLEdBQVgsQ0FBWjtBQUNBLGNBQUlTLE1BQU1GLEdBQU4sQ0FBSixFQUFnQjtBQUNkLG1CQUFPRCxHQUFQO0FBQ0Q7QUFDREYsaUJBQU9HLEdBQVA7QUFDRDtBQVg4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQVkvQixhQUFPSCxJQUFJRCxPQUFKLENBQVlBLE9BQVosQ0FBUDtBQUNEO0FBQ0Q7Ozs7NkJBQ2dCTyxLLEVBQU87QUFDckIsVUFBTUMsUUFBUSxvQkFBZDtBQUNBLGFBQU9BLE1BQU1DLElBQU4sQ0FBV0YsS0FBWCxDQUFQO0FBQ0Q7O0FBRUQ7Ozs7cUNBQ3dCQSxLLEVBQU87QUFDN0IsVUFBTUMsUUFBUSxpREFBZDtBQUNBLGFBQU9BLE1BQU1DLElBQU4sQ0FBV0YsS0FBWCxDQUFQO0FBQ0Q7QUFDRDs7Ozs0QkFDZUcsQyxFQUFHO0FBQ2hCLGFBQU9DLE9BQU9DLFNBQVAsQ0FBaUJDLFFBQWpCLENBQTBCQyxJQUExQixDQUErQkosQ0FBL0IsTUFBc0MsZ0JBQTdDO0FBQ0Q7QUFDRDs7OzswQ0FDNkJLLFMsRUFBVztBQUN0QyxhQUFPQSxVQUFVQyxTQUFWLENBQW9CLENBQXBCLEVBQXVCRCxVQUFVRSxPQUFWLENBQWtCLEdBQWxCLENBQXZCLEVBQStDQyxPQUEvQyxDQUF1RCxJQUF2RCxFQUE2RCxHQUE3RCxDQUFQO0FBQ0Q7O0FBRUQ7Ozs7Z0NBQ21CQyxJLEVBQU1DLEcsRUFBSztBQUM1QixVQUFNVixJQUFJO0FBQ1IsY0FBTVMsS0FBS0UsUUFBTCxLQUFrQixDQURoQjtBQUVSLGNBQU1GLEtBQUtHLE9BQUwsRUFGRTtBQUdSLGNBQU1ILEtBQUtJLFFBQUwsRUFIRTtBQUlSLGNBQU1KLEtBQUtLLFVBQUwsRUFKRTtBQUtSLGNBQU1MLEtBQUtNLFVBQUwsRUFMRTtBQU1SLGNBQU1DLEtBQUtDLEtBQUwsQ0FBVyxDQUFDUixLQUFLRSxRQUFMLEtBQWtCLENBQW5CLElBQXdCLENBQW5DLENBTkU7QUFPUixhQUFLRixLQUFLUyxlQUFMO0FBUEcsT0FBVjtBQVNBLFVBQUksT0FBT25CLElBQVAsQ0FBWVcsR0FBWixDQUFKLEVBQXNCQSxNQUFNQSxJQUFJRixPQUFKLENBQVlXLE9BQU9DLEVBQW5CLEVBQXVCLENBQUNYLEtBQUtZLFdBQUwsS0FBcUIsRUFBdEIsRUFBMEJDLE1BQTFCLENBQWlDLElBQUlILE9BQU9DLEVBQVAsQ0FBVUcsTUFBL0MsQ0FBdkIsQ0FBTjtBQUN0QixXQUFLLElBQUlDLENBQVQsSUFBY3hCLENBQWQsRUFBaUI7QUFDZixZQUFJLElBQUltQixNQUFKLENBQVcsTUFBTUssQ0FBTixHQUFVLEdBQXJCLEVBQTBCekIsSUFBMUIsQ0FBK0JXLEdBQS9CLENBQUosRUFBeUNBLE1BQU1BLElBQUlGLE9BQUosQ0FBWVcsT0FBT0MsRUFBbkIsRUFBd0JELE9BQU9DLEVBQVAsQ0FBVUcsTUFBVixJQUFvQixDQUFyQixHQUEyQnZCLEVBQUV3QixDQUFGLENBQTNCLEdBQW9DLENBQUMsT0FBT3hCLEVBQUV3QixDQUFGLENBQVIsRUFBY0YsTUFBZCxDQUFxQixDQUFDLEtBQUt0QixFQUFFd0IsQ0FBRixDQUFOLEVBQVlELE1BQWpDLENBQTNELENBQU47QUFDMUM7QUFDRCxhQUFPYixHQUFQO0FBQ0Q7QUFDRDs7Ozs7OzsyQkFJY2UsRyxFQUFLO0FBQ2pCLFVBQUlDLFFBQVEsSUFBSUMsSUFBSixFQUFaO0FBQ0EsVUFBSUMseUJBQXlCRixNQUFNRyxPQUFOLEtBQWtCLE9BQU8sRUFBUCxHQUFZLEVBQVosR0FBaUIsRUFBakIsR0FBc0JKLEdBQXJFO0FBQ0FDLFlBQU1JLE9BQU4sQ0FBY0Ysc0JBQWQsRUFIaUIsQ0FHc0I7QUFDdkMsVUFBSUcsUUFBUUwsTUFBTUwsV0FBTixFQUFaO0FBQ0EsVUFBSVcsU0FBU04sTUFBTWYsUUFBTixFQUFiO0FBQ0EsVUFBSXNCLFFBQVFQLE1BQU1kLE9BQU4sRUFBWjtBQUNBb0IsZUFBUyxLQUFLRSxhQUFMLENBQW1CRixTQUFTLENBQTVCLENBQVQ7QUFDQUMsY0FBUSxLQUFLQyxhQUFMLENBQW1CRCxLQUFuQixDQUFSO0FBQ0EsYUFBT0YsUUFBUSxHQUFSLEdBQWNDLE1BQWQsR0FBdUIsR0FBdkIsR0FBNkJDLEtBQXBDO0FBQ0Q7OztrQ0FDb0JFLEssRUFBTztBQUMxQixVQUFJQyxJQUFJRCxLQUFSO0FBQ0EsVUFBSUEsTUFBTWhDLFFBQU4sR0FBaUJvQixNQUFqQixJQUEyQixDQUEvQixFQUFrQztBQUNoQ2EsWUFBSSxNQUFNRCxLQUFWO0FBQ0Q7QUFDRCxhQUFPQyxDQUFQO0FBQ0Q7QUFDRDs7OztnQ0FDbUJDLE0sRUFBUTtBQUN6QixVQUFJQyxPQUFPLENBQVg7QUFDQSxVQUFJQyxPQUFPLEVBQVg7QUFDQSxVQUFJLENBQUMsa0JBQWtCeEMsSUFBbEIsQ0FBdUJzQyxNQUF2QixDQUFMLEVBQ0UsT0FBTztBQUNMRyxnQkFBUSxLQURIO0FBRUxDLGlCQUFTO0FBRkosT0FBUDtBQUlGSixlQUFTQSxPQUFPN0IsT0FBUCxDQUFlLEtBQWYsRUFBc0IsR0FBdEIsQ0FBVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxVQUFJa0MsWUFBWUwsT0FBT2YsTUFBUCxDQUFjLENBQWQsRUFBaUIsQ0FBakIsSUFBc0IsR0FBdEIsR0FBNEJxQixPQUFPTixPQUFPZixNQUFQLENBQWMsRUFBZCxFQUFrQixDQUFsQixDQUFQLENBQTVCLEdBQTJELEdBQTNELEdBQWlFcUIsT0FBT04sT0FBT2YsTUFBUCxDQUFjLEVBQWQsRUFBa0IsQ0FBbEIsQ0FBUCxDQUFqRjtBQUNBLFVBQUlzQixJQUFJLElBQUlqQixJQUFKLENBQVNlLFVBQVVsQyxPQUFWLENBQWtCLElBQWxCLEVBQXdCLEdBQXhCLENBQVQsQ0FBUjtBQUNBLFVBQUlrQyxhQUFjRSxFQUFFdkIsV0FBRixLQUFrQixHQUFsQixJQUF5QnVCLEVBQUVqQyxRQUFGLEtBQWUsQ0FBeEMsSUFBNkMsR0FBN0MsR0FBbURpQyxFQUFFaEMsT0FBRixFQUFyRSxFQUNFLE9BQU87QUFDTDRCLGdCQUFRLEtBREg7QUFFTEMsaUJBQVM7QUFGSixPQUFQO0FBSUYsV0FBSyxJQUFJSSxJQUFJLEVBQWIsRUFBaUJBLEtBQUssQ0FBdEIsRUFBeUJBLEdBQXpCO0FBQ0VQLGdCQUFTdEIsS0FBSzhCLEdBQUwsQ0FBUyxDQUFULEVBQVlELENBQVosSUFBaUIsRUFBbEIsR0FBd0JFLFNBQVNWLE9BQU9XLE1BQVAsQ0FBYyxLQUFLSCxDQUFuQixDQUFULEVBQWdDLEVBQWhDLENBQWhDO0FBREYsT0FFQSxJQUFJUCxPQUFPLEVBQVAsSUFBYSxDQUFqQixFQUNFLE9BQU87QUFDTEUsZ0JBQVEsS0FESDtBQUVMQyxpQkFBUztBQUZKLE9BQVA7QUFJRjtBQUNBLGFBQU87QUFDTEQsZ0JBQVEsSUFESDtBQUVMQyxpQkFBUztBQUZKLE9BQVA7QUFJRDtBQUNEOzs7O3dDQUMyQlEsTSxFQUFRO0FBQ2pDO0FBQ0EsVUFBSUMsS0FBSyxLQUFLQyxXQUFMLENBQWlCRixNQUFqQixDQUFUO0FBQ0EsVUFBRyxDQUFFQyxHQUFHVixNQUFSLEVBQWU7QUFDYiw0QkFDS1UsRUFETDtBQUdEO0FBQ0QsVUFBSUUsUUFBSjtBQUNBLFVBQUksTUFBTUgsT0FBTzFCLE1BQWpCLEVBQXlCO0FBQ3ZCNkIsbUJBQVdILE9BQU9ELE1BQVAsQ0FBYyxDQUFkLElBQW1CQyxPQUFPRCxNQUFQLENBQWMsQ0FBZCxDQUE5QjtBQUNBLFlBQUlELFNBQVNLLFFBQVQsSUFBcUIsRUFBekIsRUFBNkI7QUFDM0JBLHFCQUFXLE9BQU9BLFFBQWxCO0FBQ0QsU0FGRCxNQUVPO0FBQ0xBLHFCQUFXLE9BQU9BLFFBQWxCO0FBQ0Q7QUFDREEsbUJBQVdBLFdBQVcsR0FBWCxHQUFpQkgsT0FBT0QsTUFBUCxDQUFjLENBQWQsQ0FBakIsR0FBb0NDLE9BQU9ELE1BQVAsQ0FBYyxDQUFkLENBQXBDLEdBQXVELEdBQXZELEdBQTZEQyxPQUFPRCxNQUFQLENBQWMsRUFBZCxDQUE3RCxHQUFpRkMsT0FBT0QsTUFBUCxDQUFjLEVBQWQsQ0FBNUY7QUFDRCxPQVJELE1BUU8sSUFBSSxNQUFNQyxPQUFPMUIsTUFBakIsRUFBeUI7QUFDOUI2QixtQkFBV0gsT0FBT0QsTUFBUCxDQUFjLENBQWQsSUFBbUJDLE9BQU9ELE1BQVAsQ0FBYyxDQUFkLENBQW5CLEdBQXNDQyxPQUFPRCxNQUFQLENBQWMsQ0FBZCxDQUF0QyxHQUF5REMsT0FBT0QsTUFBUCxDQUFjLENBQWQsQ0FBekQsR0FBNEUsR0FBNUUsR0FBa0ZDLE9BQU9ELE1BQVAsQ0FBYyxFQUFkLENBQWxGLEdBQXNHQyxPQUFPRCxNQUFQLENBQWMsRUFBZCxDQUF0RyxHQUEwSCxHQUExSCxHQUFnSUMsT0FBT0QsTUFBUCxDQUFjLEVBQWQsQ0FBaEksR0FBb0pDLE9BQU9ELE1BQVAsQ0FBYyxFQUFkLENBQS9KO0FBQ0Q7QUFDRCxhQUFPSSxRQUFQO0FBQ0Q7OzttQ0FDc0JILE0sRUFBUTtBQUM3QixVQUFHQSxPQUFPMUIsTUFBUCxJQUFpQixFQUFwQixFQUF3QjtBQUN0QixlQUFPMEIsT0FBTzNDLFNBQVAsQ0FBaUIsRUFBakIsRUFBcUIsRUFBckIsSUFBMkIsQ0FBbEM7QUFDRCxPQUZELE1BRU8sSUFBRzJDLE9BQU8xQixNQUFQLElBQWlCLEVBQXBCLEVBQXdCO0FBQzdCLGVBQU8wQixPQUFPM0MsU0FBUCxDQUFpQixFQUFqQixFQUFxQixFQUFyQixJQUEyQixDQUFsQztBQUNELE9BRk0sTUFFQTtBQUNMO0FBQ0EsZUFBTyxFQUFQO0FBQ0Q7QUFDRjs7Ozs7O2tCQW5Ma0JyQyxJIiwiZmlsZSI6IkxhbmcuanMiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgZGVmYXVsdCBjbGFzcyBMYW5nIHtcclxuICBzdGF0aWMgZG93bkltZyh1cmwsY2FsbGJhY2sgPSBudWxsKSB7XHJcbiAgICBjb25zb2xlLmxvZyh1cmwpXHJcbiAgICAvL+WbvueJh+S/neWtmOWIsOacrOWcsFxyXG4gICAgd3guc2F2ZUltYWdlVG9QaG90b3NBbGJ1bSh7XHJcbiAgICAgIGZpbGVQYXRoOiB1cmwsXHJcbiAgICAgIHN1Y2Nlc3M6IGFzeW5jIGZ1bmN0aW9uIChkYXRhKSB7XHJcbiAgICAgICBpZihjYWxsYmFjaykgY2FsbGJhY2soZGF0YSlcclxuICAgICAgfSxcclxuICAgICAgZmFpbDogZnVuY3Rpb24gKGVycikge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGVycik7XHJcbiAgICAgICAgaWYgKGVyci5lcnJNc2cgPT09IFwic2F2ZUltYWdlVG9QaG90b3NBbGJ1bTpmYWlsIGF1dGggZGVueVwiKSB7XHJcbiAgICAgICAgICBjb25zb2xlLmxvZyhcIuW9k+WIneeUqOaIt+aLkue7ne+8jOWGjeasoeWPkei1t+aOiOadg1wiKVxyXG4gICAgICAgICAgd3gub3BlblNldHRpbmcoe1xyXG4gICAgICAgICAgICBzdWNjZXNzKHNldHRpbmdkYXRhKSB7XHJcbiAgICAgICAgICAgICAgY29uc29sZS5sb2coc2V0dGluZ2RhdGEpXHJcbiAgICAgICAgICAgICAgaWYgKHNldHRpbmdkYXRhLmF1dGhTZXR0aW5nWydzY29wZS53cml0ZVBob3Rvc0FsYnVtJ10pIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCfojrflj5bmnYPpmZDmiJDlip/vvIznu5nlh7rlho3mrKHngrnlh7vlm77niYfkv53lrZjliLDnm7jlhoznmoTmj5DnpLrjgIInKVxyXG4gICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygn6I635Y+W5p2D6ZmQ5aSx6LSl77yM57uZ5Ye65LiN57uZ5p2D6ZmQ5bCx5peg5rOV5q2j5bi45L2/55So55qE5o+Q56S6JylcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH0pXHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG4gICAgICBjb21wbGV0ZShyZXMpIHtcclxuICAgICAgICBjb25zb2xlLmxvZyhyZXMpO1xyXG4gICAgICB9XHJcbiAgICB9KVxyXG4gIH1cclxuICAvLyDliKTmlq3lrZfnrKbkuLLmmK/lkKbkuLrnqbpcclxuICBzdGF0aWMgaXNFbXB0eShzdHIpIHtcclxuICAgIHJldHVybiBzdHIgPT0gJycgfHwgc3RyID09IG51bGwgfHwgc3RyID09ICdudWxsJztcclxuICB9XHJcbiAgLy8g5Yik5pat5a2X56ym5Liy5piv5ZCm5LiN5Li656m6XHJcbiAgc3RhdGljIGlzTm90RW1wdHkoc3RyKSB7XHJcbiAgICByZXR1cm4gIXRoaXMuaXNFbXB0eShzdHIpO1xyXG4gIH1cclxuICAvLyDmta7ngrnmsYLlkoxcclxuICBzdGF0aWMgc3VtKG51bWJlcnMsIHRvRml4ZWQgPSAyKSB7XHJcbiAgICBsZXQgc3VtID0gMDtcclxuICAgIGZvciAoY29uc3Qgc3RyIG9mIG51bWJlcnMpIHtcclxuICAgICAgaWYgKCF0aGlzLmlzTnVtYmVyKHN0cikpIHtcclxuICAgICAgICByZXR1cm4gTmFOO1xyXG4gICAgICB9XHJcbiAgICAgIGNvbnN0IG51bSA9IHBhcnNlRmxvYXQoc3RyKTtcclxuICAgICAgaWYgKGlzTmFOKG51bSkpIHtcclxuICAgICAgICByZXR1cm4gTmFOO1xyXG4gICAgICB9XHJcbiAgICAgIHN1bSArPSBudW07XHJcbiAgICB9XHJcbiAgICByZXR1cm4gc3VtLnRvRml4ZWQodG9GaXhlZCk7XHJcbiAgfVxyXG4gIC8vIOaVsOWtl+WIpOaWrVxyXG4gIHN0YXRpYyBpc051bWJlcih2YWx1ZSkge1xyXG4gICAgY29uc3QgcGF0cm4gPSAvXlstK10/XFxkKyhcXC5cXGQrKT8kLztcclxuICAgIHJldHVybiBwYXRybi50ZXN0KHZhbHVlKTtcclxuICB9XHJcblxyXG4gIC8vIOaVsOWtl+WIpOaWrVxyXG4gIHN0YXRpYyBpc1Bvc2l0aXZlTnVtYmVyKHZhbHVlKSB7XHJcbiAgICBjb25zdCBwYXRybiA9IC9eWzEtOV1cXGQqJHxeXFwuXFxkKiR8XjBcXC5cXGQqJHxeWzEtOV1cXGQqXFwuXFxkKiR8XjAkLztcclxuICAgIHJldHVybiBwYXRybi50ZXN0KHZhbHVlKTtcclxuICB9XHJcbiAgLy8g5pWw57uE5Yik5patXHJcbiAgc3RhdGljIGlzQXJyYXkobykge1xyXG4gICAgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbChvKSA9PT0gJ1tvYmplY3QgQXJyYXldJztcclxuICB9XHJcbiAgLy8g5LqL5Lu26L2s5pel5pyfXHJcbiAgc3RhdGljIGNvbnZlcnRUaW1lc3RhcGVUb0RheSh0aW1lc3RhcGUpIHtcclxuICAgIHJldHVybiB0aW1lc3RhcGUuc3Vic3RyaW5nKDAsIHRpbWVzdGFwZS5pbmRleE9mKCcgJykpLnJlcGxhY2UoLy0vZywgJy4nKTtcclxuICB9XHJcblxyXG4gIC8vIOagvOW8j+WMluaXpeacn1xyXG4gIHN0YXRpYyBkYXRlRm9ybWF0ZShkYXRlLCBmbXQpIHtcclxuICAgIGNvbnN0IG8gPSB7XHJcbiAgICAgICdNKyc6IGRhdGUuZ2V0TW9udGgoKSArIDEsXHJcbiAgICAgICdkKyc6IGRhdGUuZ2V0RGF0ZSgpLFxyXG4gICAgICAnaCsnOiBkYXRlLmdldEhvdXJzKCksXHJcbiAgICAgICdtKyc6IGRhdGUuZ2V0TWludXRlcygpLFxyXG4gICAgICAncysnOiBkYXRlLmdldFNlY29uZHMoKSxcclxuICAgICAgJ3ErJzogTWF0aC5mbG9vcigoZGF0ZS5nZXRNb250aCgpICsgMykgLyAzKSxcclxuICAgICAgJ1MnOiBkYXRlLmdldE1pbGxpc2Vjb25kcygpXHJcbiAgICB9O1xyXG4gICAgaWYgKC8oeSspLy50ZXN0KGZtdCkpIGZtdCA9IGZtdC5yZXBsYWNlKFJlZ0V4cC4kMSwgKGRhdGUuZ2V0RnVsbFllYXIoKSArICcnKS5zdWJzdHIoNCAtIFJlZ0V4cC4kMS5sZW5ndGgpKTtcclxuICAgIGZvciAobGV0IGsgaW4gbykge1xyXG4gICAgICBpZiAobmV3IFJlZ0V4cCgnKCcgKyBrICsgJyknKS50ZXN0KGZtdCkpIGZtdCA9IGZtdC5yZXBsYWNlKFJlZ0V4cC4kMSwgKFJlZ0V4cC4kMS5sZW5ndGggPT0gMSkgPyAob1trXSkgOiAoKCcwMCcgKyBvW2tdKS5zdWJzdHIoKCcnICsgb1trXSkubGVuZ3RoKSkpO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIGZtdDtcclxuICB9XHJcbiAgLyoqXHJcbiAgICAqIOiOt+WPlui3neemu+W9k+WJjeaXpeacn+esrG7lpKnnmoTml6XmnJ9cclxuICAgICogQHBhcmFtIHtufSBkYXkgXHJcbiAgICAqL1xyXG4gIHN0YXRpYyBnZXREYXkoZGF5KSB7XHJcbiAgICB2YXIgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG4gICAgdmFyIHRhcmdldGRheV9taWxsaXNlY29uZHMgPSB0b2RheS5nZXRUaW1lKCkgKyAxMDAwICogNjAgKiA2MCAqIDI0ICogZGF5O1xyXG4gICAgdG9kYXkuc2V0VGltZSh0YXJnZXRkYXlfbWlsbGlzZWNvbmRzKTsgLy/ms6jmhI/vvIzov5nooYzmmK/lhbPplK7ku6PnoIFcclxuICAgIHZhciB0WWVhciA9IHRvZGF5LmdldEZ1bGxZZWFyKCk7XHJcbiAgICB2YXIgdE1vbnRoID0gdG9kYXkuZ2V0TW9udGgoKTtcclxuICAgIHZhciB0RGF0ZSA9IHRvZGF5LmdldERhdGUoKTtcclxuICAgIHRNb250aCA9IHRoaXMuZG9IYW5kbGVNb250aCh0TW9udGggKyAxKTtcclxuICAgIHREYXRlID0gdGhpcy5kb0hhbmRsZU1vbnRoKHREYXRlKTtcclxuICAgIHJldHVybiB0WWVhciArIFwiLVwiICsgdE1vbnRoICsgXCItXCIgKyB0RGF0ZTtcclxuICB9XHJcbiAgc3RhdGljIGRvSGFuZGxlTW9udGgobW9udGgpIHtcclxuICAgIHZhciBtID0gbW9udGg7XHJcbiAgICBpZiAobW9udGgudG9TdHJpbmcoKS5sZW5ndGggPT0gMSkge1xyXG4gICAgICBtID0gXCIwXCIgKyBtb250aDtcclxuICAgIH1cclxuICAgIHJldHVybiBtO1xyXG4gIH1cclxuICAvLyDmo4Dpqozouqvku73or4FcclxuICBzdGF0aWMgY2hlY2tJZENhcmQoSURDYXJkKSB7XHJcbiAgICB2YXIgaVN1bSA9IDA7XHJcbiAgICB2YXIgaW5mbyA9IFwiXCI7XHJcbiAgICBpZiAoIS9eXFxkezE3fShcXGR8eCkkL2kudGVzdChJRENhcmQpKVxyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIHN0YXR1czogZmFsc2UsXHJcbiAgICAgICAgbWVzc2FnZTogJ+i+k+WFpeeahOi6q+S7veivgemVv+W6puaIluagvOW8j+mUmeivryEnXHJcbiAgICAgIH07XHJcbiAgICBJRENhcmQgPSBJRENhcmQucmVwbGFjZSgveCQvaSwgXCJhXCIpO1xyXG4gICAgLy8gaWYgKGFyZWFJRFtwYXJzZUludChJRENhcmQuc3Vic3RyKDAsIDIpKV0gPT0gbnVsbClcclxuICAgIC8vICAgcmV0dXJuIHtcclxuICAgIC8vICAgICBzdGF0dXM6IGZhbHNlLFxyXG4gICAgLy8gICAgIG1lc3NhZ2U6ICfovpPlhaXnmoTouqvku73or4HmnInor68hJ1xyXG4gICAgLy8gICB9O1xyXG4gICAgdmFyIHNCaXJ0aGRheSA9IElEQ2FyZC5zdWJzdHIoNiwgNCkgKyBcIi1cIiArIE51bWJlcihJRENhcmQuc3Vic3RyKDEwLCAyKSkgKyBcIi1cIiArIE51bWJlcihJRENhcmQuc3Vic3RyKDEyLCAyKSk7XHJcbiAgICB2YXIgZCA9IG5ldyBEYXRlKHNCaXJ0aGRheS5yZXBsYWNlKC8tL2csIFwiL1wiKSk7XHJcbiAgICBpZiAoc0JpcnRoZGF5ICE9IChkLmdldEZ1bGxZZWFyKCkgKyBcIi1cIiArIChkLmdldE1vbnRoKCkgKyAxKSArIFwiLVwiICsgZC5nZXREYXRlKCkpKVxyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIHN0YXR1czogZmFsc2UsXHJcbiAgICAgICAgbWVzc2FnZTogJ+i+k+WFpeeahOi6q+S7veivgeacieivryEnXHJcbiAgICAgIH07XHJcbiAgICBmb3IgKHZhciBpID0gMTc7IGkgPj0gMDsgaS0tKVxyXG4gICAgICBpU3VtICs9IChNYXRoLnBvdygyLCBpKSAlIDExKSAqIHBhcnNlSW50KElEQ2FyZC5jaGFyQXQoMTcgLSBpKSwgMTEpO1xyXG4gICAgaWYgKGlTdW0gJSAxMSAhPSAxKVxyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIHN0YXR1czogZmFsc2UsXHJcbiAgICAgICAgbWVzc2FnZTogJ+i+k+WFpeeahOi6q+S7veivgeacieivryEnXHJcbiAgICAgIH07XHJcbiAgICAvL2FDaXR5W3BhcnNlSW50KHNJZC5zdWJzdHIoMCwyKSldK1wiLFwiK3NCaXJ0aGRheStcIixcIisoc0lkLnN1YnN0cigxNiwxKSUyP1wi55S3XCI6XCLlpbNcIik7Ly/mraTmrKHov5jlj6/ku6XliKTmlq3lh7rovpPlhaXnmoTouqvku73or4Hlj7fnmoTkurrmgKfliKtcclxuICAgIHJldHVybiB7XHJcbiAgICAgIHN0YXR1czogdHJ1ZSxcclxuICAgICAgbWVzc2FnZTogJ+agoemqjOaIkOWKn++8gSdcclxuICAgIH07XHJcbiAgfVxyXG4gIC8vIOi6q+S7veivgeiOt+WPluWHuueUn+W5tOaciOaXpVxyXG4gIHN0YXRpYyBnZXRCaXJ0aGRheUJ5SWRDYXJkKGlkQ2FyZCkge1xyXG4gICAgLy8g5qCh6aqM6Lqr5Lu96K+B5piv5ZCm5ZCI5rOVXHJcbiAgICBsZXQgX3IgPSB0aGlzLmNoZWNrSWRDYXJkKGlkQ2FyZClcclxuICAgIGlmKCEgX3Iuc3RhdHVzKXtcclxuICAgICAgcmV0dXJuIHtcclxuICAgICAgICAuLi5fclxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICB2YXIgYmlydGhTdHI7XHJcbiAgICBpZiAoMTUgPT0gaWRDYXJkLmxlbmd0aCkge1xyXG4gICAgICBiaXJ0aFN0ciA9IGlkQ2FyZC5jaGFyQXQoNikgKyBpZENhcmQuY2hhckF0KDcpO1xyXG4gICAgICBpZiAocGFyc2VJbnQoYmlydGhTdHIpIDwgMTApIHtcclxuICAgICAgICBiaXJ0aFN0ciA9ICcyMCcgKyBiaXJ0aFN0cjtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBiaXJ0aFN0ciA9ICcxOScgKyBiaXJ0aFN0cjtcclxuICAgICAgfVxyXG4gICAgICBiaXJ0aFN0ciA9IGJpcnRoU3RyICsgJy0nICsgaWRDYXJkLmNoYXJBdCg4KSArIGlkQ2FyZC5jaGFyQXQoOSkgKyAnLScgKyBpZENhcmQuY2hhckF0KDEwKSArIGlkQ2FyZC5jaGFyQXQoMTEpO1xyXG4gICAgfSBlbHNlIGlmICgxOCA9PSBpZENhcmQubGVuZ3RoKSB7XHJcbiAgICAgIGJpcnRoU3RyID0gaWRDYXJkLmNoYXJBdCg2KSArIGlkQ2FyZC5jaGFyQXQoNykgKyBpZENhcmQuY2hhckF0KDgpICsgaWRDYXJkLmNoYXJBdCg5KSArICctJyArIGlkQ2FyZC5jaGFyQXQoMTApICsgaWRDYXJkLmNoYXJBdCgxMSkgKyAnLScgKyBpZENhcmQuY2hhckF0KDEyKSArIGlkQ2FyZC5jaGFyQXQoMTMpO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIGJpcnRoU3RyO1xyXG4gIH1cclxuICBzdGF0aWMgZ2V0U2V4QnlJZENhcmQgKGlkQ2FyZCkge1xyXG4gICAgaWYoaWRDYXJkLmxlbmd0aCA9PSAxNSkge1xyXG4gICAgICByZXR1cm4gaWRDYXJkLnN1YnN0cmluZygxNCwgMTUpICUgMjtcclxuICAgIH0gZWxzZSBpZihpZENhcmQubGVuZ3RoID09IDE4KSB7XHJcbiAgICAgIHJldHVybiBpZENhcmQuc3Vic3RyaW5nKDE0LCAxNykgJSAyO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgLy/kuI3mmK8xNeaIluiAhTE4LG51bGxcclxuICAgICAgcmV0dXJuICcnO1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG5cclxuIl19