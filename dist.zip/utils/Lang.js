"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Lang = function () {
  function Lang() {
    _classCallCheck(this, Lang);
  }

  _createClass(Lang, null, [{
    key: "previewImage",
    value: function previewImage(current, urls) {
      wx.previewImage({
        current: current, // 当前显示图片的http链接
        urls: urls // 需要预览的图片http链接列表
      });
    }
  }, {
    key: "downImg",
    value: function downImg(url) {
      var callback = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;

      console.log(url);
      //图片保存到本地
      wx.saveImageToPhotosAlbum({
        filePath: url,
        success: function () {
          var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(data) {
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    if (callback) callback(data);

                  case 1:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));

          function success(_x2) {
            return _ref.apply(this, arguments);
          }

          return success;
        }(),
        fail: function fail(err) {
          console.log(err);
          if (err.errMsg === "saveImageToPhotosAlbum:fail auth deny") {
            console.log("当初用户拒绝，再次发起授权");
            wx.openSetting({
              success: function success(settingdata) {
                console.log(settingdata);
                if (settingdata.authSetting['scope.writePhotosAlbum']) {
                  console.log('获取权限成功，给出再次点击图片保存到相册的提示。');
                } else {
                  console.log('获取权限失败，给出不给权限就无法正常使用的提示');
                }
              }
            });
          }
        },
        complete: function complete(res) {
          console.log(res);
        }
      });
    }
    // 判断字符串是否为空

  }, {
    key: "isEmpty",
    value: function isEmpty(str) {
      return str == '' || str == null || str == 'null';
    }
    // 判断字符串是否不为空

  }, {
    key: "isNotEmpty",
    value: function isNotEmpty(str) {
      return !this.isEmpty(str);
    }
    // 浮点求和

  }, {
    key: "sum",
    value: function sum(numbers) {
      var toFixed = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 2;

      var sum = 0;
      var _iteratorNormalCompletion = true;
      var _didIteratorError = false;
      var _iteratorError = undefined;

      try {
        for (var _iterator = numbers[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
          var str = _step.value;

          if (!this.isNumber(str)) {
            return NaN;
          }
          var num = parseFloat(str);
          if (isNaN(num)) {
            return NaN;
          }
          sum += num;
        }
      } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion && _iterator.return) {
            _iterator.return();
          }
        } finally {
          if (_didIteratorError) {
            throw _iteratorError;
          }
        }
      }

      return sum.toFixed(toFixed);
    }
    // 数字判断

  }, {
    key: "isNumber",
    value: function isNumber(value) {
      var patrn = /^[-+]?\d+(\.\d+)?$/;
      return patrn.test(value);
    }

    // 数字判断

  }, {
    key: "isPositiveNumber",
    value: function isPositiveNumber(value) {
      var patrn = /^[1-9]\d*$|^\.\d*$|^0\.\d*$|^[1-9]\d*\.\d*$|^0$/;
      return patrn.test(value);
    }
    // 数组判断

  }, {
    key: "isArray",
    value: function isArray(o) {
      return Object.prototype.toString.call(o) === '[object Array]';
    }
    // 事件转日期

  }, {
    key: "convertTimestapeToDay",
    value: function convertTimestapeToDay(timestape) {
      return timestape.substring(0, timestape.indexOf(' ')).replace(/-/g, '.');
    }

    // 格式化日期

  }, {
    key: "dateFormate",
    value: function dateFormate(date, fmt) {
      var o = {
        'M+': date.getMonth() + 1,
        'd+': date.getDate(),
        'h+': date.getHours(),
        'm+': date.getMinutes(),
        's+': date.getSeconds(),
        'q+': Math.floor((date.getMonth() + 3) / 3),
        'S': date.getMilliseconds()
      };
      if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length));
      for (var k in o) {
        if (new RegExp('(' + k + ')').test(fmt)) fmt = fmt.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ('00' + o[k]).substr(('' + o[k]).length));
      }
      return fmt;
    }
    /**
      * 获取距离当前日期第n天的日期
      * @param {n} day 
      */

  }, {
    key: "getDay",
    value: function getDay(day) {
      var today = new Date();
      var targetday_milliseconds = today.getTime() + 1000 * 60 * 60 * 24 * day;
      today.setTime(targetday_milliseconds); //注意，这行是关键代码
      var tYear = today.getFullYear();
      var tMonth = today.getMonth();
      var tDate = today.getDate();
      tMonth = this.doHandleMonth(tMonth + 1);
      tDate = this.doHandleMonth(tDate);
      return tYear + "-" + tMonth + "-" + tDate;
    }
  }, {
    key: "doHandleMonth",
    value: function doHandleMonth(month) {
      var m = month;
      if (month.toString().length == 1) {
        m = "0" + month;
      }
      return m;
    }
    // 检验身份证

  }, {
    key: "checkIdCard",
    value: function checkIdCard(IDCard) {
      var iSum = 0;
      var info = "";
      if (!/^\d{17}(\d|x)$/i.test(IDCard)) return {
        status: false,
        message: '输入的身份证长度或格式错误!'
      };
      IDCard = IDCard.replace(/x$/i, "a");
      // if (areaID[parseInt(IDCard.substr(0, 2))] == null)
      //   return {
      //     status: false,
      //     message: '输入的身份证有误!'
      //   };
      var sBirthday = IDCard.substr(6, 4) + "-" + Number(IDCard.substr(10, 2)) + "-" + Number(IDCard.substr(12, 2));
      var d = new Date(sBirthday.replace(/-/g, "/"));
      if (sBirthday != d.getFullYear() + "-" + (d.getMonth() + 1) + "-" + d.getDate()) return {
        status: false,
        message: '输入的身份证有误!'
      };
      for (var i = 17; i >= 0; i--) {
        iSum += Math.pow(2, i) % 11 * parseInt(IDCard.charAt(17 - i), 11);
      }if (iSum % 11 != 1) return {
        status: false,
        message: '输入的身份证有误!'
      };
      //aCity[parseInt(sId.substr(0,2))]+","+sBirthday+","+(sId.substr(16,1)%2?"男":"女");//此次还可以判断出输入的身份证号的人性别
      return {
        status: true,
        message: '校验成功！'
      };
    }
    // 身份证获取出生年月日

  }, {
    key: "getBirthdayByIdCard",
    value: function getBirthdayByIdCard(idCard) {
      // 校验身份证是否合法
      var _r = this.checkIdCard(idCard);
      if (!_r.status) {
        return _extends({}, _r);
      }
      var birthStr;
      if (15 == idCard.length) {
        birthStr = idCard.charAt(6) + idCard.charAt(7);
        if (parseInt(birthStr) < 10) {
          birthStr = '20' + birthStr;
        } else {
          birthStr = '19' + birthStr;
        }
        birthStr = birthStr + '-' + idCard.charAt(8) + idCard.charAt(9) + '-' + idCard.charAt(10) + idCard.charAt(11);
      } else if (18 == idCard.length) {
        birthStr = idCard.charAt(6) + idCard.charAt(7) + idCard.charAt(8) + idCard.charAt(9) + '-' + idCard.charAt(10) + idCard.charAt(11) + '-' + idCard.charAt(12) + idCard.charAt(13);
      }
      return birthStr;
    }
  }, {
    key: "getSexByIdCard",
    value: function getSexByIdCard(idCard) {
      if (idCard.length == 15) {
        return idCard.substring(14, 15) % 2;
      } else if (idCard.length == 18) {
        return idCard.substring(14, 17) % 2;
      } else {
        //不是15或者18,null
        return '';
      }
    }
  }]);

  return Lang;
}();

exports.default = Lang;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkxhbmcuanMiXSwibmFtZXMiOlsiTGFuZyIsImN1cnJlbnQiLCJ1cmxzIiwid3giLCJwcmV2aWV3SW1hZ2UiLCJ1cmwiLCJjYWxsYmFjayIsImNvbnNvbGUiLCJsb2ciLCJzYXZlSW1hZ2VUb1Bob3Rvc0FsYnVtIiwiZmlsZVBhdGgiLCJzdWNjZXNzIiwiZGF0YSIsImZhaWwiLCJlcnIiLCJlcnJNc2ciLCJvcGVuU2V0dGluZyIsInNldHRpbmdkYXRhIiwiYXV0aFNldHRpbmciLCJjb21wbGV0ZSIsInJlcyIsInN0ciIsImlzRW1wdHkiLCJudW1iZXJzIiwidG9GaXhlZCIsInN1bSIsImlzTnVtYmVyIiwiTmFOIiwibnVtIiwicGFyc2VGbG9hdCIsImlzTmFOIiwidmFsdWUiLCJwYXRybiIsInRlc3QiLCJvIiwiT2JqZWN0IiwicHJvdG90eXBlIiwidG9TdHJpbmciLCJjYWxsIiwidGltZXN0YXBlIiwic3Vic3RyaW5nIiwiaW5kZXhPZiIsInJlcGxhY2UiLCJkYXRlIiwiZm10IiwiZ2V0TW9udGgiLCJnZXREYXRlIiwiZ2V0SG91cnMiLCJnZXRNaW51dGVzIiwiZ2V0U2Vjb25kcyIsIk1hdGgiLCJmbG9vciIsImdldE1pbGxpc2Vjb25kcyIsIlJlZ0V4cCIsIiQxIiwiZ2V0RnVsbFllYXIiLCJzdWJzdHIiLCJsZW5ndGgiLCJrIiwiZGF5IiwidG9kYXkiLCJEYXRlIiwidGFyZ2V0ZGF5X21pbGxpc2Vjb25kcyIsImdldFRpbWUiLCJzZXRUaW1lIiwidFllYXIiLCJ0TW9udGgiLCJ0RGF0ZSIsImRvSGFuZGxlTW9udGgiLCJtb250aCIsIm0iLCJJRENhcmQiLCJpU3VtIiwiaW5mbyIsInN0YXR1cyIsIm1lc3NhZ2UiLCJzQmlydGhkYXkiLCJOdW1iZXIiLCJkIiwiaSIsInBvdyIsInBhcnNlSW50IiwiY2hhckF0IiwiaWRDYXJkIiwiX3IiLCJjaGVja0lkQ2FyZCIsImJpcnRoU3RyIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7OztJQUFxQkEsSTs7Ozs7OztpQ0FDQ0MsTyxFQUFRQyxJLEVBQU07QUFDaENDLFNBQUdDLFlBQUgsQ0FBZ0I7QUFDZEgsd0JBRGMsRUFDTDtBQUNUQyxrQkFGYyxDQUVUO0FBRlMsT0FBaEI7QUFJRDs7OzRCQUNjRyxHLEVBQXNCO0FBQUEsVUFBakJDLFFBQWlCLHVFQUFOLElBQU07O0FBQ25DQyxjQUFRQyxHQUFSLENBQVlILEdBQVo7QUFDQTtBQUNBRixTQUFHTSxzQkFBSCxDQUEwQjtBQUN4QkMsa0JBQVVMLEdBRGM7QUFFeEJNO0FBQUEsNkVBQVMsaUJBQWdCQyxJQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ1Asd0JBQUlOLFFBQUosRUFBY0EsU0FBU00sSUFBVDs7QUFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFUOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBLFdBRndCO0FBS3hCQyxjQUFNLGNBQVVDLEdBQVYsRUFBZTtBQUNuQlAsa0JBQVFDLEdBQVIsQ0FBWU0sR0FBWjtBQUNBLGNBQUlBLElBQUlDLE1BQUosS0FBZSx1Q0FBbkIsRUFBNEQ7QUFDMURSLG9CQUFRQyxHQUFSLENBQVksZUFBWjtBQUNBTCxlQUFHYSxXQUFILENBQWU7QUFDYkwscUJBRGEsbUJBQ0xNLFdBREssRUFDUTtBQUNuQlYsd0JBQVFDLEdBQVIsQ0FBWVMsV0FBWjtBQUNBLG9CQUFJQSxZQUFZQyxXQUFaLENBQXdCLHdCQUF4QixDQUFKLEVBQXVEO0FBQ3JEWCwwQkFBUUMsR0FBUixDQUFZLDBCQUFaO0FBQ0QsaUJBRkQsTUFFTztBQUNMRCwwQkFBUUMsR0FBUixDQUFZLHlCQUFaO0FBQ0Q7QUFDRjtBQVJZLGFBQWY7QUFVRDtBQUNGLFNBcEJ1QjtBQXFCeEJXLGdCQXJCd0Isb0JBcUJmQyxHQXJCZSxFQXFCVjtBQUNaYixrQkFBUUMsR0FBUixDQUFZWSxHQUFaO0FBQ0Q7QUF2QnVCLE9BQTFCO0FBeUJEO0FBQ0Q7Ozs7NEJBQ2VDLEcsRUFBSztBQUNsQixhQUFPQSxPQUFPLEVBQVAsSUFBYUEsT0FBTyxJQUFwQixJQUE0QkEsT0FBTyxNQUExQztBQUNEO0FBQ0Q7Ozs7K0JBQ2tCQSxHLEVBQUs7QUFDckIsYUFBTyxDQUFDLEtBQUtDLE9BQUwsQ0FBYUQsR0FBYixDQUFSO0FBQ0Q7QUFDRDs7Ozt3QkFDV0UsTyxFQUFzQjtBQUFBLFVBQWJDLE9BQWEsdUVBQUgsQ0FBRzs7QUFDL0IsVUFBSUMsTUFBTSxDQUFWO0FBRCtCO0FBQUE7QUFBQTs7QUFBQTtBQUUvQiw2QkFBa0JGLE9BQWxCLDhIQUEyQjtBQUFBLGNBQWhCRixHQUFnQjs7QUFDekIsY0FBSSxDQUFDLEtBQUtLLFFBQUwsQ0FBY0wsR0FBZCxDQUFMLEVBQXlCO0FBQ3ZCLG1CQUFPTSxHQUFQO0FBQ0Q7QUFDRCxjQUFNQyxNQUFNQyxXQUFXUixHQUFYLENBQVo7QUFDQSxjQUFJUyxNQUFNRixHQUFOLENBQUosRUFBZ0I7QUFDZCxtQkFBT0QsR0FBUDtBQUNEO0FBQ0RGLGlCQUFPRyxHQUFQO0FBQ0Q7QUFYOEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFZL0IsYUFBT0gsSUFBSUQsT0FBSixDQUFZQSxPQUFaLENBQVA7QUFDRDtBQUNEOzs7OzZCQUNnQk8sSyxFQUFPO0FBQ3JCLFVBQU1DLFFBQVEsb0JBQWQ7QUFDQSxhQUFPQSxNQUFNQyxJQUFOLENBQVdGLEtBQVgsQ0FBUDtBQUNEOztBQUVEOzs7O3FDQUN3QkEsSyxFQUFPO0FBQzdCLFVBQU1DLFFBQVEsaURBQWQ7QUFDQSxhQUFPQSxNQUFNQyxJQUFOLENBQVdGLEtBQVgsQ0FBUDtBQUNEO0FBQ0Q7Ozs7NEJBQ2VHLEMsRUFBRztBQUNoQixhQUFPQyxPQUFPQyxTQUFQLENBQWlCQyxRQUFqQixDQUEwQkMsSUFBMUIsQ0FBK0JKLENBQS9CLE1BQXNDLGdCQUE3QztBQUNEO0FBQ0Q7Ozs7MENBQzZCSyxTLEVBQVc7QUFDdEMsYUFBT0EsVUFBVUMsU0FBVixDQUFvQixDQUFwQixFQUF1QkQsVUFBVUUsT0FBVixDQUFrQixHQUFsQixDQUF2QixFQUErQ0MsT0FBL0MsQ0FBdUQsSUFBdkQsRUFBNkQsR0FBN0QsQ0FBUDtBQUNEOztBQUVEOzs7O2dDQUNtQkMsSSxFQUFNQyxHLEVBQUs7QUFDNUIsVUFBTVYsSUFBSTtBQUNSLGNBQU1TLEtBQUtFLFFBQUwsS0FBa0IsQ0FEaEI7QUFFUixjQUFNRixLQUFLRyxPQUFMLEVBRkU7QUFHUixjQUFNSCxLQUFLSSxRQUFMLEVBSEU7QUFJUixjQUFNSixLQUFLSyxVQUFMLEVBSkU7QUFLUixjQUFNTCxLQUFLTSxVQUFMLEVBTEU7QUFNUixjQUFNQyxLQUFLQyxLQUFMLENBQVcsQ0FBQ1IsS0FBS0UsUUFBTCxLQUFrQixDQUFuQixJQUF3QixDQUFuQyxDQU5FO0FBT1IsYUFBS0YsS0FBS1MsZUFBTDtBQVBHLE9BQVY7QUFTQSxVQUFJLE9BQU9uQixJQUFQLENBQVlXLEdBQVosQ0FBSixFQUFzQkEsTUFBTUEsSUFBSUYsT0FBSixDQUFZVyxPQUFPQyxFQUFuQixFQUF1QixDQUFDWCxLQUFLWSxXQUFMLEtBQXFCLEVBQXRCLEVBQTBCQyxNQUExQixDQUFpQyxJQUFJSCxPQUFPQyxFQUFQLENBQVVHLE1BQS9DLENBQXZCLENBQU47QUFDdEIsV0FBSyxJQUFJQyxDQUFULElBQWN4QixDQUFkLEVBQWlCO0FBQ2YsWUFBSSxJQUFJbUIsTUFBSixDQUFXLE1BQU1LLENBQU4sR0FBVSxHQUFyQixFQUEwQnpCLElBQTFCLENBQStCVyxHQUEvQixDQUFKLEVBQXlDQSxNQUFNQSxJQUFJRixPQUFKLENBQVlXLE9BQU9DLEVBQW5CLEVBQXdCRCxPQUFPQyxFQUFQLENBQVVHLE1BQVYsSUFBb0IsQ0FBckIsR0FBMkJ2QixFQUFFd0IsQ0FBRixDQUEzQixHQUFvQyxDQUFDLE9BQU94QixFQUFFd0IsQ0FBRixDQUFSLEVBQWNGLE1BQWQsQ0FBcUIsQ0FBQyxLQUFLdEIsRUFBRXdCLENBQUYsQ0FBTixFQUFZRCxNQUFqQyxDQUEzRCxDQUFOO0FBQzFDO0FBQ0QsYUFBT2IsR0FBUDtBQUNEO0FBQ0Q7Ozs7Ozs7MkJBSWNlLEcsRUFBSztBQUNqQixVQUFJQyxRQUFRLElBQUlDLElBQUosRUFBWjtBQUNBLFVBQUlDLHlCQUF5QkYsTUFBTUcsT0FBTixLQUFrQixPQUFPLEVBQVAsR0FBWSxFQUFaLEdBQWlCLEVBQWpCLEdBQXNCSixHQUFyRTtBQUNBQyxZQUFNSSxPQUFOLENBQWNGLHNCQUFkLEVBSGlCLENBR3NCO0FBQ3ZDLFVBQUlHLFFBQVFMLE1BQU1MLFdBQU4sRUFBWjtBQUNBLFVBQUlXLFNBQVNOLE1BQU1mLFFBQU4sRUFBYjtBQUNBLFVBQUlzQixRQUFRUCxNQUFNZCxPQUFOLEVBQVo7QUFDQW9CLGVBQVMsS0FBS0UsYUFBTCxDQUFtQkYsU0FBUyxDQUE1QixDQUFUO0FBQ0FDLGNBQVEsS0FBS0MsYUFBTCxDQUFtQkQsS0FBbkIsQ0FBUjtBQUNBLGFBQU9GLFFBQVEsR0FBUixHQUFjQyxNQUFkLEdBQXVCLEdBQXZCLEdBQTZCQyxLQUFwQztBQUNEOzs7a0NBQ29CRSxLLEVBQU87QUFDMUIsVUFBSUMsSUFBSUQsS0FBUjtBQUNBLFVBQUlBLE1BQU1oQyxRQUFOLEdBQWlCb0IsTUFBakIsSUFBMkIsQ0FBL0IsRUFBa0M7QUFDaENhLFlBQUksTUFBTUQsS0FBVjtBQUNEO0FBQ0QsYUFBT0MsQ0FBUDtBQUNEO0FBQ0Q7Ozs7Z0NBQ21CQyxNLEVBQVE7QUFDekIsVUFBSUMsT0FBTyxDQUFYO0FBQ0EsVUFBSUMsT0FBTyxFQUFYO0FBQ0EsVUFBSSxDQUFDLGtCQUFrQnhDLElBQWxCLENBQXVCc0MsTUFBdkIsQ0FBTCxFQUNFLE9BQU87QUFDTEcsZ0JBQVEsS0FESDtBQUVMQyxpQkFBUztBQUZKLE9BQVA7QUFJRkosZUFBU0EsT0FBTzdCLE9BQVAsQ0FBZSxLQUFmLEVBQXNCLEdBQXRCLENBQVQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsVUFBSWtDLFlBQVlMLE9BQU9mLE1BQVAsQ0FBYyxDQUFkLEVBQWlCLENBQWpCLElBQXNCLEdBQXRCLEdBQTRCcUIsT0FBT04sT0FBT2YsTUFBUCxDQUFjLEVBQWQsRUFBa0IsQ0FBbEIsQ0FBUCxDQUE1QixHQUEyRCxHQUEzRCxHQUFpRXFCLE9BQU9OLE9BQU9mLE1BQVAsQ0FBYyxFQUFkLEVBQWtCLENBQWxCLENBQVAsQ0FBakY7QUFDQSxVQUFJc0IsSUFBSSxJQUFJakIsSUFBSixDQUFTZSxVQUFVbEMsT0FBVixDQUFrQixJQUFsQixFQUF3QixHQUF4QixDQUFULENBQVI7QUFDQSxVQUFJa0MsYUFBY0UsRUFBRXZCLFdBQUYsS0FBa0IsR0FBbEIsSUFBeUJ1QixFQUFFakMsUUFBRixLQUFlLENBQXhDLElBQTZDLEdBQTdDLEdBQW1EaUMsRUFBRWhDLE9BQUYsRUFBckUsRUFDRSxPQUFPO0FBQ0w0QixnQkFBUSxLQURIO0FBRUxDLGlCQUFTO0FBRkosT0FBUDtBQUlGLFdBQUssSUFBSUksSUFBSSxFQUFiLEVBQWlCQSxLQUFLLENBQXRCLEVBQXlCQSxHQUF6QjtBQUNFUCxnQkFBU3RCLEtBQUs4QixHQUFMLENBQVMsQ0FBVCxFQUFZRCxDQUFaLElBQWlCLEVBQWxCLEdBQXdCRSxTQUFTVixPQUFPVyxNQUFQLENBQWMsS0FBS0gsQ0FBbkIsQ0FBVCxFQUFnQyxFQUFoQyxDQUFoQztBQURGLE9BRUEsSUFBSVAsT0FBTyxFQUFQLElBQWEsQ0FBakIsRUFDRSxPQUFPO0FBQ0xFLGdCQUFRLEtBREg7QUFFTEMsaUJBQVM7QUFGSixPQUFQO0FBSUY7QUFDQSxhQUFPO0FBQ0xELGdCQUFRLElBREg7QUFFTEMsaUJBQVM7QUFGSixPQUFQO0FBSUQ7QUFDRDs7Ozt3Q0FDMkJRLE0sRUFBUTtBQUNqQztBQUNBLFVBQUlDLEtBQUssS0FBS0MsV0FBTCxDQUFpQkYsTUFBakIsQ0FBVDtBQUNBLFVBQUksQ0FBQ0MsR0FBR1YsTUFBUixFQUFnQjtBQUNkLDRCQUNLVSxFQURMO0FBR0Q7QUFDRCxVQUFJRSxRQUFKO0FBQ0EsVUFBSSxNQUFNSCxPQUFPMUIsTUFBakIsRUFBeUI7QUFDdkI2QixtQkFBV0gsT0FBT0QsTUFBUCxDQUFjLENBQWQsSUFBbUJDLE9BQU9ELE1BQVAsQ0FBYyxDQUFkLENBQTlCO0FBQ0EsWUFBSUQsU0FBU0ssUUFBVCxJQUFxQixFQUF6QixFQUE2QjtBQUMzQkEscUJBQVcsT0FBT0EsUUFBbEI7QUFDRCxTQUZELE1BRU87QUFDTEEscUJBQVcsT0FBT0EsUUFBbEI7QUFDRDtBQUNEQSxtQkFBV0EsV0FBVyxHQUFYLEdBQWlCSCxPQUFPRCxNQUFQLENBQWMsQ0FBZCxDQUFqQixHQUFvQ0MsT0FBT0QsTUFBUCxDQUFjLENBQWQsQ0FBcEMsR0FBdUQsR0FBdkQsR0FBNkRDLE9BQU9ELE1BQVAsQ0FBYyxFQUFkLENBQTdELEdBQWlGQyxPQUFPRCxNQUFQLENBQWMsRUFBZCxDQUE1RjtBQUNELE9BUkQsTUFRTyxJQUFJLE1BQU1DLE9BQU8xQixNQUFqQixFQUF5QjtBQUM5QjZCLG1CQUFXSCxPQUFPRCxNQUFQLENBQWMsQ0FBZCxJQUFtQkMsT0FBT0QsTUFBUCxDQUFjLENBQWQsQ0FBbkIsR0FBc0NDLE9BQU9ELE1BQVAsQ0FBYyxDQUFkLENBQXRDLEdBQXlEQyxPQUFPRCxNQUFQLENBQWMsQ0FBZCxDQUF6RCxHQUE0RSxHQUE1RSxHQUFrRkMsT0FBT0QsTUFBUCxDQUFjLEVBQWQsQ0FBbEYsR0FBc0dDLE9BQU9ELE1BQVAsQ0FBYyxFQUFkLENBQXRHLEdBQTBILEdBQTFILEdBQWdJQyxPQUFPRCxNQUFQLENBQWMsRUFBZCxDQUFoSSxHQUFvSkMsT0FBT0QsTUFBUCxDQUFjLEVBQWQsQ0FBL0o7QUFDRDtBQUNELGFBQU9JLFFBQVA7QUFDRDs7O21DQUNxQkgsTSxFQUFRO0FBQzVCLFVBQUlBLE9BQU8xQixNQUFQLElBQWlCLEVBQXJCLEVBQXlCO0FBQ3ZCLGVBQU8wQixPQUFPM0MsU0FBUCxDQUFpQixFQUFqQixFQUFxQixFQUFyQixJQUEyQixDQUFsQztBQUNELE9BRkQsTUFFTyxJQUFJMkMsT0FBTzFCLE1BQVAsSUFBaUIsRUFBckIsRUFBeUI7QUFDOUIsZUFBTzBCLE9BQU8zQyxTQUFQLENBQWlCLEVBQWpCLEVBQXFCLEVBQXJCLElBQTJCLENBQWxDO0FBQ0QsT0FGTSxNQUVBO0FBQ0w7QUFDQSxlQUFPLEVBQVA7QUFDRDtBQUNGOzs7Ozs7a0JBekxrQnhDLEkiLCJmaWxlIjoiTGFuZy5qcyIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBkZWZhdWx0IGNsYXNzIExhbmcge1xyXG4gIHN0YXRpYyBwcmV2aWV3SW1hZ2UoY3VycmVudCx1cmxzKSB7XHJcbiAgICB3eC5wcmV2aWV3SW1hZ2Uoe1xyXG4gICAgICBjdXJyZW50LCAvLyDlvZPliY3mmL7npLrlm77niYfnmoRodHRw6ZO+5o6lXHJcbiAgICAgIHVybHMgLy8g6ZyA6KaB6aKE6KeI55qE5Zu+54mHaHR0cOmTvuaOpeWIl+ihqFxyXG4gICAgfSlcclxuICB9XHJcbiAgc3RhdGljIGRvd25JbWcodXJsLCBjYWxsYmFjayA9IG51bGwpIHtcclxuICAgIGNvbnNvbGUubG9nKHVybClcclxuICAgIC8v5Zu+54mH5L+d5a2Y5Yiw5pys5ZywXHJcbiAgICB3eC5zYXZlSW1hZ2VUb1Bob3Rvc0FsYnVtKHtcclxuICAgICAgZmlsZVBhdGg6IHVybCxcclxuICAgICAgc3VjY2VzczogYXN5bmMgZnVuY3Rpb24gKGRhdGEpIHtcclxuICAgICAgICBpZiAoY2FsbGJhY2spIGNhbGxiYWNrKGRhdGEpXHJcbiAgICAgIH0sXHJcbiAgICAgIGZhaWw6IGZ1bmN0aW9uIChlcnIpIHtcclxuICAgICAgICBjb25zb2xlLmxvZyhlcnIpO1xyXG4gICAgICAgIGlmIChlcnIuZXJyTXNnID09PSBcInNhdmVJbWFnZVRvUGhvdG9zQWxidW06ZmFpbCBhdXRoIGRlbnlcIikge1xyXG4gICAgICAgICAgY29uc29sZS5sb2coXCLlvZPliJ3nlKjmiLfmi5Lnu53vvIzlho3mrKHlj5HotbfmjojmnYNcIilcclxuICAgICAgICAgIHd4Lm9wZW5TZXR0aW5nKHtcclxuICAgICAgICAgICAgc3VjY2VzcyhzZXR0aW5nZGF0YSkge1xyXG4gICAgICAgICAgICAgIGNvbnNvbGUubG9nKHNldHRpbmdkYXRhKVxyXG4gICAgICAgICAgICAgIGlmIChzZXR0aW5nZGF0YS5hdXRoU2V0dGluZ1snc2NvcGUud3JpdGVQaG90b3NBbGJ1bSddKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygn6I635Y+W5p2D6ZmQ5oiQ5Yqf77yM57uZ5Ye65YaN5qyh54K55Ye75Zu+54mH5L+d5a2Y5Yiw55u45YaM55qE5o+Q56S644CCJylcclxuICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ+iOt+WPluadg+mZkOWksei0pe+8jOe7meWHuuS4jee7meadg+mZkOWwseaXoOazleato+W4uOS9v+eUqOeahOaPkOekuicpXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9KVxyXG4gICAgICAgIH1cclxuICAgICAgfSxcclxuICAgICAgY29tcGxldGUocmVzKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2cocmVzKTtcclxuICAgICAgfVxyXG4gICAgfSlcclxuICB9XHJcbiAgLy8g5Yik5pat5a2X56ym5Liy5piv5ZCm5Li656m6XHJcbiAgc3RhdGljIGlzRW1wdHkoc3RyKSB7XHJcbiAgICByZXR1cm4gc3RyID09ICcnIHx8IHN0ciA9PSBudWxsIHx8IHN0ciA9PSAnbnVsbCc7XHJcbiAgfVxyXG4gIC8vIOWIpOaWreWtl+espuS4suaYr+WQpuS4jeS4uuepulxyXG4gIHN0YXRpYyBpc05vdEVtcHR5KHN0cikge1xyXG4gICAgcmV0dXJuICF0aGlzLmlzRW1wdHkoc3RyKTtcclxuICB9XHJcbiAgLy8g5rWu54K55rGC5ZKMXHJcbiAgc3RhdGljIHN1bShudW1iZXJzLCB0b0ZpeGVkID0gMikge1xyXG4gICAgbGV0IHN1bSA9IDA7XHJcbiAgICBmb3IgKGNvbnN0IHN0ciBvZiBudW1iZXJzKSB7XHJcbiAgICAgIGlmICghdGhpcy5pc051bWJlcihzdHIpKSB7XHJcbiAgICAgICAgcmV0dXJuIE5hTjtcclxuICAgICAgfVxyXG4gICAgICBjb25zdCBudW0gPSBwYXJzZUZsb2F0KHN0cik7XHJcbiAgICAgIGlmIChpc05hTihudW0pKSB7XHJcbiAgICAgICAgcmV0dXJuIE5hTjtcclxuICAgICAgfVxyXG4gICAgICBzdW0gKz0gbnVtO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIHN1bS50b0ZpeGVkKHRvRml4ZWQpO1xyXG4gIH1cclxuICAvLyDmlbDlrZfliKTmlq1cclxuICBzdGF0aWMgaXNOdW1iZXIodmFsdWUpIHtcclxuICAgIGNvbnN0IHBhdHJuID0gL15bLStdP1xcZCsoXFwuXFxkKyk/JC87XHJcbiAgICByZXR1cm4gcGF0cm4udGVzdCh2YWx1ZSk7XHJcbiAgfVxyXG5cclxuICAvLyDmlbDlrZfliKTmlq1cclxuICBzdGF0aWMgaXNQb3NpdGl2ZU51bWJlcih2YWx1ZSkge1xyXG4gICAgY29uc3QgcGF0cm4gPSAvXlsxLTldXFxkKiR8XlxcLlxcZCokfF4wXFwuXFxkKiR8XlsxLTldXFxkKlxcLlxcZCokfF4wJC87XHJcbiAgICByZXR1cm4gcGF0cm4udGVzdCh2YWx1ZSk7XHJcbiAgfVxyXG4gIC8vIOaVsOe7hOWIpOaWrVxyXG4gIHN0YXRpYyBpc0FycmF5KG8pIHtcclxuICAgIHJldHVybiBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwobykgPT09ICdbb2JqZWN0IEFycmF5XSc7XHJcbiAgfVxyXG4gIC8vIOS6i+S7tui9rOaXpeacn1xyXG4gIHN0YXRpYyBjb252ZXJ0VGltZXN0YXBlVG9EYXkodGltZXN0YXBlKSB7XHJcbiAgICByZXR1cm4gdGltZXN0YXBlLnN1YnN0cmluZygwLCB0aW1lc3RhcGUuaW5kZXhPZignICcpKS5yZXBsYWNlKC8tL2csICcuJyk7XHJcbiAgfVxyXG5cclxuICAvLyDmoLzlvI/ljJbml6XmnJ9cclxuICBzdGF0aWMgZGF0ZUZvcm1hdGUoZGF0ZSwgZm10KSB7XHJcbiAgICBjb25zdCBvID0ge1xyXG4gICAgICAnTSsnOiBkYXRlLmdldE1vbnRoKCkgKyAxLFxyXG4gICAgICAnZCsnOiBkYXRlLmdldERhdGUoKSxcclxuICAgICAgJ2grJzogZGF0ZS5nZXRIb3VycygpLFxyXG4gICAgICAnbSsnOiBkYXRlLmdldE1pbnV0ZXMoKSxcclxuICAgICAgJ3MrJzogZGF0ZS5nZXRTZWNvbmRzKCksXHJcbiAgICAgICdxKyc6IE1hdGguZmxvb3IoKGRhdGUuZ2V0TW9udGgoKSArIDMpIC8gMyksXHJcbiAgICAgICdTJzogZGF0ZS5nZXRNaWxsaXNlY29uZHMoKVxyXG4gICAgfTtcclxuICAgIGlmICgvKHkrKS8udGVzdChmbXQpKSBmbXQgPSBmbXQucmVwbGFjZShSZWdFeHAuJDEsIChkYXRlLmdldEZ1bGxZZWFyKCkgKyAnJykuc3Vic3RyKDQgLSBSZWdFeHAuJDEubGVuZ3RoKSk7XHJcbiAgICBmb3IgKGxldCBrIGluIG8pIHtcclxuICAgICAgaWYgKG5ldyBSZWdFeHAoJygnICsgayArICcpJykudGVzdChmbXQpKSBmbXQgPSBmbXQucmVwbGFjZShSZWdFeHAuJDEsIChSZWdFeHAuJDEubGVuZ3RoID09IDEpID8gKG9ba10pIDogKCgnMDAnICsgb1trXSkuc3Vic3RyKCgnJyArIG9ba10pLmxlbmd0aCkpKTtcclxuICAgIH1cclxuICAgIHJldHVybiBmbXQ7XHJcbiAgfVxyXG4gIC8qKlxyXG4gICAgKiDojrflj5bot53nprvlvZPliY3ml6XmnJ/nrKxu5aSp55qE5pel5pyfXHJcbiAgICAqIEBwYXJhbSB7bn0gZGF5IFxyXG4gICAgKi9cclxuICBzdGF0aWMgZ2V0RGF5KGRheSkge1xyXG4gICAgdmFyIHRvZGF5ID0gbmV3IERhdGUoKTtcclxuICAgIHZhciB0YXJnZXRkYXlfbWlsbGlzZWNvbmRzID0gdG9kYXkuZ2V0VGltZSgpICsgMTAwMCAqIDYwICogNjAgKiAyNCAqIGRheTtcclxuICAgIHRvZGF5LnNldFRpbWUodGFyZ2V0ZGF5X21pbGxpc2Vjb25kcyk7IC8v5rOo5oSP77yM6L+Z6KGM5piv5YWz6ZSu5Luj56CBXHJcbiAgICB2YXIgdFllYXIgPSB0b2RheS5nZXRGdWxsWWVhcigpO1xyXG4gICAgdmFyIHRNb250aCA9IHRvZGF5LmdldE1vbnRoKCk7XHJcbiAgICB2YXIgdERhdGUgPSB0b2RheS5nZXREYXRlKCk7XHJcbiAgICB0TW9udGggPSB0aGlzLmRvSGFuZGxlTW9udGgodE1vbnRoICsgMSk7XHJcbiAgICB0RGF0ZSA9IHRoaXMuZG9IYW5kbGVNb250aCh0RGF0ZSk7XHJcbiAgICByZXR1cm4gdFllYXIgKyBcIi1cIiArIHRNb250aCArIFwiLVwiICsgdERhdGU7XHJcbiAgfVxyXG4gIHN0YXRpYyBkb0hhbmRsZU1vbnRoKG1vbnRoKSB7XHJcbiAgICB2YXIgbSA9IG1vbnRoO1xyXG4gICAgaWYgKG1vbnRoLnRvU3RyaW5nKCkubGVuZ3RoID09IDEpIHtcclxuICAgICAgbSA9IFwiMFwiICsgbW9udGg7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gbTtcclxuICB9XHJcbiAgLy8g5qOA6aqM6Lqr5Lu96K+BXHJcbiAgc3RhdGljIGNoZWNrSWRDYXJkKElEQ2FyZCkge1xyXG4gICAgdmFyIGlTdW0gPSAwO1xyXG4gICAgdmFyIGluZm8gPSBcIlwiO1xyXG4gICAgaWYgKCEvXlxcZHsxN30oXFxkfHgpJC9pLnRlc3QoSURDYXJkKSlcclxuICAgICAgcmV0dXJuIHtcclxuICAgICAgICBzdGF0dXM6IGZhbHNlLFxyXG4gICAgICAgIG1lc3NhZ2U6ICfovpPlhaXnmoTouqvku73or4Hplb/luqbmiJbmoLzlvI/plJnor68hJ1xyXG4gICAgICB9O1xyXG4gICAgSURDYXJkID0gSURDYXJkLnJlcGxhY2UoL3gkL2ksIFwiYVwiKTtcclxuICAgIC8vIGlmIChhcmVhSURbcGFyc2VJbnQoSURDYXJkLnN1YnN0cigwLCAyKSldID09IG51bGwpXHJcbiAgICAvLyAgIHJldHVybiB7XHJcbiAgICAvLyAgICAgc3RhdHVzOiBmYWxzZSxcclxuICAgIC8vICAgICBtZXNzYWdlOiAn6L6T5YWl55qE6Lqr5Lu96K+B5pyJ6K+vISdcclxuICAgIC8vICAgfTtcclxuICAgIHZhciBzQmlydGhkYXkgPSBJRENhcmQuc3Vic3RyKDYsIDQpICsgXCItXCIgKyBOdW1iZXIoSURDYXJkLnN1YnN0cigxMCwgMikpICsgXCItXCIgKyBOdW1iZXIoSURDYXJkLnN1YnN0cigxMiwgMikpO1xyXG4gICAgdmFyIGQgPSBuZXcgRGF0ZShzQmlydGhkYXkucmVwbGFjZSgvLS9nLCBcIi9cIikpO1xyXG4gICAgaWYgKHNCaXJ0aGRheSAhPSAoZC5nZXRGdWxsWWVhcigpICsgXCItXCIgKyAoZC5nZXRNb250aCgpICsgMSkgKyBcIi1cIiArIGQuZ2V0RGF0ZSgpKSlcclxuICAgICAgcmV0dXJuIHtcclxuICAgICAgICBzdGF0dXM6IGZhbHNlLFxyXG4gICAgICAgIG1lc3NhZ2U6ICfovpPlhaXnmoTouqvku73or4HmnInor68hJ1xyXG4gICAgICB9O1xyXG4gICAgZm9yICh2YXIgaSA9IDE3OyBpID49IDA7IGktLSlcclxuICAgICAgaVN1bSArPSAoTWF0aC5wb3coMiwgaSkgJSAxMSkgKiBwYXJzZUludChJRENhcmQuY2hhckF0KDE3IC0gaSksIDExKTtcclxuICAgIGlmIChpU3VtICUgMTEgIT0gMSlcclxuICAgICAgcmV0dXJuIHtcclxuICAgICAgICBzdGF0dXM6IGZhbHNlLFxyXG4gICAgICAgIG1lc3NhZ2U6ICfovpPlhaXnmoTouqvku73or4HmnInor68hJ1xyXG4gICAgICB9O1xyXG4gICAgLy9hQ2l0eVtwYXJzZUludChzSWQuc3Vic3RyKDAsMikpXStcIixcIitzQmlydGhkYXkrXCIsXCIrKHNJZC5zdWJzdHIoMTYsMSklMj9cIueUt1wiOlwi5aWzXCIpOy8v5q2k5qyh6L+Y5Y+v5Lul5Yik5pat5Ye66L6T5YWl55qE6Lqr5Lu96K+B5Y+355qE5Lq65oCn5YirXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICBzdGF0dXM6IHRydWUsXHJcbiAgICAgIG1lc3NhZ2U6ICfmoKHpqozmiJDlip/vvIEnXHJcbiAgICB9O1xyXG4gIH1cclxuICAvLyDouqvku73or4Hojrflj5blh7rnlJ/lubTmnIjml6VcclxuICBzdGF0aWMgZ2V0QmlydGhkYXlCeUlkQ2FyZChpZENhcmQpIHtcclxuICAgIC8vIOagoemqjOi6q+S7veivgeaYr+WQpuWQiOazlVxyXG4gICAgbGV0IF9yID0gdGhpcy5jaGVja0lkQ2FyZChpZENhcmQpXHJcbiAgICBpZiAoIV9yLnN0YXR1cykge1xyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIC4uLl9yXHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIHZhciBiaXJ0aFN0cjtcclxuICAgIGlmICgxNSA9PSBpZENhcmQubGVuZ3RoKSB7XHJcbiAgICAgIGJpcnRoU3RyID0gaWRDYXJkLmNoYXJBdCg2KSArIGlkQ2FyZC5jaGFyQXQoNyk7XHJcbiAgICAgIGlmIChwYXJzZUludChiaXJ0aFN0cikgPCAxMCkge1xyXG4gICAgICAgIGJpcnRoU3RyID0gJzIwJyArIGJpcnRoU3RyO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGJpcnRoU3RyID0gJzE5JyArIGJpcnRoU3RyO1xyXG4gICAgICB9XHJcbiAgICAgIGJpcnRoU3RyID0gYmlydGhTdHIgKyAnLScgKyBpZENhcmQuY2hhckF0KDgpICsgaWRDYXJkLmNoYXJBdCg5KSArICctJyArIGlkQ2FyZC5jaGFyQXQoMTApICsgaWRDYXJkLmNoYXJBdCgxMSk7XHJcbiAgICB9IGVsc2UgaWYgKDE4ID09IGlkQ2FyZC5sZW5ndGgpIHtcclxuICAgICAgYmlydGhTdHIgPSBpZENhcmQuY2hhckF0KDYpICsgaWRDYXJkLmNoYXJBdCg3KSArIGlkQ2FyZC5jaGFyQXQoOCkgKyBpZENhcmQuY2hhckF0KDkpICsgJy0nICsgaWRDYXJkLmNoYXJBdCgxMCkgKyBpZENhcmQuY2hhckF0KDExKSArICctJyArIGlkQ2FyZC5jaGFyQXQoMTIpICsgaWRDYXJkLmNoYXJBdCgxMyk7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gYmlydGhTdHI7XHJcbiAgfVxyXG4gIHN0YXRpYyBnZXRTZXhCeUlkQ2FyZChpZENhcmQpIHtcclxuICAgIGlmIChpZENhcmQubGVuZ3RoID09IDE1KSB7XHJcbiAgICAgIHJldHVybiBpZENhcmQuc3Vic3RyaW5nKDE0LCAxNSkgJSAyO1xyXG4gICAgfSBlbHNlIGlmIChpZENhcmQubGVuZ3RoID09IDE4KSB7XHJcbiAgICAgIHJldHVybiBpZENhcmQuc3Vic3RyaW5nKDE0LCAxNykgJSAyO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgLy/kuI3mmK8xNeaIluiAhTE4LG51bGxcclxuICAgICAgcmV0dXJuICcnO1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG5cclxuIl19