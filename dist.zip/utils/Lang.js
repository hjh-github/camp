'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Lang = function () {
  function Lang() {
    _classCallCheck(this, Lang);
  }

  _createClass(Lang, null, [{
    key: 'isEmpty',

    // 判断字符串是否为空
    value: function isEmpty(str) {
      return str == '' || str == null || str == 'null';
    }
    // 判断字符串是否不为空

  }, {
    key: 'isNotEmpty',
    value: function isNotEmpty(str) {
      return !this.isEmpty(str);
    }
    // 浮点求和

  }, {
    key: 'sum',
    value: function sum(numbers) {
      var toFixed = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 2;

      var sum = 0;
      var _iteratorNormalCompletion = true;
      var _didIteratorError = false;
      var _iteratorError = undefined;

      try {
        for (var _iterator = numbers[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
          var str = _step.value;

          if (!this.isNumber(str)) {
            return NaN;
          }
          var num = parseFloat(str);
          if (isNaN(num)) {
            return NaN;
          }
          sum += num;
        }
      } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion && _iterator.return) {
            _iterator.return();
          }
        } finally {
          if (_didIteratorError) {
            throw _iteratorError;
          }
        }
      }

      return sum.toFixed(toFixed);
    }
    // 数字判断

  }, {
    key: 'isNumber',
    value: function isNumber(value) {
      var patrn = /^[-+]?\d+(\.\d+)?$/;
      return patrn.test(value);
    }

    // 数字判断

  }, {
    key: 'isPositiveNumber',
    value: function isPositiveNumber(value) {
      var patrn = /^[1-9]\d*$|^\.\d*$|^0\.\d*$|^[1-9]\d*\.\d*$|^0$/;
      return patrn.test(value);
    }
    // 数组判断

  }, {
    key: 'isArray',
    value: function isArray(o) {
      return Object.prototype.toString.call(o) === '[object Array]';
    }
    // 事件转日期

  }, {
    key: 'convertTimestapeToDay',
    value: function convertTimestapeToDay(timestape) {
      return timestape.substring(0, timestape.indexOf(' ')).replace(/-/g, '.');
    }

    // 格式化日期

  }, {
    key: 'dateFormate',
    value: function dateFormate(date, fmt) {
      var o = {
        'M+': date.getMonth() + 1,
        'd+': date.getDate(),
        'h+': date.getHours(),
        'm+': date.getMinutes(),
        's+': date.getSeconds(),
        'q+': Math.floor((date.getMonth() + 3) / 3),
        'S': date.getMilliseconds()
      };
      if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length));
      for (var k in o) {
        if (new RegExp('(' + k + ')').test(fmt)) fmt = fmt.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ('00' + o[k]).substr(('' + o[k]).length));
      }
      return fmt;
    }
    /**
      * 获取距离当前日期第n天的日期
      * @param {n} day 
      */

  }, {
    key: 'getDay',
    value: function getDay(day) {
      var today = new Date();
      var targetday_milliseconds = today.getTime() + 1000 * 60 * 60 * 24 * day;
      today.setTime(targetday_milliseconds); //注意，这行是关键代码
      var tYear = today.getFullYear();
      var tMonth = today.getMonth();
      var tDate = today.getDate();
      tMonth = this.doHandleMonth(tMonth + 1);
      tDate = this.doHandleMonth(tDate);
      return tYear + "-" + tMonth + "-" + tDate;
    }
  }, {
    key: 'doHandleMonth',
    value: function doHandleMonth(month) {
      var m = month;
      if (month.toString().length == 1) {
        m = "0" + month;
      }
      return m;
    }
    // 检验身份证

  }, {
    key: 'checkIdCard',
    value: function checkIdCard(IDCard) {
      var iSum = 0;
      var info = "";
      if (!/^\d{17}(\d|x)$/i.test(IDCard)) return {
        status: false,
        message: '输入的身份证长度或格式错误!'
      };
      IDCard = IDCard.replace(/x$/i, "a");
      // if (areaID[parseInt(IDCard.substr(0, 2))] == null)
      //   return {
      //     status: false,
      //     message: '输入的身份证有误!'
      //   };
      var sBirthday = IDCard.substr(6, 4) + "-" + Number(IDCard.substr(10, 2)) + "-" + Number(IDCard.substr(12, 2));
      var d = new Date(sBirthday.replace(/-/g, "/"));
      if (sBirthday != d.getFullYear() + "-" + (d.getMonth() + 1) + "-" + d.getDate()) return {
        status: false,
        message: '输入的身份证有误!'
      };
      for (var i = 17; i >= 0; i--) {
        iSum += Math.pow(2, i) % 11 * parseInt(IDCard.charAt(17 - i), 11);
      }if (iSum % 11 != 1) return {
        status: false,
        message: '输入的身份证有误!'
      };
      //aCity[parseInt(sId.substr(0,2))]+","+sBirthday+","+(sId.substr(16,1)%2?"男":"女");//此次还可以判断出输入的身份证号的人性别
      return {
        status: true,
        message: '校验成功！'
      };
    }
    // 身份证获取出生年月日

  }, {
    key: 'getBirthdayByIdCard',
    value: function getBirthdayByIdCard(idCard) {
      // 校验身份证是否合法
      var _r = this.checkIdCard(idCard);
      if (!_r.status) {
        return _extends({}, _r);
      }
      var birthStr;
      if (15 == idCard.length) {
        birthStr = idCard.charAt(6) + idCard.charAt(7);
        if (parseInt(birthStr) < 10) {
          birthStr = '20' + birthStr;
        } else {
          birthStr = '19' + birthStr;
        }
        birthStr = birthStr + '-' + idCard.charAt(8) + idCard.charAt(9) + '-' + idCard.charAt(10) + idCard.charAt(11);
      } else if (18 == idCard.length) {
        birthStr = idCard.charAt(6) + idCard.charAt(7) + idCard.charAt(8) + idCard.charAt(9) + '-' + idCard.charAt(10) + idCard.charAt(11) + '-' + idCard.charAt(12) + idCard.charAt(13);
      }
      return birthStr;
    }
  }, {
    key: 'getSexByIdCard',
    value: function getSexByIdCard(idCard) {
      if (idCard.length == 15) {
        return idCard.substring(14, 15) % 2;
      } else if (idCard.length == 18) {
        return idCard.substring(14, 17) % 2;
      } else {
        //不是15或者18,null
        return '';
      }
    }
  }]);

  return Lang;
}();

exports.default = Lang;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkxhbmcuanMiXSwibmFtZXMiOlsiTGFuZyIsInN0ciIsImlzRW1wdHkiLCJudW1iZXJzIiwidG9GaXhlZCIsInN1bSIsImlzTnVtYmVyIiwiTmFOIiwibnVtIiwicGFyc2VGbG9hdCIsImlzTmFOIiwidmFsdWUiLCJwYXRybiIsInRlc3QiLCJvIiwiT2JqZWN0IiwicHJvdG90eXBlIiwidG9TdHJpbmciLCJjYWxsIiwidGltZXN0YXBlIiwic3Vic3RyaW5nIiwiaW5kZXhPZiIsInJlcGxhY2UiLCJkYXRlIiwiZm10IiwiZ2V0TW9udGgiLCJnZXREYXRlIiwiZ2V0SG91cnMiLCJnZXRNaW51dGVzIiwiZ2V0U2Vjb25kcyIsIk1hdGgiLCJmbG9vciIsImdldE1pbGxpc2Vjb25kcyIsIlJlZ0V4cCIsIiQxIiwiZ2V0RnVsbFllYXIiLCJzdWJzdHIiLCJsZW5ndGgiLCJrIiwiZGF5IiwidG9kYXkiLCJEYXRlIiwidGFyZ2V0ZGF5X21pbGxpc2Vjb25kcyIsImdldFRpbWUiLCJzZXRUaW1lIiwidFllYXIiLCJ0TW9udGgiLCJ0RGF0ZSIsImRvSGFuZGxlTW9udGgiLCJtb250aCIsIm0iLCJJRENhcmQiLCJpU3VtIiwiaW5mbyIsInN0YXR1cyIsIm1lc3NhZ2UiLCJzQmlydGhkYXkiLCJOdW1iZXIiLCJkIiwiaSIsInBvdyIsInBhcnNlSW50IiwiY2hhckF0IiwiaWRDYXJkIiwiX3IiLCJjaGVja0lkQ2FyZCIsImJpcnRoU3RyIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7SUFBcUJBLEk7Ozs7Ozs7O0FBQ25COzRCQUNlQyxHLEVBQUs7QUFDbEIsYUFBT0EsT0FBTyxFQUFQLElBQWFBLE9BQU8sSUFBcEIsSUFBNEJBLE9BQU8sTUFBMUM7QUFDRDtBQUNEOzs7OytCQUNrQkEsRyxFQUFLO0FBQ3JCLGFBQU8sQ0FBQyxLQUFLQyxPQUFMLENBQWFELEdBQWIsQ0FBUjtBQUNEO0FBQ0Q7Ozs7d0JBQ1dFLE8sRUFBc0I7QUFBQSxVQUFiQyxPQUFhLHVFQUFILENBQUc7O0FBQy9CLFVBQUlDLE1BQU0sQ0FBVjtBQUQrQjtBQUFBO0FBQUE7O0FBQUE7QUFFL0IsNkJBQWtCRixPQUFsQiw4SEFBMkI7QUFBQSxjQUFoQkYsR0FBZ0I7O0FBQ3pCLGNBQUksQ0FBQyxLQUFLSyxRQUFMLENBQWNMLEdBQWQsQ0FBTCxFQUF5QjtBQUN2QixtQkFBT00sR0FBUDtBQUNEO0FBQ0QsY0FBTUMsTUFBTUMsV0FBV1IsR0FBWCxDQUFaO0FBQ0EsY0FBSVMsTUFBTUYsR0FBTixDQUFKLEVBQWdCO0FBQ2QsbUJBQU9ELEdBQVA7QUFDRDtBQUNERixpQkFBT0csR0FBUDtBQUNEO0FBWDhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBWS9CLGFBQU9ILElBQUlELE9BQUosQ0FBWUEsT0FBWixDQUFQO0FBQ0Q7QUFDRDs7Ozs2QkFDZ0JPLEssRUFBTztBQUNyQixVQUFNQyxRQUFRLG9CQUFkO0FBQ0EsYUFBT0EsTUFBTUMsSUFBTixDQUFXRixLQUFYLENBQVA7QUFDRDs7QUFFRDs7OztxQ0FDd0JBLEssRUFBTztBQUM3QixVQUFNQyxRQUFRLGlEQUFkO0FBQ0EsYUFBT0EsTUFBTUMsSUFBTixDQUFXRixLQUFYLENBQVA7QUFDRDtBQUNEOzs7OzRCQUNlRyxDLEVBQUc7QUFDaEIsYUFBT0MsT0FBT0MsU0FBUCxDQUFpQkMsUUFBakIsQ0FBMEJDLElBQTFCLENBQStCSixDQUEvQixNQUFzQyxnQkFBN0M7QUFDRDtBQUNEOzs7OzBDQUM2QkssUyxFQUFXO0FBQ3RDLGFBQU9BLFVBQVVDLFNBQVYsQ0FBb0IsQ0FBcEIsRUFBdUJELFVBQVVFLE9BQVYsQ0FBa0IsR0FBbEIsQ0FBdkIsRUFBK0NDLE9BQS9DLENBQXVELElBQXZELEVBQTZELEdBQTdELENBQVA7QUFDRDs7QUFFRDs7OztnQ0FDbUJDLEksRUFBTUMsRyxFQUFLO0FBQzVCLFVBQU1WLElBQUk7QUFDUixjQUFNUyxLQUFLRSxRQUFMLEtBQWtCLENBRGhCO0FBRVIsY0FBTUYsS0FBS0csT0FBTCxFQUZFO0FBR1IsY0FBTUgsS0FBS0ksUUFBTCxFQUhFO0FBSVIsY0FBTUosS0FBS0ssVUFBTCxFQUpFO0FBS1IsY0FBTUwsS0FBS00sVUFBTCxFQUxFO0FBTVIsY0FBTUMsS0FBS0MsS0FBTCxDQUFXLENBQUNSLEtBQUtFLFFBQUwsS0FBa0IsQ0FBbkIsSUFBd0IsQ0FBbkMsQ0FORTtBQU9SLGFBQUtGLEtBQUtTLGVBQUw7QUFQRyxPQUFWO0FBU0EsVUFBSSxPQUFPbkIsSUFBUCxDQUFZVyxHQUFaLENBQUosRUFBc0JBLE1BQU1BLElBQUlGLE9BQUosQ0FBWVcsT0FBT0MsRUFBbkIsRUFBdUIsQ0FBQ1gsS0FBS1ksV0FBTCxLQUFxQixFQUF0QixFQUEwQkMsTUFBMUIsQ0FBaUMsSUFBSUgsT0FBT0MsRUFBUCxDQUFVRyxNQUEvQyxDQUF2QixDQUFOO0FBQ3RCLFdBQUssSUFBSUMsQ0FBVCxJQUFjeEIsQ0FBZCxFQUFpQjtBQUNmLFlBQUksSUFBSW1CLE1BQUosQ0FBVyxNQUFNSyxDQUFOLEdBQVUsR0FBckIsRUFBMEJ6QixJQUExQixDQUErQlcsR0FBL0IsQ0FBSixFQUF5Q0EsTUFBTUEsSUFBSUYsT0FBSixDQUFZVyxPQUFPQyxFQUFuQixFQUF3QkQsT0FBT0MsRUFBUCxDQUFVRyxNQUFWLElBQW9CLENBQXJCLEdBQTJCdkIsRUFBRXdCLENBQUYsQ0FBM0IsR0FBb0MsQ0FBQyxPQUFPeEIsRUFBRXdCLENBQUYsQ0FBUixFQUFjRixNQUFkLENBQXFCLENBQUMsS0FBS3RCLEVBQUV3QixDQUFGLENBQU4sRUFBWUQsTUFBakMsQ0FBM0QsQ0FBTjtBQUMxQztBQUNELGFBQU9iLEdBQVA7QUFDRDtBQUNEOzs7Ozs7OzJCQUljZSxHLEVBQUs7QUFDakIsVUFBSUMsUUFBUSxJQUFJQyxJQUFKLEVBQVo7QUFDQSxVQUFJQyx5QkFBeUJGLE1BQU1HLE9BQU4sS0FBa0IsT0FBTyxFQUFQLEdBQVksRUFBWixHQUFpQixFQUFqQixHQUFzQkosR0FBckU7QUFDQUMsWUFBTUksT0FBTixDQUFjRixzQkFBZCxFQUhpQixDQUdzQjtBQUN2QyxVQUFJRyxRQUFRTCxNQUFNTCxXQUFOLEVBQVo7QUFDQSxVQUFJVyxTQUFTTixNQUFNZixRQUFOLEVBQWI7QUFDQSxVQUFJc0IsUUFBUVAsTUFBTWQsT0FBTixFQUFaO0FBQ0FvQixlQUFTLEtBQUtFLGFBQUwsQ0FBbUJGLFNBQVMsQ0FBNUIsQ0FBVDtBQUNBQyxjQUFRLEtBQUtDLGFBQUwsQ0FBbUJELEtBQW5CLENBQVI7QUFDQSxhQUFPRixRQUFRLEdBQVIsR0FBY0MsTUFBZCxHQUF1QixHQUF2QixHQUE2QkMsS0FBcEM7QUFDRDs7O2tDQUNvQkUsSyxFQUFPO0FBQzFCLFVBQUlDLElBQUlELEtBQVI7QUFDQSxVQUFJQSxNQUFNaEMsUUFBTixHQUFpQm9CLE1BQWpCLElBQTJCLENBQS9CLEVBQWtDO0FBQ2hDYSxZQUFJLE1BQU1ELEtBQVY7QUFDRDtBQUNELGFBQU9DLENBQVA7QUFDRDtBQUNEOzs7O2dDQUNtQkMsTSxFQUFRO0FBQ3pCLFVBQUlDLE9BQU8sQ0FBWDtBQUNBLFVBQUlDLE9BQU8sRUFBWDtBQUNBLFVBQUksQ0FBQyxrQkFBa0J4QyxJQUFsQixDQUF1QnNDLE1BQXZCLENBQUwsRUFDRSxPQUFPO0FBQ0xHLGdCQUFRLEtBREg7QUFFTEMsaUJBQVM7QUFGSixPQUFQO0FBSUZKLGVBQVNBLE9BQU83QixPQUFQLENBQWUsS0FBZixFQUFzQixHQUF0QixDQUFUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBQUlrQyxZQUFZTCxPQUFPZixNQUFQLENBQWMsQ0FBZCxFQUFpQixDQUFqQixJQUFzQixHQUF0QixHQUE0QnFCLE9BQU9OLE9BQU9mLE1BQVAsQ0FBYyxFQUFkLEVBQWtCLENBQWxCLENBQVAsQ0FBNUIsR0FBMkQsR0FBM0QsR0FBaUVxQixPQUFPTixPQUFPZixNQUFQLENBQWMsRUFBZCxFQUFrQixDQUFsQixDQUFQLENBQWpGO0FBQ0EsVUFBSXNCLElBQUksSUFBSWpCLElBQUosQ0FBU2UsVUFBVWxDLE9BQVYsQ0FBa0IsSUFBbEIsRUFBd0IsR0FBeEIsQ0FBVCxDQUFSO0FBQ0EsVUFBSWtDLGFBQWNFLEVBQUV2QixXQUFGLEtBQWtCLEdBQWxCLElBQXlCdUIsRUFBRWpDLFFBQUYsS0FBZSxDQUF4QyxJQUE2QyxHQUE3QyxHQUFtRGlDLEVBQUVoQyxPQUFGLEVBQXJFLEVBQ0UsT0FBTztBQUNMNEIsZ0JBQVEsS0FESDtBQUVMQyxpQkFBUztBQUZKLE9BQVA7QUFJRixXQUFLLElBQUlJLElBQUksRUFBYixFQUFpQkEsS0FBSyxDQUF0QixFQUF5QkEsR0FBekI7QUFDRVAsZ0JBQVN0QixLQUFLOEIsR0FBTCxDQUFTLENBQVQsRUFBWUQsQ0FBWixJQUFpQixFQUFsQixHQUF3QkUsU0FBU1YsT0FBT1csTUFBUCxDQUFjLEtBQUtILENBQW5CLENBQVQsRUFBZ0MsRUFBaEMsQ0FBaEM7QUFERixPQUVBLElBQUlQLE9BQU8sRUFBUCxJQUFhLENBQWpCLEVBQ0UsT0FBTztBQUNMRSxnQkFBUSxLQURIO0FBRUxDLGlCQUFTO0FBRkosT0FBUDtBQUlGO0FBQ0EsYUFBTztBQUNMRCxnQkFBUSxJQURIO0FBRUxDLGlCQUFTO0FBRkosT0FBUDtBQUlEO0FBQ0Q7Ozs7d0NBQzJCUSxNLEVBQVE7QUFDakM7QUFDQSxVQUFJQyxLQUFLLEtBQUtDLFdBQUwsQ0FBaUJGLE1BQWpCLENBQVQ7QUFDQSxVQUFHLENBQUVDLEdBQUdWLE1BQVIsRUFBZTtBQUNiLDRCQUNLVSxFQURMO0FBR0Q7QUFDRCxVQUFJRSxRQUFKO0FBQ0EsVUFBSSxNQUFNSCxPQUFPMUIsTUFBakIsRUFBeUI7QUFDdkI2QixtQkFBV0gsT0FBT0QsTUFBUCxDQUFjLENBQWQsSUFBbUJDLE9BQU9ELE1BQVAsQ0FBYyxDQUFkLENBQTlCO0FBQ0EsWUFBSUQsU0FBU0ssUUFBVCxJQUFxQixFQUF6QixFQUE2QjtBQUMzQkEscUJBQVcsT0FBT0EsUUFBbEI7QUFDRCxTQUZELE1BRU87QUFDTEEscUJBQVcsT0FBT0EsUUFBbEI7QUFDRDtBQUNEQSxtQkFBV0EsV0FBVyxHQUFYLEdBQWlCSCxPQUFPRCxNQUFQLENBQWMsQ0FBZCxDQUFqQixHQUFvQ0MsT0FBT0QsTUFBUCxDQUFjLENBQWQsQ0FBcEMsR0FBdUQsR0FBdkQsR0FBNkRDLE9BQU9ELE1BQVAsQ0FBYyxFQUFkLENBQTdELEdBQWlGQyxPQUFPRCxNQUFQLENBQWMsRUFBZCxDQUE1RjtBQUNELE9BUkQsTUFRTyxJQUFJLE1BQU1DLE9BQU8xQixNQUFqQixFQUF5QjtBQUM5QjZCLG1CQUFXSCxPQUFPRCxNQUFQLENBQWMsQ0FBZCxJQUFtQkMsT0FBT0QsTUFBUCxDQUFjLENBQWQsQ0FBbkIsR0FBc0NDLE9BQU9ELE1BQVAsQ0FBYyxDQUFkLENBQXRDLEdBQXlEQyxPQUFPRCxNQUFQLENBQWMsQ0FBZCxDQUF6RCxHQUE0RSxHQUE1RSxHQUFrRkMsT0FBT0QsTUFBUCxDQUFjLEVBQWQsQ0FBbEYsR0FBc0dDLE9BQU9ELE1BQVAsQ0FBYyxFQUFkLENBQXRHLEdBQTBILEdBQTFILEdBQWdJQyxPQUFPRCxNQUFQLENBQWMsRUFBZCxDQUFoSSxHQUFvSkMsT0FBT0QsTUFBUCxDQUFjLEVBQWQsQ0FBL0o7QUFDRDtBQUNELGFBQU9JLFFBQVA7QUFDRDs7O21DQUNzQkgsTSxFQUFRO0FBQzdCLFVBQUdBLE9BQU8xQixNQUFQLElBQWlCLEVBQXBCLEVBQXdCO0FBQ3RCLGVBQU8wQixPQUFPM0MsU0FBUCxDQUFpQixFQUFqQixFQUFxQixFQUFyQixJQUEyQixDQUFsQztBQUNELE9BRkQsTUFFTyxJQUFHMkMsT0FBTzFCLE1BQVAsSUFBaUIsRUFBcEIsRUFBd0I7QUFDN0IsZUFBTzBCLE9BQU8zQyxTQUFQLENBQWlCLEVBQWpCLEVBQXFCLEVBQXJCLElBQTJCLENBQWxDO0FBQ0QsT0FGTSxNQUVBO0FBQ0w7QUFDQSxlQUFPLEVBQVA7QUFDRDtBQUNGOzs7Ozs7a0JBdEprQnBCLEkiLCJmaWxlIjoiTGFuZy5qcyIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBkZWZhdWx0IGNsYXNzIExhbmcge1xyXG4gIC8vIOWIpOaWreWtl+espuS4suaYr+WQpuS4uuepulxyXG4gIHN0YXRpYyBpc0VtcHR5KHN0cikge1xyXG4gICAgcmV0dXJuIHN0ciA9PSAnJyB8fCBzdHIgPT0gbnVsbCB8fCBzdHIgPT0gJ251bGwnO1xyXG4gIH1cclxuICAvLyDliKTmlq3lrZfnrKbkuLLmmK/lkKbkuI3kuLrnqbpcclxuICBzdGF0aWMgaXNOb3RFbXB0eShzdHIpIHtcclxuICAgIHJldHVybiAhdGhpcy5pc0VtcHR5KHN0cik7XHJcbiAgfVxyXG4gIC8vIOa1rueCueaxguWSjFxyXG4gIHN0YXRpYyBzdW0obnVtYmVycywgdG9GaXhlZCA9IDIpIHtcclxuICAgIGxldCBzdW0gPSAwO1xyXG4gICAgZm9yIChjb25zdCBzdHIgb2YgbnVtYmVycykge1xyXG4gICAgICBpZiAoIXRoaXMuaXNOdW1iZXIoc3RyKSkge1xyXG4gICAgICAgIHJldHVybiBOYU47XHJcbiAgICAgIH1cclxuICAgICAgY29uc3QgbnVtID0gcGFyc2VGbG9hdChzdHIpO1xyXG4gICAgICBpZiAoaXNOYU4obnVtKSkge1xyXG4gICAgICAgIHJldHVybiBOYU47XHJcbiAgICAgIH1cclxuICAgICAgc3VtICs9IG51bTtcclxuICAgIH1cclxuICAgIHJldHVybiBzdW0udG9GaXhlZCh0b0ZpeGVkKTtcclxuICB9XHJcbiAgLy8g5pWw5a2X5Yik5patXHJcbiAgc3RhdGljIGlzTnVtYmVyKHZhbHVlKSB7XHJcbiAgICBjb25zdCBwYXRybiA9IC9eWy0rXT9cXGQrKFxcLlxcZCspPyQvO1xyXG4gICAgcmV0dXJuIHBhdHJuLnRlc3QodmFsdWUpO1xyXG4gIH1cclxuXHJcbiAgLy8g5pWw5a2X5Yik5patXHJcbiAgc3RhdGljIGlzUG9zaXRpdmVOdW1iZXIodmFsdWUpIHtcclxuICAgIGNvbnN0IHBhdHJuID0gL15bMS05XVxcZCokfF5cXC5cXGQqJHxeMFxcLlxcZCokfF5bMS05XVxcZCpcXC5cXGQqJHxeMCQvO1xyXG4gICAgcmV0dXJuIHBhdHJuLnRlc3QodmFsdWUpO1xyXG4gIH1cclxuICAvLyDmlbDnu4TliKTmlq1cclxuICBzdGF0aWMgaXNBcnJheShvKSB7XHJcbiAgICByZXR1cm4gT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKG8pID09PSAnW29iamVjdCBBcnJheV0nO1xyXG4gIH1cclxuICAvLyDkuovku7bovazml6XmnJ9cclxuICBzdGF0aWMgY29udmVydFRpbWVzdGFwZVRvRGF5KHRpbWVzdGFwZSkge1xyXG4gICAgcmV0dXJuIHRpbWVzdGFwZS5zdWJzdHJpbmcoMCwgdGltZXN0YXBlLmluZGV4T2YoJyAnKSkucmVwbGFjZSgvLS9nLCAnLicpO1xyXG4gIH1cclxuXHJcbiAgLy8g5qC85byP5YyW5pel5pyfXHJcbiAgc3RhdGljIGRhdGVGb3JtYXRlKGRhdGUsIGZtdCkge1xyXG4gICAgY29uc3QgbyA9IHtcclxuICAgICAgJ00rJzogZGF0ZS5nZXRNb250aCgpICsgMSxcclxuICAgICAgJ2QrJzogZGF0ZS5nZXREYXRlKCksXHJcbiAgICAgICdoKyc6IGRhdGUuZ2V0SG91cnMoKSxcclxuICAgICAgJ20rJzogZGF0ZS5nZXRNaW51dGVzKCksXHJcbiAgICAgICdzKyc6IGRhdGUuZ2V0U2Vjb25kcygpLFxyXG4gICAgICAncSsnOiBNYXRoLmZsb29yKChkYXRlLmdldE1vbnRoKCkgKyAzKSAvIDMpLFxyXG4gICAgICAnUyc6IGRhdGUuZ2V0TWlsbGlzZWNvbmRzKClcclxuICAgIH07XHJcbiAgICBpZiAoLyh5KykvLnRlc3QoZm10KSkgZm10ID0gZm10LnJlcGxhY2UoUmVnRXhwLiQxLCAoZGF0ZS5nZXRGdWxsWWVhcigpICsgJycpLnN1YnN0cig0IC0gUmVnRXhwLiQxLmxlbmd0aCkpO1xyXG4gICAgZm9yIChsZXQgayBpbiBvKSB7XHJcbiAgICAgIGlmIChuZXcgUmVnRXhwKCcoJyArIGsgKyAnKScpLnRlc3QoZm10KSkgZm10ID0gZm10LnJlcGxhY2UoUmVnRXhwLiQxLCAoUmVnRXhwLiQxLmxlbmd0aCA9PSAxKSA/IChvW2tdKSA6ICgoJzAwJyArIG9ba10pLnN1YnN0cigoJycgKyBvW2tdKS5sZW5ndGgpKSk7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gZm10O1xyXG4gIH1cclxuICAvKipcclxuICAgICog6I635Y+W6Led56a75b2T5YmN5pel5pyf56ysbuWkqeeahOaXpeacn1xyXG4gICAgKiBAcGFyYW0ge259IGRheSBcclxuICAgICovXHJcbiAgc3RhdGljIGdldERheShkYXkpIHtcclxuICAgIHZhciB0b2RheSA9IG5ldyBEYXRlKCk7XHJcbiAgICB2YXIgdGFyZ2V0ZGF5X21pbGxpc2Vjb25kcyA9IHRvZGF5LmdldFRpbWUoKSArIDEwMDAgKiA2MCAqIDYwICogMjQgKiBkYXk7XHJcbiAgICB0b2RheS5zZXRUaW1lKHRhcmdldGRheV9taWxsaXNlY29uZHMpOyAvL+azqOaEj++8jOi/meihjOaYr+WFs+mUruS7o+eggVxyXG4gICAgdmFyIHRZZWFyID0gdG9kYXkuZ2V0RnVsbFllYXIoKTtcclxuICAgIHZhciB0TW9udGggPSB0b2RheS5nZXRNb250aCgpO1xyXG4gICAgdmFyIHREYXRlID0gdG9kYXkuZ2V0RGF0ZSgpO1xyXG4gICAgdE1vbnRoID0gdGhpcy5kb0hhbmRsZU1vbnRoKHRNb250aCArIDEpO1xyXG4gICAgdERhdGUgPSB0aGlzLmRvSGFuZGxlTW9udGgodERhdGUpO1xyXG4gICAgcmV0dXJuIHRZZWFyICsgXCItXCIgKyB0TW9udGggKyBcIi1cIiArIHREYXRlO1xyXG4gIH1cclxuICBzdGF0aWMgZG9IYW5kbGVNb250aChtb250aCkge1xyXG4gICAgdmFyIG0gPSBtb250aDtcclxuICAgIGlmIChtb250aC50b1N0cmluZygpLmxlbmd0aCA9PSAxKSB7XHJcbiAgICAgIG0gPSBcIjBcIiArIG1vbnRoO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIG07XHJcbiAgfVxyXG4gIC8vIOajgOmqjOi6q+S7veivgVxyXG4gIHN0YXRpYyBjaGVja0lkQ2FyZChJRENhcmQpIHtcclxuICAgIHZhciBpU3VtID0gMDtcclxuICAgIHZhciBpbmZvID0gXCJcIjtcclxuICAgIGlmICghL15cXGR7MTd9KFxcZHx4KSQvaS50ZXN0KElEQ2FyZCkpXHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAgc3RhdHVzOiBmYWxzZSxcclxuICAgICAgICBtZXNzYWdlOiAn6L6T5YWl55qE6Lqr5Lu96K+B6ZW/5bqm5oiW5qC85byP6ZSZ6K+vISdcclxuICAgICAgfTtcclxuICAgIElEQ2FyZCA9IElEQ2FyZC5yZXBsYWNlKC94JC9pLCBcImFcIik7XHJcbiAgICAvLyBpZiAoYXJlYUlEW3BhcnNlSW50KElEQ2FyZC5zdWJzdHIoMCwgMikpXSA9PSBudWxsKVxyXG4gICAgLy8gICByZXR1cm4ge1xyXG4gICAgLy8gICAgIHN0YXR1czogZmFsc2UsXHJcbiAgICAvLyAgICAgbWVzc2FnZTogJ+i+k+WFpeeahOi6q+S7veivgeacieivryEnXHJcbiAgICAvLyAgIH07XHJcbiAgICB2YXIgc0JpcnRoZGF5ID0gSURDYXJkLnN1YnN0cig2LCA0KSArIFwiLVwiICsgTnVtYmVyKElEQ2FyZC5zdWJzdHIoMTAsIDIpKSArIFwiLVwiICsgTnVtYmVyKElEQ2FyZC5zdWJzdHIoMTIsIDIpKTtcclxuICAgIHZhciBkID0gbmV3IERhdGUoc0JpcnRoZGF5LnJlcGxhY2UoLy0vZywgXCIvXCIpKTtcclxuICAgIGlmIChzQmlydGhkYXkgIT0gKGQuZ2V0RnVsbFllYXIoKSArIFwiLVwiICsgKGQuZ2V0TW9udGgoKSArIDEpICsgXCItXCIgKyBkLmdldERhdGUoKSkpXHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAgc3RhdHVzOiBmYWxzZSxcclxuICAgICAgICBtZXNzYWdlOiAn6L6T5YWl55qE6Lqr5Lu96K+B5pyJ6K+vISdcclxuICAgICAgfTtcclxuICAgIGZvciAodmFyIGkgPSAxNzsgaSA+PSAwOyBpLS0pXHJcbiAgICAgIGlTdW0gKz0gKE1hdGgucG93KDIsIGkpICUgMTEpICogcGFyc2VJbnQoSURDYXJkLmNoYXJBdCgxNyAtIGkpLCAxMSk7XHJcbiAgICBpZiAoaVN1bSAlIDExICE9IDEpXHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAgc3RhdHVzOiBmYWxzZSxcclxuICAgICAgICBtZXNzYWdlOiAn6L6T5YWl55qE6Lqr5Lu96K+B5pyJ6K+vISdcclxuICAgICAgfTtcclxuICAgIC8vYUNpdHlbcGFyc2VJbnQoc0lkLnN1YnN0cigwLDIpKV0rXCIsXCIrc0JpcnRoZGF5K1wiLFwiKyhzSWQuc3Vic3RyKDE2LDEpJTI/XCLnlLdcIjpcIuWls1wiKTsvL+atpOasoei/mOWPr+S7peWIpOaWreWHuui+k+WFpeeahOi6q+S7veivgeWPt+eahOS6uuaAp+WIq1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgc3RhdHVzOiB0cnVlLFxyXG4gICAgICBtZXNzYWdlOiAn5qCh6aqM5oiQ5Yqf77yBJ1xyXG4gICAgfTtcclxuICB9XHJcbiAgLy8g6Lqr5Lu96K+B6I635Y+W5Ye655Sf5bm05pyI5pelXHJcbiAgc3RhdGljIGdldEJpcnRoZGF5QnlJZENhcmQoaWRDYXJkKSB7XHJcbiAgICAvLyDmoKHpqozouqvku73or4HmmK/lkKblkIjms5VcclxuICAgIGxldCBfciA9IHRoaXMuY2hlY2tJZENhcmQoaWRDYXJkKVxyXG4gICAgaWYoISBfci5zdGF0dXMpe1xyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIC4uLl9yXHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIHZhciBiaXJ0aFN0cjtcclxuICAgIGlmICgxNSA9PSBpZENhcmQubGVuZ3RoKSB7XHJcbiAgICAgIGJpcnRoU3RyID0gaWRDYXJkLmNoYXJBdCg2KSArIGlkQ2FyZC5jaGFyQXQoNyk7XHJcbiAgICAgIGlmIChwYXJzZUludChiaXJ0aFN0cikgPCAxMCkge1xyXG4gICAgICAgIGJpcnRoU3RyID0gJzIwJyArIGJpcnRoU3RyO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGJpcnRoU3RyID0gJzE5JyArIGJpcnRoU3RyO1xyXG4gICAgICB9XHJcbiAgICAgIGJpcnRoU3RyID0gYmlydGhTdHIgKyAnLScgKyBpZENhcmQuY2hhckF0KDgpICsgaWRDYXJkLmNoYXJBdCg5KSArICctJyArIGlkQ2FyZC5jaGFyQXQoMTApICsgaWRDYXJkLmNoYXJBdCgxMSk7XHJcbiAgICB9IGVsc2UgaWYgKDE4ID09IGlkQ2FyZC5sZW5ndGgpIHtcclxuICAgICAgYmlydGhTdHIgPSBpZENhcmQuY2hhckF0KDYpICsgaWRDYXJkLmNoYXJBdCg3KSArIGlkQ2FyZC5jaGFyQXQoOCkgKyBpZENhcmQuY2hhckF0KDkpICsgJy0nICsgaWRDYXJkLmNoYXJBdCgxMCkgKyBpZENhcmQuY2hhckF0KDExKSArICctJyArIGlkQ2FyZC5jaGFyQXQoMTIpICsgaWRDYXJkLmNoYXJBdCgxMyk7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gYmlydGhTdHI7XHJcbiAgfVxyXG4gIHN0YXRpYyBnZXRTZXhCeUlkQ2FyZCAoaWRDYXJkKSB7XHJcbiAgICBpZihpZENhcmQubGVuZ3RoID09IDE1KSB7XHJcbiAgICAgIHJldHVybiBpZENhcmQuc3Vic3RyaW5nKDE0LCAxNSkgJSAyO1xyXG4gICAgfSBlbHNlIGlmKGlkQ2FyZC5sZW5ndGggPT0gMTgpIHtcclxuICAgICAgcmV0dXJuIGlkQ2FyZC5zdWJzdHJpbmcoMTQsIDE3KSAlIDI7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAvL+S4jeaYrzE15oiW6ICFMTgsbnVsbFxyXG4gICAgICByZXR1cm4gJyc7XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcblxyXG4iXX0=