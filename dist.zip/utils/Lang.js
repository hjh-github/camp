"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Lang = function () {
  function Lang() {
    _classCallCheck(this, Lang);
  }

  _createClass(Lang, null, [{
    key: "previewImage",
    value: function previewImage(current, urls) {
      wx.previewImage({
        current: current, // 当前显示图片的http链接
        urls: urls // 需要预览的图片http链接列表
      });
    }
  }, {
    key: "downImg",
    value: function downImg(url) {
      var callback = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;

      wx.downloadFile({
        url: url,
        success: function success(res) {
          console.log(res);
          //图片保存到本地
          wx.saveImageToPhotosAlbum({
            filePath: res.tempFilePath,
            success: function () {
              var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(data) {
                return regeneratorRuntime.wrap(function _callee$(_context) {
                  while (1) {
                    switch (_context.prev = _context.next) {
                      case 0:
                        if (callback) callback({ code: 0 });

                      case 1:
                      case "end":
                        return _context.stop();
                    }
                  }
                }, _callee, this);
              }));

              function success(_x2) {
                return _ref.apply(this, arguments);
              }

              return success;
            }(),
            fail: function fail(err) {
              console.log(err);
              if (err.errMsg === "saveImageToPhotosAlbum:fail auth deny") {
                console.log("当前用户拒绝，再次发起授权");
                if (callback) callback({ code: -1 });
              }
            },
            complete: function complete(res) {
              console.log(res);
            }
          });
        }
      });
    }
  }, {
    key: "openSetting",
    value: function openSetting() {
      wx.openSetting({
        success: function success(settingdata) {
          if (settingdata.authSetting['scope.writePhotosAlbum']) {
            console.log('获取权限成功，给出再次点击图片保存到相册的提示。');
          } else {
            console.log('获取权限失败，给出不给权限就无法正常使用的提示');
          }
        }
      });
    }
    // 判断字符串是否为空

  }, {
    key: "isEmpty",
    value: function isEmpty(str) {
      return str == '' || str == null || str == 'null';
    }
    // 判断字符串是否不为空

  }, {
    key: "isNotEmpty",
    value: function isNotEmpty(str) {
      return !this.isEmpty(str);
    }
    // 浮点求和

  }, {
    key: "sum",
    value: function sum(numbers) {
      var toFixed = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 2;

      var sum = 0;
      var _iteratorNormalCompletion = true;
      var _didIteratorError = false;
      var _iteratorError = undefined;

      try {
        for (var _iterator = numbers[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
          var str = _step.value;

          if (!this.isNumber(str)) {
            return NaN;
          }
          var num = parseFloat(str);
          if (isNaN(num)) {
            return NaN;
          }
          sum += num;
        }
      } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion && _iterator.return) {
            _iterator.return();
          }
        } finally {
          if (_didIteratorError) {
            throw _iteratorError;
          }
        }
      }

      return sum.toFixed(toFixed);
    }
    // 数字判断

  }, {
    key: "isNumber",
    value: function isNumber(value) {
      var patrn = /^[-+]?\d+(\.\d+)?$/;
      return patrn.test(value);
    }

    // 数字判断

  }, {
    key: "isPositiveNumber",
    value: function isPositiveNumber(value) {
      var patrn = /^[1-9]\d*$|^\.\d*$|^0\.\d*$|^[1-9]\d*\.\d*$|^0$/;
      return patrn.test(value);
    }
    // 数组判断

  }, {
    key: "isArray",
    value: function isArray(o) {
      return Object.prototype.toString.call(o) === '[object Array]';
    }
    // 事件转日期

  }, {
    key: "convertTimestapeToDay",
    value: function convertTimestapeToDay(timestape) {
      return timestape.substring(0, timestape.indexOf(' ')).replace(/-/g, '.');
    }

    // 格式化日期

  }, {
    key: "dateFormate",
    value: function dateFormate(date, fmt) {
      var o = {
        'M+': date.getMonth() + 1,
        'd+': date.getDate(),
        'h+': date.getHours(),
        'm+': date.getMinutes(),
        's+': date.getSeconds(),
        'q+': Math.floor((date.getMonth() + 3) / 3),
        'S': date.getMilliseconds()
      };
      if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length));
      for (var k in o) {
        if (new RegExp('(' + k + ')').test(fmt)) fmt = fmt.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ('00' + o[k]).substr(('' + o[k]).length));
      }
      return fmt;
    }
    /**
     * 获取距离当前日期第n天的日期
     * @param {n} day
     */

  }, {
    key: "getDay",
    value: function getDay(day) {
      var today = new Date();
      var targetday_milliseconds = today.getTime() + 1000 * 60 * 60 * 24 * day;
      today.setTime(targetday_milliseconds); //注意，这行是关键代码
      var tYear = today.getFullYear();
      var tMonth = today.getMonth();
      var tDate = today.getDate();
      tMonth = this.doHandleMonth(tMonth + 1);
      tDate = this.doHandleMonth(tDate);
      return tYear + "-" + tMonth + "-" + tDate;
    }
  }, {
    key: "doHandleMonth",
    value: function doHandleMonth(month) {
      var m = month;
      if (month.toString().length == 1) {
        m = "0" + month;
      }
      return m;
    }
    // 检验身份证

  }, {
    key: "checkIdCard",
    value: function checkIdCard(IDCard) {
      var iSum = 0;
      var info = "";
      if (!/^\d{17}(\d|x)$/i.test(IDCard)) return {
        status: false,
        message: '输入的身份证长度或格式错误!'
      };
      IDCard = IDCard.replace(/x$/i, "a");
      // if (areaID[parseInt(IDCard.substr(0, 2))] == null)
      //   return {
      //     status: false,
      //     message: '输入的身份证有误!'
      //   };
      var sBirthday = IDCard.substr(6, 4) + "-" + Number(IDCard.substr(10, 2)) + "-" + Number(IDCard.substr(12, 2));
      var d = new Date(sBirthday.replace(/-/g, "/"));
      if (sBirthday != d.getFullYear() + "-" + (d.getMonth() + 1) + "-" + d.getDate()) return {
        status: false,
        message: '输入的身份证有误!'
      };
      for (var i = 17; i >= 0; i--) {
        iSum += Math.pow(2, i) % 11 * parseInt(IDCard.charAt(17 - i), 11);
      }if (iSum % 11 != 1) return {
        status: false,
        message: '输入的身份证有误!'
      };
      //aCity[parseInt(sId.substr(0,2))]+","+sBirthday+","+(sId.substr(16,1)%2?"男":"女");//此次还可以判断出输入的身份证号的人性别
      return {
        status: true,
        message: '校验成功！'
      };
    }
    // 身份证获取出生年月日

  }, {
    key: "getBirthdayByIdCard",
    value: function getBirthdayByIdCard(idCard) {
      // 校验身份证是否合法
      var _r = this.checkIdCard(idCard);
      if (!_r.status) {
        return _extends({}, _r);
      }
      var birthStr;
      if (15 == idCard.length) {
        birthStr = idCard.charAt(6) + idCard.charAt(7);
        if (parseInt(birthStr) < 10) {
          birthStr = '20' + birthStr;
        } else {
          birthStr = '19' + birthStr;
        }
        birthStr = birthStr + '-' + idCard.charAt(8) + idCard.charAt(9) + '-' + idCard.charAt(10) + idCard.charAt(11);
      } else if (18 == idCard.length) {
        birthStr = idCard.charAt(6) + idCard.charAt(7) + idCard.charAt(8) + idCard.charAt(9) + '-' + idCard.charAt(10) + idCard.charAt(11) + '-' + idCard.charAt(12) + idCard.charAt(13);
      }
      return birthStr;
    }
  }, {
    key: "getSexByIdCard",
    value: function getSexByIdCard(idCard) {
      if (idCard.length == 15) {
        return idCard.substring(14, 15) % 2;
      } else if (idCard.length == 18) {
        return idCard.substring(14, 17) % 2;
      } else {
        //不是15或者18,null
        return '';
      }
    }
  }]);

  return Lang;
}();

exports.default = Lang;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkxhbmcuanMiXSwibmFtZXMiOlsiTGFuZyIsImN1cnJlbnQiLCJ1cmxzIiwid3giLCJwcmV2aWV3SW1hZ2UiLCJ1cmwiLCJjYWxsYmFjayIsImRvd25sb2FkRmlsZSIsInN1Y2Nlc3MiLCJyZXMiLCJjb25zb2xlIiwibG9nIiwic2F2ZUltYWdlVG9QaG90b3NBbGJ1bSIsImZpbGVQYXRoIiwidGVtcEZpbGVQYXRoIiwiZGF0YSIsImNvZGUiLCJmYWlsIiwiZXJyIiwiZXJyTXNnIiwiY29tcGxldGUiLCJvcGVuU2V0dGluZyIsInNldHRpbmdkYXRhIiwiYXV0aFNldHRpbmciLCJzdHIiLCJpc0VtcHR5IiwibnVtYmVycyIsInRvRml4ZWQiLCJzdW0iLCJpc051bWJlciIsIk5hTiIsIm51bSIsInBhcnNlRmxvYXQiLCJpc05hTiIsInZhbHVlIiwicGF0cm4iLCJ0ZXN0IiwibyIsIk9iamVjdCIsInByb3RvdHlwZSIsInRvU3RyaW5nIiwiY2FsbCIsInRpbWVzdGFwZSIsInN1YnN0cmluZyIsImluZGV4T2YiLCJyZXBsYWNlIiwiZGF0ZSIsImZtdCIsImdldE1vbnRoIiwiZ2V0RGF0ZSIsImdldEhvdXJzIiwiZ2V0TWludXRlcyIsImdldFNlY29uZHMiLCJNYXRoIiwiZmxvb3IiLCJnZXRNaWxsaXNlY29uZHMiLCJSZWdFeHAiLCIkMSIsImdldEZ1bGxZZWFyIiwic3Vic3RyIiwibGVuZ3RoIiwiayIsImRheSIsInRvZGF5IiwiRGF0ZSIsInRhcmdldGRheV9taWxsaXNlY29uZHMiLCJnZXRUaW1lIiwic2V0VGltZSIsInRZZWFyIiwidE1vbnRoIiwidERhdGUiLCJkb0hhbmRsZU1vbnRoIiwibW9udGgiLCJtIiwiSURDYXJkIiwiaVN1bSIsImluZm8iLCJzdGF0dXMiLCJtZXNzYWdlIiwic0JpcnRoZGF5IiwiTnVtYmVyIiwiZCIsImkiLCJwb3ciLCJwYXJzZUludCIsImNoYXJBdCIsImlkQ2FyZCIsIl9yIiwiY2hlY2tJZENhcmQiLCJiaXJ0aFN0ciJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7SUFBcUJBLEk7Ozs7Ozs7aUNBQ0NDLE8sRUFBU0MsSSxFQUFNO0FBQ2pDQyxTQUFHQyxZQUFILENBQWdCO0FBQ2RILHdCQURjLEVBQ0w7QUFDVEMsa0JBRmMsQ0FFVDtBQUZTLE9BQWhCO0FBSUQ7Ozs0QkFDY0csRyxFQUFzQjtBQUFBLFVBQWpCQyxRQUFpQix1RUFBTixJQUFNOztBQUNuQ0gsU0FBR0ksWUFBSCxDQUFnQjtBQUNkRixnQkFEYztBQUVkRyxpQkFBUyxpQkFBU0MsR0FBVCxFQUFjO0FBQ3JCQyxrQkFBUUMsR0FBUixDQUFZRixHQUFaO0FBQ0E7QUFDQU4sYUFBR1Msc0JBQUgsQ0FBMEI7QUFDeEJDLHNCQUFVSixJQUFJSyxZQURVO0FBRXhCTjtBQUFBLGlGQUFTLGlCQUFlTyxJQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDUCw0QkFBSVQsUUFBSixFQUFjQSxTQUFTLEVBQUNVLE1BQUssQ0FBTixFQUFUOztBQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVQ7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUEsZUFGd0I7QUFLeEJDLGtCQUFNLGNBQVNDLEdBQVQsRUFBYztBQUNsQlIsc0JBQVFDLEdBQVIsQ0FBWU8sR0FBWjtBQUNBLGtCQUFJQSxJQUFJQyxNQUFKLEtBQWUsdUNBQW5CLEVBQTREO0FBQzFEVCx3QkFBUUMsR0FBUixDQUFZLGVBQVo7QUFDQSxvQkFBSUwsUUFBSixFQUFjQSxTQUFTLEVBQUNVLE1BQUssQ0FBQyxDQUFQLEVBQVQ7QUFDZjtBQUNGLGFBWHVCO0FBWXhCSSxvQkFad0Isb0JBWWZYLEdBWmUsRUFZVjtBQUNaQyxzQkFBUUMsR0FBUixDQUFZRixHQUFaO0FBQ0Q7QUFkdUIsV0FBMUI7QUFnQkQ7QUFyQmEsT0FBaEI7QUF1QkQ7OztrQ0FDbUI7QUFDbEJOLFNBQUdrQixXQUFILENBQWU7QUFDYmIsZUFEYSxtQkFDTGMsV0FESyxFQUNRO0FBQ25CLGNBQUlBLFlBQVlDLFdBQVosQ0FBd0Isd0JBQXhCLENBQUosRUFBdUQ7QUFDckRiLG9CQUFRQyxHQUFSLENBQVksMEJBQVo7QUFDRCxXQUZELE1BRU87QUFDTEQsb0JBQVFDLEdBQVIsQ0FBWSx5QkFBWjtBQUNEO0FBQ0Y7QUFQWSxPQUFmO0FBU0Q7QUFDRDs7Ozs0QkFDZWEsRyxFQUFLO0FBQ2xCLGFBQU9BLE9BQU8sRUFBUCxJQUFhQSxPQUFPLElBQXBCLElBQTRCQSxPQUFPLE1BQTFDO0FBQ0Q7QUFDRDs7OzsrQkFDa0JBLEcsRUFBSztBQUNyQixhQUFPLENBQUMsS0FBS0MsT0FBTCxDQUFhRCxHQUFiLENBQVI7QUFDRDtBQUNEOzs7O3dCQUNXRSxPLEVBQXNCO0FBQUEsVUFBYkMsT0FBYSx1RUFBSCxDQUFHOztBQUMvQixVQUFJQyxNQUFNLENBQVY7QUFEK0I7QUFBQTtBQUFBOztBQUFBO0FBRS9CLDZCQUFrQkYsT0FBbEIsOEhBQTJCO0FBQUEsY0FBaEJGLEdBQWdCOztBQUN6QixjQUFJLENBQUMsS0FBS0ssUUFBTCxDQUFjTCxHQUFkLENBQUwsRUFBeUI7QUFDdkIsbUJBQU9NLEdBQVA7QUFDRDtBQUNELGNBQU1DLE1BQU1DLFdBQVdSLEdBQVgsQ0FBWjtBQUNBLGNBQUlTLE1BQU1GLEdBQU4sQ0FBSixFQUFnQjtBQUNkLG1CQUFPRCxHQUFQO0FBQ0Q7QUFDREYsaUJBQU9HLEdBQVA7QUFDRDtBQVg4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQVkvQixhQUFPSCxJQUFJRCxPQUFKLENBQVlBLE9BQVosQ0FBUDtBQUNEO0FBQ0Q7Ozs7NkJBQ2dCTyxLLEVBQU87QUFDckIsVUFBTUMsUUFBUSxvQkFBZDtBQUNBLGFBQU9BLE1BQU1DLElBQU4sQ0FBV0YsS0FBWCxDQUFQO0FBQ0Q7O0FBRUQ7Ozs7cUNBQ3dCQSxLLEVBQU87QUFDN0IsVUFBTUMsUUFBUSxpREFBZDtBQUNBLGFBQU9BLE1BQU1DLElBQU4sQ0FBV0YsS0FBWCxDQUFQO0FBQ0Q7QUFDRDs7Ozs0QkFDZUcsQyxFQUFHO0FBQ2hCLGFBQU9DLE9BQU9DLFNBQVAsQ0FBaUJDLFFBQWpCLENBQTBCQyxJQUExQixDQUErQkosQ0FBL0IsTUFBc0MsZ0JBQTdDO0FBQ0Q7QUFDRDs7OzswQ0FDNkJLLFMsRUFBVztBQUN0QyxhQUFPQSxVQUFVQyxTQUFWLENBQW9CLENBQXBCLEVBQXVCRCxVQUFVRSxPQUFWLENBQWtCLEdBQWxCLENBQXZCLEVBQStDQyxPQUEvQyxDQUF1RCxJQUF2RCxFQUE2RCxHQUE3RCxDQUFQO0FBQ0Q7O0FBRUQ7Ozs7Z0NBQ21CQyxJLEVBQU1DLEcsRUFBSztBQUM1QixVQUFNVixJQUFJO0FBQ1IsY0FBTVMsS0FBS0UsUUFBTCxLQUFrQixDQURoQjtBQUVSLGNBQU1GLEtBQUtHLE9BQUwsRUFGRTtBQUdSLGNBQU1ILEtBQUtJLFFBQUwsRUFIRTtBQUlSLGNBQU1KLEtBQUtLLFVBQUwsRUFKRTtBQUtSLGNBQU1MLEtBQUtNLFVBQUwsRUFMRTtBQU1SLGNBQU1DLEtBQUtDLEtBQUwsQ0FBVyxDQUFDUixLQUFLRSxRQUFMLEtBQWtCLENBQW5CLElBQXdCLENBQW5DLENBTkU7QUFPUixhQUFLRixLQUFLUyxlQUFMO0FBUEcsT0FBVjtBQVNBLFVBQUksT0FBT25CLElBQVAsQ0FBWVcsR0FBWixDQUFKLEVBQXNCQSxNQUFNQSxJQUFJRixPQUFKLENBQVlXLE9BQU9DLEVBQW5CLEVBQXVCLENBQUNYLEtBQUtZLFdBQUwsS0FBcUIsRUFBdEIsRUFBMEJDLE1BQTFCLENBQWlDLElBQUlILE9BQU9DLEVBQVAsQ0FBVUcsTUFBL0MsQ0FBdkIsQ0FBTjtBQUN0QixXQUFLLElBQUlDLENBQVQsSUFBY3hCLENBQWQsRUFBaUI7QUFDZixZQUFJLElBQUltQixNQUFKLENBQVcsTUFBTUssQ0FBTixHQUFVLEdBQXJCLEVBQTBCekIsSUFBMUIsQ0FBK0JXLEdBQS9CLENBQUosRUFBeUNBLE1BQU1BLElBQUlGLE9BQUosQ0FBWVcsT0FBT0MsRUFBbkIsRUFBd0JELE9BQU9DLEVBQVAsQ0FBVUcsTUFBVixJQUFvQixDQUFyQixHQUEyQnZCLEVBQUV3QixDQUFGLENBQTNCLEdBQW9DLENBQ3hHLE9BQU94QixFQUFFd0IsQ0FBRixDQURpRyxFQUMzRkYsTUFEMkYsQ0FDcEYsQ0FBQyxLQUFLdEIsRUFBRXdCLENBQUYsQ0FBTixFQUFZRCxNQUR3RSxDQUEzRCxDQUFOO0FBRTFDO0FBQ0QsYUFBT2IsR0FBUDtBQUNEO0FBQ0Q7Ozs7Ozs7MkJBSWNlLEcsRUFBSztBQUNqQixVQUFJQyxRQUFRLElBQUlDLElBQUosRUFBWjtBQUNBLFVBQUlDLHlCQUF5QkYsTUFBTUcsT0FBTixLQUFrQixPQUFPLEVBQVAsR0FBWSxFQUFaLEdBQWlCLEVBQWpCLEdBQXNCSixHQUFyRTtBQUNBQyxZQUFNSSxPQUFOLENBQWNGLHNCQUFkLEVBSGlCLENBR3NCO0FBQ3ZDLFVBQUlHLFFBQVFMLE1BQU1MLFdBQU4sRUFBWjtBQUNBLFVBQUlXLFNBQVNOLE1BQU1mLFFBQU4sRUFBYjtBQUNBLFVBQUlzQixRQUFRUCxNQUFNZCxPQUFOLEVBQVo7QUFDQW9CLGVBQVMsS0FBS0UsYUFBTCxDQUFtQkYsU0FBUyxDQUE1QixDQUFUO0FBQ0FDLGNBQVEsS0FBS0MsYUFBTCxDQUFtQkQsS0FBbkIsQ0FBUjtBQUNBLGFBQU9GLFFBQVEsR0FBUixHQUFjQyxNQUFkLEdBQXVCLEdBQXZCLEdBQTZCQyxLQUFwQztBQUNEOzs7a0NBQ29CRSxLLEVBQU87QUFDMUIsVUFBSUMsSUFBSUQsS0FBUjtBQUNBLFVBQUlBLE1BQU1oQyxRQUFOLEdBQWlCb0IsTUFBakIsSUFBMkIsQ0FBL0IsRUFBa0M7QUFDaENhLFlBQUksTUFBTUQsS0FBVjtBQUNEO0FBQ0QsYUFBT0MsQ0FBUDtBQUNEO0FBQ0Q7Ozs7Z0NBQ21CQyxNLEVBQVE7QUFDekIsVUFBSUMsT0FBTyxDQUFYO0FBQ0EsVUFBSUMsT0FBTyxFQUFYO0FBQ0EsVUFBSSxDQUFDLGtCQUFrQnhDLElBQWxCLENBQXVCc0MsTUFBdkIsQ0FBTCxFQUNFLE9BQU87QUFDTEcsZ0JBQVEsS0FESDtBQUVMQyxpQkFBUztBQUZKLE9BQVA7QUFJRkosZUFBU0EsT0FBTzdCLE9BQVAsQ0FBZSxLQUFmLEVBQXNCLEdBQXRCLENBQVQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsVUFBSWtDLFlBQVlMLE9BQU9mLE1BQVAsQ0FBYyxDQUFkLEVBQWlCLENBQWpCLElBQXNCLEdBQXRCLEdBQTRCcUIsT0FBT04sT0FBT2YsTUFBUCxDQUFjLEVBQWQsRUFBa0IsQ0FBbEIsQ0FBUCxDQUE1QixHQUEyRCxHQUEzRCxHQUFpRXFCLE9BQU9OLE9BQU9mLE1BQVAsQ0FBYyxFQUFkLEVBQWtCLENBQWxCLENBQVAsQ0FBakY7QUFDQSxVQUFJc0IsSUFBSSxJQUFJakIsSUFBSixDQUFTZSxVQUFVbEMsT0FBVixDQUFrQixJQUFsQixFQUF3QixHQUF4QixDQUFULENBQVI7QUFDQSxVQUFJa0MsYUFBY0UsRUFBRXZCLFdBQUYsS0FBa0IsR0FBbEIsSUFBeUJ1QixFQUFFakMsUUFBRixLQUFlLENBQXhDLElBQTZDLEdBQTdDLEdBQW1EaUMsRUFBRWhDLE9BQUYsRUFBckUsRUFDRSxPQUFPO0FBQ0w0QixnQkFBUSxLQURIO0FBRUxDLGlCQUFTO0FBRkosT0FBUDtBQUlGLFdBQUssSUFBSUksSUFBSSxFQUFiLEVBQWlCQSxLQUFLLENBQXRCLEVBQXlCQSxHQUF6QjtBQUNFUCxnQkFBU3RCLEtBQUs4QixHQUFMLENBQVMsQ0FBVCxFQUFZRCxDQUFaLElBQWlCLEVBQWxCLEdBQXdCRSxTQUFTVixPQUFPVyxNQUFQLENBQWMsS0FBS0gsQ0FBbkIsQ0FBVCxFQUFnQyxFQUFoQyxDQUFoQztBQURGLE9BRUEsSUFBSVAsT0FBTyxFQUFQLElBQWEsQ0FBakIsRUFDRSxPQUFPO0FBQ0xFLGdCQUFRLEtBREg7QUFFTEMsaUJBQVM7QUFGSixPQUFQO0FBSUY7QUFDQSxhQUFPO0FBQ0xELGdCQUFRLElBREg7QUFFTEMsaUJBQVM7QUFGSixPQUFQO0FBSUQ7QUFDRDs7Ozt3Q0FDMkJRLE0sRUFBUTtBQUNqQztBQUNBLFVBQUlDLEtBQUssS0FBS0MsV0FBTCxDQUFpQkYsTUFBakIsQ0FBVDtBQUNBLFVBQUksQ0FBQ0MsR0FBR1YsTUFBUixFQUFnQjtBQUNkLDRCQUNLVSxFQURMO0FBR0Q7QUFDRCxVQUFJRSxRQUFKO0FBQ0EsVUFBSSxNQUFNSCxPQUFPMUIsTUFBakIsRUFBeUI7QUFDdkI2QixtQkFBV0gsT0FBT0QsTUFBUCxDQUFjLENBQWQsSUFBbUJDLE9BQU9ELE1BQVAsQ0FBYyxDQUFkLENBQTlCO0FBQ0EsWUFBSUQsU0FBU0ssUUFBVCxJQUFxQixFQUF6QixFQUE2QjtBQUMzQkEscUJBQVcsT0FBT0EsUUFBbEI7QUFDRCxTQUZELE1BRU87QUFDTEEscUJBQVcsT0FBT0EsUUFBbEI7QUFDRDtBQUNEQSxtQkFBV0EsV0FBVyxHQUFYLEdBQWlCSCxPQUFPRCxNQUFQLENBQWMsQ0FBZCxDQUFqQixHQUFvQ0MsT0FBT0QsTUFBUCxDQUFjLENBQWQsQ0FBcEMsR0FBdUQsR0FBdkQsR0FBNkRDLE9BQU9ELE1BQVAsQ0FBYyxFQUFkLENBQTdELEdBQWlGQyxPQUFPRCxNQUFQLENBQWMsRUFBZCxDQUE1RjtBQUNELE9BUkQsTUFRTyxJQUFJLE1BQU1DLE9BQU8xQixNQUFqQixFQUF5QjtBQUM5QjZCLG1CQUFXSCxPQUFPRCxNQUFQLENBQWMsQ0FBZCxJQUFtQkMsT0FBT0QsTUFBUCxDQUFjLENBQWQsQ0FBbkIsR0FBc0NDLE9BQU9ELE1BQVAsQ0FBYyxDQUFkLENBQXRDLEdBQXlEQyxPQUFPRCxNQUFQLENBQWMsQ0FBZCxDQUF6RCxHQUE0RSxHQUE1RSxHQUFrRkMsT0FBT0QsTUFBUCxDQUFjLEVBQWQsQ0FBbEYsR0FDVEMsT0FBT0QsTUFBUCxDQUFjLEVBQWQsQ0FEUyxHQUNXLEdBRFgsR0FDaUJDLE9BQU9ELE1BQVAsQ0FBYyxFQUFkLENBRGpCLEdBQ3FDQyxPQUFPRCxNQUFQLENBQWMsRUFBZCxDQURoRDtBQUVEO0FBQ0QsYUFBT0ksUUFBUDtBQUNEOzs7bUNBQ3FCSCxNLEVBQVE7QUFDNUIsVUFBSUEsT0FBTzFCLE1BQVAsSUFBaUIsRUFBckIsRUFBeUI7QUFDdkIsZUFBTzBCLE9BQU8zQyxTQUFQLENBQWlCLEVBQWpCLEVBQXFCLEVBQXJCLElBQTJCLENBQWxDO0FBQ0QsT0FGRCxNQUVPLElBQUkyQyxPQUFPMUIsTUFBUCxJQUFpQixFQUFyQixFQUF5QjtBQUM5QixlQUFPMEIsT0FBTzNDLFNBQVAsQ0FBaUIsRUFBakIsRUFBcUIsRUFBckIsSUFBMkIsQ0FBbEM7QUFDRCxPQUZNLE1BRUE7QUFDTDtBQUNBLGVBQU8sRUFBUDtBQUNEO0FBQ0Y7Ozs7OztrQkFsTWtCM0MsSSIsImZpbGUiOiJMYW5nLmpzIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGRlZmF1bHQgY2xhc3MgTGFuZyB7XHJcbiAgc3RhdGljIHByZXZpZXdJbWFnZShjdXJyZW50LCB1cmxzKSB7XHJcbiAgICB3eC5wcmV2aWV3SW1hZ2Uoe1xyXG4gICAgICBjdXJyZW50LCAvLyDlvZPliY3mmL7npLrlm77niYfnmoRodHRw6ZO+5o6lXHJcbiAgICAgIHVybHMgLy8g6ZyA6KaB6aKE6KeI55qE5Zu+54mHaHR0cOmTvuaOpeWIl+ihqFxyXG4gICAgfSlcclxuICB9XHJcbiAgc3RhdGljIGRvd25JbWcodXJsLCBjYWxsYmFjayA9IG51bGwpIHtcclxuICAgIHd4LmRvd25sb2FkRmlsZSh7XHJcbiAgICAgIHVybCxcclxuICAgICAgc3VjY2VzczogZnVuY3Rpb24ocmVzKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2cocmVzKTtcclxuICAgICAgICAvL+WbvueJh+S/neWtmOWIsOacrOWcsFxyXG4gICAgICAgIHd4LnNhdmVJbWFnZVRvUGhvdG9zQWxidW0oe1xyXG4gICAgICAgICAgZmlsZVBhdGg6IHJlcy50ZW1wRmlsZVBhdGgsXHJcbiAgICAgICAgICBzdWNjZXNzOiBhc3luYyBmdW5jdGlvbihkYXRhKSB7XHJcbiAgICAgICAgICAgIGlmIChjYWxsYmFjaykgY2FsbGJhY2soe2NvZGU6MH0pXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgZmFpbDogZnVuY3Rpb24oZXJyKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycik7XHJcbiAgICAgICAgICAgIGlmIChlcnIuZXJyTXNnID09PSBcInNhdmVJbWFnZVRvUGhvdG9zQWxidW06ZmFpbCBhdXRoIGRlbnlcIikge1xyXG4gICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi5b2T5YmN55So5oi35ouS57ud77yM5YaN5qyh5Y+R6LW35o6I5p2DXCIpXG4gICAgICAgICAgICAgIGlmIChjYWxsYmFjaykgY2FsbGJhY2soe2NvZGU6LTF9KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgY29tcGxldGUocmVzKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKHJlcyk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSlcclxuICAgICAgfVxyXG4gICAgfSlcclxuICB9XG4gIHN0YXRpYyBvcGVuU2V0dGluZygpe1xuICAgIHd4Lm9wZW5TZXR0aW5nKHtcbiAgICAgIHN1Y2Nlc3Moc2V0dGluZ2RhdGEpIHtcbiAgICAgICAgaWYgKHNldHRpbmdkYXRhLmF1dGhTZXR0aW5nWydzY29wZS53cml0ZVBob3Rvc0FsYnVtJ10pIHtcbiAgICAgICAgICBjb25zb2xlLmxvZygn6I635Y+W5p2D6ZmQ5oiQ5Yqf77yM57uZ5Ye65YaN5qyh54K55Ye75Zu+54mH5L+d5a2Y5Yiw55u45YaM55qE5o+Q56S644CCJylcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjb25zb2xlLmxvZygn6I635Y+W5p2D6ZmQ5aSx6LSl77yM57uZ5Ye65LiN57uZ5p2D6ZmQ5bCx5peg5rOV5q2j5bi45L2/55So55qE5o+Q56S6JylcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pXG4gIH1cclxuICAvLyDliKTmlq3lrZfnrKbkuLLmmK/lkKbkuLrnqbpcclxuICBzdGF0aWMgaXNFbXB0eShzdHIpIHtcclxuICAgIHJldHVybiBzdHIgPT0gJycgfHwgc3RyID09IG51bGwgfHwgc3RyID09ICdudWxsJztcclxuICB9XHJcbiAgLy8g5Yik5pat5a2X56ym5Liy5piv5ZCm5LiN5Li656m6XHJcbiAgc3RhdGljIGlzTm90RW1wdHkoc3RyKSB7XHJcbiAgICByZXR1cm4gIXRoaXMuaXNFbXB0eShzdHIpO1xyXG4gIH1cclxuICAvLyDmta7ngrnmsYLlkoxcclxuICBzdGF0aWMgc3VtKG51bWJlcnMsIHRvRml4ZWQgPSAyKSB7XHJcbiAgICBsZXQgc3VtID0gMDtcclxuICAgIGZvciAoY29uc3Qgc3RyIG9mIG51bWJlcnMpIHtcclxuICAgICAgaWYgKCF0aGlzLmlzTnVtYmVyKHN0cikpIHtcclxuICAgICAgICByZXR1cm4gTmFOO1xyXG4gICAgICB9XHJcbiAgICAgIGNvbnN0IG51bSA9IHBhcnNlRmxvYXQoc3RyKTtcclxuICAgICAgaWYgKGlzTmFOKG51bSkpIHtcclxuICAgICAgICByZXR1cm4gTmFOO1xyXG4gICAgICB9XHJcbiAgICAgIHN1bSArPSBudW07XHJcbiAgICB9XHJcbiAgICByZXR1cm4gc3VtLnRvRml4ZWQodG9GaXhlZCk7XHJcbiAgfVxyXG4gIC8vIOaVsOWtl+WIpOaWrVxyXG4gIHN0YXRpYyBpc051bWJlcih2YWx1ZSkge1xyXG4gICAgY29uc3QgcGF0cm4gPSAvXlstK10/XFxkKyhcXC5cXGQrKT8kLztcclxuICAgIHJldHVybiBwYXRybi50ZXN0KHZhbHVlKTtcclxuICB9XHJcblxyXG4gIC8vIOaVsOWtl+WIpOaWrVxyXG4gIHN0YXRpYyBpc1Bvc2l0aXZlTnVtYmVyKHZhbHVlKSB7XHJcbiAgICBjb25zdCBwYXRybiA9IC9eWzEtOV1cXGQqJHxeXFwuXFxkKiR8XjBcXC5cXGQqJHxeWzEtOV1cXGQqXFwuXFxkKiR8XjAkLztcclxuICAgIHJldHVybiBwYXRybi50ZXN0KHZhbHVlKTtcclxuICB9XHJcbiAgLy8g5pWw57uE5Yik5patXHJcbiAgc3RhdGljIGlzQXJyYXkobykge1xyXG4gICAgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbChvKSA9PT0gJ1tvYmplY3QgQXJyYXldJztcclxuICB9XHJcbiAgLy8g5LqL5Lu26L2s5pel5pyfXHJcbiAgc3RhdGljIGNvbnZlcnRUaW1lc3RhcGVUb0RheSh0aW1lc3RhcGUpIHtcclxuICAgIHJldHVybiB0aW1lc3RhcGUuc3Vic3RyaW5nKDAsIHRpbWVzdGFwZS5pbmRleE9mKCcgJykpLnJlcGxhY2UoLy0vZywgJy4nKTtcclxuICB9XHJcblxyXG4gIC8vIOagvOW8j+WMluaXpeacn1xyXG4gIHN0YXRpYyBkYXRlRm9ybWF0ZShkYXRlLCBmbXQpIHtcclxuICAgIGNvbnN0IG8gPSB7XHJcbiAgICAgICdNKyc6IGRhdGUuZ2V0TW9udGgoKSArIDEsXHJcbiAgICAgICdkKyc6IGRhdGUuZ2V0RGF0ZSgpLFxyXG4gICAgICAnaCsnOiBkYXRlLmdldEhvdXJzKCksXHJcbiAgICAgICdtKyc6IGRhdGUuZ2V0TWludXRlcygpLFxyXG4gICAgICAncysnOiBkYXRlLmdldFNlY29uZHMoKSxcclxuICAgICAgJ3ErJzogTWF0aC5mbG9vcigoZGF0ZS5nZXRNb250aCgpICsgMykgLyAzKSxcclxuICAgICAgJ1MnOiBkYXRlLmdldE1pbGxpc2Vjb25kcygpXHJcbiAgICB9O1xyXG4gICAgaWYgKC8oeSspLy50ZXN0KGZtdCkpIGZtdCA9IGZtdC5yZXBsYWNlKFJlZ0V4cC4kMSwgKGRhdGUuZ2V0RnVsbFllYXIoKSArICcnKS5zdWJzdHIoNCAtIFJlZ0V4cC4kMS5sZW5ndGgpKTtcclxuICAgIGZvciAobGV0IGsgaW4gbykge1xyXG4gICAgICBpZiAobmV3IFJlZ0V4cCgnKCcgKyBrICsgJyknKS50ZXN0KGZtdCkpIGZtdCA9IGZtdC5yZXBsYWNlKFJlZ0V4cC4kMSwgKFJlZ0V4cC4kMS5sZW5ndGggPT0gMSkgPyAob1trXSkgOiAoKFxyXG4gICAgICAgICcwMCcgKyBvW2tdKS5zdWJzdHIoKCcnICsgb1trXSkubGVuZ3RoKSkpO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIGZtdDtcclxuICB9XHJcbiAgLyoqXHJcbiAgICog6I635Y+W6Led56a75b2T5YmN5pel5pyf56ysbuWkqeeahOaXpeacn1xyXG4gICAqIEBwYXJhbSB7bn0gZGF5XHJcbiAgICovXHJcbiAgc3RhdGljIGdldERheShkYXkpIHtcclxuICAgIHZhciB0b2RheSA9IG5ldyBEYXRlKCk7XHJcbiAgICB2YXIgdGFyZ2V0ZGF5X21pbGxpc2Vjb25kcyA9IHRvZGF5LmdldFRpbWUoKSArIDEwMDAgKiA2MCAqIDYwICogMjQgKiBkYXk7XHJcbiAgICB0b2RheS5zZXRUaW1lKHRhcmdldGRheV9taWxsaXNlY29uZHMpOyAvL+azqOaEj++8jOi/meihjOaYr+WFs+mUruS7o+eggVxyXG4gICAgdmFyIHRZZWFyID0gdG9kYXkuZ2V0RnVsbFllYXIoKTtcclxuICAgIHZhciB0TW9udGggPSB0b2RheS5nZXRNb250aCgpO1xyXG4gICAgdmFyIHREYXRlID0gdG9kYXkuZ2V0RGF0ZSgpO1xyXG4gICAgdE1vbnRoID0gdGhpcy5kb0hhbmRsZU1vbnRoKHRNb250aCArIDEpO1xyXG4gICAgdERhdGUgPSB0aGlzLmRvSGFuZGxlTW9udGgodERhdGUpO1xyXG4gICAgcmV0dXJuIHRZZWFyICsgXCItXCIgKyB0TW9udGggKyBcIi1cIiArIHREYXRlO1xyXG4gIH1cclxuICBzdGF0aWMgZG9IYW5kbGVNb250aChtb250aCkge1xyXG4gICAgdmFyIG0gPSBtb250aDtcclxuICAgIGlmIChtb250aC50b1N0cmluZygpLmxlbmd0aCA9PSAxKSB7XHJcbiAgICAgIG0gPSBcIjBcIiArIG1vbnRoO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIG07XHJcbiAgfVxyXG4gIC8vIOajgOmqjOi6q+S7veivgVxyXG4gIHN0YXRpYyBjaGVja0lkQ2FyZChJRENhcmQpIHtcclxuICAgIHZhciBpU3VtID0gMDtcclxuICAgIHZhciBpbmZvID0gXCJcIjtcclxuICAgIGlmICghL15cXGR7MTd9KFxcZHx4KSQvaS50ZXN0KElEQ2FyZCkpXHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAgc3RhdHVzOiBmYWxzZSxcclxuICAgICAgICBtZXNzYWdlOiAn6L6T5YWl55qE6Lqr5Lu96K+B6ZW/5bqm5oiW5qC85byP6ZSZ6K+vISdcclxuICAgICAgfTtcclxuICAgIElEQ2FyZCA9IElEQ2FyZC5yZXBsYWNlKC94JC9pLCBcImFcIik7XHJcbiAgICAvLyBpZiAoYXJlYUlEW3BhcnNlSW50KElEQ2FyZC5zdWJzdHIoMCwgMikpXSA9PSBudWxsKVxyXG4gICAgLy8gICByZXR1cm4ge1xyXG4gICAgLy8gICAgIHN0YXR1czogZmFsc2UsXHJcbiAgICAvLyAgICAgbWVzc2FnZTogJ+i+k+WFpeeahOi6q+S7veivgeacieivryEnXHJcbiAgICAvLyAgIH07XHJcbiAgICB2YXIgc0JpcnRoZGF5ID0gSURDYXJkLnN1YnN0cig2LCA0KSArIFwiLVwiICsgTnVtYmVyKElEQ2FyZC5zdWJzdHIoMTAsIDIpKSArIFwiLVwiICsgTnVtYmVyKElEQ2FyZC5zdWJzdHIoMTIsIDIpKTtcclxuICAgIHZhciBkID0gbmV3IERhdGUoc0JpcnRoZGF5LnJlcGxhY2UoLy0vZywgXCIvXCIpKTtcclxuICAgIGlmIChzQmlydGhkYXkgIT0gKGQuZ2V0RnVsbFllYXIoKSArIFwiLVwiICsgKGQuZ2V0TW9udGgoKSArIDEpICsgXCItXCIgKyBkLmdldERhdGUoKSkpXHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAgc3RhdHVzOiBmYWxzZSxcclxuICAgICAgICBtZXNzYWdlOiAn6L6T5YWl55qE6Lqr5Lu96K+B5pyJ6K+vISdcclxuICAgICAgfTtcclxuICAgIGZvciAodmFyIGkgPSAxNzsgaSA+PSAwOyBpLS0pXHJcbiAgICAgIGlTdW0gKz0gKE1hdGgucG93KDIsIGkpICUgMTEpICogcGFyc2VJbnQoSURDYXJkLmNoYXJBdCgxNyAtIGkpLCAxMSk7XHJcbiAgICBpZiAoaVN1bSAlIDExICE9IDEpXHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAgc3RhdHVzOiBmYWxzZSxcclxuICAgICAgICBtZXNzYWdlOiAn6L6T5YWl55qE6Lqr5Lu96K+B5pyJ6K+vISdcclxuICAgICAgfTtcclxuICAgIC8vYUNpdHlbcGFyc2VJbnQoc0lkLnN1YnN0cigwLDIpKV0rXCIsXCIrc0JpcnRoZGF5K1wiLFwiKyhzSWQuc3Vic3RyKDE2LDEpJTI/XCLnlLdcIjpcIuWls1wiKTsvL+atpOasoei/mOWPr+S7peWIpOaWreWHuui+k+WFpeeahOi6q+S7veivgeWPt+eahOS6uuaAp+WIq1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgc3RhdHVzOiB0cnVlLFxyXG4gICAgICBtZXNzYWdlOiAn5qCh6aqM5oiQ5Yqf77yBJ1xyXG4gICAgfTtcclxuICB9XHJcbiAgLy8g6Lqr5Lu96K+B6I635Y+W5Ye655Sf5bm05pyI5pelXHJcbiAgc3RhdGljIGdldEJpcnRoZGF5QnlJZENhcmQoaWRDYXJkKSB7XHJcbiAgICAvLyDmoKHpqozouqvku73or4HmmK/lkKblkIjms5VcclxuICAgIGxldCBfciA9IHRoaXMuY2hlY2tJZENhcmQoaWRDYXJkKVxyXG4gICAgaWYgKCFfci5zdGF0dXMpIHtcclxuICAgICAgcmV0dXJuIHtcclxuICAgICAgICAuLi5fclxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICB2YXIgYmlydGhTdHI7XHJcbiAgICBpZiAoMTUgPT0gaWRDYXJkLmxlbmd0aCkge1xyXG4gICAgICBiaXJ0aFN0ciA9IGlkQ2FyZC5jaGFyQXQoNikgKyBpZENhcmQuY2hhckF0KDcpO1xyXG4gICAgICBpZiAocGFyc2VJbnQoYmlydGhTdHIpIDwgMTApIHtcclxuICAgICAgICBiaXJ0aFN0ciA9ICcyMCcgKyBiaXJ0aFN0cjtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBiaXJ0aFN0ciA9ICcxOScgKyBiaXJ0aFN0cjtcclxuICAgICAgfVxyXG4gICAgICBiaXJ0aFN0ciA9IGJpcnRoU3RyICsgJy0nICsgaWRDYXJkLmNoYXJBdCg4KSArIGlkQ2FyZC5jaGFyQXQoOSkgKyAnLScgKyBpZENhcmQuY2hhckF0KDEwKSArIGlkQ2FyZC5jaGFyQXQoMTEpO1xyXG4gICAgfSBlbHNlIGlmICgxOCA9PSBpZENhcmQubGVuZ3RoKSB7XHJcbiAgICAgIGJpcnRoU3RyID0gaWRDYXJkLmNoYXJBdCg2KSArIGlkQ2FyZC5jaGFyQXQoNykgKyBpZENhcmQuY2hhckF0KDgpICsgaWRDYXJkLmNoYXJBdCg5KSArICctJyArIGlkQ2FyZC5jaGFyQXQoMTApICtcclxuICAgICAgICBpZENhcmQuY2hhckF0KDExKSArICctJyArIGlkQ2FyZC5jaGFyQXQoMTIpICsgaWRDYXJkLmNoYXJBdCgxMyk7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gYmlydGhTdHI7XHJcbiAgfVxyXG4gIHN0YXRpYyBnZXRTZXhCeUlkQ2FyZChpZENhcmQpIHtcclxuICAgIGlmIChpZENhcmQubGVuZ3RoID09IDE1KSB7XHJcbiAgICAgIHJldHVybiBpZENhcmQuc3Vic3RyaW5nKDE0LCAxNSkgJSAyO1xyXG4gICAgfSBlbHNlIGlmIChpZENhcmQubGVuZ3RoID09IDE4KSB7XHJcbiAgICAgIHJldHVybiBpZENhcmQuc3Vic3RyaW5nKDE0LCAxNykgJSAyO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgLy/kuI3mmK8xNeaIluiAhTE4LG51bGxcclxuICAgICAgcmV0dXJuICcnO1xyXG4gICAgfVxyXG4gIH1cclxufVxuIl19