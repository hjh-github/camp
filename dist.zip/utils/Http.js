'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _Tips = require('./Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

// HTTP工具类
var http = function () {
  function http() {
    _classCallCheck(this, http);
  }

  _createClass(http, null, [{
    key: 'request',
    value: function () {
      var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(method, url, data) {
        var loading = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : true;
        var msg = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : false;

        var _this = this;

        var form = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : false;
        var needToken = arguments.length > 6 && arguments[6] !== undefined ? arguments[6] : true;

        var param, _data;

        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                param = {
                  url: url,
                  method: method,
                  data: data,
                  header: {
                    "Content-Type": "application/x-www-form-urlencoded"
                  }
                };


                if (loading) {
                  // store.save('loading', true)
                  // Tips.loading();
                  wx.showNavigationBarLoading();
                }
                // 网络连接超时
                _data = void 0;
                _context.next = 5;
                return _wepy2.default.request(param).then(function (res) {
                  // console.log(res,'resulte')
                  if (loading) {
                    // store.save('loading', false)
                    // Tips.loaded();
                    wx.hideNavigationBarLoading();
                  }
                  if (res.data.errcode == 401) {
                    if (res.data.errmsg) _Tips2.default.toast(res.data.errmsg, function () {
                      _wepy2.default.$instance.globalData.sessionId = '';
                      _wepy2.default.reLaunch({ url: '/pages/home/index' });
                    }, "none");
                    return;
                  }
                  if (res.data.errcode != 200) {
                    if (res.data.errmsg) _Tips2.default.toast(res.data.errmsg, function () {}, "none");
                  }
                  if (_this.isSuccess(res)) {
                    _data = !msg ? res.data.data : res.data;
                  } else {
                    throw _this.requestException(res);
                  }
                }).catch(function (err) {
                  if (loading) {
                    // store.save('loading', false)
                    // Tips.loaded();
                    wx.hideNavigationBarLoading();
                  }
                  console.log(err);
                  // Tips.loaded();
                  _Tips2.default.toast("网络连接超时，请重试", function () {}, "none");
                  // 用于出现网络出错时的重连
                  _data = 'request error';
                });

              case 5:
                return _context.abrupt('return', _data);

              case 6:
              case 'end':
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function request(_x5, _x6, _x7) {
        return _ref.apply(this, arguments);
      }

      return request;
    }()

    /**
     * 判断请求是否成功
     */

  }, {
    key: 'isSuccess',
    value: function isSuccess(res) {
      var wxCode = res.statusCode;
      // 微信请求错误
      if (wxCode !== 200) {
        return false;
      }

      return true;
    }

    /**
     * 异常
     */

  }, {
    key: 'requestException',
    value: function requestException(res) {
      var error = {};
      error.statusCode = res.statusCode;
      var wxData = res.data;
      var serverData = wxData.data;
      if (serverData) {
        error.serverCode = wxData.code;
        error.message = serverData.message;
        error.serverData = serverData;
      }
      return error;
    }
  }, {
    key: 'get',
    value: function get(url, data) {
      var loading = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : true;
      var msg = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : false;

      return this.request('GET', url, data, loading, msg);
    }
  }, {
    key: 'put',
    value: function put(url, data) {
      var loading = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : true;
      var msg = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : false;

      return this.request('PUT', url, data, loading, msg);
    }
  }, {
    key: 'post',
    value: function post(url, data) {
      var loading = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : true;
      var msg = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : false;
      var form = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : false;
      var needToken = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : true;

      return this.request('POST', url, data, loading, msg, form, needToken);
    }
  }, {
    key: 'patch',
    value: function patch(url, data) {
      var loading = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : true;
      var msg = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : false;

      return this.request('PATCH', url, data, loading, msg);
    }
  }, {
    key: 'delete',
    value: function _delete(url, data) {
      var loading = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : true;
      var msg = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : false;

      return this.request('DELETE', url, data, loading, msg);
    }
  }]);

  return http;
}();

exports.default = http;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkh0dHAuanMiXSwibmFtZXMiOlsiaHR0cCIsIm1ldGhvZCIsInVybCIsImRhdGEiLCJsb2FkaW5nIiwibXNnIiwiZm9ybSIsIm5lZWRUb2tlbiIsInBhcmFtIiwiaGVhZGVyIiwid3giLCJzaG93TmF2aWdhdGlvbkJhckxvYWRpbmciLCJfZGF0YSIsIndlcHkiLCJyZXF1ZXN0IiwidGhlbiIsImhpZGVOYXZpZ2F0aW9uQmFyTG9hZGluZyIsInJlcyIsImVycmNvZGUiLCJlcnJtc2ciLCJUaXBzIiwidG9hc3QiLCIkaW5zdGFuY2UiLCJnbG9iYWxEYXRhIiwic2Vzc2lvbklkIiwicmVMYXVuY2giLCJpc1N1Y2Nlc3MiLCJyZXF1ZXN0RXhjZXB0aW9uIiwiY2F0Y2giLCJjb25zb2xlIiwibG9nIiwiZXJyIiwid3hDb2RlIiwic3RhdHVzQ29kZSIsImVycm9yIiwid3hEYXRhIiwic2VydmVyRGF0YSIsInNlcnZlckNvZGUiLCJjb2RlIiwibWVzc2FnZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQUE7Ozs7QUFDQTs7Ozs7Ozs7OztBQUNBO0lBQ3FCQSxJOzs7Ozs7OzswRkFDRUMsTSxFQUFRQyxHLEVBQUtDLEk7WUFBTUMsTyx1RUFBVSxJO1lBQU1DLEcsdUVBQU0sSzs7OztZQUFPQyxJLHVFQUFPLEs7WUFBT0MsUyx1RUFBWSxJOzs7Ozs7OztBQUV2RkMscUIsR0FBUTtBQUNaTix1QkFBS0EsR0FETztBQUVaRCwwQkFBUUEsTUFGSTtBQUdaRSx3QkFBTUEsSUFITTtBQUlaTSwwQkFBUTtBQUNOLG9DQUFnQjtBQURWO0FBSkksaUI7OztBQVNkLG9CQUFJTCxPQUFKLEVBQWE7QUFDWDtBQUNBO0FBQ0FNLHFCQUFHQyx3QkFBSDtBQUNEO0FBQ0Q7QUFDSUMscUI7O3VCQUNFQyxlQUFLQyxPQUFMLENBQWFOLEtBQWIsRUFBb0JPLElBQXBCLENBQXlCLGVBQU87QUFDcEM7QUFDQSxzQkFBSVgsT0FBSixFQUFhO0FBQ1g7QUFDQTtBQUNBTSx1QkFBR00sd0JBQUg7QUFDRDtBQUNELHNCQUFHQyxJQUFJZCxJQUFKLENBQVNlLE9BQVQsSUFBb0IsR0FBdkIsRUFBMkI7QUFDdkIsd0JBQUlELElBQUlkLElBQUosQ0FBU2dCLE1BQWIsRUFBcUJDLGVBQUtDLEtBQUwsQ0FBV0osSUFBSWQsSUFBSixDQUFTZ0IsTUFBcEIsRUFBNEIsWUFBTTtBQUNyRE4scUNBQUtTLFNBQUwsQ0FBZUMsVUFBZixDQUEwQkMsU0FBMUIsR0FBc0MsRUFBdEM7QUFDQVgscUNBQUtZLFFBQUwsQ0FBYyxFQUFFdkIsS0FBSyxtQkFBUCxFQUFkO0FBQ0QscUJBSG9CLEVBR2xCLE1BSGtCO0FBSXZCO0FBQ0Q7QUFDRCxzQkFBSWUsSUFBSWQsSUFBSixDQUFTZSxPQUFULElBQW9CLEdBQXhCLEVBQTZCO0FBQzNCLHdCQUFJRCxJQUFJZCxJQUFKLENBQVNnQixNQUFiLEVBQXFCQyxlQUFLQyxLQUFMLENBQVdKLElBQUlkLElBQUosQ0FBU2dCLE1BQXBCLEVBQTRCLFlBQU0sQ0FBRyxDQUFyQyxFQUF1QyxNQUF2QztBQUN0QjtBQUNELHNCQUFJLE1BQUtPLFNBQUwsQ0FBZVQsR0FBZixDQUFKLEVBQXlCO0FBQ3ZCTCw0QkFBUSxDQUFDUCxHQUFELEdBQU9ZLElBQUlkLElBQUosQ0FBU0EsSUFBaEIsR0FBdUJjLElBQUlkLElBQW5DO0FBQ0QsbUJBRkQsTUFFTztBQUNMLDBCQUFNLE1BQUt3QixnQkFBTCxDQUFzQlYsR0FBdEIsQ0FBTjtBQUNEO0FBQ0YsaUJBdEJLLEVBc0JIVyxLQXRCRyxDQXNCRyxlQUFPO0FBQ2Qsc0JBQUl4QixPQUFKLEVBQWE7QUFDWDtBQUNBO0FBQ0FNLHVCQUFHTSx3QkFBSDtBQUNEO0FBQ0RhLDBCQUFRQyxHQUFSLENBQVlDLEdBQVo7QUFDQTtBQUNBWCxpQ0FBS0MsS0FBTCxDQUFXLFlBQVgsRUFBeUIsWUFBTSxDQUFHLENBQWxDLEVBQW9DLE1BQXBDO0FBQ0E7QUFDQVQsMEJBQVEsZUFBUjtBQUNELGlCQWpDSyxDOzs7aURBa0NDQSxLOzs7Ozs7Ozs7Ozs7Ozs7OztBQUdUOzs7Ozs7OEJBR2lCSyxHLEVBQUs7QUFDcEIsVUFBTWUsU0FBU2YsSUFBSWdCLFVBQW5CO0FBQ0E7QUFDQSxVQUFJRCxXQUFXLEdBQWYsRUFBb0I7QUFDbEIsZUFBTyxLQUFQO0FBQ0Q7O0FBRUQsYUFBTyxJQUFQO0FBQ0Q7O0FBRUQ7Ozs7OztxQ0FHd0JmLEcsRUFBSztBQUMzQixVQUFNaUIsUUFBUSxFQUFkO0FBQ0FBLFlBQU1ELFVBQU4sR0FBbUJoQixJQUFJZ0IsVUFBdkI7QUFDQSxVQUFNRSxTQUFTbEIsSUFBSWQsSUFBbkI7QUFDQSxVQUFNaUMsYUFBYUQsT0FBT2hDLElBQTFCO0FBQ0EsVUFBSWlDLFVBQUosRUFBZ0I7QUFDZEYsY0FBTUcsVUFBTixHQUFtQkYsT0FBT0csSUFBMUI7QUFDQUosY0FBTUssT0FBTixHQUFnQkgsV0FBV0csT0FBM0I7QUFDQUwsY0FBTUUsVUFBTixHQUFtQkEsVUFBbkI7QUFDRDtBQUNELGFBQU9GLEtBQVA7QUFDRDs7O3dCQUVVaEMsRyxFQUFLQyxJLEVBQW1DO0FBQUEsVUFBN0JDLE9BQTZCLHVFQUFuQixJQUFtQjtBQUFBLFVBQWJDLEdBQWEsdUVBQVAsS0FBTzs7QUFDakQsYUFBTyxLQUFLUyxPQUFMLENBQWEsS0FBYixFQUFvQlosR0FBcEIsRUFBeUJDLElBQXpCLEVBQStCQyxPQUEvQixFQUF3Q0MsR0FBeEMsQ0FBUDtBQUNEOzs7d0JBRVVILEcsRUFBS0MsSSxFQUFtQztBQUFBLFVBQTdCQyxPQUE2Qix1RUFBbkIsSUFBbUI7QUFBQSxVQUFiQyxHQUFhLHVFQUFQLEtBQU87O0FBQ2pELGFBQU8sS0FBS1MsT0FBTCxDQUFhLEtBQWIsRUFBb0JaLEdBQXBCLEVBQXlCQyxJQUF6QixFQUErQkMsT0FBL0IsRUFBd0NDLEdBQXhDLENBQVA7QUFDRDs7O3lCQUVXSCxHLEVBQUtDLEksRUFBbUU7QUFBQSxVQUE3REMsT0FBNkQsdUVBQW5ELElBQW1EO0FBQUEsVUFBN0NDLEdBQTZDLHVFQUF2QyxLQUF1QztBQUFBLFVBQWhDQyxJQUFnQyx1RUFBekIsS0FBeUI7QUFBQSxVQUFsQkMsU0FBa0IsdUVBQU4sSUFBTTs7QUFDbEYsYUFBTyxLQUFLTyxPQUFMLENBQWEsTUFBYixFQUFxQlosR0FBckIsRUFBMEJDLElBQTFCLEVBQWdDQyxPQUFoQyxFQUF5Q0MsR0FBekMsRUFBOENDLElBQTlDLEVBQW9EQyxTQUFwRCxDQUFQO0FBQ0Q7OzswQkFFWUwsRyxFQUFLQyxJLEVBQW1DO0FBQUEsVUFBN0JDLE9BQTZCLHVFQUFuQixJQUFtQjtBQUFBLFVBQWJDLEdBQWEsdUVBQVAsS0FBTzs7QUFDbkQsYUFBTyxLQUFLUyxPQUFMLENBQWEsT0FBYixFQUFzQlosR0FBdEIsRUFBMkJDLElBQTNCLEVBQWlDQyxPQUFqQyxFQUEwQ0MsR0FBMUMsQ0FBUDtBQUNEOzs7NEJBRWFILEcsRUFBS0MsSSxFQUFtQztBQUFBLFVBQTdCQyxPQUE2Qix1RUFBbkIsSUFBbUI7QUFBQSxVQUFiQyxHQUFhLHVFQUFQLEtBQU87O0FBQ3BELGFBQU8sS0FBS1MsT0FBTCxDQUFhLFFBQWIsRUFBdUJaLEdBQXZCLEVBQTRCQyxJQUE1QixFQUFrQ0MsT0FBbEMsRUFBMkNDLEdBQTNDLENBQVA7QUFDRDs7Ozs7O2tCQXZHa0JMLEkiLCJmaWxlIjoiSHR0cC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB3ZXB5IGZyb20gJ3dlcHknO1xyXG5pbXBvcnQgVGlwcyBmcm9tICcuLi91dGlscy9UaXBzJztcclxuLy8gSFRUUOW3peWFt+exu1xyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBodHRwIHtcclxuICBzdGF0aWMgYXN5bmMgcmVxdWVzdChtZXRob2QsIHVybCwgZGF0YSwgbG9hZGluZyA9IHRydWUsIG1zZyA9IGZhbHNlLCBmb3JtID0gZmFsc2UsIG5lZWRUb2tlbiA9IHRydWUpIHtcclxuXHJcbiAgICBjb25zdCBwYXJhbSA9IHtcclxuICAgICAgdXJsOiB1cmwsXHJcbiAgICAgIG1ldGhvZDogbWV0aG9kLFxyXG4gICAgICBkYXRhOiBkYXRhLFxyXG4gICAgICBoZWFkZXI6IHtcclxuICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL3gtd3d3LWZvcm0tdXJsZW5jb2RlZFwiIFxyXG4gICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGlmIChsb2FkaW5nKSB7XHJcbiAgICAgIC8vIHN0b3JlLnNhdmUoJ2xvYWRpbmcnLCB0cnVlKVxyXG4gICAgICAvLyBUaXBzLmxvYWRpbmcoKTtcclxuICAgICAgd3guc2hvd05hdmlnYXRpb25CYXJMb2FkaW5nKClcclxuICAgIH1cclxuICAgIC8vIOe9kee7nOi/nuaOpei2heaXtlxyXG4gICAgbGV0IF9kYXRhO1xyXG4gICAgYXdhaXQgd2VweS5yZXF1ZXN0KHBhcmFtKS50aGVuKHJlcyA9PiB7XHJcbiAgICAgIC8vIGNvbnNvbGUubG9nKHJlcywncmVzdWx0ZScpXHJcbiAgICAgIGlmIChsb2FkaW5nKSB7XHJcbiAgICAgICAgLy8gc3RvcmUuc2F2ZSgnbG9hZGluZycsIGZhbHNlKVxyXG4gICAgICAgIC8vIFRpcHMubG9hZGVkKCk7XHJcbiAgICAgICAgd3guaGlkZU5hdmlnYXRpb25CYXJMb2FkaW5nKClcclxuICAgICAgfVxyXG4gICAgICBpZihyZXMuZGF0YS5lcnJjb2RlID09IDQwMSl7XHJcbiAgICAgICAgICBpZiAocmVzLmRhdGEuZXJybXNnKSBUaXBzLnRvYXN0KHJlcy5kYXRhLmVycm1zZywgKCkgPT4geyBcclxuICAgICAgICAgICAgd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5zZXNzaW9uSWQgPSAnJ1xyXG4gICAgICAgICAgICB3ZXB5LnJlTGF1bmNoKHsgdXJsOiAnL3BhZ2VzL2hvbWUvaW5kZXgnIH0pO1xyXG4gICAgICAgICAgfSwgXCJub25lXCIpO1xyXG4gICAgICAgIHJldHVyblxyXG4gICAgICB9XHJcbiAgICAgIGlmIChyZXMuZGF0YS5lcnJjb2RlICE9IDIwMCkge1xyXG4gICAgICAgIGlmIChyZXMuZGF0YS5lcnJtc2cpIFRpcHMudG9hc3QocmVzLmRhdGEuZXJybXNnLCAoKSA9PiB7IH0sIFwibm9uZVwiKTtcclxuICAgICAgfVxyXG4gICAgICBpZiAodGhpcy5pc1N1Y2Nlc3MocmVzKSkge1xyXG4gICAgICAgIF9kYXRhID0gIW1zZyA/IHJlcy5kYXRhLmRhdGEgOiByZXMuZGF0YTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICB0aHJvdyB0aGlzLnJlcXVlc3RFeGNlcHRpb24ocmVzKTtcclxuICAgICAgfVxyXG4gICAgfSkuY2F0Y2goZXJyID0+IHtcclxuICAgICAgaWYgKGxvYWRpbmcpIHtcclxuICAgICAgICAvLyBzdG9yZS5zYXZlKCdsb2FkaW5nJywgZmFsc2UpXHJcbiAgICAgICAgLy8gVGlwcy5sb2FkZWQoKTtcclxuICAgICAgICB3eC5oaWRlTmF2aWdhdGlvbkJhckxvYWRpbmcoKVxyXG4gICAgICB9XHJcbiAgICAgIGNvbnNvbGUubG9nKGVycilcclxuICAgICAgLy8gVGlwcy5sb2FkZWQoKTtcclxuICAgICAgVGlwcy50b2FzdChcIue9kee7nOi/nuaOpei2heaXtu+8jOivt+mHjeivlVwiLCAoKSA9PiB7IH0sIFwibm9uZVwiKTtcclxuICAgICAgLy8g55So5LqO5Ye6546w572R57uc5Ye66ZSZ5pe255qE6YeN6L+eXHJcbiAgICAgIF9kYXRhID0gJ3JlcXVlc3QgZXJyb3InO1xyXG4gICAgfSk7XHJcbiAgICByZXR1cm4gX2RhdGE7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiDliKTmlq3or7fmsYLmmK/lkKbmiJDlip9cclxuICAgKi9cclxuICBzdGF0aWMgaXNTdWNjZXNzKHJlcykge1xyXG4gICAgY29uc3Qgd3hDb2RlID0gcmVzLnN0YXR1c0NvZGU7XHJcbiAgICAvLyDlvq7kv6Hor7fmsYLplJnor69cclxuICAgIGlmICh3eENvZGUgIT09IDIwMCkge1xyXG4gICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHRydWU7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiDlvILluLhcclxuICAgKi9cclxuICBzdGF0aWMgcmVxdWVzdEV4Y2VwdGlvbihyZXMpIHtcclxuICAgIGNvbnN0IGVycm9yID0ge307XHJcbiAgICBlcnJvci5zdGF0dXNDb2RlID0gcmVzLnN0YXR1c0NvZGU7XHJcbiAgICBjb25zdCB3eERhdGEgPSByZXMuZGF0YTtcclxuICAgIGNvbnN0IHNlcnZlckRhdGEgPSB3eERhdGEuZGF0YTtcclxuICAgIGlmIChzZXJ2ZXJEYXRhKSB7XHJcbiAgICAgIGVycm9yLnNlcnZlckNvZGUgPSB3eERhdGEuY29kZTtcclxuICAgICAgZXJyb3IubWVzc2FnZSA9IHNlcnZlckRhdGEubWVzc2FnZTtcclxuICAgICAgZXJyb3Iuc2VydmVyRGF0YSA9IHNlcnZlckRhdGE7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gZXJyb3I7XHJcbiAgfVxyXG5cclxuICBzdGF0aWMgZ2V0KHVybCwgZGF0YSwgbG9hZGluZyA9IHRydWUsIG1zZyA9IGZhbHNlKSB7XHJcbiAgICByZXR1cm4gdGhpcy5yZXF1ZXN0KCdHRVQnLCB1cmwsIGRhdGEsIGxvYWRpbmcsIG1zZyk7XHJcbiAgfVxyXG5cclxuICBzdGF0aWMgcHV0KHVybCwgZGF0YSwgbG9hZGluZyA9IHRydWUsIG1zZyA9IGZhbHNlKSB7XHJcbiAgICByZXR1cm4gdGhpcy5yZXF1ZXN0KCdQVVQnLCB1cmwsIGRhdGEsIGxvYWRpbmcsIG1zZyk7XHJcbiAgfVxyXG5cclxuICBzdGF0aWMgcG9zdCh1cmwsIGRhdGEsIGxvYWRpbmcgPSB0cnVlLCBtc2cgPSBmYWxzZSwgZm9ybSA9IGZhbHNlLCBuZWVkVG9rZW4gPSB0cnVlKSB7XHJcbiAgICByZXR1cm4gdGhpcy5yZXF1ZXN0KCdQT1NUJywgdXJsLCBkYXRhLCBsb2FkaW5nLCBtc2csIGZvcm0sIG5lZWRUb2tlbik7XHJcbiAgfVxyXG5cclxuICBzdGF0aWMgcGF0Y2godXJsLCBkYXRhLCBsb2FkaW5nID0gdHJ1ZSwgbXNnID0gZmFsc2UpIHtcclxuICAgIHJldHVybiB0aGlzLnJlcXVlc3QoJ1BBVENIJywgdXJsLCBkYXRhLCBsb2FkaW5nLCBtc2cpO1xyXG4gIH1cclxuXHJcbiAgc3RhdGljIGRlbGV0ZSh1cmwsIGRhdGEsIGxvYWRpbmcgPSB0cnVlLCBtc2cgPSBmYWxzZSkge1xyXG4gICAgcmV0dXJuIHRoaXMucmVxdWVzdCgnREVMRVRFJywgdXJsLCBkYXRhLCBsb2FkaW5nLCBtc2cpO1xyXG4gIH1cclxufVxyXG4iXX0=