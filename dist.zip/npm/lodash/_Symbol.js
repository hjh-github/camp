var root = require('./_root.js');

/** Built-in value references. */
var Symbol = root.Symbol;

module.exports = Symbol;
