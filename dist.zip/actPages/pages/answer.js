"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

var _WxUtils = require('./../../utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

var _config = require('./../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

var _utils = require('./../../store/utils.js');

var _utils2 = _interopRequireDefault(_utils);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
    _inherits(Dialog, _wepy$page);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
            navigationBarTitleText: "答题"
        }, _this.data = {
            step: 0,
            qustions: [],
            qustionInx: 0,
            testPaper: {},
            answers: {},
            unTime: 10,
            result: {},
            opt: {}
        }, _this.methods = {
            back: function back() {
                _WxUtils2.default.backOrRedirect('/actPages/pages/index');
            },
            start: function start() {

                this.start();
            },
            select: function select(key) {
                // 不可重复答题
                if (!this.qustions[this.qustionInx]['answerUser']) {
                    this.qustions[this.qustionInx]['answerUser'] = key;
                    this.qustions[this.qustionInx]['spendTime'] = 11 - this.unTime;
                    this.nextQus();
                }
            }
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(Dialog, [{
        key: "onLoad",
        value: function () {
            var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(opt) {
                return regeneratorRuntime.wrap(function _callee$(_context) {
                    while (1) {
                        switch (_context.prev = _context.next) {
                            case 0:
                                this.opt = opt;
                                _context.next = 3;
                                return _auth2.default.login();

                            case 3:
                            case "end":
                                return _context.stop();
                        }
                    }
                }, _callee, this);
            }));

            function onLoad(_x) {
                return _ref2.apply(this, arguments);
            }

            return onLoad;
        }()
    }, {
        key: "start",
        value: function () {
            var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
                var _ref4, testPaper;

                return regeneratorRuntime.wrap(function _callee2$(_context2) {
                    while (1) {
                        switch (_context2.prev = _context2.next) {
                            case 0:
                                _context2.next = 2;
                                return _config2.default.answerStart(this.opt.id);

                            case 2:
                                _ref4 = _context2.sent;
                                testPaper = _ref4.testPaper;

                                if (testPaper && testPaper.testPaperQuestions) {
                                    this.step = 1;
                                    this.dowmTime();
                                    this.testPaper = testPaper;
                                    this.qustions = testPaper.testPaperQuestions;
                                    this.$apply();
                                } else {
                                    _Tips2.default.toast('试卷被偷了，请重新点击开始答题', function () {}, 'none');
                                }

                            case 5:
                            case "end":
                                return _context2.stop();
                        }
                    }
                }, _callee2, this);
            }));

            function start() {
                return _ref3.apply(this, arguments);
            }

            return start;
        }()
    }, {
        key: "dowmTime",
        value: function dowmTime() {
            var _this2 = this;

            clearInterval(this.setInterval);
            this.unTime = 10;
            this.setInterval = setInterval(function () {
                if (_this2.unTime > 0) {
                    _this2.unTime = _this2.unTime - 1;
                    _this2.$apply();
                } else {
                    _this2.answers[_this2.qustionInx] = "";
                    clearInterval(_this2.setInterval);
                    _this2.nextQus();
                }
            }, 1000);
        }
    }, {
        key: "nextQus",
        value: function nextQus() {
            var _this3 = this;

            setTimeout(function () {
                if (_this3.qustionInx < _this3.qustions.length - 1) {
                    _this3.qustionInx = _this3.qustionInx + 1;
                    _this3.dowmTime();
                } else {
                    clearInterval(_this3.setInterval);
                    _this3.finish();
                    _this3.step = 2;
                }
                _this3.$apply();
            }, 1000);
        }
    }, {
        key: "finish",
        value: function () {
            var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
                var _this4 = this;

                var _arr, params;

                return regeneratorRuntime.wrap(function _callee3$(_context3) {
                    while (1) {
                        switch (_context3.prev = _context3.next) {
                            case 0:
                                _arr = [];

                                this.qustions.forEach(function (e) {
                                    _arr.push({
                                        answerUser: e['answerUser'],
                                        spendTime: e['spendTime'],
                                        questionSort: e.sort,
                                        questionId: e.id,
                                        answerSheetId: _this4.testPaper.answerSheetId
                                    });
                                });
                                params = {
                                    answerSheetId: this.testPaper.answerSheetId,
                                    answerDetails: JSON.stringify(_arr)
                                };
                                _context3.next = 5;
                                return _config2.default.answerOver(params);

                            case 5:
                                this.result = _context3.sent;

                                this.unTime = this.result.answerSheet.spendTime;
                                this.$apply();

                            case 8:
                            case "end":
                                return _context3.stop();
                        }
                    }
                }, _callee3, this);
            }));

            function finish() {
                return _ref5.apply(this, arguments);
            }

            return finish;
        }()
    }]);

    return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'actPages/pages/answer'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFuc3dlci5qcyJdLCJuYW1lcyI6WyJEaWFsb2ciLCJjb25maWciLCJuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0IiwiZGF0YSIsInN0ZXAiLCJxdXN0aW9ucyIsInF1c3Rpb25JbngiLCJ0ZXN0UGFwZXIiLCJhbnN3ZXJzIiwidW5UaW1lIiwicmVzdWx0Iiwib3B0IiwibWV0aG9kcyIsImJhY2siLCJXeFV0aWxzIiwiYmFja09yUmVkaXJlY3QiLCJzdGFydCIsInNlbGVjdCIsImtleSIsIm5leHRRdXMiLCJhdXRoIiwibG9naW4iLCJhbnN3ZXJTdGFydCIsImlkIiwidGVzdFBhcGVyUXVlc3Rpb25zIiwiZG93bVRpbWUiLCIkYXBwbHkiLCJUaXBzIiwidG9hc3QiLCJjbGVhckludGVydmFsIiwic2V0SW50ZXJ2YWwiLCJzZXRUaW1lb3V0IiwibGVuZ3RoIiwiZmluaXNoIiwiX2FyciIsImZvckVhY2giLCJwdXNoIiwiYW5zd2VyVXNlciIsImUiLCJzcGVuZFRpbWUiLCJxdWVzdGlvblNvcnQiLCJzb3J0IiwicXVlc3Rpb25JZCIsImFuc3dlclNoZWV0SWQiLCJwYXJhbXMiLCJhbnN3ZXJEZXRhaWxzIiwiSlNPTiIsInN0cmluZ2lmeSIsImFuc3dlck92ZXIiLCJhbnN3ZXJTaGVldCIsIndlcHkiLCJwYWdlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFDSTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7Ozs7Ozs7Ozs7O0lBQ3FCQSxNOzs7Ozs7Ozs7Ozs7OzswTEFDakJDLE0sR0FBUztBQUNMQyxvQ0FBd0I7QUFEbkIsUyxRQUdUQyxJLEdBQU87QUFDSEMsa0JBQU0sQ0FESDtBQUVIQyxzQkFBVSxFQUZQO0FBR0hDLHdCQUFZLENBSFQ7QUFJSEMsdUJBQVcsRUFKUjtBQUtIQyxxQkFBUyxFQUxOO0FBTUhDLG9CQUFRLEVBTkw7QUFPSEMsb0JBQVEsRUFQTDtBQVFIQyxpQkFBSTtBQVJELFMsUUEwRVBDLE8sR0FBVTtBQUNOQyxnQkFETSxrQkFDQztBQUNIQyxrQ0FBUUMsY0FBUixDQUF1Qix1QkFBdkI7QUFDSCxhQUhLO0FBSU5DLGlCQUpNLG1CQUlFOztBQUVKLHFCQUFLQSxLQUFMO0FBQ0gsYUFQSztBQVFOQyxrQkFSTSxrQkFRQ0MsR0FSRCxFQVFNO0FBQ1I7QUFDQSxvQkFBSSxDQUFDLEtBQUtiLFFBQUwsQ0FBYyxLQUFLQyxVQUFuQixFQUErQixZQUEvQixDQUFMLEVBQW1EO0FBQy9DLHlCQUFLRCxRQUFMLENBQWMsS0FBS0MsVUFBbkIsRUFBK0IsWUFBL0IsSUFBK0NZLEdBQS9DO0FBQ0EseUJBQUtiLFFBQUwsQ0FBYyxLQUFLQyxVQUFuQixFQUErQixXQUEvQixJQUE4QyxLQUFLLEtBQUtHLE1BQXhEO0FBQ0EseUJBQUtVLE9BQUw7QUFDSDtBQUNKO0FBZkssUzs7Ozs7O2lHQWhFR1IsRzs7Ozs7QUFDVCxxQ0FBS0EsR0FBTCxHQUFXQSxHQUFYOzt1Q0FDTVMsZUFBS0MsS0FBTCxFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7dUNBS0lwQixpQkFBT3FCLFdBQVAsQ0FBbUIsS0FBS1gsR0FBTCxDQUFTWSxFQUE1QixDOzs7O0FBRE5oQix5QyxTQUFBQSxTOztBQUVKLG9DQUFJQSxhQUFhQSxVQUFVaUIsa0JBQTNCLEVBQStDO0FBQzNDLHlDQUFLcEIsSUFBTCxHQUFZLENBQVo7QUFDQSx5Q0FBS3FCLFFBQUw7QUFDQSx5Q0FBS2xCLFNBQUwsR0FBaUJBLFNBQWpCO0FBQ0EseUNBQUtGLFFBQUwsR0FBZ0JFLFVBQVVpQixrQkFBMUI7QUFDQSx5Q0FBS0UsTUFBTDtBQUNILGlDQU5ELE1BTU87QUFDSEMsbURBQUtDLEtBQUwsQ0FBVyxpQkFBWCxFQUE4QixZQUFNLENBQUUsQ0FBdEMsRUFBd0MsTUFBeEM7QUFDSDs7Ozs7Ozs7Ozs7Ozs7Ozs7O21DQUVNO0FBQUE7O0FBQ1BDLDBCQUFjLEtBQUtDLFdBQW5CO0FBQ0EsaUJBQUtyQixNQUFMLEdBQWMsRUFBZDtBQUNBLGlCQUFLcUIsV0FBTCxHQUFtQkEsWUFBWSxZQUFNO0FBQ2pDLG9CQUFJLE9BQUtyQixNQUFMLEdBQWMsQ0FBbEIsRUFBcUI7QUFDakIsMkJBQUtBLE1BQUwsR0FBYyxPQUFLQSxNQUFMLEdBQWMsQ0FBNUI7QUFDQSwyQkFBS2lCLE1BQUw7QUFDSCxpQkFIRCxNQUdPO0FBQ0gsMkJBQUtsQixPQUFMLENBQWEsT0FBS0YsVUFBbEIsSUFBZ0MsRUFBaEM7QUFDQXVCLGtDQUFjLE9BQUtDLFdBQW5CO0FBQ0EsMkJBQUtYLE9BQUw7QUFDSDtBQUNKLGFBVGtCLEVBU2hCLElBVGdCLENBQW5CO0FBVUg7OztrQ0FDUztBQUFBOztBQUNOWSx1QkFBVyxZQUFNO0FBQ2Isb0JBQUksT0FBS3pCLFVBQUwsR0FBa0IsT0FBS0QsUUFBTCxDQUFjMkIsTUFBZCxHQUF1QixDQUE3QyxFQUFnRDtBQUM1QywyQkFBSzFCLFVBQUwsR0FBa0IsT0FBS0EsVUFBTCxHQUFrQixDQUFwQztBQUNBLDJCQUFLbUIsUUFBTDtBQUNILGlCQUhELE1BR087QUFDSEksa0NBQWMsT0FBS0MsV0FBbkI7QUFDQSwyQkFBS0csTUFBTDtBQUNBLDJCQUFLN0IsSUFBTCxHQUFZLENBQVo7QUFDSDtBQUNELHVCQUFLc0IsTUFBTDtBQUNILGFBVkQsRUFVRyxJQVZIO0FBV0g7Ozs7Ozs7Ozs7Ozs7QUFFT1Esb0MsR0FBTyxFOztBQUNYLHFDQUFLN0IsUUFBTCxDQUFjOEIsT0FBZCxDQUFzQixhQUFLO0FBQ3ZCRCx5Q0FBS0UsSUFBTCxDQUFVO0FBQ05DLG9EQUFZQyxFQUFFLFlBQUYsQ0FETjtBQUVOQyxtREFBV0QsRUFBRSxXQUFGLENBRkw7QUFHTkUsc0RBQWNGLEVBQUVHLElBSFY7QUFJTkMsb0RBQVlKLEVBQUVmLEVBSlI7QUFLTm9CLHVEQUFlLE9BQUtwQyxTQUFMLENBQWVvQztBQUx4QixxQ0FBVjtBQU9ILGlDQVJEO0FBU0lDLHNDLEdBQVM7QUFDVEQsbURBQWUsS0FBS3BDLFNBQUwsQ0FBZW9DLGFBRHJCO0FBRVRFLG1EQUFlQyxLQUFLQyxTQUFMLENBQWViLElBQWY7QUFGTixpQzs7dUNBSU9qQyxpQkFBTytDLFVBQVAsQ0FBa0JKLE1BQWxCLEM7OztBQUFwQixxQ0FBS2xDLE07O0FBQ0wscUNBQUtELE1BQUwsR0FBYyxLQUFLQyxNQUFMLENBQVl1QyxXQUFaLENBQXdCVixTQUF0QztBQUNBLHFDQUFLYixNQUFMOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBNUU0QndCLGVBQUtDLEk7O2tCQUFwQm5ELE0iLCJmaWxlIjoiYW5zd2VyLmpzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbiAgICBpbXBvcnQgd2VweSBmcm9tIFwid2VweVwiO1xyXG4gICAgaW1wb3J0IFRpcHMgZnJvbSBcIkAvdXRpbHMvVGlwc1wiO1xyXG4gICAgaW1wb3J0IFd4VXRpbHMgZnJvbSBcIkAvdXRpbHMvV3hVdGlsc1wiO1xyXG4gICAgaW1wb3J0IGNvbmZpZyBmcm9tIFwiLi4vYXBpL2NvbmZpZ1wiO1xyXG4gICAgaW1wb3J0IGF1dGggZnJvbSBcIkAvYXBpL2F1dGhcIjtcclxuICAgIGltcG9ydCBzdG9yZSBmcm9tIFwiQC9zdG9yZS91dGlsc1wiO1xyXG4gICAgZXhwb3J0IGRlZmF1bHQgY2xhc3MgRGlhbG9nIGV4dGVuZHMgd2VweS5wYWdlIHtcclxuICAgICAgICBjb25maWcgPSB7XHJcbiAgICAgICAgICAgIG5hdmlnYXRpb25CYXJUaXRsZVRleHQ6IFwi562U6aKYXCJcclxuICAgICAgICB9O1xyXG4gICAgICAgIGRhdGEgPSB7XHJcbiAgICAgICAgICAgIHN0ZXA6IDAsXHJcbiAgICAgICAgICAgIHF1c3Rpb25zOiBbXSxcclxuICAgICAgICAgICAgcXVzdGlvbklueDogMCxcclxuICAgICAgICAgICAgdGVzdFBhcGVyOiB7fSxcclxuICAgICAgICAgICAgYW5zd2Vyczoge30sXHJcbiAgICAgICAgICAgIHVuVGltZTogMTAsXHJcbiAgICAgICAgICAgIHJlc3VsdDoge30sXHJcbiAgICAgICAgICAgIG9wdDp7fVxyXG4gICAgICAgIH07XHJcbiAgICAgICAgYXN5bmMgb25Mb2FkKG9wdCkge1xyXG4gICAgICAgICAgICB0aGlzLm9wdCA9IG9wdFxyXG4gICAgICAgICAgICBhd2FpdCBhdXRoLmxvZ2luKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGFzeW5jIHN0YXJ0KCkge1xyXG4gICAgICAgICAgICBsZXQge1xyXG4gICAgICAgICAgICAgICAgdGVzdFBhcGVyXHJcbiAgICAgICAgICAgIH0gPSBhd2FpdCBjb25maWcuYW5zd2VyU3RhcnQodGhpcy5vcHQuaWQpO1xyXG4gICAgICAgICAgICBpZiAodGVzdFBhcGVyICYmIHRlc3RQYXBlci50ZXN0UGFwZXJRdWVzdGlvbnMpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuc3RlcCA9IDE7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmRvd21UaW1lKCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnRlc3RQYXBlciA9IHRlc3RQYXBlcjtcclxuICAgICAgICAgICAgICAgIHRoaXMucXVzdGlvbnMgPSB0ZXN0UGFwZXIudGVzdFBhcGVyUXVlc3Rpb25zO1xyXG4gICAgICAgICAgICAgICAgdGhpcy4kYXBwbHkoKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIFRpcHMudG9hc3QoJ+ivleWNt+iiq+WBt+S6hu+8jOivt+mHjeaWsOeCueWHu+W8gOWni+etlOmimCcsICgpID0+IHt9LCAnbm9uZScpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgZG93bVRpbWUoKSB7XHJcbiAgICAgICAgICAgIGNsZWFySW50ZXJ2YWwodGhpcy5zZXRJbnRlcnZhbCk7XHJcbiAgICAgICAgICAgIHRoaXMudW5UaW1lID0gMTA7XHJcbiAgICAgICAgICAgIHRoaXMuc2V0SW50ZXJ2YWwgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy51blRpbWUgPiAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy51blRpbWUgPSB0aGlzLnVuVGltZSAtIDE7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy4kYXBwbHkoKTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hbnN3ZXJzW3RoaXMucXVzdGlvbklueF0gPSBcIlwiO1xyXG4gICAgICAgICAgICAgICAgICAgIGNsZWFySW50ZXJ2YWwodGhpcy5zZXRJbnRlcnZhbCk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5uZXh0UXVzKClcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSwgMTAwMCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIG5leHRRdXMoKSB7XHJcbiAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMucXVzdGlvbklueCA8IHRoaXMucXVzdGlvbnMubGVuZ3RoIC0gMSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMucXVzdGlvbklueCA9IHRoaXMucXVzdGlvbklueCArIDE7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5kb3dtVGltZSgpXHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIGNsZWFySW50ZXJ2YWwodGhpcy5zZXRJbnRlcnZhbCk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5maW5pc2goKVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc3RlcCA9IDI7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB0aGlzLiRhcHBseSgpO1xyXG4gICAgICAgICAgICB9LCAxMDAwKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgYXN5bmMgZmluaXNoKCkge1xyXG4gICAgICAgICAgICBsZXQgX2FyciA9IFtdXHJcbiAgICAgICAgICAgIHRoaXMucXVzdGlvbnMuZm9yRWFjaChlID0+IHtcclxuICAgICAgICAgICAgICAgIF9hcnIucHVzaCh7XHJcbiAgICAgICAgICAgICAgICAgICAgYW5zd2VyVXNlcjogZVsnYW5zd2VyVXNlciddLFxyXG4gICAgICAgICAgICAgICAgICAgIHNwZW5kVGltZTogZVsnc3BlbmRUaW1lJ10sXHJcbiAgICAgICAgICAgICAgICAgICAgcXVlc3Rpb25Tb3J0OiBlLnNvcnQsXHJcbiAgICAgICAgICAgICAgICAgICAgcXVlc3Rpb25JZDogZS5pZCxcclxuICAgICAgICAgICAgICAgICAgICBhbnN3ZXJTaGVldElkOiB0aGlzLnRlc3RQYXBlci5hbnN3ZXJTaGVldElkXHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICAgICAgICAgICAgYW5zd2VyU2hlZXRJZDogdGhpcy50ZXN0UGFwZXIuYW5zd2VyU2hlZXRJZCxcclxuICAgICAgICAgICAgICAgIGFuc3dlckRldGFpbHM6IEpTT04uc3RyaW5naWZ5KF9hcnIpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdGhpcy5yZXN1bHQgPSBhd2FpdCBjb25maWcuYW5zd2VyT3ZlcihwYXJhbXMpXHJcbiAgICAgICAgICAgIHRoaXMudW5UaW1lID0gdGhpcy5yZXN1bHQuYW5zd2VyU2hlZXQuc3BlbmRUaW1lXHJcbiAgICAgICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgICB9XHJcbiAgICAgICAgbWV0aG9kcyA9IHtcclxuICAgICAgICAgICAgYmFjaygpIHtcclxuICAgICAgICAgICAgICAgIFd4VXRpbHMuYmFja09yUmVkaXJlY3QoJy9hY3RQYWdlcy9wYWdlcy9pbmRleCcpO1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBzdGFydCgpIHtcclxuICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICB0aGlzLnN0YXJ0KCk7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHNlbGVjdChrZXkpIHtcclxuICAgICAgICAgICAgICAgIC8vIOS4jeWPr+mHjeWkjeetlOmimFxyXG4gICAgICAgICAgICAgICAgaWYgKCF0aGlzLnF1c3Rpb25zW3RoaXMucXVzdGlvbklueF1bJ2Fuc3dlclVzZXInXSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMucXVzdGlvbnNbdGhpcy5xdXN0aW9uSW54XVsnYW5zd2VyVXNlciddID0ga2V5O1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMucXVzdGlvbnNbdGhpcy5xdXN0aW9uSW54XVsnc3BlbmRUaW1lJ10gPSAxMSAtIHRoaXMudW5UaW1lO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubmV4dFF1cygpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9O1xyXG4gICAgfVxyXG4iXX0=