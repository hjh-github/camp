"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _config = require('./../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
    _inherits(Dialog, _wepy$page);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
            navigationBarTitleText: "知识竞答赛"
        }, _this.data = {
            info: {},
            loaded: false
        }, _this.methods = {
            toanswer: function toanswer() {
                _wepy2.default.navigateTo({
                    url: './answerAct'
                });
            },
            rank: function rank() {
                _wepy2.default.navigateTo({
                    url: './rank'
                });
            }
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(Dialog, [{
        key: "load",
        value: function () {
            var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
                var _ref3, answerIndex;

                return regeneratorRuntime.wrap(function _callee$(_context) {
                    while (1) {
                        switch (_context.prev = _context.next) {
                            case 0:
                                _context.next = 2;
                                return _config2.default.answerInfo();

                            case 2:
                                _ref3 = _context.sent;
                                answerIndex = _ref3.answerIndex;

                                this.info = answerIndex;
                                this.loaded = true;
                                this.$apply();

                            case 7:
                            case "end":
                                return _context.stop();
                        }
                    }
                }, _callee, this);
            }));

            function load() {
                return _ref2.apply(this, arguments);
            }

            return load;
        }()
    }, {
        key: "onLoad",
        value: function () {
            var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
                return regeneratorRuntime.wrap(function _callee2$(_context2) {
                    while (1) {
                        switch (_context2.prev = _context2.next) {
                            case 0:
                                _context2.next = 2;
                                return _auth2.default.login();

                            case 2:
                                this.load();

                            case 3:
                            case "end":
                                return _context2.stop();
                        }
                    }
                }, _callee2, this);
            }));

            function onLoad() {
                return _ref4.apply(this, arguments);
            }

            return onLoad;
        }()
    }, {
        key: "onShow",
        value: function onShow() {
            this.load();
        }
        // 转发暂时先不开启

    }, {
        key: "onShareAppMessage",
        value: function onShareAppMessage(res) {
            if (res.from === 'button') {
                // 来自页面内转发按钮
                console.log(res.target);
            }
            return {
                title: '',
                path: '/actPages/home/index'
            };
        }
    }]);

    return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'actPages/pages/index'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LmpzIl0sIm5hbWVzIjpbIkRpYWxvZyIsImNvbmZpZyIsIm5hdmlnYXRpb25CYXJUaXRsZVRleHQiLCJkYXRhIiwiaW5mbyIsImxvYWRlZCIsIm1ldGhvZHMiLCJ0b2Fuc3dlciIsIndlcHkiLCJuYXZpZ2F0ZVRvIiwidXJsIiwicmFuayIsImFuc3dlckluZm8iLCJhbnN3ZXJJbmRleCIsIiRhcHBseSIsImF1dGgiLCJsb2dpbiIsImxvYWQiLCJyZXMiLCJmcm9tIiwiY29uc29sZSIsImxvZyIsInRhcmdldCIsInRpdGxlIiwicGF0aCIsInBhZ2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUNJOzs7O0FBQ0E7Ozs7QUFDQTs7Ozs7Ozs7Ozs7Ozs7SUFDcUJBLE07Ozs7Ozs7Ozs7Ozs7OzBMQUNqQkMsTSxHQUFTO0FBQ0xDLG9DQUF3QjtBQURuQixTLFFBR1RDLEksR0FBTztBQUNIQyxrQkFBTSxFQURIO0FBRUhDLG9CQUFRO0FBRkwsUyxRQThCUEMsTyxHQUFVO0FBQ05DLG9CQURNLHNCQUNLO0FBQ1BDLCtCQUFLQyxVQUFMLENBQWdCO0FBQ1pDLHlCQUFLO0FBRE8saUJBQWhCO0FBR0gsYUFMSztBQU1OQyxnQkFOTSxrQkFNQztBQUNISCwrQkFBS0MsVUFBTCxDQUFnQjtBQUNaQyx5QkFBSztBQURPLGlCQUFoQjtBQUdIO0FBVkssUzs7Ozs7Ozs7Ozs7Ozs7dUNBdkJJVCxpQkFBT1csVUFBUCxFOzs7O0FBRE5DLDJDLFNBQUFBLFc7O0FBRUoscUNBQUtULElBQUwsR0FBWVMsV0FBWjtBQUNBLHFDQUFLUixNQUFMLEdBQWMsSUFBZDtBQUNBLHFDQUFLUyxNQUFMOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3VDQUdNQyxlQUFLQyxLQUFMLEU7OztBQUNOLHFDQUFLQyxJQUFMOzs7Ozs7Ozs7Ozs7Ozs7Ozs7aUNBRUs7QUFDTCxpQkFBS0EsSUFBTDtBQUNIO0FBQ0Q7Ozs7MENBQ2tCQyxHLEVBQUs7QUFDbkIsZ0JBQUlBLElBQUlDLElBQUosS0FBYSxRQUFqQixFQUEyQjtBQUN2QjtBQUNBQyx3QkFBUUMsR0FBUixDQUFZSCxJQUFJSSxNQUFoQjtBQUNIO0FBQ0QsbUJBQU87QUFDSEMsdUJBQU8sRUFESjtBQUVIQyxzQkFBTTtBQUZILGFBQVA7QUFJSDs7OztFQWpDK0JoQixlQUFLaUIsSTs7a0JBQXBCekIsTSIsImZpbGUiOiJpbmRleC5qcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4gICAgaW1wb3J0IHdlcHkgZnJvbSBcIndlcHlcIjtcclxuICAgIGltcG9ydCBjb25maWcgZnJvbSBcIi4uL2FwaS9jb25maWdcIjtcclxuICAgIGltcG9ydCBhdXRoIGZyb20gXCJAL2FwaS9hdXRoXCI7XHJcbiAgICBleHBvcnQgZGVmYXVsdCBjbGFzcyBEaWFsb2cgZXh0ZW5kcyB3ZXB5LnBhZ2Uge1xyXG4gICAgICAgIGNvbmZpZyA9IHtcclxuICAgICAgICAgICAgbmF2aWdhdGlvbkJhclRpdGxlVGV4dDogXCLnn6Xor4bnq57nrZTotZtcIlxyXG4gICAgICAgIH07XHJcbiAgICAgICAgZGF0YSA9IHtcclxuICAgICAgICAgICAgaW5mbzoge30sXHJcbiAgICAgICAgICAgIGxvYWRlZDogZmFsc2VcclxuICAgICAgICB9O1xyXG4gICAgICAgIGFzeW5jIGxvYWQoKSB7XHJcbiAgICAgICAgICAgIGxldCB7XHJcbiAgICAgICAgICAgICAgICBhbnN3ZXJJbmRleFxyXG4gICAgICAgICAgICB9ID0gYXdhaXQgY29uZmlnLmFuc3dlckluZm8oKVxyXG4gICAgICAgICAgICB0aGlzLmluZm8gPSBhbnN3ZXJJbmRleFxyXG4gICAgICAgICAgICB0aGlzLmxvYWRlZCA9IHRydWVcclxuICAgICAgICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgICAgIH1cclxuICAgICAgICBhc3luYyBvbkxvYWQoKSB7XHJcbiAgICAgICAgICAgIGF3YWl0IGF1dGgubG9naW4oKTtcclxuICAgICAgICAgICAgdGhpcy5sb2FkKClcclxuICAgICAgICB9XHJcbiAgICAgICAgb25TaG93KCkge1xyXG4gICAgICAgICAgICB0aGlzLmxvYWQoKVxyXG4gICAgICAgIH1cclxuICAgICAgICAvLyDovazlj5HmmoLml7blhYjkuI3lvIDlkK9cclxuICAgICAgICBvblNoYXJlQXBwTWVzc2FnZShyZXMpIHtcclxuICAgICAgICAgICAgaWYgKHJlcy5mcm9tID09PSAnYnV0dG9uJykge1xyXG4gICAgICAgICAgICAgICAgLy8g5p2l6Ieq6aG16Z2i5YaF6L2s5Y+R5oyJ6ZKuXHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhyZXMudGFyZ2V0KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICB0aXRsZTogJycsXHJcbiAgICAgICAgICAgICAgICBwYXRoOiAnL2FjdFBhZ2VzL2hvbWUvaW5kZXgnXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgbWV0aG9kcyA9IHtcclxuICAgICAgICAgICAgdG9hbnN3ZXIoKSB7XHJcbiAgICAgICAgICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICAgICAgICAgIHVybDogJy4vYW5zd2VyQWN0J1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHJhbmsoKSB7XHJcbiAgICAgICAgICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICAgICAgICAgIHVybDogJy4vcmFuaydcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuIl19