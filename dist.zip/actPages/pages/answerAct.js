"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _config = require('./../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
    _inherits(Dialog, _wepy$page);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
            navigationBarTitleText: "答题挑战"
        }, _this.data = {
            qustions: {},
            id: ''
        }, _this.methods = {
            onGotUserInfo: function () {
                var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(e) {
                    return regeneratorRuntime.wrap(function _callee$(_context) {
                        while (1) {
                            switch (_context.prev = _context.next) {
                                case 0:
                                    if (!(e.detail.errMsg == "getUserInfo:ok")) {
                                        _context.next = 4;
                                        break;
                                    }

                                    _context.next = 3;
                                    return _auth2.default.getUserinfo(e.detail);

                                case 3:
                                    if (this.id) {
                                        _wepy2.default.navigateTo({
                                            url: './answer?id=' + this.id
                                        });
                                    }

                                case 4:
                                case "end":
                                    return _context.stop();
                            }
                        }
                    }, _callee, this);
                }));

                function onGotUserInfo(_x) {
                    return _ref2.apply(this, arguments);
                }

                return onGotUserInfo;
            }(),
            open: function open(id) {
                this.id = id;
            },
            linend: function linend() {
                this.tiemend = true;
                this.$apply();
                console.log('linend');
            }
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(Dialog, [{
        key: "load",
        value: function () {
            var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
                var _ref4, answerWeekVo;

                return regeneratorRuntime.wrap(function _callee2$(_context2) {
                    while (1) {
                        switch (_context2.prev = _context2.next) {
                            case 0:
                                _context2.next = 2;
                                return _config2.default.answerlist();

                            case 2:
                                _ref4 = _context2.sent;
                                answerWeekVo = _ref4.answerWeekVo;

                                this.qustions = answerWeekVo;
                                this.$apply();

                            case 6:
                            case "end":
                                return _context2.stop();
                        }
                    }
                }, _callee2, this);
            }));

            function load() {
                return _ref3.apply(this, arguments);
            }

            return load;
        }()
    }, {
        key: "onLoad",
        value: function () {
            var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
                return regeneratorRuntime.wrap(function _callee3$(_context3) {
                    while (1) {
                        switch (_context3.prev = _context3.next) {
                            case 0:
                                _context3.next = 2;
                                return _auth2.default.login();

                            case 2:
                                this.load();

                            case 3:
                            case "end":
                                return _context3.stop();
                        }
                    }
                }, _callee3, this);
            }));

            function onLoad() {
                return _ref5.apply(this, arguments);
            }

            return onLoad;
        }()
    }]);

    return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'actPages/pages/answerAct'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFuc3dlckFjdC5qcyJdLCJuYW1lcyI6WyJEaWFsb2ciLCJjb25maWciLCJuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0IiwiZGF0YSIsInF1c3Rpb25zIiwiaWQiLCJtZXRob2RzIiwib25Hb3RVc2VySW5mbyIsImUiLCJkZXRhaWwiLCJlcnJNc2ciLCJhdXRoIiwiZ2V0VXNlcmluZm8iLCJ3ZXB5IiwibmF2aWdhdGVUbyIsInVybCIsIm9wZW4iLCJsaW5lbmQiLCJ0aWVtZW5kIiwiJGFwcGx5IiwiY29uc29sZSIsImxvZyIsImFuc3dlcmxpc3QiLCJhbnN3ZXJXZWVrVm8iLCJsb2dpbiIsImxvYWQiLCJwYWdlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFDSTs7OztBQUNBOzs7O0FBQ0E7Ozs7Ozs7Ozs7Ozs7O0lBQ3FCQSxNOzs7Ozs7Ozs7Ozs7OzswTEFDakJDLE0sR0FBUztBQUNMQyxvQ0FBd0I7QUFEbkIsUyxRQUdUQyxJLEdBQU87QUFDSEMsc0JBQVUsRUFEUDtBQUVIQyxnQkFBSTtBQUZELFMsUUFlUEMsTyxHQUFVO0FBQ0FDLHlCQURBO0FBQUEscUdBQ2NDLENBRGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBDQUVFQSxFQUFFQyxNQUFGLENBQVNDLE1BQVQsSUFBbUIsZ0JBRnJCO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUEsMkNBR1FDLGVBQUtDLFdBQUwsQ0FBaUJKLEVBQUVDLE1BQW5CLENBSFI7O0FBQUE7QUFJRSx3Q0FBSSxLQUFLSixFQUFULEVBQWE7QUFDVFEsdURBQUtDLFVBQUwsQ0FBZ0I7QUFDWkMsaURBQUssaUJBQWlCLEtBQUtWO0FBRGYseUNBQWhCO0FBR0g7O0FBUkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFXTlcsZ0JBWE0sZ0JBV0RYLEVBWEMsRUFXRztBQUNMLHFCQUFLQSxFQUFMLEdBQVVBLEVBQVY7QUFDSCxhQWJLO0FBY05ZLGtCQWRNLG9CQWNHO0FBQ0wscUJBQUtDLE9BQUwsR0FBZSxJQUFmO0FBQ0EscUJBQUtDLE1BQUw7QUFDQUMsd0JBQVFDLEdBQVIsQ0FBWSxRQUFaO0FBQ0g7QUFsQkssUzs7Ozs7Ozs7Ozs7Ozs7dUNBUklwQixpQkFBT3FCLFVBQVAsRTs7OztBQUROQyw0QyxTQUFBQSxZOztBQUVKLHFDQUFLbkIsUUFBTCxHQUFnQm1CLFlBQWhCO0FBQ0EscUNBQUtKLE1BQUw7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7dUNBR01SLGVBQUthLEtBQUwsRTs7O0FBQ04scUNBQUtDLElBQUw7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUFqQjRCWixlQUFLYSxJOztrQkFBcEIxQixNIiwiZmlsZSI6ImFuc3dlckFjdC5qcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4gICAgaW1wb3J0IHdlcHkgZnJvbSBcIndlcHlcIjtcclxuICAgIGltcG9ydCBjb25maWcgZnJvbSBcIi4uL2FwaS9jb25maWdcIjtcclxuICAgIGltcG9ydCBhdXRoIGZyb20gXCJAL2FwaS9hdXRoXCI7XHJcbiAgICBleHBvcnQgZGVmYXVsdCBjbGFzcyBEaWFsb2cgZXh0ZW5kcyB3ZXB5LnBhZ2Uge1xyXG4gICAgICAgIGNvbmZpZyA9IHtcclxuICAgICAgICAgICAgbmF2aWdhdGlvbkJhclRpdGxlVGV4dDogXCLnrZTpopjmjJHmiJhcIlxyXG4gICAgICAgIH07XHJcbiAgICAgICAgZGF0YSA9IHtcclxuICAgICAgICAgICAgcXVzdGlvbnM6IHt9LFxyXG4gICAgICAgICAgICBpZDogJydcclxuICAgICAgICB9O1xyXG4gICAgICAgIGFzeW5jIGxvYWQoKSB7XHJcbiAgICAgICAgICAgIGxldCB7XHJcbiAgICAgICAgICAgICAgICBhbnN3ZXJXZWVrVm9cclxuICAgICAgICAgICAgfSA9IGF3YWl0IGNvbmZpZy5hbnN3ZXJsaXN0KClcclxuICAgICAgICAgICAgdGhpcy5xdXN0aW9ucyA9IGFuc3dlcldlZWtWb1xyXG4gICAgICAgICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGFzeW5jIG9uTG9hZCgpIHtcclxuICAgICAgICAgICAgYXdhaXQgYXV0aC5sb2dpbigpO1xyXG4gICAgICAgICAgICB0aGlzLmxvYWQoKVxyXG4gICAgICAgIH1cclxuICAgICAgICBtZXRob2RzID0ge1xyXG4gICAgICAgICAgICBhc3luYyBvbkdvdFVzZXJJbmZvKGUpIHtcclxuICAgICAgICAgICAgICAgIGlmIChlLmRldGFpbC5lcnJNc2cgPT0gXCJnZXRVc2VySW5mbzpva1wiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYXdhaXQgYXV0aC5nZXRVc2VyaW5mbyhlLmRldGFpbCk7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuaWQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgd2VweS5uYXZpZ2F0ZVRvKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVybDogJy4vYW5zd2VyP2lkPScgKyB0aGlzLmlkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgb3BlbihpZCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5pZCA9IGlkXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGxpbmVuZCgpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMudGllbWVuZCA9IHRydWVcclxuICAgICAgICAgICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdsaW5lbmQnKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuIl19