'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = undefined;

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _base2 = require('./../../api/base.js');

var _base3 = _interopRequireDefault(_base2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var config = function (_base) {
    _inherits(config, _base);

    function config() {
        _classCallCheck(this, config);

        return _possibleConstructorReturn(this, (config.__proto__ || Object.getPrototypeOf(config)).apply(this, arguments));
    }

    _createClass(config, null, [{
        key: 'answerStart',

        // 获取评论列表
        value: function () {
            var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(testPaperId) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee$(_context) {
                    while (1) {
                        switch (_context.prev = _context.next) {
                            case 0:
                                url = this.baseUrl + '/answer/start';
                                params = {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId,
                                    testPaperId: testPaperId
                                };
                                return _context.abrupt('return', this.post(url, params, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context.stop();
                        }
                    }
                }, _callee, this);
            }));

            function answerStart(_x) {
                return _ref.apply(this, arguments);
            }

            return answerStart;
        }()
        // 提交答卷

    }, {
        key: 'answerOver',
        value: function () {
            var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(opt) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee2$(_context2) {
                    while (1) {
                        switch (_context2.prev = _context2.next) {
                            case 0:
                                url = this.baseUrl + '/answer/over';
                                params = _extends({
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                }, opt);
                                return _context2.abrupt('return', this.post(url, params, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context2.stop();
                        }
                    }
                }, _callee2, this);
            }));

            function answerOver(_x2) {
                return _ref2.apply(this, arguments);
            }

            return answerOver;
        }()
        // 获取答题活动信息

    }, {
        key: 'answerInfo',
        value: function () {
            var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
                var url, params;
                return regeneratorRuntime.wrap(function _callee3$(_context3) {
                    while (1) {
                        switch (_context3.prev = _context3.next) {
                            case 0:
                                url = this.baseUrl + '/answer';
                                params = {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                };
                                return _context3.abrupt('return', this.post(url, params, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context3.stop();
                        }
                    }
                }, _callee3, this);
            }));

            function answerInfo() {
                return _ref3.apply(this, arguments);
            }

            return answerInfo;
        }()
        // 本周答题列表

    }, {
        key: 'answerlist',
        value: function () {
            var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
                var url, params;
                return regeneratorRuntime.wrap(function _callee4$(_context4) {
                    while (1) {
                        switch (_context4.prev = _context4.next) {
                            case 0:
                                url = this.baseUrl + '/answer/list';
                                params = {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                };
                                return _context4.abrupt('return', this.post(url, params, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context4.stop();
                        }
                    }
                }, _callee4, this);
            }));

            function answerlist() {
                return _ref4.apply(this, arguments);
            }

            return answerlist;
        }()
        // 排行榜

    }, {
        key: 'ranking',
        value: function () {
            var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5(type) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee5$(_context5) {
                    while (1) {
                        switch (_context5.prev = _context5.next) {
                            case 0:
                                url = this.baseUrl + '/answer/ranking';
                                params = {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId,
                                    type: type
                                };
                                return _context5.abrupt('return', this.post(url, params, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context5.stop();
                        }
                    }
                }, _callee5, this);
            }));

            function ranking(_x3) {
                return _ref5.apply(this, arguments);
            }

            return ranking;
        }()
    }]);

    return config;
}(_base3.default);

exports.default = config;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbmZpZy5qcyJdLCJuYW1lcyI6WyJjb25maWciLCJ0ZXN0UGFwZXJJZCIsInVybCIsImJhc2VVcmwiLCJwYXJhbXMiLCJzZXNzaW9uSWQiLCJ3ZXB5IiwiJGluc3RhbmNlIiwiZ2xvYmFsRGF0YSIsInBvc3QiLCJ0aGVuIiwicmVzIiwib3B0IiwidHlwZSIsImJhc2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7O0FBQUE7Ozs7QUFDQTs7Ozs7Ozs7Ozs7Ozs7SUFFcUJBLE07Ozs7Ozs7Ozs7OztBQUNqQjs7Z0dBQ3lCQyxXOzs7Ozs7QUFDakJDLG1DLEdBQVMsS0FBS0MsTztBQUNkQyxzQyxHQUFTO0FBQ1RDLCtDQUFXQyxlQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJILFNBRDVCO0FBRVRKO0FBRlMsaUM7aUVBSU4sS0FBS1EsSUFBTCxDQUFVUCxHQUFWLEVBQWVFLE1BQWYsRUFBdUIsSUFBdkIsRUFBNkJNLElBQTdCLENBQWtDLGVBQU87QUFDNUMsMkNBQU9DLEdBQVA7QUFDSCxpQ0FGTSxDOzs7Ozs7Ozs7Ozs7Ozs7O0FBSVg7Ozs7O2tHQUN3QkMsRzs7Ozs7O0FBQ2hCVixtQyxHQUFTLEtBQUtDLE87QUFDZEMsc0M7QUFDQUMsK0NBQVdDLGVBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQkg7bUNBQ2xDTyxHO2tFQUVBLEtBQUtILElBQUwsQ0FBVVAsR0FBVixFQUFlRSxNQUFmLEVBQXVCLElBQXZCLEVBQTZCTSxJQUE3QixDQUFrQyxlQUFPO0FBQzVDLDJDQUFPQyxHQUFQO0FBQ0gsaUNBRk0sQzs7Ozs7Ozs7Ozs7Ozs7OztBQUlWOzs7Ozs7Ozs7OztBQUVPVCxtQyxHQUFTLEtBQUtDLE87QUFDZEMsc0MsR0FBUztBQUNUQywrQ0FBV0MsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCSDtBQUQ1QixpQztrRUFHTixLQUFLSSxJQUFMLENBQVVQLEdBQVYsRUFBZUUsTUFBZixFQUF1QixJQUF2QixFQUE2Qk0sSUFBN0IsQ0FBa0MsZUFBTztBQUM1QywyQ0FBT0MsR0FBUDtBQUNILGlDQUZNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJWDs7Ozs7Ozs7Ozs7QUFFUVQsbUMsR0FBUyxLQUFLQyxPO0FBQ2RDLHNDLEdBQVM7QUFDVEMsK0NBQVdDLGVBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQkg7QUFENUIsaUM7a0VBR04sS0FBS0ksSUFBTCxDQUFVUCxHQUFWLEVBQWVFLE1BQWYsRUFBdUIsSUFBdkIsRUFBNkJNLElBQTdCLENBQWtDLGVBQU87QUFDNUMsMkNBQU9DLEdBQVA7QUFDSCxpQ0FGTSxDOzs7Ozs7Ozs7Ozs7Ozs7O0FBSVg7Ozs7O2tHQUNxQkUsSTs7Ozs7O0FBQ2JYLG1DLEdBQVMsS0FBS0MsTztBQUNkQyxzQyxHQUFTO0FBQ1RDLCtDQUFXQyxlQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJILFNBRDVCO0FBRVRRO0FBRlMsaUM7a0VBSU4sS0FBS0osSUFBTCxDQUFVUCxHQUFWLEVBQWVFLE1BQWYsRUFBdUIsSUFBdkIsRUFBNkJNLElBQTdCLENBQWtDLGVBQU87QUFDNUMsMkNBQU9DLEdBQVA7QUFDSCxpQ0FGTSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBbERxQkcsYzs7a0JBQWZkLE0iLCJmaWxlIjoiY29uZmlnLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHdlcHkgZnJvbSAnd2VweSdcclxuaW1wb3J0IGJhc2UgZnJvbSAnQC9hcGkvYmFzZSdcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIGNvbmZpZyBleHRlbmRzIGJhc2Uge1xyXG4gICAgLy8g6I635Y+W6K+E6K665YiX6KGoXHJcbiAgICBzdGF0aWMgYXN5bmMgYW5zd2VyU3RhcnQodGVzdFBhcGVySWQpIHtcclxuICAgICAgICBsZXQgdXJsID0gYCR7dGhpcy5iYXNlVXJsfS9hbnN3ZXIvc3RhcnRgO1xyXG4gICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgIHNlc3Npb25JZDogd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5zZXNzaW9uSWQsXHJcbiAgICAgICAgICAgIHRlc3RQYXBlcklkXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB0aGlzLnBvc3QodXJsLCBwYXJhbXMsIHRydWUpLnRoZW4ocmVzID0+IHtcclxuICAgICAgICAgICAgcmV0dXJuIHJlcztcclxuICAgICAgICB9KVxyXG4gICAgfVxyXG4gICAgLy8g5o+Q5Lqk562U5Y23XHJcbiAgICBzdGF0aWMgYXN5bmMgYW5zd2VyT3ZlcihvcHQpIHtcclxuICAgICAgICBsZXQgdXJsID0gYCR7dGhpcy5iYXNlVXJsfS9hbnN3ZXIvb3ZlcmA7XHJcbiAgICAgICAgbGV0IHBhcmFtcyA9IHtcclxuICAgICAgICAgICAgc2Vzc2lvbklkOiB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnNlc3Npb25JZCxcclxuICAgICAgICAgICAgLi4ub3B0XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB0aGlzLnBvc3QodXJsLCBwYXJhbXMsIHRydWUpLnRoZW4ocmVzID0+IHtcclxuICAgICAgICAgICAgcmV0dXJuIHJlcztcclxuICAgICAgICB9KVxyXG4gICAgfVxyXG4gICAgIC8vIOiOt+WPluetlOmimOa0u+WKqOS/oeaBr1xyXG4gICAgIHN0YXRpYyBhc3luYyBhbnN3ZXJJbmZvKCkge1xyXG4gICAgICAgIGxldCB1cmwgPSBgJHt0aGlzLmJhc2VVcmx9L2Fuc3dlcmA7XHJcbiAgICAgICAgbGV0IHBhcmFtcyA9IHtcclxuICAgICAgICAgICAgc2Vzc2lvbklkOiB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnNlc3Npb25JZCxcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHRoaXMucG9zdCh1cmwsIHBhcmFtcywgdHJ1ZSkudGhlbihyZXMgPT4ge1xyXG4gICAgICAgICAgICByZXR1cm4gcmVzO1xyXG4gICAgICAgIH0pXHJcbiAgICB9XHJcbiAgICAvLyDmnKzlkajnrZTpopjliJfooahcclxuICAgIHN0YXRpYyBhc3luYyBhbnN3ZXJsaXN0KCkge1xyXG4gICAgICAgIGxldCB1cmwgPSBgJHt0aGlzLmJhc2VVcmx9L2Fuc3dlci9saXN0YDtcclxuICAgICAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICAgICAgICBzZXNzaW9uSWQ6IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuc2Vzc2lvbklkLFxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdGhpcy5wb3N0KHVybCwgcGFyYW1zLCB0cnVlKS50aGVuKHJlcyA9PiB7XHJcbiAgICAgICAgICAgIHJldHVybiByZXM7XHJcbiAgICAgICAgfSlcclxuICAgIH1cclxuICAgIC8vIOaOkuihjOamnFxyXG4gICAgc3RhdGljIGFzeW5jIHJhbmtpbmcodHlwZSkge1xyXG4gICAgICAgIGxldCB1cmwgPSBgJHt0aGlzLmJhc2VVcmx9L2Fuc3dlci9yYW5raW5nYDtcclxuICAgICAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICAgICAgICBzZXNzaW9uSWQ6IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuc2Vzc2lvbklkLFxyXG4gICAgICAgICAgICB0eXBlXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB0aGlzLnBvc3QodXJsLCBwYXJhbXMsIHRydWUpLnRoZW4ocmVzID0+IHtcclxuICAgICAgICAgICAgcmV0dXJuIHJlcztcclxuICAgICAgICB9KVxyXG4gICAgfVxyXG59XHJcblxyXG4iXX0=