'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = undefined;

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _base2 = require('./../api/base.js');

var _base3 = _interopRequireDefault(_base2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var agent = function (_base) {
    _inherits(agent, _base);

    function agent() {
        _classCallCheck(this, agent);

        return _possibleConstructorReturn(this, (agent.__proto__ || Object.getPrototypeOf(agent)).apply(this, arguments));
    }

    _createClass(agent, null, [{
        key: 'orders',
        value: function () {
            var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(opt) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee$(_context) {
                    while (1) {
                        switch (_context.prev = _context.next) {
                            case 0:
                                url = this.baseUrl + '/member/agent/orders';
                                params = _extends({}, opt, {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                });
                                return _context.abrupt('return', this.get(url, params, true, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context.stop();
                        }
                    }
                }, _callee, this);
            }));

            function orders(_x) {
                return _ref.apply(this, arguments);
            }

            return orders;
        }()
    }, {
        key: 'agenter',
        value: function () {
            var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
                var url, params;
                return regeneratorRuntime.wrap(function _callee2$(_context2) {
                    while (1) {
                        switch (_context2.prev = _context2.next) {
                            case 0:
                                url = this.baseUrl + '/member/agent';
                                params = {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                };
                                return _context2.abrupt('return', this.get(url, params, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context2.stop();
                        }
                    }
                }, _callee2, this);
            }));

            function agenter() {
                return _ref2.apply(this, arguments);
            }

            return agenter;
        }()
    }, {
        key: 'sign',
        value: function () {
            var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(opt) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee3$(_context3) {
                    while (1) {
                        switch (_context3.prev = _context3.next) {
                            case 0:
                                url = this.baseUrl + '/member/agent/apply';
                                params = _extends({}, opt, {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                });
                                return _context3.abrupt('return', this.post(url, params, true, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context3.stop();
                        }
                    }
                }, _callee3, this);
            }));

            function sign(_x2) {
                return _ref3.apply(this, arguments);
            }

            return sign;
        }()
    }, {
        key: 'plusUp',
        value: function () {
            var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4(opt) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee4$(_context4) {
                    while (1) {
                        switch (_context4.prev = _context4.next) {
                            case 0:
                                url = this.baseUrl + '/member/plus/up';
                                params = {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                };
                                return _context4.abrupt('return', this.post(url, params, true, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context4.stop();
                        }
                    }
                }, _callee4, this);
            }));

            function plusUp(_x3) {
                return _ref4.apply(this, arguments);
            }

            return plusUp;
        }()
    }, {
        key: 'agentIndex',
        value: function () {
            var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
                var url, params;
                return regeneratorRuntime.wrap(function _callee5$(_context5) {
                    while (1) {
                        switch (_context5.prev = _context5.next) {
                            case 0:
                                url = this.baseUrl + '/member/agent/index';
                                params = {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                };
                                return _context5.abrupt('return', this.post(url, params, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context5.stop();
                        }
                    }
                }, _callee5, this);
            }));

            function agentIndex() {
                return _ref5.apply(this, arguments);
            }

            return agentIndex;
        }()
    }, {
        key: 'applyV2',
        value: function () {
            var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
                var url, params;
                return regeneratorRuntime.wrap(function _callee6$(_context6) {
                    while (1) {
                        switch (_context6.prev = _context6.next) {
                            case 0:
                                url = this.baseUrl + '/member/agent/applyV2';
                                params = {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                };
                                return _context6.abrupt('return', this.post(url, params, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context6.stop();
                        }
                    }
                }, _callee6, this);
            }));

            function applyV2() {
                return _ref6.apply(this, arguments);
            }

            return applyV2;
        }()
    }, {
        key: 'withdrawLog',
        value: function () {
            var _ref7 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee7() {
                var url, params;
                return regeneratorRuntime.wrap(function _callee7$(_context7) {
                    while (1) {
                        switch (_context7.prev = _context7.next) {
                            case 0:
                                url = this.baseUrl + '/member/agent/withdrawLog';
                                params = {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                };
                                return _context7.abrupt('return', this.post(url, params, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context7.stop();
                        }
                    }
                }, _callee7, this);
            }));

            function withdrawLog() {
                return _ref7.apply(this, arguments);
            }

            return withdrawLog;
        }()
    }, {
        key: 'fanslist',
        value: function () {
            var _ref8 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee8() {
                var url, params;
                return regeneratorRuntime.wrap(function _callee8$(_context8) {
                    while (1) {
                        switch (_context8.prev = _context8.next) {
                            case 0:
                                url = this.baseUrl + '/member/agent/fans';
                                params = {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                };
                                return _context8.abrupt('return', this.post(url, params, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context8.stop();
                        }
                    }
                }, _callee8, this);
            }));

            function fanslist() {
                return _ref8.apply(this, arguments);
            }

            return fanslist;
        }()
    }]);

    return agent;
}(_base3.default);

exports.default = agent;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwaS5qcyJdLCJuYW1lcyI6WyJhZ2VudCIsIm9wdCIsInVybCIsImJhc2VVcmwiLCJwYXJhbXMiLCJzZXNzaW9uSWQiLCJ3ZXB5IiwiJGluc3RhbmNlIiwiZ2xvYmFsRGF0YSIsImdldCIsInRoZW4iLCJyZXMiLCJwb3N0IiwiYmFzZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7QUFBQTs7OztBQUNBOzs7Ozs7Ozs7Ozs7OztJQUVxQkEsSzs7Ozs7Ozs7Ozs7O2dHQUNHQyxHOzs7Ozs7QUFDWkMsbUMsR0FBUyxLQUFLQyxPO0FBQ2RDLHNDLGdCQUNHSCxHO0FBQ0hJLCtDQUFXQyxlQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJIOztpRUFFbEMsS0FBS0ksR0FBTCxDQUFTUCxHQUFULEVBQWNFLE1BQWQsRUFBc0IsSUFBdEIsRUFBMkIsSUFBM0IsRUFBaUNNLElBQWpDLENBQXNDLGVBQU87QUFDaEQsMkNBQU9DLEdBQVA7QUFDSCxpQ0FGTSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBS0hULG1DLEdBQVMsS0FBS0MsTztBQUNkQyxzQyxHQUFTO0FBQ1RDLCtDQUFXQyxlQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJIO0FBRDVCLGlDO2tFQUdOLEtBQUtJLEdBQUwsQ0FBU1AsR0FBVCxFQUFjRSxNQUFkLEVBQXNCLElBQXRCLEVBQTRCTSxJQUE1QixDQUFpQyxlQUFPO0FBQzNDLDJDQUFPQyxHQUFQO0FBQ0gsaUNBRk0sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztrR0FJT1YsRzs7Ozs7O0FBQ1ZDLG1DLEdBQVMsS0FBS0MsTztBQUNkQyxzQyxnQkFDR0gsRztBQUNISSwrQ0FBV0MsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCSDs7a0VBRWxDLEtBQUtPLElBQUwsQ0FBVVYsR0FBVixFQUFlRSxNQUFmLEVBQXVCLElBQXZCLEVBQTRCLElBQTVCLEVBQWtDTSxJQUFsQyxDQUF1QyxlQUFPO0FBQ2pELDJDQUFPQyxHQUFQO0FBQ0gsaUNBRk0sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztrR0FJU1YsRzs7Ozs7O0FBQ1pDLG1DLEdBQVMsS0FBS0MsTztBQUNkQyxzQyxHQUFTO0FBQ1RDLCtDQUFXQyxlQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJIO0FBRDVCLGlDO2tFQUdOLEtBQUtPLElBQUwsQ0FBVVYsR0FBVixFQUFlRSxNQUFmLEVBQXVCLElBQXZCLEVBQTRCLElBQTVCLEVBQWtDTSxJQUFsQyxDQUF1QyxlQUFPO0FBQ2pELDJDQUFPQyxHQUFQO0FBQ0gsaUNBRk0sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUtIVCxtQyxHQUFTLEtBQUtDLE87QUFDZEMsc0MsR0FBUztBQUNUQywrQ0FBV0MsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCSDtBQUQ1QixpQztrRUFHTixLQUFLTyxJQUFMLENBQVVWLEdBQVYsRUFBZUUsTUFBZixFQUF1QixJQUF2QixFQUE2Qk0sSUFBN0IsQ0FBa0MsZUFBTztBQUM1QywyQ0FBT0MsR0FBUDtBQUNILGlDQUZNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFLSFQsbUMsR0FBUyxLQUFLQyxPO0FBQ2RDLHNDLEdBQVM7QUFDVEMsK0NBQVdDLGVBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQkg7QUFENUIsaUM7a0VBR04sS0FBS08sSUFBTCxDQUFVVixHQUFWLEVBQWVFLE1BQWYsRUFBdUIsSUFBdkIsRUFBNkJNLElBQTdCLENBQWtDLGVBQU87QUFDNUMsMkNBQU9DLEdBQVA7QUFDSCxpQ0FGTSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBS0hULG1DLEdBQVMsS0FBS0MsTztBQUNkQyxzQyxHQUFTO0FBQ1RDLCtDQUFXQyxlQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJIO0FBRDVCLGlDO2tFQUdOLEtBQUtPLElBQUwsQ0FBVVYsR0FBVixFQUFlRSxNQUFmLEVBQXVCLElBQXZCLEVBQTZCTSxJQUE3QixDQUFrQyxlQUFPO0FBQzVDLDJDQUFPQyxHQUFQO0FBQ0gsaUNBRk0sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUtIVCxtQyxHQUFTLEtBQUtDLE87QUFDZEMsc0MsR0FBUztBQUNUQywrQ0FBV0MsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCSDtBQUQ1QixpQztrRUFHTixLQUFLTyxJQUFMLENBQVVWLEdBQVYsRUFBZUUsTUFBZixFQUF1QixJQUF2QixFQUE2Qk0sSUFBN0IsQ0FBa0MsZUFBTztBQUM1QywyQ0FBT0MsR0FBUDtBQUNILGlDQUZNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUF2RW9CRSxjOztrQkFBZGIsSyIsImZpbGUiOiJhcGkuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgd2VweSBmcm9tICd3ZXB5J1xyXG5pbXBvcnQgYmFzZSBmcm9tICcuLi9hcGkvYmFzZSdcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIGFnZW50IGV4dGVuZHMgYmFzZSB7XHJcbiAgICBzdGF0aWMgYXN5bmMgb3JkZXJzKG9wdCkge1xyXG4gICAgICAgIGxldCB1cmwgPSBgJHt0aGlzLmJhc2VVcmx9L21lbWJlci9hZ2VudC9vcmRlcnNgO1xyXG4gICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgIC4uLm9wdCxcclxuICAgICAgICAgICAgc2Vzc2lvbklkOiB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnNlc3Npb25JZFxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdGhpcy5nZXQodXJsLCBwYXJhbXMsIHRydWUsdHJ1ZSkudGhlbihyZXMgPT4ge1xyXG4gICAgICAgICAgICByZXR1cm4gcmVzO1xyXG4gICAgICAgIH0pXHJcbiAgICB9XHJcbiAgICBzdGF0aWMgYXN5bmMgYWdlbnRlcigpIHtcclxuICAgICAgICBsZXQgdXJsID0gYCR7dGhpcy5iYXNlVXJsfS9tZW1iZXIvYWdlbnRgO1xyXG4gICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgIHNlc3Npb25JZDogd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5zZXNzaW9uSWRcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuZ2V0KHVybCwgcGFyYW1zLCB0cnVlKS50aGVuKHJlcyA9PiB7XHJcbiAgICAgICAgICAgIHJldHVybiByZXM7XHJcbiAgICAgICAgfSlcclxuICAgIH1cclxuICAgIHN0YXRpYyBhc3luYyBzaWduKG9wdCkge1xyXG4gICAgICAgIGxldCB1cmwgPSBgJHt0aGlzLmJhc2VVcmx9L21lbWJlci9hZ2VudC9hcHBseWA7XHJcbiAgICAgICAgbGV0IHBhcmFtcyA9IHtcclxuICAgICAgICAgICAgLi4ub3B0LFxyXG4gICAgICAgICAgICBzZXNzaW9uSWQ6IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuc2Vzc2lvbklkXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB0aGlzLnBvc3QodXJsLCBwYXJhbXMsIHRydWUsdHJ1ZSkudGhlbihyZXMgPT4ge1xyXG4gICAgICAgICAgICByZXR1cm4gcmVzO1xyXG4gICAgICAgIH0pXHJcbiAgICB9XHJcbiAgICBzdGF0aWMgYXN5bmMgcGx1c1VwKG9wdCkge1xyXG4gICAgICAgIGxldCB1cmwgPSBgJHt0aGlzLmJhc2VVcmx9L21lbWJlci9wbHVzL3VwYDtcclxuICAgICAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICAgICAgICBzZXNzaW9uSWQ6IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuc2Vzc2lvbklkXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB0aGlzLnBvc3QodXJsLCBwYXJhbXMsIHRydWUsdHJ1ZSkudGhlbihyZXMgPT4ge1xyXG4gICAgICAgICAgICByZXR1cm4gcmVzO1xyXG4gICAgICAgIH0pXHJcbiAgICB9XHJcbiAgICBzdGF0aWMgYXN5bmMgYWdlbnRJbmRleCgpIHtcclxuICAgICAgICBsZXQgdXJsID0gYCR7dGhpcy5iYXNlVXJsfS9tZW1iZXIvYWdlbnQvaW5kZXhgO1xyXG4gICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgIHNlc3Npb25JZDogd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5zZXNzaW9uSWRcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHRoaXMucG9zdCh1cmwsIHBhcmFtcywgdHJ1ZSkudGhlbihyZXMgPT4ge1xyXG4gICAgICAgICAgICByZXR1cm4gcmVzO1xyXG4gICAgICAgIH0pXHJcbiAgICB9XHJcbiAgICBzdGF0aWMgYXN5bmMgYXBwbHlWMigpIHtcclxuICAgICAgICBsZXQgdXJsID0gYCR7dGhpcy5iYXNlVXJsfS9tZW1iZXIvYWdlbnQvYXBwbHlWMmA7XHJcbiAgICAgICAgbGV0IHBhcmFtcyA9IHtcclxuICAgICAgICAgICAgc2Vzc2lvbklkOiB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnNlc3Npb25JZFxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdGhpcy5wb3N0KHVybCwgcGFyYW1zLCB0cnVlKS50aGVuKHJlcyA9PiB7XHJcbiAgICAgICAgICAgIHJldHVybiByZXM7XHJcbiAgICAgICAgfSlcclxuICAgIH1cclxuICAgIHN0YXRpYyBhc3luYyB3aXRoZHJhd0xvZygpIHtcclxuICAgICAgICBsZXQgdXJsID0gYCR7dGhpcy5iYXNlVXJsfS9tZW1iZXIvYWdlbnQvd2l0aGRyYXdMb2dgO1xyXG4gICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgIHNlc3Npb25JZDogd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5zZXNzaW9uSWRcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHRoaXMucG9zdCh1cmwsIHBhcmFtcywgdHJ1ZSkudGhlbihyZXMgPT4ge1xyXG4gICAgICAgICAgICByZXR1cm4gcmVzO1xyXG4gICAgICAgIH0pXHJcbiAgICB9XHJcbiAgICBzdGF0aWMgYXN5bmMgZmFuc2xpc3QoKSB7XHJcbiAgICAgICAgbGV0IHVybCA9IGAke3RoaXMuYmFzZVVybH0vbWVtYmVyL2FnZW50L2ZhbnNgO1xyXG4gICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgIHNlc3Npb25JZDogd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5zZXNzaW9uSWRcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHRoaXMucG9zdCh1cmwsIHBhcmFtcywgdHJ1ZSkudGhlbihyZXMgPT4ge1xyXG4gICAgICAgICAgICByZXR1cm4gcmVzO1xyXG4gICAgICAgIH0pXHJcbiAgICB9XHJcbn0iXX0=