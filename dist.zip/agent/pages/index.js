"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

var _api = require('./../api.js');

var _api2 = _interopRequireDefault(_api);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

var _utils = require('./../../store/utils.js');

var _utils2 = _interopRequireDefault(_utils);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
    _inherits(Dialog, _wepy$page);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
            navigationBarTitleText: "我的代理"
        }, _this.data = {
            agent: {},
            TabCur: 0,
            orders: [],
            orderState: [2, 3],
            pageIndex: 1,
            toload: true,
            loadmoring: false
        }, _this.methods = {
            tabSelect: function tabSelect(e) {
                var cur = e.currentTarget.dataset.id || e.detail.current;
                if (this.TabCur != cur) {
                    this.TabCur = cur;
                    this.orders = [];
                    this.pageIndex = 1;
                    this.loadData();
                }
            },
            todetaile: function todetaile(id) {
                _wepy2.default.navigateTo({
                    url: '/pages/my/order?id=' + id + "&notic=1"
                });
            },
            toShare: function () {
                var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(e) {
                    return regeneratorRuntime.wrap(function _callee$(_context) {
                        while (1) {
                            switch (_context.prev = _context.next) {
                                case 0:
                                    if (!(e.detail.errMsg == "getUserInfo:ok")) {
                                        _context.next = 5;
                                        break;
                                    }

                                    _context.next = 3;
                                    return _auth2.default.getUserinfo(e.detail);

                                case 3:
                                    _utils2.default.save('agentInfo', {
                                        path: 'pages/home/index',
                                        id: this.agent.id
                                    });
                                    _wepy2.default.navigateTo({
                                        url: './share'
                                    });

                                case 5:
                                case "end":
                                    return _context.stop();
                            }
                        }
                    }, _callee, this);
                }));

                function toShare(_x) {
                    return _ref2.apply(this, arguments);
                }

                return toShare;
            }()
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(Dialog, [{
        key: "onLoad",
        value: function () {
            var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
                var _ref4, agent;

                return regeneratorRuntime.wrap(function _callee2$(_context2) {
                    while (1) {
                        switch (_context2.prev = _context2.next) {
                            case 0:
                                _context2.next = 2;
                                return _api2.default.agenter();

                            case 2:
                                _ref4 = _context2.sent;
                                agent = _ref4.agent;

                                this.agent = agent;
                                _context2.next = 7;
                                return this.loadData();

                            case 7:
                                this.$apply();

                            case 8:
                            case "end":
                                return _context2.stop();
                        }
                    }
                }, _callee2, this);
            }));

            function onLoad() {
                return _ref3.apply(this, arguments);
            }

            return onLoad;
        }()
    }, {
        key: "loadData",
        value: function () {
            var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(pageIndex) {
                var params, res, ordersList;
                return regeneratorRuntime.wrap(function _callee3$(_context3) {
                    while (1) {
                        switch (_context3.prev = _context3.next) {
                            case 0:
                                params = {
                                    orderState: this.orderState[this.TabCur],
                                    pageIndex: pageIndex || this.pageIndex,
                                    pageSize: 10
                                };
                                _context3.next = 3;
                                return _api2.default.orders(params);

                            case 3:
                                res = _context3.sent;

                                if (!(res.errcode == 200)) {
                                    _context3.next = 19;
                                    break;
                                }

                                ordersList = res.data.ordersList;

                                if (ordersList.length) {
                                    _context3.next = 14;
                                    break;
                                }

                                if (pageIndex == 1) {
                                    this.orders = ordersList;
                                }
                                // this.pageIndex = pageIndex
                                this.toload = true;
                                this.loadmoring = true;
                                this.$apply();
                                return _context3.abrupt("return", false);

                            case 14:
                                if (pageIndex > 1) this.pageIndex = pageIndex;
                                if (pageIndex == 1) {
                                    this.orders = ordersList;
                                } else {
                                    this.orders = this.orders.concat(ordersList);
                                }
                                this.loadmoring = true;

                            case 17:
                                console.log(this.loadmoring);
                                this.$apply();

                            case 19:
                            case "end":
                                return _context3.stop();
                        }
                    }
                }, _callee3, this);
            }));

            function loadData(_x2) {
                return _ref5.apply(this, arguments);
            }

            return loadData;
        }()
    }, {
        key: "onReachBottom",
        value: function onReachBottom() {
            this.getMore();
        }
    }, {
        key: "getMore",
        value: function () {
            var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
                return regeneratorRuntime.wrap(function _callee4$(_context4) {
                    while (1) {
                        switch (_context4.prev = _context4.next) {
                            case 0:
                                this.loadmoring = true;
                                this.toload = false;
                                _context4.next = 4;
                                return this.loadData(this.pageIndex + 1);

                            case 4:
                                this.$apply();

                            case 5:
                            case "end":
                                return _context4.stop();
                        }
                    }
                }, _callee4, this);
            }));

            function getMore() {
                return _ref6.apply(this, arguments);
            }

            return getMore;
        }()
    }]);

    return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'agent/pages/index'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LmpzIl0sIm5hbWVzIjpbIkRpYWxvZyIsImNvbmZpZyIsIm5hdmlnYXRpb25CYXJUaXRsZVRleHQiLCJkYXRhIiwiYWdlbnQiLCJUYWJDdXIiLCJvcmRlcnMiLCJvcmRlclN0YXRlIiwicGFnZUluZGV4IiwidG9sb2FkIiwibG9hZG1vcmluZyIsIm1ldGhvZHMiLCJ0YWJTZWxlY3QiLCJlIiwiY3VyIiwiY3VycmVudFRhcmdldCIsImRhdGFzZXQiLCJpZCIsImRldGFpbCIsImN1cnJlbnQiLCJsb2FkRGF0YSIsInRvZGV0YWlsZSIsIndlcHkiLCJuYXZpZ2F0ZVRvIiwidXJsIiwidG9TaGFyZSIsImVyck1zZyIsImF1dGgiLCJnZXRVc2VyaW5mbyIsInN0b3JlIiwic2F2ZSIsInBhdGgiLCJhZ2VudGVyIiwiJGFwcGx5IiwicGFyYW1zIiwicGFnZVNpemUiLCJyZXMiLCJlcnJjb2RlIiwib3JkZXJzTGlzdCIsImxlbmd0aCIsImNvbmNhdCIsImNvbnNvbGUiLCJsb2ciLCJnZXRNb3JlIiwicGFnZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQ0k7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7Ozs7Ozs7Ozs7Ozs7SUFDcUJBLE07Ozs7Ozs7Ozs7Ozs7OzBMQUNqQkMsTSxHQUFTO0FBQ0xDLG9DQUF3QjtBQURuQixTLFFBR1RDLEksR0FBTztBQUNIQyxtQkFBTyxFQURKO0FBRUhDLG9CQUFRLENBRkw7QUFHSEMsb0JBQVEsRUFITDtBQUlIQyx3QkFBWSxDQUFDLENBQUQsRUFBSSxDQUFKLENBSlQ7QUFLSEMsdUJBQVcsQ0FMUjtBQU1IQyxvQkFBUSxJQU5MO0FBT0hDLHdCQUFZO0FBUFQsUyxRQXlEUEMsTyxHQUFVO0FBQ05DLHFCQURNLHFCQUNJQyxDQURKLEVBQ087QUFDVCxvQkFBSUMsTUFBTUQsRUFBRUUsYUFBRixDQUFnQkMsT0FBaEIsQ0FBd0JDLEVBQXhCLElBQThCSixFQUFFSyxNQUFGLENBQVNDLE9BQWpEO0FBQ0Esb0JBQUksS0FBS2QsTUFBTCxJQUFlUyxHQUFuQixFQUF3QjtBQUNwQix5QkFBS1QsTUFBTCxHQUFjUyxHQUFkO0FBQ0EseUJBQUtSLE1BQUwsR0FBYyxFQUFkO0FBQ0EseUJBQUtFLFNBQUwsR0FBaUIsQ0FBakI7QUFDQSx5QkFBS1ksUUFBTDtBQUNIO0FBQ0osYUFUSztBQVVOQyxxQkFWTSxxQkFVSUosRUFWSixFQVVRO0FBQ1ZLLCtCQUFLQyxVQUFMLENBQWdCO0FBQ1pDLHlCQUFLLHdCQUF3QlAsRUFBeEIsR0FBNkI7QUFEdEIsaUJBQWhCO0FBR0gsYUFkSztBQWVEUSxtQkFmQztBQUFBLHFHQWVPWixDQWZQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQ0FnQkVBLEVBQUVLLE1BQUYsQ0FBU1EsTUFBVCxJQUFtQixnQkFoQnJCO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUEsMkNBaUJRQyxlQUFLQyxXQUFMLENBQWlCZixFQUFFSyxNQUFuQixDQWpCUjs7QUFBQTtBQWtCRVcsb0RBQU1DLElBQU4sQ0FBVyxXQUFYLEVBQXdCO0FBQ3BCQyw4Q0FBTSxrQkFEYztBQUVwQmQsNENBQUksS0FBS2IsS0FBTCxDQUFXYTtBQUZLLHFDQUF4QjtBQUlBSyxtREFBS0MsVUFBTCxDQUFnQjtBQUNaQyw2Q0FBSztBQURPLHFDQUFoQjs7QUF0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQSxTOzs7Ozs7Ozs7Ozs7Ozt1Q0E3Q0l2QixjQUFPK0IsT0FBUCxFOzs7O0FBRE41QixxQyxTQUFBQSxLOztBQUVKLHFDQUFLQSxLQUFMLEdBQWFBLEtBQWI7O3VDQUNNLEtBQUtnQixRQUFMLEU7OztBQUNOLHFDQUFLYSxNQUFMOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O2tHQUVXekIsUzs7Ozs7O0FBQ1AwQixzQyxHQUFTO0FBQ1QzQixnREFBWSxLQUFLQSxVQUFMLENBQWdCLEtBQUtGLE1BQXJCLENBREg7QUFFVEcsK0NBQVdBLGFBQWEsS0FBS0EsU0FGcEI7QUFHVDJCLDhDQUFVO0FBSEQsaUM7O3VDQUtHbEMsY0FBT0ssTUFBUCxDQUFjNEIsTUFBZCxDOzs7QUFBWkUsbUM7O3NDQUNBQSxJQUFJQyxPQUFKLElBQWUsRzs7Ozs7QUFDWEMsMEMsR0FBYUYsSUFBSWpDLElBQUosQ0FBU21DLFU7O29DQUNyQkEsV0FBV0MsTTs7Ozs7QUFDWixvQ0FBSS9CLGFBQWEsQ0FBakIsRUFBb0I7QUFDaEIseUNBQUtGLE1BQUwsR0FBY2dDLFVBQWQ7QUFDSDtBQUNEO0FBQ0EscUNBQUs3QixNQUFMLEdBQWMsSUFBZDtBQUNBLHFDQUFLQyxVQUFMLEdBQWtCLElBQWxCO0FBQ0EscUNBQUt1QixNQUFMO2tFQUNPLEs7OztBQUVQLG9DQUFJekIsWUFBWSxDQUFoQixFQUFtQixLQUFLQSxTQUFMLEdBQWlCQSxTQUFqQjtBQUNuQixvQ0FBSUEsYUFBYSxDQUFqQixFQUFvQjtBQUNoQix5Q0FBS0YsTUFBTCxHQUFjZ0MsVUFBZDtBQUNILGlDQUZELE1BRU87QUFDSCx5Q0FBS2hDLE1BQUwsR0FBYyxLQUFLQSxNQUFMLENBQVlrQyxNQUFaLENBQW1CRixVQUFuQixDQUFkO0FBQ0g7QUFDRCxxQ0FBSzVCLFVBQUwsR0FBa0IsSUFBbEI7OztBQUVKK0Isd0NBQVFDLEdBQVIsQ0FBWSxLQUFLaEMsVUFBakI7QUFDQSxxQ0FBS3VCLE1BQUw7Ozs7Ozs7Ozs7Ozs7Ozs7Ozt3Q0FHUTtBQUNaLGlCQUFLVSxPQUFMO0FBQ0g7Ozs7Ozs7OztBQUVHLHFDQUFLakMsVUFBTCxHQUFrQixJQUFsQjtBQUNBLHFDQUFLRCxNQUFMLEdBQWMsS0FBZDs7dUNBQ00sS0FBS1csUUFBTCxDQUFjLEtBQUtaLFNBQUwsR0FBaUIsQ0FBL0IsQzs7O0FBQ04scUNBQUt5QixNQUFMOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBM0Q0QlgsZUFBS3NCLEk7O2tCQUFwQjVDLE0iLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuICAgIGltcG9ydCB3ZXB5IGZyb20gXCJ3ZXB5XCJcclxuICAgIGltcG9ydCBUaXBzIGZyb20gXCJAL3V0aWxzL1RpcHNcIlxyXG4gICAgaW1wb3J0IGNvbmZpZyBmcm9tIFwiLi4vYXBpXCJcclxuICAgIGltcG9ydCBhdXRoIGZyb20gXCJAL2FwaS9hdXRoXCJcclxuICAgIGltcG9ydCBzdG9yZSBmcm9tIFwiQC9zdG9yZS91dGlsc1wiXHJcbiAgICBleHBvcnQgZGVmYXVsdCBjbGFzcyBEaWFsb2cgZXh0ZW5kcyB3ZXB5LnBhZ2Uge1xyXG4gICAgICAgIGNvbmZpZyA9IHtcclxuICAgICAgICAgICAgbmF2aWdhdGlvbkJhclRpdGxlVGV4dDogXCLmiJHnmoTku6PnkIZcIlxyXG4gICAgICAgIH07XHJcbiAgICAgICAgZGF0YSA9IHtcclxuICAgICAgICAgICAgYWdlbnQ6IHt9LFxyXG4gICAgICAgICAgICBUYWJDdXI6IDAsXHJcbiAgICAgICAgICAgIG9yZGVyczogW10sXHJcbiAgICAgICAgICAgIG9yZGVyU3RhdGU6IFsyLCAzXSxcclxuICAgICAgICAgICAgcGFnZUluZGV4OiAxLFxyXG4gICAgICAgICAgICB0b2xvYWQ6IHRydWUsXHJcbiAgICAgICAgICAgIGxvYWRtb3Jpbmc6IGZhbHNlLFxyXG4gICAgICAgIH07XHJcbiAgICAgICAgYXN5bmMgb25Mb2FkKCkge1xyXG4gICAgICAgICAgICBsZXQge1xyXG4gICAgICAgICAgICAgICAgYWdlbnRcclxuICAgICAgICAgICAgfSA9IGF3YWl0IGNvbmZpZy5hZ2VudGVyKClcclxuICAgICAgICAgICAgdGhpcy5hZ2VudCA9IGFnZW50XHJcbiAgICAgICAgICAgIGF3YWl0IHRoaXMubG9hZERhdGEoKVxyXG4gICAgICAgICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGFzeW5jIGxvYWREYXRhKHBhZ2VJbmRleCkge1xyXG4gICAgICAgICAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICAgICAgICAgICAgb3JkZXJTdGF0ZTogdGhpcy5vcmRlclN0YXRlW3RoaXMuVGFiQ3VyXSxcclxuICAgICAgICAgICAgICAgIHBhZ2VJbmRleDogcGFnZUluZGV4IHx8IHRoaXMucGFnZUluZGV4LFxyXG4gICAgICAgICAgICAgICAgcGFnZVNpemU6IDEwXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGNvbmZpZy5vcmRlcnMocGFyYW1zKVxyXG4gICAgICAgICAgICBpZiAocmVzLmVycmNvZGUgPT0gMjAwKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgb3JkZXJzTGlzdCA9IHJlcy5kYXRhLm9yZGVyc0xpc3RcclxuICAgICAgICAgICAgICAgIGlmICghb3JkZXJzTGlzdC5sZW5ndGgpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAocGFnZUluZGV4ID09IDEpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5vcmRlcnMgPSBvcmRlcnNMaXN0XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8vIHRoaXMucGFnZUluZGV4ID0gcGFnZUluZGV4XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy50b2xvYWQgPSB0cnVlXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5sb2FkbW9yaW5nID0gdHJ1ZVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHBhZ2VJbmRleCA+IDEpIHRoaXMucGFnZUluZGV4ID0gcGFnZUluZGV4XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHBhZ2VJbmRleCA9PSAxKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMub3JkZXJzID0gb3JkZXJzTGlzdFxyXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMub3JkZXJzID0gdGhpcy5vcmRlcnMuY29uY2F0KG9yZGVyc0xpc3QpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubG9hZG1vcmluZyA9IHRydWVcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKHRoaXMubG9hZG1vcmluZylcclxuICAgICAgICAgICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBvblJlYWNoQm90dG9tKCkge1xyXG4gICAgICAgICAgICB0aGlzLmdldE1vcmUoKVxyXG4gICAgICAgIH1cclxuICAgICAgICBhc3luYyBnZXRNb3JlKCkge1xyXG4gICAgICAgICAgICB0aGlzLmxvYWRtb3JpbmcgPSB0cnVlXHJcbiAgICAgICAgICAgIHRoaXMudG9sb2FkID0gZmFsc2VcclxuICAgICAgICAgICAgYXdhaXQgdGhpcy5sb2FkRGF0YSh0aGlzLnBhZ2VJbmRleCArIDEpXHJcbiAgICAgICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgICB9XHJcbiAgICAgICAgbWV0aG9kcyA9IHtcclxuICAgICAgICAgICAgdGFiU2VsZWN0KGUpIHtcclxuICAgICAgICAgICAgICAgIGxldCBjdXIgPSBlLmN1cnJlbnRUYXJnZXQuZGF0YXNldC5pZCB8fCBlLmRldGFpbC5jdXJyZW50O1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuVGFiQ3VyICE9IGN1cikge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuVGFiQ3VyID0gY3VyXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5vcmRlcnMgPSBbXVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMucGFnZUluZGV4ID0gMVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubG9hZERhdGEoKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB0b2RldGFpbGUoaWQpIHtcclxuICAgICAgICAgICAgICAgIHdlcHkubmF2aWdhdGVUbyh7XHJcbiAgICAgICAgICAgICAgICAgICAgdXJsOiAnL3BhZ2VzL215L29yZGVyP2lkPScgKyBpZCArIFwiJm5vdGljPTFcIlxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgYXN5bmMgdG9TaGFyZShlKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoZS5kZXRhaWwuZXJyTXNnID09IFwiZ2V0VXNlckluZm86b2tcIikge1xyXG4gICAgICAgICAgICAgICAgICAgIGF3YWl0IGF1dGguZ2V0VXNlcmluZm8oZS5kZXRhaWwpXHJcbiAgICAgICAgICAgICAgICAgICAgc3RvcmUuc2F2ZSgnYWdlbnRJbmZvJywge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYXRoOiAncGFnZXMvaG9tZS9pbmRleCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkOiB0aGlzLmFnZW50LmlkXHJcbiAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB1cmw6ICcuL3NoYXJlJ1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuIl19