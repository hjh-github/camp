"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

var _api = require('./../api.js');

var _api2 = _interopRequireDefault(_api);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

var _utils = require('./../../store/utils.js');

var _utils2 = _interopRequireDefault(_utils);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
    _inherits(Dialog, _wepy$page);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
            navigationBarTitleText: "我的代理"
        }, _this.data = {
            agent: {},
            TabCur: 0,
            orders: [],
            orderState: [2, 3],
            pageIndex: 1,
            toload: true,
            loadmoring: false
        }, _this.methods = {
            tabSelect: function tabSelect(e) {
                var cur = e.currentTarget.dataset.id || e.detail.current;
                if (this.TabCur != cur) {
                    this.TabCur = cur;
                    this.orders = [];
                    this.pageIndex = 1;
                    this.loadData();
                }
            },
            todetaile: function todetaile(id) {
                _wepy2.default.navigateTo({
                    url: '/pages/my/order?id=' + id + "&notic=1"
                });
            },
            toShare: function () {
                var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(e) {
                    return regeneratorRuntime.wrap(function _callee$(_context) {
                        while (1) {
                            switch (_context.prev = _context.next) {
                                case 0:
                                    if (!(e.detail.errMsg == "getUserInfo:ok")) {
                                        _context.next = 5;
                                        break;
                                    }

                                    _context.next = 3;
                                    return _auth2.default.getUserinfo(e.detail);

                                case 3:
                                    _utils2.default.save('agentInfo', {
                                        path: 'pages/home/index',
                                        id: this.agent.id
                                    });
                                    _wepy2.default.navigateTo({
                                        url: './share'
                                    });

                                case 5:
                                case "end":
                                    return _context.stop();
                            }
                        }
                    }, _callee, this);
                }));

                function toShare(_x) {
                    return _ref2.apply(this, arguments);
                }

                return toShare;
            }()
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(Dialog, [{
        key: "onLoad",
        value: function () {
            var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
                var _ref4, agent;

                return regeneratorRuntime.wrap(function _callee2$(_context2) {
                    while (1) {
                        switch (_context2.prev = _context2.next) {
                            case 0:
                                _context2.next = 2;
                                return _api2.default.agenter();

                            case 2:
                                _ref4 = _context2.sent;
                                agent = _ref4.agent;

                                this.agent = agent;
                                _context2.next = 7;
                                return this.loadData();

                            case 7:
                                this.$apply();

                            case 8:
                            case "end":
                                return _context2.stop();
                        }
                    }
                }, _callee2, this);
            }));

            function onLoad() {
                return _ref3.apply(this, arguments);
            }

            return onLoad;
        }()
    }, {
        key: "loadData",
        value: function () {
            var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(pageIndex) {
                var params, res, ordersList;
                return regeneratorRuntime.wrap(function _callee3$(_context3) {
                    while (1) {
                        switch (_context3.prev = _context3.next) {
                            case 0:
                                params = {
                                    orderState: this.orderState[this.TabCur],
                                    pageIndex: pageIndex || this.pageIndex,
                                    pageSize: 10
                                };
                                _context3.next = 3;
                                return _api2.default.orders(params);

                            case 3:
                                res = _context3.sent;

                                if (!(res.errcode == 200)) {
                                    _context3.next = 18;
                                    break;
                                }

                                ordersList = res.data.ordersList;

                                if (ordersList.length) {
                                    _context3.next = 14;
                                    break;
                                }

                                if (pageIndex == 1) {
                                    this.orders = ordersList;
                                }
                                // this.pageIndex = pageIndex
                                this.toload = true;
                                this.loadmoring = true;
                                this.$apply();
                                return _context3.abrupt("return", false);

                            case 14:
                                if (pageIndex > 1) this.pageIndex = pageIndex;
                                if (pageIndex == 1) {
                                    this.orders = ordersList;
                                } else {
                                    this.orders = this.orders.concat(ordersList);
                                }
                                this.loadmoring = true;

                            case 17:
                                this.$apply();

                            case 18:
                            case "end":
                                return _context3.stop();
                        }
                    }
                }, _callee3, this);
            }));

            function loadData(_x2) {
                return _ref5.apply(this, arguments);
            }

            return loadData;
        }()
    }, {
        key: "onReachBottom",
        value: function onReachBottom() {
            this.getMore();
        }
    }, {
        key: "getMore",
        value: function () {
            var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
                return regeneratorRuntime.wrap(function _callee4$(_context4) {
                    while (1) {
                        switch (_context4.prev = _context4.next) {
                            case 0:
                                this.loadmoring = true;
                                this.toload = false;
                                _context4.next = 4;
                                return this.loadData(this.pageIndex + 1);

                            case 4:
                                this.$apply();

                            case 5:
                            case "end":
                                return _context4.stop();
                        }
                    }
                }, _callee4, this);
            }));

            function getMore() {
                return _ref6.apply(this, arguments);
            }

            return getMore;
        }()
    }]);

    return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'agent/pages/index'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LmpzIl0sIm5hbWVzIjpbIkRpYWxvZyIsImNvbmZpZyIsIm5hdmlnYXRpb25CYXJUaXRsZVRleHQiLCJkYXRhIiwiYWdlbnQiLCJUYWJDdXIiLCJvcmRlcnMiLCJvcmRlclN0YXRlIiwicGFnZUluZGV4IiwidG9sb2FkIiwibG9hZG1vcmluZyIsIm1ldGhvZHMiLCJ0YWJTZWxlY3QiLCJlIiwiY3VyIiwiY3VycmVudFRhcmdldCIsImRhdGFzZXQiLCJpZCIsImRldGFpbCIsImN1cnJlbnQiLCJsb2FkRGF0YSIsInRvZGV0YWlsZSIsIndlcHkiLCJuYXZpZ2F0ZVRvIiwidXJsIiwidG9TaGFyZSIsImVyck1zZyIsImF1dGgiLCJnZXRVc2VyaW5mbyIsInN0b3JlIiwic2F2ZSIsInBhdGgiLCJhZ2VudGVyIiwiJGFwcGx5IiwicGFyYW1zIiwicGFnZVNpemUiLCJyZXMiLCJlcnJjb2RlIiwib3JkZXJzTGlzdCIsImxlbmd0aCIsImNvbmNhdCIsImdldE1vcmUiLCJwYWdlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFDSTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7Ozs7Ozs7Ozs7OztJQUNxQkEsTTs7Ozs7Ozs7Ozs7Ozs7MExBQ2pCQyxNLEdBQVM7QUFDTEMsb0NBQXdCO0FBRG5CLFMsUUFHVEMsSSxHQUFPO0FBQ0hDLG1CQUFPLEVBREo7QUFFSEMsb0JBQVEsQ0FGTDtBQUdIQyxvQkFBUSxFQUhMO0FBSUhDLHdCQUFZLENBQUMsQ0FBRCxFQUFJLENBQUosQ0FKVDtBQUtIQyx1QkFBVyxDQUxSO0FBTUhDLG9CQUFRLElBTkw7QUFPSEMsd0JBQVk7QUFQVCxTLFFBd0RQQyxPLEdBQVU7QUFDTkMscUJBRE0scUJBQ0lDLENBREosRUFDTztBQUNULG9CQUFJQyxNQUFNRCxFQUFFRSxhQUFGLENBQWdCQyxPQUFoQixDQUF3QkMsRUFBeEIsSUFBOEJKLEVBQUVLLE1BQUYsQ0FBU0MsT0FBakQ7QUFDQSxvQkFBSSxLQUFLZCxNQUFMLElBQWVTLEdBQW5CLEVBQXdCO0FBQ3BCLHlCQUFLVCxNQUFMLEdBQWNTLEdBQWQ7QUFDQSx5QkFBS1IsTUFBTCxHQUFjLEVBQWQ7QUFDQSx5QkFBS0UsU0FBTCxHQUFpQixDQUFqQjtBQUNBLHlCQUFLWSxRQUFMO0FBQ0g7QUFDSixhQVRLO0FBVU5DLHFCQVZNLHFCQVVJSixFQVZKLEVBVVE7QUFDVkssK0JBQUtDLFVBQUwsQ0FBZ0I7QUFDWkMseUJBQUssd0JBQXdCUCxFQUF4QixHQUE2QjtBQUR0QixpQkFBaEI7QUFHSCxhQWRLO0FBZURRLG1CQWZDO0FBQUEscUdBZU9aLENBZlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBDQWdCRUEsRUFBRUssTUFBRixDQUFTUSxNQUFULElBQW1CLGdCQWhCckI7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQSwyQ0FpQlFDLGVBQUtDLFdBQUwsQ0FBaUJmLEVBQUVLLE1BQW5CLENBakJSOztBQUFBO0FBa0JFVyxvREFBTUMsSUFBTixDQUFXLFdBQVgsRUFBd0I7QUFDcEJDLDhDQUFNLGtCQURjO0FBRXBCZCw0Q0FBSSxLQUFLYixLQUFMLENBQVdhO0FBRksscUNBQXhCO0FBSUFLLG1EQUFLQyxVQUFMLENBQWdCO0FBQ1pDLDZDQUFLO0FBRE8scUNBQWhCOztBQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBLFM7Ozs7Ozs7Ozs7Ozs7O3VDQTVDSXZCLGNBQU8rQixPQUFQLEU7Ozs7QUFETjVCLHFDLFNBQUFBLEs7O0FBRUoscUNBQUtBLEtBQUwsR0FBYUEsS0FBYjs7dUNBQ00sS0FBS2dCLFFBQUwsRTs7O0FBQ04scUNBQUthLE1BQUw7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7a0dBRVd6QixTOzs7Ozs7QUFDUDBCLHNDLEdBQVM7QUFDVDNCLGdEQUFZLEtBQUtBLFVBQUwsQ0FBZ0IsS0FBS0YsTUFBckIsQ0FESDtBQUVURywrQ0FBV0EsYUFBYSxLQUFLQSxTQUZwQjtBQUdUMkIsOENBQVU7QUFIRCxpQzs7dUNBS0dsQyxjQUFPSyxNQUFQLENBQWM0QixNQUFkLEM7OztBQUFaRSxtQzs7c0NBQ0FBLElBQUlDLE9BQUosSUFBZSxHOzs7OztBQUNYQywwQyxHQUFhRixJQUFJakMsSUFBSixDQUFTbUMsVTs7b0NBQ3JCQSxXQUFXQyxNOzs7OztBQUNaLG9DQUFJL0IsYUFBYSxDQUFqQixFQUFvQjtBQUNoQix5Q0FBS0YsTUFBTCxHQUFjZ0MsVUFBZDtBQUNIO0FBQ0Q7QUFDQSxxQ0FBSzdCLE1BQUwsR0FBYyxJQUFkO0FBQ0EscUNBQUtDLFVBQUwsR0FBa0IsSUFBbEI7QUFDQSxxQ0FBS3VCLE1BQUw7a0VBQ08sSzs7O0FBRVAsb0NBQUl6QixZQUFZLENBQWhCLEVBQW1CLEtBQUtBLFNBQUwsR0FBaUJBLFNBQWpCO0FBQ25CLG9DQUFJQSxhQUFhLENBQWpCLEVBQW9CO0FBQ2hCLHlDQUFLRixNQUFMLEdBQWNnQyxVQUFkO0FBQ0gsaUNBRkQsTUFFTztBQUNILHlDQUFLaEMsTUFBTCxHQUFjLEtBQUtBLE1BQUwsQ0FBWWtDLE1BQVosQ0FBbUJGLFVBQW5CLENBQWQ7QUFDSDtBQUNELHFDQUFLNUIsVUFBTCxHQUFrQixJQUFsQjs7O0FBRUoscUNBQUt1QixNQUFMOzs7Ozs7Ozs7Ozs7Ozs7Ozs7d0NBR1E7QUFDWixpQkFBS1EsT0FBTDtBQUNIOzs7Ozs7Ozs7QUFFRyxxQ0FBSy9CLFVBQUwsR0FBa0IsSUFBbEI7QUFDQSxxQ0FBS0QsTUFBTCxHQUFjLEtBQWQ7O3VDQUNNLEtBQUtXLFFBQUwsQ0FBYyxLQUFLWixTQUFMLEdBQWlCLENBQS9CLEM7OztBQUNOLHFDQUFLeUIsTUFBTDs7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQTFENEJYLGVBQUtvQixJOztrQkFBcEIxQyxNIiwiZmlsZSI6ImluZGV4LmpzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbiAgICBpbXBvcnQgd2VweSBmcm9tIFwid2VweVwiXHJcbiAgICBpbXBvcnQgVGlwcyBmcm9tIFwiQC91dGlscy9UaXBzXCJcclxuICAgIGltcG9ydCBjb25maWcgZnJvbSBcIi4uL2FwaVwiXHJcbiAgICBpbXBvcnQgYXV0aCBmcm9tIFwiQC9hcGkvYXV0aFwiXHJcbiAgICBpbXBvcnQgc3RvcmUgZnJvbSBcIkAvc3RvcmUvdXRpbHNcIlxyXG4gICAgZXhwb3J0IGRlZmF1bHQgY2xhc3MgRGlhbG9nIGV4dGVuZHMgd2VweS5wYWdlIHtcclxuICAgICAgICBjb25maWcgPSB7XHJcbiAgICAgICAgICAgIG5hdmlnYXRpb25CYXJUaXRsZVRleHQ6IFwi5oiR55qE5Luj55CGXCJcclxuICAgICAgICB9O1xyXG4gICAgICAgIGRhdGEgPSB7XHJcbiAgICAgICAgICAgIGFnZW50OiB7fSxcclxuICAgICAgICAgICAgVGFiQ3VyOiAwLFxyXG4gICAgICAgICAgICBvcmRlcnM6IFtdLFxyXG4gICAgICAgICAgICBvcmRlclN0YXRlOiBbMiwgM10sXHJcbiAgICAgICAgICAgIHBhZ2VJbmRleDogMSxcclxuICAgICAgICAgICAgdG9sb2FkOiB0cnVlLFxyXG4gICAgICAgICAgICBsb2FkbW9yaW5nOiBmYWxzZSxcclxuICAgICAgICB9O1xyXG4gICAgICAgIGFzeW5jIG9uTG9hZCgpIHtcclxuICAgICAgICAgICAgbGV0IHtcclxuICAgICAgICAgICAgICAgIGFnZW50XHJcbiAgICAgICAgICAgIH0gPSBhd2FpdCBjb25maWcuYWdlbnRlcigpXHJcbiAgICAgICAgICAgIHRoaXMuYWdlbnQgPSBhZ2VudFxyXG4gICAgICAgICAgICBhd2FpdCB0aGlzLmxvYWREYXRhKClcclxuICAgICAgICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgICAgIH1cclxuICAgICAgICBhc3luYyBsb2FkRGF0YShwYWdlSW5kZXgpIHtcclxuICAgICAgICAgICAgbGV0IHBhcmFtcyA9IHtcclxuICAgICAgICAgICAgICAgIG9yZGVyU3RhdGU6IHRoaXMub3JkZXJTdGF0ZVt0aGlzLlRhYkN1cl0sXHJcbiAgICAgICAgICAgICAgICBwYWdlSW5kZXg6IHBhZ2VJbmRleCB8fCB0aGlzLnBhZ2VJbmRleCxcclxuICAgICAgICAgICAgICAgIHBhZ2VTaXplOiAxMFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGxldCByZXMgPSBhd2FpdCBjb25maWcub3JkZXJzKHBhcmFtcylcclxuICAgICAgICAgICAgaWYgKHJlcy5lcnJjb2RlID09IDIwMCkge1xyXG4gICAgICAgICAgICAgICAgbGV0IG9yZGVyc0xpc3QgPSByZXMuZGF0YS5vcmRlcnNMaXN0XHJcbiAgICAgICAgICAgICAgICBpZiAoIW9yZGVyc0xpc3QubGVuZ3RoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHBhZ2VJbmRleCA9PSAxKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMub3JkZXJzID0gb3JkZXJzTGlzdFxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAvLyB0aGlzLnBhZ2VJbmRleCA9IHBhZ2VJbmRleFxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMudG9sb2FkID0gdHJ1ZVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubG9hZG1vcmluZyA9IHRydWVcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChwYWdlSW5kZXggPiAxKSB0aGlzLnBhZ2VJbmRleCA9IHBhZ2VJbmRleFxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChwYWdlSW5kZXggPT0gMSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm9yZGVycyA9IG9yZGVyc0xpc3RcclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm9yZGVycyA9IHRoaXMub3JkZXJzLmNvbmNhdChvcmRlcnNMaXN0KVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmxvYWRtb3JpbmcgPSB0cnVlXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgb25SZWFjaEJvdHRvbSgpIHtcclxuICAgICAgICAgICAgdGhpcy5nZXRNb3JlKClcclxuICAgICAgICB9XHJcbiAgICAgICAgYXN5bmMgZ2V0TW9yZSgpIHtcclxuICAgICAgICAgICAgdGhpcy5sb2FkbW9yaW5nID0gdHJ1ZVxyXG4gICAgICAgICAgICB0aGlzLnRvbG9hZCA9IGZhbHNlXHJcbiAgICAgICAgICAgIGF3YWl0IHRoaXMubG9hZERhdGEodGhpcy5wYWdlSW5kZXggKyAxKVxyXG4gICAgICAgICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICAgICAgfVxyXG4gICAgICAgIG1ldGhvZHMgPSB7XHJcbiAgICAgICAgICAgIHRhYlNlbGVjdChlKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgY3VyID0gZS5jdXJyZW50VGFyZ2V0LmRhdGFzZXQuaWQgfHwgZS5kZXRhaWwuY3VycmVudDtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLlRhYkN1ciAhPSBjdXIpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLlRhYkN1ciA9IGN1clxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMub3JkZXJzID0gW11cclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnBhZ2VJbmRleCA9IDFcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmxvYWREYXRhKClcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgdG9kZXRhaWxlKGlkKSB7XHJcbiAgICAgICAgICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICAgICAgICAgIHVybDogJy9wYWdlcy9teS9vcmRlcj9pZD0nICsgaWQgKyBcIiZub3RpYz0xXCJcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgIGFzeW5jIHRvU2hhcmUoZSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKGUuZGV0YWlsLmVyck1zZyA9PSBcImdldFVzZXJJbmZvOm9rXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICBhd2FpdCBhdXRoLmdldFVzZXJpbmZvKGUuZGV0YWlsKVxyXG4gICAgICAgICAgICAgICAgICAgIHN0b3JlLnNhdmUoJ2FnZW50SW5mbycsIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGF0aDogJ3BhZ2VzL2hvbWUvaW5kZXgnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZDogdGhpcy5hZ2VudC5pZFxyXG4gICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgd2VweS5uYXZpZ2F0ZVRvKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdXJsOiAnLi9zaGFyZSdcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH07XHJcbiAgICB9XHJcbiJdfQ==