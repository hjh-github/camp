"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

var _WxUtils = require('./../../utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

var _api = require('./../api.js');

var _api2 = _interopRequireDefault(_api);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
    _inherits(Dialog, _wepy$page);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
            navigationBarTitleText: "成为超级会员"
        }, _this.data = {}, _this.methods = {
            tobuy: function () {
                var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
                    var _code;

                    return regeneratorRuntime.wrap(function _callee$(_context) {
                        while (1) {
                            switch (_context.prev = _context.next) {
                                case 0:
                                    _context.next = 2;
                                    return _api2.default.plusUp();

                                case 2:
                                    _code = _context.sent;

                                    _WxUtils2.default.wxPay(_code.data).then(function (r) {
                                        _Tips2.default.toast('支付成功', function () {
                                            _WxUtils2.default.backOrRedirect('/pages/my/my');
                                        }, 'none');
                                    });

                                case 4:
                                case "end":
                                    return _context.stop();
                            }
                        }
                    }, _callee, this);
                }));

                function tobuy() {
                    return _ref2.apply(this, arguments);
                }

                return tobuy;
            }()
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'agent/pages/buyVip'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImJ1eVZpcC5qcyJdLCJuYW1lcyI6WyJEaWFsb2ciLCJjb25maWciLCJuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0IiwiZGF0YSIsIm1ldGhvZHMiLCJ0b2J1eSIsInBsdXNVcCIsIl9jb2RlIiwiV3hVdGlscyIsInd4UGF5IiwidGhlbiIsIlRpcHMiLCJ0b2FzdCIsImJhY2tPclJlZGlyZWN0Iiwid2VweSIsInBhZ2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFDSTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7Ozs7Ozs7Ozs7Ozs7SUFDcUJBLE07Ozs7Ozs7Ozs7Ozs7OzBMQUNqQkMsTSxHQUFTO0FBQ0xDLG9DQUF3QjtBQURuQixTLFFBR1RDLEksR0FBTyxFLFFBQ1BDLE8sR0FBVTtBQUNBQyxpQkFEQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJDQUVnQkosY0FBT0ssTUFBUCxFQUZoQjs7QUFBQTtBQUVFQyx5Q0FGRjs7QUFHRkMsc0RBQVFDLEtBQVIsQ0FBY0YsTUFBTUosSUFBcEIsRUFBMEJPLElBQTFCLENBQStCLGFBQUs7QUFDaENDLHVEQUFLQyxLQUFMLENBQVcsTUFBWCxFQUFtQixZQUFNO0FBQ3JCSiw4REFBUUssY0FBUixDQUF1QixjQUF2QjtBQUNILHlDQUZELEVBRUcsTUFGSDtBQUdILHFDQUpEOztBQUhFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUEsUzs7OztFQUxzQkMsZUFBS0MsSTs7a0JBQXBCZixNIiwiZmlsZSI6ImJ1eVZpcC5qcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4gICAgaW1wb3J0IHdlcHkgZnJvbSBcIndlcHlcIlxyXG4gICAgaW1wb3J0IFRpcHMgZnJvbSBcIkAvdXRpbHMvVGlwc1wiXHJcbiAgICBpbXBvcnQgV3hVdGlscyBmcm9tIFwiQC91dGlscy9XeFV0aWxzXCJcclxuICAgIGltcG9ydCBjb25maWcgZnJvbSBcIi4uL2FwaVwiXHJcbiAgICBleHBvcnQgZGVmYXVsdCBjbGFzcyBEaWFsb2cgZXh0ZW5kcyB3ZXB5LnBhZ2Uge1xyXG4gICAgICAgIGNvbmZpZyA9IHtcclxuICAgICAgICAgICAgbmF2aWdhdGlvbkJhclRpdGxlVGV4dDogXCLmiJDkuLrotoXnuqfkvJrlkZhcIlxyXG4gICAgICAgIH07XHJcbiAgICAgICAgZGF0YSA9IHt9O1xyXG4gICAgICAgIG1ldGhvZHMgPSB7XHJcbiAgICAgICAgICAgIGFzeW5jIHRvYnV5KCkge1xyXG4gICAgICAgICAgICAgICAgbGV0IF9jb2RlID0gYXdhaXQgY29uZmlnLnBsdXNVcCgpXHJcbiAgICAgICAgICAgICAgICBXeFV0aWxzLnd4UGF5KF9jb2RlLmRhdGEpLnRoZW4ociA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgVGlwcy50b2FzdCgn5pSv5LuY5oiQ5YqfJywgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBXeFV0aWxzLmJhY2tPclJlZGlyZWN0KCcvcGFnZXMvbXkvbXknKVxyXG4gICAgICAgICAgICAgICAgICAgIH0sICdub25lJylcclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9O1xyXG4gICAgfVxyXG4iXX0=