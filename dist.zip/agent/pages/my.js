"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

var _api = require('./../api.js');

var _api2 = _interopRequireDefault(_api);

var _navigator = require('./../../mixins/navigator.js');

var _navigator2 = _interopRequireDefault(_navigator);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
    _inherits(Dialog, _wepy$page);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
            navigationBarTitleText: "宝妈代理"
        }, _this.data = {
            agentIndex: {},
            modalName: ''
        }, _this.mixins = [_navigator2.default], _this.methods = {
            inAgent: function inAgent() {
                this.inAgent();
            },
            toInagent: function toInagent() {
                this.ckeckIn();
            },
            hideModal: function hideModal() {
                this.modalName = '';
            },
            navi: function navi(e) {
                this.ckeckIn(function () {
                    var url = e.currentTarget.dataset.url || e.target.dataset.url;
                    _wepy2.default.navigateTo({
                        url: url
                    });
                });
            },
            ret: function ret() {
                return;
            }
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(Dialog, [{
        key: "onLoad",
        value: function () {
            var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
                return regeneratorRuntime.wrap(function _callee$(_context) {
                    while (1) {
                        switch (_context.prev = _context.next) {
                            case 0:
                                _context.next = 2;
                                return _auth2.default.login();

                            case 2:
                                this.load();

                            case 3:
                            case "end":
                                return _context.stop();
                        }
                    }
                }, _callee, this);
            }));

            function onLoad() {
                return _ref2.apply(this, arguments);
            }

            return onLoad;
        }()
    }, {
        key: "load",
        value: function () {
            var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
                return regeneratorRuntime.wrap(function _callee2$(_context2) {
                    while (1) {
                        switch (_context2.prev = _context2.next) {
                            case 0:
                                _context2.next = 2;
                                return _api2.default.agentIndex();

                            case 2:
                                this.agentIndex = _context2.sent;

                                this.$apply();

                            case 4:
                            case "end":
                                return _context2.stop();
                        }
                    }
                }, _callee2, this);
            }));

            function load() {
                return _ref3.apply(this, arguments);
            }

            return load;
        }()
    }, {
        key: "ckeckIn",
        value: function ckeckIn(callback) {
            if (!this.agentIndex || !this.agentIndex.state) {
                this.modalName = 'image';
                this.$apply();
            } else {
                callback && callback();
            }
        }
    }, {
        key: "inAgent",
        value: function () {
            var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
                return regeneratorRuntime.wrap(function _callee3$(_context3) {
                    while (1) {
                        switch (_context3.prev = _context3.next) {
                            case 0:
                                _context3.next = 2;
                                return _api2.default.applyV2();

                            case 2:
                                this.load();
                                this.modalName = '';
                                this.$apply();

                            case 5:
                            case "end":
                                return _context3.stop();
                        }
                    }
                }, _callee3, this);
            }));

            function inAgent() {
                return _ref4.apply(this, arguments);
            }

            return inAgent;
        }()
    }]);

    return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'agent/pages/my'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm15LmpzIl0sIm5hbWVzIjpbIkRpYWxvZyIsImNvbmZpZyIsIm5hdmlnYXRpb25CYXJUaXRsZVRleHQiLCJkYXRhIiwiYWdlbnRJbmRleCIsIm1vZGFsTmFtZSIsIm1peGlucyIsIm5hdmlnYXRvciIsIm1ldGhvZHMiLCJpbkFnZW50IiwidG9JbmFnZW50IiwiY2tlY2tJbiIsImhpZGVNb2RhbCIsIm5hdmkiLCJlIiwidXJsIiwiY3VycmVudFRhcmdldCIsImRhdGFzZXQiLCJ0YXJnZXQiLCJ3ZXB5IiwibmF2aWdhdGVUbyIsInJldCIsImF1dGgiLCJsb2dpbiIsImxvYWQiLCIkYXBwbHkiLCJjYWxsYmFjayIsInN0YXRlIiwiYXBwbHlWMiIsInBhZ2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUNJOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7Ozs7Ozs7Ozs7OztJQUNxQkEsTTs7Ozs7Ozs7Ozs7Ozs7MExBQ2pCQyxNLEdBQVM7QUFDTEMsb0NBQXdCO0FBRG5CLFMsUUFHVEMsSSxHQUFPO0FBQ0hDLHdCQUFZLEVBRFQ7QUFFSEMsdUJBQVc7QUFGUixTLFFBSVBDLE0sR0FBUyxDQUFDQyxtQkFBRCxDLFFBdUJUQyxPLEdBQVU7QUFDTkMsbUJBRE0scUJBQ0c7QUFDTCxxQkFBS0EsT0FBTDtBQUNILGFBSEs7QUFJTkMscUJBSk0sdUJBSUs7QUFDUCxxQkFBS0MsT0FBTDtBQUNILGFBTks7QUFPTkMscUJBUE0sdUJBT007QUFDUixxQkFBS1AsU0FBTCxHQUFpQixFQUFqQjtBQUNILGFBVEs7QUFVTlEsZ0JBVk0sZ0JBVURDLENBVkMsRUFVRTtBQUNKLHFCQUFLSCxPQUFMLENBQWEsWUFBTTtBQUNmLHdCQUFJSSxNQUFNRCxFQUFFRSxhQUFGLENBQWdCQyxPQUFoQixDQUF3QkYsR0FBeEIsSUFBK0JELEVBQUVJLE1BQUYsQ0FBU0QsT0FBVCxDQUFpQkYsR0FBMUQ7QUFDQUksbUNBQUtDLFVBQUwsQ0FBZ0I7QUFDWkw7QUFEWSxxQkFBaEI7QUFHSCxpQkFMRDtBQU1ILGFBakJLO0FBa0JOTSxlQWxCTSxpQkFrQkE7QUFDRjtBQUNIO0FBcEJLLFM7Ozs7Ozs7Ozs7Ozt1Q0FyQkFDLGVBQUtDLEtBQUwsRTs7O0FBQ04scUNBQUtDLElBQUw7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7dUNBR3dCdkIsY0FBT0csVUFBUCxFOzs7QUFBeEIscUNBQUtBLFU7O0FBQ0wscUNBQUtxQixNQUFMOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Z0NBRUlDLFEsRUFBVTtBQUNkLGdCQUFJLENBQUMsS0FBS3RCLFVBQU4sSUFBb0IsQ0FBQyxLQUFLQSxVQUFMLENBQWdCdUIsS0FBekMsRUFBaUQ7QUFDN0MscUJBQUt0QixTQUFMLEdBQWlCLE9BQWpCO0FBQ0EscUJBQUtvQixNQUFMO0FBQ0gsYUFIRCxNQUdPO0FBQ0hDLDRCQUFZQSxVQUFaO0FBQ0g7QUFDSjs7Ozs7Ozs7Ozt1Q0FFU3pCLGNBQU8yQixPQUFQLEU7OztBQUNOLHFDQUFLSixJQUFMO0FBQ0EscUNBQUtuQixTQUFMLEdBQWlCLEVBQWpCO0FBQ0EscUNBQUtvQixNQUFMOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBN0I0Qk4sZUFBS1UsSTs7a0JBQXBCN0IsTSIsImZpbGUiOiJteS5qcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4gICAgaW1wb3J0IHdlcHkgZnJvbSBcIndlcHlcIjtcclxuICAgIGltcG9ydCBhdXRoIGZyb20gXCJAL2FwaS9hdXRoXCJcclxuICAgIGltcG9ydCBjb25maWcgZnJvbSBcIi4uL2FwaVwiXHJcbiAgICBpbXBvcnQgbmF2aWdhdG9yIGZyb20gJ0AvbWl4aW5zL25hdmlnYXRvcidcclxuICAgIGV4cG9ydCBkZWZhdWx0IGNsYXNzIERpYWxvZyBleHRlbmRzIHdlcHkucGFnZSB7XHJcbiAgICAgICAgY29uZmlnID0ge1xyXG4gICAgICAgICAgICBuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0OiBcIuWuneWmiOS7o+eQhlwiXHJcbiAgICAgICAgfTtcclxuICAgICAgICBkYXRhID0ge1xyXG4gICAgICAgICAgICBhZ2VudEluZGV4OiB7fSxcclxuICAgICAgICAgICAgbW9kYWxOYW1lOiAnJ1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgbWl4aW5zID0gW25hdmlnYXRvcl1cclxuICAgICAgICBhc3luYyBvbkxvYWQoKSB7XHJcbiAgICAgICAgICAgIGF3YWl0IGF1dGgubG9naW4oKVxyXG4gICAgICAgICAgICB0aGlzLmxvYWQoKVxyXG4gICAgICAgIH1cclxuICAgICAgICBhc3luYyBsb2FkKCkge1xyXG4gICAgICAgICAgICB0aGlzLmFnZW50SW5kZXggPSBhd2FpdCBjb25maWcuYWdlbnRJbmRleCgpXHJcbiAgICAgICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgICB9XHJcbiAgICAgICAgY2tlY2tJbihjYWxsYmFjaykge1xyXG4gICAgICAgICAgICBpZiAoIXRoaXMuYWdlbnRJbmRleCB8fCAhdGhpcy5hZ2VudEluZGV4LnN0YXRlICkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RhbE5hbWUgPSAnaW1hZ2UnXHJcbiAgICAgICAgICAgICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBjYWxsYmFjayAmJiBjYWxsYmFjaygpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgYXN5bmMgaW5BZ2VudCgpIHtcclxuICAgICAgICAgICAgYXdhaXQgY29uZmlnLmFwcGx5VjIoKVxyXG4gICAgICAgICAgICB0aGlzLmxvYWQoKVxyXG4gICAgICAgICAgICB0aGlzLm1vZGFsTmFtZSA9ICcnXHJcbiAgICAgICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgICB9XHJcbiAgICAgICAgbWV0aG9kcyA9IHtcclxuICAgICAgICAgICAgaW5BZ2VudCgpe1xyXG4gICAgICAgICAgICAgICAgdGhpcy5pbkFnZW50KClcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgdG9JbmFnZW50KCl7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNrZWNrSW4oKVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBoaWRlTW9kYWwoKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGFsTmFtZSA9ICcnXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIG5hdmkoZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5ja2Vja0luKCgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgdXJsID0gZS5jdXJyZW50VGFyZ2V0LmRhdGFzZXQudXJsIHx8IGUudGFyZ2V0LmRhdGFzZXQudXJsXHJcbiAgICAgICAgICAgICAgICAgICAgd2VweS5uYXZpZ2F0ZVRvKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdXJsXHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICByZXQoKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH07XHJcbiAgICB9XHJcbiJdfQ==