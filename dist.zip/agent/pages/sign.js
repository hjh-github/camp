"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});


var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _api = require('./../api.js');

var _api2 = _interopRequireDefault(_api);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

var _Validate = require('./../../utils/Validate.js');

var _Validate2 = _interopRequireDefault(_Validate);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
  _inherits(Dialog, _wepy$page);

  function Dialog() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, Dialog);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
      navigationBarTitleText: "申请代理"
    }, _this.data = {
      form: {}
    }, _this.methods = {
      input: function input(e) {
        var name = e.target.dataset.name || e.currentTarget.dataset.name,
            value = e.detail.value;
        this.form[name] = e.detail.value;
      },
      sign: function () {
        var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
          var res;
          return regeneratorRuntime.wrap(function _callee$(_context) {
            while (1) {
              switch (_context.prev = _context.next) {
                case 0:
                  if (this.form.name) {
                    _context.next = 3;
                    break;
                  }

                  _Tips2.default.toast('请先填写联系人姓名', function () {}, 'none');
                  return _context.abrupt("return");

                case 3:
                  if (_Validate2.default.tel(this.form.phone)) {
                    _context.next = 6;
                    break;
                  }

                  _Tips2.default.toast('请先填写正确的手机号', function () {}, 'none');
                  return _context.abrupt("return");

                case 6:
                  _context.next = 8;
                  return _api2.default.sign(this.form);

                case 8:
                  res = _context.sent;

                  if (res.errcode == 200) {
                    _Tips2.default.toast('申请成功，我们会尽快与您联系！', function () {
                      _wepy2.default.navigateBack({
                        delta: 1 //返回的页面数，如果 delta 大于现有页面数，则返回到首页,
                      });
                    }, 'none');
                  }

                case 10:
                case "end":
                  return _context.stop();
              }
            }
          }, _callee, this);
        }));

        function sign() {
          return _ref2.apply(this, arguments);
        }

        return sign;
      }()
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }

  return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'agent/pages/sign'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNpZ24uanMiXSwibmFtZXMiOlsiRGlhbG9nIiwiY29uZmlnIiwibmF2aWdhdGlvbkJhclRpdGxlVGV4dCIsImRhdGEiLCJmb3JtIiwibWV0aG9kcyIsImlucHV0IiwiZSIsIm5hbWUiLCJ0YXJnZXQiLCJkYXRhc2V0IiwiY3VycmVudFRhcmdldCIsInZhbHVlIiwiZGV0YWlsIiwic2lnbiIsIlRpcHMiLCJ0b2FzdCIsIlZhbGlkYXRlIiwidGVsIiwicGhvbmUiLCJyZXMiLCJlcnJjb2RlIiwid2VweSIsIm5hdmlnYXRlQmFjayIsImRlbHRhIiwicGFnZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUNFOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7Ozs7Ozs7Ozs7OztJQUNxQkEsTTs7Ozs7Ozs7Ozs7Ozs7c0xBQ25CQyxNLEdBQVM7QUFDUEMsOEJBQXdCO0FBRGpCLEssUUFHVEMsSSxHQUFPO0FBQ0xDLFlBQU07QUFERCxLLFFBR1BDLE8sR0FBVTtBQUNSQyxXQURRLGlCQUNGQyxDQURFLEVBQ0M7QUFDUCxZQUFJQyxPQUFPRCxFQUFFRSxNQUFGLENBQVNDLE9BQVQsQ0FBaUJGLElBQWpCLElBQXlCRCxFQUFFSSxhQUFGLENBQWdCRCxPQUFoQixDQUF3QkYsSUFBNUQ7QUFBQSxZQUNFSSxRQUFRTCxFQUFFTSxNQUFGLENBQVNELEtBRG5CO0FBRUEsYUFBS1IsSUFBTCxDQUFVSSxJQUFWLElBQWtCRCxFQUFFTSxNQUFGLENBQVNELEtBQTNCO0FBQ0QsT0FMTztBQU1GRSxVQU5FO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBT0QsS0FBS1YsSUFBTCxDQUFVSSxJQVBUO0FBQUE7QUFBQTtBQUFBOztBQVFKTyxpQ0FBS0MsS0FBTCxDQUFXLFdBQVgsRUFBd0IsWUFBTSxDQUFFLENBQWhDLEVBQWtDLE1BQWxDO0FBUkk7O0FBQUE7QUFBQSxzQkFXREMsbUJBQVNDLEdBQVQsQ0FBYSxLQUFLZCxJQUFMLENBQVVlLEtBQXZCLENBWEM7QUFBQTtBQUFBO0FBQUE7O0FBWUpKLGlDQUFLQyxLQUFMLENBQVcsWUFBWCxFQUF5QixZQUFNLENBQUUsQ0FBakMsRUFBbUMsTUFBbkM7QUFaSTs7QUFBQTtBQUFBO0FBQUEseUJBZVVmLGNBQU9hLElBQVAsQ0FBWSxLQUFLVixJQUFqQixDQWZWOztBQUFBO0FBZUZnQixxQkFmRTs7QUFnQk4sc0JBQUlBLElBQUlDLE9BQUosSUFBZSxHQUFuQixFQUF3QjtBQUN0Qk4sbUNBQUtDLEtBQUwsQ0FBVyxpQkFBWCxFQUE4QixZQUFNO0FBQ2xDTSxxQ0FBS0MsWUFBTCxDQUFrQjtBQUNoQkMsK0JBQU8sQ0FEUyxDQUNQO0FBRE8sdUJBQWxCO0FBR0QscUJBSkQsRUFJRyxNQUpIO0FBS0Q7O0FBdEJLO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUEsSzs7OztFQVB3QkYsZUFBS0csSTs7a0JBQXBCekIsTSIsImZpbGUiOiJzaWduLmpzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbiAgaW1wb3J0IHdlcHkgZnJvbSBcIndlcHlcIjtcclxuICBpbXBvcnQgY29uZmlnIGZyb20gXCIuLi9hcGlcIlxyXG4gIGltcG9ydCBUaXBzIGZyb20gXCJAL3V0aWxzL1RpcHNcIlxyXG4gIGltcG9ydCBWYWxpZGF0ZSBmcm9tIFwiQC91dGlscy9WYWxpZGF0ZVwiXHJcbiAgZXhwb3J0IGRlZmF1bHQgY2xhc3MgRGlhbG9nIGV4dGVuZHMgd2VweS5wYWdlIHtcclxuICAgIGNvbmZpZyA9IHtcclxuICAgICAgbmF2aWdhdGlvbkJhclRpdGxlVGV4dDogXCLnlLPor7fku6PnkIZcIlxyXG4gICAgfTtcclxuICAgIGRhdGEgPSB7XHJcbiAgICAgIGZvcm06IHt9XHJcbiAgICB9O1xyXG4gICAgbWV0aG9kcyA9IHtcclxuICAgICAgaW5wdXQoZSkge1xyXG4gICAgICAgIGxldCBuYW1lID0gZS50YXJnZXQuZGF0YXNldC5uYW1lIHx8IGUuY3VycmVudFRhcmdldC5kYXRhc2V0Lm5hbWUsXHJcbiAgICAgICAgICB2YWx1ZSA9IGUuZGV0YWlsLnZhbHVlXHJcbiAgICAgICAgdGhpcy5mb3JtW25hbWVdID0gZS5kZXRhaWwudmFsdWU7XHJcbiAgICAgIH0sXHJcbiAgICAgIGFzeW5jIHNpZ24oKSB7XHJcbiAgICAgICAgaWYgKCF0aGlzLmZvcm0ubmFtZSkge1xyXG4gICAgICAgICAgVGlwcy50b2FzdCgn6K+35YWI5aGr5YaZ6IGU57O75Lq65aeT5ZCNJywgKCkgPT4ge30sICdub25lJylcclxuICAgICAgICAgIHJldHVyblxyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoIVZhbGlkYXRlLnRlbCh0aGlzLmZvcm0ucGhvbmUpKSB7XHJcbiAgICAgICAgICBUaXBzLnRvYXN0KCfor7flhYjloavlhpnmraPnoa7nmoTmiYvmnLrlj7cnLCAoKSA9PiB7fSwgJ25vbmUnKVxyXG4gICAgICAgICAgcmV0dXJuXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGxldCByZXMgPSBhd2FpdCBjb25maWcuc2lnbih0aGlzLmZvcm0pXHJcbiAgICAgICAgaWYgKHJlcy5lcnJjb2RlID09IDIwMCkge1xyXG4gICAgICAgICAgVGlwcy50b2FzdCgn55Sz6K+35oiQ5Yqf77yM5oiR5Lus5Lya5bC95b+r5LiO5oKo6IGU57O777yBJywgKCkgPT4ge1xyXG4gICAgICAgICAgICB3ZXB5Lm5hdmlnYXRlQmFjayh7XHJcbiAgICAgICAgICAgICAgZGVsdGE6IDEgLy/ov5Tlm57nmoTpobXpnaLmlbDvvIzlpoLmnpwgZGVsdGEg5aSn5LqO546w5pyJ6aG16Z2i5pWw77yM5YiZ6L+U5Zue5Yiw6aaW6aG1LFxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgIH0sICdub25lJylcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgfVxyXG4iXX0=