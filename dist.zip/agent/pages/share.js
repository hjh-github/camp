"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _dec, _class;

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

var _Lang = require('./../../utils/Lang.js');

var _Lang2 = _interopRequireDefault(_Lang);

var _utils = require('./../../store/utils.js');

var _utils2 = _interopRequireDefault(_utils);

var _wepyRedux = require('./../../npm/wepy-redux/lib/index.js');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var shareInfo = (_dec = (0, _wepyRedux.connect)({
    shareInfo: _utils2.default.get("shareInfo")
}), _dec(_class = function (_wepy$page) {
    _inherits(shareInfo, _wepy$page);

    function shareInfo() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, shareInfo);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = shareInfo.__proto__ || Object.getPrototypeOf(shareInfo)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
            navigationBarTitleText: "生成海报"
        }, _this.methods = {
            //点击保存到相册
            saveImg: function saveImg() {
                console.log('dowm');
                _Lang2.default.downImg(this.loadImagePath);
            }
        }, _this.data = {
            loadImagePath: ''
            /**
             * 生命周期函数--监听页面加载
             */
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(shareInfo, [{
        key: "onLoad",
        value: function () {
            var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(options) {
                var res;
                return regeneratorRuntime.wrap(function _callee$(_context) {
                    while (1) {
                        switch (_context.prev = _context.next) {
                            case 0:
                                _context.next = 2;
                                return _auth2.default.login();

                            case 2:
                                _context.next = 4;
                                return _config2.default.getPoster({
                                    page: 'pages/home/index',
                                    sceneStr: encodeURI("agentId=" + options.agentId),
                                    id: this.shareInfo.id,
                                    type: this.shareInfo.type
                                });

                            case 4:
                                res = _context.sent;

                                this.loadImagePath = res.qr;
                                this.$apply();

                            case 7:
                            case "end":
                                return _context.stop();
                        }
                    }
                }, _callee, this);
            }));

            function onLoad(_x) {
                return _ref2.apply(this, arguments);
            }

            return onLoad;
        }()
    }]);

    return shareInfo;
}(_wepy2.default.page)) || _class);

Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(shareInfo , 'agent/pages/share'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNoYXJlLmpzIl0sIm5hbWVzIjpbInNoYXJlSW5mbyIsInN0b3JlIiwiZ2V0IiwiY29uZmlnIiwibmF2aWdhdGlvbkJhclRpdGxlVGV4dCIsIm1ldGhvZHMiLCJzYXZlSW1nIiwiY29uc29sZSIsImxvZyIsIkxhbmciLCJkb3duSW1nIiwibG9hZEltYWdlUGF0aCIsImRhdGEiLCJvcHRpb25zIiwiYXV0aCIsImxvZ2luIiwiZ2V0UG9zdGVyIiwicGFnZSIsInNjZW5lU3RyIiwiZW5jb2RlVVJJIiwiYWdlbnRJZCIsImlkIiwidHlwZSIsInJlcyIsInFyIiwiJGFwcGx5Iiwid2VweSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7QUFDSTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7Ozs7Ozs7OztJQU1xQkEsUyxXQUhwQix3QkFBUTtBQUNMQSxlQUFXQyxnQkFBTUMsR0FBTixDQUFVLFdBQVY7QUFETixDQUFSLEM7Ozs7Ozs7Ozs7Ozs7O2dNQUlHQyxNLEdBQVM7QUFDTEMsb0NBQXdCO0FBRG5CLFMsUUFHVEMsTyxHQUFVO0FBQ047QUFDQUMsbUJBRk0scUJBRUk7QUFDTkMsd0JBQVFDLEdBQVIsQ0FBWSxNQUFaO0FBQ0FDLCtCQUFLQyxPQUFMLENBQWEsS0FBS0MsYUFBbEI7QUFDSDtBQUxLLFMsUUFPVkMsSSxHQUFPO0FBQ0hELDJCQUFjO0FBRWxCOzs7QUFITyxTOzs7Ozs7aUdBTU1FLE87Ozs7Ozs7dUNBQ0hDLGVBQUtDLEtBQUwsRTs7Ozt1Q0FDVVosaUJBQU9hLFNBQVAsQ0FBaUI7QUFDN0JDLDBDQUFNLGtCQUR1QjtBQUU3QkMsOENBQVVDLHVCQUFxQk4sUUFBUU8sT0FBN0IsQ0FGbUI7QUFHN0JDLHdDQUFHLEtBQUtyQixTQUFMLENBQWVxQixFQUhXO0FBSTdCQywwQ0FBSyxLQUFLdEIsU0FBTCxDQUFlc0I7QUFKUyxpQ0FBakIsQzs7O0FBQVpDLG1DOztBQU1KLHFDQUFLWixhQUFMLEdBQXFCWSxJQUFJQyxFQUF6QjtBQUNBLHFDQUFLQyxNQUFMOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBMUIrQkMsZUFBS1QsSTtrQkFBdkJqQixTIiwiZmlsZSI6InNoYXJlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbiAgICBpbXBvcnQgd2VweSBmcm9tIFwid2VweVwiO1xyXG4gICAgaW1wb3J0IGNvbmZpZyBmcm9tIFwiQC9hcGkvY29uZmlnXCJcclxuICAgIGltcG9ydCBhdXRoIGZyb20gXCJAL2FwaS9hdXRoXCJcclxuICAgIGltcG9ydCBMYW5nIGZyb20gXCJAL3V0aWxzL0xhbmdcIlxyXG4gICAgaW1wb3J0IHN0b3JlIGZyb20gXCJAL3N0b3JlL3V0aWxzXCJcclxuICAgIGltcG9ydCB7XHJcbiAgICAgICAgY29ubmVjdFxyXG4gICAgfSBmcm9tIFwid2VweS1yZWR1eFwiXHJcbiAgICBAY29ubmVjdCh7XHJcbiAgICAgICAgc2hhcmVJbmZvOiBzdG9yZS5nZXQoXCJzaGFyZUluZm9cIilcclxuICAgIH0pXHJcbiAgICBleHBvcnQgZGVmYXVsdCBjbGFzcyBzaGFyZUluZm8gZXh0ZW5kcyB3ZXB5LnBhZ2Uge1xyXG4gICAgICAgIGNvbmZpZyA9IHtcclxuICAgICAgICAgICAgbmF2aWdhdGlvbkJhclRpdGxlVGV4dDogXCLnlJ/miJDmtbfmiqVcIlxyXG4gICAgICAgIH07XHJcbiAgICAgICAgbWV0aG9kcyA9IHtcclxuICAgICAgICAgICAgLy/ngrnlh7vkv53lrZjliLDnm7jlhoxcclxuICAgICAgICAgICAgc2F2ZUltZygpIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdkb3dtJylcclxuICAgICAgICAgICAgICAgIExhbmcuZG93bkltZyh0aGlzLmxvYWRJbWFnZVBhdGgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuICAgICAgICBkYXRhID0ge1xyXG4gICAgICAgICAgICBsb2FkSW1hZ2VQYXRoOicnXHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8qKlxyXG4gICAgICAgICAqIOeUn+WRveWRqOacn+WHveaVsC0t55uR5ZCs6aG16Z2i5Yqg6L29XHJcbiAgICAgICAgICovXHJcbiAgICAgICAgYXN5bmMgb25Mb2FkKG9wdGlvbnMpIHtcclxuICAgICAgICAgICAgYXdhaXQgYXV0aC5sb2dpbigpXHJcbiAgICAgICAgICAgIGxldCByZXMgPSBhd2FpdCBjb25maWcuZ2V0UG9zdGVyKHtcclxuICAgICAgICAgICAgICAgIHBhZ2U6ICdwYWdlcy9ob21lL2luZGV4JyxcclxuICAgICAgICAgICAgICAgIHNjZW5lU3RyOiBlbmNvZGVVUkkoYGFnZW50SWQ9JHtvcHRpb25zLmFnZW50SWR9YCksXHJcbiAgICAgICAgICAgICAgICBpZDp0aGlzLnNoYXJlSW5mby5pZCxcclxuICAgICAgICAgICAgICAgIHR5cGU6dGhpcy5zaGFyZUluZm8udHlwZVxyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICB0aGlzLmxvYWRJbWFnZVBhdGggPSByZXMucXJcclxuICAgICAgICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuICAgIH1cclxuIl19