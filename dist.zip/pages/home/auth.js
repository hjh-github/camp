"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
    _inherits(Dialog, _wepy$page);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
            navigationBarTitleText: "登录"
        }, _this.data = {
            mobile: ''
        }, _this.methods = {
            onGotUserInfo: function () {
                var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(e) {
                    return regeneratorRuntime.wrap(function _callee$(_context) {
                        while (1) {
                            switch (_context.prev = _context.next) {
                                case 0:
                                    if (!(e.detail.errMsg == "getUserInfo:ok")) {
                                        _context.next = 6;
                                        break;
                                    }

                                    _context.next = 3;
                                    return _auth2.default.getUserinfo(e.detail);

                                case 3:
                                    _context.next = 5;
                                    return _auth2.default.toLogin();

                                case 5:
                                    _wepy2.default.navigateBack({
                                        delta: 1 //返回的页面数，如果 delta 大于现有页面数，则返回到首页,
                                    });

                                case 6:
                                case "end":
                                    return _context.stop();
                            }
                        }
                    }, _callee, this);
                }));

                function onGotUserInfo(_x) {
                    return _ref2.apply(this, arguments);
                }

                return onGotUserInfo;
            }(),
            bindgetphonenumber: function () {
                var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(e) {
                    var mobile;
                    return regeneratorRuntime.wrap(function _callee2$(_context2) {
                        while (1) {
                            switch (_context2.prev = _context2.next) {
                                case 0:
                                    if (!(e.detail.errMsg == "getPhoneNumber:ok")) {
                                        _context2.next = 6;
                                        break;
                                    }

                                    _context2.next = 3;
                                    return _auth2.default.getPhone(e.detail);

                                case 3:
                                    mobile = _context2.sent;

                                    if (mobile) {
                                        _wepy2.default.setStorageSync('mobile', mobile);
                                        this.mobile = mobile;
                                    } else {
                                        _Tips2.default.toast('未授权成功，请重试', function () {}, 'none');
                                    }
                                    this.$apply();

                                case 6:
                                case "end":
                                    return _context2.stop();
                            }
                        }
                    }, _callee2, this);
                }));

                function bindgetphonenumber(_x2) {
                    return _ref3.apply(this, arguments);
                }

                return bindgetphonenumber;
            }()
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/home/auth'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImF1dGguanMiXSwibmFtZXMiOlsiRGlhbG9nIiwiY29uZmlnIiwibmF2aWdhdGlvbkJhclRpdGxlVGV4dCIsImRhdGEiLCJtb2JpbGUiLCJtZXRob2RzIiwib25Hb3RVc2VySW5mbyIsImUiLCJkZXRhaWwiLCJlcnJNc2ciLCJhdXRoIiwiZ2V0VXNlcmluZm8iLCJ0b0xvZ2luIiwid2VweSIsIm5hdmlnYXRlQmFjayIsImRlbHRhIiwiYmluZGdldHBob25lbnVtYmVyIiwiZ2V0UGhvbmUiLCJzZXRTdG9yYWdlU3luYyIsIlRpcHMiLCJ0b2FzdCIsIiRhcHBseSIsInBhZ2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFDSTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7Ozs7Ozs7Ozs7Ozs7SUFDcUJBLE07Ozs7Ozs7Ozs7Ozs7OzBMQUNqQkMsTSxHQUFTO0FBQ0xDLG9DQUF3QjtBQURuQixTLFFBR1RDLEksR0FBTztBQUNIQyxvQkFBUTtBQURMLFMsUUFHUEMsTyxHQUFVO0FBQ0FDLHlCQURBO0FBQUEscUdBQ2NDLENBRGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBDQUVFQSxFQUFFQyxNQUFGLENBQVNDLE1BQVQsSUFBbUIsZ0JBRnJCO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUEsMkNBR1FDLGVBQUtDLFdBQUwsQ0FBaUJKLEVBQUVDLE1BQW5CLENBSFI7O0FBQUE7QUFBQTtBQUFBLDJDQUlRRSxlQUFLRSxPQUFMLEVBSlI7O0FBQUE7QUFLRUMsbURBQUtDLFlBQUwsQ0FBa0I7QUFDZEMsK0NBQU8sQ0FETyxDQUNMO0FBREsscUNBQWxCOztBQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBVUFDLDhCQVZBO0FBQUEsc0dBVW1CVCxDQVZuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQ0FXRUEsRUFBRUMsTUFBRixDQUFTQyxNQUFULElBQW1CLG1CQVhyQjtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBLDJDQVlxQkMsZUFBS08sUUFBTCxDQUFjVixFQUFFQyxNQUFoQixDQVpyQjs7QUFBQTtBQVlNSiwwQ0FaTjs7QUFhRSx3Q0FBSUEsTUFBSixFQUFZO0FBQ1JTLHVEQUFLSyxjQUFMLENBQW9CLFFBQXBCLEVBQThCZCxNQUE5QjtBQUNBLDZDQUFLQSxNQUFMLEdBQWNBLE1BQWQ7QUFDSCxxQ0FIRCxNQUdPO0FBQ0hlLHVEQUFLQyxLQUFMLENBQVcsV0FBWCxFQUF3QixZQUFNLENBQUUsQ0FBaEMsRUFBa0MsTUFBbEM7QUFDSDtBQUNELHlDQUFLQyxNQUFMOztBQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBLFM7Ozs7RUFQc0JSLGVBQUtTLEk7O2tCQUFwQnRCLE0iLCJmaWxlIjoiYXV0aC5qcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4gICAgaW1wb3J0IHdlcHkgZnJvbSBcIndlcHlcIjtcclxuICAgIGltcG9ydCBhdXRoIGZyb20gXCJAL2FwaS9hdXRoXCJcclxuICAgIGltcG9ydCBUaXBzIGZyb20gXCJAL3V0aWxzL1RpcHNcIlxyXG4gICAgaW1wb3J0IGNvbmZpZyBmcm9tIFwiQC9hcGkvY29uZmlnXCJcclxuICAgIGV4cG9ydCBkZWZhdWx0IGNsYXNzIERpYWxvZyBleHRlbmRzIHdlcHkucGFnZSB7XHJcbiAgICAgICAgY29uZmlnID0ge1xyXG4gICAgICAgICAgICBuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0OiBcIueZu+W9lVwiXHJcbiAgICAgICAgfTtcclxuICAgICAgICBkYXRhID0ge1xyXG4gICAgICAgICAgICBtb2JpbGU6ICcnLFxyXG4gICAgICAgIH07XHJcbiAgICAgICAgbWV0aG9kcyA9IHtcclxuICAgICAgICAgICAgYXN5bmMgb25Hb3RVc2VySW5mbyhlKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoZS5kZXRhaWwuZXJyTXNnID09IFwiZ2V0VXNlckluZm86b2tcIikge1xyXG4gICAgICAgICAgICAgICAgICAgIGF3YWl0IGF1dGguZ2V0VXNlcmluZm8oZS5kZXRhaWwpXHJcbiAgICAgICAgICAgICAgICAgICAgYXdhaXQgYXV0aC50b0xvZ2luKClcclxuICAgICAgICAgICAgICAgICAgICB3ZXB5Lm5hdmlnYXRlQmFjayh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlbHRhOiAxIC8v6L+U5Zue55qE6aG16Z2i5pWw77yM5aaC5p6cIGRlbHRhIOWkp+S6jueOsOaciemhtemdouaVsO+8jOWImei/lOWbnuWIsOmmlumhtSxcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgYXN5bmMgYmluZGdldHBob25lbnVtYmVyKGUpIHtcclxuICAgICAgICAgICAgICAgIGlmIChlLmRldGFpbC5lcnJNc2cgPT0gXCJnZXRQaG9uZU51bWJlcjpva1wiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IG1vYmlsZSA9IGF3YWl0IGF1dGguZ2V0UGhvbmUoZS5kZXRhaWwpXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKG1vYmlsZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB3ZXB5LnNldFN0b3JhZ2VTeW5jKCdtb2JpbGUnLCBtb2JpbGUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm1vYmlsZSA9IG1vYmlsZVxyXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFRpcHMudG9hc3QoJ+acquaOiOadg+aIkOWKn++8jOivt+mHjeivlScsICgpID0+IHt9LCAnbm9uZScpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH07XHJcbiAgICB9XHJcbiJdfQ==