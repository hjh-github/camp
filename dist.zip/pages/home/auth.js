"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
  _inherits(Dialog, _wepy$page);

  function Dialog() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, Dialog);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
      navigationBarTitleText: "登录"
    }, _this.data = {
      mobile: ''
    }, _this.methods = {
      onGotUserInfo: function () {
        var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(e) {
          var _this2 = this;

          return regeneratorRuntime.wrap(function _callee2$(_context2) {
            while (1) {
              switch (_context2.prev = _context2.next) {
                case 0:
                  wx.getUserProfile({
                    desc: '仅用于部分活动显示',
                    success: function () {
                      var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(res) {
                        return regeneratorRuntime.wrap(function _callee$(_context) {
                          while (1) {
                            switch (_context.prev = _context.next) {
                              case 0:
                                _context.next = 2;
                                return _auth2.default.getUserinfo(res);

                              case 2:
                                _context.next = 4;
                                return _auth2.default.toLogin();

                              case 4:
                                _wepy2.default.navigateBack({
                                  delta: 1 //返回的页面数，如果 delta 大于现有页面数，则返回到首页,
                                });

                              case 5:
                              case "end":
                                return _context.stop();
                            }
                          }
                        }, _callee, _this2);
                      }));

                      function success(_x2) {
                        return _ref3.apply(this, arguments);
                      }

                      return success;
                    }()
                  });

                case 1:
                case "end":
                  return _context2.stop();
              }
            }
          }, _callee2, this);
        }));

        function onGotUserInfo(_x) {
          return _ref2.apply(this, arguments);
        }

        return onGotUserInfo;
      }(),
      bindgetphonenumber: function () {
        var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(e) {
          var mobile;
          return regeneratorRuntime.wrap(function _callee3$(_context3) {
            while (1) {
              switch (_context3.prev = _context3.next) {
                case 0:
                  if (!(e.detail.errMsg == "getPhoneNumber:ok")) {
                    _context3.next = 6;
                    break;
                  }

                  _context3.next = 3;
                  return _auth2.default.getPhone(e.detail);

                case 3:
                  mobile = _context3.sent;

                  if (mobile) {
                    _wepy2.default.setStorageSync('mobile', mobile);
                    this.mobile = mobile;
                  } else {
                    _Tips2.default.toast('未授权成功，请重试', function () {}, 'none');
                  }
                  this.$apply();

                case 6:
                case "end":
                  return _context3.stop();
              }
            }
          }, _callee3, this);
        }));

        function bindgetphonenumber(_x3) {
          return _ref4.apply(this, arguments);
        }

        return bindgetphonenumber;
      }()
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(Dialog, [{
    key: "onLoad",
    value: function onLoad(opt) {
      //用于部分活动要求不授权手机号，单独授权用户昵称 + 头像时使用
      if (opt.mobile) this.mobile = opt.mobile;
      console.log(opt.mobile);
    }
  }]);

  return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/home/auth'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImF1dGguanMiXSwibmFtZXMiOlsiRGlhbG9nIiwiY29uZmlnIiwibmF2aWdhdGlvbkJhclRpdGxlVGV4dCIsImRhdGEiLCJtb2JpbGUiLCJtZXRob2RzIiwib25Hb3RVc2VySW5mbyIsImUiLCJ3eCIsImdldFVzZXJQcm9maWxlIiwiZGVzYyIsInN1Y2Nlc3MiLCJyZXMiLCJhdXRoIiwiZ2V0VXNlcmluZm8iLCJ0b0xvZ2luIiwid2VweSIsIm5hdmlnYXRlQmFjayIsImRlbHRhIiwiYmluZGdldHBob25lbnVtYmVyIiwiZGV0YWlsIiwiZXJyTXNnIiwiZ2V0UGhvbmUiLCJzZXRTdG9yYWdlU3luYyIsIlRpcHMiLCJ0b2FzdCIsIiRhcHBseSIsIm9wdCIsImNvbnNvbGUiLCJsb2ciLCJwYWdlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFDRTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7Ozs7Ozs7Ozs7Ozs7SUFDcUJBLE07Ozs7Ozs7Ozs7Ozs7O3NMQUNuQkMsTSxHQUFTO0FBQ1BDLDhCQUF3QjtBQURqQixLLFFBR1RDLEksR0FBTztBQUNMQyxjQUFRO0FBREgsSyxRQVFQQyxPLEdBQVU7QUFDRkMsbUJBREU7QUFBQSw4RkFDWUMsQ0FEWjtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRU5DLHFCQUFHQyxjQUFILENBQWtCO0FBQ2hCQywwQkFBTSxXQURVO0FBRWhCQztBQUFBLDBGQUFRLGlCQUFNQyxHQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVDQUNBQyxlQUFLQyxXQUFMLENBQWlCRixHQUFqQixDQURBOztBQUFBO0FBQUE7QUFBQSx1Q0FFQUMsZUFBS0UsT0FBTCxFQUZBOztBQUFBO0FBR05DLCtDQUFLQyxZQUFMLENBQWtCO0FBQ2hCQyx5Q0FBTyxDQURTLENBQ1A7QUFETyxpQ0FBbEI7O0FBSE07QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQVI7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFGZ0IsbUJBQWxCOztBQUZNO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBYUZDLHdCQWJFO0FBQUEsOEZBYWlCWixDQWJqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFjRkEsRUFBRWEsTUFBRixDQUFTQyxNQUFULElBQW1CLG1CQWRqQjtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBLHlCQWVlUixlQUFLUyxRQUFMLENBQWNmLEVBQUVhLE1BQWhCLENBZmY7O0FBQUE7QUFlQWhCLHdCQWZBOztBQWdCSixzQkFBSUEsTUFBSixFQUFZO0FBQ1ZZLG1DQUFLTyxjQUFMLENBQW9CLFFBQXBCLEVBQThCbkIsTUFBOUI7QUFDQSx5QkFBS0EsTUFBTCxHQUFjQSxNQUFkO0FBQ0QsbUJBSEQsTUFHTztBQUNMb0IsbUNBQUtDLEtBQUwsQ0FBVyxXQUFYLEVBQXdCLFlBQU0sQ0FBRSxDQUFoQyxFQUFrQyxNQUFsQztBQUNEO0FBQ0QsdUJBQUtDLE1BQUw7O0FBdEJJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUEsSzs7Ozs7MkJBTEhDLEcsRUFBSTtBQUNUO0FBQ0EsVUFBR0EsSUFBSXZCLE1BQVAsRUFBZSxLQUFLQSxNQUFMLEdBQWN1QixJQUFJdkIsTUFBbEI7QUFDZndCLGNBQVFDLEdBQVIsQ0FBWUYsSUFBSXZCLE1BQWhCO0FBQ0Q7Ozs7RUFYaUNZLGVBQUtjLEk7O2tCQUFwQjlCLE0iLCJmaWxlIjoiYXV0aC5qcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4gIGltcG9ydCB3ZXB5IGZyb20gXCJ3ZXB5XCI7XHJcbiAgaW1wb3J0IGF1dGggZnJvbSBcIkAvYXBpL2F1dGhcIlxyXG4gIGltcG9ydCBUaXBzIGZyb20gXCJAL3V0aWxzL1RpcHNcIlxyXG4gIGltcG9ydCBjb25maWcgZnJvbSBcIkAvYXBpL2NvbmZpZ1wiXHJcbiAgZXhwb3J0IGRlZmF1bHQgY2xhc3MgRGlhbG9nIGV4dGVuZHMgd2VweS5wYWdlIHtcclxuICAgIGNvbmZpZyA9IHtcclxuICAgICAgbmF2aWdhdGlvbkJhclRpdGxlVGV4dDogXCLnmbvlvZVcIlxyXG4gICAgfTtcclxuICAgIGRhdGEgPSB7XHJcbiAgICAgIG1vYmlsZTogJycsXHJcbiAgICB9O1xuICAgIG9uTG9hZChvcHQpe1xuICAgICAgLy/nlKjkuo7pg6jliIbmtLvliqjopoHmsYLkuI3mjojmnYPmiYvmnLrlj7fvvIzljZXni6zmjojmnYPnlKjmiLfmmLXnp7AgKyDlpLTlg4/ml7bkvb/nlKhcbiAgICAgIGlmKG9wdC5tb2JpbGUpIHRoaXMubW9iaWxlID0gb3B0Lm1vYmlsZVxuICAgICAgY29uc29sZS5sb2cob3B0Lm1vYmlsZSlcbiAgICB9XHJcbiAgICBtZXRob2RzID0ge1xyXG4gICAgICBhc3luYyBvbkdvdFVzZXJJbmZvKGUpIHtcclxuICAgICAgICB3eC5nZXRVc2VyUHJvZmlsZSh7XHJcbiAgICAgICAgICBkZXNjOiAn5LuF55So5LqO6YOo5YiG5rS75Yqo5pi+56S6JyxcclxuICAgICAgICAgIHN1Y2Nlc3M6YXN5bmMgcmVzID0+IHtcclxuICAgICAgICAgICAgYXdhaXQgYXV0aC5nZXRVc2VyaW5mbyhyZXMpXHJcbiAgICAgICAgICAgIGF3YWl0IGF1dGgudG9Mb2dpbigpXHJcbiAgICAgICAgICAgIHdlcHkubmF2aWdhdGVCYWNrKHtcclxuICAgICAgICAgICAgICBkZWx0YTogMSAvL+i/lOWbnueahOmhtemdouaVsO+8jOWmguaenCBkZWx0YSDlpKfkuo7njrDmnInpobXpnaLmlbDvvIzliJnov5Tlm57liLDpppbpobUsXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pXHJcbiAgICAgIH0sXHJcbiAgICAgIGFzeW5jIGJpbmRnZXRwaG9uZW51bWJlcihlKSB7XHJcbiAgICAgICAgaWYgKGUuZGV0YWlsLmVyck1zZyA9PSBcImdldFBob25lTnVtYmVyOm9rXCIpIHtcclxuICAgICAgICAgIGxldCBtb2JpbGUgPSBhd2FpdCBhdXRoLmdldFBob25lKGUuZGV0YWlsKVxyXG4gICAgICAgICAgaWYgKG1vYmlsZSkge1xyXG4gICAgICAgICAgICB3ZXB5LnNldFN0b3JhZ2VTeW5jKCdtb2JpbGUnLCBtb2JpbGUpO1xyXG4gICAgICAgICAgICB0aGlzLm1vYmlsZSA9IG1vYmlsZVxyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgVGlwcy50b2FzdCgn5pyq5o6I5p2D5oiQ5Yqf77yM6K+36YeN6K+VJywgKCkgPT4ge30sICdub25lJylcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgfVxyXG4iXX0=