"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _dec, _class;

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _wepyRedux = require('./../../npm/wepy-redux/lib/index.js');

var _utils = require('./../../store/utils.js');

var _utils2 = _interopRequireDefault(_utils);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = (_dec = (0, _wepyRedux.connect)({
    city: _utils2.default.get("city")
}), _dec(_class = function (_wepy$page) {
    _inherits(Dialog, _wepy$page);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.data = {
            hidden: true,
            list: [],
            listCur: '',
            listCurID: ''
        }, _this.methods = {
            getCur: function getCur(e) {
                console.log(e.target.id);
                this.hidden = false;
                this.listCur = e.target.id;
            },
            setCur: function setCur(e) {
                this.hidden = true;
                this.listCur = this.listCur;
            },

            //滑动选择Item
            tMove: function tMove(e) {
                var y = e.touches[0].clientY,
                    offsettop = this.data.boxTop,
                    that = this;
                //判断选择区域,只有在选择区才会生效
                if (y > offsettop) {
                    var num = parseInt((y - offsettop) / 20);
                    this.listCur = that.list[num].name;
                };
            },

            //触发全部开始选择
            tStart: function tStart() {
                this.hidden = false;
            },

            //触发结束选择
            tEnd: function tEnd() {
                this.hidden = true;
                this.listCurID = this.listCur;
            },
            check: function check(e) {
                _utils2.default.save('city', e);
                _wepy2.default.$instance.globalData.cityCode = e.code;
                _wepy2.default.switchTab({ url: './index' });
            }
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(Dialog, [{
        key: "onLoad",
        value: function () {
            var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
                var res;
                return regeneratorRuntime.wrap(function _callee$(_context) {
                    while (1) {
                        switch (_context.prev = _context.next) {
                            case 0:
                                _context.next = 2;
                                return _config2.default.citys();

                            case 2:
                                res = _context.sent;

                                this.list = this.filter(res);
                                this.listCur = this.list[0].name;
                                this.$apply();

                            case 6:
                            case "end":
                                return _context.stop();
                        }
                    }
                }, _callee, this);
            }));

            function onLoad() {
                return _ref2.apply(this, arguments);
            }

            return onLoad;
        }()
        // 解析

    }, {
        key: "filter",
        value: function filter(arr) {
            var _obj = {},
                _arr = [];
            arr.forEach(function (e) {
                if (typeof _obj[e.initial] == 'undefined') {
                    _obj[e.initial] = [e];
                } else {
                    _obj[e.initial].push(e);
                }
            });
            for (var i in _obj) {
                _arr.push({
                    name: i,
                    list: _obj[i]
                });
            }
            return _arr;
        }
    }]);

    return Dialog;
}(_wepy2.default.page)) || _class);

Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/home/address'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFkZHJlc3MuanMiXSwibmFtZXMiOlsiRGlhbG9nIiwiY2l0eSIsInN0b3JlIiwiZ2V0IiwiZGF0YSIsImhpZGRlbiIsImxpc3QiLCJsaXN0Q3VyIiwibGlzdEN1cklEIiwibWV0aG9kcyIsImdldEN1ciIsImUiLCJjb25zb2xlIiwibG9nIiwidGFyZ2V0IiwiaWQiLCJzZXRDdXIiLCJ0TW92ZSIsInkiLCJ0b3VjaGVzIiwiY2xpZW50WSIsIm9mZnNldHRvcCIsImJveFRvcCIsInRoYXQiLCJudW0iLCJwYXJzZUludCIsIm5hbWUiLCJ0U3RhcnQiLCJ0RW5kIiwiY2hlY2siLCJzYXZlIiwid2VweSIsIiRpbnN0YW5jZSIsImdsb2JhbERhdGEiLCJjaXR5Q29kZSIsImNvZGUiLCJzd2l0Y2hUYWIiLCJ1cmwiLCJjb25maWciLCJjaXR5cyIsInJlcyIsImZpbHRlciIsIiRhcHBseSIsImFyciIsIl9vYmoiLCJfYXJyIiwiZm9yRWFjaCIsImluaXRpYWwiLCJwdXNoIiwiaSIsInBhZ2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7O0FBQ0k7Ozs7QUFDQTs7OztBQUNBOztBQUdBOzs7Ozs7Ozs7Ozs7OztJQUlxQkEsTSxXQUhwQix3QkFBUTtBQUNMQyxVQUFNQyxnQkFBTUMsR0FBTixDQUFVLE1BQVY7QUFERCxDQUFSLEM7Ozs7Ozs7Ozs7Ozs7OzBMQUlHQyxJLEdBQU87QUFDSEMsb0JBQVEsSUFETDtBQUVIQyxrQkFBTSxFQUZIO0FBR0hDLHFCQUFTLEVBSE47QUFJSEMsdUJBQVc7QUFKUixTLFFBK0JQQyxPLEdBQVU7QUFDTkMsa0JBRE0sa0JBQ0NDLENBREQsRUFDSTtBQUNOQyx3QkFBUUMsR0FBUixDQUFZRixFQUFFRyxNQUFGLENBQVNDLEVBQXJCO0FBQ0EscUJBQUtWLE1BQUwsR0FBYyxLQUFkO0FBQ0EscUJBQUtFLE9BQUwsR0FBZUksRUFBRUcsTUFBRixDQUFTQyxFQUF4QjtBQUNILGFBTEs7QUFNTkMsa0JBTk0sa0JBTUNMLENBTkQsRUFNSTtBQUNOLHFCQUFLTixNQUFMLEdBQWMsSUFBZDtBQUNBLHFCQUFLRSxPQUFMLEdBQWUsS0FBS0EsT0FBcEI7QUFDSCxhQVRLOztBQVVOO0FBQ0FVLGlCQVhNLGlCQVdBTixDQVhBLEVBV0c7QUFDTCxvQkFBSU8sSUFBSVAsRUFBRVEsT0FBRixDQUFVLENBQVYsRUFBYUMsT0FBckI7QUFBQSxvQkFDSUMsWUFBWSxLQUFLakIsSUFBTCxDQUFVa0IsTUFEMUI7QUFBQSxvQkFFSUMsT0FBTyxJQUZYO0FBR0E7QUFDQSxvQkFBSUwsSUFBSUcsU0FBUixFQUFtQjtBQUNmLHdCQUFJRyxNQUFNQyxTQUFTLENBQUNQLElBQUlHLFNBQUwsSUFBa0IsRUFBM0IsQ0FBVjtBQUNBLHlCQUFLZCxPQUFMLEdBQWVnQixLQUFLakIsSUFBTCxDQUFVa0IsR0FBVixFQUFlRSxJQUE5QjtBQUNIO0FBQ0osYUFwQks7O0FBcUJOO0FBQ0FDLGtCQXRCTSxvQkFzQkc7QUFDTCxxQkFBS3RCLE1BQUwsR0FBYyxLQUFkO0FBQ0gsYUF4Qks7O0FBeUJOO0FBQ0F1QixnQkExQk0sa0JBMEJDO0FBQ0gscUJBQUt2QixNQUFMLEdBQWMsSUFBZDtBQUNBLHFCQUFLRyxTQUFMLEdBQWlCLEtBQUtELE9BQXRCO0FBQ0gsYUE3Qks7QUE4Qk5zQixpQkE5Qk0saUJBOEJBbEIsQ0E5QkEsRUE4QkU7QUFDSlQsZ0NBQU00QixJQUFOLENBQVcsTUFBWCxFQUFtQm5CLENBQW5CO0FBQ0FvQiwrQkFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCQyxRQUExQixHQUFxQ3ZCLEVBQUV3QixJQUF2QztBQUNBSiwrQkFBS0ssU0FBTCxDQUFlLEVBQUVDLEtBQUssU0FBUCxFQUFmO0FBRUg7QUFuQ0ssUzs7Ozs7Ozs7Ozs7Ozt1Q0F4QlVDLGlCQUFPQyxLQUFQLEU7OztBQUFaQyxtQzs7QUFDSixxQ0FBS2xDLElBQUwsR0FBWSxLQUFLbUMsTUFBTCxDQUFZRCxHQUFaLENBQVo7QUFDQSxxQ0FBS2pDLE9BQUwsR0FBZSxLQUFLRCxJQUFMLENBQVUsQ0FBVixFQUFhb0IsSUFBNUI7QUFDQSxxQ0FBS2dCLE1BQUw7Ozs7Ozs7Ozs7Ozs7Ozs7QUFFSjs7OzsrQkFDT0MsRyxFQUFLO0FBQ1IsZ0JBQUlDLE9BQU8sRUFBWDtBQUFBLGdCQUNJQyxPQUFPLEVBRFg7QUFFQUYsZ0JBQUlHLE9BQUosQ0FBWSxhQUFLO0FBQ2Isb0JBQUksT0FBT0YsS0FBS2pDLEVBQUVvQyxPQUFQLENBQVAsSUFBMEIsV0FBOUIsRUFBMkM7QUFDdkNILHlCQUFLakMsRUFBRW9DLE9BQVAsSUFBa0IsQ0FBQ3BDLENBQUQsQ0FBbEI7QUFDSCxpQkFGRCxNQUVPO0FBQ0hpQyx5QkFBS2pDLEVBQUVvQyxPQUFQLEVBQWdCQyxJQUFoQixDQUFxQnJDLENBQXJCO0FBQ0g7QUFDSixhQU5EO0FBT0EsaUJBQUssSUFBSXNDLENBQVQsSUFBY0wsSUFBZCxFQUFvQjtBQUNoQkMscUJBQUtHLElBQUwsQ0FBVTtBQUNOdEIsMEJBQU11QixDQURBO0FBRU4zQywwQkFBTXNDLEtBQUtLLENBQUw7QUFGQSxpQkFBVjtBQUlIO0FBQ0QsbUJBQU9KLElBQVA7QUFDSDs7OztFQS9CK0JkLGVBQUttQixJO2tCQUFwQmxELE0iLCJmaWxlIjoiYWRkcmVzcy5qcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4gICAgaW1wb3J0IHdlcHkgZnJvbSBcIndlcHlcIlxyXG4gICAgaW1wb3J0IGNvbmZpZyBmcm9tIFwiQC9hcGkvY29uZmlnXCJcclxuICAgIGltcG9ydCB7XHJcbiAgICAgICAgY29ubmVjdFxyXG4gICAgfSBmcm9tIFwid2VweS1yZWR1eFwiXHJcbiAgICBpbXBvcnQgc3RvcmUgZnJvbSBcIkAvc3RvcmUvdXRpbHNcIlxyXG4gICAgQGNvbm5lY3Qoe1xyXG4gICAgICAgIGNpdHk6IHN0b3JlLmdldChcImNpdHlcIilcclxuICAgIH0pXHJcbiAgICBleHBvcnQgZGVmYXVsdCBjbGFzcyBEaWFsb2cgZXh0ZW5kcyB3ZXB5LnBhZ2Uge1xyXG4gICAgICAgIGRhdGEgPSB7XHJcbiAgICAgICAgICAgIGhpZGRlbjogdHJ1ZSxcclxuICAgICAgICAgICAgbGlzdDogW10sXHJcbiAgICAgICAgICAgIGxpc3RDdXI6ICcnLFxyXG4gICAgICAgICAgICBsaXN0Q3VySUQ6ICcnXHJcbiAgICAgICAgfTtcclxuICAgICAgICBhc3luYyBvbkxvYWQoKSB7XHJcbiAgICAgICAgICAgIGxldCByZXMgPSBhd2FpdCBjb25maWcuY2l0eXMoKVxyXG4gICAgICAgICAgICB0aGlzLmxpc3QgPSB0aGlzLmZpbHRlcihyZXMpXHJcbiAgICAgICAgICAgIHRoaXMubGlzdEN1ciA9IHRoaXMubGlzdFswXS5uYW1lXHJcbiAgICAgICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgICB9XHJcbiAgICAgICAgLy8g6Kej5p6QXHJcbiAgICAgICAgZmlsdGVyKGFycikge1xyXG4gICAgICAgICAgICBsZXQgX29iaiA9IHt9LFxyXG4gICAgICAgICAgICAgICAgX2FyciA9IFtdXHJcbiAgICAgICAgICAgIGFyci5mb3JFYWNoKGUgPT4ge1xyXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBfb2JqW2UuaW5pdGlhbF0gPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgICAgICBfb2JqW2UuaW5pdGlhbF0gPSBbZV1cclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgX29ialtlLmluaXRpYWxdLnB1c2goZSlcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgZm9yIChsZXQgaSBpbiBfb2JqKSB7XHJcbiAgICAgICAgICAgICAgICBfYXJyLnB1c2goe1xyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU6IGksXHJcbiAgICAgICAgICAgICAgICAgICAgbGlzdDogX29ialtpXVxyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gX2FyclxyXG4gICAgICAgIH1cclxuICAgICAgICBtZXRob2RzID0ge1xyXG4gICAgICAgICAgICBnZXRDdXIoZSkge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZS50YXJnZXQuaWQpXHJcbiAgICAgICAgICAgICAgICB0aGlzLmhpZGRlbiA9IGZhbHNlXHJcbiAgICAgICAgICAgICAgICB0aGlzLmxpc3RDdXIgPSBlLnRhcmdldC5pZFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBzZXRDdXIoZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5oaWRkZW4gPSB0cnVlXHJcbiAgICAgICAgICAgICAgICB0aGlzLmxpc3RDdXIgPSB0aGlzLmxpc3RDdXJcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgLy/mu5HliqjpgInmi6lJdGVtXHJcbiAgICAgICAgICAgIHRNb3ZlKGUpIHtcclxuICAgICAgICAgICAgICAgIGxldCB5ID0gZS50b3VjaGVzWzBdLmNsaWVudFksXHJcbiAgICAgICAgICAgICAgICAgICAgb2Zmc2V0dG9wID0gdGhpcy5kYXRhLmJveFRvcCxcclxuICAgICAgICAgICAgICAgICAgICB0aGF0ID0gdGhpcztcclxuICAgICAgICAgICAgICAgIC8v5Yik5pat6YCJ5oup5Yy65Z+fLOWPquacieWcqOmAieaLqeWMuuaJjeS8mueUn+aViFxyXG4gICAgICAgICAgICAgICAgaWYgKHkgPiBvZmZzZXR0b3ApIHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgbnVtID0gcGFyc2VJbnQoKHkgLSBvZmZzZXR0b3ApIC8gMjApO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubGlzdEN1ciA9IHRoYXQubGlzdFtudW1dLm5hbWVcclxuICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIC8v6Kem5Y+R5YWo6YOo5byA5aeL6YCJ5oupXHJcbiAgICAgICAgICAgIHRTdGFydCgpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuaGlkZGVuID0gZmFsc2VcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgLy/op6blj5Hnu5PmnZ/pgInmi6lcclxuICAgICAgICAgICAgdEVuZCgpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuaGlkZGVuID0gdHJ1ZVxyXG4gICAgICAgICAgICAgICAgdGhpcy5saXN0Q3VySUQgPSB0aGlzLmxpc3RDdXJcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgY2hlY2soZSl7XHJcbiAgICAgICAgICAgICAgICBzdG9yZS5zYXZlKCdjaXR5JywgZSlcclxuICAgICAgICAgICAgICAgIHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuY2l0eUNvZGUgPSBlLmNvZGVcclxuICAgICAgICAgICAgICAgIHdlcHkuc3dpdGNoVGFiKHsgdXJsOiAnLi9pbmRleCcgfSk7XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH07XHJcbiAgICB9XHJcbiJdfQ==