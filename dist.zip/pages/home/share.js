"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _dec, _class;

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

var _Lang = require('./../../utils/Lang.js');

var _Lang2 = _interopRequireDefault(_Lang);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

var _utils = require('./../../store/utils.js');

var _utils2 = _interopRequireDefault(_utils);

var _wepyRedux = require('./../../npm/wepy-redux/lib/index.js');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var shareInfo = (_dec = (0, _wepyRedux.connect)({
    shareInfo: _utils2.default.get("shareInfo")
}), _dec(_class = function (_wepy$page) {
    _inherits(shareInfo, _wepy$page);

    function shareInfo() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, shareInfo);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = shareInfo.__proto__ || Object.getPrototypeOf(shareInfo)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
            navigationBarTitleText: "生成海报"
        }, _this.methods = {
            //点击保存到相册
            saveImg: function saveImg() {
                var _this2 = this;

                if (this.errcode == '-1') {
                    _Lang2.default.openSetting();
                    return;
                }
                _Lang2.default.downImg(this.loadImagePath, function (res) {
                    if (res.code == 0) {
                        _Tips2.default.toast('保存成功', function () {}, 'none');
                    } else if (res.code == '-1') {
                        _this2.errcode = res.code;
                        _Tips2.default.toast('您已拒绝授权下载图片，点击保存按钮获取授权', function () {}, 'none');
                    }
                    _this2.$apply();
                });
            }
        }, _this.data = {
            loadImagePath: '',
            errcode: 0
            /**
             * 生命周期函数--监听页面加载
             */
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(shareInfo, [{
        key: "onLoad",
        value: function () {
            var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(options) {
                var agentId, res;
                return regeneratorRuntime.wrap(function _callee$(_context) {
                    while (1) {
                        switch (_context.prev = _context.next) {
                            case 0:
                                _context.next = 2;
                                return _auth2.default.login();

                            case 2:
                                agentId = _wepy2.default.getStorageSync('member').agentId;
                                _context.next = 5;
                                return _config2.default.getPoster({
                                    page: this.shareInfo.path,
                                    sceneStr: encodeURI("agentId=" + agentId + "&id=" + this.shareInfo.id),
                                    id: this.shareInfo.id,
                                    type: this.shareInfo.type
                                });

                            case 5:
                                res = _context.sent;

                                this.loadImagePath = res.qr;
                                this.$apply();

                            case 8:
                            case "end":
                                return _context.stop();
                        }
                    }
                }, _callee, this);
            }));

            function onLoad(_x) {
                return _ref2.apply(this, arguments);
            }

            return onLoad;
        }()
    }]);

    return shareInfo;
}(_wepy2.default.page)) || _class);

Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(shareInfo , 'pages/home/share'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNoYXJlLmpzIl0sIm5hbWVzIjpbInNoYXJlSW5mbyIsInN0b3JlIiwiZ2V0IiwiY29uZmlnIiwibmF2aWdhdGlvbkJhclRpdGxlVGV4dCIsIm1ldGhvZHMiLCJzYXZlSW1nIiwiZXJyY29kZSIsIkxhbmciLCJvcGVuU2V0dGluZyIsImRvd25JbWciLCJsb2FkSW1hZ2VQYXRoIiwicmVzIiwiY29kZSIsIlRpcHMiLCJ0b2FzdCIsIiRhcHBseSIsImRhdGEiLCJvcHRpb25zIiwiYXV0aCIsImxvZ2luIiwiYWdlbnRJZCIsIndlcHkiLCJnZXRTdG9yYWdlU3luYyIsImdldFBvc3RlciIsInBhZ2UiLCJwYXRoIiwic2NlbmVTdHIiLCJlbmNvZGVVUkkiLCJpZCIsInR5cGUiLCJxciJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7QUFDSTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNDOzs7O0FBQ0Q7Ozs7QUFDQTs7Ozs7Ozs7Ozs7O0lBTXFCQSxTLFdBSHBCLHdCQUFRO0FBQ0xBLGVBQVdDLGdCQUFNQyxHQUFOLENBQVUsV0FBVjtBQUROLENBQVIsQzs7Ozs7Ozs7Ozs7Ozs7Z01BSUdDLE0sR0FBUztBQUNMQyxvQ0FBd0I7QUFEbkIsUyxRQUdUQyxPLEdBQVU7QUFDTjtBQUNBQyxtQkFGTSxxQkFFSTtBQUFBOztBQUNOLG9CQUFHLEtBQUtDLE9BQUwsSUFBZ0IsSUFBbkIsRUFBd0I7QUFDdEJDLG1DQUFLQyxXQUFMO0FBQ0E7QUFDRDtBQUNERCwrQkFBS0UsT0FBTCxDQUFhLEtBQUtDLGFBQWxCLEVBQWdDLGVBQUs7QUFDbkMsd0JBQUdDLElBQUlDLElBQUosSUFBWSxDQUFmLEVBQWlCO0FBQ2JDLHVDQUFLQyxLQUFMLENBQVcsTUFBWCxFQUFtQixZQUFNLENBQUUsQ0FBM0IsRUFBNkIsTUFBN0I7QUFDSCxxQkFGRCxNQUVNLElBQUdILElBQUlDLElBQUosSUFBWSxJQUFmLEVBQW9CO0FBQ3RCLCtCQUFLTixPQUFMLEdBQWVLLElBQUlDLElBQW5CO0FBQ0FDLHVDQUFLQyxLQUFMLENBQVcsdUJBQVgsRUFBb0MsWUFBTSxDQUFFLENBQTVDLEVBQThDLE1BQTlDO0FBQ0g7QUFDRCwyQkFBS0MsTUFBTDtBQUNELGlCQVJEO0FBU0g7QUFoQkssUyxRQWtCVkMsSSxHQUFPO0FBQ0hOLDJCQUFjLEVBRFg7QUFFSEoscUJBQVE7QUFFWjs7O0FBSk8sUzs7Ozs7O2lHQU9NVyxPOzs7Ozs7O3VDQUNIQyxlQUFLQyxLQUFMLEU7OztBQUNGQyx1QyxHQUFVQyxlQUFLQyxjQUFMLENBQW9CLFFBQXBCLEVBQThCRixPOzt1Q0FDNUJsQixpQkFBT3FCLFNBQVAsQ0FBaUI7QUFDN0JDLDBDQUFNLEtBQUt6QixTQUFMLENBQWUwQixJQURRO0FBRTdCQyw4Q0FBVUMsdUJBQXFCUCxPQUFyQixZQUFtQyxLQUFLckIsU0FBTCxDQUFlNkIsRUFBbEQsQ0FGbUI7QUFHN0JBLHdDQUFHLEtBQUs3QixTQUFMLENBQWU2QixFQUhXO0FBSTdCQywwQ0FBSyxLQUFLOUIsU0FBTCxDQUFlOEI7QUFKUyxpQ0FBakIsQzs7O0FBQVpsQixtQzs7QUFNSixxQ0FBS0QsYUFBTCxHQUFxQkMsSUFBSW1CLEVBQXpCO0FBQ0EscUNBQUtmLE1BQUw7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUF2QytCTSxlQUFLRyxJO2tCQUF2QnpCLFMiLCJmaWxlIjoic2hhcmUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuICAgIGltcG9ydCB3ZXB5IGZyb20gXCJ3ZXB5XCI7XHJcbiAgICBpbXBvcnQgY29uZmlnIGZyb20gXCJAL2FwaS9jb25maWdcIlxyXG4gICAgaW1wb3J0IGF1dGggZnJvbSBcIkAvYXBpL2F1dGhcIlxyXG4gICAgaW1wb3J0IExhbmcgZnJvbSBcIkAvdXRpbHMvTGFuZ1wiXHJcbiAgICAgaW1wb3J0IFRpcHMgZnJvbSBcIkAvdXRpbHMvVGlwc1wiXHJcbiAgICBpbXBvcnQgc3RvcmUgZnJvbSBcIkAvc3RvcmUvdXRpbHNcIlxyXG4gICAgaW1wb3J0IHtcclxuICAgICAgICBjb25uZWN0XHJcbiAgICB9IGZyb20gXCJ3ZXB5LXJlZHV4XCJcclxuICAgIEBjb25uZWN0KHtcclxuICAgICAgICBzaGFyZUluZm86IHN0b3JlLmdldChcInNoYXJlSW5mb1wiKVxyXG4gICAgfSlcclxuICAgIGV4cG9ydCBkZWZhdWx0IGNsYXNzIHNoYXJlSW5mbyBleHRlbmRzIHdlcHkucGFnZSB7XHJcbiAgICAgICAgY29uZmlnID0ge1xyXG4gICAgICAgICAgICBuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0OiBcIueUn+aIkOa1t+aKpVwiXHJcbiAgICAgICAgfTtcclxuICAgICAgICBtZXRob2RzID0ge1xyXG4gICAgICAgICAgICAvL+eCueWHu+S/neWtmOWIsOebuOWGjFxyXG4gICAgICAgICAgICBzYXZlSW1nKCkge1xyXG4gICAgICAgICAgICAgICAgaWYodGhpcy5lcnJjb2RlID09ICctMScpe1xyXG4gICAgICAgICAgICAgICAgICBMYW5nLm9wZW5TZXR0aW5nKClcclxuICAgICAgICAgICAgICAgICAgcmV0dXJuIFxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgTGFuZy5kb3duSW1nKHRoaXMubG9hZEltYWdlUGF0aCxyZXM9PntcclxuICAgICAgICAgICAgICAgICAgaWYocmVzLmNvZGUgPT0gMCl7XHJcbiAgICAgICAgICAgICAgICAgICAgICBUaXBzLnRvYXN0KCfkv53lrZjmiJDlip8nLCAoKSA9PiB7fSwgJ25vbmUnKVxyXG4gICAgICAgICAgICAgICAgICB9ZWxzZSBpZihyZXMuY29kZSA9PSAnLTEnKXtcclxuICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZXJyY29kZSA9IHJlcy5jb2RlXHJcbiAgICAgICAgICAgICAgICAgICAgICBUaXBzLnRvYXN0KCfmgqjlt7Lmi5Lnu53mjojmnYPkuIvovb3lm77niYfvvIzngrnlh7vkv53lrZjmjInpkq7ojrflj5bmjojmnYMnLCAoKSA9PiB7fSwgJ25vbmUnKVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuICAgICAgICBkYXRhID0ge1xyXG4gICAgICAgICAgICBsb2FkSW1hZ2VQYXRoOicnLFxyXG4gICAgICAgICAgICBlcnJjb2RlOjBcclxuICAgICAgICB9XHJcbiAgICAgICAgLyoqXHJcbiAgICAgICAgICog55Sf5ZG95ZGo5pyf5Ye95pWwLS3nm5HlkKzpobXpnaLliqDovb1cclxuICAgICAgICAgKi9cclxuICAgICAgICBhc3luYyBvbkxvYWQob3B0aW9ucykge1xyXG4gICAgICAgICAgICBhd2FpdCBhdXRoLmxvZ2luKClcclxuICAgICAgICAgICAgbGV0IGFnZW50SWQgPSB3ZXB5LmdldFN0b3JhZ2VTeW5jKCdtZW1iZXInKS5hZ2VudElkXHJcbiAgICAgICAgICAgIGxldCByZXMgPSBhd2FpdCBjb25maWcuZ2V0UG9zdGVyKHtcclxuICAgICAgICAgICAgICAgIHBhZ2U6IHRoaXMuc2hhcmVJbmZvLnBhdGgsXHJcbiAgICAgICAgICAgICAgICBzY2VuZVN0cjogZW5jb2RlVVJJKGBhZ2VudElkPSR7YWdlbnRJZH0maWQ9JHt0aGlzLnNoYXJlSW5mby5pZH1gKSxcclxuICAgICAgICAgICAgICAgIGlkOnRoaXMuc2hhcmVJbmZvLmlkLFxyXG4gICAgICAgICAgICAgICAgdHlwZTp0aGlzLnNoYXJlSW5mby50eXBlXHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIHRoaXMubG9hZEltYWdlUGF0aCA9IHJlcy5xclxyXG4gICAgICAgICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICAgICAgfVxyXG5cclxuICAgIH1cclxuIl19