"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _dec, _class;

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

var _Lang = require('./../../utils/Lang.js');

var _Lang2 = _interopRequireDefault(_Lang);

var _utils = require('./../../store/utils.js');

var _utils2 = _interopRequireDefault(_utils);

var _wepyRedux = require('./../../npm/wepy-redux/lib/index.js');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var shareInfo = (_dec = (0, _wepyRedux.connect)({
    shareInfo: _utils2.default.get("shareInfo")
}), _dec(_class = function (_wepy$page) {
    _inherits(shareInfo, _wepy$page);

    function shareInfo() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, shareInfo);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = shareInfo.__proto__ || Object.getPrototypeOf(shareInfo)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
            navigationBarTitleText: "生成海报"
        }, _this.methods = {
            //点击保存到相册
            saveImg: function saveImg() {
                console.log('dowm');
                _Lang2.default.downImg(this.loadImagePath);
            }
        }, _this.data = {
            // canvas 
            _width: '360', //手机屏宽
            _heigth: '637', //手机屏高
            swiperHeight: 300, //主图图片高度
            canvasType: false, //canvas是否显示
            loadImagePath: '', //下载的图片
            imageUrl: 'https://images.hxqxly.com/hxqimage/images/1/course/90acf8e9-5f2d-46d5-835e-a2891b842621.jpg', //主图网络路径
            codeUrl: 'https://images.hxqxly.com/hxqimage/images/1/course/90acf8e9-5f2d-46d5-835e-a2891b842621.jpg', //二维码网络路径
            bgUrl: '/static/images/bg.jpg',
            avat: '',
            name: '',
            localImageUrl: '', //绘制的商品图片本地路径
            localCodeUrl: '', //绘制的二维码图片本地路径
            localBgUrl: '',
            localavatUrl: ''
            /**
             * 生命周期函数--监听页面加载
             */
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(shareInfo, [{
        key: "onLoad",
        value: function () {
            var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(options) {
                var res;
                return regeneratorRuntime.wrap(function _callee$(_context) {
                    while (1) {
                        switch (_context.prev = _context.next) {
                            case 0:
                                _context.next = 2;
                                return _auth2.default.login();

                            case 2:
                                _context.next = 4;
                                return _config2.default.getUnlimited({
                                    page: this.shareInfo.path,
                                    sceneStr: this.shareInfo.id
                                });

                            case 4:
                                res = _context.sent;

                                this.codeUrl = res.qr;
                                this.avat = res.profilePhoto;
                                this.name = res.name;
                                this.$apply();
                                this.creatQrcodePictures();

                            case 10:
                            case "end":
                                return _context.stop();
                        }
                    }
                }, _callee, this);
            }));

            function onLoad(_x) {
                return _ref2.apply(this, arguments);
            }

            return onLoad;
        }()
        /*按生成图片按钮时*/

    }, {
        key: "creatQrcodePictures",
        value: function creatQrcodePictures() {
            wx.showLoading({
                title: '正在绘制图片'
            });
            /*获取手机宽高*/
            var that = this;
            var imgHeigth = this.swiperHeight;
            var imgUrl = this.imageUrl;
            var qrcodeUrl = this.codeUrl;
            that.getImginfo([imgUrl, qrcodeUrl, that.avat, that.bgUrl], 0);
        }
        // 获取图片信息

    }, {
        key: "getImginfo",
        value: function getImginfo(urlArr, _type) {
            var that = this;
            wx.getImageInfo({
                src: urlArr[_type],
                success: function success(res) {
                    //res.path是网络图片的本地地址
                    if (_type === 0) {
                        //商品图片
                        that.localImageUrl = res.path;
                        that.getImginfo(urlArr, 1);
                    } else if (_type == 1) {
                        that.localCodeUrl = res.path;
                        that.getImginfo(urlArr, 2);
                    } else if (_type == 2) {
                        that.localavatUrl = res.path;
                        that.getImginfo(urlArr, 3);
                    } else {
                        that.localBgUrl = res.path;
                        that.createNewImg();
                    }
                },
                fail: function fail(res) {
                    //失败回调
                    console.log('Fail：', _type, res);
                }
            });
        }
        //绘制canvas

    }, {
        key: "createNewImg",
        value: function createNewImg() {
            var that = this;
            // 图片的x坐标
            var bg_x = 10;
            // 图片的y坐标
            var bg_y = 70;
            // 图片宽度
            var bg_w = this.data.pageWidth - 116;
            // 图片高度
            var bg_h = this.data.pageHeight * 0.35;
            // 图片圆角
            var bg_r = 4;
            var ctx = wx.createCanvasContext('mycanvas');
            // 绘制背景
            ctx.setFillStyle("#fff");
            ctx.fillRect(0, 0, 0, 0);
            //绘制背景图片
            ctx.drawImage(this.bgUrl, 0, 0, 360, 637);
            //绘制头像
            var qrW = 50; //绘制的二维码宽度
            var qrH = 50; //绘制的二维码高度
            var qr_x = 40; //绘制的二维码在画布上的位置
            var qr_y = 50; //绘制的二维码在画布上的位置
            ctx.save();
            ctx.beginPath(); //开始绘制
            //先画个圆  前两个参数确定了圆心 （x,y） 坐标 第三个参数是圆的半径 四参数是绘图方向 默认是false，即顺时针
            ctx.arc(qrW / 2 + qr_x, qrH / 2 + qr_y, qrW / 2, 0, Math.PI * 2, false);
            ctx.clip(); //画好了圆 剪切 原始画布中剪切任意形状和尺寸。一旦剪切了某个区域，则所有之后的绘图都会被限制在被剪切的区域内 这也是我们要save上下文的原因
            ctx.drawImage(this.localavatUrl, qr_x, qr_y, qrW, qrH);
            // 恢复之前保存的绘图上下文
            ctx.restore();
            ctx.setFontSize(16);
            ctx.setFillStyle('#333');
            ctx.fillText(this.name, 100, 70, 280);
            ctx.setFontSize(12);
            ctx.setFillStyle('#999');
            ctx.fillText('成长，是我们最值得珍藏的记忆', 100, 90, 280);
            // 绘制banner
            ctx.beginPath();
            ctx.save();
            var left = 40,
                top = 120,
                width = 280,
                height = 140,
                fillet = 6,
                w = 2;
            left = left / 2 * w;
            top = top / 2 * w;
            width = width / 2 * w;
            height = height / 2 * w;
            fillet = fillet / 2 * w;
            ctx.setLineWidth(1);
            ctx.setStrokeStyle('#ffffff');
            ctx.moveTo(left + fillet, top); // 创建开始点
            ctx.lineTo(left + width - fillet, top); // 创建水平线
            ctx.arcTo(left + width, top, left + width, top + fillet, fillet); // 创建弧
            ctx.lineTo(left + width, top + height - fillet); // 创建垂直线
            ctx.arcTo(left + width, top + height, left + width - fillet, top + height, fillet); // 创建弧
            ctx.lineTo(left + fillet, top + height); // 创建水平线
            ctx.arcTo(left, top + height, left, top + height - fillet, fillet); // 创建弧
            ctx.lineTo(left, top + fillet); // 创建垂直线
            ctx.arcTo(left, top, left + fillet, top, fillet); // 创建弧
            ctx.stroke(); // 这个具体干什么用的？
            ctx.clip();
            ctx.drawImage(this.localImageUrl, left, top, width, height);
            ctx.restore();
            // // 绘制标题
            ctx.setFontSize(13);
            ctx.setFillStyle('#333');
            //商品名称
            ctx.fillText(this.shareInfo.course.courseTittle, 40, 290, 280);
            // 绘制价格单位 '￥'
            ctx.setFontSize(16);
            ctx.setFillStyle('#333');
            ctx.fillText('活动费：', 40, 315, 280);
            ctx.setFontSize(12);
            ctx.setFillStyle('#fb867f');
            ctx.fillText('￥', 100, 315, 280);
            ctx.setFontSize(16);
            ctx.setFillStyle('#fb867f');
            ctx.fillText(this.shareInfo.course.price, 110, 315, 280);
            // 绘制已售
            ctx.setFontSize(13);
            ctx.setFillStyle('#999');
            ctx.fillText("\u5DF2\u552E" + (this.shareInfo.course.actualSales + this.shareInfo.course.virtualSales) + "\u4EBA", 260, 315, 280);
            // 绘制请求助力
            ctx.setFontSize(15);
            ctx.setFillStyle('#999');
            ctx.fillText('我正在参加“华心桥体验营”的促销活动', 50, 370, 280);
            ctx.setFontSize(15);
            ctx.setFillStyle('#999');
            ctx.fillText('原价：', 60, 394, 280);
            ctx.setFontSize(15);
            ctx.setFillStyle('#fb867f');
            ctx.fillText(this.shareInfo.course.price + "\u5143\uFF0C", 100, 394, 280);
            ctx.setFontSize(15);
            ctx.setFillStyle('#999');
            ctx.fillText('最低：', 180, 394, 280);
            ctx.setFontSize(15);
            ctx.setFillStyle('#fb867f');
            ctx.fillText(this.shareInfo.course.minimumPrice + "\u5143\uFF0C", 220, 394, 280);
            ctx.setFontSize(15);
            ctx.setFillStyle('#999');
            ctx.fillText('请给我点一点出点力，谢谢！', 80, 420, 280);
            // // 绘制小程序名称
            ctx.drawImage(this.localCodeUrl, 40, 500, 100, 100);
            // 显示绘制
            ctx.draw();
            //将生成好的图片保存到本地，需要延迟一会，绘制期间耗时
            setTimeout(function () {
                wx.canvasToTempFilePath({
                    canvasId: 'mycanvas',
                    success: function success(res) {
                        var tempFilePath = res.tempFilePath;
                        that.loadImagePath = tempFilePath;
                        that.$apply();
                    },
                    fail: function fail(res) {
                        console.log(res);
                    }
                });
            }, 500);
            //关闭提示
            wx.hideLoading();
        }
    }]);

    return shareInfo;
}(_wepy2.default.page)) || _class);

Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(shareInfo , 'pages/home/share'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNoYXJlLmpzIl0sIm5hbWVzIjpbInNoYXJlSW5mbyIsInN0b3JlIiwiZ2V0IiwiY29uZmlnIiwibmF2aWdhdGlvbkJhclRpdGxlVGV4dCIsIm1ldGhvZHMiLCJzYXZlSW1nIiwiY29uc29sZSIsImxvZyIsIkxhbmciLCJkb3duSW1nIiwibG9hZEltYWdlUGF0aCIsImRhdGEiLCJfd2lkdGgiLCJfaGVpZ3RoIiwic3dpcGVySGVpZ2h0IiwiY2FudmFzVHlwZSIsImltYWdlVXJsIiwiY29kZVVybCIsImJnVXJsIiwiYXZhdCIsIm5hbWUiLCJsb2NhbEltYWdlVXJsIiwibG9jYWxDb2RlVXJsIiwibG9jYWxCZ1VybCIsImxvY2FsYXZhdFVybCIsIm9wdGlvbnMiLCJhdXRoIiwibG9naW4iLCJnZXRVbmxpbWl0ZWQiLCJwYWdlIiwicGF0aCIsInNjZW5lU3RyIiwiaWQiLCJyZXMiLCJxciIsInByb2ZpbGVQaG90byIsIiRhcHBseSIsImNyZWF0UXJjb2RlUGljdHVyZXMiLCJ3eCIsInNob3dMb2FkaW5nIiwidGl0bGUiLCJ0aGF0IiwiaW1nSGVpZ3RoIiwiaW1nVXJsIiwicXJjb2RlVXJsIiwiZ2V0SW1naW5mbyIsInVybEFyciIsIl90eXBlIiwiZ2V0SW1hZ2VJbmZvIiwic3JjIiwic3VjY2VzcyIsImNyZWF0ZU5ld0ltZyIsImZhaWwiLCJiZ194IiwiYmdfeSIsImJnX3ciLCJwYWdlV2lkdGgiLCJiZ19oIiwicGFnZUhlaWdodCIsImJnX3IiLCJjdHgiLCJjcmVhdGVDYW52YXNDb250ZXh0Iiwic2V0RmlsbFN0eWxlIiwiZmlsbFJlY3QiLCJkcmF3SW1hZ2UiLCJxclciLCJxckgiLCJxcl94IiwicXJfeSIsInNhdmUiLCJiZWdpblBhdGgiLCJhcmMiLCJNYXRoIiwiUEkiLCJjbGlwIiwicmVzdG9yZSIsInNldEZvbnRTaXplIiwiZmlsbFRleHQiLCJsZWZ0IiwidG9wIiwid2lkdGgiLCJoZWlnaHQiLCJmaWxsZXQiLCJ3Iiwic2V0TGluZVdpZHRoIiwic2V0U3Ryb2tlU3R5bGUiLCJtb3ZlVG8iLCJsaW5lVG8iLCJhcmNUbyIsInN0cm9rZSIsImNvdXJzZSIsImNvdXJzZVRpdHRsZSIsInByaWNlIiwiYWN0dWFsU2FsZXMiLCJ2aXJ0dWFsU2FsZXMiLCJtaW5pbXVtUHJpY2UiLCJkcmF3Iiwic2V0VGltZW91dCIsImNhbnZhc1RvVGVtcEZpbGVQYXRoIiwiY2FudmFzSWQiLCJ0ZW1wRmlsZVBhdGgiLCJoaWRlTG9hZGluZyIsIndlcHkiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7O0FBQ0k7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7Ozs7Ozs7Ozs7SUFNcUJBLFMsV0FIcEIsd0JBQVE7QUFDTEEsZUFBV0MsZ0JBQU1DLEdBQU4sQ0FBVSxXQUFWO0FBRE4sQ0FBUixDOzs7Ozs7Ozs7Ozs7OztnTUFJR0MsTSxHQUFTO0FBQ0xDLG9DQUF3QjtBQURuQixTLFFBR1RDLE8sR0FBVTtBQUNOO0FBQ0FDLG1CQUZNLHFCQUVJO0FBQ05DLHdCQUFRQyxHQUFSLENBQVksTUFBWjtBQUNBQywrQkFBS0MsT0FBTCxDQUFhLEtBQUtDLGFBQWxCO0FBQ0g7QUFMSyxTLFFBT1ZDLEksR0FBTztBQUNIO0FBQ0FDLG9CQUFRLEtBRkwsRUFFWTtBQUNmQyxxQkFBUyxLQUhOLEVBR2E7QUFDaEJDLDBCQUFjLEdBSlgsRUFJZ0I7QUFDbkJDLHdCQUFZLEtBTFQsRUFLZ0I7QUFDbkJMLDJCQUFlLEVBTlosRUFNZ0I7QUFDbkJNLHNCQUFVLDZGQVBQLEVBT3NHO0FBQ3pHQyxxQkFBUyw2RkFSTixFQVFxRztBQUN4R0MsbUJBQU8sdUJBVEo7QUFVSEMsa0JBQUssRUFWRjtBQVdIQyxrQkFBSyxFQVhGO0FBWUhDLDJCQUFlLEVBWlosRUFZZ0I7QUFDbkJDLDBCQUFjLEVBYlgsRUFhZTtBQUNsQkMsd0JBQVksRUFkVDtBQWVIQywwQkFBYztBQUVsQjs7O0FBakJPLFM7Ozs7OztpR0FvQk1DLE87Ozs7Ozs7dUNBQ0hDLGVBQUtDLEtBQUwsRTs7Ozt1Q0FDVXpCLGlCQUFPMEIsWUFBUCxDQUFvQjtBQUNoQ0MsMENBQU0sS0FBSzlCLFNBQUwsQ0FBZStCLElBRFc7QUFFaENDLDhDQUFVLEtBQUtoQyxTQUFMLENBQWVpQztBQUZPLGlDQUFwQixDOzs7QUFBWkMsbUM7O0FBSUoscUNBQUtoQixPQUFMLEdBQWVnQixJQUFJQyxFQUFuQjtBQUNBLHFDQUFLZixJQUFMLEdBQVljLElBQUlFLFlBQWhCO0FBQ0EscUNBQUtmLElBQUwsR0FBWWEsSUFBSWIsSUFBaEI7QUFDQSxxQ0FBS2dCLE1BQUw7QUFDQSxxQ0FBS0MsbUJBQUw7Ozs7Ozs7Ozs7Ozs7Ozs7QUFFSjs7Ozs4Q0FDc0I7QUFDbEJDLGVBQUdDLFdBQUgsQ0FBZTtBQUNYQyx1QkFBTztBQURJLGFBQWY7QUFHQTtBQUNBLGdCQUFJQyxPQUFPLElBQVg7QUFDQSxnQkFBSUMsWUFBWSxLQUFLNUIsWUFBckI7QUFDQSxnQkFBSTZCLFNBQVMsS0FBSzNCLFFBQWxCO0FBQ0EsZ0JBQUk0QixZQUFZLEtBQUszQixPQUFyQjtBQUNBd0IsaUJBQUtJLFVBQUwsQ0FBZ0IsQ0FBQ0YsTUFBRCxFQUFTQyxTQUFULEVBQW1CSCxLQUFLdEIsSUFBeEIsRUFBOEJzQixLQUFLdkIsS0FBbkMsQ0FBaEIsRUFBMkQsQ0FBM0Q7QUFDSDtBQUNEOzs7O21DQUNXNEIsTSxFQUFRQyxLLEVBQU87QUFDdEIsZ0JBQUlOLE9BQU8sSUFBWDtBQUNBSCxlQUFHVSxZQUFILENBQWdCO0FBQ1pDLHFCQUFLSCxPQUFPQyxLQUFQLENBRE87QUFFWkcsdUJBRlksbUJBRUpqQixHQUZJLEVBRUM7QUFDVDtBQUNBLHdCQUFJYyxVQUFVLENBQWQsRUFBaUI7QUFBRTtBQUNmTiw2QkFBS3BCLGFBQUwsR0FBcUJZLElBQUlILElBQXpCO0FBQ0FXLDZCQUFLSSxVQUFMLENBQWdCQyxNQUFoQixFQUF3QixDQUF4QjtBQUNILHFCQUhELE1BR08sSUFBSUMsU0FBUyxDQUFiLEVBQWdCO0FBQ25CTiw2QkFBS25CLFlBQUwsR0FBb0JXLElBQUlILElBQXhCO0FBQ0FXLDZCQUFLSSxVQUFMLENBQWdCQyxNQUFoQixFQUF3QixDQUF4QjtBQUNILHFCQUhNLE1BR0QsSUFBSUMsU0FBUyxDQUFiLEVBQWdCO0FBQ2xCTiw2QkFBS2pCLFlBQUwsR0FBb0JTLElBQUlILElBQXhCO0FBQ0FXLDZCQUFLSSxVQUFMLENBQWdCQyxNQUFoQixFQUF3QixDQUF4QjtBQUNILHFCQUhLLE1BR0M7QUFDSEwsNkJBQUtsQixVQUFMLEdBQWtCVSxJQUFJSCxJQUF0QjtBQUNBVyw2QkFBS1UsWUFBTDtBQUNIO0FBQ0osaUJBakJXO0FBa0JaQyxvQkFsQlksZ0JBa0JQbkIsR0FsQk8sRUFrQkY7QUFDTjtBQUNBM0IsNEJBQVFDLEdBQVIsQ0FBWSxPQUFaLEVBQXFCd0MsS0FBckIsRUFBNEJkLEdBQTVCO0FBQ0g7QUFyQlcsYUFBaEI7QUF1Qkg7QUFDRDs7Ozt1Q0FDZTtBQUNYLGdCQUFJUSxPQUFPLElBQVg7QUFDQTtBQUNBLGdCQUFJWSxPQUFPLEVBQVg7QUFDQTtBQUNBLGdCQUFJQyxPQUFPLEVBQVg7QUFDQTtBQUNBLGdCQUFJQyxPQUFPLEtBQUs1QyxJQUFMLENBQVU2QyxTQUFWLEdBQXNCLEdBQWpDO0FBQ0E7QUFDQSxnQkFBSUMsT0FBTyxLQUFLOUMsSUFBTCxDQUFVK0MsVUFBVixHQUF1QixJQUFsQztBQUNBO0FBQ0EsZ0JBQUlDLE9BQU8sQ0FBWDtBQUNBLGdCQUFJQyxNQUFNdEIsR0FBR3VCLG1CQUFILENBQXVCLFVBQXZCLENBQVY7QUFDQTtBQUNBRCxnQkFBSUUsWUFBSixDQUFpQixNQUFqQjtBQUNBRixnQkFBSUcsUUFBSixDQUFhLENBQWIsRUFBZ0IsQ0FBaEIsRUFBbUIsQ0FBbkIsRUFBc0IsQ0FBdEI7QUFDQTtBQUNBSCxnQkFBSUksU0FBSixDQUFjLEtBQUs5QyxLQUFuQixFQUEwQixDQUExQixFQUE2QixDQUE3QixFQUFnQyxHQUFoQyxFQUFxQyxHQUFyQztBQUNBO0FBQ0EsZ0JBQUkrQyxNQUFNLEVBQVYsQ0FuQlcsQ0FtQkc7QUFDZCxnQkFBSUMsTUFBTSxFQUFWLENBcEJXLENBb0JHO0FBQ2QsZ0JBQUlDLE9BQU8sRUFBWCxDQXJCVyxDQXFCSTtBQUNmLGdCQUFJQyxPQUFPLEVBQVgsQ0F0QlcsQ0FzQkk7QUFDZlIsZ0JBQUlTLElBQUo7QUFDQVQsZ0JBQUlVLFNBQUosR0F4QlcsQ0F3Qk07QUFDakI7QUFDQVYsZ0JBQUlXLEdBQUosQ0FBUU4sTUFBTSxDQUFOLEdBQVVFLElBQWxCLEVBQXdCRCxNQUFNLENBQU4sR0FBVUUsSUFBbEMsRUFBd0NILE1BQU0sQ0FBOUMsRUFBaUQsQ0FBakQsRUFBb0RPLEtBQUtDLEVBQUwsR0FBVSxDQUE5RCxFQUFpRSxLQUFqRTtBQUNBYixnQkFBSWMsSUFBSixHQTNCVyxDQTJCQztBQUNaZCxnQkFBSUksU0FBSixDQUFjLEtBQUt4QyxZQUFuQixFQUFpQzJDLElBQWpDLEVBQXVDQyxJQUF2QyxFQUE2Q0gsR0FBN0MsRUFBa0RDLEdBQWxEO0FBQ0E7QUFDQU4sZ0JBQUllLE9BQUo7QUFDQWYsZ0JBQUlnQixXQUFKLENBQWdCLEVBQWhCO0FBQ0FoQixnQkFBSUUsWUFBSixDQUFpQixNQUFqQjtBQUNBRixnQkFBSWlCLFFBQUosQ0FBYSxLQUFLekQsSUFBbEIsRUFBd0IsR0FBeEIsRUFBNkIsRUFBN0IsRUFBaUMsR0FBakM7QUFDQXdDLGdCQUFJZ0IsV0FBSixDQUFnQixFQUFoQjtBQUNBaEIsZ0JBQUlFLFlBQUosQ0FBaUIsTUFBakI7QUFDQUYsZ0JBQUlpQixRQUFKLENBQWEsZ0JBQWIsRUFBK0IsR0FBL0IsRUFBb0MsRUFBcEMsRUFBd0MsR0FBeEM7QUFDQTtBQUNBakIsZ0JBQUlVLFNBQUo7QUFDQVYsZ0JBQUlTLElBQUo7QUFDQSxnQkFBSVMsT0FBTyxFQUFYO0FBQUEsZ0JBQ0lDLE1BQU0sR0FEVjtBQUFBLGdCQUVJQyxRQUFRLEdBRlo7QUFBQSxnQkFHSUMsU0FBUyxHQUhiO0FBQUEsZ0JBSUlDLFNBQVMsQ0FKYjtBQUFBLGdCQUtJQyxJQUFJLENBTFI7QUFNQUwsbUJBQU9BLE9BQU8sQ0FBUCxHQUFXSyxDQUFsQjtBQUNBSixrQkFBTUEsTUFBTSxDQUFOLEdBQVVJLENBQWhCO0FBQ0FILG9CQUFRQSxRQUFRLENBQVIsR0FBWUcsQ0FBcEI7QUFDQUYscUJBQVNBLFNBQVMsQ0FBVCxHQUFhRSxDQUF0QjtBQUNBRCxxQkFBU0EsU0FBUyxDQUFULEdBQWFDLENBQXRCO0FBQ0F2QixnQkFBSXdCLFlBQUosQ0FBaUIsQ0FBakI7QUFDQXhCLGdCQUFJeUIsY0FBSixDQUFtQixTQUFuQjtBQUNBekIsZ0JBQUkwQixNQUFKLENBQVdSLE9BQU9JLE1BQWxCLEVBQTBCSCxHQUExQixFQXJEVyxDQXFEcUI7QUFDaENuQixnQkFBSTJCLE1BQUosQ0FBV1QsT0FBT0UsS0FBUCxHQUFlRSxNQUExQixFQUFrQ0gsR0FBbEMsRUF0RFcsQ0FzRDZCO0FBQ3hDbkIsZ0JBQUk0QixLQUFKLENBQVVWLE9BQU9FLEtBQWpCLEVBQXdCRCxHQUF4QixFQUE2QkQsT0FBT0UsS0FBcEMsRUFBMkNELE1BQU1HLE1BQWpELEVBQXlEQSxNQUF6RCxFQXZEVyxDQXVEdUQ7QUFDbEV0QixnQkFBSTJCLE1BQUosQ0FBV1QsT0FBT0UsS0FBbEIsRUFBeUJELE1BQU1FLE1BQU4sR0FBZUMsTUFBeEMsRUF4RFcsQ0F3RHNDO0FBQ2pEdEIsZ0JBQUk0QixLQUFKLENBQVVWLE9BQU9FLEtBQWpCLEVBQXdCRCxNQUFNRSxNQUE5QixFQUFzQ0gsT0FBT0UsS0FBUCxHQUFlRSxNQUFyRCxFQUE2REgsTUFBTUUsTUFBbkUsRUFBMkVDLE1BQTNFLEVBekRXLENBeUR5RTtBQUNwRnRCLGdCQUFJMkIsTUFBSixDQUFXVCxPQUFPSSxNQUFsQixFQUEwQkgsTUFBTUUsTUFBaEMsRUExRFcsQ0EwRDhCO0FBQ3pDckIsZ0JBQUk0QixLQUFKLENBQVVWLElBQVYsRUFBZ0JDLE1BQU1FLE1BQXRCLEVBQThCSCxJQUE5QixFQUFvQ0MsTUFBTUUsTUFBTixHQUFlQyxNQUFuRCxFQUEyREEsTUFBM0QsRUEzRFcsQ0EyRHlEO0FBQ3BFdEIsZ0JBQUkyQixNQUFKLENBQVdULElBQVgsRUFBaUJDLE1BQU1HLE1BQXZCLEVBNURXLENBNERxQjtBQUNoQ3RCLGdCQUFJNEIsS0FBSixDQUFVVixJQUFWLEVBQWdCQyxHQUFoQixFQUFxQkQsT0FBT0ksTUFBNUIsRUFBb0NILEdBQXBDLEVBQXlDRyxNQUF6QyxFQTdEVyxDQTZEdUM7QUFDbER0QixnQkFBSTZCLE1BQUosR0E5RFcsQ0E4REc7QUFDZDdCLGdCQUFJYyxJQUFKO0FBQ0FkLGdCQUFJSSxTQUFKLENBQWMsS0FBSzNDLGFBQW5CLEVBQWtDeUQsSUFBbEMsRUFBd0NDLEdBQXhDLEVBQTZDQyxLQUE3QyxFQUFvREMsTUFBcEQ7QUFDQXJCLGdCQUFJZSxPQUFKO0FBQ0E7QUFDQWYsZ0JBQUlnQixXQUFKLENBQWdCLEVBQWhCO0FBQ0FoQixnQkFBSUUsWUFBSixDQUFpQixNQUFqQjtBQUNBO0FBQ0FGLGdCQUFJaUIsUUFBSixDQUFhLEtBQUs5RSxTQUFMLENBQWUyRixNQUFmLENBQXNCQyxZQUFuQyxFQUFpRCxFQUFqRCxFQUFxRCxHQUFyRCxFQUEwRCxHQUExRDtBQUNBO0FBQ0EvQixnQkFBSWdCLFdBQUosQ0FBZ0IsRUFBaEI7QUFDQWhCLGdCQUFJRSxZQUFKLENBQWlCLE1BQWpCO0FBQ0FGLGdCQUFJaUIsUUFBSixDQUFhLE1BQWIsRUFBcUIsRUFBckIsRUFBeUIsR0FBekIsRUFBOEIsR0FBOUI7QUFDQWpCLGdCQUFJZ0IsV0FBSixDQUFnQixFQUFoQjtBQUNBaEIsZ0JBQUlFLFlBQUosQ0FBaUIsU0FBakI7QUFDQUYsZ0JBQUlpQixRQUFKLENBQWEsR0FBYixFQUFrQixHQUFsQixFQUF1QixHQUF2QixFQUE0QixHQUE1QjtBQUNBakIsZ0JBQUlnQixXQUFKLENBQWdCLEVBQWhCO0FBQ0FoQixnQkFBSUUsWUFBSixDQUFpQixTQUFqQjtBQUNBRixnQkFBSWlCLFFBQUosQ0FBYSxLQUFLOUUsU0FBTCxDQUFlMkYsTUFBZixDQUFzQkUsS0FBbkMsRUFBMEMsR0FBMUMsRUFBK0MsR0FBL0MsRUFBb0QsR0FBcEQ7QUFDQTtBQUNBaEMsZ0JBQUlnQixXQUFKLENBQWdCLEVBQWhCO0FBQ0FoQixnQkFBSUUsWUFBSixDQUFpQixNQUFqQjtBQUNBRixnQkFBSWlCLFFBQUosbUJBQWtCLEtBQUs5RSxTQUFMLENBQWUyRixNQUFmLENBQXNCRyxXQUF0QixHQUFvQyxLQUFLOUYsU0FBTCxDQUFlMkYsTUFBZixDQUFzQkksWUFBNUUsY0FBNkYsR0FBN0YsRUFBa0csR0FBbEcsRUFBdUcsR0FBdkc7QUFDQTtBQUNBbEMsZ0JBQUlnQixXQUFKLENBQWdCLEVBQWhCO0FBQ0FoQixnQkFBSUUsWUFBSixDQUFpQixNQUFqQjtBQUNBRixnQkFBSWlCLFFBQUosQ0FBYSxvQkFBYixFQUFtQyxFQUFuQyxFQUF1QyxHQUF2QyxFQUE0QyxHQUE1QztBQUNBakIsZ0JBQUlnQixXQUFKLENBQWdCLEVBQWhCO0FBQ0FoQixnQkFBSUUsWUFBSixDQUFpQixNQUFqQjtBQUNBRixnQkFBSWlCLFFBQUosQ0FBYSxLQUFiLEVBQW9CLEVBQXBCLEVBQXdCLEdBQXhCLEVBQTZCLEdBQTdCO0FBQ0FqQixnQkFBSWdCLFdBQUosQ0FBZ0IsRUFBaEI7QUFDQWhCLGdCQUFJRSxZQUFKLENBQWlCLFNBQWpCO0FBQ0FGLGdCQUFJaUIsUUFBSixDQUFnQixLQUFLOUUsU0FBTCxDQUFlMkYsTUFBZixDQUFzQkUsS0FBdEMsbUJBQWlELEdBQWpELEVBQXNELEdBQXRELEVBQTJELEdBQTNEO0FBQ0FoQyxnQkFBSWdCLFdBQUosQ0FBZ0IsRUFBaEI7QUFDQWhCLGdCQUFJRSxZQUFKLENBQWlCLE1BQWpCO0FBQ0FGLGdCQUFJaUIsUUFBSixDQUFhLEtBQWIsRUFBb0IsR0FBcEIsRUFBeUIsR0FBekIsRUFBOEIsR0FBOUI7QUFDQWpCLGdCQUFJZ0IsV0FBSixDQUFnQixFQUFoQjtBQUNBaEIsZ0JBQUlFLFlBQUosQ0FBaUIsU0FBakI7QUFDQUYsZ0JBQUlpQixRQUFKLENBQWdCLEtBQUs5RSxTQUFMLENBQWUyRixNQUFmLENBQXNCSyxZQUF0QyxtQkFBd0QsR0FBeEQsRUFBNkQsR0FBN0QsRUFBa0UsR0FBbEU7QUFDQW5DLGdCQUFJZ0IsV0FBSixDQUFnQixFQUFoQjtBQUNBaEIsZ0JBQUlFLFlBQUosQ0FBaUIsTUFBakI7QUFDQUYsZ0JBQUlpQixRQUFKLENBQWEsZUFBYixFQUE4QixFQUE5QixFQUFrQyxHQUFsQyxFQUF1QyxHQUF2QztBQUNBO0FBQ0FqQixnQkFBSUksU0FBSixDQUFjLEtBQUsxQyxZQUFuQixFQUFpQyxFQUFqQyxFQUFxQyxHQUFyQyxFQUEwQyxHQUExQyxFQUErQyxHQUEvQztBQUNBO0FBQ0FzQyxnQkFBSW9DLElBQUo7QUFDQTtBQUNBQyx1QkFBVyxZQUFXO0FBQ2xCM0QsbUJBQUc0RCxvQkFBSCxDQUF3QjtBQUNwQkMsOEJBQVUsVUFEVTtBQUVwQmpELDJCQUZvQixtQkFFWmpCLEdBRlksRUFFUDtBQUNULDRCQUFJbUUsZUFBZW5FLElBQUltRSxZQUF2QjtBQUNBM0QsNkJBQUsvQixhQUFMLEdBQXFCMEYsWUFBckI7QUFDQTNELDZCQUFLTCxNQUFMO0FBQ0gscUJBTm1CO0FBT3BCZ0Isd0JBUG9CLGdCQU9mbkIsR0FQZSxFQU9WO0FBQ04zQixnQ0FBUUMsR0FBUixDQUFZMEIsR0FBWjtBQUNIO0FBVG1CLGlCQUF4QjtBQVdILGFBWkQsRUFZRyxHQVpIO0FBYUE7QUFDQUssZUFBRytELFdBQUg7QUFDSDs7OztFQS9Na0NDLGVBQUt6RSxJO2tCQUF2QjlCLFMiLCJmaWxlIjoic2hhcmUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuICAgIGltcG9ydCB3ZXB5IGZyb20gXCJ3ZXB5XCI7XHJcbiAgICBpbXBvcnQgY29uZmlnIGZyb20gXCJAL2FwaS9jb25maWdcIlxyXG4gICAgaW1wb3J0IGF1dGggZnJvbSBcIkAvYXBpL2F1dGhcIlxyXG4gICAgaW1wb3J0IExhbmcgZnJvbSBcIkAvdXRpbHMvTGFuZ1wiXHJcbiAgICBpbXBvcnQgc3RvcmUgZnJvbSBcIkAvc3RvcmUvdXRpbHNcIlxyXG4gICAgaW1wb3J0IHtcclxuICAgICAgICBjb25uZWN0XHJcbiAgICB9IGZyb20gXCJ3ZXB5LXJlZHV4XCJcclxuICAgIEBjb25uZWN0KHtcclxuICAgICAgICBzaGFyZUluZm86IHN0b3JlLmdldChcInNoYXJlSW5mb1wiKVxyXG4gICAgfSlcclxuICAgIGV4cG9ydCBkZWZhdWx0IGNsYXNzIHNoYXJlSW5mbyBleHRlbmRzIHdlcHkucGFnZSB7XHJcbiAgICAgICAgY29uZmlnID0ge1xyXG4gICAgICAgICAgICBuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0OiBcIueUn+aIkOa1t+aKpVwiXHJcbiAgICAgICAgfTtcclxuICAgICAgICBtZXRob2RzID0ge1xyXG4gICAgICAgICAgICAvL+eCueWHu+S/neWtmOWIsOebuOWGjFxyXG4gICAgICAgICAgICBzYXZlSW1nKCkge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ2Rvd20nKVxyXG4gICAgICAgICAgICAgICAgTGFuZy5kb3duSW1nKHRoaXMubG9hZEltYWdlUGF0aCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9O1xyXG4gICAgICAgIGRhdGEgPSB7XHJcbiAgICAgICAgICAgIC8vIGNhbnZhcyBcclxuICAgICAgICAgICAgX3dpZHRoOiAnMzYwJywgLy/miYvmnLrlsY/lrr1cclxuICAgICAgICAgICAgX2hlaWd0aDogJzYzNycsIC8v5omL5py65bGP6auYXHJcbiAgICAgICAgICAgIHN3aXBlckhlaWdodDogMzAwLCAvL+S4u+WbvuWbvueJh+mrmOW6plxyXG4gICAgICAgICAgICBjYW52YXNUeXBlOiBmYWxzZSwgLy9jYW52YXPmmK/lkKbmmL7npLpcclxuICAgICAgICAgICAgbG9hZEltYWdlUGF0aDogJycsIC8v5LiL6L2955qE5Zu+54mHXHJcbiAgICAgICAgICAgIGltYWdlVXJsOiAnaHR0cHM6Ly9pbWFnZXMuaHhxeGx5LmNvbS9oeHFpbWFnZS9pbWFnZXMvMS9jb3Vyc2UvOTBhY2Y4ZTktNWYyZC00NmQ1LTgzNWUtYTI4OTFiODQyNjIxLmpwZycsIC8v5Li75Zu+572R57uc6Lev5b6EXHJcbiAgICAgICAgICAgIGNvZGVVcmw6ICdodHRwczovL2ltYWdlcy5oeHF4bHkuY29tL2h4cWltYWdlL2ltYWdlcy8xL2NvdXJzZS85MGFjZjhlOS01ZjJkLTQ2ZDUtODM1ZS1hMjg5MWI4NDI2MjEuanBnJywgLy/kuoznu7TnoIHnvZHnu5zot6/lvoRcclxuICAgICAgICAgICAgYmdVcmw6ICcvc3RhdGljL2ltYWdlcy9iZy5qcGcnLFxyXG4gICAgICAgICAgICBhdmF0OicnLFxyXG4gICAgICAgICAgICBuYW1lOicnLFxyXG4gICAgICAgICAgICBsb2NhbEltYWdlVXJsOiAnJywgLy/nu5jliLbnmoTllYblk4Hlm77niYfmnKzlnLDot6/lvoRcclxuICAgICAgICAgICAgbG9jYWxDb2RlVXJsOiAnJywgLy/nu5jliLbnmoTkuoznu7TnoIHlm77niYfmnKzlnLDot6/lvoRcclxuICAgICAgICAgICAgbG9jYWxCZ1VybDogJycsXHJcbiAgICAgICAgICAgIGxvY2FsYXZhdFVybDogJycsXHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8qKlxyXG4gICAgICAgICAqIOeUn+WRveWRqOacn+WHveaVsC0t55uR5ZCs6aG16Z2i5Yqg6L29XHJcbiAgICAgICAgICovXHJcbiAgICAgICAgYXN5bmMgb25Mb2FkKG9wdGlvbnMpIHtcclxuICAgICAgICAgICAgYXdhaXQgYXV0aC5sb2dpbigpXHJcbiAgICAgICAgICAgIGxldCByZXMgPSBhd2FpdCBjb25maWcuZ2V0VW5saW1pdGVkKHtcclxuICAgICAgICAgICAgICAgIHBhZ2U6IHRoaXMuc2hhcmVJbmZvLnBhdGgsXHJcbiAgICAgICAgICAgICAgICBzY2VuZVN0cjogdGhpcy5zaGFyZUluZm8uaWRcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgdGhpcy5jb2RlVXJsID0gcmVzLnFyXHJcbiAgICAgICAgICAgIHRoaXMuYXZhdCA9IHJlcy5wcm9maWxlUGhvdG9cclxuICAgICAgICAgICAgdGhpcy5uYW1lID0gcmVzLm5hbWVcclxuICAgICAgICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgICAgICAgICB0aGlzLmNyZWF0UXJjb2RlUGljdHVyZXMoKVxyXG4gICAgICAgIH1cclxuICAgICAgICAvKuaMieeUn+aIkOWbvueJh+aMiemSruaXtiovXHJcbiAgICAgICAgY3JlYXRRcmNvZGVQaWN0dXJlcygpIHtcclxuICAgICAgICAgICAgd3guc2hvd0xvYWRpbmcoe1xyXG4gICAgICAgICAgICAgICAgdGl0bGU6ICfmraPlnKjnu5jliLblm77niYcnLFxyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAvKuiOt+WPluaJi+acuuWuvemrmCovXHJcbiAgICAgICAgICAgIGxldCB0aGF0ID0gdGhpc1xyXG4gICAgICAgICAgICBsZXQgaW1nSGVpZ3RoID0gdGhpcy5zd2lwZXJIZWlnaHRcclxuICAgICAgICAgICAgbGV0IGltZ1VybCA9IHRoaXMuaW1hZ2VVcmxcclxuICAgICAgICAgICAgbGV0IHFyY29kZVVybCA9IHRoaXMuY29kZVVybFxyXG4gICAgICAgICAgICB0aGF0LmdldEltZ2luZm8oW2ltZ1VybCwgcXJjb2RlVXJsLHRoYXQuYXZhdCwgdGhhdC5iZ1VybF0sIDApO1xyXG4gICAgICAgIH1cclxuICAgICAgICAvLyDojrflj5blm77niYfkv6Hmga9cclxuICAgICAgICBnZXRJbWdpbmZvKHVybEFyciwgX3R5cGUpIHtcclxuICAgICAgICAgICAgbGV0IHRoYXQgPSB0aGlzO1xyXG4gICAgICAgICAgICB3eC5nZXRJbWFnZUluZm8oe1xyXG4gICAgICAgICAgICAgICAgc3JjOiB1cmxBcnJbX3R5cGVdLFxyXG4gICAgICAgICAgICAgICAgc3VjY2VzcyhyZXMpIHtcclxuICAgICAgICAgICAgICAgICAgICAvL3Jlcy5wYXRo5piv572R57uc5Zu+54mH55qE5pys5Zyw5Zyw5Z2AXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKF90eXBlID09PSAwKSB7IC8v5ZWG5ZOB5Zu+54mHXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoYXQubG9jYWxJbWFnZVVybCA9IHJlcy5wYXRoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoYXQuZ2V0SW1naW5mbyh1cmxBcnIsIDEpXHJcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChfdHlwZSA9PSAxKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoYXQubG9jYWxDb2RlVXJsID0gcmVzLnBhdGhcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhhdC5nZXRJbWdpbmZvKHVybEFyciwgMilcclxuICAgICAgICAgICAgICAgICAgICB9ZWxzZSBpZiAoX3R5cGUgPT0gMikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGF0LmxvY2FsYXZhdFVybCA9IHJlcy5wYXRoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoYXQuZ2V0SW1naW5mbyh1cmxBcnIsIDMpXHJcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhhdC5sb2NhbEJnVXJsID0gcmVzLnBhdGhcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhhdC5jcmVhdGVOZXdJbWcoKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgZmFpbChyZXMpIHtcclxuICAgICAgICAgICAgICAgICAgICAvL+Wksei0peWbnuiwg1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdGYWls77yaJywgX3R5cGUsIHJlcylcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8v57uY5Yi2Y2FudmFzXHJcbiAgICAgICAgY3JlYXRlTmV3SW1nKCkge1xyXG4gICAgICAgICAgICBsZXQgdGhhdCA9IHRoaXM7XHJcbiAgICAgICAgICAgIC8vIOWbvueJh+eahHjlnZDmoIdcclxuICAgICAgICAgICAgbGV0IGJnX3ggPSAxMFxyXG4gICAgICAgICAgICAvLyDlm77niYfnmoR55Z2Q5qCHXHJcbiAgICAgICAgICAgIGxldCBiZ195ID0gNzBcclxuICAgICAgICAgICAgLy8g5Zu+54mH5a695bqmXHJcbiAgICAgICAgICAgIGxldCBiZ193ID0gdGhpcy5kYXRhLnBhZ2VXaWR0aCAtIDExNlxyXG4gICAgICAgICAgICAvLyDlm77niYfpq5jluqZcclxuICAgICAgICAgICAgbGV0IGJnX2ggPSB0aGlzLmRhdGEucGFnZUhlaWdodCAqIDAuMzVcclxuICAgICAgICAgICAgLy8g5Zu+54mH5ZyG6KeSXHJcbiAgICAgICAgICAgIGxldCBiZ19yID0gNFxyXG4gICAgICAgICAgICBsZXQgY3R4ID0gd3guY3JlYXRlQ2FudmFzQ29udGV4dCgnbXljYW52YXMnKTtcclxuICAgICAgICAgICAgLy8g57uY5Yi26IOM5pmvXHJcbiAgICAgICAgICAgIGN0eC5zZXRGaWxsU3R5bGUoXCIjZmZmXCIpO1xyXG4gICAgICAgICAgICBjdHguZmlsbFJlY3QoMCwgMCwgMCwgMCk7XHJcbiAgICAgICAgICAgIC8v57uY5Yi26IOM5pmv5Zu+54mHXHJcbiAgICAgICAgICAgIGN0eC5kcmF3SW1hZ2UodGhpcy5iZ1VybCwgMCwgMCwgMzYwLCA2MzcpO1xyXG4gICAgICAgICAgICAvL+e7mOWItuWktOWDj1xyXG4gICAgICAgICAgICB2YXIgcXJXID0gNTA7IC8v57uY5Yi255qE5LqM57u056CB5a695bqmXHJcbiAgICAgICAgICAgIHZhciBxckggPSA1MDsgLy/nu5jliLbnmoTkuoznu7TnoIHpq5jluqZcclxuICAgICAgICAgICAgdmFyIHFyX3ggPSA0MDsgLy/nu5jliLbnmoTkuoznu7TnoIHlnKjnlLvluIPkuIrnmoTkvY3nva5cclxuICAgICAgICAgICAgdmFyIHFyX3kgPSA1MDsgLy/nu5jliLbnmoTkuoznu7TnoIHlnKjnlLvluIPkuIrnmoTkvY3nva5cclxuICAgICAgICAgICAgY3R4LnNhdmUoKTtcclxuICAgICAgICAgICAgY3R4LmJlZ2luUGF0aCgpOyAvL+W8gOWni+e7mOWItlxyXG4gICAgICAgICAgICAvL+WFiOeUu+S4quWchiAg5YmN5Lik5Liq5Y+C5pWw56Gu5a6a5LqG5ZyG5b+DIO+8iHgsee+8iSDlnZDmoIcg56ys5LiJ5Liq5Y+C5pWw5piv5ZyG55qE5Y2K5b6EIOWbm+WPguaVsOaYr+e7mOWbvuaWueWQkSDpu5jorqTmmK9mYWxzZe+8jOWNs+mhuuaXtumSiFxyXG4gICAgICAgICAgICBjdHguYXJjKHFyVyAvIDIgKyBxcl94LCBxckggLyAyICsgcXJfeSwgcXJXIC8gMiwgMCwgTWF0aC5QSSAqIDIsIGZhbHNlKTtcclxuICAgICAgICAgICAgY3R4LmNsaXAoKTsgLy/nlLvlpb3kuoblnIYg5Ymq5YiHIOWOn+Wni+eUu+W4g+S4reWJquWIh+S7u+aEj+W9oueKtuWSjOWwuuWvuOOAguS4gOaXpuWJquWIh+S6huafkOS4quWMuuWfn++8jOWImeaJgOacieS5i+WQjueahOe7mOWbvumDveS8muiiq+mZkOWItuWcqOiiq+WJquWIh+eahOWMuuWfn+WGhSDov5nkuZ/mmK/miJHku6zopoFzYXZl5LiK5LiL5paH55qE5Y6f5ZugXHJcbiAgICAgICAgICAgIGN0eC5kcmF3SW1hZ2UodGhpcy5sb2NhbGF2YXRVcmwsIHFyX3gsIHFyX3ksIHFyVywgcXJIKTtcclxuICAgICAgICAgICAgLy8g5oGi5aSN5LmL5YmN5L+d5a2Y55qE57uY5Zu+5LiK5LiL5paHXHJcbiAgICAgICAgICAgIGN0eC5yZXN0b3JlKClcclxuICAgICAgICAgICAgY3R4LnNldEZvbnRTaXplKDE2KTtcclxuICAgICAgICAgICAgY3R4LnNldEZpbGxTdHlsZSgnIzMzMycpO1xyXG4gICAgICAgICAgICBjdHguZmlsbFRleHQodGhpcy5uYW1lLCAxMDAsIDcwLCAyODApO1xyXG4gICAgICAgICAgICBjdHguc2V0Rm9udFNpemUoMTIpO1xyXG4gICAgICAgICAgICBjdHguc2V0RmlsbFN0eWxlKCcjOTk5Jyk7XHJcbiAgICAgICAgICAgIGN0eC5maWxsVGV4dCgn5oiQ6ZW/77yM5piv5oiR5Lus5pyA5YC85b6X54+N6JeP55qE6K6w5b+GJywgMTAwLCA5MCwgMjgwKTtcclxuICAgICAgICAgICAgLy8g57uY5Yi2YmFubmVyXHJcbiAgICAgICAgICAgIGN0eC5iZWdpblBhdGgoKTtcclxuICAgICAgICAgICAgY3R4LnNhdmUoKTtcclxuICAgICAgICAgICAgbGV0IGxlZnQgPSA0MCxcclxuICAgICAgICAgICAgICAgIHRvcCA9IDEyMCxcclxuICAgICAgICAgICAgICAgIHdpZHRoID0gMjgwLFxyXG4gICAgICAgICAgICAgICAgaGVpZ2h0ID0gMTQwLFxyXG4gICAgICAgICAgICAgICAgZmlsbGV0ID0gNixcclxuICAgICAgICAgICAgICAgIHcgPSAyXHJcbiAgICAgICAgICAgIGxlZnQgPSBsZWZ0IC8gMiAqIHc7XHJcbiAgICAgICAgICAgIHRvcCA9IHRvcCAvIDIgKiB3O1xyXG4gICAgICAgICAgICB3aWR0aCA9IHdpZHRoIC8gMiAqIHc7XHJcbiAgICAgICAgICAgIGhlaWdodCA9IGhlaWdodCAvIDIgKiB3O1xyXG4gICAgICAgICAgICBmaWxsZXQgPSBmaWxsZXQgLyAyICogdztcclxuICAgICAgICAgICAgY3R4LnNldExpbmVXaWR0aCgxKTtcclxuICAgICAgICAgICAgY3R4LnNldFN0cm9rZVN0eWxlKCcjZmZmZmZmJyk7XHJcbiAgICAgICAgICAgIGN0eC5tb3ZlVG8obGVmdCArIGZpbGxldCwgdG9wKTsgLy8g5Yib5bu65byA5aeL54K5XHJcbiAgICAgICAgICAgIGN0eC5saW5lVG8obGVmdCArIHdpZHRoIC0gZmlsbGV0LCB0b3ApOyAvLyDliJvlu7rmsLTlubPnur9cclxuICAgICAgICAgICAgY3R4LmFyY1RvKGxlZnQgKyB3aWR0aCwgdG9wLCBsZWZ0ICsgd2lkdGgsIHRvcCArIGZpbGxldCwgZmlsbGV0KTsgLy8g5Yib5bu65bynXHJcbiAgICAgICAgICAgIGN0eC5saW5lVG8obGVmdCArIHdpZHRoLCB0b3AgKyBoZWlnaHQgLSBmaWxsZXQpOyAvLyDliJvlu7rlnoLnm7Tnur9cclxuICAgICAgICAgICAgY3R4LmFyY1RvKGxlZnQgKyB3aWR0aCwgdG9wICsgaGVpZ2h0LCBsZWZ0ICsgd2lkdGggLSBmaWxsZXQsIHRvcCArIGhlaWdodCwgZmlsbGV0KTsgLy8g5Yib5bu65bynXHJcbiAgICAgICAgICAgIGN0eC5saW5lVG8obGVmdCArIGZpbGxldCwgdG9wICsgaGVpZ2h0KTsgLy8g5Yib5bu65rC05bmz57q/XHJcbiAgICAgICAgICAgIGN0eC5hcmNUbyhsZWZ0LCB0b3AgKyBoZWlnaHQsIGxlZnQsIHRvcCArIGhlaWdodCAtIGZpbGxldCwgZmlsbGV0KTsgLy8g5Yib5bu65bynXHJcbiAgICAgICAgICAgIGN0eC5saW5lVG8obGVmdCwgdG9wICsgZmlsbGV0KTsgLy8g5Yib5bu65Z6C55u057q/XHJcbiAgICAgICAgICAgIGN0eC5hcmNUbyhsZWZ0LCB0b3AsIGxlZnQgKyBmaWxsZXQsIHRvcCwgZmlsbGV0KTsgLy8g5Yib5bu65bynXHJcbiAgICAgICAgICAgIGN0eC5zdHJva2UoKTsgLy8g6L+Z5Liq5YW35L2T5bmy5LuA5LmI55So55qE77yfXHJcbiAgICAgICAgICAgIGN0eC5jbGlwKCk7XHJcbiAgICAgICAgICAgIGN0eC5kcmF3SW1hZ2UodGhpcy5sb2NhbEltYWdlVXJsLCBsZWZ0LCB0b3AsIHdpZHRoLCBoZWlnaHQpO1xyXG4gICAgICAgICAgICBjdHgucmVzdG9yZSgpO1xyXG4gICAgICAgICAgICAvLyAvLyDnu5jliLbmoIfpophcclxuICAgICAgICAgICAgY3R4LnNldEZvbnRTaXplKDEzKTtcclxuICAgICAgICAgICAgY3R4LnNldEZpbGxTdHlsZSgnIzMzMycpO1xyXG4gICAgICAgICAgICAvL+WVhuWTgeWQjeensFxyXG4gICAgICAgICAgICBjdHguZmlsbFRleHQodGhpcy5zaGFyZUluZm8uY291cnNlLmNvdXJzZVRpdHRsZSwgNDAsIDI5MCwgMjgwKTtcclxuICAgICAgICAgICAgLy8g57uY5Yi25Lu35qC85Y2V5L2NICfvv6UnXHJcbiAgICAgICAgICAgIGN0eC5zZXRGb250U2l6ZSgxNik7XHJcbiAgICAgICAgICAgIGN0eC5zZXRGaWxsU3R5bGUoJyMzMzMnKTtcclxuICAgICAgICAgICAgY3R4LmZpbGxUZXh0KCfmtLvliqjotLnvvJonLCA0MCwgMzE1LCAyODApO1xyXG4gICAgICAgICAgICBjdHguc2V0Rm9udFNpemUoMTIpO1xyXG4gICAgICAgICAgICBjdHguc2V0RmlsbFN0eWxlKCcjZmI4NjdmJyk7XHJcbiAgICAgICAgICAgIGN0eC5maWxsVGV4dCgn77+lJywgMTAwLCAzMTUsIDI4MCk7XHJcbiAgICAgICAgICAgIGN0eC5zZXRGb250U2l6ZSgxNik7XHJcbiAgICAgICAgICAgIGN0eC5zZXRGaWxsU3R5bGUoJyNmYjg2N2YnKTtcclxuICAgICAgICAgICAgY3R4LmZpbGxUZXh0KHRoaXMuc2hhcmVJbmZvLmNvdXJzZS5wcmljZSwgMTEwLCAzMTUsIDI4MCk7XHJcbiAgICAgICAgICAgIC8vIOe7mOWItuW3suWUrlxyXG4gICAgICAgICAgICBjdHguc2V0Rm9udFNpemUoMTMpO1xyXG4gICAgICAgICAgICBjdHguc2V0RmlsbFN0eWxlKCcjOTk5Jyk7XHJcbiAgICAgICAgICAgIGN0eC5maWxsVGV4dChg5bey5ZSuJHt0aGlzLnNoYXJlSW5mby5jb3Vyc2UuYWN0dWFsU2FsZXMgKyB0aGlzLnNoYXJlSW5mby5jb3Vyc2UudmlydHVhbFNhbGVzfeS6umAsIDI2MCwgMzE1LCAyODApO1xyXG4gICAgICAgICAgICAvLyDnu5jliLbor7fmsYLliqnliptcclxuICAgICAgICAgICAgY3R4LnNldEZvbnRTaXplKDE1KTtcclxuICAgICAgICAgICAgY3R4LnNldEZpbGxTdHlsZSgnIzk5OScpO1xyXG4gICAgICAgICAgICBjdHguZmlsbFRleHQoJ+aIkeato+WcqOWPguWKoOKAnOWNjuW/g+ahpeS9k+mqjOiQpeKAneeahOS/g+mUgOa0u+WKqCcsIDUwLCAzNzAsIDI4MCk7XHJcbiAgICAgICAgICAgIGN0eC5zZXRGb250U2l6ZSgxNSk7XHJcbiAgICAgICAgICAgIGN0eC5zZXRGaWxsU3R5bGUoJyM5OTknKTtcclxuICAgICAgICAgICAgY3R4LmZpbGxUZXh0KCfljp/ku7fvvJonLCA2MCwgMzk0LCAyODApO1xyXG4gICAgICAgICAgICBjdHguc2V0Rm9udFNpemUoMTUpO1xyXG4gICAgICAgICAgICBjdHguc2V0RmlsbFN0eWxlKCcjZmI4NjdmJyk7XHJcbiAgICAgICAgICAgIGN0eC5maWxsVGV4dChgJHt0aGlzLnNoYXJlSW5mby5jb3Vyc2UucHJpY2V95YWD77yMYCwgMTAwLCAzOTQsIDI4MCk7XHJcbiAgICAgICAgICAgIGN0eC5zZXRGb250U2l6ZSgxNSk7XHJcbiAgICAgICAgICAgIGN0eC5zZXRGaWxsU3R5bGUoJyM5OTknKTtcclxuICAgICAgICAgICAgY3R4LmZpbGxUZXh0KCfmnIDkvY7vvJonLCAxODAsIDM5NCwgMjgwKTtcclxuICAgICAgICAgICAgY3R4LnNldEZvbnRTaXplKDE1KTtcclxuICAgICAgICAgICAgY3R4LnNldEZpbGxTdHlsZSgnI2ZiODY3ZicpO1xyXG4gICAgICAgICAgICBjdHguZmlsbFRleHQoYCR7dGhpcy5zaGFyZUluZm8uY291cnNlLm1pbmltdW1QcmljZX3lhYPvvIxgLCAyMjAsIDM5NCwgMjgwKTtcclxuICAgICAgICAgICAgY3R4LnNldEZvbnRTaXplKDE1KTtcclxuICAgICAgICAgICAgY3R4LnNldEZpbGxTdHlsZSgnIzk5OScpO1xyXG4gICAgICAgICAgICBjdHguZmlsbFRleHQoJ+ivt+e7meaIkeeCueS4gOeCueWHuueCueWKm++8jOiwouiwou+8gScsIDgwLCA0MjAsIDI4MCk7XHJcbiAgICAgICAgICAgIC8vIC8vIOe7mOWItuWwj+eoi+W6j+WQjeensFxyXG4gICAgICAgICAgICBjdHguZHJhd0ltYWdlKHRoaXMubG9jYWxDb2RlVXJsLCA0MCwgNTAwLCAxMDAsIDEwMCk7XHJcbiAgICAgICAgICAgIC8vIOaYvuekuue7mOWItlxyXG4gICAgICAgICAgICBjdHguZHJhdygpO1xyXG4gICAgICAgICAgICAvL+WwhueUn+aIkOWlveeahOWbvueJh+S/neWtmOWIsOacrOWcsO+8jOmcgOimgeW7tui/n+S4gOS8mu+8jOe7mOWItuacn+mXtOiAl+aXtlxyXG4gICAgICAgICAgICBzZXRUaW1lb3V0KGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgd3guY2FudmFzVG9UZW1wRmlsZVBhdGgoe1xyXG4gICAgICAgICAgICAgICAgICAgIGNhbnZhc0lkOiAnbXljYW52YXMnLFxyXG4gICAgICAgICAgICAgICAgICAgIHN1Y2Nlc3MocmVzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciB0ZW1wRmlsZVBhdGggPSByZXMudGVtcEZpbGVQYXRoO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGF0LmxvYWRJbWFnZVBhdGggPSB0ZW1wRmlsZVBhdGhcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhhdC4kYXBwbHkoKVxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgZmFpbChyZXMpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2cocmVzKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfSwgNTAwKTtcclxuICAgICAgICAgICAgLy/lhbPpl63mj5DnpLpcclxuICAgICAgICAgICAgd3guaGlkZUxvYWRpbmcoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiJdfQ==