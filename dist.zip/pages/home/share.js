"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _dec, _class;

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

var _Lang = require('./../../utils/Lang.js');

var _Lang2 = _interopRequireDefault(_Lang);

var _utils = require('./../../store/utils.js');

var _utils2 = _interopRequireDefault(_utils);

var _wepyRedux = require('./../../npm/wepy-redux/lib/index.js');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var shareInfo = (_dec = (0, _wepyRedux.connect)({
    shareInfo: _utils2.default.get("shareInfo")
}), _dec(_class = function (_wepy$page) {
    _inherits(shareInfo, _wepy$page);

    function shareInfo() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, shareInfo);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = shareInfo.__proto__ || Object.getPrototypeOf(shareInfo)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
            navigationBarTitleText: "生成海报"
        }, _this.methods = {
            //点击保存到相册
            saveImg: function saveImg() {
                console.log('dowm');
                _Lang2.default.downImg(this.loadImagePath);
            }
        }, _this.data = {
            // canvas 
            _width: '360', //手机屏宽
            _heigth: '637', //手机屏高
            swiperHeight: 300, //主图图片高度
            canvasType: false, //canvas是否显示
            loadImagePath: '', //下载的图片
            imageUrl: 'https://images.hxqxly.com/hxqimage/images/1/course/90acf8e9-5f2d-46d5-835e-a2891b842621.jpg', //主图网络路径
            codeUrl: 'https://images.hxqxly.com/hxqimage/images/1/course/90acf8e9-5f2d-46d5-835e-a2891b842621.jpg', //二维码网络路径
            bgUrl: '/static/images/bg.jpg',
            avat: '',
            name: '',
            localImageUrl: '', //绘制的商品图片本地路径
            localCodeUrl: '', //绘制的二维码图片本地路径
            localBgUrl: '',
            localavatUrl: ''
            /**
             * 生命周期函数--监听页面加载
             */
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(shareInfo, [{
        key: "onLoad",
        value: function () {
            var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(options) {
                var res;
                return regeneratorRuntime.wrap(function _callee$(_context) {
                    while (1) {
                        switch (_context.prev = _context.next) {
                            case 0:
                                _context.next = 2;
                                return _auth2.default.login();

                            case 2:
                                _context.next = 4;
                                return _config2.default.getUnlimited({
                                    page: this.shareInfo.path,
                                    sceneStr: this.shareInfo.id
                                });

                            case 4:
                                res = _context.sent;

                                this.codeUrl = res.qr;
                                this.avat = res.profilePhoto;
                                this.imageUrl = this.shareInfo.course.image;
                                this.name = res.name;
                                this.$apply();
                                this.creatQrcodePictures();

                            case 11:
                            case "end":
                                return _context.stop();
                        }
                    }
                }, _callee, this);
            }));

            function onLoad(_x) {
                return _ref2.apply(this, arguments);
            }

            return onLoad;
        }()
        /*按生成图片按钮时*/

    }, {
        key: "creatQrcodePictures",
        value: function creatQrcodePictures() {
            wx.showLoading({
                title: '正在绘制图片'
            });
            /*获取手机宽高*/
            var that = this;
            var imgHeigth = this.swiperHeight;
            var imgUrl = this.imageUrl;
            var qrcodeUrl = this.codeUrl;
            that.getImginfo([imgUrl, qrcodeUrl, that.avat, that.bgUrl], 0);
        }
        // 获取图片信息

    }, {
        key: "getImginfo",
        value: function getImginfo(urlArr, _type) {
            var that = this;
            wx.getImageInfo({
                src: urlArr[_type],
                success: function success(res) {
                    //res.path是网络图片的本地地址
                    if (_type === 0) {
                        //商品图片
                        that.localImageUrl = res.path;
                        that.getImginfo(urlArr, 1);
                    } else if (_type == 1) {
                        that.localCodeUrl = res.path;
                        that.getImginfo(urlArr, 2);
                    } else if (_type == 2) {
                        that.localavatUrl = res.path;
                        that.getImginfo(urlArr, 3);
                    } else {
                        that.localBgUrl = res.path;
                        that.createNewImg();
                    }
                },
                fail: function fail(res) {
                    //失败回调
                    console.log('Fail：', _type, res);
                }
            });
        }
        //绘制canvas

    }, {
        key: "createNewImg",
        value: function createNewImg() {
            var that = this;
            // 图片的x坐标
            var bg_x = 10;
            // 图片的y坐标
            var bg_y = 70;
            // 图片宽度
            var bg_w = this.data.pageWidth - 116;
            // 图片高度
            var bg_h = this.data.pageHeight * 0.35;
            // 图片圆角
            var bg_r = 4;
            var ctx = wx.createCanvasContext('mycanvas');
            // 绘制背景
            ctx.setFillStyle("#fff");
            ctx.fillRect(0, 0, 0, 0);
            //绘制背景图片
            ctx.drawImage(this.bgUrl, 0, 0, 360, 637);
            //绘制头像
            var qrW = 50; //绘制的二维码宽度
            var qrH = 50; //绘制的二维码高度
            var qr_x = 40; //绘制的二维码在画布上的位置
            var qr_y = 50; //绘制的二维码在画布上的位置
            ctx.save();
            ctx.beginPath(); //开始绘制
            //先画个圆  前两个参数确定了圆心 （x,y） 坐标 第三个参数是圆的半径 四参数是绘图方向 默认是false，即顺时针
            ctx.arc(qrW / 2 + qr_x, qrH / 2 + qr_y, qrW / 2, 0, Math.PI * 2, false);
            ctx.clip(); //画好了圆 剪切 原始画布中剪切任意形状和尺寸。一旦剪切了某个区域，则所有之后的绘图都会被限制在被剪切的区域内 这也是我们要save上下文的原因
            ctx.drawImage(this.localavatUrl, qr_x, qr_y, qrW, qrH);
            // 恢复之前保存的绘图上下文
            ctx.restore();
            ctx.setFontSize(16);
            ctx.setFillStyle('#333');
            ctx.fillText(this.name, 100, 70, 280);
            ctx.setFontSize(12);
            ctx.setFillStyle('#999');
            ctx.fillText('成长，是我们最值得珍藏的记忆', 100, 90, 280);
            // 绘制banner
            ctx.beginPath();
            ctx.save();
            var left = 40,
                top = 120,
                width = 280,
                height = 140,
                fillet = 6,
                w = 2;
            left = left / 2 * w;
            top = top / 2 * w;
            width = width / 2 * w;
            height = height / 2 * w;
            fillet = fillet / 2 * w;
            ctx.setLineWidth(1);
            ctx.setStrokeStyle('#ffffff');
            ctx.moveTo(left + fillet, top); // 创建开始点
            ctx.lineTo(left + width - fillet, top); // 创建水平线
            ctx.arcTo(left + width, top, left + width, top + fillet, fillet); // 创建弧
            ctx.lineTo(left + width, top + height - fillet); // 创建垂直线
            ctx.arcTo(left + width, top + height, left + width - fillet, top + height, fillet); // 创建弧
            ctx.lineTo(left + fillet, top + height); // 创建水平线
            ctx.arcTo(left, top + height, left, top + height - fillet, fillet); // 创建弧
            ctx.lineTo(left, top + fillet); // 创建垂直线
            ctx.arcTo(left, top, left + fillet, top, fillet); // 创建弧
            ctx.stroke(); // 这个具体干什么用的？
            ctx.clip();
            ctx.drawImage(this.localImageUrl, left, top, width, height);
            ctx.restore();
            // // 绘制标题
            ctx.setFontSize(13);
            ctx.setFillStyle('#333');
            //商品名称
            ctx.fillText(this.shareInfo.course.courseTittle, 40, 290, 280);
            // 绘制价格单位 '￥'
            ctx.setFontSize(16);
            ctx.setFillStyle('#333');
            ctx.fillText('活动费：', 40, 315, 280);
            ctx.setFontSize(12);
            ctx.setFillStyle('#fb867f');
            ctx.fillText('￥', 100, 315, 280);
            ctx.setFontSize(16);
            ctx.setFillStyle('#fb867f');
            ctx.fillText(this.shareInfo.course.price, 110, 315, 280);
            // 绘制已售
            ctx.setFontSize(13);
            ctx.setFillStyle('#999');
            ctx.fillText("\u5DF2\u552E" + (this.shareInfo.course.actualSales + this.shareInfo.course.virtualSales) + "\u4EBA", 260, 315, 280);
            // 绘制请求助力
            ctx.setFontSize(15);
            ctx.setFillStyle('#999');
            ctx.fillText('我正在参加“雄鹰童行”的促销活动', 50, 370, 280);
            ctx.setFontSize(15);
            ctx.setFillStyle('#999');
            ctx.fillText('原价：', 60, 394, 280);
            ctx.setFontSize(15);
            ctx.setFillStyle('#fb867f');
            ctx.fillText(this.shareInfo.course.price + "\u5143\uFF0C", 100, 394, 280);
            ctx.setFontSize(15);
            ctx.setFillStyle('#999');
            ctx.fillText('最低：', 180, 394, 280);
            ctx.setFontSize(15);
            ctx.setFillStyle('#fb867f');
            ctx.fillText(this.shareInfo.course.minimumPrice + "\u5143\uFF0C", 220, 394, 280);
            ctx.setFontSize(15);
            ctx.setFillStyle('#999');
            ctx.fillText('请给我点一点出点力，谢谢！', 80, 420, 280);
            // // 绘制小程序名称
            ctx.drawImage(this.localCodeUrl, 40, 500, 100, 100);
            // 显示绘制
            ctx.draw();
            //将生成好的图片保存到本地，需要延迟一会，绘制期间耗时
            setTimeout(function () {
                wx.canvasToTempFilePath({
                    canvasId: 'mycanvas',
                    success: function success(res) {
                        var tempFilePath = res.tempFilePath;
                        that.loadImagePath = tempFilePath;
                        that.$apply();
                    },
                    fail: function fail(res) {
                        console.log(res);
                    }
                });
            }, 500);
            //关闭提示
            wx.hideLoading();
        }
    }]);

    return shareInfo;
}(_wepy2.default.page)) || _class);

Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(shareInfo , 'pages/home/share'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNoYXJlLmpzIl0sIm5hbWVzIjpbInNoYXJlSW5mbyIsInN0b3JlIiwiZ2V0IiwiY29uZmlnIiwibmF2aWdhdGlvbkJhclRpdGxlVGV4dCIsIm1ldGhvZHMiLCJzYXZlSW1nIiwiY29uc29sZSIsImxvZyIsIkxhbmciLCJkb3duSW1nIiwibG9hZEltYWdlUGF0aCIsImRhdGEiLCJfd2lkdGgiLCJfaGVpZ3RoIiwic3dpcGVySGVpZ2h0IiwiY2FudmFzVHlwZSIsImltYWdlVXJsIiwiY29kZVVybCIsImJnVXJsIiwiYXZhdCIsIm5hbWUiLCJsb2NhbEltYWdlVXJsIiwibG9jYWxDb2RlVXJsIiwibG9jYWxCZ1VybCIsImxvY2FsYXZhdFVybCIsIm9wdGlvbnMiLCJhdXRoIiwibG9naW4iLCJnZXRVbmxpbWl0ZWQiLCJwYWdlIiwicGF0aCIsInNjZW5lU3RyIiwiaWQiLCJyZXMiLCJxciIsInByb2ZpbGVQaG90byIsImNvdXJzZSIsImltYWdlIiwiJGFwcGx5IiwiY3JlYXRRcmNvZGVQaWN0dXJlcyIsInd4Iiwic2hvd0xvYWRpbmciLCJ0aXRsZSIsInRoYXQiLCJpbWdIZWlndGgiLCJpbWdVcmwiLCJxcmNvZGVVcmwiLCJnZXRJbWdpbmZvIiwidXJsQXJyIiwiX3R5cGUiLCJnZXRJbWFnZUluZm8iLCJzcmMiLCJzdWNjZXNzIiwiY3JlYXRlTmV3SW1nIiwiZmFpbCIsImJnX3giLCJiZ195IiwiYmdfdyIsInBhZ2VXaWR0aCIsImJnX2giLCJwYWdlSGVpZ2h0IiwiYmdfciIsImN0eCIsImNyZWF0ZUNhbnZhc0NvbnRleHQiLCJzZXRGaWxsU3R5bGUiLCJmaWxsUmVjdCIsImRyYXdJbWFnZSIsInFyVyIsInFySCIsInFyX3giLCJxcl95Iiwic2F2ZSIsImJlZ2luUGF0aCIsImFyYyIsIk1hdGgiLCJQSSIsImNsaXAiLCJyZXN0b3JlIiwic2V0Rm9udFNpemUiLCJmaWxsVGV4dCIsImxlZnQiLCJ0b3AiLCJ3aWR0aCIsImhlaWdodCIsImZpbGxldCIsInciLCJzZXRMaW5lV2lkdGgiLCJzZXRTdHJva2VTdHlsZSIsIm1vdmVUbyIsImxpbmVUbyIsImFyY1RvIiwic3Ryb2tlIiwiY291cnNlVGl0dGxlIiwicHJpY2UiLCJhY3R1YWxTYWxlcyIsInZpcnR1YWxTYWxlcyIsIm1pbmltdW1QcmljZSIsImRyYXciLCJzZXRUaW1lb3V0IiwiY2FudmFzVG9UZW1wRmlsZVBhdGgiLCJjYW52YXNJZCIsInRlbXBGaWxlUGF0aCIsImhpZGVMb2FkaW5nIiwid2VweSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7QUFDSTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7Ozs7Ozs7OztJQU1xQkEsUyxXQUhwQix3QkFBUTtBQUNMQSxlQUFXQyxnQkFBTUMsR0FBTixDQUFVLFdBQVY7QUFETixDQUFSLEM7Ozs7Ozs7Ozs7Ozs7O2dNQUlHQyxNLEdBQVM7QUFDTEMsb0NBQXdCO0FBRG5CLFMsUUFHVEMsTyxHQUFVO0FBQ047QUFDQUMsbUJBRk0scUJBRUk7QUFDTkMsd0JBQVFDLEdBQVIsQ0FBWSxNQUFaO0FBQ0FDLCtCQUFLQyxPQUFMLENBQWEsS0FBS0MsYUFBbEI7QUFDSDtBQUxLLFMsUUFPVkMsSSxHQUFPO0FBQ0g7QUFDQUMsb0JBQVEsS0FGTCxFQUVZO0FBQ2ZDLHFCQUFTLEtBSE4sRUFHYTtBQUNoQkMsMEJBQWMsR0FKWCxFQUlnQjtBQUNuQkMsd0JBQVksS0FMVCxFQUtnQjtBQUNuQkwsMkJBQWUsRUFOWixFQU1nQjtBQUNuQk0sc0JBQVUsNkZBUFAsRUFPc0c7QUFDekdDLHFCQUFTLDZGQVJOLEVBUXFHO0FBQ3hHQyxtQkFBTyx1QkFUSjtBQVVIQyxrQkFBSyxFQVZGO0FBV0hDLGtCQUFLLEVBWEY7QUFZSEMsMkJBQWUsRUFaWixFQVlnQjtBQUNuQkMsMEJBQWMsRUFiWCxFQWFlO0FBQ2xCQyx3QkFBWSxFQWRUO0FBZUhDLDBCQUFjO0FBRWxCOzs7QUFqQk8sUzs7Ozs7O2lHQW9CTUMsTzs7Ozs7Ozt1Q0FDSEMsZUFBS0MsS0FBTCxFOzs7O3VDQUNVekIsaUJBQU8wQixZQUFQLENBQW9CO0FBQ2hDQywwQ0FBTSxLQUFLOUIsU0FBTCxDQUFlK0IsSUFEVztBQUVoQ0MsOENBQVUsS0FBS2hDLFNBQUwsQ0FBZWlDO0FBRk8saUNBQXBCLEM7OztBQUFaQyxtQzs7QUFJSixxQ0FBS2hCLE9BQUwsR0FBZWdCLElBQUlDLEVBQW5CO0FBQ0EscUNBQUtmLElBQUwsR0FBWWMsSUFBSUUsWUFBaEI7QUFDQSxxQ0FBS25CLFFBQUwsR0FBZ0IsS0FBS2pCLFNBQUwsQ0FBZXFDLE1BQWYsQ0FBc0JDLEtBQXRDO0FBQ0EscUNBQUtqQixJQUFMLEdBQVlhLElBQUliLElBQWhCO0FBQ0EscUNBQUtrQixNQUFMO0FBQ0EscUNBQUtDLG1CQUFMOzs7Ozs7Ozs7Ozs7Ozs7O0FBRUo7Ozs7OENBQ3NCO0FBQ2xCQyxlQUFHQyxXQUFILENBQWU7QUFDWEMsdUJBQU87QUFESSxhQUFmO0FBR0E7QUFDQSxnQkFBSUMsT0FBTyxJQUFYO0FBQ0EsZ0JBQUlDLFlBQVksS0FBSzlCLFlBQXJCO0FBQ0EsZ0JBQUkrQixTQUFTLEtBQUs3QixRQUFsQjtBQUNBLGdCQUFJOEIsWUFBWSxLQUFLN0IsT0FBckI7QUFDQTBCLGlCQUFLSSxVQUFMLENBQWdCLENBQUNGLE1BQUQsRUFBU0MsU0FBVCxFQUFtQkgsS0FBS3hCLElBQXhCLEVBQThCd0IsS0FBS3pCLEtBQW5DLENBQWhCLEVBQTJELENBQTNEO0FBQ0g7QUFDRDs7OzttQ0FDVzhCLE0sRUFBUUMsSyxFQUFPO0FBQ3RCLGdCQUFJTixPQUFPLElBQVg7QUFDQUgsZUFBR1UsWUFBSCxDQUFnQjtBQUNaQyxxQkFBS0gsT0FBT0MsS0FBUCxDQURPO0FBRVpHLHVCQUZZLG1CQUVKbkIsR0FGSSxFQUVDO0FBQ1Q7QUFDQSx3QkFBSWdCLFVBQVUsQ0FBZCxFQUFpQjtBQUFFO0FBQ2ZOLDZCQUFLdEIsYUFBTCxHQUFxQlksSUFBSUgsSUFBekI7QUFDQWEsNkJBQUtJLFVBQUwsQ0FBZ0JDLE1BQWhCLEVBQXdCLENBQXhCO0FBQ0gscUJBSEQsTUFHTyxJQUFJQyxTQUFTLENBQWIsRUFBZ0I7QUFDbkJOLDZCQUFLckIsWUFBTCxHQUFvQlcsSUFBSUgsSUFBeEI7QUFDQWEsNkJBQUtJLFVBQUwsQ0FBZ0JDLE1BQWhCLEVBQXdCLENBQXhCO0FBQ0gscUJBSE0sTUFHRCxJQUFJQyxTQUFTLENBQWIsRUFBZ0I7QUFDbEJOLDZCQUFLbkIsWUFBTCxHQUFvQlMsSUFBSUgsSUFBeEI7QUFDQWEsNkJBQUtJLFVBQUwsQ0FBZ0JDLE1BQWhCLEVBQXdCLENBQXhCO0FBQ0gscUJBSEssTUFHQztBQUNITCw2QkFBS3BCLFVBQUwsR0FBa0JVLElBQUlILElBQXRCO0FBQ0FhLDZCQUFLVSxZQUFMO0FBQ0g7QUFDSixpQkFqQlc7QUFrQlpDLG9CQWxCWSxnQkFrQlByQixHQWxCTyxFQWtCRjtBQUNOO0FBQ0EzQiw0QkFBUUMsR0FBUixDQUFZLE9BQVosRUFBcUIwQyxLQUFyQixFQUE0QmhCLEdBQTVCO0FBQ0g7QUFyQlcsYUFBaEI7QUF1Qkg7QUFDRDs7Ozt1Q0FDZTtBQUNYLGdCQUFJVSxPQUFPLElBQVg7QUFDQTtBQUNBLGdCQUFJWSxPQUFPLEVBQVg7QUFDQTtBQUNBLGdCQUFJQyxPQUFPLEVBQVg7QUFDQTtBQUNBLGdCQUFJQyxPQUFPLEtBQUs5QyxJQUFMLENBQVUrQyxTQUFWLEdBQXNCLEdBQWpDO0FBQ0E7QUFDQSxnQkFBSUMsT0FBTyxLQUFLaEQsSUFBTCxDQUFVaUQsVUFBVixHQUF1QixJQUFsQztBQUNBO0FBQ0EsZ0JBQUlDLE9BQU8sQ0FBWDtBQUNBLGdCQUFJQyxNQUFNdEIsR0FBR3VCLG1CQUFILENBQXVCLFVBQXZCLENBQVY7QUFDQTtBQUNBRCxnQkFBSUUsWUFBSixDQUFpQixNQUFqQjtBQUNBRixnQkFBSUcsUUFBSixDQUFhLENBQWIsRUFBZ0IsQ0FBaEIsRUFBbUIsQ0FBbkIsRUFBc0IsQ0FBdEI7QUFDQTtBQUNBSCxnQkFBSUksU0FBSixDQUFjLEtBQUtoRCxLQUFuQixFQUEwQixDQUExQixFQUE2QixDQUE3QixFQUFnQyxHQUFoQyxFQUFxQyxHQUFyQztBQUNBO0FBQ0EsZ0JBQUlpRCxNQUFNLEVBQVYsQ0FuQlcsQ0FtQkc7QUFDZCxnQkFBSUMsTUFBTSxFQUFWLENBcEJXLENBb0JHO0FBQ2QsZ0JBQUlDLE9BQU8sRUFBWCxDQXJCVyxDQXFCSTtBQUNmLGdCQUFJQyxPQUFPLEVBQVgsQ0F0QlcsQ0FzQkk7QUFDZlIsZ0JBQUlTLElBQUo7QUFDQVQsZ0JBQUlVLFNBQUosR0F4QlcsQ0F3Qk07QUFDakI7QUFDQVYsZ0JBQUlXLEdBQUosQ0FBUU4sTUFBTSxDQUFOLEdBQVVFLElBQWxCLEVBQXdCRCxNQUFNLENBQU4sR0FBVUUsSUFBbEMsRUFBd0NILE1BQU0sQ0FBOUMsRUFBaUQsQ0FBakQsRUFBb0RPLEtBQUtDLEVBQUwsR0FBVSxDQUE5RCxFQUFpRSxLQUFqRTtBQUNBYixnQkFBSWMsSUFBSixHQTNCVyxDQTJCQztBQUNaZCxnQkFBSUksU0FBSixDQUFjLEtBQUsxQyxZQUFuQixFQUFpQzZDLElBQWpDLEVBQXVDQyxJQUF2QyxFQUE2Q0gsR0FBN0MsRUFBa0RDLEdBQWxEO0FBQ0E7QUFDQU4sZ0JBQUllLE9BQUo7QUFDQWYsZ0JBQUlnQixXQUFKLENBQWdCLEVBQWhCO0FBQ0FoQixnQkFBSUUsWUFBSixDQUFpQixNQUFqQjtBQUNBRixnQkFBSWlCLFFBQUosQ0FBYSxLQUFLM0QsSUFBbEIsRUFBd0IsR0FBeEIsRUFBNkIsRUFBN0IsRUFBaUMsR0FBakM7QUFDQTBDLGdCQUFJZ0IsV0FBSixDQUFnQixFQUFoQjtBQUNBaEIsZ0JBQUlFLFlBQUosQ0FBaUIsTUFBakI7QUFDQUYsZ0JBQUlpQixRQUFKLENBQWEsZ0JBQWIsRUFBK0IsR0FBL0IsRUFBb0MsRUFBcEMsRUFBd0MsR0FBeEM7QUFDQTtBQUNBakIsZ0JBQUlVLFNBQUo7QUFDQVYsZ0JBQUlTLElBQUo7QUFDQSxnQkFBSVMsT0FBTyxFQUFYO0FBQUEsZ0JBQ0lDLE1BQU0sR0FEVjtBQUFBLGdCQUVJQyxRQUFRLEdBRlo7QUFBQSxnQkFHSUMsU0FBUyxHQUhiO0FBQUEsZ0JBSUlDLFNBQVMsQ0FKYjtBQUFBLGdCQUtJQyxJQUFJLENBTFI7QUFNQUwsbUJBQU9BLE9BQU8sQ0FBUCxHQUFXSyxDQUFsQjtBQUNBSixrQkFBTUEsTUFBTSxDQUFOLEdBQVVJLENBQWhCO0FBQ0FILG9CQUFRQSxRQUFRLENBQVIsR0FBWUcsQ0FBcEI7QUFDQUYscUJBQVNBLFNBQVMsQ0FBVCxHQUFhRSxDQUF0QjtBQUNBRCxxQkFBU0EsU0FBUyxDQUFULEdBQWFDLENBQXRCO0FBQ0F2QixnQkFBSXdCLFlBQUosQ0FBaUIsQ0FBakI7QUFDQXhCLGdCQUFJeUIsY0FBSixDQUFtQixTQUFuQjtBQUNBekIsZ0JBQUkwQixNQUFKLENBQVdSLE9BQU9JLE1BQWxCLEVBQTBCSCxHQUExQixFQXJEVyxDQXFEcUI7QUFDaENuQixnQkFBSTJCLE1BQUosQ0FBV1QsT0FBT0UsS0FBUCxHQUFlRSxNQUExQixFQUFrQ0gsR0FBbEMsRUF0RFcsQ0FzRDZCO0FBQ3hDbkIsZ0JBQUk0QixLQUFKLENBQVVWLE9BQU9FLEtBQWpCLEVBQXdCRCxHQUF4QixFQUE2QkQsT0FBT0UsS0FBcEMsRUFBMkNELE1BQU1HLE1BQWpELEVBQXlEQSxNQUF6RCxFQXZEVyxDQXVEdUQ7QUFDbEV0QixnQkFBSTJCLE1BQUosQ0FBV1QsT0FBT0UsS0FBbEIsRUFBeUJELE1BQU1FLE1BQU4sR0FBZUMsTUFBeEMsRUF4RFcsQ0F3RHNDO0FBQ2pEdEIsZ0JBQUk0QixLQUFKLENBQVVWLE9BQU9FLEtBQWpCLEVBQXdCRCxNQUFNRSxNQUE5QixFQUFzQ0gsT0FBT0UsS0FBUCxHQUFlRSxNQUFyRCxFQUE2REgsTUFBTUUsTUFBbkUsRUFBMkVDLE1BQTNFLEVBekRXLENBeUR5RTtBQUNwRnRCLGdCQUFJMkIsTUFBSixDQUFXVCxPQUFPSSxNQUFsQixFQUEwQkgsTUFBTUUsTUFBaEMsRUExRFcsQ0EwRDhCO0FBQ3pDckIsZ0JBQUk0QixLQUFKLENBQVVWLElBQVYsRUFBZ0JDLE1BQU1FLE1BQXRCLEVBQThCSCxJQUE5QixFQUFvQ0MsTUFBTUUsTUFBTixHQUFlQyxNQUFuRCxFQUEyREEsTUFBM0QsRUEzRFcsQ0EyRHlEO0FBQ3BFdEIsZ0JBQUkyQixNQUFKLENBQVdULElBQVgsRUFBaUJDLE1BQU1HLE1BQXZCLEVBNURXLENBNERxQjtBQUNoQ3RCLGdCQUFJNEIsS0FBSixDQUFVVixJQUFWLEVBQWdCQyxHQUFoQixFQUFxQkQsT0FBT0ksTUFBNUIsRUFBb0NILEdBQXBDLEVBQXlDRyxNQUF6QyxFQTdEVyxDQTZEdUM7QUFDbER0QixnQkFBSTZCLE1BQUosR0E5RFcsQ0E4REc7QUFDZDdCLGdCQUFJYyxJQUFKO0FBQ0FkLGdCQUFJSSxTQUFKLENBQWMsS0FBSzdDLGFBQW5CLEVBQWtDMkQsSUFBbEMsRUFBd0NDLEdBQXhDLEVBQTZDQyxLQUE3QyxFQUFvREMsTUFBcEQ7QUFDQXJCLGdCQUFJZSxPQUFKO0FBQ0E7QUFDQWYsZ0JBQUlnQixXQUFKLENBQWdCLEVBQWhCO0FBQ0FoQixnQkFBSUUsWUFBSixDQUFpQixNQUFqQjtBQUNBO0FBQ0FGLGdCQUFJaUIsUUFBSixDQUFhLEtBQUtoRixTQUFMLENBQWVxQyxNQUFmLENBQXNCd0QsWUFBbkMsRUFBaUQsRUFBakQsRUFBcUQsR0FBckQsRUFBMEQsR0FBMUQ7QUFDQTtBQUNBOUIsZ0JBQUlnQixXQUFKLENBQWdCLEVBQWhCO0FBQ0FoQixnQkFBSUUsWUFBSixDQUFpQixNQUFqQjtBQUNBRixnQkFBSWlCLFFBQUosQ0FBYSxNQUFiLEVBQXFCLEVBQXJCLEVBQXlCLEdBQXpCLEVBQThCLEdBQTlCO0FBQ0FqQixnQkFBSWdCLFdBQUosQ0FBZ0IsRUFBaEI7QUFDQWhCLGdCQUFJRSxZQUFKLENBQWlCLFNBQWpCO0FBQ0FGLGdCQUFJaUIsUUFBSixDQUFhLEdBQWIsRUFBa0IsR0FBbEIsRUFBdUIsR0FBdkIsRUFBNEIsR0FBNUI7QUFDQWpCLGdCQUFJZ0IsV0FBSixDQUFnQixFQUFoQjtBQUNBaEIsZ0JBQUlFLFlBQUosQ0FBaUIsU0FBakI7QUFDQUYsZ0JBQUlpQixRQUFKLENBQWEsS0FBS2hGLFNBQUwsQ0FBZXFDLE1BQWYsQ0FBc0J5RCxLQUFuQyxFQUEwQyxHQUExQyxFQUErQyxHQUEvQyxFQUFvRCxHQUFwRDtBQUNBO0FBQ0EvQixnQkFBSWdCLFdBQUosQ0FBZ0IsRUFBaEI7QUFDQWhCLGdCQUFJRSxZQUFKLENBQWlCLE1BQWpCO0FBQ0FGLGdCQUFJaUIsUUFBSixtQkFBa0IsS0FBS2hGLFNBQUwsQ0FBZXFDLE1BQWYsQ0FBc0IwRCxXQUF0QixHQUFvQyxLQUFLL0YsU0FBTCxDQUFlcUMsTUFBZixDQUFzQjJELFlBQTVFLGNBQTZGLEdBQTdGLEVBQWtHLEdBQWxHLEVBQXVHLEdBQXZHO0FBQ0E7QUFDQWpDLGdCQUFJZ0IsV0FBSixDQUFnQixFQUFoQjtBQUNBaEIsZ0JBQUlFLFlBQUosQ0FBaUIsTUFBakI7QUFDQUYsZ0JBQUlpQixRQUFKLENBQWEsa0JBQWIsRUFBaUMsRUFBakMsRUFBcUMsR0FBckMsRUFBMEMsR0FBMUM7QUFDQWpCLGdCQUFJZ0IsV0FBSixDQUFnQixFQUFoQjtBQUNBaEIsZ0JBQUlFLFlBQUosQ0FBaUIsTUFBakI7QUFDQUYsZ0JBQUlpQixRQUFKLENBQWEsS0FBYixFQUFvQixFQUFwQixFQUF3QixHQUF4QixFQUE2QixHQUE3QjtBQUNBakIsZ0JBQUlnQixXQUFKLENBQWdCLEVBQWhCO0FBQ0FoQixnQkFBSUUsWUFBSixDQUFpQixTQUFqQjtBQUNBRixnQkFBSWlCLFFBQUosQ0FBZ0IsS0FBS2hGLFNBQUwsQ0FBZXFDLE1BQWYsQ0FBc0J5RCxLQUF0QyxtQkFBaUQsR0FBakQsRUFBc0QsR0FBdEQsRUFBMkQsR0FBM0Q7QUFDQS9CLGdCQUFJZ0IsV0FBSixDQUFnQixFQUFoQjtBQUNBaEIsZ0JBQUlFLFlBQUosQ0FBaUIsTUFBakI7QUFDQUYsZ0JBQUlpQixRQUFKLENBQWEsS0FBYixFQUFvQixHQUFwQixFQUF5QixHQUF6QixFQUE4QixHQUE5QjtBQUNBakIsZ0JBQUlnQixXQUFKLENBQWdCLEVBQWhCO0FBQ0FoQixnQkFBSUUsWUFBSixDQUFpQixTQUFqQjtBQUNBRixnQkFBSWlCLFFBQUosQ0FBZ0IsS0FBS2hGLFNBQUwsQ0FBZXFDLE1BQWYsQ0FBc0I0RCxZQUF0QyxtQkFBd0QsR0FBeEQsRUFBNkQsR0FBN0QsRUFBa0UsR0FBbEU7QUFDQWxDLGdCQUFJZ0IsV0FBSixDQUFnQixFQUFoQjtBQUNBaEIsZ0JBQUlFLFlBQUosQ0FBaUIsTUFBakI7QUFDQUYsZ0JBQUlpQixRQUFKLENBQWEsZUFBYixFQUE4QixFQUE5QixFQUFrQyxHQUFsQyxFQUF1QyxHQUF2QztBQUNBO0FBQ0FqQixnQkFBSUksU0FBSixDQUFjLEtBQUs1QyxZQUFuQixFQUFpQyxFQUFqQyxFQUFxQyxHQUFyQyxFQUEwQyxHQUExQyxFQUErQyxHQUEvQztBQUNBO0FBQ0F3QyxnQkFBSW1DLElBQUo7QUFDQTtBQUNBQyx1QkFBVyxZQUFXO0FBQ2xCMUQsbUJBQUcyRCxvQkFBSCxDQUF3QjtBQUNwQkMsOEJBQVUsVUFEVTtBQUVwQmhELDJCQUZvQixtQkFFWm5CLEdBRlksRUFFUDtBQUNULDRCQUFJb0UsZUFBZXBFLElBQUlvRSxZQUF2QjtBQUNBMUQsNkJBQUtqQyxhQUFMLEdBQXFCMkYsWUFBckI7QUFDQTFELDZCQUFLTCxNQUFMO0FBQ0gscUJBTm1CO0FBT3BCZ0Isd0JBUG9CLGdCQU9mckIsR0FQZSxFQU9WO0FBQ04zQixnQ0FBUUMsR0FBUixDQUFZMEIsR0FBWjtBQUNIO0FBVG1CLGlCQUF4QjtBQVdILGFBWkQsRUFZRyxHQVpIO0FBYUE7QUFDQU8sZUFBRzhELFdBQUg7QUFDSDs7OztFQWhOa0NDLGVBQUsxRSxJO2tCQUF2QjlCLFMiLCJmaWxlIjoic2hhcmUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuICAgIGltcG9ydCB3ZXB5IGZyb20gXCJ3ZXB5XCI7XHJcbiAgICBpbXBvcnQgY29uZmlnIGZyb20gXCJAL2FwaS9jb25maWdcIlxyXG4gICAgaW1wb3J0IGF1dGggZnJvbSBcIkAvYXBpL2F1dGhcIlxyXG4gICAgaW1wb3J0IExhbmcgZnJvbSBcIkAvdXRpbHMvTGFuZ1wiXHJcbiAgICBpbXBvcnQgc3RvcmUgZnJvbSBcIkAvc3RvcmUvdXRpbHNcIlxyXG4gICAgaW1wb3J0IHtcclxuICAgICAgICBjb25uZWN0XHJcbiAgICB9IGZyb20gXCJ3ZXB5LXJlZHV4XCJcclxuICAgIEBjb25uZWN0KHtcclxuICAgICAgICBzaGFyZUluZm86IHN0b3JlLmdldChcInNoYXJlSW5mb1wiKVxyXG4gICAgfSlcclxuICAgIGV4cG9ydCBkZWZhdWx0IGNsYXNzIHNoYXJlSW5mbyBleHRlbmRzIHdlcHkucGFnZSB7XHJcbiAgICAgICAgY29uZmlnID0ge1xyXG4gICAgICAgICAgICBuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0OiBcIueUn+aIkOa1t+aKpVwiXHJcbiAgICAgICAgfTtcclxuICAgICAgICBtZXRob2RzID0ge1xyXG4gICAgICAgICAgICAvL+eCueWHu+S/neWtmOWIsOebuOWGjFxyXG4gICAgICAgICAgICBzYXZlSW1nKCkge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ2Rvd20nKVxyXG4gICAgICAgICAgICAgICAgTGFuZy5kb3duSW1nKHRoaXMubG9hZEltYWdlUGF0aCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9O1xyXG4gICAgICAgIGRhdGEgPSB7XHJcbiAgICAgICAgICAgIC8vIGNhbnZhcyBcclxuICAgICAgICAgICAgX3dpZHRoOiAnMzYwJywgLy/miYvmnLrlsY/lrr1cclxuICAgICAgICAgICAgX2hlaWd0aDogJzYzNycsIC8v5omL5py65bGP6auYXHJcbiAgICAgICAgICAgIHN3aXBlckhlaWdodDogMzAwLCAvL+S4u+WbvuWbvueJh+mrmOW6plxyXG4gICAgICAgICAgICBjYW52YXNUeXBlOiBmYWxzZSwgLy9jYW52YXPmmK/lkKbmmL7npLpcclxuICAgICAgICAgICAgbG9hZEltYWdlUGF0aDogJycsIC8v5LiL6L2955qE5Zu+54mHXHJcbiAgICAgICAgICAgIGltYWdlVXJsOiAnaHR0cHM6Ly9pbWFnZXMuaHhxeGx5LmNvbS9oeHFpbWFnZS9pbWFnZXMvMS9jb3Vyc2UvOTBhY2Y4ZTktNWYyZC00NmQ1LTgzNWUtYTI4OTFiODQyNjIxLmpwZycsIC8v5Li75Zu+572R57uc6Lev5b6EXHJcbiAgICAgICAgICAgIGNvZGVVcmw6ICdodHRwczovL2ltYWdlcy5oeHF4bHkuY29tL2h4cWltYWdlL2ltYWdlcy8xL2NvdXJzZS85MGFjZjhlOS01ZjJkLTQ2ZDUtODM1ZS1hMjg5MWI4NDI2MjEuanBnJywgLy/kuoznu7TnoIHnvZHnu5zot6/lvoRcclxuICAgICAgICAgICAgYmdVcmw6ICcvc3RhdGljL2ltYWdlcy9iZy5qcGcnLFxyXG4gICAgICAgICAgICBhdmF0OicnLFxyXG4gICAgICAgICAgICBuYW1lOicnLFxyXG4gICAgICAgICAgICBsb2NhbEltYWdlVXJsOiAnJywgLy/nu5jliLbnmoTllYblk4Hlm77niYfmnKzlnLDot6/lvoRcclxuICAgICAgICAgICAgbG9jYWxDb2RlVXJsOiAnJywgLy/nu5jliLbnmoTkuoznu7TnoIHlm77niYfmnKzlnLDot6/lvoRcclxuICAgICAgICAgICAgbG9jYWxCZ1VybDogJycsXHJcbiAgICAgICAgICAgIGxvY2FsYXZhdFVybDogJycsXHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8qKlxyXG4gICAgICAgICAqIOeUn+WRveWRqOacn+WHveaVsC0t55uR5ZCs6aG16Z2i5Yqg6L29XHJcbiAgICAgICAgICovXHJcbiAgICAgICAgYXN5bmMgb25Mb2FkKG9wdGlvbnMpIHtcclxuICAgICAgICAgICAgYXdhaXQgYXV0aC5sb2dpbigpXHJcbiAgICAgICAgICAgIGxldCByZXMgPSBhd2FpdCBjb25maWcuZ2V0VW5saW1pdGVkKHtcclxuICAgICAgICAgICAgICAgIHBhZ2U6IHRoaXMuc2hhcmVJbmZvLnBhdGgsXHJcbiAgICAgICAgICAgICAgICBzY2VuZVN0cjogdGhpcy5zaGFyZUluZm8uaWRcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgdGhpcy5jb2RlVXJsID0gcmVzLnFyXHJcbiAgICAgICAgICAgIHRoaXMuYXZhdCA9IHJlcy5wcm9maWxlUGhvdG9cclxuICAgICAgICAgICAgdGhpcy5pbWFnZVVybCA9IHRoaXMuc2hhcmVJbmZvLmNvdXJzZS5pbWFnZVxyXG4gICAgICAgICAgICB0aGlzLm5hbWUgPSByZXMubmFtZVxyXG4gICAgICAgICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICAgICAgICAgIHRoaXMuY3JlYXRRcmNvZGVQaWN0dXJlcygpXHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8q5oyJ55Sf5oiQ5Zu+54mH5oyJ6ZKu5pe2Ki9cclxuICAgICAgICBjcmVhdFFyY29kZVBpY3R1cmVzKCkge1xyXG4gICAgICAgICAgICB3eC5zaG93TG9hZGluZyh7XHJcbiAgICAgICAgICAgICAgICB0aXRsZTogJ+ato+WcqOe7mOWItuWbvueJhycsXHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIC8q6I635Y+W5omL5py65a696auYKi9cclxuICAgICAgICAgICAgbGV0IHRoYXQgPSB0aGlzXHJcbiAgICAgICAgICAgIGxldCBpbWdIZWlndGggPSB0aGlzLnN3aXBlckhlaWdodFxyXG4gICAgICAgICAgICBsZXQgaW1nVXJsID0gdGhpcy5pbWFnZVVybFxyXG4gICAgICAgICAgICBsZXQgcXJjb2RlVXJsID0gdGhpcy5jb2RlVXJsXHJcbiAgICAgICAgICAgIHRoYXQuZ2V0SW1naW5mbyhbaW1nVXJsLCBxcmNvZGVVcmwsdGhhdC5hdmF0LCB0aGF0LmJnVXJsXSwgMCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vIOiOt+WPluWbvueJh+S/oeaBr1xyXG4gICAgICAgIGdldEltZ2luZm8odXJsQXJyLCBfdHlwZSkge1xyXG4gICAgICAgICAgICBsZXQgdGhhdCA9IHRoaXM7XHJcbiAgICAgICAgICAgIHd4LmdldEltYWdlSW5mbyh7XHJcbiAgICAgICAgICAgICAgICBzcmM6IHVybEFycltfdHlwZV0sXHJcbiAgICAgICAgICAgICAgICBzdWNjZXNzKHJlcykge1xyXG4gICAgICAgICAgICAgICAgICAgIC8vcmVzLnBhdGjmmK/nvZHnu5zlm77niYfnmoTmnKzlnLDlnLDlnYBcclxuICAgICAgICAgICAgICAgICAgICBpZiAoX3R5cGUgPT09IDApIHsgLy/llYblk4Hlm77niYdcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhhdC5sb2NhbEltYWdlVXJsID0gcmVzLnBhdGhcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhhdC5nZXRJbWdpbmZvKHVybEFyciwgMSlcclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKF90eXBlID09IDEpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhhdC5sb2NhbENvZGVVcmwgPSByZXMucGF0aFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGF0LmdldEltZ2luZm8odXJsQXJyLCAyKVxyXG4gICAgICAgICAgICAgICAgICAgIH1lbHNlIGlmIChfdHlwZSA9PSAyKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoYXQubG9jYWxhdmF0VXJsID0gcmVzLnBhdGhcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhhdC5nZXRJbWdpbmZvKHVybEFyciwgMylcclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGF0LmxvY2FsQmdVcmwgPSByZXMucGF0aFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGF0LmNyZWF0ZU5ld0ltZygpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICBmYWlsKHJlcykge1xyXG4gICAgICAgICAgICAgICAgICAgIC8v5aSx6LSl5Zue6LCDXHJcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ0ZhaWzvvJonLCBfdHlwZSwgcmVzKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgLy/nu5jliLZjYW52YXNcclxuICAgICAgICBjcmVhdGVOZXdJbWcoKSB7XHJcbiAgICAgICAgICAgIGxldCB0aGF0ID0gdGhpcztcclxuICAgICAgICAgICAgLy8g5Zu+54mH55qEeOWdkOagh1xyXG4gICAgICAgICAgICBsZXQgYmdfeCA9IDEwXHJcbiAgICAgICAgICAgIC8vIOWbvueJh+eahHnlnZDmoIdcclxuICAgICAgICAgICAgbGV0IGJnX3kgPSA3MFxyXG4gICAgICAgICAgICAvLyDlm77niYflrr3luqZcclxuICAgICAgICAgICAgbGV0IGJnX3cgPSB0aGlzLmRhdGEucGFnZVdpZHRoIC0gMTE2XHJcbiAgICAgICAgICAgIC8vIOWbvueJh+mrmOW6plxyXG4gICAgICAgICAgICBsZXQgYmdfaCA9IHRoaXMuZGF0YS5wYWdlSGVpZ2h0ICogMC4zNVxyXG4gICAgICAgICAgICAvLyDlm77niYflnIbop5JcclxuICAgICAgICAgICAgbGV0IGJnX3IgPSA0XHJcbiAgICAgICAgICAgIGxldCBjdHggPSB3eC5jcmVhdGVDYW52YXNDb250ZXh0KCdteWNhbnZhcycpO1xyXG4gICAgICAgICAgICAvLyDnu5jliLbog4zmma9cclxuICAgICAgICAgICAgY3R4LnNldEZpbGxTdHlsZShcIiNmZmZcIik7XHJcbiAgICAgICAgICAgIGN0eC5maWxsUmVjdCgwLCAwLCAwLCAwKTtcclxuICAgICAgICAgICAgLy/nu5jliLbog4zmma/lm77niYdcclxuICAgICAgICAgICAgY3R4LmRyYXdJbWFnZSh0aGlzLmJnVXJsLCAwLCAwLCAzNjAsIDYzNyk7XHJcbiAgICAgICAgICAgIC8v57uY5Yi25aS05YOPXHJcbiAgICAgICAgICAgIHZhciBxclcgPSA1MDsgLy/nu5jliLbnmoTkuoznu7TnoIHlrr3luqZcclxuICAgICAgICAgICAgdmFyIHFySCA9IDUwOyAvL+e7mOWItueahOS6jOe7tOeggemrmOW6plxyXG4gICAgICAgICAgICB2YXIgcXJfeCA9IDQwOyAvL+e7mOWItueahOS6jOe7tOeggeWcqOeUu+W4g+S4iueahOS9jee9rlxyXG4gICAgICAgICAgICB2YXIgcXJfeSA9IDUwOyAvL+e7mOWItueahOS6jOe7tOeggeWcqOeUu+W4g+S4iueahOS9jee9rlxyXG4gICAgICAgICAgICBjdHguc2F2ZSgpO1xyXG4gICAgICAgICAgICBjdHguYmVnaW5QYXRoKCk7IC8v5byA5aeL57uY5Yi2XHJcbiAgICAgICAgICAgIC8v5YWI55S75Liq5ZyGICDliY3kuKTkuKrlj4LmlbDnoa7lrprkuoblnIblv4Mg77yIeCx577yJIOWdkOaghyDnrKzkuInkuKrlj4LmlbDmmK/lnIbnmoTljYrlvoQg5Zub5Y+C5pWw5piv57uY5Zu+5pa55ZCRIOm7mOiupOaYr2ZhbHNl77yM5Y2z6aG65pe26ZKIXHJcbiAgICAgICAgICAgIGN0eC5hcmMocXJXIC8gMiArIHFyX3gsIHFySCAvIDIgKyBxcl95LCBxclcgLyAyLCAwLCBNYXRoLlBJICogMiwgZmFsc2UpO1xyXG4gICAgICAgICAgICBjdHguY2xpcCgpOyAvL+eUu+WlveS6huWchiDliarliIcg5Y6f5aeL55S75biD5Lit5Ymq5YiH5Lu75oSP5b2i54q25ZKM5bC65a+444CC5LiA5pem5Ymq5YiH5LqG5p+Q5Liq5Yy65Z+f77yM5YiZ5omA5pyJ5LmL5ZCO55qE57uY5Zu+6YO95Lya6KKr6ZmQ5Yi25Zyo6KKr5Ymq5YiH55qE5Yy65Z+f5YaFIOi/meS5n+aYr+aIkeS7rOimgXNhdmXkuIrkuIvmlofnmoTljp/lm6BcclxuICAgICAgICAgICAgY3R4LmRyYXdJbWFnZSh0aGlzLmxvY2FsYXZhdFVybCwgcXJfeCwgcXJfeSwgcXJXLCBxckgpO1xyXG4gICAgICAgICAgICAvLyDmgaLlpI3kuYvliY3kv53lrZjnmoTnu5jlm77kuIrkuIvmlodcclxuICAgICAgICAgICAgY3R4LnJlc3RvcmUoKVxyXG4gICAgICAgICAgICBjdHguc2V0Rm9udFNpemUoMTYpO1xyXG4gICAgICAgICAgICBjdHguc2V0RmlsbFN0eWxlKCcjMzMzJyk7XHJcbiAgICAgICAgICAgIGN0eC5maWxsVGV4dCh0aGlzLm5hbWUsIDEwMCwgNzAsIDI4MCk7XHJcbiAgICAgICAgICAgIGN0eC5zZXRGb250U2l6ZSgxMik7XHJcbiAgICAgICAgICAgIGN0eC5zZXRGaWxsU3R5bGUoJyM5OTknKTtcclxuICAgICAgICAgICAgY3R4LmZpbGxUZXh0KCfmiJDplb/vvIzmmK/miJHku6zmnIDlgLzlvpfnj43ol4/nmoTorrDlv4YnLCAxMDAsIDkwLCAyODApO1xyXG4gICAgICAgICAgICAvLyDnu5jliLZiYW5uZXJcclxuICAgICAgICAgICAgY3R4LmJlZ2luUGF0aCgpO1xyXG4gICAgICAgICAgICBjdHguc2F2ZSgpO1xyXG4gICAgICAgICAgICBsZXQgbGVmdCA9IDQwLFxyXG4gICAgICAgICAgICAgICAgdG9wID0gMTIwLFxyXG4gICAgICAgICAgICAgICAgd2lkdGggPSAyODAsXHJcbiAgICAgICAgICAgICAgICBoZWlnaHQgPSAxNDAsXHJcbiAgICAgICAgICAgICAgICBmaWxsZXQgPSA2LFxyXG4gICAgICAgICAgICAgICAgdyA9IDJcclxuICAgICAgICAgICAgbGVmdCA9IGxlZnQgLyAyICogdztcclxuICAgICAgICAgICAgdG9wID0gdG9wIC8gMiAqIHc7XHJcbiAgICAgICAgICAgIHdpZHRoID0gd2lkdGggLyAyICogdztcclxuICAgICAgICAgICAgaGVpZ2h0ID0gaGVpZ2h0IC8gMiAqIHc7XHJcbiAgICAgICAgICAgIGZpbGxldCA9IGZpbGxldCAvIDIgKiB3O1xyXG4gICAgICAgICAgICBjdHguc2V0TGluZVdpZHRoKDEpO1xyXG4gICAgICAgICAgICBjdHguc2V0U3Ryb2tlU3R5bGUoJyNmZmZmZmYnKTtcclxuICAgICAgICAgICAgY3R4Lm1vdmVUbyhsZWZ0ICsgZmlsbGV0LCB0b3ApOyAvLyDliJvlu7rlvIDlp4vngrlcclxuICAgICAgICAgICAgY3R4LmxpbmVUbyhsZWZ0ICsgd2lkdGggLSBmaWxsZXQsIHRvcCk7IC8vIOWIm+W7uuawtOW5s+e6v1xyXG4gICAgICAgICAgICBjdHguYXJjVG8obGVmdCArIHdpZHRoLCB0b3AsIGxlZnQgKyB3aWR0aCwgdG9wICsgZmlsbGV0LCBmaWxsZXQpOyAvLyDliJvlu7rlvKdcclxuICAgICAgICAgICAgY3R4LmxpbmVUbyhsZWZ0ICsgd2lkdGgsIHRvcCArIGhlaWdodCAtIGZpbGxldCk7IC8vIOWIm+W7uuWeguebtOe6v1xyXG4gICAgICAgICAgICBjdHguYXJjVG8obGVmdCArIHdpZHRoLCB0b3AgKyBoZWlnaHQsIGxlZnQgKyB3aWR0aCAtIGZpbGxldCwgdG9wICsgaGVpZ2h0LCBmaWxsZXQpOyAvLyDliJvlu7rlvKdcclxuICAgICAgICAgICAgY3R4LmxpbmVUbyhsZWZ0ICsgZmlsbGV0LCB0b3AgKyBoZWlnaHQpOyAvLyDliJvlu7rmsLTlubPnur9cclxuICAgICAgICAgICAgY3R4LmFyY1RvKGxlZnQsIHRvcCArIGhlaWdodCwgbGVmdCwgdG9wICsgaGVpZ2h0IC0gZmlsbGV0LCBmaWxsZXQpOyAvLyDliJvlu7rlvKdcclxuICAgICAgICAgICAgY3R4LmxpbmVUbyhsZWZ0LCB0b3AgKyBmaWxsZXQpOyAvLyDliJvlu7rlnoLnm7Tnur9cclxuICAgICAgICAgICAgY3R4LmFyY1RvKGxlZnQsIHRvcCwgbGVmdCArIGZpbGxldCwgdG9wLCBmaWxsZXQpOyAvLyDliJvlu7rlvKdcclxuICAgICAgICAgICAgY3R4LnN0cm9rZSgpOyAvLyDov5nkuKrlhbfkvZPlubLku4DkuYjnlKjnmoTvvJ9cclxuICAgICAgICAgICAgY3R4LmNsaXAoKTtcclxuICAgICAgICAgICAgY3R4LmRyYXdJbWFnZSh0aGlzLmxvY2FsSW1hZ2VVcmwsIGxlZnQsIHRvcCwgd2lkdGgsIGhlaWdodCk7XHJcbiAgICAgICAgICAgIGN0eC5yZXN0b3JlKCk7XHJcbiAgICAgICAgICAgIC8vIC8vIOe7mOWItuagh+mimFxyXG4gICAgICAgICAgICBjdHguc2V0Rm9udFNpemUoMTMpO1xyXG4gICAgICAgICAgICBjdHguc2V0RmlsbFN0eWxlKCcjMzMzJyk7XHJcbiAgICAgICAgICAgIC8v5ZWG5ZOB5ZCN56ewXHJcbiAgICAgICAgICAgIGN0eC5maWxsVGV4dCh0aGlzLnNoYXJlSW5mby5jb3Vyc2UuY291cnNlVGl0dGxlLCA0MCwgMjkwLCAyODApO1xyXG4gICAgICAgICAgICAvLyDnu5jliLbku7fmoLzljZXkvY0gJ++/pSdcclxuICAgICAgICAgICAgY3R4LnNldEZvbnRTaXplKDE2KTtcclxuICAgICAgICAgICAgY3R4LnNldEZpbGxTdHlsZSgnIzMzMycpO1xyXG4gICAgICAgICAgICBjdHguZmlsbFRleHQoJ+a0u+WKqOi0ue+8micsIDQwLCAzMTUsIDI4MCk7XHJcbiAgICAgICAgICAgIGN0eC5zZXRGb250U2l6ZSgxMik7XHJcbiAgICAgICAgICAgIGN0eC5zZXRGaWxsU3R5bGUoJyNmYjg2N2YnKTtcclxuICAgICAgICAgICAgY3R4LmZpbGxUZXh0KCfvv6UnLCAxMDAsIDMxNSwgMjgwKTtcclxuICAgICAgICAgICAgY3R4LnNldEZvbnRTaXplKDE2KTtcclxuICAgICAgICAgICAgY3R4LnNldEZpbGxTdHlsZSgnI2ZiODY3ZicpO1xyXG4gICAgICAgICAgICBjdHguZmlsbFRleHQodGhpcy5zaGFyZUluZm8uY291cnNlLnByaWNlLCAxMTAsIDMxNSwgMjgwKTtcclxuICAgICAgICAgICAgLy8g57uY5Yi25bey5ZSuXHJcbiAgICAgICAgICAgIGN0eC5zZXRGb250U2l6ZSgxMyk7XHJcbiAgICAgICAgICAgIGN0eC5zZXRGaWxsU3R5bGUoJyM5OTknKTtcclxuICAgICAgICAgICAgY3R4LmZpbGxUZXh0KGDlt7LllK4ke3RoaXMuc2hhcmVJbmZvLmNvdXJzZS5hY3R1YWxTYWxlcyArIHRoaXMuc2hhcmVJbmZvLmNvdXJzZS52aXJ0dWFsU2FsZXN95Lq6YCwgMjYwLCAzMTUsIDI4MCk7XHJcbiAgICAgICAgICAgIC8vIOe7mOWItuivt+axguWKqeWKm1xyXG4gICAgICAgICAgICBjdHguc2V0Rm9udFNpemUoMTUpO1xyXG4gICAgICAgICAgICBjdHguc2V0RmlsbFN0eWxlKCcjOTk5Jyk7XHJcbiAgICAgICAgICAgIGN0eC5maWxsVGV4dCgn5oiR5q2j5Zyo5Y+C5Yqg4oCc6ZuE6bmw56ul6KGM4oCd55qE5L+D6ZSA5rS75YqoJywgNTAsIDM3MCwgMjgwKTtcclxuICAgICAgICAgICAgY3R4LnNldEZvbnRTaXplKDE1KTtcclxuICAgICAgICAgICAgY3R4LnNldEZpbGxTdHlsZSgnIzk5OScpO1xyXG4gICAgICAgICAgICBjdHguZmlsbFRleHQoJ+WOn+S7t++8micsIDYwLCAzOTQsIDI4MCk7XHJcbiAgICAgICAgICAgIGN0eC5zZXRGb250U2l6ZSgxNSk7XHJcbiAgICAgICAgICAgIGN0eC5zZXRGaWxsU3R5bGUoJyNmYjg2N2YnKTtcclxuICAgICAgICAgICAgY3R4LmZpbGxUZXh0KGAke3RoaXMuc2hhcmVJbmZvLmNvdXJzZS5wcmljZX3lhYPvvIxgLCAxMDAsIDM5NCwgMjgwKTtcclxuICAgICAgICAgICAgY3R4LnNldEZvbnRTaXplKDE1KTtcclxuICAgICAgICAgICAgY3R4LnNldEZpbGxTdHlsZSgnIzk5OScpO1xyXG4gICAgICAgICAgICBjdHguZmlsbFRleHQoJ+acgOS9ju+8micsIDE4MCwgMzk0LCAyODApO1xyXG4gICAgICAgICAgICBjdHguc2V0Rm9udFNpemUoMTUpO1xyXG4gICAgICAgICAgICBjdHguc2V0RmlsbFN0eWxlKCcjZmI4NjdmJyk7XHJcbiAgICAgICAgICAgIGN0eC5maWxsVGV4dChgJHt0aGlzLnNoYXJlSW5mby5jb3Vyc2UubWluaW11bVByaWNlfeWFg++8jGAsIDIyMCwgMzk0LCAyODApO1xyXG4gICAgICAgICAgICBjdHguc2V0Rm9udFNpemUoMTUpO1xyXG4gICAgICAgICAgICBjdHguc2V0RmlsbFN0eWxlKCcjOTk5Jyk7XHJcbiAgICAgICAgICAgIGN0eC5maWxsVGV4dCgn6K+357uZ5oiR54K55LiA54K55Ye654K55Yqb77yM6LCi6LCi77yBJywgODAsIDQyMCwgMjgwKTtcclxuICAgICAgICAgICAgLy8gLy8g57uY5Yi25bCP56iL5bqP5ZCN56ewXHJcbiAgICAgICAgICAgIGN0eC5kcmF3SW1hZ2UodGhpcy5sb2NhbENvZGVVcmwsIDQwLCA1MDAsIDEwMCwgMTAwKTtcclxuICAgICAgICAgICAgLy8g5pi+56S657uY5Yi2XHJcbiAgICAgICAgICAgIGN0eC5kcmF3KCk7XHJcbiAgICAgICAgICAgIC8v5bCG55Sf5oiQ5aW955qE5Zu+54mH5L+d5a2Y5Yiw5pys5Zyw77yM6ZyA6KaB5bu26L+f5LiA5Lya77yM57uY5Yi25pyf6Ze06ICX5pe2XHJcbiAgICAgICAgICAgIHNldFRpbWVvdXQoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICB3eC5jYW52YXNUb1RlbXBGaWxlUGF0aCh7XHJcbiAgICAgICAgICAgICAgICAgICAgY2FudmFzSWQ6ICdteWNhbnZhcycsXHJcbiAgICAgICAgICAgICAgICAgICAgc3VjY2VzcyhyZXMpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHRlbXBGaWxlUGF0aCA9IHJlcy50ZW1wRmlsZVBhdGg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoYXQubG9hZEltYWdlUGF0aCA9IHRlbXBGaWxlUGF0aFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGF0LiRhcHBseSgpXHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICBmYWlsKHJlcykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhyZXMpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9LCA1MDApO1xyXG4gICAgICAgICAgICAvL+WFs+mXreaPkOekulxyXG4gICAgICAgICAgICB3eC5oaWRlTG9hZGluZygpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuIl19