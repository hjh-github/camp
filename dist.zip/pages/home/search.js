"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _dec, _class;

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _cCard = require('./../../components/home/cCard.js');

var _cCard2 = _interopRequireDefault(_cCard);

var _utils = require('./../../store/utils.js');

var _utils2 = _interopRequireDefault(_utils);

var _wepyRedux = require('./../../npm/wepy-redux/lib/index.js');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = (_dec = (0, _wepyRedux.connect)({
    city: _utils2.default.get("city")
}), _dec(_class = function (_wepy$page) {
    _inherits(Dialog, _wepy$page);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
            navigationBarTitleText: "搜索"
        }, _this.data = {
            theme: _wepy2.default.$instance.globalData.themeColor,
            courses: [],
            key: '',
            isLoad: false,
            pageIndex: 1,
            isUp: false
        }, _this.$repeat = {}, _this.$props = { "cCard": { "xmlns:v-bind": "", "v-bind:model.sync": "courses" } }, _this.$events = {}, _this.components = {
            cCard: _cCard2.default
        }, _this.methods = {
            input: function input(e) {
                this.key = e.detail.value;
            },
            search: function search() {
                this.loadcourses();
            },
            getMore: function () {
                var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
                    return regeneratorRuntime.wrap(function _callee$(_context) {
                        while (1) {
                            switch (_context.prev = _context.next) {
                                case 0:
                                    if (!this.isLoad) {
                                        _context.next = 3;
                                        break;
                                    }

                                    _context.next = 3;
                                    return this.loadcourses(this.pageIndex + 1);

                                case 3:
                                case "end":
                                    return _context.stop();
                            }
                        }
                    }, _callee, this);
                }));

                function getMore() {
                    return _ref2.apply(this, arguments);
                }

                return getMore;
            }()
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(Dialog, [{
        key: "onLoad",
        value: function onLoad(opt) {
            if (opt.kw) {
                this.key = opt.kw;
            }
            this.loadcourses();
        }
    }, {
        key: "loadcourses",
        value: function () {
            var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
                var pageIndex = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 1;
                var params, courses;
                return regeneratorRuntime.wrap(function _callee2$(_context2) {
                    while (1) {
                        switch (_context2.prev = _context2.next) {
                            case 0:
                                this.isUp = true;
                                this.isLoad = false;
                                params = {
                                    keywords: this.key,
                                    cityCode: this.city.code,
                                    pageIndex: pageIndex
                                };
                                _context2.next = 5;
                                return _config2.default.search(params);

                            case 5:
                                courses = _context2.sent;

                                if (courses.courses.length) {
                                    _context2.next = 13;
                                    break;
                                }

                                if (pageIndex == 1) {
                                    this.courses = courses.courses;
                                }
                                // this.pageIndex = pageIndex
                                this.isLoad = true;
                                this.$apply();
                                return _context2.abrupt("return", false);

                            case 13:
                                if (pageIndex > 1) this.pageIndex = pageIndex;
                                if (pageIndex == 1) {
                                    this.courses = courses.courses;
                                } else {
                                    this.courses = this.courses.concat(courses.courses);
                                }
                                this.isLoad = true;
                                this.isUp = false;
                                this.$apply();

                            case 18:
                            case "end":
                                return _context2.stop();
                        }
                    }
                }, _callee2, this);
            }));

            function loadcourses() {
                return _ref3.apply(this, arguments);
            }

            return loadcourses;
        }()
    }]);

    return Dialog;
}(_wepy2.default.page)) || _class);

Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/home/search'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNlYXJjaC5qcyJdLCJuYW1lcyI6WyJEaWFsb2ciLCJjaXR5Iiwic3RvcmUiLCJnZXQiLCJjb25maWciLCJuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0IiwiZGF0YSIsInRoZW1lIiwid2VweSIsIiRpbnN0YW5jZSIsImdsb2JhbERhdGEiLCJ0aGVtZUNvbG9yIiwiY291cnNlcyIsImtleSIsImlzTG9hZCIsInBhZ2VJbmRleCIsImlzVXAiLCIkcmVwZWF0IiwiJHByb3BzIiwiJGV2ZW50cyIsImNvbXBvbmVudHMiLCJjQ2FyZCIsIm1ldGhvZHMiLCJpbnB1dCIsImUiLCJkZXRhaWwiLCJ2YWx1ZSIsInNlYXJjaCIsImxvYWRjb3Vyc2VzIiwiZ2V0TW9yZSIsIm9wdCIsImt3IiwicGFyYW1zIiwia2V5d29yZHMiLCJjaXR5Q29kZSIsImNvZGUiLCJsZW5ndGgiLCIkYXBwbHkiLCJjb25jYXQiLCJwYWdlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUNJOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7Ozs7Ozs7OztJQU1xQkEsTSxXQUhwQix3QkFBUTtBQUNMQyxVQUFNQyxnQkFBTUMsR0FBTixDQUFVLE1BQVY7QUFERCxDQUFSLEM7Ozs7Ozs7Ozs7Ozs7OzBMQUlHQyxNLEdBQVM7QUFDTEMsb0NBQXdCO0FBRG5CLFMsUUFHVEMsSSxHQUFPO0FBQ0hDLG1CQUFPQyxlQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJDLFVBRDlCO0FBRUhDLHFCQUFTLEVBRk47QUFHSEMsaUJBQUssRUFIRjtBQUlIQyxvQkFBUSxLQUpMO0FBS0hDLHVCQUFXLENBTFI7QUFNSEMsa0JBQU07QUFOSCxTLFFBUVJDLE8sR0FBVSxFLFFBQ2pCQyxNLEdBQVMsRUFBQyxTQUFRLEVBQUMsZ0JBQWUsRUFBaEIsRUFBbUIscUJBQW9CLFNBQXZDLEVBQVQsRSxRQUNUQyxPLEdBQVUsRSxRQUNUQyxVLEdBQWE7QUFDRkM7QUFERSxTLFFBc0NOQyxPLEdBQVU7QUFDTkMsaUJBRE0saUJBQ0FDLENBREEsRUFDRztBQUNMLHFCQUFLWCxHQUFMLEdBQVdXLEVBQUVDLE1BQUYsQ0FBU0MsS0FBcEI7QUFDSCxhQUhLO0FBSU5DLGtCQUpNLG9CQUlHO0FBQ0wscUJBQUtDLFdBQUw7QUFDSCxhQU5LO0FBT0FDLG1CQVBBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlDQVFDLEtBQUtmLE1BUk47QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQSwyQ0FRb0IsS0FBS2MsV0FBTCxDQUFpQixLQUFLYixTQUFMLEdBQWlCLENBQWxDLENBUnBCOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUEsUzs7Ozs7K0JBbkNIZSxHLEVBQUk7QUFDUCxnQkFBR0EsSUFBSUMsRUFBUCxFQUFVO0FBQ04scUJBQUtsQixHQUFMLEdBQVdpQixJQUFJQyxFQUFmO0FBQ0g7QUFDRCxpQkFBS0gsV0FBTDtBQUNIOzs7OztvQkFDaUJiLFMsdUVBQVksQzs7Ozs7O0FBQzFCLHFDQUFLQyxJQUFMLEdBQVksSUFBWjtBQUNBLHFDQUFLRixNQUFMLEdBQWMsS0FBZDtBQUNJa0Isc0MsR0FBUztBQUNUQyw4Q0FBVSxLQUFLcEIsR0FETjtBQUVUcUIsOENBQVUsS0FBS2pDLElBQUwsQ0FBVWtDLElBRlg7QUFHVHBCLCtDQUFXQTtBQUhGLGlDOzt1Q0FLT1gsaUJBQU91QixNQUFQLENBQWNLLE1BQWQsQzs7O0FBQWhCcEIsdUM7O29DQUNDQSxRQUFRQSxPQUFSLENBQWdCd0IsTTs7Ozs7QUFDakIsb0NBQUlyQixhQUFhLENBQWpCLEVBQW9CO0FBQ2hCLHlDQUFLSCxPQUFMLEdBQWVBLFFBQVFBLE9BQXZCO0FBQ0g7QUFDRDtBQUNBLHFDQUFLRSxNQUFMLEdBQWMsSUFBZDtBQUNBLHFDQUFLdUIsTUFBTDtrRUFDTyxLOzs7QUFFUCxvQ0FBSXRCLFlBQVksQ0FBaEIsRUFBbUIsS0FBS0EsU0FBTCxHQUFpQkEsU0FBakI7QUFDbkIsb0NBQUlBLGFBQWEsQ0FBakIsRUFBb0I7QUFDaEIseUNBQUtILE9BQUwsR0FBZUEsUUFBUUEsT0FBdkI7QUFDSCxpQ0FGRCxNQUVPO0FBQ0gseUNBQUtBLE9BQUwsR0FBZSxLQUFLQSxPQUFMLENBQWEwQixNQUFiLENBQW9CMUIsUUFBUUEsT0FBNUIsQ0FBZjtBQUNIO0FBQ0QscUNBQUtFLE1BQUwsR0FBYyxJQUFkO0FBQ0EscUNBQUtFLElBQUwsR0FBWSxLQUFaO0FBQ0EscUNBQUtxQixNQUFMOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBbER3QjdCLGVBQUsrQixJO2tCQUFwQnZDLE0iLCJmaWxlIjoic2VhcmNoLmpzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbiAgICBpbXBvcnQgd2VweSBmcm9tIFwid2VweVwiXHJcbiAgICBpbXBvcnQgY29uZmlnIGZyb20gXCJAL2FwaS9jb25maWdcIlxyXG4gICAgaW1wb3J0IGNDYXJkIGZyb20gXCJAL2NvbXBvbmVudHMvaG9tZS9jQ2FyZFwiXHJcbiAgICBpbXBvcnQgc3RvcmUgZnJvbSBcIkAvc3RvcmUvdXRpbHNcIlxyXG4gICAgaW1wb3J0IHtcclxuICAgICAgICBjb25uZWN0XHJcbiAgICB9IGZyb20gXCJ3ZXB5LXJlZHV4XCJcclxuICAgIEBjb25uZWN0KHtcclxuICAgICAgICBjaXR5OiBzdG9yZS5nZXQoXCJjaXR5XCIpXHJcbiAgICB9KVxyXG4gICAgZXhwb3J0IGRlZmF1bHQgY2xhc3MgRGlhbG9nIGV4dGVuZHMgd2VweS5wYWdlIHtcclxuICAgICAgICBjb25maWcgPSB7XHJcbiAgICAgICAgICAgIG5hdmlnYXRpb25CYXJUaXRsZVRleHQ6IFwi5pCc57SiXCJcclxuICAgICAgICB9O1xyXG4gICAgICAgIGRhdGEgPSB7XHJcbiAgICAgICAgICAgIHRoZW1lOiB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnRoZW1lQ29sb3IsXHJcbiAgICAgICAgICAgIGNvdXJzZXM6IFtdLFxyXG4gICAgICAgICAgICBrZXk6ICcnLFxyXG4gICAgICAgICAgICBpc0xvYWQ6IGZhbHNlLFxyXG4gICAgICAgICAgICBwYWdlSW5kZXg6IDEsXHJcbiAgICAgICAgICAgIGlzVXA6IGZhbHNlXHJcbiAgICAgICAgfTtcclxuICAgICAgICRyZXBlYXQgPSB7fTtcclxuJHByb3BzID0ge1wiY0NhcmRcIjp7XCJ4bWxuczp2LWJpbmRcIjpcIlwiLFwidi1iaW5kOm1vZGVsLnN5bmNcIjpcImNvdXJzZXNcIn19O1xyXG4kZXZlbnRzID0ge307XHJcbiBjb21wb25lbnRzID0ge1xyXG4gICAgICAgICAgICBjQ2FyZFxyXG4gICAgICAgIH1cclxuICAgICAgICBvbkxvYWQob3B0KXtcclxuICAgICAgICAgICAgaWYob3B0Lmt3KXtcclxuICAgICAgICAgICAgICAgIHRoaXMua2V5ID0gb3B0Lmt3XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdGhpcy5sb2FkY291cnNlcygpXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGFzeW5jIGxvYWRjb3Vyc2VzKHBhZ2VJbmRleCA9IDEpIHtcclxuICAgICAgICAgICAgdGhpcy5pc1VwID0gdHJ1ZVxyXG4gICAgICAgICAgICB0aGlzLmlzTG9hZCA9IGZhbHNlXHJcbiAgICAgICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgICAgICBrZXl3b3JkczogdGhpcy5rZXksXHJcbiAgICAgICAgICAgICAgICBjaXR5Q29kZTogdGhpcy5jaXR5LmNvZGUsXHJcbiAgICAgICAgICAgICAgICBwYWdlSW5kZXg6IHBhZ2VJbmRleFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGxldCBjb3Vyc2VzID0gYXdhaXQgY29uZmlnLnNlYXJjaChwYXJhbXMpXHJcbiAgICAgICAgICAgIGlmICghY291cnNlcy5jb3Vyc2VzLmxlbmd0aCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHBhZ2VJbmRleCA9PSAxKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jb3Vyc2VzID0gY291cnNlcy5jb3Vyc2VzXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvLyB0aGlzLnBhZ2VJbmRleCA9IHBhZ2VJbmRleFxyXG4gICAgICAgICAgICAgICAgdGhpcy5pc0xvYWQgPSB0cnVlXHJcbiAgICAgICAgICAgICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGlmIChwYWdlSW5kZXggPiAxKSB0aGlzLnBhZ2VJbmRleCA9IHBhZ2VJbmRleFxyXG4gICAgICAgICAgICAgICAgaWYgKHBhZ2VJbmRleCA9PSAxKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jb3Vyc2VzID0gY291cnNlcy5jb3Vyc2VzXHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY291cnNlcyA9IHRoaXMuY291cnNlcy5jb25jYXQoY291cnNlcy5jb3Vyc2VzKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgdGhpcy5pc0xvYWQgPSB0cnVlXHJcbiAgICAgICAgICAgICAgICB0aGlzLmlzVXAgPSBmYWxzZVxyXG4gICAgICAgICAgICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIG1ldGhvZHMgPSB7XHJcbiAgICAgICAgICAgIGlucHV0KGUpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMua2V5ID0gZS5kZXRhaWwudmFsdWVcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgc2VhcmNoKCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5sb2FkY291cnNlcygpXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGFzeW5jIGdldE1vcmUoKSB7XHJcbiAgICAgICAgICAgICAgICBpZih0aGlzLmlzTG9hZCkgYXdhaXQgdGhpcy5sb2FkY291cnNlcyh0aGlzLnBhZ2VJbmRleCArIDEpXHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH07XHJcbiAgICB9XHJcbiJdfQ==