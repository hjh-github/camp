"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _Lang = require('./../../utils/Lang.js');

var _Lang2 = _interopRequireDefault(_Lang);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var shareInfo = function (_wepy$page) {
    _inherits(shareInfo, _wepy$page);

    function shareInfo() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, shareInfo);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = shareInfo.__proto__ || Object.getPrototypeOf(shareInfo)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
            navigationBarTitleText: "详情"
        }, _this.methods = {
            //点击保存到相册
            saveImg: function saveImg() {
                var _this2 = this;

                if (this.errcode == '-1') {
                    _Lang2.default.openSetting();
                    return;
                }
                _Lang2.default.downImg(this.loadImagePath, function (res) {
                    if (res.code == 0) {
                        _Tips2.default.toast('保存成功', function () {}, 'none');
                    } else if (res.code == '-1') {
                        _this2.errcode = res.code;
                        _Tips2.default.toast('您已拒绝授权下载图片，点击保存按钮获取授权', function () {}, 'none');
                    }
                    _this2.$apply();
                });
            },
            proview: function proview(item) {
                if (!item) return;
                wx.previewImage({
                    current: item, // 当前显示图片的http链接
                    urls: [item] // 需要预览的图片http链接列表
                });
            }
        }, _this.data = {
            loadImagePath: '',
            errcode: 0
            /**
             * 生命周期函数--监听页面加载
             */
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(shareInfo, [{
        key: "onLoad",
        value: function () {
            var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(options) {
                return regeneratorRuntime.wrap(function _callee$(_context) {
                    while (1) {
                        switch (_context.prev = _context.next) {
                            case 0:
                                console.log(_wepy2.default.$instance.globalData.picView);
                                this.loadImagePath = _wepy2.default.$instance.globalData.picView;
                                this.$apply();

                            case 3:
                            case "end":
                                return _context.stop();
                        }
                    }
                }, _callee, this);
            }));

            function onLoad(_x) {
                return _ref2.apply(this, arguments);
            }

            return onLoad;
        }()
    }]);

    return shareInfo;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(shareInfo , 'pages/home/picView'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBpY1ZpZXcuanMiXSwibmFtZXMiOlsic2hhcmVJbmZvIiwiY29uZmlnIiwibmF2aWdhdGlvbkJhclRpdGxlVGV4dCIsIm1ldGhvZHMiLCJzYXZlSW1nIiwiZXJyY29kZSIsIkxhbmciLCJvcGVuU2V0dGluZyIsImRvd25JbWciLCJsb2FkSW1hZ2VQYXRoIiwicmVzIiwiY29kZSIsIlRpcHMiLCJ0b2FzdCIsIiRhcHBseSIsInByb3ZpZXciLCJpdGVtIiwid3giLCJwcmV2aWV3SW1hZ2UiLCJjdXJyZW50IiwidXJscyIsImRhdGEiLCJvcHRpb25zIiwiY29uc29sZSIsImxvZyIsIndlcHkiLCIkaW5zdGFuY2UiLCJnbG9iYWxEYXRhIiwicGljVmlldyIsInBhZ2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUNJOzs7O0FBQ0E7Ozs7QUFDQTs7Ozs7Ozs7Ozs7Ozs7SUFDcUJBLFM7Ozs7Ozs7Ozs7Ozs7O2dNQUNqQkMsTSxHQUFTO0FBQ0xDLG9DQUF3QjtBQURuQixTLFFBR1RDLE8sR0FBVTtBQUNOO0FBQ0FDLG1CQUZNLHFCQUVJO0FBQUE7O0FBQ04sb0JBQUcsS0FBS0MsT0FBTCxJQUFnQixJQUFuQixFQUF3QjtBQUN0QkMsbUNBQUtDLFdBQUw7QUFDQTtBQUNEO0FBQ0RELCtCQUFLRSxPQUFMLENBQWEsS0FBS0MsYUFBbEIsRUFBZ0MsZUFBSztBQUNuQyx3QkFBR0MsSUFBSUMsSUFBSixJQUFZLENBQWYsRUFBaUI7QUFDYkMsdUNBQUtDLEtBQUwsQ0FBVyxNQUFYLEVBQW1CLFlBQU0sQ0FBRSxDQUEzQixFQUE2QixNQUE3QjtBQUNILHFCQUZELE1BRU0sSUFBR0gsSUFBSUMsSUFBSixJQUFZLElBQWYsRUFBb0I7QUFDdEIsK0JBQUtOLE9BQUwsR0FBZUssSUFBSUMsSUFBbkI7QUFDQUMsdUNBQUtDLEtBQUwsQ0FBVyx1QkFBWCxFQUFvQyxZQUFNLENBQUUsQ0FBNUMsRUFBOEMsTUFBOUM7QUFDSDtBQUNELDJCQUFLQyxNQUFMO0FBQ0QsaUJBUkQ7QUFTSCxhQWhCSztBQWlCTkMsbUJBakJNLG1CQWlCRUMsSUFqQkYsRUFpQk87QUFDWCxvQkFBRyxDQUFDQSxJQUFKLEVBQVU7QUFDVkMsbUJBQUdDLFlBQUgsQ0FBZ0I7QUFDZEMsNkJBQVNILElBREssRUFDQztBQUNmSSwwQkFBTSxDQUFDSixJQUFELENBRlEsQ0FFRDtBQUZDLGlCQUFoQjtBQUlEO0FBdkJLLFMsUUF5QlZLLEksR0FBTztBQUNIWiwyQkFBYyxFQURYO0FBRUhKLHFCQUFRO0FBRVo7OztBQUpPLFM7Ozs7OztpR0FPTWlCLE87Ozs7O0FBQ1RDLHdDQUFRQyxHQUFSLENBQVlDLGVBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQkMsT0FBdEM7QUFDQSxxQ0FBS25CLGFBQUwsR0FBcUJnQixlQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJDLE9BQS9DO0FBQ0EscUNBQUtkLE1BQUw7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUF2QytCVyxlQUFLSSxJOztrQkFBdkI3QixTIiwiZmlsZSI6InBpY1ZpZXcuanMiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuICAgIGltcG9ydCB3ZXB5IGZyb20gXCJ3ZXB5XCI7XHJcbiAgICBpbXBvcnQgTGFuZyBmcm9tIFwiQC91dGlscy9MYW5nXCJcclxuICAgIGltcG9ydCBUaXBzIGZyb20gXCJAL3V0aWxzL1RpcHNcIlxyXG4gICAgZXhwb3J0IGRlZmF1bHQgY2xhc3Mgc2hhcmVJbmZvIGV4dGVuZHMgd2VweS5wYWdlIHtcclxuICAgICAgICBjb25maWcgPSB7XHJcbiAgICAgICAgICAgIG5hdmlnYXRpb25CYXJUaXRsZVRleHQ6IFwi6K+m5oOFXCJcclxuICAgICAgICB9O1xyXG4gICAgICAgIG1ldGhvZHMgPSB7XHJcbiAgICAgICAgICAgIC8v54K55Ye75L+d5a2Y5Yiw55u45YaMXHJcbiAgICAgICAgICAgIHNhdmVJbWcoKSB7XHJcbiAgICAgICAgICAgICAgICBpZih0aGlzLmVycmNvZGUgPT0gJy0xJyl7XHJcbiAgICAgICAgICAgICAgICAgIExhbmcub3BlblNldHRpbmcoKVxyXG4gICAgICAgICAgICAgICAgICByZXR1cm5cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIExhbmcuZG93bkltZyh0aGlzLmxvYWRJbWFnZVBhdGgscmVzPT57XHJcbiAgICAgICAgICAgICAgICAgIGlmKHJlcy5jb2RlID09IDApe1xyXG4gICAgICAgICAgICAgICAgICAgICAgVGlwcy50b2FzdCgn5L+d5a2Y5oiQ5YqfJywgKCkgPT4ge30sICdub25lJylcclxuICAgICAgICAgICAgICAgICAgfWVsc2UgaWYocmVzLmNvZGUgPT0gJy0xJyl7XHJcbiAgICAgICAgICAgICAgICAgICAgICB0aGlzLmVycmNvZGUgPSByZXMuY29kZVxyXG4gICAgICAgICAgICAgICAgICAgICAgVGlwcy50b2FzdCgn5oKo5bey5ouS57ud5o6I5p2D5LiL6L295Zu+54mH77yM54K55Ye75L+d5a2Y5oyJ6ZKu6I635Y+W5o6I5p2DJywgKCkgPT4ge30sICdub25lJylcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHByb3ZpZXcoaXRlbSl7XG4gICAgICAgICAgICAgIGlmKCFpdGVtKSByZXR1cm5cbiAgICAgICAgICAgICAgd3gucHJldmlld0ltYWdlKHtcbiAgICAgICAgICAgICAgICBjdXJyZW50OiBpdGVtLCAvLyDlvZPliY3mmL7npLrlm77niYfnmoRodHRw6ZO+5o6lXG4gICAgICAgICAgICAgICAgdXJsczogW2l0ZW1dIC8vIOmcgOimgemihOiniOeahOWbvueJh2h0dHDpk77mjqXliJfooahcbiAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgfTtcclxuICAgICAgICBkYXRhID0ge1xyXG4gICAgICAgICAgICBsb2FkSW1hZ2VQYXRoOicnLFxyXG4gICAgICAgICAgICBlcnJjb2RlOjBcclxuICAgICAgICB9XHJcbiAgICAgICAgLyoqXHJcbiAgICAgICAgICog55Sf5ZG95ZGo5pyf5Ye95pWwLS3nm5HlkKzpobXpnaLliqDovb1cclxuICAgICAgICAgKi9cclxuICAgICAgICBhc3luYyBvbkxvYWQob3B0aW9ucykge1xuICAgICAgICAgICAgY29uc29sZS5sb2cod2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5waWNWaWV3KVxyXG4gICAgICAgICAgICB0aGlzLmxvYWRJbWFnZVBhdGggPSB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnBpY1ZpZXdcclxuICAgICAgICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgICAgIH1cclxuXHJcbiAgICB9XHJcbiJdfQ==