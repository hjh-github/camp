"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _dec, _class;

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _header = require('./../../components/home/header.js');

var _header2 = _interopRequireDefault(_header);

var _swiper = require('./../../components/common/swiper.js');

var _swiper2 = _interopRequireDefault(_swiper);

var _loading = require('./../../components/common/loading.js');

var _loading2 = _interopRequireDefault(_loading);

var _contact = require('./../../components/common/contact.js');

var _contact2 = _interopRequireDefault(_contact);

var _navs = require('./../../components/home/navs.js');

var _navs2 = _interopRequireDefault(_navs);

var _scrollNav2 = require('./../../components/home/scrollNav.js');

var _scrollNav3 = _interopRequireDefault(_scrollNav2);

var _help = require('./../../components/common/help.js');

var _help2 = _interopRequireDefault(_help);

var _ordering = require('./../../components/common/ordering.js');

var _ordering2 = _interopRequireDefault(_ordering);

var _cCard = require('./../../components/home/cCard.js');

var _cCard2 = _interopRequireDefault(_cCard);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

var _utils = require('./../../store/utils.js');

var _utils2 = _interopRequireDefault(_utils);

var _wepyRedux = require('./../../npm/wepy-redux/lib/index.js');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var _scrollNav = [{
  id: 0,
  name: '全部'
}];
var Dialog = (_dec = (0, _wepyRedux.connect)({
  city: _utils2.default.get("city")
}), _dec(_class = function (_wepy$page) {
  _inherits(Dialog, _wepy$page);

  function Dialog() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, Dialog);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.data = {
      isfixed: false,
      theme: _wepy2.default.$instance.globalData.themeColor,
      swipers: {
        type: 1,
        list: []
      },
      navs: {
        list: [],
        gridCol: 5,
        skin: false
      },
      scrollNav: [{
        id: 0,
        name: '全部'
      }],
      courses: [],
      isShow: false,
      courseTypeId: 0,
      sort: 0,
      pageIndex: 1,
      pageSize: 10,
      toload: false,
      isLoad: true,
      loadmoring: false,
      _city: ''
    }, _this.$repeat = {}, _this.$props = { "cSwiper": { "xmlns:v-bind": "", "v-bind:model.sync": "swipers" }, "Navs": { "v-bind:model.sync": "navs" }, "scrollNav": { "v-bind:isfixed.sync": "isfixed", "v-bind:model.sync": "scrollNav", "xmlns:v-on": "" }, "cCard": { "v-bind:model.sync": "courses" }, "loading": { "xmlns:wx": "" } }, _this.$events = { "scrollNav": { "v-on:ret": "getScreen" } }, _this.components = {
      cSwiper: _swiper2.default,
      Navs: _navs2.default,
      cHeader: _header2.default,
      scrollNav: _scrollNav3.default,
      cCard: _cCard2.default,
      loading: _loading2.default,
      hel: _help2.default,
      ordering: _ordering2.default,
      contact: _contact2.default
    }, _this.config = {
      navigationBarTitleText: "",
      enablePullDownRefresh: true
    }, _this.methods = {
      getScreen: function () {
        var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(key, screen) {
          return regeneratorRuntime.wrap(function _callee$(_context) {
            while (1) {
              switch (_context.prev = _context.next) {
                case 0:
                  this.courseTypeId = key;
                  this.sort = screen;
                  _context.next = 4;
                  return this.loadcourses(1);

                case 4:
                  this.$apply();

                case 5:
                case "end":
                  return _context.stop();
              }
            }
          }, _callee, this);
        }));

        function getScreen(_x, _x2) {
          return _ref2.apply(this, arguments);
        }

        return getScreen;
      }()
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(Dialog, [{
    key: "onShareAppMessage",

    // 转发暂时先不开启
    value: function onShareAppMessage(res) {
      if (res.from === 'button') {
        // 来自页面内转发按钮
        console.log(res.target);
      }
      return {
        title: '',
        path: '/pages/home/index'
      };
    }
  }, {
    key: "onLoad",
    value: function () {
      var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
        return regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _wepy2.default.setNavigationBarColor({
                  frontColor: '#ffffff', //前景颜色值，包括按钮、标题、状态栏的颜色，仅支持 #ffffff 和 #000000,
                  backgroundColor: this.theme, //背景颜色值，有效值为十六进制颜色,
                  success: function success(res) {}
                });
                _context2.next = 3;
                return _auth2.default.login();

              case 3:
                _context2.next = 5;
                return this.load();

              case 5:
                this.isShow = true;
                this.$apply();
                // this.$invoke('cSwiper', 'load', this.model)
                // this.$invoke('Navs', 'load', this.model)

              case 7:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));

      function onLoad() {
        return _ref3.apply(this, arguments);
      }

      return onLoad;
    }()
  }, {
    key: "onShow",
    value: function () {
      var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
        return regeneratorRuntime.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                if (!(!this.isShow || !this.city)) {
                  _context3.next = 2;
                  break;
                }

                return _context3.abrupt("return", false);

              case 2:
                _context3.next = 4;
                return this.load(1);

              case 4:
                this.$apply();

              case 5:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this);
      }));

      function onShow() {
        return _ref4.apply(this, arguments);
      }

      return onShow;
    }()
  }, {
    key: "onPullDownRefresh",
    value: function () {
      var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
        return regeneratorRuntime.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                _context4.next = 2;
                return this.loadcourses(1);

              case 2:
                this.pageIndex = 1;
                this.$apply();
                wx.stopPullDownRefresh();

              case 5:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, this);
      }));

      function onPullDownRefresh() {
        return _ref5.apply(this, arguments);
      }

      return onPullDownRefresh;
    }()
  }, {
    key: "load",
    value: function () {
      var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
        var page = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
        var homeData;
        return regeneratorRuntime.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                _context5.next = 2;
                return _config2.default.getIndex({
                  courseTypeId: this.courseTypeId,
                  sort: this.sort,
                  pageIndex: page || this.pageIndex,
                  pageSize: this.pageSize
                });

              case 2:
                homeData = _context5.sent;

                this.swipers.list = homeData.banners;
                this.navs.list = homeData.navs;
                this.scrollNav = _scrollNav.concat(homeData.types);
                this.courses = homeData.courses;
                this._city = homeData.cityName;
                if (!_wepy2.default.$instance.globalData.cityCode) {
                  _utils2.default.save('city', {
                    name: homeData.cityName,
                    code: homeData.cityCode
                  });
                  _wepy2.default.$instance.globalData.cityCode = homeData.cityCode;
                  wx.setNavigationBarTitle({
                    title: homeData.head || '华心桥体验营'
                  });
                  this.$invoke('ordering', 'load', homeData.newOrderList);
                }

              case 9:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5, this);
      }));

      function load() {
        return _ref6.apply(this, arguments);
      }

      return load;
    }()
  }, {
    key: "showMore",
    value: function showMore() {
      this.isLoad = false;
    }
  }, {
    key: "noMore",
    value: function noMore() {
      this.isLoad = true;
    }
  }, {
    key: "loadcourses",
    value: function () {
      var _ref7 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee6(pageIndex) {
        var params, courses;
        return regeneratorRuntime.wrap(function _callee6$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                params = {
                  courseTypeId: this.courseTypeId,
                  sort: this.sort,
                  pageIndex: pageIndex,
                  pageSize: this.pageSize
                };
                _context6.next = 3;
                return _config2.default.getCourses(params);

              case 3:
                courses = _context6.sent;

                if (courses.courses.length) {
                  _context6.next = 12;
                  break;
                }

                if (pageIndex == 1) {
                  this.courses = courses.courses;
                }
                this.pageIndex = pageIndex;
                this.noMore();
                this.$apply();
                return _context6.abrupt("return", false);

              case 12:
                if (pageIndex > 1) this.pageIndex = pageIndex;
                if (pageIndex == 1) {
                  this.courses = courses.courses;
                } else {
                  this.courses = this.courses.concat(courses.courses);
                }

              case 14:
              case "end":
                return _context6.stop();
            }
          }
        }, _callee6, this);
      }));

      function loadcourses(_x4) {
        return _ref7.apply(this, arguments);
      }

      return loadcourses;
    }()
  }, {
    key: "onPageScroll",
    value: function onPageScroll(e) {
      if (e.scrollTop > 410) {
        if (!this.isfixed) {
          this.isfixed = true;
          this.$apply();
        }
      } else {
        if (this.isfixed) {
          this.isfixed = false;
          this.$apply();
        }
      }
    }
  }, {
    key: "onReachBottom",
    value: function onReachBottom() {
      this.getMore();
    }
  }, {
    key: "getMore",
    value: function () {
      var _ref8 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee7() {
        return regeneratorRuntime.wrap(function _callee7$(_context7) {
          while (1) {
            switch (_context7.prev = _context7.next) {
              case 0:
                if (!this.loadmoring) {
                  _context7.next = 2;
                  break;
                }

                return _context7.abrupt("return", false);

              case 2:
                this.loadmoring = true;
                this.showMore();
                _context7.next = 6;
                return this.loadcourses(this.pageIndex + 1);

              case 6:
                this.loadmoring = false;
                this.$apply();

              case 8:
              case "end":
                return _context7.stop();
            }
          }
        }, _callee7, this);
      }));

      function getMore() {
        return _ref8.apply(this, arguments);
      }

      return getMore;
    }()
  }]);

  return Dialog;
}(_wepy2.default.page)) || _class);

Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/home/index'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LmpzIl0sIm5hbWVzIjpbIl9zY3JvbGxOYXYiLCJpZCIsIm5hbWUiLCJEaWFsb2ciLCJjaXR5Iiwic3RvcmUiLCJnZXQiLCJkYXRhIiwiaXNmaXhlZCIsInRoZW1lIiwid2VweSIsIiRpbnN0YW5jZSIsImdsb2JhbERhdGEiLCJ0aGVtZUNvbG9yIiwic3dpcGVycyIsInR5cGUiLCJsaXN0IiwibmF2cyIsImdyaWRDb2wiLCJza2luIiwic2Nyb2xsTmF2IiwiY291cnNlcyIsImlzU2hvdyIsImNvdXJzZVR5cGVJZCIsInNvcnQiLCJwYWdlSW5kZXgiLCJwYWdlU2l6ZSIsInRvbG9hZCIsImlzTG9hZCIsImxvYWRtb3JpbmciLCJfY2l0eSIsIiRyZXBlYXQiLCIkcHJvcHMiLCIkZXZlbnRzIiwiY29tcG9uZW50cyIsImNTd2lwZXIiLCJOYXZzIiwiY0hlYWRlciIsImNDYXJkIiwibG9hZGluZyIsImhlbCIsIm9yZGVyaW5nIiwiY29udGFjdCIsImNvbmZpZyIsIm5hdmlnYXRpb25CYXJUaXRsZVRleHQiLCJlbmFibGVQdWxsRG93blJlZnJlc2giLCJtZXRob2RzIiwiZ2V0U2NyZWVuIiwia2V5Iiwic2NyZWVuIiwibG9hZGNvdXJzZXMiLCIkYXBwbHkiLCJyZXMiLCJmcm9tIiwiY29uc29sZSIsImxvZyIsInRhcmdldCIsInRpdGxlIiwicGF0aCIsInNldE5hdmlnYXRpb25CYXJDb2xvciIsImZyb250Q29sb3IiLCJiYWNrZ3JvdW5kQ29sb3IiLCJzdWNjZXNzIiwiYXV0aCIsImxvZ2luIiwibG9hZCIsInd4Iiwic3RvcFB1bGxEb3duUmVmcmVzaCIsInBhZ2UiLCJnZXRJbmRleCIsImhvbWVEYXRhIiwiYmFubmVycyIsImNvbmNhdCIsInR5cGVzIiwiY2l0eU5hbWUiLCJjaXR5Q29kZSIsInNhdmUiLCJjb2RlIiwic2V0TmF2aWdhdGlvbkJhclRpdGxlIiwiaGVhZCIsIiRpbnZva2UiLCJuZXdPcmRlckxpc3QiLCJwYXJhbXMiLCJnZXRDb3Vyc2VzIiwibGVuZ3RoIiwibm9Nb3JlIiwiZSIsInNjcm9sbFRvcCIsImdldE1vcmUiLCJzaG93TW9yZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7QUFLRTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7Ozs7Ozs7Ozs7QUFqQkEsSUFBTUEsYUFBYSxDQUFDO0FBQ2xCQyxNQUFJLENBRGM7QUFFbEJDLFFBQU07QUFGWSxDQUFELENBQW5CO0lBdUJxQkMsTSxXQUhwQix3QkFBUTtBQUNQQyxRQUFNQyxnQkFBTUMsR0FBTixDQUFVLE1BQVY7QUFEQyxDQUFSLEM7Ozs7Ozs7Ozs7Ozs7O3NMQUlDQyxJLEdBQU87QUFDTEMsZUFBUyxLQURKO0FBRUxDLGFBQU9DLGVBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQkMsVUFGNUI7QUFHTEMsZUFBUztBQUNQQyxjQUFNLENBREM7QUFFUEMsY0FBTTtBQUZDLE9BSEo7QUFPTEMsWUFBTTtBQUNKRCxjQUFNLEVBREY7QUFFSkUsaUJBQVMsQ0FGTDtBQUdKQyxjQUFNO0FBSEYsT0FQRDtBQVlMQyxpQkFBVyxDQUFDO0FBQ1ZuQixZQUFJLENBRE07QUFFVkMsY0FBTTtBQUZJLE9BQUQsQ0FaTjtBQWdCTG1CLGVBQVMsRUFoQko7QUFpQkxDLGNBQVEsS0FqQkg7QUFrQkxDLG9CQUFjLENBbEJUO0FBbUJMQyxZQUFNLENBbkJEO0FBb0JMQyxpQkFBVyxDQXBCTjtBQXFCTEMsZ0JBQVUsRUFyQkw7QUFzQkxDLGNBQVEsS0F0Qkg7QUF1QkxDLGNBQVEsSUF2Qkg7QUF3QkxDLGtCQUFZLEtBeEJQO0FBeUJMQyxhQUFPO0FBekJGLEssUUEyQlJDLE8sR0FBVSxFLFFBQ2JDLE0sR0FBUyxFQUFDLFdBQVUsRUFBQyxnQkFBZSxFQUFoQixFQUFtQixxQkFBb0IsU0FBdkMsRUFBWCxFQUE2RCxRQUFPLEVBQUMscUJBQW9CLE1BQXJCLEVBQXBFLEVBQWlHLGFBQVksRUFBQyx1QkFBc0IsU0FBdkIsRUFBaUMscUJBQW9CLFdBQXJELEVBQWlFLGNBQWEsRUFBOUUsRUFBN0csRUFBK0wsU0FBUSxFQUFDLHFCQUFvQixTQUFyQixFQUF2TSxFQUF1TyxXQUFVLEVBQUMsWUFBVyxFQUFaLEVBQWpQLEUsUUFDVEMsTyxHQUFVLEVBQUMsYUFBWSxFQUFDLFlBQVcsV0FBWixFQUFiLEUsUUFDVEMsVSxHQUFhO0FBQ1JDLCtCQURRO0FBRVJDLDBCQUZRO0FBR1JDLCtCQUhRO0FBSVJqQixvQ0FKUTtBQUtSa0IsNEJBTFE7QUFNUkMsZ0NBTlE7QUFPUkMseUJBUFE7QUFRUkMsa0NBUlE7QUFTUkM7QUFUUSxLLFFBV1ZDLE0sR0FBUztBQUNQQyw4QkFBd0IsRUFEakI7QUFFUEMsNkJBQXVCO0FBRmhCLEssUUEwSFRDLE8sR0FBVTtBQUNGQyxlQURFO0FBQUEsNkZBQ1FDLEdBRFIsRUFDYUMsTUFEYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRU4sdUJBQUsxQixZQUFMLEdBQW9CeUIsR0FBcEI7QUFDQSx1QkFBS3hCLElBQUwsR0FBWXlCLE1BQVo7QUFITTtBQUFBLHlCQUlBLEtBQUtDLFdBQUwsQ0FBaUIsQ0FBakIsQ0FKQTs7QUFBQTtBQUtOLHVCQUFLQyxNQUFMOztBQUxNO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUEsSzs7Ozs7O0FBdEhWO3NDQUNrQkMsRyxFQUFLO0FBQ3JCLFVBQUlBLElBQUlDLElBQUosS0FBYSxRQUFqQixFQUEyQjtBQUN6QjtBQUNBQyxnQkFBUUMsR0FBUixDQUFZSCxJQUFJSSxNQUFoQjtBQUNEO0FBQ0QsYUFBTztBQUNMQyxlQUFPLEVBREY7QUFFTEMsY0FBTTtBQUZELE9BQVA7QUFJRDs7Ozs7Ozs7O0FBRUNoRCwrQkFBS2lELHFCQUFMLENBQTJCO0FBQ3pCQyw4QkFBWSxTQURhLEVBQ0Y7QUFDdkJDLG1DQUFpQixLQUFLcEQsS0FGRyxFQUVJO0FBQzdCcUQsMkJBQVMsc0JBQU8sQ0FBRTtBQUhPLGlCQUEzQjs7dUJBS01DLGVBQUtDLEtBQUwsRTs7Ozt1QkFDQSxLQUFLQyxJQUFMLEU7OztBQUNOLHFCQUFLM0MsTUFBTCxHQUFjLElBQWQ7QUFDQSxxQkFBSzZCLE1BQUw7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7c0JBR0ksQ0FBQyxLQUFLN0IsTUFBTixJQUFnQixDQUFDLEtBQUtsQixJOzs7OztrREFDakIsSzs7Ozt1QkFFSCxLQUFLNkQsSUFBTCxDQUFVLENBQVYsQzs7O0FBQ04scUJBQUtkLE1BQUw7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7dUJBR00sS0FBS0QsV0FBTCxDQUFpQixDQUFqQixDOzs7QUFDTixxQkFBS3pCLFNBQUwsR0FBaUIsQ0FBakI7QUFDQSxxQkFBSzBCLE1BQUw7QUFDQWUsbUJBQUdDLG1CQUFIOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztZQUVTQyxJLHVFQUFPLEU7Ozs7Ozs7dUJBQ0t6QixpQkFBTzBCLFFBQVAsQ0FBZ0I7QUFDbkM5QyxnQ0FBYyxLQUFLQSxZQURnQjtBQUVuQ0Msd0JBQU0sS0FBS0EsSUFGd0I7QUFHbkNDLDZCQUFXMkMsUUFBUSxLQUFLM0MsU0FIVztBQUluQ0MsNEJBQVUsS0FBS0E7QUFKb0IsaUJBQWhCLEM7OztBQUFqQjRDLHdCOztBQU1KLHFCQUFLeEQsT0FBTCxDQUFhRSxJQUFiLEdBQW9Cc0QsU0FBU0MsT0FBN0I7QUFDQSxxQkFBS3RELElBQUwsQ0FBVUQsSUFBVixHQUFpQnNELFNBQVNyRCxJQUExQjtBQUNBLHFCQUFLRyxTQUFMLEdBQWlCcEIsV0FBV3dFLE1BQVgsQ0FBa0JGLFNBQVNHLEtBQTNCLENBQWpCO0FBQ0EscUJBQUtwRCxPQUFMLEdBQWVpRCxTQUFTakQsT0FBeEI7QUFDQSxxQkFBS1MsS0FBTCxHQUFhd0MsU0FBU0ksUUFBdEI7QUFDQSxvQkFBSSxDQUFDaEUsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCK0QsUUFBL0IsRUFBeUM7QUFDdkN0RSxrQ0FBTXVFLElBQU4sQ0FBVyxNQUFYLEVBQW1CO0FBQ2pCMUUsMEJBQU1vRSxTQUFTSSxRQURFO0FBRWpCRywwQkFBTVAsU0FBU0s7QUFGRSxtQkFBbkI7QUFJQWpFLGlDQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEIrRCxRQUExQixHQUFxQ0wsU0FBU0ssUUFBOUM7QUFDQVQscUJBQUdZLHFCQUFILENBQXlCO0FBQ3ZCckIsMkJBQU9hLFNBQVNTLElBQVQsSUFBaUI7QUFERCxtQkFBekI7QUFHQSx1QkFBS0MsT0FBTCxDQUFhLFVBQWIsRUFBeUIsTUFBekIsRUFBaUNWLFNBQVNXLFlBQTFDO0FBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7OzsrQkFFUTtBQUNULFdBQUtyRCxNQUFMLEdBQWMsS0FBZDtBQUNEOzs7NkJBQ1E7QUFDUCxXQUFLQSxNQUFMLEdBQWMsSUFBZDtBQUNEOzs7OzRGQUNpQkgsUzs7Ozs7O0FBQ1p5RCxzQixHQUFTO0FBQ1gzRCxnQ0FBYyxLQUFLQSxZQURSO0FBRVhDLHdCQUFNLEtBQUtBLElBRkE7QUFHWEMsNkJBQVdBLFNBSEE7QUFJWEMsNEJBQVUsS0FBS0E7QUFKSixpQjs7dUJBTU9pQixpQkFBT3dDLFVBQVAsQ0FBa0JELE1BQWxCLEM7OztBQUFoQjdELHVCOztvQkFDQ0EsUUFBUUEsT0FBUixDQUFnQitELE07Ozs7O0FBQ25CLG9CQUFJM0QsYUFBYSxDQUFqQixFQUFvQjtBQUNsQix1QkFBS0osT0FBTCxHQUFlQSxRQUFRQSxPQUF2QjtBQUNEO0FBQ0QscUJBQUtJLFNBQUwsR0FBaUJBLFNBQWpCO0FBQ0EscUJBQUs0RCxNQUFMO0FBQ0EscUJBQUtsQyxNQUFMO2tEQUNPLEs7OztBQUVQLG9CQUFJMUIsWUFBWSxDQUFoQixFQUFtQixLQUFLQSxTQUFMLEdBQWlCQSxTQUFqQjtBQUNuQixvQkFBSUEsYUFBYSxDQUFqQixFQUFvQjtBQUNsQix1QkFBS0osT0FBTCxHQUFlQSxRQUFRQSxPQUF2QjtBQUNELGlCQUZELE1BRU87QUFDTCx1QkFBS0EsT0FBTCxHQUFlLEtBQUtBLE9BQUwsQ0FBYW1ELE1BQWIsQ0FBb0JuRCxRQUFRQSxPQUE1QixDQUFmO0FBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7OztpQ0FHUWlFLEMsRUFBRztBQUNkLFVBQUlBLEVBQUVDLFNBQUYsR0FBYyxHQUFsQixFQUF1QjtBQUNyQixZQUFJLENBQUMsS0FBSy9FLE9BQVYsRUFBbUI7QUFDakIsZUFBS0EsT0FBTCxHQUFlLElBQWY7QUFDQSxlQUFLMkMsTUFBTDtBQUNEO0FBQ0YsT0FMRCxNQUtPO0FBQ0wsWUFBSSxLQUFLM0MsT0FBVCxFQUFrQjtBQUNoQixlQUFLQSxPQUFMLEdBQWUsS0FBZjtBQUNBLGVBQUsyQyxNQUFMO0FBQ0Q7QUFDRjtBQUNGOzs7b0NBQ2U7QUFDZCxXQUFLcUMsT0FBTDtBQUNEOzs7Ozs7Ozs7cUJBRUssS0FBSzNELFU7Ozs7O2tEQUNBLEs7OztBQUVULHFCQUFLQSxVQUFMLEdBQWtCLElBQWxCO0FBQ0EscUJBQUs0RCxRQUFMOzt1QkFDTSxLQUFLdkMsV0FBTCxDQUFpQixLQUFLekIsU0FBTCxHQUFpQixDQUFsQyxDOzs7QUFDTixxQkFBS0ksVUFBTCxHQUFrQixLQUFsQjtBQUNBLHFCQUFLc0IsTUFBTDs7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQWxLZ0N6QyxlQUFLMEQsSTtrQkFBcEJqRSxNIiwiZmlsZSI6ImluZGV4LmpzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbiAgY29uc3QgX3Njcm9sbE5hdiA9IFt7XHJcbiAgICBpZDogMCxcclxuICAgIG5hbWU6ICflhajpg6gnXHJcbiAgfV1cclxuICBpbXBvcnQgd2VweSBmcm9tIFwid2VweVwiO1xyXG4gIGltcG9ydCBjSGVhZGVyIGZyb20gXCJAL2NvbXBvbmVudHMvaG9tZS9oZWFkZXJcIlxyXG4gIGltcG9ydCBjU3dpcGVyIGZyb20gXCJAL2NvbXBvbmVudHMvY29tbW9uL3N3aXBlclwiXHJcbiAgaW1wb3J0IGxvYWRpbmcgZnJvbSBcIkAvY29tcG9uZW50cy9jb21tb24vbG9hZGluZ1wiXHJcbiAgaW1wb3J0IGNvbnRhY3QgZnJvbSBcIkAvY29tcG9uZW50cy9jb21tb24vY29udGFjdFwiXHJcbiAgaW1wb3J0IE5hdnMgZnJvbSBcIkAvY29tcG9uZW50cy9ob21lL25hdnNcIlxyXG4gIGltcG9ydCBzY3JvbGxOYXYgZnJvbSBcIkAvY29tcG9uZW50cy9ob21lL3Njcm9sbE5hdlwiXHJcbiAgaW1wb3J0IGhlbCBmcm9tIFwiQC9jb21wb25lbnRzL2NvbW1vbi9oZWxwXCJcclxuICBpbXBvcnQgb3JkZXJpbmcgZnJvbSBcIkAvY29tcG9uZW50cy9jb21tb24vb3JkZXJpbmdcIlxyXG4gIGltcG9ydCBjQ2FyZCBmcm9tIFwiQC9jb21wb25lbnRzL2hvbWUvY0NhcmRcIlxyXG4gIGltcG9ydCBjb25maWcgZnJvbSBcIkAvYXBpL2NvbmZpZ1wiXHJcbiAgaW1wb3J0IGF1dGggZnJvbSBcIkAvYXBpL2F1dGhcIlxyXG4gIGltcG9ydCBzdG9yZSBmcm9tIFwiQC9zdG9yZS91dGlsc1wiXHJcbiAgaW1wb3J0IHtcclxuICAgIGNvbm5lY3RcclxuICB9IGZyb20gXCJ3ZXB5LXJlZHV4XCJcclxuICBAY29ubmVjdCh7XHJcbiAgICBjaXR5OiBzdG9yZS5nZXQoXCJjaXR5XCIpXHJcbiAgfSlcclxuICBleHBvcnQgZGVmYXVsdCBjbGFzcyBEaWFsb2cgZXh0ZW5kcyB3ZXB5LnBhZ2Uge1xyXG4gICAgZGF0YSA9IHtcclxuICAgICAgaXNmaXhlZDogZmFsc2UsXHJcbiAgICAgIHRoZW1lOiB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnRoZW1lQ29sb3IsXHJcbiAgICAgIHN3aXBlcnM6IHtcclxuICAgICAgICB0eXBlOiAxLFxyXG4gICAgICAgIGxpc3Q6IFtdLFxyXG4gICAgICB9LFxyXG4gICAgICBuYXZzOiB7XHJcbiAgICAgICAgbGlzdDogW10sXHJcbiAgICAgICAgZ3JpZENvbDogNSxcclxuICAgICAgICBza2luOiBmYWxzZVxyXG4gICAgICB9LFxyXG4gICAgICBzY3JvbGxOYXY6IFt7XHJcbiAgICAgICAgaWQ6IDAsXHJcbiAgICAgICAgbmFtZTogJ+WFqOmDqCdcclxuICAgICAgfV0sXHJcbiAgICAgIGNvdXJzZXM6IFtdLFxyXG4gICAgICBpc1Nob3c6IGZhbHNlLFxyXG4gICAgICBjb3Vyc2VUeXBlSWQ6IDAsXHJcbiAgICAgIHNvcnQ6IDAsXHJcbiAgICAgIHBhZ2VJbmRleDogMSxcclxuICAgICAgcGFnZVNpemU6IDEwLFxyXG4gICAgICB0b2xvYWQ6IGZhbHNlLFxyXG4gICAgICBpc0xvYWQ6IHRydWUsXHJcbiAgICAgIGxvYWRtb3Jpbmc6IGZhbHNlLFxyXG4gICAgICBfY2l0eTogJydcclxuICAgIH07XHJcbiAgICRyZXBlYXQgPSB7fTtcclxuJHByb3BzID0ge1wiY1N3aXBlclwiOntcInhtbG5zOnYtYmluZFwiOlwiXCIsXCJ2LWJpbmQ6bW9kZWwuc3luY1wiOlwic3dpcGVyc1wifSxcIk5hdnNcIjp7XCJ2LWJpbmQ6bW9kZWwuc3luY1wiOlwibmF2c1wifSxcInNjcm9sbE5hdlwiOntcInYtYmluZDppc2ZpeGVkLnN5bmNcIjpcImlzZml4ZWRcIixcInYtYmluZDptb2RlbC5zeW5jXCI6XCJzY3JvbGxOYXZcIixcInhtbG5zOnYtb25cIjpcIlwifSxcImNDYXJkXCI6e1widi1iaW5kOm1vZGVsLnN5bmNcIjpcImNvdXJzZXNcIn0sXCJsb2FkaW5nXCI6e1wieG1sbnM6d3hcIjpcIlwifX07XHJcbiRldmVudHMgPSB7XCJzY3JvbGxOYXZcIjp7XCJ2LW9uOnJldFwiOlwiZ2V0U2NyZWVuXCJ9fTtcclxuIGNvbXBvbmVudHMgPSB7XHJcbiAgICAgIGNTd2lwZXIsXHJcbiAgICAgIE5hdnMsXHJcbiAgICAgIGNIZWFkZXIsXHJcbiAgICAgIHNjcm9sbE5hdixcclxuICAgICAgY0NhcmQsXHJcbiAgICAgIGxvYWRpbmcsXHJcbiAgICAgIGhlbCxcclxuICAgICAgb3JkZXJpbmcsXHJcbiAgICAgIGNvbnRhY3RcclxuICAgIH1cclxuICAgIGNvbmZpZyA9IHtcclxuICAgICAgbmF2aWdhdGlvbkJhclRpdGxlVGV4dDogXCJcIixcclxuICAgICAgZW5hYmxlUHVsbERvd25SZWZyZXNoOiB0cnVlXHJcbiAgICB9O1xyXG4gICAgLy8g6L2s5Y+R5pqC5pe25YWI5LiN5byA5ZCvXHJcbiAgICBvblNoYXJlQXBwTWVzc2FnZShyZXMpIHtcclxuICAgICAgaWYgKHJlcy5mcm9tID09PSAnYnV0dG9uJykge1xyXG4gICAgICAgIC8vIOadpeiHqumhtemdouWGhei9rOWPkeaMiemSrlxyXG4gICAgICAgIGNvbnNvbGUubG9nKHJlcy50YXJnZXQpXHJcbiAgICAgIH1cclxuICAgICAgcmV0dXJuIHtcclxuICAgICAgICB0aXRsZTogJycsXHJcbiAgICAgICAgcGF0aDogJy9wYWdlcy9ob21lL2luZGV4J1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBhc3luYyBvbkxvYWQoKSB7XHJcbiAgICAgIHdlcHkuc2V0TmF2aWdhdGlvbkJhckNvbG9yKHtcclxuICAgICAgICBmcm9udENvbG9yOiAnI2ZmZmZmZicsIC8v5YmN5pmv6aKc6Imy5YC877yM5YyF5ous5oyJ6ZKu44CB5qCH6aKY44CB54q25oCB5qCP55qE6aKc6Imy77yM5LuF5pSv5oyBICNmZmZmZmYg5ZKMICMwMDAwMDAsXHJcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiB0aGlzLnRoZW1lLCAvL+iDjOaZr+minOiJsuWAvO+8jOacieaViOWAvOS4uuWNgeWFrei/m+WItuminOiJsixcclxuICAgICAgICBzdWNjZXNzOiByZXMgPT4ge31cclxuICAgICAgfSk7XHJcbiAgICAgIGF3YWl0IGF1dGgubG9naW4oKVxyXG4gICAgICBhd2FpdCB0aGlzLmxvYWQoKVxyXG4gICAgICB0aGlzLmlzU2hvdyA9IHRydWVcclxuICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgICAvLyB0aGlzLiRpbnZva2UoJ2NTd2lwZXInLCAnbG9hZCcsIHRoaXMubW9kZWwpXHJcbiAgICAgIC8vIHRoaXMuJGludm9rZSgnTmF2cycsICdsb2FkJywgdGhpcy5tb2RlbClcclxuICAgIH1cclxuICAgIGFzeW5jIG9uU2hvdygpIHtcclxuICAgICAgaWYgKCF0aGlzLmlzU2hvdyB8fCAhdGhpcy5jaXR5KSB7XHJcbiAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgIH1cclxuICAgICAgYXdhaXQgdGhpcy5sb2FkKDEpXHJcbiAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgIH1cclxuICAgIGFzeW5jIG9uUHVsbERvd25SZWZyZXNoKCkge1xyXG4gICAgICBhd2FpdCB0aGlzLmxvYWRjb3Vyc2VzKDEpXHJcbiAgICAgIHRoaXMucGFnZUluZGV4ID0gMVxyXG4gICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICAgIHd4LnN0b3BQdWxsRG93blJlZnJlc2goKVxyXG4gICAgfVxyXG4gICAgYXN5bmMgbG9hZChwYWdlID0gJycpIHtcclxuICAgICAgbGV0IGhvbWVEYXRhID0gYXdhaXQgY29uZmlnLmdldEluZGV4KHtcclxuICAgICAgICBjb3Vyc2VUeXBlSWQ6IHRoaXMuY291cnNlVHlwZUlkLFxyXG4gICAgICAgIHNvcnQ6IHRoaXMuc29ydCxcclxuICAgICAgICBwYWdlSW5kZXg6IHBhZ2UgfHwgdGhpcy5wYWdlSW5kZXgsXHJcbiAgICAgICAgcGFnZVNpemU6IHRoaXMucGFnZVNpemVcclxuICAgICAgfSlcclxuICAgICAgdGhpcy5zd2lwZXJzLmxpc3QgPSBob21lRGF0YS5iYW5uZXJzXHJcbiAgICAgIHRoaXMubmF2cy5saXN0ID0gaG9tZURhdGEubmF2c1xyXG4gICAgICB0aGlzLnNjcm9sbE5hdiA9IF9zY3JvbGxOYXYuY29uY2F0KGhvbWVEYXRhLnR5cGVzKVxyXG4gICAgICB0aGlzLmNvdXJzZXMgPSBob21lRGF0YS5jb3Vyc2VzXHJcbiAgICAgIHRoaXMuX2NpdHkgPSBob21lRGF0YS5jaXR5TmFtZVxyXG4gICAgICBpZiAoIXdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuY2l0eUNvZGUpIHtcclxuICAgICAgICBzdG9yZS5zYXZlKCdjaXR5Jywge1xyXG4gICAgICAgICAgbmFtZTogaG9tZURhdGEuY2l0eU5hbWUsXHJcbiAgICAgICAgICBjb2RlOiBob21lRGF0YS5jaXR5Q29kZVxyXG4gICAgICAgIH0pXHJcbiAgICAgICAgd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5jaXR5Q29kZSA9IGhvbWVEYXRhLmNpdHlDb2RlXHJcbiAgICAgICAgd3guc2V0TmF2aWdhdGlvbkJhclRpdGxlKHtcclxuICAgICAgICAgIHRpdGxlOiBob21lRGF0YS5oZWFkIHx8ICfljY7lv4PmoaXkvZPpqozokKUnXHJcbiAgICAgICAgfSlcclxuICAgICAgICB0aGlzLiRpbnZva2UoJ29yZGVyaW5nJywgJ2xvYWQnLCBob21lRGF0YS5uZXdPcmRlckxpc3QpXHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIHNob3dNb3JlKCkge1xyXG4gICAgICB0aGlzLmlzTG9hZCA9IGZhbHNlXHJcbiAgICB9XHJcbiAgICBub01vcmUoKSB7XHJcbiAgICAgIHRoaXMuaXNMb2FkID0gdHJ1ZVxyXG4gICAgfVxyXG4gICAgYXN5bmMgbG9hZGNvdXJzZXMocGFnZUluZGV4KSB7XHJcbiAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgY291cnNlVHlwZUlkOiB0aGlzLmNvdXJzZVR5cGVJZCxcclxuICAgICAgICBzb3J0OiB0aGlzLnNvcnQsXHJcbiAgICAgICAgcGFnZUluZGV4OiBwYWdlSW5kZXgsXHJcbiAgICAgICAgcGFnZVNpemU6IHRoaXMucGFnZVNpemVcclxuICAgICAgfVxyXG4gICAgICBsZXQgY291cnNlcyA9IGF3YWl0IGNvbmZpZy5nZXRDb3Vyc2VzKHBhcmFtcylcclxuICAgICAgaWYgKCFjb3Vyc2VzLmNvdXJzZXMubGVuZ3RoKSB7XHJcbiAgICAgICAgaWYgKHBhZ2VJbmRleCA9PSAxKSB7XHJcbiAgICAgICAgICB0aGlzLmNvdXJzZXMgPSBjb3Vyc2VzLmNvdXJzZXNcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5wYWdlSW5kZXggPSBwYWdlSW5kZXhcclxuICAgICAgICB0aGlzLm5vTW9yZSgpXHJcbiAgICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgICAgIHJldHVybiBmYWxzZVxyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGlmIChwYWdlSW5kZXggPiAxKSB0aGlzLnBhZ2VJbmRleCA9IHBhZ2VJbmRleFxyXG4gICAgICAgIGlmIChwYWdlSW5kZXggPT0gMSkge1xyXG4gICAgICAgICAgdGhpcy5jb3Vyc2VzID0gY291cnNlcy5jb3Vyc2VzXHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHRoaXMuY291cnNlcyA9IHRoaXMuY291cnNlcy5jb25jYXQoY291cnNlcy5jb3Vyc2VzKVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgb25QYWdlU2Nyb2xsKGUpIHtcclxuICAgICAgaWYgKGUuc2Nyb2xsVG9wID4gNDEwKSB7XHJcbiAgICAgICAgaWYgKCF0aGlzLmlzZml4ZWQpIHtcclxuICAgICAgICAgIHRoaXMuaXNmaXhlZCA9IHRydWVcclxuICAgICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgICB9XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgaWYgKHRoaXMuaXNmaXhlZCkge1xyXG4gICAgICAgICAgdGhpcy5pc2ZpeGVkID0gZmFsc2VcclxuICAgICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIG9uUmVhY2hCb3R0b20oKSB7XHJcbiAgICAgIHRoaXMuZ2V0TW9yZSgpXHJcbiAgICB9XHJcbiAgICBhc3luYyBnZXRNb3JlKCkge1xyXG4gICAgICBpZiAodGhpcy5sb2FkbW9yaW5nKSB7XHJcbiAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgIH1cclxuICAgICAgdGhpcy5sb2FkbW9yaW5nID0gdHJ1ZVxyXG4gICAgICB0aGlzLnNob3dNb3JlKClcclxuICAgICAgYXdhaXQgdGhpcy5sb2FkY291cnNlcyh0aGlzLnBhZ2VJbmRleCArIDEpXHJcbiAgICAgIHRoaXMubG9hZG1vcmluZyA9IGZhbHNlXHJcbiAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgIH1cclxuICAgIG1ldGhvZHMgPSB7XHJcbiAgICAgIGFzeW5jIGdldFNjcmVlbihrZXksIHNjcmVlbikge1xyXG4gICAgICAgIHRoaXMuY291cnNlVHlwZUlkID0ga2V5XHJcbiAgICAgICAgdGhpcy5zb3J0ID0gc2NyZWVuXHJcbiAgICAgICAgYXdhaXQgdGhpcy5sb2FkY291cnNlcygxKVxyXG4gICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgfSxcclxuICAgIH07XHJcbiAgfVxyXG4iXX0=