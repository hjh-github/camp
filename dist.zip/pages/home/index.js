"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _dec, _class;

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _header = require('./../../components/home/header.js');

var _header2 = _interopRequireDefault(_header);

var _swiper = require('./../../components/common/swiper.js');

var _swiper2 = _interopRequireDefault(_swiper);

var _loading = require('./../../components/common/loading.js');

var _loading2 = _interopRequireDefault(_loading);

var _contact = require('./../../components/common/contact.js');

var _contact2 = _interopRequireDefault(_contact);

var _navs = require('./../../components/home/navs.js');

var _navs2 = _interopRequireDefault(_navs);

var _scrollNav2 = require('./../../components/home/scrollNav.js');

var _scrollNav3 = _interopRequireDefault(_scrollNav2);

var _help = require('./../../components/common/help.js');

var _help2 = _interopRequireDefault(_help);

var _ordering = require('./../../components/common/ordering.js');

var _ordering2 = _interopRequireDefault(_ordering);

var _cCard = require('./../../components/home/cCard.js');

var _cCard2 = _interopRequireDefault(_cCard);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

var _utils = require('./../../store/utils.js');

var _utils2 = _interopRequireDefault(_utils);

var _wepyRedux = require('./../../npm/wepy-redux/lib/index.js');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var _scrollNav = [{
  id: 0,
  name: '全部'
}];
var Dialog = (_dec = (0, _wepyRedux.connect)({
  city: _utils2.default.get("city")
}), _dec(_class = function (_wepy$page) {
  _inherits(Dialog, _wepy$page);

  function Dialog() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, Dialog);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.data = {
      isfixed: false,
      theme: _wepy2.default.$instance.globalData.themeColor,
      swipers: {
        type: 1,
        list: []
      },
      navs: {
        list: [],
        gridCol: 5,
        skin: false
      },
      scrollNav: [{
        id: 0,
        name: '全部'
      }],
      courses: [],
      isShow: false,
      courseTypeId: 0,
      sort: 0,
      pageIndex: 1,
      pageSize: 10,
      toload: false,
      isLoad: true,
      loadmoring: false,
      _city: '',
      member: {}
    }, _this.$repeat = {}, _this.$props = { "cSwiper": { "xmlns:v-bind": "", "v-bind:model.sync": "swipers" }, "Navs": { "v-bind:model.sync": "navs" }, "scrollNav": { "v-bind:isfixed.sync": "isfixed", "v-bind:model.sync": "scrollNav", "xmlns:v-on": "" }, "cCard": { "v-bind:model.sync": "courses" }, "loading": { "xmlns:wx": "" } }, _this.$events = { "scrollNav": { "v-on:ret": "getScreen" } }, _this.components = {
      cSwiper: _swiper2.default,
      Navs: _navs2.default,
      cHeader: _header2.default,
      scrollNav: _scrollNav3.default,
      cCard: _cCard2.default,
      loading: _loading2.default,
      hel: _help2.default,
      ordering: _ordering2.default,
      contact: _contact2.default
    }, _this.config = {
      navigationBarTitleText: "",
      enablePullDownRefresh: true
    }, _this.methods = {
      getScreen: function () {
        var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(key, screen) {
          return regeneratorRuntime.wrap(function _callee$(_context) {
            while (1) {
              switch (_context.prev = _context.next) {
                case 0:
                  this.courseTypeId = key;
                  this.sort = screen;
                  _context.next = 4;
                  return this.loadcourses(1);

                case 4:
                  this.$apply();

                case 5:
                case "end":
                  return _context.stop();
              }
            }
          }, _callee, this);
        }));

        function getScreen(_x, _x2) {
          return _ref2.apply(this, arguments);
        }

        return getScreen;
      }()
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(Dialog, [{
    key: "onShareAppMessage",

    // 转发暂时先不开启
    value: function onShareAppMessage(res) {
      if (res.from === 'button') {
        // 来自页面内转发按钮
        console.log(res.target);
      }
      return {
        title: '',
        path: '/pages/home/index?agentId=' + this.member.agentId
      };
    }
  }, {
    key: "onLoad",
    value: function () {
      var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(opt) {
        return regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _wepy2.default.setNavigationBarColor({
                  frontColor: '#ffffff', //前景颜色值，包括按钮、标题、状态栏的颜色，仅支持 #ffffff 和 #000000,
                  backgroundColor: this.theme, //背景颜色值，有效值为十六进制颜色,
                  success: function success(res) {}
                });
                _context2.next = 3;
                return _auth2.default.login();

              case 3:
                this.member = _wepy2.default.getStorageSync('member');
                _context2.next = 6;
                return this.load();

              case 6:
                this.isShow = true;
                this.$apply();

              case 8:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));

      function onLoad(_x3) {
        return _ref3.apply(this, arguments);
      }

      return onLoad;
    }()
  }, {
    key: "onShow",
    value: function () {
      var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
        return regeneratorRuntime.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                if (!(_wepy2.default.$instance.globalData.scene != 1007)) {
                  _context3.next = 3;
                  break;
                }

                if (!(!this.isShow || !this.city)) {
                  _context3.next = 3;
                  break;
                }

                return _context3.abrupt("return", false);

              case 3:
                _context3.next = 5;
                return this.load(1);

              case 5:
                this.$apply();

              case 6:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this);
      }));

      function onShow() {
        return _ref4.apply(this, arguments);
      }

      return onShow;
    }()
  }, {
    key: "onPullDownRefresh",
    value: function () {
      var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
        return regeneratorRuntime.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                _context4.next = 2;
                return this.loadcourses(1);

              case 2:
                this.pageIndex = 1;
                this.$apply();
                wx.stopPullDownRefresh();

              case 5:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, this);
      }));

      function onPullDownRefresh() {
        return _ref5.apply(this, arguments);
      }

      return onPullDownRefresh;
    }()
  }, {
    key: "load",
    value: function () {
      var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
        var page = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
        var homeData;
        return regeneratorRuntime.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                _context5.next = 2;
                return _config2.default.getIndex({
                  courseTypeId: this.courseTypeId,
                  sort: this.sort,
                  pageIndex: page || this.pageIndex,
                  pageSize: this.pageSize
                });

              case 2:
                homeData = _context5.sent;

                wx.setNavigationBarTitle({
                  title: homeData.head
                });
                this.swipers.list = homeData.banners;
                this.navs.list = homeData.navs;
                this.scrollNav = _scrollNav.concat(homeData.types);
                this.courses = homeData.courses;
                this._city = homeData.cityName;
                if (!_wepy2.default.$instance.globalData.cityCode) {
                  _utils2.default.save('city', {
                    name: homeData.cityName,
                    code: homeData.cityCode
                  });
                  _wepy2.default.$instance.globalData.cityCode = homeData.cityCode;
                  this.$apply();
                  this.$invoke('ordering', 'load', homeData.newOrderList);
                }

              case 10:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5, this);
      }));

      function load() {
        return _ref6.apply(this, arguments);
      }

      return load;
    }()
  }, {
    key: "showMore",
    value: function showMore() {
      this.isLoad = false;
    }
  }, {
    key: "noMore",
    value: function noMore() {
      this.isLoad = true;
    }
  }, {
    key: "loadcourses",
    value: function () {
      var _ref7 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee6(pageIndex) {
        var params, courses;
        return regeneratorRuntime.wrap(function _callee6$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                params = {
                  courseTypeId: this.courseTypeId,
                  sort: this.sort,
                  pageIndex: pageIndex,
                  pageSize: this.pageSize
                };
                _context6.next = 3;
                return _config2.default.getCourses(params);

              case 3:
                courses = _context6.sent;

                if (courses.courses.length) {
                  _context6.next = 12;
                  break;
                }

                if (pageIndex == 1) {
                  this.courses = courses.courses;
                }
                this.pageIndex = pageIndex;
                this.noMore();
                this.$apply();
                return _context6.abrupt("return", false);

              case 12:
                if (pageIndex > 1) this.pageIndex = pageIndex;
                if (pageIndex == 1) {
                  this.courses = courses.courses;
                } else {
                  this.courses = this.courses.concat(courses.courses);
                }

              case 14:
              case "end":
                return _context6.stop();
            }
          }
        }, _callee6, this);
      }));

      function loadcourses(_x5) {
        return _ref7.apply(this, arguments);
      }

      return loadcourses;
    }()
  }, {
    key: "onPageScroll",
    value: function onPageScroll(e) {
      if (e.scrollTop > 410) {
        if (!this.isfixed) {
          this.isfixed = true;
          this.$apply();
        }
      } else {
        if (this.isfixed) {
          this.isfixed = false;
          this.$apply();
        }
      }
    }
  }, {
    key: "onReachBottom",
    value: function onReachBottom() {
      this.getMore();
    }
  }, {
    key: "getMore",
    value: function () {
      var _ref8 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee7() {
        return regeneratorRuntime.wrap(function _callee7$(_context7) {
          while (1) {
            switch (_context7.prev = _context7.next) {
              case 0:
                if (!this.loadmoring) {
                  _context7.next = 2;
                  break;
                }

                return _context7.abrupt("return", false);

              case 2:
                this.loadmoring = true;
                this.showMore();
                _context7.next = 6;
                return this.loadcourses(this.pageIndex + 1);

              case 6:
                this.loadmoring = false;
                this.$apply();

              case 8:
              case "end":
                return _context7.stop();
            }
          }
        }, _callee7, this);
      }));

      function getMore() {
        return _ref8.apply(this, arguments);
      }

      return getMore;
    }()
  }]);

  return Dialog;
}(_wepy2.default.page)) || _class);

Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/home/index'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LmpzIl0sIm5hbWVzIjpbIl9zY3JvbGxOYXYiLCJpZCIsIm5hbWUiLCJEaWFsb2ciLCJjaXR5Iiwic3RvcmUiLCJnZXQiLCJkYXRhIiwiaXNmaXhlZCIsInRoZW1lIiwid2VweSIsIiRpbnN0YW5jZSIsImdsb2JhbERhdGEiLCJ0aGVtZUNvbG9yIiwic3dpcGVycyIsInR5cGUiLCJsaXN0IiwibmF2cyIsImdyaWRDb2wiLCJza2luIiwic2Nyb2xsTmF2IiwiY291cnNlcyIsImlzU2hvdyIsImNvdXJzZVR5cGVJZCIsInNvcnQiLCJwYWdlSW5kZXgiLCJwYWdlU2l6ZSIsInRvbG9hZCIsImlzTG9hZCIsImxvYWRtb3JpbmciLCJfY2l0eSIsIm1lbWJlciIsIiRyZXBlYXQiLCIkcHJvcHMiLCIkZXZlbnRzIiwiY29tcG9uZW50cyIsImNTd2lwZXIiLCJOYXZzIiwiY0hlYWRlciIsImNDYXJkIiwibG9hZGluZyIsImhlbCIsIm9yZGVyaW5nIiwiY29udGFjdCIsImNvbmZpZyIsIm5hdmlnYXRpb25CYXJUaXRsZVRleHQiLCJlbmFibGVQdWxsRG93blJlZnJlc2giLCJtZXRob2RzIiwiZ2V0U2NyZWVuIiwia2V5Iiwic2NyZWVuIiwibG9hZGNvdXJzZXMiLCIkYXBwbHkiLCJyZXMiLCJmcm9tIiwiY29uc29sZSIsImxvZyIsInRhcmdldCIsInRpdGxlIiwicGF0aCIsImFnZW50SWQiLCJvcHQiLCJzZXROYXZpZ2F0aW9uQmFyQ29sb3IiLCJmcm9udENvbG9yIiwiYmFja2dyb3VuZENvbG9yIiwic3VjY2VzcyIsImF1dGgiLCJsb2dpbiIsImdldFN0b3JhZ2VTeW5jIiwibG9hZCIsInNjZW5lIiwid3giLCJzdG9wUHVsbERvd25SZWZyZXNoIiwicGFnZSIsImdldEluZGV4IiwiaG9tZURhdGEiLCJzZXROYXZpZ2F0aW9uQmFyVGl0bGUiLCJoZWFkIiwiYmFubmVycyIsImNvbmNhdCIsInR5cGVzIiwiY2l0eU5hbWUiLCJjaXR5Q29kZSIsInNhdmUiLCJjb2RlIiwiJGludm9rZSIsIm5ld09yZGVyTGlzdCIsInBhcmFtcyIsImdldENvdXJzZXMiLCJsZW5ndGgiLCJub01vcmUiLCJlIiwic2Nyb2xsVG9wIiwiZ2V0TW9yZSIsInNob3dNb3JlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUtFOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7Ozs7Ozs7OztBQWpCQSxJQUFNQSxhQUFhLENBQUM7QUFDbEJDLE1BQUksQ0FEYztBQUVsQkMsUUFBTTtBQUZZLENBQUQsQ0FBbkI7SUF1QnFCQyxNLFdBSHBCLHdCQUFRO0FBQ1BDLFFBQU1DLGdCQUFNQyxHQUFOLENBQVUsTUFBVjtBQURDLENBQVIsQzs7Ozs7Ozs7Ozs7Ozs7c0xBSUNDLEksR0FBTztBQUNMQyxlQUFTLEtBREo7QUFFTEMsYUFBT0MsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCQyxVQUY1QjtBQUdMQyxlQUFTO0FBQ1BDLGNBQU0sQ0FEQztBQUVQQyxjQUFNO0FBRkMsT0FISjtBQU9MQyxZQUFNO0FBQ0pELGNBQU0sRUFERjtBQUVKRSxpQkFBUyxDQUZMO0FBR0pDLGNBQU07QUFIRixPQVBEO0FBWUxDLGlCQUFXLENBQUM7QUFDVm5CLFlBQUksQ0FETTtBQUVWQyxjQUFNO0FBRkksT0FBRCxDQVpOO0FBZ0JMbUIsZUFBUyxFQWhCSjtBQWlCTEMsY0FBUSxLQWpCSDtBQWtCTEMsb0JBQWMsQ0FsQlQ7QUFtQkxDLFlBQU0sQ0FuQkQ7QUFvQkxDLGlCQUFXLENBcEJOO0FBcUJMQyxnQkFBVSxFQXJCTDtBQXNCTEMsY0FBUSxLQXRCSDtBQXVCTEMsY0FBUSxJQXZCSDtBQXdCTEMsa0JBQVksS0F4QlA7QUF5QkxDLGFBQU8sRUF6QkY7QUEwQkxDLGNBQU87QUExQkYsSyxRQTRCUkMsTyxHQUFVLEUsUUFDYkMsTSxHQUFTLEVBQUMsV0FBVSxFQUFDLGdCQUFlLEVBQWhCLEVBQW1CLHFCQUFvQixTQUF2QyxFQUFYLEVBQTZELFFBQU8sRUFBQyxxQkFBb0IsTUFBckIsRUFBcEUsRUFBaUcsYUFBWSxFQUFDLHVCQUFzQixTQUF2QixFQUFpQyxxQkFBb0IsV0FBckQsRUFBaUUsY0FBYSxFQUE5RSxFQUE3RyxFQUErTCxTQUFRLEVBQUMscUJBQW9CLFNBQXJCLEVBQXZNLEVBQXVPLFdBQVUsRUFBQyxZQUFXLEVBQVosRUFBalAsRSxRQUNUQyxPLEdBQVUsRUFBQyxhQUFZLEVBQUMsWUFBVyxXQUFaLEVBQWIsRSxRQUNUQyxVLEdBQWE7QUFDUkMsK0JBRFE7QUFFUkMsMEJBRlE7QUFHUkMsK0JBSFE7QUFJUmxCLG9DQUpRO0FBS1JtQiw0QkFMUTtBQU1SQyxnQ0FOUTtBQU9SQyx5QkFQUTtBQVFSQyxrQ0FSUTtBQVNSQztBQVRRLEssUUFXVkMsTSxHQUFTO0FBQ1BDLDhCQUF3QixFQURqQjtBQUVQQyw2QkFBdUI7QUFGaEIsSyxRQTRIVEMsTyxHQUFVO0FBQ0ZDLGVBREU7QUFBQSw2RkFDUUMsR0FEUixFQUNhQyxNQURiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFTix1QkFBSzNCLFlBQUwsR0FBb0IwQixHQUFwQjtBQUNBLHVCQUFLekIsSUFBTCxHQUFZMEIsTUFBWjtBQUhNO0FBQUEseUJBSUEsS0FBS0MsV0FBTCxDQUFpQixDQUFqQixDQUpBOztBQUFBO0FBS04sdUJBQUtDLE1BQUw7O0FBTE07QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQSxLOzs7Ozs7QUF4SFY7c0NBQ2tCQyxHLEVBQUs7QUFDckIsVUFBSUEsSUFBSUMsSUFBSixLQUFhLFFBQWpCLEVBQTJCO0FBQ3pCO0FBQ0FDLGdCQUFRQyxHQUFSLENBQVlILElBQUlJLE1BQWhCO0FBQ0Q7QUFDRCxhQUFPO0FBQ0xDLGVBQU8sRUFERjtBQUVMQyxjQUFNLCtCQUErQixLQUFLNUIsTUFBTCxDQUFZNkI7QUFGNUMsT0FBUDtBQUlEOzs7OzRGQUNZQyxHOzs7OztBQUNYbkQsK0JBQUtvRCxxQkFBTCxDQUEyQjtBQUN6QkMsOEJBQVksU0FEYSxFQUNGO0FBQ3ZCQyxtQ0FBaUIsS0FBS3ZELEtBRkcsRUFFSTtBQUM3QndELDJCQUFTLHNCQUFPLENBQUU7QUFITyxpQkFBM0I7O3VCQUtNQyxlQUFLQyxLQUFMLEU7OztBQUNOLHFCQUFLcEMsTUFBTCxHQUFjckIsZUFBSzBELGNBQUwsQ0FBb0IsUUFBcEIsQ0FBZDs7dUJBQ00sS0FBS0MsSUFBTCxFOzs7QUFDTixxQkFBSy9DLE1BQUwsR0FBYyxJQUFkO0FBQ0EscUJBQUs4QixNQUFMOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7c0JBR0kxQyxlQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEIwRCxLQUExQixJQUFtQyxJOzs7OztzQkFDakMsQ0FBQyxLQUFLaEQsTUFBTixJQUFnQixDQUFDLEtBQUtsQixJOzs7OztrREFDakIsSzs7Ozt1QkFHTCxLQUFLaUUsSUFBTCxDQUFVLENBQVYsQzs7O0FBQ04scUJBQUtqQixNQUFMOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3VCQUdNLEtBQUtELFdBQUwsQ0FBaUIsQ0FBakIsQzs7O0FBQ04scUJBQUsxQixTQUFMLEdBQWlCLENBQWpCO0FBQ0EscUJBQUsyQixNQUFMO0FBQ0FtQixtQkFBR0MsbUJBQUg7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1lBRVNDLEksdUVBQU8sRTs7Ozs7Ozt1QkFDSzdCLGlCQUFPOEIsUUFBUCxDQUFnQjtBQUNuQ25ELGdDQUFjLEtBQUtBLFlBRGdCO0FBRW5DQyx3QkFBTSxLQUFLQSxJQUZ3QjtBQUduQ0MsNkJBQVdnRCxRQUFRLEtBQUtoRCxTQUhXO0FBSW5DQyw0QkFBVSxLQUFLQTtBQUpvQixpQkFBaEIsQzs7O0FBQWpCaUQsd0I7O0FBTUpKLG1CQUFHSyxxQkFBSCxDQUF5QjtBQUN2QmxCLHlCQUFPaUIsU0FBU0U7QUFETyxpQkFBekI7QUFHQSxxQkFBSy9ELE9BQUwsQ0FBYUUsSUFBYixHQUFvQjJELFNBQVNHLE9BQTdCO0FBQ0EscUJBQUs3RCxJQUFMLENBQVVELElBQVYsR0FBaUIyRCxTQUFTMUQsSUFBMUI7QUFDQSxxQkFBS0csU0FBTCxHQUFpQnBCLFdBQVcrRSxNQUFYLENBQWtCSixTQUFTSyxLQUEzQixDQUFqQjtBQUNBLHFCQUFLM0QsT0FBTCxHQUFlc0QsU0FBU3RELE9BQXhCO0FBQ0EscUJBQUtTLEtBQUwsR0FBYTZDLFNBQVNNLFFBQXRCO0FBQ0Esb0JBQUksQ0FBQ3ZFLGVBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQnNFLFFBQS9CLEVBQXlDO0FBQ3ZDN0Usa0NBQU04RSxJQUFOLENBQVcsTUFBWCxFQUFtQjtBQUNqQmpGLDBCQUFNeUUsU0FBU00sUUFERTtBQUVqQkcsMEJBQU1ULFNBQVNPO0FBRkUsbUJBQW5CO0FBSUF4RSxpQ0FBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCc0UsUUFBMUIsR0FBcUNQLFNBQVNPLFFBQTlDO0FBQ0EsdUJBQUs5QixNQUFMO0FBQ0EsdUJBQUtpQyxPQUFMLENBQWEsVUFBYixFQUF5QixNQUF6QixFQUFpQ1YsU0FBU1csWUFBMUM7QUFDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7OytCQUVRO0FBQ1QsV0FBSzFELE1BQUwsR0FBYyxLQUFkO0FBQ0Q7Ozs2QkFDUTtBQUNQLFdBQUtBLE1BQUwsR0FBYyxJQUFkO0FBQ0Q7Ozs7NEZBQ2lCSCxTOzs7Ozs7QUFDWjhELHNCLEdBQVM7QUFDWGhFLGdDQUFjLEtBQUtBLFlBRFI7QUFFWEMsd0JBQU0sS0FBS0EsSUFGQTtBQUdYQyw2QkFBV0EsU0FIQTtBQUlYQyw0QkFBVSxLQUFLQTtBQUpKLGlCOzt1QkFNT2tCLGlCQUFPNEMsVUFBUCxDQUFrQkQsTUFBbEIsQzs7O0FBQWhCbEUsdUI7O29CQUNDQSxRQUFRQSxPQUFSLENBQWdCb0UsTTs7Ozs7QUFDbkIsb0JBQUloRSxhQUFhLENBQWpCLEVBQW9CO0FBQ2xCLHVCQUFLSixPQUFMLEdBQWVBLFFBQVFBLE9BQXZCO0FBQ0Q7QUFDRCxxQkFBS0ksU0FBTCxHQUFpQkEsU0FBakI7QUFDQSxxQkFBS2lFLE1BQUw7QUFDQSxxQkFBS3RDLE1BQUw7a0RBQ08sSzs7O0FBRVAsb0JBQUkzQixZQUFZLENBQWhCLEVBQW1CLEtBQUtBLFNBQUwsR0FBaUJBLFNBQWpCO0FBQ25CLG9CQUFJQSxhQUFhLENBQWpCLEVBQW9CO0FBQ2xCLHVCQUFLSixPQUFMLEdBQWVBLFFBQVFBLE9BQXZCO0FBQ0QsaUJBRkQsTUFFTztBQUNMLHVCQUFLQSxPQUFMLEdBQWUsS0FBS0EsT0FBTCxDQUFhMEQsTUFBYixDQUFvQjFELFFBQVFBLE9BQTVCLENBQWY7QUFDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7O2lDQUdRc0UsQyxFQUFHO0FBQ2QsVUFBSUEsRUFBRUMsU0FBRixHQUFjLEdBQWxCLEVBQXVCO0FBQ3JCLFlBQUksQ0FBQyxLQUFLcEYsT0FBVixFQUFtQjtBQUNqQixlQUFLQSxPQUFMLEdBQWUsSUFBZjtBQUNBLGVBQUs0QyxNQUFMO0FBQ0Q7QUFDRixPQUxELE1BS087QUFDTCxZQUFJLEtBQUs1QyxPQUFULEVBQWtCO0FBQ2hCLGVBQUtBLE9BQUwsR0FBZSxLQUFmO0FBQ0EsZUFBSzRDLE1BQUw7QUFDRDtBQUNGO0FBQ0Y7OztvQ0FDZTtBQUNkLFdBQUt5QyxPQUFMO0FBQ0Q7Ozs7Ozs7OztxQkFFSyxLQUFLaEUsVTs7Ozs7a0RBQ0EsSzs7O0FBRVQscUJBQUtBLFVBQUwsR0FBa0IsSUFBbEI7QUFDQSxxQkFBS2lFLFFBQUw7O3VCQUNNLEtBQUszQyxXQUFMLENBQWlCLEtBQUsxQixTQUFMLEdBQWlCLENBQWxDLEM7OztBQUNOLHFCQUFLSSxVQUFMLEdBQWtCLEtBQWxCO0FBQ0EscUJBQUt1QixNQUFMOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBcktnQzFDLGVBQUsrRCxJO2tCQUFwQnRFLE0iLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuICBjb25zdCBfc2Nyb2xsTmF2ID0gW3tcclxuICAgIGlkOiAwLFxyXG4gICAgbmFtZTogJ+WFqOmDqCdcclxuICB9XVxyXG4gIGltcG9ydCB3ZXB5IGZyb20gXCJ3ZXB5XCI7XHJcbiAgaW1wb3J0IGNIZWFkZXIgZnJvbSBcIkAvY29tcG9uZW50cy9ob21lL2hlYWRlclwiXHJcbiAgaW1wb3J0IGNTd2lwZXIgZnJvbSBcIkAvY29tcG9uZW50cy9jb21tb24vc3dpcGVyXCJcclxuICBpbXBvcnQgbG9hZGluZyBmcm9tIFwiQC9jb21wb25lbnRzL2NvbW1vbi9sb2FkaW5nXCJcclxuICBpbXBvcnQgY29udGFjdCBmcm9tIFwiQC9jb21wb25lbnRzL2NvbW1vbi9jb250YWN0XCJcclxuICBpbXBvcnQgTmF2cyBmcm9tIFwiQC9jb21wb25lbnRzL2hvbWUvbmF2c1wiXHJcbiAgaW1wb3J0IHNjcm9sbE5hdiBmcm9tIFwiQC9jb21wb25lbnRzL2hvbWUvc2Nyb2xsTmF2XCJcclxuICBpbXBvcnQgaGVsIGZyb20gXCJAL2NvbXBvbmVudHMvY29tbW9uL2hlbHBcIlxyXG4gIGltcG9ydCBvcmRlcmluZyBmcm9tIFwiQC9jb21wb25lbnRzL2NvbW1vbi9vcmRlcmluZ1wiXHJcbiAgaW1wb3J0IGNDYXJkIGZyb20gXCJAL2NvbXBvbmVudHMvaG9tZS9jQ2FyZFwiXHJcbiAgaW1wb3J0IGNvbmZpZyBmcm9tIFwiQC9hcGkvY29uZmlnXCJcclxuICBpbXBvcnQgYXV0aCBmcm9tIFwiQC9hcGkvYXV0aFwiXHJcbiAgaW1wb3J0IHN0b3JlIGZyb20gXCJAL3N0b3JlL3V0aWxzXCJcclxuICBpbXBvcnQge1xyXG4gICAgY29ubmVjdFxyXG4gIH0gZnJvbSBcIndlcHktcmVkdXhcIlxyXG4gIEBjb25uZWN0KHtcclxuICAgIGNpdHk6IHN0b3JlLmdldChcImNpdHlcIilcclxuICB9KVxyXG4gIGV4cG9ydCBkZWZhdWx0IGNsYXNzIERpYWxvZyBleHRlbmRzIHdlcHkucGFnZSB7XHJcbiAgICBkYXRhID0ge1xyXG4gICAgICBpc2ZpeGVkOiBmYWxzZSxcclxuICAgICAgdGhlbWU6IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEudGhlbWVDb2xvcixcclxuICAgICAgc3dpcGVyczoge1xyXG4gICAgICAgIHR5cGU6IDEsXHJcbiAgICAgICAgbGlzdDogW10sXHJcbiAgICAgIH0sXHJcbiAgICAgIG5hdnM6IHtcclxuICAgICAgICBsaXN0OiBbXSxcclxuICAgICAgICBncmlkQ29sOiA1LFxyXG4gICAgICAgIHNraW46IGZhbHNlXHJcbiAgICAgIH0sXHJcbiAgICAgIHNjcm9sbE5hdjogW3tcclxuICAgICAgICBpZDogMCxcclxuICAgICAgICBuYW1lOiAn5YWo6YOoJ1xyXG4gICAgICB9XSxcclxuICAgICAgY291cnNlczogW10sXHJcbiAgICAgIGlzU2hvdzogZmFsc2UsXHJcbiAgICAgIGNvdXJzZVR5cGVJZDogMCxcclxuICAgICAgc29ydDogMCxcclxuICAgICAgcGFnZUluZGV4OiAxLFxyXG4gICAgICBwYWdlU2l6ZTogMTAsXHJcbiAgICAgIHRvbG9hZDogZmFsc2UsXHJcbiAgICAgIGlzTG9hZDogdHJ1ZSxcclxuICAgICAgbG9hZG1vcmluZzogZmFsc2UsXHJcbiAgICAgIF9jaXR5OiAnJyxcclxuICAgICAgbWVtYmVyOnt9XHJcbiAgICB9O1xyXG4gICAkcmVwZWF0ID0ge307XHJcbiRwcm9wcyA9IHtcImNTd2lwZXJcIjp7XCJ4bWxuczp2LWJpbmRcIjpcIlwiLFwidi1iaW5kOm1vZGVsLnN5bmNcIjpcInN3aXBlcnNcIn0sXCJOYXZzXCI6e1widi1iaW5kOm1vZGVsLnN5bmNcIjpcIm5hdnNcIn0sXCJzY3JvbGxOYXZcIjp7XCJ2LWJpbmQ6aXNmaXhlZC5zeW5jXCI6XCJpc2ZpeGVkXCIsXCJ2LWJpbmQ6bW9kZWwuc3luY1wiOlwic2Nyb2xsTmF2XCIsXCJ4bWxuczp2LW9uXCI6XCJcIn0sXCJjQ2FyZFwiOntcInYtYmluZDptb2RlbC5zeW5jXCI6XCJjb3Vyc2VzXCJ9LFwibG9hZGluZ1wiOntcInhtbG5zOnd4XCI6XCJcIn19O1xyXG4kZXZlbnRzID0ge1wic2Nyb2xsTmF2XCI6e1widi1vbjpyZXRcIjpcImdldFNjcmVlblwifX07XHJcbiBjb21wb25lbnRzID0ge1xyXG4gICAgICBjU3dpcGVyLFxyXG4gICAgICBOYXZzLFxyXG4gICAgICBjSGVhZGVyLFxyXG4gICAgICBzY3JvbGxOYXYsXHJcbiAgICAgIGNDYXJkLFxyXG4gICAgICBsb2FkaW5nLFxyXG4gICAgICBoZWwsXHJcbiAgICAgIG9yZGVyaW5nLFxyXG4gICAgICBjb250YWN0XHJcbiAgICB9XHJcbiAgICBjb25maWcgPSB7XHJcbiAgICAgIG5hdmlnYXRpb25CYXJUaXRsZVRleHQ6IFwiXCIsXHJcbiAgICAgIGVuYWJsZVB1bGxEb3duUmVmcmVzaDogdHJ1ZVxyXG4gICAgfTtcclxuICAgIC8vIOi9rOWPkeaaguaXtuWFiOS4jeW8gOWQr1xyXG4gICAgb25TaGFyZUFwcE1lc3NhZ2UocmVzKSB7XHJcbiAgICAgIGlmIChyZXMuZnJvbSA9PT0gJ2J1dHRvbicpIHtcclxuICAgICAgICAvLyDmnaXoh6rpobXpnaLlhoXovazlj5HmjInpkq5cclxuICAgICAgICBjb25zb2xlLmxvZyhyZXMudGFyZ2V0KVxyXG4gICAgICB9XHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAgdGl0bGU6ICcnLFxyXG4gICAgICAgIHBhdGg6ICcvcGFnZXMvaG9tZS9pbmRleD9hZ2VudElkPScgKyB0aGlzLm1lbWJlci5hZ2VudElkIFxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBhc3luYyBvbkxvYWQob3B0KSB7XHJcbiAgICAgIHdlcHkuc2V0TmF2aWdhdGlvbkJhckNvbG9yKHtcclxuICAgICAgICBmcm9udENvbG9yOiAnI2ZmZmZmZicsIC8v5YmN5pmv6aKc6Imy5YC877yM5YyF5ous5oyJ6ZKu44CB5qCH6aKY44CB54q25oCB5qCP55qE6aKc6Imy77yM5LuF5pSv5oyBICNmZmZmZmYg5ZKMICMwMDAwMDAsXHJcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiB0aGlzLnRoZW1lLCAvL+iDjOaZr+minOiJsuWAvO+8jOacieaViOWAvOS4uuWNgeWFrei/m+WItuminOiJsixcclxuICAgICAgICBzdWNjZXNzOiByZXMgPT4ge31cclxuICAgICAgfSk7XHJcbiAgICAgIGF3YWl0IGF1dGgubG9naW4oKVxyXG4gICAgICB0aGlzLm1lbWJlciA9IHdlcHkuZ2V0U3RvcmFnZVN5bmMoJ21lbWJlcicpO1xyXG4gICAgICBhd2FpdCB0aGlzLmxvYWQoKVxyXG4gICAgICB0aGlzLmlzU2hvdyA9IHRydWVcclxuICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgfVxyXG4gICAgYXN5bmMgb25TaG93KCkge1xyXG4gICAgICBpZiAod2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5zY2VuZSAhPSAxMDA3KSB7XHJcbiAgICAgICAgaWYgKCF0aGlzLmlzU2hvdyB8fCAhdGhpcy5jaXR5KSB7XHJcbiAgICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgICAgYXdhaXQgdGhpcy5sb2FkKDEpXHJcbiAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgIH1cclxuICAgIGFzeW5jIG9uUHVsbERvd25SZWZyZXNoKCkge1xyXG4gICAgICBhd2FpdCB0aGlzLmxvYWRjb3Vyc2VzKDEpXHJcbiAgICAgIHRoaXMucGFnZUluZGV4ID0gMVxyXG4gICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICAgIHd4LnN0b3BQdWxsRG93blJlZnJlc2goKVxyXG4gICAgfVxyXG4gICAgYXN5bmMgbG9hZChwYWdlID0gJycpIHtcclxuICAgICAgbGV0IGhvbWVEYXRhID0gYXdhaXQgY29uZmlnLmdldEluZGV4KHtcclxuICAgICAgICBjb3Vyc2VUeXBlSWQ6IHRoaXMuY291cnNlVHlwZUlkLFxyXG4gICAgICAgIHNvcnQ6IHRoaXMuc29ydCxcclxuICAgICAgICBwYWdlSW5kZXg6IHBhZ2UgfHwgdGhpcy5wYWdlSW5kZXgsXHJcbiAgICAgICAgcGFnZVNpemU6IHRoaXMucGFnZVNpemVcclxuICAgICAgfSlcclxuICAgICAgd3guc2V0TmF2aWdhdGlvbkJhclRpdGxlKHtcclxuICAgICAgICB0aXRsZTogaG9tZURhdGEuaGVhZFxyXG4gICAgICB9KVxyXG4gICAgICB0aGlzLnN3aXBlcnMubGlzdCA9IGhvbWVEYXRhLmJhbm5lcnNcclxuICAgICAgdGhpcy5uYXZzLmxpc3QgPSBob21lRGF0YS5uYXZzXHJcbiAgICAgIHRoaXMuc2Nyb2xsTmF2ID0gX3Njcm9sbE5hdi5jb25jYXQoaG9tZURhdGEudHlwZXMpXHJcbiAgICAgIHRoaXMuY291cnNlcyA9IGhvbWVEYXRhLmNvdXJzZXNcclxuICAgICAgdGhpcy5fY2l0eSA9IGhvbWVEYXRhLmNpdHlOYW1lXHJcbiAgICAgIGlmICghd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5jaXR5Q29kZSkge1xyXG4gICAgICAgIHN0b3JlLnNhdmUoJ2NpdHknLCB7XHJcbiAgICAgICAgICBuYW1lOiBob21lRGF0YS5jaXR5TmFtZSxcclxuICAgICAgICAgIGNvZGU6IGhvbWVEYXRhLmNpdHlDb2RlXHJcbiAgICAgICAgfSlcclxuICAgICAgICB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLmNpdHlDb2RlID0gaG9tZURhdGEuY2l0eUNvZGVcclxuICAgICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICAgICAgdGhpcy4kaW52b2tlKCdvcmRlcmluZycsICdsb2FkJywgaG9tZURhdGEubmV3T3JkZXJMaXN0KVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBzaG93TW9yZSgpIHtcclxuICAgICAgdGhpcy5pc0xvYWQgPSBmYWxzZVxyXG4gICAgfVxyXG4gICAgbm9Nb3JlKCkge1xyXG4gICAgICB0aGlzLmlzTG9hZCA9IHRydWVcclxuICAgIH1cclxuICAgIGFzeW5jIGxvYWRjb3Vyc2VzKHBhZ2VJbmRleCkge1xyXG4gICAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICAgIGNvdXJzZVR5cGVJZDogdGhpcy5jb3Vyc2VUeXBlSWQsXHJcbiAgICAgICAgc29ydDogdGhpcy5zb3J0LFxyXG4gICAgICAgIHBhZ2VJbmRleDogcGFnZUluZGV4LFxyXG4gICAgICAgIHBhZ2VTaXplOiB0aGlzLnBhZ2VTaXplXHJcbiAgICAgIH1cclxuICAgICAgbGV0IGNvdXJzZXMgPSBhd2FpdCBjb25maWcuZ2V0Q291cnNlcyhwYXJhbXMpXHJcbiAgICAgIGlmICghY291cnNlcy5jb3Vyc2VzLmxlbmd0aCkge1xyXG4gICAgICAgIGlmIChwYWdlSW5kZXggPT0gMSkge1xyXG4gICAgICAgICAgdGhpcy5jb3Vyc2VzID0gY291cnNlcy5jb3Vyc2VzXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMucGFnZUluZGV4ID0gcGFnZUluZGV4XHJcbiAgICAgICAgdGhpcy5ub01vcmUoKVxyXG4gICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBpZiAocGFnZUluZGV4ID4gMSkgdGhpcy5wYWdlSW5kZXggPSBwYWdlSW5kZXhcclxuICAgICAgICBpZiAocGFnZUluZGV4ID09IDEpIHtcclxuICAgICAgICAgIHRoaXMuY291cnNlcyA9IGNvdXJzZXMuY291cnNlc1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICB0aGlzLmNvdXJzZXMgPSB0aGlzLmNvdXJzZXMuY29uY2F0KGNvdXJzZXMuY291cnNlcylcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIG9uUGFnZVNjcm9sbChlKSB7XHJcbiAgICAgIGlmIChlLnNjcm9sbFRvcCA+IDQxMCkge1xyXG4gICAgICAgIGlmICghdGhpcy5pc2ZpeGVkKSB7XHJcbiAgICAgICAgICB0aGlzLmlzZml4ZWQgPSB0cnVlXHJcbiAgICAgICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICAgICAgfVxyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGlmICh0aGlzLmlzZml4ZWQpIHtcclxuICAgICAgICAgIHRoaXMuaXNmaXhlZCA9IGZhbHNlXHJcbiAgICAgICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBvblJlYWNoQm90dG9tKCkge1xyXG4gICAgICB0aGlzLmdldE1vcmUoKVxyXG4gICAgfVxyXG4gICAgYXN5bmMgZ2V0TW9yZSgpIHtcclxuICAgICAgaWYgKHRoaXMubG9hZG1vcmluZykge1xyXG4gICAgICAgIHJldHVybiBmYWxzZVxyXG4gICAgICB9XHJcbiAgICAgIHRoaXMubG9hZG1vcmluZyA9IHRydWVcclxuICAgICAgdGhpcy5zaG93TW9yZSgpXHJcbiAgICAgIGF3YWl0IHRoaXMubG9hZGNvdXJzZXModGhpcy5wYWdlSW5kZXggKyAxKVxyXG4gICAgICB0aGlzLmxvYWRtb3JpbmcgPSBmYWxzZVxyXG4gICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICB9XHJcbiAgICBtZXRob2RzID0ge1xyXG4gICAgICBhc3luYyBnZXRTY3JlZW4oa2V5LCBzY3JlZW4pIHtcclxuICAgICAgICB0aGlzLmNvdXJzZVR5cGVJZCA9IGtleVxyXG4gICAgICAgIHRoaXMuc29ydCA9IHNjcmVlblxyXG4gICAgICAgIGF3YWl0IHRoaXMubG9hZGNvdXJzZXMoMSlcclxuICAgICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICAgIH0sXHJcbiAgICB9O1xyXG4gIH1cclxuIl19