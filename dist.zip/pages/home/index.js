"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _dec, _class;

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _header = require('./../../components/home/header.js');

var _header2 = _interopRequireDefault(_header);

var _swiper = require('./../../components/common/swiper.js');

var _swiper2 = _interopRequireDefault(_swiper);

var _loading = require('./../../components/common/loading.js');

var _loading2 = _interopRequireDefault(_loading);

var _shadow = require('./../../components/common/shadow.js');

var _shadow2 = _interopRequireDefault(_shadow);

var _contact = require('./../../components/common/contact.js');

var _contact2 = _interopRequireDefault(_contact);

var _navs = require('./../../components/home/navs.js');

var _navs2 = _interopRequireDefault(_navs);

var _scrollNav2 = require('./../../components/home/scrollNav.js');

var _scrollNav3 = _interopRequireDefault(_scrollNav2);

var _help = require('./../../components/common/help.js');

var _help2 = _interopRequireDefault(_help);

var _ordering = require('./../../components/common/ordering.js');

var _ordering2 = _interopRequireDefault(_ordering);

var _cCard = require('./../../components/home/cCard.js');

var _cCard2 = _interopRequireDefault(_cCard);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

var _utils = require('./../../store/utils.js');

var _utils2 = _interopRequireDefault(_utils);

var _wepyRedux = require('./../../npm/wepy-redux/lib/index.js');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var _scrollNav = [{
  id: 0,
  name: '全部'
}];
var Dialog = (_dec = (0, _wepyRedux.connect)({
  city: _utils2.default.get("city")
}), _dec(_class = function (_wepy$page) {
  _inherits(Dialog, _wepy$page);

  function Dialog() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, Dialog);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.data = {
      isfixed: false,
      theme: _wepy2.default.$instance.globalData.themeColor,
      swipers: {
        type: 1,
        list: []
      },
      navs: {
        list: [],
        gridCol: 5,
        skin: false
      },
      scrollNav: [{
        id: 0,
        name: '全部'
      }],
      courses: [],
      isShow: false,
      courseTypeId: 0,
      sort: 0,
      pageIndex: 1,
      pageSize: 10,
      toload: false,
      isLoad: true,
      loadmoring: false,
      _city: '',
      member: {},
      homeData: {}
    }, _this.$repeat = {}, _this.$props = { "cSwiper": { "xmlns:v-bind": "", "v-bind:model.sync": "swipers" }, "Navs": { "v-bind:model.sync": "navs" }, "scrollNav": { "v-bind:isfixed.sync": "isfixed", "v-bind:model.sync": "scrollNav", "xmlns:v-on": "" }, "cCard": { "v-bind:model.sync": "courses" }, "loading": { "xmlns:wx": "" } }, _this.$events = { "scrollNav": { "v-on:ret": "getScreen" } }, _this.components = {
      cSwiper: _swiper2.default,
      Navs: _navs2.default,
      cHeader: _header2.default,
      scrollNav: _scrollNav3.default,
      cCard: _cCard2.default,
      loading: _loading2.default,
      hel: _help2.default,
      ordering: _ordering2.default,
      contact: _contact2.default,
      shadow: _shadow2.default
    }, _this.config = {
      navigationBarTitleText: "",
      enablePullDownRefresh: true
    }, _this.methods = {
      getScreen: function () {
        var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(key, screen) {
          return regeneratorRuntime.wrap(function _callee$(_context) {
            while (1) {
              switch (_context.prev = _context.next) {
                case 0:
                  this.courseTypeId = key;
                  this.sort = screen;
                  _context.next = 4;
                  return this.loadcourses(1);

                case 4:
                  this.$apply();

                case 5:
                case "end":
                  return _context.stop();
              }
            }
          }, _callee, this);
        }));

        function getScreen(_x, _x2) {
          return _ref2.apply(this, arguments);
        }

        return getScreen;
      }()
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(Dialog, [{
    key: "onShareAppMessage",

    // 转发暂时先不开启
    value: function onShareAppMessage(res) {
      if (res.from === 'button') {
        // 来自页面内转发按钮
        console.log(res.target);
      }
      return {
        title: '',
        path: '/pages/home/index?agentId=' + this.member.agentId
      };
    }
  }, {
    key: "onLoad",
    value: function () {
      var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(opt) {
        return regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _wepy2.default.setNavigationBarColor({
                  frontColor: '#ffffff', //前景颜色值，包括按钮、标题、状态栏的颜色，仅支持 #ffffff 和 #000000,
                  backgroundColor: this.theme, //背景颜色值，有效值为十六进制颜色,
                  success: function success(res) {}
                });
                _context2.next = 3;
                return _auth2.default.login();

              case 3:
                this.member = _wepy2.default.getStorageSync('member');
                _context2.next = 6;
                return this.load();

              case 6:
                if (this.homeData.popwindow.length) {
                  this.$invoke('shadow', 'load', this.homeData.popwindow);
                }
                this.isShow = true;
                this.$apply();

              case 9:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));

      function onLoad(_x3) {
        return _ref3.apply(this, arguments);
      }

      return onLoad;
    }()
  }, {
    key: "onShow",
    value: function () {
      var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
        return regeneratorRuntime.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                if (!(_wepy2.default.$instance.globalData.scene != 1007)) {
                  _context3.next = 3;
                  break;
                }

                if (!(!this.isShow || !this.city)) {
                  _context3.next = 3;
                  break;
                }

                return _context3.abrupt("return", false);

              case 3:
                _context3.next = 5;
                return this.load(1);

              case 5:
                this.$apply();

              case 6:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this);
      }));

      function onShow() {
        return _ref4.apply(this, arguments);
      }

      return onShow;
    }()
  }, {
    key: "onPullDownRefresh",
    value: function () {
      var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
        return regeneratorRuntime.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                _context4.next = 2;
                return this.loadcourses(1);

              case 2:
                this.pageIndex = 1;
                this.$apply();
                wx.stopPullDownRefresh();

              case 5:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, this);
      }));

      function onPullDownRefresh() {
        return _ref5.apply(this, arguments);
      }

      return onPullDownRefresh;
    }()
  }, {
    key: "load",
    value: function () {
      var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
        var page = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
        var homeData;
        return regeneratorRuntime.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                _context5.next = 2;
                return _config2.default.getIndex({
                  courseTypeId: this.courseTypeId,
                  sort: this.sort,
                  pageIndex: page || this.pageIndex,
                  pageSize: this.pageSize
                });

              case 2:
                homeData = _context5.sent;

                wx.setNavigationBarTitle({
                  title: homeData.head
                });
                this.homeData = homeData;
                this.swipers.list = homeData.banners;
                this.navs.list = homeData.navs;
                this.scrollNav = _scrollNav.concat(homeData.types);
                this.courses = homeData.courses;
                this._city = homeData.cityName;
                if (!_wepy2.default.$instance.globalData.cityCode) {
                  _utils2.default.save('city', {
                    name: homeData.cityName,
                    code: homeData.cityCode
                  });
                  _wepy2.default.$instance.globalData.cityCode = homeData.cityCode;
                  this.$apply();
                  this.$invoke('ordering', 'load', homeData.newOrderList);
                }

              case 11:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5, this);
      }));

      function load() {
        return _ref6.apply(this, arguments);
      }

      return load;
    }()
  }, {
    key: "showMore",
    value: function showMore() {
      this.isLoad = false;
    }
  }, {
    key: "noMore",
    value: function noMore() {
      this.isLoad = true;
    }
  }, {
    key: "loadcourses",
    value: function () {
      var _ref7 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee6(pageIndex) {
        var params, courses;
        return regeneratorRuntime.wrap(function _callee6$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                params = {
                  courseTypeId: this.courseTypeId,
                  sort: this.sort,
                  pageIndex: pageIndex,
                  pageSize: this.pageSize
                };
                _context6.next = 3;
                return _config2.default.getCourses(params);

              case 3:
                courses = _context6.sent;

                if (courses.courses.length) {
                  _context6.next = 12;
                  break;
                }

                if (pageIndex == 1) {
                  this.courses = courses.courses;
                }
                this.pageIndex = pageIndex;
                this.noMore();
                this.$apply();
                return _context6.abrupt("return", false);

              case 12:
                if (pageIndex > 1) this.pageIndex = pageIndex;
                if (pageIndex == 1) {
                  this.courses = courses.courses;
                } else {
                  this.courses = this.courses.concat(courses.courses);
                }

              case 14:
              case "end":
                return _context6.stop();
            }
          }
        }, _callee6, this);
      }));

      function loadcourses(_x5) {
        return _ref7.apply(this, arguments);
      }

      return loadcourses;
    }()
  }, {
    key: "onPageScroll",
    value: function onPageScroll(e) {
      if (e.scrollTop > 410) {
        if (!this.isfixed) {
          this.isfixed = true;
          this.$apply();
        }
      } else {
        if (this.isfixed) {
          this.isfixed = false;
          this.$apply();
        }
      }
    }
  }, {
    key: "onReachBottom",
    value: function onReachBottom() {
      this.getMore();
    }
  }, {
    key: "getMore",
    value: function () {
      var _ref8 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee7() {
        return regeneratorRuntime.wrap(function _callee7$(_context7) {
          while (1) {
            switch (_context7.prev = _context7.next) {
              case 0:
                if (!this.loadmoring) {
                  _context7.next = 2;
                  break;
                }

                return _context7.abrupt("return", false);

              case 2:
                this.loadmoring = true;
                this.showMore();
                _context7.next = 6;
                return this.loadcourses(this.pageIndex + 1);

              case 6:
                this.loadmoring = false;
                this.$apply();

              case 8:
              case "end":
                return _context7.stop();
            }
          }
        }, _callee7, this);
      }));

      function getMore() {
        return _ref8.apply(this, arguments);
      }

      return getMore;
    }()
  }]);

  return Dialog;
}(_wepy2.default.page)) || _class);

Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/home/index'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LmpzIl0sIm5hbWVzIjpbIl9zY3JvbGxOYXYiLCJpZCIsIm5hbWUiLCJEaWFsb2ciLCJjaXR5Iiwic3RvcmUiLCJnZXQiLCJkYXRhIiwiaXNmaXhlZCIsInRoZW1lIiwid2VweSIsIiRpbnN0YW5jZSIsImdsb2JhbERhdGEiLCJ0aGVtZUNvbG9yIiwic3dpcGVycyIsInR5cGUiLCJsaXN0IiwibmF2cyIsImdyaWRDb2wiLCJza2luIiwic2Nyb2xsTmF2IiwiY291cnNlcyIsImlzU2hvdyIsImNvdXJzZVR5cGVJZCIsInNvcnQiLCJwYWdlSW5kZXgiLCJwYWdlU2l6ZSIsInRvbG9hZCIsImlzTG9hZCIsImxvYWRtb3JpbmciLCJfY2l0eSIsIm1lbWJlciIsImhvbWVEYXRhIiwiJHJlcGVhdCIsIiRwcm9wcyIsIiRldmVudHMiLCJjb21wb25lbnRzIiwiY1N3aXBlciIsIk5hdnMiLCJjSGVhZGVyIiwiY0NhcmQiLCJsb2FkaW5nIiwiaGVsIiwib3JkZXJpbmciLCJjb250YWN0Iiwic2hhZG93IiwiY29uZmlnIiwibmF2aWdhdGlvbkJhclRpdGxlVGV4dCIsImVuYWJsZVB1bGxEb3duUmVmcmVzaCIsIm1ldGhvZHMiLCJnZXRTY3JlZW4iLCJrZXkiLCJzY3JlZW4iLCJsb2FkY291cnNlcyIsIiRhcHBseSIsInJlcyIsImZyb20iLCJjb25zb2xlIiwibG9nIiwidGFyZ2V0IiwidGl0bGUiLCJwYXRoIiwiYWdlbnRJZCIsIm9wdCIsInNldE5hdmlnYXRpb25CYXJDb2xvciIsImZyb250Q29sb3IiLCJiYWNrZ3JvdW5kQ29sb3IiLCJzdWNjZXNzIiwiYXV0aCIsImxvZ2luIiwiZ2V0U3RvcmFnZVN5bmMiLCJsb2FkIiwicG9wd2luZG93IiwibGVuZ3RoIiwiJGludm9rZSIsInNjZW5lIiwid3giLCJzdG9wUHVsbERvd25SZWZyZXNoIiwicGFnZSIsImdldEluZGV4Iiwic2V0TmF2aWdhdGlvbkJhclRpdGxlIiwiaGVhZCIsImJhbm5lcnMiLCJjb25jYXQiLCJ0eXBlcyIsImNpdHlOYW1lIiwiY2l0eUNvZGUiLCJzYXZlIiwiY29kZSIsIm5ld09yZGVyTGlzdCIsInBhcmFtcyIsImdldENvdXJzZXMiLCJub01vcmUiLCJlIiwic2Nyb2xsVG9wIiwiZ2V0TW9yZSIsInNob3dNb3JlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUtFOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7Ozs7Ozs7Ozs7O0FBbEJBLElBQU1BLGFBQWEsQ0FBQztBQUNsQkMsTUFBSSxDQURjO0FBRWxCQyxRQUFNO0FBRlksQ0FBRCxDQUFuQjtJQXdCcUJDLE0sV0FIcEIsd0JBQVE7QUFDUEMsUUFBTUMsZ0JBQU1DLEdBQU4sQ0FBVSxNQUFWO0FBREMsQ0FBUixDOzs7Ozs7Ozs7Ozs7OztzTEFJQ0MsSSxHQUFPO0FBQ0xDLGVBQVMsS0FESjtBQUVMQyxhQUFPQyxlQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJDLFVBRjVCO0FBR0xDLGVBQVM7QUFDUEMsY0FBTSxDQURDO0FBRVBDLGNBQU07QUFGQyxPQUhKO0FBT0xDLFlBQU07QUFDSkQsY0FBTSxFQURGO0FBRUpFLGlCQUFTLENBRkw7QUFHSkMsY0FBTTtBQUhGLE9BUEQ7QUFZTEMsaUJBQVcsQ0FBQztBQUNWbkIsWUFBSSxDQURNO0FBRVZDLGNBQU07QUFGSSxPQUFELENBWk47QUFnQkxtQixlQUFTLEVBaEJKO0FBaUJMQyxjQUFRLEtBakJIO0FBa0JMQyxvQkFBYyxDQWxCVDtBQW1CTEMsWUFBTSxDQW5CRDtBQW9CTEMsaUJBQVcsQ0FwQk47QUFxQkxDLGdCQUFVLEVBckJMO0FBc0JMQyxjQUFRLEtBdEJIO0FBdUJMQyxjQUFRLElBdkJIO0FBd0JMQyxrQkFBWSxLQXhCUDtBQXlCTEMsYUFBTyxFQXpCRjtBQTBCTEMsY0FBTyxFQTFCRjtBQTJCTEMsZ0JBQVM7QUEzQkosSyxRQTZCUkMsTyxHQUFVLEUsUUFDYkMsTSxHQUFTLEVBQUMsV0FBVSxFQUFDLGdCQUFlLEVBQWhCLEVBQW1CLHFCQUFvQixTQUF2QyxFQUFYLEVBQTZELFFBQU8sRUFBQyxxQkFBb0IsTUFBckIsRUFBcEUsRUFBaUcsYUFBWSxFQUFDLHVCQUFzQixTQUF2QixFQUFpQyxxQkFBb0IsV0FBckQsRUFBaUUsY0FBYSxFQUE5RSxFQUE3RyxFQUErTCxTQUFRLEVBQUMscUJBQW9CLFNBQXJCLEVBQXZNLEVBQXVPLFdBQVUsRUFBQyxZQUFXLEVBQVosRUFBalAsRSxRQUNUQyxPLEdBQVUsRUFBQyxhQUFZLEVBQUMsWUFBVyxXQUFaLEVBQWIsRSxRQUNUQyxVLEdBQWE7QUFDUkMsK0JBRFE7QUFFUkMsMEJBRlE7QUFHUkMsK0JBSFE7QUFJUm5CLG9DQUpRO0FBS1JvQiw0QkFMUTtBQU1SQyxnQ0FOUTtBQU9SQyx5QkFQUTtBQVFSQyxrQ0FSUTtBQVNSQyxnQ0FUUTtBQVVSQztBQVZRLEssUUFZVkMsTSxHQUFTO0FBQ1BDLDhCQUF3QixFQURqQjtBQUVQQyw2QkFBdUI7QUFGaEIsSyxRQWdJVEMsTyxHQUFVO0FBQ0ZDLGVBREU7QUFBQSw2RkFDUUMsR0FEUixFQUNhQyxNQURiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFTix1QkFBSzdCLFlBQUwsR0FBb0I0QixHQUFwQjtBQUNBLHVCQUFLM0IsSUFBTCxHQUFZNEIsTUFBWjtBQUhNO0FBQUEseUJBSUEsS0FBS0MsV0FBTCxDQUFpQixDQUFqQixDQUpBOztBQUFBO0FBS04sdUJBQUtDLE1BQUw7O0FBTE07QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQSxLOzs7Ozs7QUE1SFY7c0NBQ2tCQyxHLEVBQUs7QUFDckIsVUFBSUEsSUFBSUMsSUFBSixLQUFhLFFBQWpCLEVBQTJCO0FBQ3pCO0FBQ0FDLGdCQUFRQyxHQUFSLENBQVlILElBQUlJLE1BQWhCO0FBQ0Q7QUFDRCxhQUFPO0FBQ0xDLGVBQU8sRUFERjtBQUVMQyxjQUFNLCtCQUErQixLQUFLOUIsTUFBTCxDQUFZK0I7QUFGNUMsT0FBUDtBQUlEOzs7OzRGQUNZQyxHOzs7OztBQUNYckQsK0JBQUtzRCxxQkFBTCxDQUEyQjtBQUN6QkMsOEJBQVksU0FEYSxFQUNGO0FBQ3ZCQyxtQ0FBaUIsS0FBS3pELEtBRkcsRUFFSTtBQUM3QjBELDJCQUFTLHNCQUFPLENBQUU7QUFITyxpQkFBM0I7O3VCQUtNQyxlQUFLQyxLQUFMLEU7OztBQUNOLHFCQUFLdEMsTUFBTCxHQUFjckIsZUFBSzRELGNBQUwsQ0FBb0IsUUFBcEIsQ0FBZDs7dUJBQ00sS0FBS0MsSUFBTCxFOzs7QUFDTixvQkFBRyxLQUFLdkMsUUFBTCxDQUFjd0MsU0FBZCxDQUF3QkMsTUFBM0IsRUFBa0M7QUFDaEMsdUJBQUtDLE9BQUwsQ0FBYSxRQUFiLEVBQXNCLE1BQXRCLEVBQTZCLEtBQUsxQyxRQUFMLENBQWN3QyxTQUEzQztBQUNEO0FBQ0QscUJBQUtsRCxNQUFMLEdBQWMsSUFBZDtBQUNBLHFCQUFLZ0MsTUFBTDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3NCQUdJNUMsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCK0QsS0FBMUIsSUFBbUMsSTs7Ozs7c0JBQ2pDLENBQUMsS0FBS3JELE1BQU4sSUFBZ0IsQ0FBQyxLQUFLbEIsSTs7Ozs7a0RBQ2pCLEs7Ozs7dUJBR0wsS0FBS21FLElBQUwsQ0FBVSxDQUFWLEM7OztBQUNOLHFCQUFLakIsTUFBTDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozt1QkFHTSxLQUFLRCxXQUFMLENBQWlCLENBQWpCLEM7OztBQUNOLHFCQUFLNUIsU0FBTCxHQUFpQixDQUFqQjtBQUNBLHFCQUFLNkIsTUFBTDtBQUNBc0IsbUJBQUdDLG1CQUFIOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztZQUVTQyxJLHVFQUFPLEU7Ozs7Ozs7dUJBQ0toQyxpQkFBT2lDLFFBQVAsQ0FBZ0I7QUFDbkN4RCxnQ0FBYyxLQUFLQSxZQURnQjtBQUVuQ0Msd0JBQU0sS0FBS0EsSUFGd0I7QUFHbkNDLDZCQUFXcUQsUUFBUSxLQUFLckQsU0FIVztBQUluQ0MsNEJBQVUsS0FBS0E7QUFKb0IsaUJBQWhCLEM7OztBQUFqQk0sd0I7O0FBTUo0QyxtQkFBR0kscUJBQUgsQ0FBeUI7QUFDdkJwQix5QkFBTzVCLFNBQVNpRDtBQURPLGlCQUF6QjtBQUdBLHFCQUFLakQsUUFBTCxHQUFnQkEsUUFBaEI7QUFDQSxxQkFBS2xCLE9BQUwsQ0FBYUUsSUFBYixHQUFvQmdCLFNBQVNrRCxPQUE3QjtBQUNBLHFCQUFLakUsSUFBTCxDQUFVRCxJQUFWLEdBQWlCZ0IsU0FBU2YsSUFBMUI7QUFDQSxxQkFBS0csU0FBTCxHQUFpQnBCLFdBQVdtRixNQUFYLENBQWtCbkQsU0FBU29ELEtBQTNCLENBQWpCO0FBQ0EscUJBQUsvRCxPQUFMLEdBQWVXLFNBQVNYLE9BQXhCO0FBQ0EscUJBQUtTLEtBQUwsR0FBYUUsU0FBU3FELFFBQXRCO0FBQ0Esb0JBQUksQ0FBQzNFLGVBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQjBFLFFBQS9CLEVBQXlDO0FBQ3ZDakYsa0NBQU1rRixJQUFOLENBQVcsTUFBWCxFQUFtQjtBQUNqQnJGLDBCQUFNOEIsU0FBU3FELFFBREU7QUFFakJHLDBCQUFNeEQsU0FBU3NEO0FBRkUsbUJBQW5CO0FBSUE1RSxpQ0FBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCMEUsUUFBMUIsR0FBcUN0RCxTQUFTc0QsUUFBOUM7QUFDQSx1QkFBS2hDLE1BQUw7QUFDQSx1QkFBS29CLE9BQUwsQ0FBYSxVQUFiLEVBQXlCLE1BQXpCLEVBQWlDMUMsU0FBU3lELFlBQTFDO0FBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7OzsrQkFFUTtBQUNULFdBQUs3RCxNQUFMLEdBQWMsS0FBZDtBQUNEOzs7NkJBQ1E7QUFDUCxXQUFLQSxNQUFMLEdBQWMsSUFBZDtBQUNEOzs7OzRGQUNpQkgsUzs7Ozs7O0FBQ1ppRSxzQixHQUFTO0FBQ1huRSxnQ0FBYyxLQUFLQSxZQURSO0FBRVhDLHdCQUFNLEtBQUtBLElBRkE7QUFHWEMsNkJBQVdBLFNBSEE7QUFJWEMsNEJBQVUsS0FBS0E7QUFKSixpQjs7dUJBTU9vQixpQkFBTzZDLFVBQVAsQ0FBa0JELE1BQWxCLEM7OztBQUFoQnJFLHVCOztvQkFDQ0EsUUFBUUEsT0FBUixDQUFnQm9ELE07Ozs7O0FBQ25CLG9CQUFJaEQsYUFBYSxDQUFqQixFQUFvQjtBQUNsQix1QkFBS0osT0FBTCxHQUFlQSxRQUFRQSxPQUF2QjtBQUNEO0FBQ0QscUJBQUtJLFNBQUwsR0FBaUJBLFNBQWpCO0FBQ0EscUJBQUttRSxNQUFMO0FBQ0EscUJBQUt0QyxNQUFMO2tEQUNPLEs7OztBQUVQLG9CQUFJN0IsWUFBWSxDQUFoQixFQUFtQixLQUFLQSxTQUFMLEdBQWlCQSxTQUFqQjtBQUNuQixvQkFBSUEsYUFBYSxDQUFqQixFQUFvQjtBQUNsQix1QkFBS0osT0FBTCxHQUFlQSxRQUFRQSxPQUF2QjtBQUNELGlCQUZELE1BRU87QUFDTCx1QkFBS0EsT0FBTCxHQUFlLEtBQUtBLE9BQUwsQ0FBYThELE1BQWIsQ0FBb0I5RCxRQUFRQSxPQUE1QixDQUFmO0FBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7OztpQ0FHUXdFLEMsRUFBRztBQUNkLFVBQUlBLEVBQUVDLFNBQUYsR0FBYyxHQUFsQixFQUF1QjtBQUNyQixZQUFJLENBQUMsS0FBS3RGLE9BQVYsRUFBbUI7QUFDakIsZUFBS0EsT0FBTCxHQUFlLElBQWY7QUFDQSxlQUFLOEMsTUFBTDtBQUNEO0FBQ0YsT0FMRCxNQUtPO0FBQ0wsWUFBSSxLQUFLOUMsT0FBVCxFQUFrQjtBQUNoQixlQUFLQSxPQUFMLEdBQWUsS0FBZjtBQUNBLGVBQUs4QyxNQUFMO0FBQ0Q7QUFDRjtBQUNGOzs7b0NBQ2U7QUFDZCxXQUFLeUMsT0FBTDtBQUNEOzs7Ozs7Ozs7cUJBRUssS0FBS2xFLFU7Ozs7O2tEQUNBLEs7OztBQUVULHFCQUFLQSxVQUFMLEdBQWtCLElBQWxCO0FBQ0EscUJBQUttRSxRQUFMOzt1QkFDTSxLQUFLM0MsV0FBTCxDQUFpQixLQUFLNUIsU0FBTCxHQUFpQixDQUFsQyxDOzs7QUFDTixxQkFBS0ksVUFBTCxHQUFrQixLQUFsQjtBQUNBLHFCQUFLeUIsTUFBTDs7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQTNLZ0M1QyxlQUFLb0UsSTtrQkFBcEIzRSxNIiwiZmlsZSI6ImluZGV4LmpzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbiAgY29uc3QgX3Njcm9sbE5hdiA9IFt7XHJcbiAgICBpZDogMCxcclxuICAgIG5hbWU6ICflhajpg6gnXHJcbiAgfV1cclxuICBpbXBvcnQgd2VweSBmcm9tIFwid2VweVwiO1xyXG4gIGltcG9ydCBjSGVhZGVyIGZyb20gXCJAL2NvbXBvbmVudHMvaG9tZS9oZWFkZXJcIlxyXG4gIGltcG9ydCBjU3dpcGVyIGZyb20gXCJAL2NvbXBvbmVudHMvY29tbW9uL3N3aXBlclwiXHJcbiAgaW1wb3J0IGxvYWRpbmcgZnJvbSBcIkAvY29tcG9uZW50cy9jb21tb24vbG9hZGluZ1wiXHJcbiAgaW1wb3J0IHNoYWRvdyBmcm9tIFwiQC9jb21wb25lbnRzL2NvbW1vbi9zaGFkb3dcIlxyXG4gIGltcG9ydCBjb250YWN0IGZyb20gXCJAL2NvbXBvbmVudHMvY29tbW9uL2NvbnRhY3RcIlxyXG4gIGltcG9ydCBOYXZzIGZyb20gXCJAL2NvbXBvbmVudHMvaG9tZS9uYXZzXCJcclxuICBpbXBvcnQgc2Nyb2xsTmF2IGZyb20gXCJAL2NvbXBvbmVudHMvaG9tZS9zY3JvbGxOYXZcIlxyXG4gIGltcG9ydCBoZWwgZnJvbSBcIkAvY29tcG9uZW50cy9jb21tb24vaGVscFwiXHJcbiAgaW1wb3J0IG9yZGVyaW5nIGZyb20gXCJAL2NvbXBvbmVudHMvY29tbW9uL29yZGVyaW5nXCJcclxuICBpbXBvcnQgY0NhcmQgZnJvbSBcIkAvY29tcG9uZW50cy9ob21lL2NDYXJkXCJcclxuICBpbXBvcnQgY29uZmlnIGZyb20gXCJAL2FwaS9jb25maWdcIlxyXG4gIGltcG9ydCBhdXRoIGZyb20gXCJAL2FwaS9hdXRoXCJcclxuICBpbXBvcnQgc3RvcmUgZnJvbSBcIkAvc3RvcmUvdXRpbHNcIlxyXG4gIGltcG9ydCB7XHJcbiAgICBjb25uZWN0XHJcbiAgfSBmcm9tIFwid2VweS1yZWR1eFwiXHJcbiAgQGNvbm5lY3Qoe1xyXG4gICAgY2l0eTogc3RvcmUuZ2V0KFwiY2l0eVwiKVxyXG4gIH0pXHJcbiAgZXhwb3J0IGRlZmF1bHQgY2xhc3MgRGlhbG9nIGV4dGVuZHMgd2VweS5wYWdlIHtcclxuICAgIGRhdGEgPSB7XHJcbiAgICAgIGlzZml4ZWQ6IGZhbHNlLFxyXG4gICAgICB0aGVtZTogd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS50aGVtZUNvbG9yLFxyXG4gICAgICBzd2lwZXJzOiB7XHJcbiAgICAgICAgdHlwZTogMSxcclxuICAgICAgICBsaXN0OiBbXSxcclxuICAgICAgfSxcclxuICAgICAgbmF2czoge1xyXG4gICAgICAgIGxpc3Q6IFtdLFxyXG4gICAgICAgIGdyaWRDb2w6IDUsXHJcbiAgICAgICAgc2tpbjogZmFsc2VcclxuICAgICAgfSxcclxuICAgICAgc2Nyb2xsTmF2OiBbe1xyXG4gICAgICAgIGlkOiAwLFxyXG4gICAgICAgIG5hbWU6ICflhajpg6gnXHJcbiAgICAgIH1dLFxyXG4gICAgICBjb3Vyc2VzOiBbXSxcclxuICAgICAgaXNTaG93OiBmYWxzZSxcclxuICAgICAgY291cnNlVHlwZUlkOiAwLFxyXG4gICAgICBzb3J0OiAwLFxyXG4gICAgICBwYWdlSW5kZXg6IDEsXHJcbiAgICAgIHBhZ2VTaXplOiAxMCxcclxuICAgICAgdG9sb2FkOiBmYWxzZSxcclxuICAgICAgaXNMb2FkOiB0cnVlLFxyXG4gICAgICBsb2FkbW9yaW5nOiBmYWxzZSxcclxuICAgICAgX2NpdHk6ICcnLFxyXG4gICAgICBtZW1iZXI6e30sXHJcbiAgICAgIGhvbWVEYXRhOnt9XHJcbiAgICB9O1xyXG4gICAkcmVwZWF0ID0ge307XHJcbiRwcm9wcyA9IHtcImNTd2lwZXJcIjp7XCJ4bWxuczp2LWJpbmRcIjpcIlwiLFwidi1iaW5kOm1vZGVsLnN5bmNcIjpcInN3aXBlcnNcIn0sXCJOYXZzXCI6e1widi1iaW5kOm1vZGVsLnN5bmNcIjpcIm5hdnNcIn0sXCJzY3JvbGxOYXZcIjp7XCJ2LWJpbmQ6aXNmaXhlZC5zeW5jXCI6XCJpc2ZpeGVkXCIsXCJ2LWJpbmQ6bW9kZWwuc3luY1wiOlwic2Nyb2xsTmF2XCIsXCJ4bWxuczp2LW9uXCI6XCJcIn0sXCJjQ2FyZFwiOntcInYtYmluZDptb2RlbC5zeW5jXCI6XCJjb3Vyc2VzXCJ9LFwibG9hZGluZ1wiOntcInhtbG5zOnd4XCI6XCJcIn19O1xyXG4kZXZlbnRzID0ge1wic2Nyb2xsTmF2XCI6e1widi1vbjpyZXRcIjpcImdldFNjcmVlblwifX07XHJcbiBjb21wb25lbnRzID0ge1xyXG4gICAgICBjU3dpcGVyLFxyXG4gICAgICBOYXZzLFxyXG4gICAgICBjSGVhZGVyLFxyXG4gICAgICBzY3JvbGxOYXYsXHJcbiAgICAgIGNDYXJkLFxyXG4gICAgICBsb2FkaW5nLFxyXG4gICAgICBoZWwsXHJcbiAgICAgIG9yZGVyaW5nLFxyXG4gICAgICBjb250YWN0LFxyXG4gICAgICBzaGFkb3dcclxuICAgIH1cclxuICAgIGNvbmZpZyA9IHtcclxuICAgICAgbmF2aWdhdGlvbkJhclRpdGxlVGV4dDogXCJcIixcclxuICAgICAgZW5hYmxlUHVsbERvd25SZWZyZXNoOiB0cnVlXHJcbiAgICB9O1xyXG4gICAgLy8g6L2s5Y+R5pqC5pe25YWI5LiN5byA5ZCvXHJcbiAgICBvblNoYXJlQXBwTWVzc2FnZShyZXMpIHtcclxuICAgICAgaWYgKHJlcy5mcm9tID09PSAnYnV0dG9uJykge1xyXG4gICAgICAgIC8vIOadpeiHqumhtemdouWGhei9rOWPkeaMiemSrlxyXG4gICAgICAgIGNvbnNvbGUubG9nKHJlcy50YXJnZXQpXHJcbiAgICAgIH1cclxuICAgICAgcmV0dXJuIHtcclxuICAgICAgICB0aXRsZTogJycsXHJcbiAgICAgICAgcGF0aDogJy9wYWdlcy9ob21lL2luZGV4P2FnZW50SWQ9JyArIHRoaXMubWVtYmVyLmFnZW50SWQgXHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIGFzeW5jIG9uTG9hZChvcHQpIHtcclxuICAgICAgd2VweS5zZXROYXZpZ2F0aW9uQmFyQ29sb3Ioe1xyXG4gICAgICAgIGZyb250Q29sb3I6ICcjZmZmZmZmJywgLy/liY3mma/popzoibLlgLzvvIzljIXmi6zmjInpkq7jgIHmoIfpopjjgIHnirbmgIHmoI/nmoTpopzoibLvvIzku4XmlK/mjIEgI2ZmZmZmZiDlkowgIzAwMDAwMCxcclxuICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IHRoaXMudGhlbWUsIC8v6IOM5pmv6aKc6Imy5YC877yM5pyJ5pWI5YC85Li65Y2B5YWt6L+b5Yi26aKc6ImyLFxyXG4gICAgICAgIHN1Y2Nlc3M6IHJlcyA9PiB7fVxyXG4gICAgICB9KTtcclxuICAgICAgYXdhaXQgYXV0aC5sb2dpbigpXHJcbiAgICAgIHRoaXMubWVtYmVyID0gd2VweS5nZXRTdG9yYWdlU3luYygnbWVtYmVyJyk7XHJcbiAgICAgIGF3YWl0IHRoaXMubG9hZCgpXHJcbiAgICAgIGlmKHRoaXMuaG9tZURhdGEucG9wd2luZG93Lmxlbmd0aCl7XHJcbiAgICAgICAgdGhpcy4kaW52b2tlKCdzaGFkb3cnLCdsb2FkJyx0aGlzLmhvbWVEYXRhLnBvcHdpbmRvdylcclxuICAgICAgfVxyXG4gICAgICB0aGlzLmlzU2hvdyA9IHRydWVcclxuICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgfVxyXG4gICAgYXN5bmMgb25TaG93KCkge1xyXG4gICAgICBpZiAod2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5zY2VuZSAhPSAxMDA3KSB7XHJcbiAgICAgICAgaWYgKCF0aGlzLmlzU2hvdyB8fCAhdGhpcy5jaXR5KSB7XHJcbiAgICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgICAgYXdhaXQgdGhpcy5sb2FkKDEpXHJcbiAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgIH1cclxuICAgIGFzeW5jIG9uUHVsbERvd25SZWZyZXNoKCkge1xyXG4gICAgICBhd2FpdCB0aGlzLmxvYWRjb3Vyc2VzKDEpXHJcbiAgICAgIHRoaXMucGFnZUluZGV4ID0gMVxyXG4gICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICAgIHd4LnN0b3BQdWxsRG93blJlZnJlc2goKVxyXG4gICAgfVxyXG4gICAgYXN5bmMgbG9hZChwYWdlID0gJycpIHtcclxuICAgICAgbGV0IGhvbWVEYXRhID0gYXdhaXQgY29uZmlnLmdldEluZGV4KHtcclxuICAgICAgICBjb3Vyc2VUeXBlSWQ6IHRoaXMuY291cnNlVHlwZUlkLFxyXG4gICAgICAgIHNvcnQ6IHRoaXMuc29ydCxcclxuICAgICAgICBwYWdlSW5kZXg6IHBhZ2UgfHwgdGhpcy5wYWdlSW5kZXgsXHJcbiAgICAgICAgcGFnZVNpemU6IHRoaXMucGFnZVNpemVcclxuICAgICAgfSlcclxuICAgICAgd3guc2V0TmF2aWdhdGlvbkJhclRpdGxlKHtcclxuICAgICAgICB0aXRsZTogaG9tZURhdGEuaGVhZFxyXG4gICAgICB9KVxyXG4gICAgICB0aGlzLmhvbWVEYXRhID0gaG9tZURhdGFcclxuICAgICAgdGhpcy5zd2lwZXJzLmxpc3QgPSBob21lRGF0YS5iYW5uZXJzXHJcbiAgICAgIHRoaXMubmF2cy5saXN0ID0gaG9tZURhdGEubmF2c1xyXG4gICAgICB0aGlzLnNjcm9sbE5hdiA9IF9zY3JvbGxOYXYuY29uY2F0KGhvbWVEYXRhLnR5cGVzKVxyXG4gICAgICB0aGlzLmNvdXJzZXMgPSBob21lRGF0YS5jb3Vyc2VzXHJcbiAgICAgIHRoaXMuX2NpdHkgPSBob21lRGF0YS5jaXR5TmFtZVxyXG4gICAgICBpZiAoIXdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuY2l0eUNvZGUpIHtcclxuICAgICAgICBzdG9yZS5zYXZlKCdjaXR5Jywge1xyXG4gICAgICAgICAgbmFtZTogaG9tZURhdGEuY2l0eU5hbWUsXHJcbiAgICAgICAgICBjb2RlOiBob21lRGF0YS5jaXR5Q29kZVxyXG4gICAgICAgIH0pXHJcbiAgICAgICAgd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5jaXR5Q29kZSA9IGhvbWVEYXRhLmNpdHlDb2RlXHJcbiAgICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgICAgIHRoaXMuJGludm9rZSgnb3JkZXJpbmcnLCAnbG9hZCcsIGhvbWVEYXRhLm5ld09yZGVyTGlzdClcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgc2hvd01vcmUoKSB7XHJcbiAgICAgIHRoaXMuaXNMb2FkID0gZmFsc2VcclxuICAgIH1cclxuICAgIG5vTW9yZSgpIHtcclxuICAgICAgdGhpcy5pc0xvYWQgPSB0cnVlXHJcbiAgICB9XHJcbiAgICBhc3luYyBsb2FkY291cnNlcyhwYWdlSW5kZXgpIHtcclxuICAgICAgbGV0IHBhcmFtcyA9IHtcclxuICAgICAgICBjb3Vyc2VUeXBlSWQ6IHRoaXMuY291cnNlVHlwZUlkLFxyXG4gICAgICAgIHNvcnQ6IHRoaXMuc29ydCxcclxuICAgICAgICBwYWdlSW5kZXg6IHBhZ2VJbmRleCxcclxuICAgICAgICBwYWdlU2l6ZTogdGhpcy5wYWdlU2l6ZVxyXG4gICAgICB9XHJcbiAgICAgIGxldCBjb3Vyc2VzID0gYXdhaXQgY29uZmlnLmdldENvdXJzZXMocGFyYW1zKVxyXG4gICAgICBpZiAoIWNvdXJzZXMuY291cnNlcy5sZW5ndGgpIHtcclxuICAgICAgICBpZiAocGFnZUluZGV4ID09IDEpIHtcclxuICAgICAgICAgIHRoaXMuY291cnNlcyA9IGNvdXJzZXMuY291cnNlc1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLnBhZ2VJbmRleCA9IHBhZ2VJbmRleFxyXG4gICAgICAgIHRoaXMubm9Nb3JlKClcclxuICAgICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgaWYgKHBhZ2VJbmRleCA+IDEpIHRoaXMucGFnZUluZGV4ID0gcGFnZUluZGV4XHJcbiAgICAgICAgaWYgKHBhZ2VJbmRleCA9PSAxKSB7XHJcbiAgICAgICAgICB0aGlzLmNvdXJzZXMgPSBjb3Vyc2VzLmNvdXJzZXNcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgdGhpcy5jb3Vyc2VzID0gdGhpcy5jb3Vyc2VzLmNvbmNhdChjb3Vyc2VzLmNvdXJzZXMpXHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBvblBhZ2VTY3JvbGwoZSkge1xyXG4gICAgICBpZiAoZS5zY3JvbGxUb3AgPiA0MTApIHtcclxuICAgICAgICBpZiAoIXRoaXMuaXNmaXhlZCkge1xyXG4gICAgICAgICAgdGhpcy5pc2ZpeGVkID0gdHJ1ZVxyXG4gICAgICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgICAgIH1cclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBpZiAodGhpcy5pc2ZpeGVkKSB7XHJcbiAgICAgICAgICB0aGlzLmlzZml4ZWQgPSBmYWxzZVxyXG4gICAgICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgb25SZWFjaEJvdHRvbSgpIHtcclxuICAgICAgdGhpcy5nZXRNb3JlKClcclxuICAgIH1cclxuICAgIGFzeW5jIGdldE1vcmUoKSB7XHJcbiAgICAgIGlmICh0aGlzLmxvYWRtb3JpbmcpIHtcclxuICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgfVxyXG4gICAgICB0aGlzLmxvYWRtb3JpbmcgPSB0cnVlXHJcbiAgICAgIHRoaXMuc2hvd01vcmUoKVxyXG4gICAgICBhd2FpdCB0aGlzLmxvYWRjb3Vyc2VzKHRoaXMucGFnZUluZGV4ICsgMSlcclxuICAgICAgdGhpcy5sb2FkbW9yaW5nID0gZmFsc2VcclxuICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgfVxyXG4gICAgbWV0aG9kcyA9IHtcclxuICAgICAgYXN5bmMgZ2V0U2NyZWVuKGtleSwgc2NyZWVuKSB7XHJcbiAgICAgICAgdGhpcy5jb3Vyc2VUeXBlSWQgPSBrZXlcclxuICAgICAgICB0aGlzLnNvcnQgPSBzY3JlZW5cclxuICAgICAgICBhd2FpdCB0aGlzLmxvYWRjb3Vyc2VzKDEpXHJcbiAgICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgICB9LFxyXG4gICAgfTtcclxuICB9XHJcbiJdfQ==