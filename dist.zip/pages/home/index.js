"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _dec, _class;

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _header = require('./../../components/home/header.js');

var _header2 = _interopRequireDefault(_header);

var _swiper = require('./../../components/common/swiper.js');

var _swiper2 = _interopRequireDefault(_swiper);

var _loading = require('./../../components/common/loading.js');

var _loading2 = _interopRequireDefault(_loading);

var _navs = require('./../../components/home/navs.js');

var _navs2 = _interopRequireDefault(_navs);

var _scrollNav2 = require('./../../components/home/scrollNav.js');

var _scrollNav3 = _interopRequireDefault(_scrollNav2);

var _help = require('./../../components/common/help.js');

var _help2 = _interopRequireDefault(_help);

var _ordering = require('./../../components/common/ordering.js');

var _ordering2 = _interopRequireDefault(_ordering);

var _cCard = require('./../../components/home/cCard.js');

var _cCard2 = _interopRequireDefault(_cCard);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

var _utils = require('./../../store/utils.js');

var _utils2 = _interopRequireDefault(_utils);

var _wepyRedux = require('./../../npm/wepy-redux/lib/index.js');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var _scrollNav = [{
  id: 0,
  name: '全部'
}];
var Dialog = (_dec = (0, _wepyRedux.connect)({
  city: _utils2.default.get("city")
}), _dec(_class = function (_wepy$page) {
  _inherits(Dialog, _wepy$page);

  function Dialog() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, Dialog);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.data = {
      isfixed: false,
      theme: _wepy2.default.$instance.globalData.themeColor,
      swipers: {
        type: 1,
        list: []
      },
      navs: {
        list: [],
        gridCol: 5,
        skin: false
      },
      scrollNav: [{
        id: 0,
        name: '全部'
      }],
      courses: [],
      isShow: false,
      courseTypeId: 0,
      sort: 0,
      pageIndex: 1,
      pageSize: 10,
      toload: false,
      isLoad: true,
      loadmoring: false,
      _city: ''
    }, _this.$repeat = {}, _this.$props = { "cSwiper": { "xmlns:v-bind": "", "v-bind:model.sync": "swipers" }, "Navs": { "v-bind:model.sync": "navs" }, "scrollNav": { "v-bind:isfixed.sync": "isfixed", "v-bind:model.sync": "scrollNav", "xmlns:v-on": "" }, "cCard": { "v-bind:model.sync": "courses" }, "loading": { "xmlns:wx": "" } }, _this.$events = { "scrollNav": { "v-on:ret": "getScreen" } }, _this.components = {
      cSwiper: _swiper2.default,
      Navs: _navs2.default,
      cHeader: _header2.default,
      scrollNav: _scrollNav3.default,
      cCard: _cCard2.default,
      loading: _loading2.default,
      hel: _help2.default,
      ordering: _ordering2.default
    }, _this.config = {
      navigationBarTitleText: "华心桥体验营",
      enablePullDownRefresh: true
    }, _this.methods = {
      getScreen: function () {
        var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(key, screen) {
          return regeneratorRuntime.wrap(function _callee$(_context) {
            while (1) {
              switch (_context.prev = _context.next) {
                case 0:
                  this.courseTypeId = key;
                  this.sort = screen;
                  _context.next = 4;
                  return this.loadcourses(1);

                case 4:
                  this.$apply();

                case 5:
                case "end":
                  return _context.stop();
              }
            }
          }, _callee, this);
        }));

        function getScreen(_x, _x2) {
          return _ref2.apply(this, arguments);
        }

        return getScreen;
      }()
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(Dialog, [{
    key: "onShareAppMessage",

    // 转发暂时先不开启
    value: function onShareAppMessage(res) {
      if (res.from === 'button') {
        // 来自页面内转发按钮
        console.log(res.target);
      }
      return {
        title: '华心桥体验营',
        path: '/pages/home/index'
      };
    }
  }, {
    key: "onLoad",
    value: function () {
      var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
        return regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _wepy2.default.setNavigationBarColor({
                  frontColor: '#ffffff', //前景颜色值，包括按钮、标题、状态栏的颜色，仅支持 #ffffff 和 #000000,
                  backgroundColor: this.theme, //背景颜色值，有效值为十六进制颜色,
                  success: function success(res) {}
                });
                _context2.next = 3;
                return _auth2.default.login();

              case 3:
                _context2.next = 5;
                return this.load();

              case 5:
                this.isShow = true;
                this.$apply();
                // this.$invoke('cSwiper', 'load', this.model)
                // this.$invoke('Navs', 'load', this.model)

              case 7:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));

      function onLoad() {
        return _ref3.apply(this, arguments);
      }

      return onLoad;
    }()
  }, {
    key: "onShow",
    value: function () {
      var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
        return regeneratorRuntime.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                if (!(!this.isShow || !this.city)) {
                  _context3.next = 2;
                  break;
                }

                return _context3.abrupt("return", false);

              case 2:
                _context3.next = 4;
                return this.load(1);

              case 4:
                this.$apply();

              case 5:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this);
      }));

      function onShow() {
        return _ref4.apply(this, arguments);
      }

      return onShow;
    }()
  }, {
    key: "onPullDownRefresh",
    value: function () {
      var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
        return regeneratorRuntime.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                _context4.next = 2;
                return this.loadcourses(1);

              case 2:
                this.pageIndex = 1;
                this.$apply();
                wx.stopPullDownRefresh();

              case 5:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, this);
      }));

      function onPullDownRefresh() {
        return _ref5.apply(this, arguments);
      }

      return onPullDownRefresh;
    }()
  }, {
    key: "load",
    value: function () {
      var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
        var page = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
        var homeData;
        return regeneratorRuntime.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                _context5.next = 2;
                return _config2.default.getIndex({
                  courseTypeId: this.courseTypeId,
                  sort: this.sort,
                  pageIndex: page || this.pageIndex,
                  pageSize: this.pageSize
                });

              case 2:
                homeData = _context5.sent;

                this.swipers.list = homeData.banners;
                this.navs.list = homeData.navs;
                this.scrollNav = _scrollNav.concat(homeData.types);
                this.courses = homeData.courses;
                this._city = homeData.cityName;
                if (!_wepy2.default.$instance.globalData.cityCode) {
                  _utils2.default.save('city', {
                    name: homeData.cityName,
                    code: homeData.cityCode
                  });
                  _wepy2.default.$instance.globalData.cityCode = homeData.cityCode;
                  this.$invoke('ordering', 'load', homeData.newOrderList);
                }

              case 9:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5, this);
      }));

      function load() {
        return _ref6.apply(this, arguments);
      }

      return load;
    }()
  }, {
    key: "showMore",
    value: function showMore() {
      this.isLoad = false;
    }
  }, {
    key: "noMore",
    value: function noMore() {
      this.isLoad = true;
    }
  }, {
    key: "loadcourses",
    value: function () {
      var _ref7 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee6(pageIndex) {
        var params, courses;
        return regeneratorRuntime.wrap(function _callee6$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                params = {
                  courseTypeId: this.courseTypeId,
                  sort: this.sort,
                  pageIndex: pageIndex,
                  pageSize: this.pageSize
                };
                _context6.next = 3;
                return _config2.default.getCourses(params);

              case 3:
                courses = _context6.sent;

                if (courses.courses.length) {
                  _context6.next = 12;
                  break;
                }

                if (pageIndex == 1) {
                  this.courses = courses.courses;
                }
                this.pageIndex = pageIndex;
                this.noMore();
                this.$apply();
                return _context6.abrupt("return", false);

              case 12:
                if (pageIndex > 1) this.pageIndex = pageIndex;
                if (pageIndex == 1) {
                  this.courses = courses.courses;
                } else {
                  this.courses = this.courses.concat(courses.courses);
                }

              case 14:
              case "end":
                return _context6.stop();
            }
          }
        }, _callee6, this);
      }));

      function loadcourses(_x4) {
        return _ref7.apply(this, arguments);
      }

      return loadcourses;
    }()
  }, {
    key: "onPageScroll",
    value: function onPageScroll(e) {
      if (e.scrollTop > 410) {
        if (!this.isfixed) {
          this.isfixed = true;
          this.$apply();
        }
      } else {
        if (this.isfixed) {
          this.isfixed = false;
          this.$apply();
        }
      }
    }
  }, {
    key: "onReachBottom",
    value: function onReachBottom() {
      this.getMore();
    }
  }, {
    key: "getMore",
    value: function () {
      var _ref8 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee7() {
        return regeneratorRuntime.wrap(function _callee7$(_context7) {
          while (1) {
            switch (_context7.prev = _context7.next) {
              case 0:
                if (!this.loadmoring) {
                  _context7.next = 2;
                  break;
                }

                return _context7.abrupt("return", false);

              case 2:
                this.loadmoring = true;
                this.showMore();
                _context7.next = 6;
                return this.loadcourses(this.pageIndex + 1);

              case 6:
                this.loadmoring = false;
                this.$apply();

              case 8:
              case "end":
                return _context7.stop();
            }
          }
        }, _callee7, this);
      }));

      function getMore() {
        return _ref8.apply(this, arguments);
      }

      return getMore;
    }()
  }]);

  return Dialog;
}(_wepy2.default.page)) || _class);

Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/home/index'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LmpzIl0sIm5hbWVzIjpbIl9zY3JvbGxOYXYiLCJpZCIsIm5hbWUiLCJEaWFsb2ciLCJjaXR5Iiwic3RvcmUiLCJnZXQiLCJkYXRhIiwiaXNmaXhlZCIsInRoZW1lIiwid2VweSIsIiRpbnN0YW5jZSIsImdsb2JhbERhdGEiLCJ0aGVtZUNvbG9yIiwic3dpcGVycyIsInR5cGUiLCJsaXN0IiwibmF2cyIsImdyaWRDb2wiLCJza2luIiwic2Nyb2xsTmF2IiwiY291cnNlcyIsImlzU2hvdyIsImNvdXJzZVR5cGVJZCIsInNvcnQiLCJwYWdlSW5kZXgiLCJwYWdlU2l6ZSIsInRvbG9hZCIsImlzTG9hZCIsImxvYWRtb3JpbmciLCJfY2l0eSIsIiRyZXBlYXQiLCIkcHJvcHMiLCIkZXZlbnRzIiwiY29tcG9uZW50cyIsImNTd2lwZXIiLCJOYXZzIiwiY0hlYWRlciIsImNDYXJkIiwibG9hZGluZyIsImhlbCIsIm9yZGVyaW5nIiwiY29uZmlnIiwibmF2aWdhdGlvbkJhclRpdGxlVGV4dCIsImVuYWJsZVB1bGxEb3duUmVmcmVzaCIsIm1ldGhvZHMiLCJnZXRTY3JlZW4iLCJrZXkiLCJzY3JlZW4iLCJsb2FkY291cnNlcyIsIiRhcHBseSIsInJlcyIsImZyb20iLCJjb25zb2xlIiwibG9nIiwidGFyZ2V0IiwidGl0bGUiLCJwYXRoIiwic2V0TmF2aWdhdGlvbkJhckNvbG9yIiwiZnJvbnRDb2xvciIsImJhY2tncm91bmRDb2xvciIsInN1Y2Nlc3MiLCJhdXRoIiwibG9naW4iLCJsb2FkIiwid3giLCJzdG9wUHVsbERvd25SZWZyZXNoIiwicGFnZSIsImdldEluZGV4IiwiaG9tZURhdGEiLCJiYW5uZXJzIiwiY29uY2F0IiwidHlwZXMiLCJjaXR5TmFtZSIsImNpdHlDb2RlIiwic2F2ZSIsImNvZGUiLCIkaW52b2tlIiwibmV3T3JkZXJMaXN0IiwicGFyYW1zIiwiZ2V0Q291cnNlcyIsImxlbmd0aCIsIm5vTW9yZSIsImUiLCJzY3JvbGxUb3AiLCJnZXRNb3JlIiwic2hvd01vcmUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7O0FBS0U7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7Ozs7Ozs7OztBQWhCQSxJQUFNQSxhQUFhLENBQUM7QUFDbEJDLE1BQUksQ0FEYztBQUVsQkMsUUFBTTtBQUZZLENBQUQsQ0FBbkI7SUFzQnFCQyxNLFdBSHBCLHdCQUFRO0FBQ1BDLFFBQU1DLGdCQUFNQyxHQUFOLENBQVUsTUFBVjtBQURDLENBQVIsQzs7Ozs7Ozs7Ozs7Ozs7c0xBSUNDLEksR0FBTztBQUNMQyxlQUFTLEtBREo7QUFFTEMsYUFBT0MsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCQyxVQUY1QjtBQUdMQyxlQUFTO0FBQ1BDLGNBQU0sQ0FEQztBQUVQQyxjQUFNO0FBRkMsT0FISjtBQU9MQyxZQUFNO0FBQ0pELGNBQU0sRUFERjtBQUVKRSxpQkFBUyxDQUZMO0FBR0pDLGNBQU07QUFIRixPQVBEO0FBWUxDLGlCQUFXLENBQUM7QUFDVm5CLFlBQUksQ0FETTtBQUVWQyxjQUFNO0FBRkksT0FBRCxDQVpOO0FBZ0JMbUIsZUFBUyxFQWhCSjtBQWlCTEMsY0FBUSxLQWpCSDtBQWtCTEMsb0JBQWMsQ0FsQlQ7QUFtQkxDLFlBQU0sQ0FuQkQ7QUFvQkxDLGlCQUFXLENBcEJOO0FBcUJMQyxnQkFBVSxFQXJCTDtBQXNCTEMsY0FBUSxLQXRCSDtBQXVCTEMsY0FBUSxJQXZCSDtBQXdCTEMsa0JBQVksS0F4QlA7QUF5QkxDLGFBQU87QUF6QkYsSyxRQTJCUkMsTyxHQUFVLEUsUUFDYkMsTSxHQUFTLEVBQUMsV0FBVSxFQUFDLGdCQUFlLEVBQWhCLEVBQW1CLHFCQUFvQixTQUF2QyxFQUFYLEVBQTZELFFBQU8sRUFBQyxxQkFBb0IsTUFBckIsRUFBcEUsRUFBaUcsYUFBWSxFQUFDLHVCQUFzQixTQUF2QixFQUFpQyxxQkFBb0IsV0FBckQsRUFBaUUsY0FBYSxFQUE5RSxFQUE3RyxFQUErTCxTQUFRLEVBQUMscUJBQW9CLFNBQXJCLEVBQXZNLEVBQXVPLFdBQVUsRUFBQyxZQUFXLEVBQVosRUFBalAsRSxRQUNUQyxPLEdBQVUsRUFBQyxhQUFZLEVBQUMsWUFBVyxXQUFaLEVBQWIsRSxRQUNUQyxVLEdBQWE7QUFDUkMsK0JBRFE7QUFFUkMsMEJBRlE7QUFHUkMsK0JBSFE7QUFJUmpCLG9DQUpRO0FBS1JrQiw0QkFMUTtBQU1SQyxnQ0FOUTtBQU9SQyx5QkFQUTtBQVFSQztBQVJRLEssUUFVVkMsTSxHQUFTO0FBQ1BDLDhCQUF3QixRQURqQjtBQUVQQyw2QkFBdUI7QUFGaEIsSyxRQXVIVEMsTyxHQUFVO0FBQ0ZDLGVBREU7QUFBQSw2RkFDUUMsR0FEUixFQUNhQyxNQURiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFTix1QkFBS3pCLFlBQUwsR0FBb0J3QixHQUFwQjtBQUNBLHVCQUFLdkIsSUFBTCxHQUFZd0IsTUFBWjtBQUhNO0FBQUEseUJBSUEsS0FBS0MsV0FBTCxDQUFpQixDQUFqQixDQUpBOztBQUFBO0FBS04sdUJBQUtDLE1BQUw7O0FBTE07QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQSxLOzs7Ozs7QUFuSFY7c0NBQ3NCQyxHLEVBQUs7QUFDbkIsVUFBSUEsSUFBSUMsSUFBSixLQUFhLFFBQWpCLEVBQTJCO0FBQ3ZCO0FBQ0FDLGdCQUFRQyxHQUFSLENBQVlILElBQUlJLE1BQWhCO0FBQ0g7QUFDRCxhQUFPO0FBQ0hDLGVBQU8sUUFESjtBQUVIQyxjQUFNO0FBRkgsT0FBUDtBQUlIOzs7Ozs7Ozs7QUFFSC9DLCtCQUFLZ0QscUJBQUwsQ0FBMkI7QUFDekJDLDhCQUFZLFNBRGEsRUFDRjtBQUN2QkMsbUNBQWlCLEtBQUtuRCxLQUZHLEVBRUk7QUFDN0JvRCwyQkFBUyxzQkFBTyxDQUFFO0FBSE8saUJBQTNCOzt1QkFLTUMsZUFBS0MsS0FBTCxFOzs7O3VCQUNBLEtBQUtDLElBQUwsRTs7O0FBQ04scUJBQUsxQyxNQUFMLEdBQWMsSUFBZDtBQUNBLHFCQUFLNEIsTUFBTDtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztzQkFHSSxDQUFDLEtBQUs1QixNQUFOLElBQWdCLENBQUMsS0FBS2xCLEk7Ozs7O2tEQUNqQixLOzs7O3VCQUVILEtBQUs0RCxJQUFMLENBQVUsQ0FBVixDOzs7QUFDTixxQkFBS2QsTUFBTDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozt1QkFHTSxLQUFLRCxXQUFMLENBQWlCLENBQWpCLEM7OztBQUNOLHFCQUFLeEIsU0FBTCxHQUFpQixDQUFqQjtBQUNBLHFCQUFLeUIsTUFBTDtBQUNBZSxtQkFBR0MsbUJBQUg7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1lBRVNDLEksdUVBQU8sRTs7Ozs7Ozt1QkFDS3pCLGlCQUFPMEIsUUFBUCxDQUFnQjtBQUNuQzdDLGdDQUFjLEtBQUtBLFlBRGdCO0FBRW5DQyx3QkFBTSxLQUFLQSxJQUZ3QjtBQUduQ0MsNkJBQVcwQyxRQUFRLEtBQUsxQyxTQUhXO0FBSW5DQyw0QkFBVSxLQUFLQTtBQUpvQixpQkFBaEIsQzs7O0FBQWpCMkMsd0I7O0FBTUoscUJBQUt2RCxPQUFMLENBQWFFLElBQWIsR0FBb0JxRCxTQUFTQyxPQUE3QjtBQUNBLHFCQUFLckQsSUFBTCxDQUFVRCxJQUFWLEdBQWlCcUQsU0FBU3BELElBQTFCO0FBQ0EscUJBQUtHLFNBQUwsR0FBaUJwQixXQUFXdUUsTUFBWCxDQUFrQkYsU0FBU0csS0FBM0IsQ0FBakI7QUFDQSxxQkFBS25ELE9BQUwsR0FBZWdELFNBQVNoRCxPQUF4QjtBQUNBLHFCQUFLUyxLQUFMLEdBQWF1QyxTQUFTSSxRQUF0QjtBQUNBLG9CQUFJLENBQUMvRCxlQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEI4RCxRQUEvQixFQUF5QztBQUN2Q3JFLGtDQUFNc0UsSUFBTixDQUFXLE1BQVgsRUFBbUI7QUFDakJ6RSwwQkFBTW1FLFNBQVNJLFFBREU7QUFFakJHLDBCQUFNUCxTQUFTSztBQUZFLG1CQUFuQjtBQUlBaEUsaUNBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQjhELFFBQTFCLEdBQXFDTCxTQUFTSyxRQUE5QztBQUNBLHVCQUFLRyxPQUFMLENBQWEsVUFBYixFQUF3QixNQUF4QixFQUErQlIsU0FBU1MsWUFBeEM7QUFDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7OytCQUVRO0FBQ1QsV0FBS2xELE1BQUwsR0FBYyxLQUFkO0FBQ0Q7Ozs2QkFDUTtBQUNQLFdBQUtBLE1BQUwsR0FBYyxJQUFkO0FBQ0Q7Ozs7NEZBQ2lCSCxTOzs7Ozs7QUFDWnNELHNCLEdBQVM7QUFDWHhELGdDQUFjLEtBQUtBLFlBRFI7QUFFWEMsd0JBQU0sS0FBS0EsSUFGQTtBQUdYQyw2QkFBV0EsU0FIQTtBQUlYQyw0QkFBVSxLQUFLQTtBQUpKLGlCOzt1QkFNT2dCLGlCQUFPc0MsVUFBUCxDQUFrQkQsTUFBbEIsQzs7O0FBQWhCMUQsdUI7O29CQUNDQSxRQUFRQSxPQUFSLENBQWdCNEQsTTs7Ozs7QUFDbkIsb0JBQUl4RCxhQUFhLENBQWpCLEVBQW9CO0FBQ2xCLHVCQUFLSixPQUFMLEdBQWVBLFFBQVFBLE9BQXZCO0FBQ0Q7QUFDRCxxQkFBS0ksU0FBTCxHQUFpQkEsU0FBakI7QUFDQSxxQkFBS3lELE1BQUw7QUFDQSxxQkFBS2hDLE1BQUw7a0RBQ08sSzs7O0FBRVAsb0JBQUl6QixZQUFZLENBQWhCLEVBQW1CLEtBQUtBLFNBQUwsR0FBaUJBLFNBQWpCO0FBQ25CLG9CQUFJQSxhQUFhLENBQWpCLEVBQW9CO0FBQ2xCLHVCQUFLSixPQUFMLEdBQWVBLFFBQVFBLE9BQXZCO0FBQ0QsaUJBRkQsTUFFTztBQUNMLHVCQUFLQSxPQUFMLEdBQWUsS0FBS0EsT0FBTCxDQUFha0QsTUFBYixDQUFvQmxELFFBQVFBLE9BQTVCLENBQWY7QUFDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7O2lDQUdROEQsQyxFQUFHO0FBQ2QsVUFBSUEsRUFBRUMsU0FBRixHQUFjLEdBQWxCLEVBQXVCO0FBQ3JCLFlBQUksQ0FBQyxLQUFLNUUsT0FBVixFQUFtQjtBQUNqQixlQUFLQSxPQUFMLEdBQWUsSUFBZjtBQUNBLGVBQUswQyxNQUFMO0FBQ0Q7QUFDRixPQUxELE1BS087QUFDTCxZQUFJLEtBQUsxQyxPQUFULEVBQWtCO0FBQ2hCLGVBQUtBLE9BQUwsR0FBZSxLQUFmO0FBQ0EsZUFBSzBDLE1BQUw7QUFDRDtBQUNGO0FBQ0Y7OztvQ0FDZTtBQUNkLFdBQUttQyxPQUFMO0FBQ0Q7Ozs7Ozs7OztxQkFFSyxLQUFLeEQsVTs7Ozs7a0RBQ0EsSzs7O0FBRVQscUJBQUtBLFVBQUwsR0FBa0IsSUFBbEI7QUFDQSxxQkFBS3lELFFBQUw7O3VCQUNNLEtBQUtyQyxXQUFMLENBQWlCLEtBQUt4QixTQUFMLEdBQWlCLENBQWxDLEM7OztBQUNOLHFCQUFLSSxVQUFMLEdBQWtCLEtBQWxCO0FBQ0EscUJBQUtxQixNQUFMOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBOUpnQ3hDLGVBQUt5RCxJO2tCQUFwQmhFLE0iLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuICBjb25zdCBfc2Nyb2xsTmF2ID0gW3tcclxuICAgIGlkOiAwLFxyXG4gICAgbmFtZTogJ+WFqOmDqCdcclxuICB9XVxyXG4gIGltcG9ydCB3ZXB5IGZyb20gXCJ3ZXB5XCI7XHJcbiAgaW1wb3J0IGNIZWFkZXIgZnJvbSBcIkAvY29tcG9uZW50cy9ob21lL2hlYWRlclwiXHJcbiAgaW1wb3J0IGNTd2lwZXIgZnJvbSBcIkAvY29tcG9uZW50cy9jb21tb24vc3dpcGVyXCJcclxuICBpbXBvcnQgbG9hZGluZyBmcm9tIFwiQC9jb21wb25lbnRzL2NvbW1vbi9sb2FkaW5nXCJcclxuICBpbXBvcnQgTmF2cyBmcm9tIFwiQC9jb21wb25lbnRzL2hvbWUvbmF2c1wiXHJcbiAgaW1wb3J0IHNjcm9sbE5hdiBmcm9tIFwiQC9jb21wb25lbnRzL2hvbWUvc2Nyb2xsTmF2XCJcclxuICBpbXBvcnQgaGVsIGZyb20gXCJAL2NvbXBvbmVudHMvY29tbW9uL2hlbHBcIlxyXG4gIGltcG9ydCBvcmRlcmluZyBmcm9tIFwiQC9jb21wb25lbnRzL2NvbW1vbi9vcmRlcmluZ1wiXHJcbiAgaW1wb3J0IGNDYXJkIGZyb20gXCJAL2NvbXBvbmVudHMvaG9tZS9jQ2FyZFwiXHJcbiAgaW1wb3J0IGNvbmZpZyBmcm9tIFwiQC9hcGkvY29uZmlnXCJcclxuICBpbXBvcnQgYXV0aCBmcm9tIFwiQC9hcGkvYXV0aFwiXHJcbiAgaW1wb3J0IHN0b3JlIGZyb20gXCJAL3N0b3JlL3V0aWxzXCJcclxuICBpbXBvcnQge1xyXG4gICAgY29ubmVjdFxyXG4gIH0gZnJvbSBcIndlcHktcmVkdXhcIlxyXG4gIEBjb25uZWN0KHtcclxuICAgIGNpdHk6IHN0b3JlLmdldChcImNpdHlcIilcclxuICB9KVxyXG4gIGV4cG9ydCBkZWZhdWx0IGNsYXNzIERpYWxvZyBleHRlbmRzIHdlcHkucGFnZSB7XHJcbiAgICBkYXRhID0ge1xyXG4gICAgICBpc2ZpeGVkOiBmYWxzZSxcclxuICAgICAgdGhlbWU6IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEudGhlbWVDb2xvcixcclxuICAgICAgc3dpcGVyczoge1xyXG4gICAgICAgIHR5cGU6IDEsXHJcbiAgICAgICAgbGlzdDogW10sXHJcbiAgICAgIH0sXHJcbiAgICAgIG5hdnM6IHtcclxuICAgICAgICBsaXN0OiBbXSxcclxuICAgICAgICBncmlkQ29sOiA1LFxyXG4gICAgICAgIHNraW46IGZhbHNlXHJcbiAgICAgIH0sXHJcbiAgICAgIHNjcm9sbE5hdjogW3tcclxuICAgICAgICBpZDogMCxcclxuICAgICAgICBuYW1lOiAn5YWo6YOoJ1xyXG4gICAgICB9XSxcclxuICAgICAgY291cnNlczogW10sXHJcbiAgICAgIGlzU2hvdzogZmFsc2UsXHJcbiAgICAgIGNvdXJzZVR5cGVJZDogMCxcclxuICAgICAgc29ydDogMCxcclxuICAgICAgcGFnZUluZGV4OiAxLFxyXG4gICAgICBwYWdlU2l6ZTogMTAsXHJcbiAgICAgIHRvbG9hZDogZmFsc2UsXHJcbiAgICAgIGlzTG9hZDogdHJ1ZSxcclxuICAgICAgbG9hZG1vcmluZzogZmFsc2UsXHJcbiAgICAgIF9jaXR5OiAnJ1xyXG4gICAgfTtcclxuICAgJHJlcGVhdCA9IHt9O1xyXG4kcHJvcHMgPSB7XCJjU3dpcGVyXCI6e1wieG1sbnM6di1iaW5kXCI6XCJcIixcInYtYmluZDptb2RlbC5zeW5jXCI6XCJzd2lwZXJzXCJ9LFwiTmF2c1wiOntcInYtYmluZDptb2RlbC5zeW5jXCI6XCJuYXZzXCJ9LFwic2Nyb2xsTmF2XCI6e1widi1iaW5kOmlzZml4ZWQuc3luY1wiOlwiaXNmaXhlZFwiLFwidi1iaW5kOm1vZGVsLnN5bmNcIjpcInNjcm9sbE5hdlwiLFwieG1sbnM6di1vblwiOlwiXCJ9LFwiY0NhcmRcIjp7XCJ2LWJpbmQ6bW9kZWwuc3luY1wiOlwiY291cnNlc1wifSxcImxvYWRpbmdcIjp7XCJ4bWxuczp3eFwiOlwiXCJ9fTtcclxuJGV2ZW50cyA9IHtcInNjcm9sbE5hdlwiOntcInYtb246cmV0XCI6XCJnZXRTY3JlZW5cIn19O1xyXG4gY29tcG9uZW50cyA9IHtcclxuICAgICAgY1N3aXBlcixcclxuICAgICAgTmF2cyxcclxuICAgICAgY0hlYWRlcixcclxuICAgICAgc2Nyb2xsTmF2LFxyXG4gICAgICBjQ2FyZCxcclxuICAgICAgbG9hZGluZyxcclxuICAgICAgaGVsLFxyXG4gICAgICBvcmRlcmluZ1xyXG4gICAgfVxyXG4gICAgY29uZmlnID0ge1xyXG4gICAgICBuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0OiBcIuWNjuW/g+ahpeS9k+mqjOiQpVwiLFxyXG4gICAgICBlbmFibGVQdWxsRG93blJlZnJlc2g6IHRydWVcclxuICAgIH07XHJcbiAgICAvLyDovazlj5HmmoLml7blhYjkuI3lvIDlkK9cclxuICAgICAgICBvblNoYXJlQXBwTWVzc2FnZShyZXMpIHtcclxuICAgICAgICAgICAgaWYgKHJlcy5mcm9tID09PSAnYnV0dG9uJykge1xyXG4gICAgICAgICAgICAgICAgLy8g5p2l6Ieq6aG16Z2i5YaF6L2s5Y+R5oyJ6ZKuXHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhyZXMudGFyZ2V0KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICB0aXRsZTogJ+WNjuW/g+ahpeS9k+mqjOiQpScsXHJcbiAgICAgICAgICAgICAgICBwYXRoOiAnL3BhZ2VzL2hvbWUvaW5kZXgnXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICBhc3luYyBvbkxvYWQoKSB7XHJcbiAgICAgIHdlcHkuc2V0TmF2aWdhdGlvbkJhckNvbG9yKHtcclxuICAgICAgICBmcm9udENvbG9yOiAnI2ZmZmZmZicsIC8v5YmN5pmv6aKc6Imy5YC877yM5YyF5ous5oyJ6ZKu44CB5qCH6aKY44CB54q25oCB5qCP55qE6aKc6Imy77yM5LuF5pSv5oyBICNmZmZmZmYg5ZKMICMwMDAwMDAsXHJcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiB0aGlzLnRoZW1lLCAvL+iDjOaZr+minOiJsuWAvO+8jOacieaViOWAvOS4uuWNgeWFrei/m+WItuminOiJsixcclxuICAgICAgICBzdWNjZXNzOiByZXMgPT4ge31cclxuICAgICAgfSk7XHJcbiAgICAgIGF3YWl0IGF1dGgubG9naW4oKVxyXG4gICAgICBhd2FpdCB0aGlzLmxvYWQoKVxyXG4gICAgICB0aGlzLmlzU2hvdyA9IHRydWVcclxuICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgICAvLyB0aGlzLiRpbnZva2UoJ2NTd2lwZXInLCAnbG9hZCcsIHRoaXMubW9kZWwpXHJcbiAgICAgIC8vIHRoaXMuJGludm9rZSgnTmF2cycsICdsb2FkJywgdGhpcy5tb2RlbClcclxuICAgIH1cclxuICAgIGFzeW5jIG9uU2hvdygpIHtcclxuICAgICAgaWYgKCF0aGlzLmlzU2hvdyB8fCAhdGhpcy5jaXR5KSB7XHJcbiAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgIH1cclxuICAgICAgYXdhaXQgdGhpcy5sb2FkKDEpXHJcbiAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgIH1cclxuICAgIGFzeW5jIG9uUHVsbERvd25SZWZyZXNoKCkge1xyXG4gICAgICBhd2FpdCB0aGlzLmxvYWRjb3Vyc2VzKDEpXHJcbiAgICAgIHRoaXMucGFnZUluZGV4ID0gMVxyXG4gICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICAgIHd4LnN0b3BQdWxsRG93blJlZnJlc2goKVxyXG4gICAgfVxyXG4gICAgYXN5bmMgbG9hZChwYWdlID0gJycpIHtcclxuICAgICAgbGV0IGhvbWVEYXRhID0gYXdhaXQgY29uZmlnLmdldEluZGV4KHtcclxuICAgICAgICBjb3Vyc2VUeXBlSWQ6IHRoaXMuY291cnNlVHlwZUlkLFxyXG4gICAgICAgIHNvcnQ6IHRoaXMuc29ydCxcclxuICAgICAgICBwYWdlSW5kZXg6IHBhZ2UgfHwgdGhpcy5wYWdlSW5kZXgsXHJcbiAgICAgICAgcGFnZVNpemU6IHRoaXMucGFnZVNpemVcclxuICAgICAgfSlcclxuICAgICAgdGhpcy5zd2lwZXJzLmxpc3QgPSBob21lRGF0YS5iYW5uZXJzXHJcbiAgICAgIHRoaXMubmF2cy5saXN0ID0gaG9tZURhdGEubmF2c1xyXG4gICAgICB0aGlzLnNjcm9sbE5hdiA9IF9zY3JvbGxOYXYuY29uY2F0KGhvbWVEYXRhLnR5cGVzKVxyXG4gICAgICB0aGlzLmNvdXJzZXMgPSBob21lRGF0YS5jb3Vyc2VzXHJcbiAgICAgIHRoaXMuX2NpdHkgPSBob21lRGF0YS5jaXR5TmFtZVxyXG4gICAgICBpZiAoIXdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuY2l0eUNvZGUpIHtcclxuICAgICAgICBzdG9yZS5zYXZlKCdjaXR5Jywge1xyXG4gICAgICAgICAgbmFtZTogaG9tZURhdGEuY2l0eU5hbWUsXHJcbiAgICAgICAgICBjb2RlOiBob21lRGF0YS5jaXR5Q29kZVxyXG4gICAgICAgIH0pXHJcbiAgICAgICAgd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5jaXR5Q29kZSA9IGhvbWVEYXRhLmNpdHlDb2RlXHJcbiAgICAgICAgdGhpcy4kaW52b2tlKCdvcmRlcmluZycsJ2xvYWQnLGhvbWVEYXRhLm5ld09yZGVyTGlzdClcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgc2hvd01vcmUoKSB7XHJcbiAgICAgIHRoaXMuaXNMb2FkID0gZmFsc2VcclxuICAgIH1cclxuICAgIG5vTW9yZSgpIHtcclxuICAgICAgdGhpcy5pc0xvYWQgPSB0cnVlXHJcbiAgICB9XHJcbiAgICBhc3luYyBsb2FkY291cnNlcyhwYWdlSW5kZXgpIHtcclxuICAgICAgbGV0IHBhcmFtcyA9IHtcclxuICAgICAgICBjb3Vyc2VUeXBlSWQ6IHRoaXMuY291cnNlVHlwZUlkLFxyXG4gICAgICAgIHNvcnQ6IHRoaXMuc29ydCxcclxuICAgICAgICBwYWdlSW5kZXg6IHBhZ2VJbmRleCxcclxuICAgICAgICBwYWdlU2l6ZTogdGhpcy5wYWdlU2l6ZVxyXG4gICAgICB9XHJcbiAgICAgIGxldCBjb3Vyc2VzID0gYXdhaXQgY29uZmlnLmdldENvdXJzZXMocGFyYW1zKVxyXG4gICAgICBpZiAoIWNvdXJzZXMuY291cnNlcy5sZW5ndGgpIHtcclxuICAgICAgICBpZiAocGFnZUluZGV4ID09IDEpIHtcclxuICAgICAgICAgIHRoaXMuY291cnNlcyA9IGNvdXJzZXMuY291cnNlc1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLnBhZ2VJbmRleCA9IHBhZ2VJbmRleFxyXG4gICAgICAgIHRoaXMubm9Nb3JlKClcclxuICAgICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgaWYgKHBhZ2VJbmRleCA+IDEpIHRoaXMucGFnZUluZGV4ID0gcGFnZUluZGV4XHJcbiAgICAgICAgaWYgKHBhZ2VJbmRleCA9PSAxKSB7XHJcbiAgICAgICAgICB0aGlzLmNvdXJzZXMgPSBjb3Vyc2VzLmNvdXJzZXNcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgdGhpcy5jb3Vyc2VzID0gdGhpcy5jb3Vyc2VzLmNvbmNhdChjb3Vyc2VzLmNvdXJzZXMpXHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBvblBhZ2VTY3JvbGwoZSkge1xyXG4gICAgICBpZiAoZS5zY3JvbGxUb3AgPiA0MTApIHtcclxuICAgICAgICBpZiAoIXRoaXMuaXNmaXhlZCkge1xyXG4gICAgICAgICAgdGhpcy5pc2ZpeGVkID0gdHJ1ZVxyXG4gICAgICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgICAgIH1cclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBpZiAodGhpcy5pc2ZpeGVkKSB7XHJcbiAgICAgICAgICB0aGlzLmlzZml4ZWQgPSBmYWxzZVxyXG4gICAgICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgb25SZWFjaEJvdHRvbSgpIHtcclxuICAgICAgdGhpcy5nZXRNb3JlKClcclxuICAgIH1cclxuICAgIGFzeW5jIGdldE1vcmUoKSB7XHJcbiAgICAgIGlmICh0aGlzLmxvYWRtb3JpbmcpIHtcclxuICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgfVxyXG4gICAgICB0aGlzLmxvYWRtb3JpbmcgPSB0cnVlXHJcbiAgICAgIHRoaXMuc2hvd01vcmUoKVxyXG4gICAgICBhd2FpdCB0aGlzLmxvYWRjb3Vyc2VzKHRoaXMucGFnZUluZGV4ICsgMSlcclxuICAgICAgdGhpcy5sb2FkbW9yaW5nID0gZmFsc2VcclxuICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgfVxyXG4gICAgbWV0aG9kcyA9IHtcclxuICAgICAgYXN5bmMgZ2V0U2NyZWVuKGtleSwgc2NyZWVuKSB7XHJcbiAgICAgICAgdGhpcy5jb3Vyc2VUeXBlSWQgPSBrZXlcclxuICAgICAgICB0aGlzLnNvcnQgPSBzY3JlZW5cclxuICAgICAgICBhd2FpdCB0aGlzLmxvYWRjb3Vyc2VzKDEpXHJcbiAgICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgICB9LFxyXG4gICAgfTtcclxuICB9XHJcbiJdfQ==