"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

var _WxUtils = require('./../../utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
    _inherits(Dialog, _wepy$page);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
            navigationBarTitleText: "我的订单"
        }, _this.data = {
            theme: _wepy2.default.$instance.globalData.themeColor,
            orderType: [{
                name: '全部',
                orderState: '0'
            }, {
                name: '待付款',
                orderState: '1'
            }, {
                name: '待参加',
                orderState: '2'
            }, {
                name: '已完成',
                orderState: '3'
            }],
            orderState: {
                1: '待付款',
                2: '待参加',
                3: '已完成',
                4: '已取消'
            },
            orderStats: {},
            TabCur: 0,
            scrollLeft: 0,
            pageIndex: 1,
            orders: [],
            toload: false,
            isload: true,
            loadmoring: false
        }, _this.methods = {
            remark: function remark(id) {
                _wepy2.default.navigateTo({
                    url: '/pages/meet/commiRemarke?id=' + id
                });
            },
            getMore: function () {
                var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
                    return regeneratorRuntime.wrap(function _callee$(_context) {
                        while (1) {
                            switch (_context.prev = _context.next) {
                                case 0:
                                    if (!this.loadmoring) {
                                        _context.next = 2;
                                        break;
                                    }

                                    return _context.abrupt("return", false);

                                case 2:
                                    this.loadmoring = true;
                                    this.toload = false;
                                    _context.next = 6;
                                    return this.loadData(this.pageIndex + 1);

                                case 6:
                                    this.$apply();

                                case 7:
                                case "end":
                                    return _context.stop();
                            }
                        }
                    }, _callee, this);
                }));

                function getMore() {
                    return _ref2.apply(this, arguments);
                }

                return getMore;
            }(),
            cancle: function cancle(id) {
                var self = this;
                wx.showModal({
                    content: '取消订单后将无法恢复！是否继续？',
                    // confirmText:,
                    success: function () {
                        var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(res) {
                            var _res;

                            return regeneratorRuntime.wrap(function _callee2$(_context2) {
                                while (1) {
                                    switch (_context2.prev = _context2.next) {
                                        case 0:
                                            if (!res.confirm) {
                                                _context2.next = 10;
                                                break;
                                            }

                                            _context2.next = 3;
                                            return _config2.default.cancalorder(id);

                                        case 3:
                                            _res = _context2.sent;

                                            if (!(_res.errcode == 200)) {
                                                _context2.next = 7;
                                                break;
                                            }

                                            _context2.next = 7;
                                            return self.loadData(1);

                                        case 7:
                                            console.log(_res);
                                            _context2.next = 11;
                                            break;

                                        case 10:
                                            if (res.cancel) {
                                                console.log('用户点击取消');
                                            }

                                        case 11:
                                        case "end":
                                            return _context2.stop();
                                    }
                                }
                            }, _callee2, this);
                        }));

                        function success(_x) {
                            return _ref3.apply(this, arguments);
                        }

                        return success;
                    }()
                });
            },
            tabSelect: function () {
                var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(id, e) {
                    return regeneratorRuntime.wrap(function _callee3$(_context3) {
                        while (1) {
                            switch (_context3.prev = _context3.next) {
                                case 0:
                                    if (!(this.TabCur == e.currentTarget.dataset.id)) {
                                        _context3.next = 2;
                                        break;
                                    }

                                    return _context3.abrupt("return", false);

                                case 2:
                                    this.TabCur = e.currentTarget.dataset.id;
                                    this.scrollLeft = (e.currentTarget.dataset.id - 1) * 120;
                                    this.pageIndex = 1;
                                    _context3.next = 7;
                                    return this.loadData(1);

                                case 7:
                                case "end":
                                    return _context3.stop();
                            }
                        }
                    }, _callee3, this);
                }));

                function tabSelect(_x2, _x3) {
                    return _ref4.apply(this, arguments);
                }

                return tabSelect;
            }(),
            todetaile: function todetaile(id) {
                _wepy2.default.navigateTo({
                    url: './order?id=' + id
                });
            },
            pay: function () {
                var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4(e) {
                    var _code;

                    return regeneratorRuntime.wrap(function _callee4$(_context4) {
                        while (1) {
                            switch (_context4.prev = _context4.next) {
                                case 0:
                                    _context4.next = 2;
                                    return _config2.default.wxpaytopay({
                                        orderPaySn: e.paySn,
                                        describe: '描述',
                                        money: parseInt(e.moneyOrder * 100)
                                    });

                                case 2:
                                    _code = _context4.sent;

                                    _WxUtils2.default.wxPay(_code.data).then(function (res) {
                                        _Tips2.default.toast("支付成功", function (res) {
                                            _WxUtils2.default.backOrRedirect("/pages/my/order?id=" + e.id);
                                        });
                                    });

                                case 4:
                                case "end":
                                    return _context4.stop();
                            }
                        }
                    }, _callee4, this);
                }));

                function pay(_x4) {
                    return _ref5.apply(this, arguments);
                }

                return pay;
            }()
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(Dialog, [{
        key: "onLoad",
        value: function () {
            var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5(opt) {
                return regeneratorRuntime.wrap(function _callee5$(_context5) {
                    while (1) {
                        switch (_context5.prev = _context5.next) {
                            case 0:
                                this.TabCur = this.orderType.findIndex(function (e) {
                                    return e.orderState == opt.id;
                                });
                                this.scrollLeft = (this.TabCur - 1) * 120;
                                _context5.next = 4;
                                return this.loadData();

                            case 4:
                                this.isload = false;

                            case 5:
                            case "end":
                                return _context5.stop();
                        }
                    }
                }, _callee5, this);
            }));

            function onLoad(_x5) {
                return _ref6.apply(this, arguments);
            }

            return onLoad;
        }()
    }, {
        key: "onShow",
        value: function () {
            var _ref7 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
                return regeneratorRuntime.wrap(function _callee6$(_context6) {
                    while (1) {
                        switch (_context6.prev = _context6.next) {
                            case 0:
                                if (this.isload) {
                                    _context6.next = 5;
                                    break;
                                }

                                this.loadmoring = false;
                                this.pageIndex = 1;
                                _context6.next = 5;
                                return this.loadData(1);

                            case 5:
                            case "end":
                                return _context6.stop();
                        }
                    }
                }, _callee6, this);
            }));

            function onShow() {
                return _ref7.apply(this, arguments);
            }

            return onShow;
        }()
    }, {
        key: "loadData",
        value: function () {
            var _ref8 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee7(pageIndex) {
                var params, res, ordersList;
                return regeneratorRuntime.wrap(function _callee7$(_context7) {
                    while (1) {
                        switch (_context7.prev = _context7.next) {
                            case 0:
                                params = {
                                    orderState: this.orderType[this.TabCur].orderState,
                                    pageIndex: pageIndex || this.pageIndex,
                                    pageSize: 10
                                };
                                _context7.next = 3;
                                return _config2.default.orders(params);

                            case 3:
                                res = _context7.sent;

                                if (!(res.errcode == 200)) {
                                    _context7.next = 20;
                                    break;
                                }

                                ordersList = res.data.ordersList;

                                this.orderStats = res.data.orderStats;

                                if (ordersList.length) {
                                    _context7.next = 16;
                                    break;
                                }

                                if (pageIndex == 1) {
                                    this.orders = ordersList;
                                }
                                this.pageIndex = pageIndex;
                                this.toload = true;
                                this.loadmoring = true;
                                this.$apply();
                                return _context7.abrupt("return", false);

                            case 16:
                                if (pageIndex > 1) this.pageIndex = pageIndex;
                                if (pageIndex == 1) {
                                    this.orders = ordersList;
                                } else {
                                    this.orders = this.orders.concat(ordersList);
                                }
                                this.loadmoring = false;

                            case 19:
                                this.$apply();

                            case 20:
                            case "end":
                                return _context7.stop();
                        }
                    }
                }, _callee7, this);
            }));

            function loadData(_x6) {
                return _ref8.apply(this, arguments);
            }

            return loadData;
        }()
    }, {
        key: "onShareAppMessage",
        value: function onShareAppMessage(res) {
            var params = {
                title: '',
                imageUrl: '',
                path: ''
            };
            if (res.from === 'button') {
                // 来自页面内转发按钮
                console.log(res.target);
                var tar = res.target;
                if (tar.dataset.act == 'pt') {
                    params.title = tar.dataset.title;
                    params.imageUrl = tar.dataset.images;
                    params.path = '/pages/activity/pintuan?aid=' + tar.dataset.actid;
                }
            }
            return {
                title: params.title,
                imageUrl: params.imageUrl,
                path: params.path
            };
        }
    }]);

    return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/my/orders'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm9yZGVycy5qcyJdLCJuYW1lcyI6WyJEaWFsb2ciLCJjb25maWciLCJuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0IiwiZGF0YSIsInRoZW1lIiwid2VweSIsIiRpbnN0YW5jZSIsImdsb2JhbERhdGEiLCJ0aGVtZUNvbG9yIiwib3JkZXJUeXBlIiwibmFtZSIsIm9yZGVyU3RhdGUiLCJvcmRlclN0YXRzIiwiVGFiQ3VyIiwic2Nyb2xsTGVmdCIsInBhZ2VJbmRleCIsIm9yZGVycyIsInRvbG9hZCIsImlzbG9hZCIsImxvYWRtb3JpbmciLCJtZXRob2RzIiwicmVtYXJrIiwiaWQiLCJuYXZpZ2F0ZVRvIiwidXJsIiwiZ2V0TW9yZSIsImxvYWREYXRhIiwiJGFwcGx5IiwiY2FuY2xlIiwic2VsZiIsInd4Iiwic2hvd01vZGFsIiwiY29udGVudCIsInN1Y2Nlc3MiLCJyZXMiLCJjb25maXJtIiwiY2FuY2Fsb3JkZXIiLCJlcnJjb2RlIiwiY29uc29sZSIsImxvZyIsImNhbmNlbCIsInRhYlNlbGVjdCIsImUiLCJjdXJyZW50VGFyZ2V0IiwiZGF0YXNldCIsInRvZGV0YWlsZSIsInBheSIsInd4cGF5dG9wYXkiLCJvcmRlclBheVNuIiwicGF5U24iLCJkZXNjcmliZSIsIm1vbmV5IiwicGFyc2VJbnQiLCJtb25leU9yZGVyIiwiX2NvZGUiLCJXeFV0aWxzIiwid3hQYXkiLCJ0aGVuIiwiVGlwcyIsInRvYXN0IiwiYmFja09yUmVkaXJlY3QiLCJvcHQiLCJmaW5kSW5kZXgiLCJwYXJhbXMiLCJwYWdlU2l6ZSIsIm9yZGVyc0xpc3QiLCJsZW5ndGgiLCJjb25jYXQiLCJ0aXRsZSIsImltYWdlVXJsIiwicGF0aCIsImZyb20iLCJ0YXJnZXQiLCJ0YXIiLCJhY3QiLCJpbWFnZXMiLCJhY3RpZCIsInBhZ2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUNJOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7Ozs7Ozs7Ozs7OztJQUNxQkEsTTs7Ozs7Ozs7Ozs7Ozs7MExBQ2pCQyxNLEdBQVM7QUFDTEMsb0NBQXdCO0FBRG5CLFMsUUFHVEMsSSxHQUFPO0FBQ0hDLG1CQUFPQyxlQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJDLFVBRDlCO0FBRUhDLHVCQUFXLENBQUM7QUFDSkMsc0JBQU0sSUFERjtBQUVKQyw0QkFBWTtBQUZSLGFBQUQsRUFHSjtBQUNDRCxzQkFBTSxLQURQO0FBRUNDLDRCQUFZO0FBRmIsYUFISSxFQU9QO0FBQ0lELHNCQUFNLEtBRFY7QUFFSUMsNEJBQVk7QUFGaEIsYUFQTyxFQVVKO0FBQ0NELHNCQUFNLEtBRFA7QUFFQ0MsNEJBQVk7QUFGYixhQVZJLENBRlI7QUFpQkhBLHdCQUFZO0FBQ1IsbUJBQUcsS0FESztBQUVSLG1CQUFHLEtBRks7QUFHUixtQkFBRyxLQUhLO0FBSVIsbUJBQUc7QUFKSyxhQWpCVDtBQXVCSEMsd0JBQVksRUF2QlQ7QUF3QkhDLG9CQUFRLENBeEJMO0FBeUJIQyx3QkFBWSxDQXpCVDtBQTBCSEMsdUJBQVcsQ0ExQlI7QUEyQkhDLG9CQUFRLEVBM0JMO0FBNEJIQyxvQkFBUSxLQTVCTDtBQTZCSEMsb0JBQVEsSUE3Qkw7QUE4QkhDLHdCQUFZO0FBOUJULFMsUUFvR1BDLE8sR0FBVTtBQUNOQyxrQkFETSxrQkFDQ0MsRUFERCxFQUNLO0FBQ1BqQiwrQkFBS2tCLFVBQUwsQ0FBZ0I7QUFDWkMseUJBQUssaUNBQWlDRjtBQUQxQixpQkFBaEI7QUFHSCxhQUxLO0FBTUFHLG1CQU5BO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlDQU9FLEtBQUtOLFVBUFA7QUFBQTtBQUFBO0FBQUE7O0FBQUEscUVBUVMsS0FSVDs7QUFBQTtBQVVGLHlDQUFLQSxVQUFMLEdBQWtCLElBQWxCO0FBQ0EseUNBQUtGLE1BQUwsR0FBYyxLQUFkO0FBWEU7QUFBQSwyQ0FZSSxLQUFLUyxRQUFMLENBQWMsS0FBS1gsU0FBTCxHQUFpQixDQUEvQixDQVpKOztBQUFBO0FBYUYseUNBQUtZLE1BQUw7O0FBYkU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFlTkMsa0JBZk0sa0JBZUNOLEVBZkQsRUFlSztBQUNQLG9CQUFJTyxPQUFPLElBQVg7QUFDQUMsbUJBQUdDLFNBQUgsQ0FBYTtBQUNUQyw2QkFBUyxrQkFEQTtBQUVUO0FBQ0FDO0FBQUEsNEZBQVMsa0JBQWVDLEdBQWY7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlEQUNEQSxJQUFJQyxPQURIO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUEsbURBRWVsQyxpQkFBT21DLFdBQVAsQ0FBbUJkLEVBQW5CLENBRmY7O0FBQUE7QUFFR1ksZ0RBRkg7O0FBQUEsa0RBR0dBLEtBQUlHLE9BQUosSUFBZSxHQUhsQjtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBLG1EQUlTUixLQUFLSCxRQUFMLENBQWMsQ0FBZCxDQUpUOztBQUFBO0FBTURZLG9EQUFRQyxHQUFSLENBQVlMLElBQVo7QUFOQztBQUFBOztBQUFBO0FBT0UsZ0RBQUlBLElBQUlNLE1BQVIsRUFBZ0I7QUFDbkJGLHdEQUFRQyxHQUFSLENBQVksUUFBWjtBQUNIOztBQVRJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFUOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBSFMsaUJBQWI7QUFlSCxhQWhDSztBQWlDQUUscUJBakNBO0FBQUEsc0dBaUNVbkIsRUFqQ1YsRUFpQ2NvQixDQWpDZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMENBa0NFLEtBQUs3QixNQUFMLElBQWU2QixFQUFFQyxhQUFGLENBQWdCQyxPQUFoQixDQUF3QnRCLEVBbEN6QztBQUFBO0FBQUE7QUFBQTs7QUFBQSxzRUFrQ29ELEtBbENwRDs7QUFBQTtBQW1DRix5Q0FBS1QsTUFBTCxHQUFjNkIsRUFBRUMsYUFBRixDQUFnQkMsT0FBaEIsQ0FBd0J0QixFQUF0QztBQUNBLHlDQUFLUixVQUFMLEdBQWtCLENBQUM0QixFQUFFQyxhQUFGLENBQWdCQyxPQUFoQixDQUF3QnRCLEVBQXhCLEdBQTZCLENBQTlCLElBQW1DLEdBQXJEO0FBQ0EseUNBQUtQLFNBQUwsR0FBaUIsQ0FBakI7QUFyQ0U7QUFBQSwyQ0FzQ0ksS0FBS1csUUFBTCxDQUFjLENBQWQsQ0F0Q0o7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUF3Q05tQixxQkF4Q00scUJBd0NJdkIsRUF4Q0osRUF3Q1E7QUFDVmpCLCtCQUFLa0IsVUFBTCxDQUFnQjtBQUNaQyx5QkFBSyxnQkFBZ0JGO0FBRFQsaUJBQWhCO0FBR0gsYUE1Q0s7QUE2Q0F3QixlQTdDQTtBQUFBLHNHQTZDSUosQ0E3Q0o7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkNBOENnQnpDLGlCQUFPOEMsVUFBUCxDQUFrQjtBQUNoQ0Msb0RBQVlOLEVBQUVPLEtBRGtCO0FBRWhDQyxrREFBVSxJQUZzQjtBQUdoQ0MsK0NBQU9DLFNBQVNWLEVBQUVXLFVBQUYsR0FBZSxHQUF4QjtBQUh5QixxQ0FBbEIsQ0E5Q2hCOztBQUFBO0FBOENFQyx5Q0E5Q0Y7O0FBbURGQyxzREFBUUMsS0FBUixDQUFjRixNQUFNbkQsSUFBcEIsRUFBMEJzRCxJQUExQixDQUErQixlQUFPO0FBQ2xDQyx1REFBS0MsS0FBTCxDQUFXLE1BQVgsRUFBbUIsZUFBTztBQUN0QkosOERBQVFLLGNBQVIsQ0FDSSx3QkFBd0JsQixFQUFFcEIsRUFEOUI7QUFHSCx5Q0FKRDtBQUtILHFDQU5EOztBQW5ERTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBLFM7Ozs7OztrR0FwRUd1QyxHOzs7OztBQUNULHFDQUFLaEQsTUFBTCxHQUFjLEtBQUtKLFNBQUwsQ0FBZXFELFNBQWYsQ0FBeUIsYUFBSztBQUN4QywyQ0FBT3BCLEVBQUUvQixVQUFGLElBQWdCa0QsSUFBSXZDLEVBQTNCO0FBQ0gsaUNBRmEsQ0FBZDtBQUdBLHFDQUFLUixVQUFMLEdBQWtCLENBQUMsS0FBS0QsTUFBTCxHQUFjLENBQWYsSUFBb0IsR0FBdEM7O3VDQUNNLEtBQUthLFFBQUwsRTs7O0FBQ04scUNBQUtSLE1BQUwsR0FBYyxLQUFkOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7b0NBR0ssS0FBS0EsTTs7Ozs7QUFDTixxQ0FBS0MsVUFBTCxHQUFrQixLQUFsQjtBQUNBLHFDQUFLSixTQUFMLEdBQWlCLENBQWpCOzt1Q0FDTSxLQUFLVyxRQUFMLENBQWMsQ0FBZCxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O2tHQUdDWCxTOzs7Ozs7QUFDUGdELHNDLEdBQVM7QUFDVHBELGdEQUFZLEtBQUtGLFNBQUwsQ0FBZSxLQUFLSSxNQUFwQixFQUE0QkYsVUFEL0I7QUFFVEksK0NBQVdBLGFBQWEsS0FBS0EsU0FGcEI7QUFHVGlELDhDQUFVO0FBSEQsaUM7O3VDQUtHL0QsaUJBQU9lLE1BQVAsQ0FBYytDLE1BQWQsQzs7O0FBQVo3QixtQzs7c0NBQ0FBLElBQUlHLE9BQUosSUFBZSxHOzs7OztBQUNYNEIsMEMsR0FBYS9CLElBQUkvQixJQUFKLENBQVM4RCxVOztBQUMxQixxQ0FBS3JELFVBQUwsR0FBa0JzQixJQUFJL0IsSUFBSixDQUFTUyxVQUEzQjs7b0NBQ0txRCxXQUFXQyxNOzs7OztBQUNaLG9DQUFJbkQsYUFBYSxDQUFqQixFQUFvQjtBQUNoQix5Q0FBS0MsTUFBTCxHQUFjaUQsVUFBZDtBQUNIO0FBQ0QscUNBQUtsRCxTQUFMLEdBQWlCQSxTQUFqQjtBQUNBLHFDQUFLRSxNQUFMLEdBQWMsSUFBZDtBQUNBLHFDQUFLRSxVQUFMLEdBQWtCLElBQWxCO0FBQ0EscUNBQUtRLE1BQUw7a0VBQ08sSzs7O0FBRVAsb0NBQUlaLFlBQVksQ0FBaEIsRUFBbUIsS0FBS0EsU0FBTCxHQUFpQkEsU0FBakI7QUFDbkIsb0NBQUlBLGFBQWEsQ0FBakIsRUFBb0I7QUFDaEIseUNBQUtDLE1BQUwsR0FBY2lELFVBQWQ7QUFDSCxpQ0FGRCxNQUVPO0FBQ0gseUNBQUtqRCxNQUFMLEdBQWMsS0FBS0EsTUFBTCxDQUFZbUQsTUFBWixDQUFtQkYsVUFBbkIsQ0FBZDtBQUNIO0FBQ0QscUNBQUs5QyxVQUFMLEdBQWtCLEtBQWxCOzs7QUFFSixxQ0FBS1EsTUFBTDs7Ozs7Ozs7Ozs7Ozs7Ozs7OzBDQUdVTyxHLEVBQUs7QUFDbkIsZ0JBQUk2QixTQUFTO0FBQ1RLLHVCQUFPLEVBREU7QUFFVEMsMEJBQVUsRUFGRDtBQUdUQyxzQkFBTTtBQUhHLGFBQWI7QUFLQSxnQkFBSXBDLElBQUlxQyxJQUFKLEtBQWEsUUFBakIsRUFBMkI7QUFDdkI7QUFDQWpDLHdCQUFRQyxHQUFSLENBQVlMLElBQUlzQyxNQUFoQjtBQUNBLG9CQUFJQyxNQUFNdkMsSUFBSXNDLE1BQWQ7QUFDQSxvQkFBSUMsSUFBSTdCLE9BQUosQ0FBWThCLEdBQVosSUFBbUIsSUFBdkIsRUFBNkI7QUFDekJYLDJCQUFPSyxLQUFQLEdBQWVLLElBQUk3QixPQUFKLENBQVl3QixLQUEzQjtBQUNBTCwyQkFBT00sUUFBUCxHQUFrQkksSUFBSTdCLE9BQUosQ0FBWStCLE1BQTlCO0FBQ0FaLDJCQUFPTyxJQUFQLEdBQWMsaUNBQWlDRyxJQUFJN0IsT0FBSixDQUFZZ0MsS0FBM0Q7QUFDSDtBQUNKO0FBQ0QsbUJBQU87QUFDSFIsdUJBQU9MLE9BQU9LLEtBRFg7QUFFSEMsMEJBQVVOLE9BQU9NLFFBRmQ7QUFHSEMsc0JBQU1QLE9BQU9PO0FBSFYsYUFBUDtBQUtIOzs7O0VBdkcrQmpFLGVBQUt3RSxJOztrQkFBcEI3RSxNIiwiZmlsZSI6Im9yZGVycy5qcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4gICAgaW1wb3J0IHdlcHkgZnJvbSBcIndlcHlcIlxyXG4gICAgaW1wb3J0IGNvbmZpZyBmcm9tIFwiQC9hcGkvY29uZmlnXCJcclxuICAgIGltcG9ydCBUaXBzIGZyb20gXCJAL3V0aWxzL1RpcHNcIlxyXG4gICAgaW1wb3J0IFd4VXRpbHMgZnJvbSBcIkAvdXRpbHMvV3hVdGlsc1wiXHJcbiAgICBleHBvcnQgZGVmYXVsdCBjbGFzcyBEaWFsb2cgZXh0ZW5kcyB3ZXB5LnBhZ2Uge1xyXG4gICAgICAgIGNvbmZpZyA9IHtcclxuICAgICAgICAgICAgbmF2aWdhdGlvbkJhclRpdGxlVGV4dDogXCLmiJHnmoTorqLljZVcIlxyXG4gICAgICAgIH07XHJcbiAgICAgICAgZGF0YSA9IHtcclxuICAgICAgICAgICAgdGhlbWU6IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEudGhlbWVDb2xvcixcclxuICAgICAgICAgICAgb3JkZXJUeXBlOiBbe1xyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU6ICflhajpg6gnLFxyXG4gICAgICAgICAgICAgICAgICAgIG9yZGVyU3RhdGU6ICcwJ1xyXG4gICAgICAgICAgICAgICAgfSwge1xyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU6ICflvoXku5jmrL4nLFxyXG4gICAgICAgICAgICAgICAgICAgIG9yZGVyU3RhdGU6ICcxJ1xyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICBuYW1lOiAn5b6F5Y+C5YqgJyxcclxuICAgICAgICAgICAgICAgICAgICBvcmRlclN0YXRlOiAnMidcclxuICAgICAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgICAgICBuYW1lOiAn5bey5a6M5oiQJyxcclxuICAgICAgICAgICAgICAgICAgICBvcmRlclN0YXRlOiAnMydcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgb3JkZXJTdGF0ZToge1xyXG4gICAgICAgICAgICAgICAgMTogJ+W+heS7mOasvicsXHJcbiAgICAgICAgICAgICAgICAyOiAn5b6F5Y+C5YqgJyxcclxuICAgICAgICAgICAgICAgIDM6ICflt7LlrozmiJAnLFxyXG4gICAgICAgICAgICAgICAgNDogJ+W3suWPlua2iCdcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgb3JkZXJTdGF0czoge30sXHJcbiAgICAgICAgICAgIFRhYkN1cjogMCxcclxuICAgICAgICAgICAgc2Nyb2xsTGVmdDogMCxcclxuICAgICAgICAgICAgcGFnZUluZGV4OiAxLFxyXG4gICAgICAgICAgICBvcmRlcnM6IFtdLFxyXG4gICAgICAgICAgICB0b2xvYWQ6IGZhbHNlLFxyXG4gICAgICAgICAgICBpc2xvYWQ6IHRydWUsXHJcbiAgICAgICAgICAgIGxvYWRtb3Jpbmc6IGZhbHNlLFxyXG4gICAgICAgIH07XHJcbiAgICAgICAgYXN5bmMgb25Mb2FkKG9wdCkge1xyXG4gICAgICAgICAgICB0aGlzLlRhYkN1ciA9IHRoaXMub3JkZXJUeXBlLmZpbmRJbmRleChlID0+IHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBlLm9yZGVyU3RhdGUgPT0gb3B0LmlkXHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIHRoaXMuc2Nyb2xsTGVmdCA9ICh0aGlzLlRhYkN1ciAtIDEpICogMTIwXHJcbiAgICAgICAgICAgIGF3YWl0IHRoaXMubG9hZERhdGEoKVxyXG4gICAgICAgICAgICB0aGlzLmlzbG9hZCA9IGZhbHNlXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGFzeW5jIG9uU2hvdygpIHtcclxuICAgICAgICAgICAgaWYgKCF0aGlzLmlzbG9hZCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5sb2FkbW9yaW5nID0gZmFsc2VcclxuICAgICAgICAgICAgICAgIHRoaXMucGFnZUluZGV4ID0gMVxyXG4gICAgICAgICAgICAgICAgYXdhaXQgdGhpcy5sb2FkRGF0YSgxKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGFzeW5jIGxvYWREYXRhKHBhZ2VJbmRleCkge1xyXG4gICAgICAgICAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICAgICAgICAgICAgb3JkZXJTdGF0ZTogdGhpcy5vcmRlclR5cGVbdGhpcy5UYWJDdXJdLm9yZGVyU3RhdGUsXHJcbiAgICAgICAgICAgICAgICBwYWdlSW5kZXg6IHBhZ2VJbmRleCB8fCB0aGlzLnBhZ2VJbmRleCxcclxuICAgICAgICAgICAgICAgIHBhZ2VTaXplOiAxMFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGxldCByZXMgPSBhd2FpdCBjb25maWcub3JkZXJzKHBhcmFtcylcclxuICAgICAgICAgICAgaWYgKHJlcy5lcnJjb2RlID09IDIwMCkge1xyXG4gICAgICAgICAgICAgICAgbGV0IG9yZGVyc0xpc3QgPSByZXMuZGF0YS5vcmRlcnNMaXN0XHJcbiAgICAgICAgICAgICAgICB0aGlzLm9yZGVyU3RhdHMgPSByZXMuZGF0YS5vcmRlclN0YXRzXHJcbiAgICAgICAgICAgICAgICBpZiAoIW9yZGVyc0xpc3QubGVuZ3RoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHBhZ2VJbmRleCA9PSAxKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMub3JkZXJzID0gb3JkZXJzTGlzdFxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnBhZ2VJbmRleCA9IHBhZ2VJbmRleFxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMudG9sb2FkID0gdHJ1ZVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubG9hZG1vcmluZyA9IHRydWVcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChwYWdlSW5kZXggPiAxKSB0aGlzLnBhZ2VJbmRleCA9IHBhZ2VJbmRleFxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChwYWdlSW5kZXggPT0gMSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm9yZGVycyA9IG9yZGVyc0xpc3RcclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm9yZGVycyA9IHRoaXMub3JkZXJzLmNvbmNhdChvcmRlcnNMaXN0KVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmxvYWRtb3JpbmcgPSBmYWxzZVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIG9uU2hhcmVBcHBNZXNzYWdlKHJlcykge1xyXG4gICAgICAgICAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICAgICAgICAgICAgdGl0bGU6ICcnLFxyXG4gICAgICAgICAgICAgICAgaW1hZ2VVcmw6ICcnLFxyXG4gICAgICAgICAgICAgICAgcGF0aDogJydcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAocmVzLmZyb20gPT09ICdidXR0b24nKSB7XHJcbiAgICAgICAgICAgICAgICAvLyDmnaXoh6rpobXpnaLlhoXovazlj5HmjInpkq5cclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKHJlcy50YXJnZXQpXHJcbiAgICAgICAgICAgICAgICBsZXQgdGFyID0gcmVzLnRhcmdldFxyXG4gICAgICAgICAgICAgICAgaWYgKHRhci5kYXRhc2V0LmFjdCA9PSAncHQnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcGFyYW1zLnRpdGxlID0gdGFyLmRhdGFzZXQudGl0bGVcclxuICAgICAgICAgICAgICAgICAgICBwYXJhbXMuaW1hZ2VVcmwgPSB0YXIuZGF0YXNldC5pbWFnZXNcclxuICAgICAgICAgICAgICAgICAgICBwYXJhbXMucGF0aCA9ICcvcGFnZXMvYWN0aXZpdHkvcGludHVhbj9haWQ9JyArIHRhci5kYXRhc2V0LmFjdGlkXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgIHRpdGxlOiBwYXJhbXMudGl0bGUsXHJcbiAgICAgICAgICAgICAgICBpbWFnZVVybDogcGFyYW1zLmltYWdlVXJsLFxyXG4gICAgICAgICAgICAgICAgcGF0aDogcGFyYW1zLnBhdGhcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBtZXRob2RzID0ge1xyXG4gICAgICAgICAgICByZW1hcmsoaWQpIHtcclxuICAgICAgICAgICAgICAgIHdlcHkubmF2aWdhdGVUbyh7XHJcbiAgICAgICAgICAgICAgICAgICAgdXJsOiAnL3BhZ2VzL21lZXQvY29tbWlSZW1hcmtlP2lkPScgKyBpZFxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGFzeW5jIGdldE1vcmUoKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5sb2FkbW9yaW5nKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB0aGlzLmxvYWRtb3JpbmcgPSB0cnVlXHJcbiAgICAgICAgICAgICAgICB0aGlzLnRvbG9hZCA9IGZhbHNlXHJcbiAgICAgICAgICAgICAgICBhd2FpdCB0aGlzLmxvYWREYXRhKHRoaXMucGFnZUluZGV4ICsgMSlcclxuICAgICAgICAgICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgY2FuY2xlKGlkKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgc2VsZiA9IHRoaXNcclxuICAgICAgICAgICAgICAgIHd4LnNob3dNb2RhbCh7XHJcbiAgICAgICAgICAgICAgICAgICAgY29udGVudDogJ+WPlua2iOiuouWNleWQjuWwhuaXoOazleaBouWkje+8geaYr+WQpue7p+e7re+8nycsXHJcbiAgICAgICAgICAgICAgICAgICAgLy8gY29uZmlybVRleHQ6LFxyXG4gICAgICAgICAgICAgICAgICAgIHN1Y2Nlc3M6IGFzeW5jIGZ1bmN0aW9uKHJlcykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzLmNvbmZpcm0pIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCByZXMgPSBhd2FpdCBjb25maWcuY2FuY2Fsb3JkZXIoaWQpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzLmVycmNvZGUgPT0gMjAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXdhaXQgc2VsZi5sb2FkRGF0YSgxKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2cocmVzKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKHJlcy5jYW5jZWwpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCfnlKjmiLfngrnlh7vlj5bmtognKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgYXN5bmMgdGFiU2VsZWN0KGlkLCBlKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5UYWJDdXIgPT0gZS5jdXJyZW50VGFyZ2V0LmRhdGFzZXQuaWQpIHJldHVybiBmYWxzZVxyXG4gICAgICAgICAgICAgICAgdGhpcy5UYWJDdXIgPSBlLmN1cnJlbnRUYXJnZXQuZGF0YXNldC5pZDtcclxuICAgICAgICAgICAgICAgIHRoaXMuc2Nyb2xsTGVmdCA9IChlLmN1cnJlbnRUYXJnZXQuZGF0YXNldC5pZCAtIDEpICogMTIwXHJcbiAgICAgICAgICAgICAgICB0aGlzLnBhZ2VJbmRleCA9IDFcclxuICAgICAgICAgICAgICAgIGF3YWl0IHRoaXMubG9hZERhdGEoMSlcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgdG9kZXRhaWxlKGlkKSB7XHJcbiAgICAgICAgICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICAgICAgICAgIHVybDogJy4vb3JkZXI/aWQ9JyArIGlkXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgYXN5bmMgcGF5KGUpIHtcclxuICAgICAgICAgICAgICAgIGxldCBfY29kZSA9IGF3YWl0IGNvbmZpZy53eHBheXRvcGF5KHtcclxuICAgICAgICAgICAgICAgICAgICBvcmRlclBheVNuOiBlLnBheVNuLFxyXG4gICAgICAgICAgICAgICAgICAgIGRlc2NyaWJlOiAn5o+P6L+wJyxcclxuICAgICAgICAgICAgICAgICAgICBtb25leTogcGFyc2VJbnQoZS5tb25leU9yZGVyICogMTAwKVxyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgIFd4VXRpbHMud3hQYXkoX2NvZGUuZGF0YSkudGhlbihyZXMgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIFRpcHMudG9hc3QoXCLmlK/ku5jmiJDlip9cIiwgcmVzID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgV3hVdGlscy5iYWNrT3JSZWRpcmVjdChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGAvcGFnZXMvbXkvb3JkZXI/aWQ9YCArIGUuaWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9O1xyXG4gICAgfVxyXG4iXX0=