"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

var _WxUtils = require('./../../utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
    _inherits(Dialog, _wepy$page);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
            navigationBarTitleText: "我的订单"
        }, _this.data = {
            theme: _wepy2.default.$instance.globalData.themeColor,
            orderType: [{
                name: '全部',
                orderState: '0'
            }, {
                name: '待付款',
                orderState: '1'
            }, {
                name: '待参加',
                orderState: '2'
            }, {
                name: '已完成',
                orderState: '3'
            }, {
                name: '待拼团',
                orderState: '5'
            }],
            orderState: {
                1: '待付款',
                2: '待参加',
                3: '已完成',
                4: '已取消',
                5: '拼团中'
            },
            orderStats: {},
            TabCur: 0,
            scrollLeft: 0,
            pageIndex: 1,
            orders: [],
            toload: false,
            isload: true,
            loadmoring: false
        }, _this.methods = {
            remark: function remark(id) {
                _wepy2.default.navigateTo({
                    url: '/pages/meet/commiRemarke?id=' + id
                });
            },
            getMore: function () {
                var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
                    return regeneratorRuntime.wrap(function _callee$(_context) {
                        while (1) {
                            switch (_context.prev = _context.next) {
                                case 0:
                                    if (!this.loadmoring) {
                                        _context.next = 2;
                                        break;
                                    }

                                    return _context.abrupt("return", false);

                                case 2:
                                    this.loadmoring = true;
                                    this.toload = false;
                                    _context.next = 6;
                                    return this.loadData(this.pageIndex + 1);

                                case 6:
                                    this.$apply();

                                case 7:
                                case "end":
                                    return _context.stop();
                            }
                        }
                    }, _callee, this);
                }));

                function getMore() {
                    return _ref2.apply(this, arguments);
                }

                return getMore;
            }(),
            cancle: function cancle(id) {
                var self = this;
                wx.showModal({
                    content: '取消订单后将无法恢复！是否继续？',
                    // confirmText:,
                    success: function () {
                        var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(res) {
                            var _res;

                            return regeneratorRuntime.wrap(function _callee2$(_context2) {
                                while (1) {
                                    switch (_context2.prev = _context2.next) {
                                        case 0:
                                            if (!res.confirm) {
                                                _context2.next = 10;
                                                break;
                                            }

                                            _context2.next = 3;
                                            return _config2.default.cancalorder(id);

                                        case 3:
                                            _res = _context2.sent;

                                            if (!(_res.errcode == 200)) {
                                                _context2.next = 7;
                                                break;
                                            }

                                            _context2.next = 7;
                                            return self.loadData(1);

                                        case 7:
                                            console.log(_res);
                                            _context2.next = 11;
                                            break;

                                        case 10:
                                            if (res.cancel) {
                                                console.log('用户点击取消');
                                            }

                                        case 11:
                                        case "end":
                                            return _context2.stop();
                                    }
                                }
                            }, _callee2, this);
                        }));

                        function success(_x) {
                            return _ref3.apply(this, arguments);
                        }

                        return success;
                    }()
                });
            },
            tabSelect: function () {
                var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(id, e) {
                    return regeneratorRuntime.wrap(function _callee3$(_context3) {
                        while (1) {
                            switch (_context3.prev = _context3.next) {
                                case 0:
                                    if (!(this.TabCur == e.currentTarget.dataset.id)) {
                                        _context3.next = 2;
                                        break;
                                    }

                                    return _context3.abrupt("return", false);

                                case 2:
                                    this.TabCur = e.currentTarget.dataset.id;
                                    this.scrollLeft = (e.currentTarget.dataset.id - 1) * 120;
                                    this.pageIndex = 1;
                                    _context3.next = 7;
                                    return this.loadData(1);

                                case 7:
                                case "end":
                                    return _context3.stop();
                            }
                        }
                    }, _callee3, this);
                }));

                function tabSelect(_x2, _x3) {
                    return _ref4.apply(this, arguments);
                }

                return tabSelect;
            }(),
            todetaile: function todetaile(id) {
                _wepy2.default.navigateTo({
                    url: './order?id=' + id
                });
            },
            pay: function () {
                var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4(e) {
                    var _code;

                    return regeneratorRuntime.wrap(function _callee4$(_context4) {
                        while (1) {
                            switch (_context4.prev = _context4.next) {
                                case 0:
                                    _context4.next = 2;
                                    return _config2.default.wxpaytopay({
                                        orderPaySn: e.paySn,
                                        describe: '描述',
                                        money: e.moneyOrder * 100
                                    });

                                case 2:
                                    _code = _context4.sent;

                                    _WxUtils2.default.wxPay(_code.data).then(function (res) {
                                        _Tips2.default.toast("支付成功", function (res) {
                                            _WxUtils2.default.backOrRedirect("/pages/my/order?id=" + e.id);
                                        });
                                    });

                                case 4:
                                case "end":
                                    return _context4.stop();
                            }
                        }
                    }, _callee4, this);
                }));

                function pay(_x4) {
                    return _ref5.apply(this, arguments);
                }

                return pay;
            }()
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(Dialog, [{
        key: "onLoad",
        value: function () {
            var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5(opt) {
                return regeneratorRuntime.wrap(function _callee5$(_context5) {
                    while (1) {
                        switch (_context5.prev = _context5.next) {
                            case 0:
                                this.TabCur = this.orderType.findIndex(function (e) {
                                    return e.orderState == opt.id;
                                });
                                this.scrollLeft = (this.TabCur - 1) * 120;
                                _context5.next = 4;
                                return this.loadData();

                            case 4:
                                this.isload = false;

                            case 5:
                            case "end":
                                return _context5.stop();
                        }
                    }
                }, _callee5, this);
            }));

            function onLoad(_x5) {
                return _ref6.apply(this, arguments);
            }

            return onLoad;
        }()
    }, {
        key: "onShow",
        value: function () {
            var _ref7 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
                return regeneratorRuntime.wrap(function _callee6$(_context6) {
                    while (1) {
                        switch (_context6.prev = _context6.next) {
                            case 0:
                                if (this.isload) {
                                    _context6.next = 5;
                                    break;
                                }

                                this.loadmoring = false;
                                this.pageIndex = 1;
                                _context6.next = 5;
                                return this.loadData(1);

                            case 5:
                            case "end":
                                return _context6.stop();
                        }
                    }
                }, _callee6, this);
            }));

            function onShow() {
                return _ref7.apply(this, arguments);
            }

            return onShow;
        }()
    }, {
        key: "loadData",
        value: function () {
            var _ref8 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee7(pageIndex) {
                var params, res, ordersList;
                return regeneratorRuntime.wrap(function _callee7$(_context7) {
                    while (1) {
                        switch (_context7.prev = _context7.next) {
                            case 0:
                                params = {
                                    orderState: this.orderType[this.TabCur].orderState,
                                    pageIndex: pageIndex || this.pageIndex,
                                    pageSize: 10
                                };
                                _context7.next = 3;
                                return _config2.default.orders(params);

                            case 3:
                                res = _context7.sent;

                                if (!(res.errcode == 200)) {
                                    _context7.next = 20;
                                    break;
                                }

                                ordersList = res.data.ordersList;

                                this.orderStats = res.data.orderStats;

                                if (ordersList.length) {
                                    _context7.next = 16;
                                    break;
                                }

                                if (pageIndex == 1) {
                                    this.orders = ordersList;
                                }
                                this.pageIndex = pageIndex;
                                this.toload = true;
                                this.loadmoring = true;
                                this.$apply();
                                return _context7.abrupt("return", false);

                            case 16:
                                if (pageIndex > 1) this.pageIndex = pageIndex;
                                if (pageIndex == 1) {
                                    this.orders = ordersList;
                                } else {
                                    this.orders = this.orders.concat(ordersList);
                                }
                                this.loadmoring = false;

                            case 19:
                                this.$apply();

                            case 20:
                            case "end":
                                return _context7.stop();
                        }
                    }
                }, _callee7, this);
            }));

            function loadData(_x6) {
                return _ref8.apply(this, arguments);
            }

            return loadData;
        }()
    }, {
        key: "onShareAppMessage",
        value: function onShareAppMessage(res) {
            var params = {
                title: '',
                imageUrl: '',
                path: ''
            };
            if (res.from === 'button') {
                // 来自页面内转发按钮
                console.log(res.target);
                var tar = res.target;
                if (tar.dataset.act == 'pt') {
                    params.title = tar.dataset.title;
                    params.imageUrl = tar.dataset.images;
                    params.path = '/pages/activity/pintuan?aid=' + tar.dataset.actid;
                }
            }
            return {
                title: params.title,
                imageUrl: params.imageUrl,
                path: params.path
            };
        }
    }]);

    return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/my/orders'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm9yZGVycy5qcyJdLCJuYW1lcyI6WyJEaWFsb2ciLCJjb25maWciLCJuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0IiwiZGF0YSIsInRoZW1lIiwid2VweSIsIiRpbnN0YW5jZSIsImdsb2JhbERhdGEiLCJ0aGVtZUNvbG9yIiwib3JkZXJUeXBlIiwibmFtZSIsIm9yZGVyU3RhdGUiLCJvcmRlclN0YXRzIiwiVGFiQ3VyIiwic2Nyb2xsTGVmdCIsInBhZ2VJbmRleCIsIm9yZGVycyIsInRvbG9hZCIsImlzbG9hZCIsImxvYWRtb3JpbmciLCJtZXRob2RzIiwicmVtYXJrIiwiaWQiLCJuYXZpZ2F0ZVRvIiwidXJsIiwiZ2V0TW9yZSIsImxvYWREYXRhIiwiJGFwcGx5IiwiY2FuY2xlIiwic2VsZiIsInd4Iiwic2hvd01vZGFsIiwiY29udGVudCIsInN1Y2Nlc3MiLCJyZXMiLCJjb25maXJtIiwiY2FuY2Fsb3JkZXIiLCJlcnJjb2RlIiwiY29uc29sZSIsImxvZyIsImNhbmNlbCIsInRhYlNlbGVjdCIsImUiLCJjdXJyZW50VGFyZ2V0IiwiZGF0YXNldCIsInRvZGV0YWlsZSIsInBheSIsInd4cGF5dG9wYXkiLCJvcmRlclBheVNuIiwicGF5U24iLCJkZXNjcmliZSIsIm1vbmV5IiwibW9uZXlPcmRlciIsIl9jb2RlIiwiV3hVdGlscyIsInd4UGF5IiwidGhlbiIsIlRpcHMiLCJ0b2FzdCIsImJhY2tPclJlZGlyZWN0Iiwib3B0IiwiZmluZEluZGV4IiwicGFyYW1zIiwicGFnZVNpemUiLCJvcmRlcnNMaXN0IiwibGVuZ3RoIiwiY29uY2F0IiwidGl0bGUiLCJpbWFnZVVybCIsInBhdGgiLCJmcm9tIiwidGFyZ2V0IiwidGFyIiwiYWN0IiwiaW1hZ2VzIiwiYWN0aWQiLCJwYWdlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFDSTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7Ozs7Ozs7Ozs7Ozs7SUFDcUJBLE07Ozs7Ozs7Ozs7Ozs7OzBMQUNqQkMsTSxHQUFTO0FBQ0xDLG9DQUF3QjtBQURuQixTLFFBR1RDLEksR0FBTztBQUNIQyxtQkFBT0MsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCQyxVQUQ5QjtBQUVIQyx1QkFBVyxDQUFDO0FBQ0pDLHNCQUFNLElBREY7QUFFSkMsNEJBQVk7QUFGUixhQUFELEVBR0o7QUFDQ0Qsc0JBQU0sS0FEUDtBQUVDQyw0QkFBWTtBQUZiLGFBSEksRUFPUDtBQUNJRCxzQkFBTSxLQURWO0FBRUlDLDRCQUFZO0FBRmhCLGFBUE8sRUFVSjtBQUNDRCxzQkFBTSxLQURQO0FBRUNDLDRCQUFZO0FBRmIsYUFWSSxFQWFKO0FBQ0NELHNCQUFNLEtBRFA7QUFFQ0MsNEJBQVk7QUFGYixhQWJJLENBRlI7QUFvQkhBLHdCQUFZO0FBQ1IsbUJBQUcsS0FESztBQUVSLG1CQUFHLEtBRks7QUFHUixtQkFBRyxLQUhLO0FBSVIsbUJBQUcsS0FKSztBQUtSLG1CQUFHO0FBTEssYUFwQlQ7QUEyQkhDLHdCQUFZLEVBM0JUO0FBNEJIQyxvQkFBUSxDQTVCTDtBQTZCSEMsd0JBQVksQ0E3QlQ7QUE4QkhDLHVCQUFXLENBOUJSO0FBK0JIQyxvQkFBUSxFQS9CTDtBQWdDSEMsb0JBQVEsS0FoQ0w7QUFpQ0hDLG9CQUFRLElBakNMO0FBa0NIQyx3QkFBWTtBQWxDVCxTLFFBMEdQQyxPLEdBQVU7QUFDTkMsa0JBRE0sa0JBQ0NDLEVBREQsRUFDSztBQUNQakIsK0JBQUtrQixVQUFMLENBQWdCO0FBQ1pDLHlCQUFLLGlDQUFpQ0Y7QUFEMUIsaUJBQWhCO0FBR0gsYUFMSztBQU1BRyxtQkFOQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5Q0FPRSxLQUFLTixVQVBQO0FBQUE7QUFBQTtBQUFBOztBQUFBLHFFQVFTLEtBUlQ7O0FBQUE7QUFVRix5Q0FBS0EsVUFBTCxHQUFrQixJQUFsQjtBQUNBLHlDQUFLRixNQUFMLEdBQWMsS0FBZDtBQVhFO0FBQUEsMkNBWUksS0FBS1MsUUFBTCxDQUFjLEtBQUtYLFNBQUwsR0FBaUIsQ0FBL0IsQ0FaSjs7QUFBQTtBQWFGLHlDQUFLWSxNQUFMOztBQWJFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBZU5DLGtCQWZNLGtCQWVDTixFQWZELEVBZUs7QUFDUCxvQkFBSU8sT0FBTyxJQUFYO0FBQ0FDLG1CQUFHQyxTQUFILENBQWE7QUFDVEMsNkJBQVMsa0JBREE7QUFFVDtBQUNBQztBQUFBLDRGQUFTLGtCQUFlQyxHQUFmO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpREFDREEsSUFBSUMsT0FESDtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBLG1EQUVlbEMsaUJBQU9tQyxXQUFQLENBQW1CZCxFQUFuQixDQUZmOztBQUFBO0FBRUdZLGdEQUZIOztBQUFBLGtEQUdHQSxLQUFJRyxPQUFKLElBQWUsR0FIbEI7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQSxtREFJU1IsS0FBS0gsUUFBTCxDQUFjLENBQWQsQ0FKVDs7QUFBQTtBQU1EWSxvREFBUUMsR0FBUixDQUFZTCxJQUFaO0FBTkM7QUFBQTs7QUFBQTtBQU9FLGdEQUFJQSxJQUFJTSxNQUFSLEVBQWdCO0FBQ25CRix3REFBUUMsR0FBUixDQUFZLFFBQVo7QUFDSDs7QUFUSTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBVDs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUhTLGlCQUFiO0FBZUgsYUFoQ0s7QUFpQ0FFLHFCQWpDQTtBQUFBLHNHQWlDVW5CLEVBakNWLEVBaUNjb0IsQ0FqQ2Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBDQWtDRSxLQUFLN0IsTUFBTCxJQUFlNkIsRUFBRUMsYUFBRixDQUFnQkMsT0FBaEIsQ0FBd0J0QixFQWxDekM7QUFBQTtBQUFBO0FBQUE7O0FBQUEsc0VBa0NvRCxLQWxDcEQ7O0FBQUE7QUFtQ0YseUNBQUtULE1BQUwsR0FBYzZCLEVBQUVDLGFBQUYsQ0FBZ0JDLE9BQWhCLENBQXdCdEIsRUFBdEM7QUFDQSx5Q0FBS1IsVUFBTCxHQUFrQixDQUFDNEIsRUFBRUMsYUFBRixDQUFnQkMsT0FBaEIsQ0FBd0J0QixFQUF4QixHQUE2QixDQUE5QixJQUFtQyxHQUFyRDtBQUNBLHlDQUFLUCxTQUFMLEdBQWlCLENBQWpCO0FBckNFO0FBQUEsMkNBc0NJLEtBQUtXLFFBQUwsQ0FBYyxDQUFkLENBdENKOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBd0NObUIscUJBeENNLHFCQXdDSXZCLEVBeENKLEVBd0NRO0FBQ1ZqQiwrQkFBS2tCLFVBQUwsQ0FBZ0I7QUFDWkMseUJBQUssZ0JBQWdCRjtBQURULGlCQUFoQjtBQUdILGFBNUNLO0FBNkNBd0IsZUE3Q0E7QUFBQSxzR0E2Q0lKLENBN0NKO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJDQThDZ0J6QyxpQkFBTzhDLFVBQVAsQ0FBa0I7QUFDaENDLG9EQUFZTixFQUFFTyxLQURrQjtBQUVoQ0Msa0RBQVUsSUFGc0I7QUFHaENDLCtDQUFPVCxFQUFFVSxVQUFGLEdBQWU7QUFIVSxxQ0FBbEIsQ0E5Q2hCOztBQUFBO0FBOENFQyx5Q0E5Q0Y7O0FBbURGQyxzREFBUUMsS0FBUixDQUFjRixNQUFNbEQsSUFBcEIsRUFBMEJxRCxJQUExQixDQUErQixlQUFPO0FBQ2xDQyx1REFBS0MsS0FBTCxDQUFXLE1BQVgsRUFBbUIsZUFBTztBQUN0QkosOERBQVFLLGNBQVIsQ0FDSSx3QkFBd0JqQixFQUFFcEIsRUFEOUI7QUFHSCx5Q0FKRDtBQUtILHFDQU5EOztBQW5ERTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBLFM7Ozs7OztrR0F0RUdzQyxHOzs7OztBQUNULHFDQUFLL0MsTUFBTCxHQUFjLEtBQUtKLFNBQUwsQ0FBZW9ELFNBQWYsQ0FBeUIsYUFBSztBQUN4QywyQ0FBT25CLEVBQUUvQixVQUFGLElBQWdCaUQsSUFBSXRDLEVBQTNCO0FBQ0gsaUNBRmEsQ0FBZDtBQUdBLHFDQUFLUixVQUFMLEdBQWtCLENBQUMsS0FBS0QsTUFBTCxHQUFjLENBQWYsSUFBb0IsR0FBdEM7O3VDQUNNLEtBQUthLFFBQUwsRTs7O0FBQ04scUNBQUtSLE1BQUwsR0FBYyxLQUFkOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7b0NBR0ssS0FBS0EsTTs7Ozs7QUFDTixxQ0FBS0MsVUFBTCxHQUFrQixLQUFsQjtBQUNBLHFDQUFLSixTQUFMLEdBQWlCLENBQWpCOzt1Q0FDTSxLQUFLVyxRQUFMLENBQWMsQ0FBZCxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O2tHQUdDWCxTOzs7Ozs7QUFDUCtDLHNDLEdBQVM7QUFDVG5ELGdEQUFZLEtBQUtGLFNBQUwsQ0FBZSxLQUFLSSxNQUFwQixFQUE0QkYsVUFEL0I7QUFFVEksK0NBQVdBLGFBQWEsS0FBS0EsU0FGcEI7QUFHVGdELDhDQUFVO0FBSEQsaUM7O3VDQUtHOUQsaUJBQU9lLE1BQVAsQ0FBYzhDLE1BQWQsQzs7O0FBQVo1QixtQzs7c0NBQ0FBLElBQUlHLE9BQUosSUFBZSxHOzs7OztBQUNYMkIsMEMsR0FBYTlCLElBQUkvQixJQUFKLENBQVM2RCxVOztBQUMxQixxQ0FBS3BELFVBQUwsR0FBa0JzQixJQUFJL0IsSUFBSixDQUFTUyxVQUEzQjs7b0NBQ0tvRCxXQUFXQyxNOzs7OztBQUNaLG9DQUFJbEQsYUFBYSxDQUFqQixFQUFvQjtBQUNoQix5Q0FBS0MsTUFBTCxHQUFjZ0QsVUFBZDtBQUNIO0FBQ0QscUNBQUtqRCxTQUFMLEdBQWlCQSxTQUFqQjtBQUNBLHFDQUFLRSxNQUFMLEdBQWMsSUFBZDtBQUNBLHFDQUFLRSxVQUFMLEdBQWtCLElBQWxCO0FBQ0EscUNBQUtRLE1BQUw7a0VBQ08sSzs7O0FBRVAsb0NBQUlaLFlBQVksQ0FBaEIsRUFBbUIsS0FBS0EsU0FBTCxHQUFpQkEsU0FBakI7QUFDbkIsb0NBQUlBLGFBQWEsQ0FBakIsRUFBb0I7QUFDaEIseUNBQUtDLE1BQUwsR0FBY2dELFVBQWQ7QUFDSCxpQ0FGRCxNQUVPO0FBQ0gseUNBQUtoRCxNQUFMLEdBQWMsS0FBS0EsTUFBTCxDQUFZa0QsTUFBWixDQUFtQkYsVUFBbkIsQ0FBZDtBQUNIO0FBQ0QscUNBQUs3QyxVQUFMLEdBQWtCLEtBQWxCOzs7QUFFSixxQ0FBS1EsTUFBTDs7Ozs7Ozs7Ozs7Ozs7Ozs7OzBDQUlVTyxHLEVBQUs7QUFDbkIsZ0JBQUk0QixTQUFTO0FBQ1RLLHVCQUFPLEVBREU7QUFFVEMsMEJBQVMsRUFGQTtBQUdUQyxzQkFBTTtBQUhHLGFBQWI7QUFLQSxnQkFBSW5DLElBQUlvQyxJQUFKLEtBQWEsUUFBakIsRUFBMkI7QUFDdkI7QUFDQWhDLHdCQUFRQyxHQUFSLENBQVlMLElBQUlxQyxNQUFoQjtBQUNBLG9CQUFJQyxNQUFNdEMsSUFBSXFDLE1BQWQ7QUFDQSxvQkFBR0MsSUFBSTVCLE9BQUosQ0FBWTZCLEdBQVosSUFBbUIsSUFBdEIsRUFBMkI7QUFDdkJYLDJCQUFPSyxLQUFQLEdBQWVLLElBQUk1QixPQUFKLENBQVl1QixLQUEzQjtBQUNBTCwyQkFBT00sUUFBUCxHQUFrQkksSUFBSTVCLE9BQUosQ0FBWThCLE1BQTlCO0FBQ0FaLDJCQUFPTyxJQUFQLEdBQWEsaUNBQWtDRyxJQUFJNUIsT0FBSixDQUFZK0IsS0FBM0Q7QUFDSDtBQUVKO0FBQ0QsbUJBQU87QUFDSFIsdUJBQU9MLE9BQU9LLEtBRFg7QUFFSEMsMEJBQVNOLE9BQU9NLFFBRmI7QUFHSEMsc0JBQUtQLE9BQU9PO0FBSFQsYUFBUDtBQUtIOzs7O0VBN0crQmhFLGVBQUt1RSxJOztrQkFBcEI1RSxNIiwiZmlsZSI6Im9yZGVycy5qcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4gICAgaW1wb3J0IHdlcHkgZnJvbSBcIndlcHlcIlxyXG4gICAgaW1wb3J0IGNvbmZpZyBmcm9tIFwiQC9hcGkvY29uZmlnXCJcclxuICAgIGltcG9ydCBUaXBzIGZyb20gXCJAL3V0aWxzL1RpcHNcIlxyXG4gICAgaW1wb3J0IFd4VXRpbHMgZnJvbSBcIkAvdXRpbHMvV3hVdGlsc1wiXHJcbiAgICBleHBvcnQgZGVmYXVsdCBjbGFzcyBEaWFsb2cgZXh0ZW5kcyB3ZXB5LnBhZ2Uge1xyXG4gICAgICAgIGNvbmZpZyA9IHtcclxuICAgICAgICAgICAgbmF2aWdhdGlvbkJhclRpdGxlVGV4dDogXCLmiJHnmoTorqLljZVcIlxyXG4gICAgICAgIH07XHJcbiAgICAgICAgZGF0YSA9IHtcclxuICAgICAgICAgICAgdGhlbWU6IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEudGhlbWVDb2xvcixcclxuICAgICAgICAgICAgb3JkZXJUeXBlOiBbe1xyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU6ICflhajpg6gnLFxyXG4gICAgICAgICAgICAgICAgICAgIG9yZGVyU3RhdGU6ICcwJ1xyXG4gICAgICAgICAgICAgICAgfSwge1xyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU6ICflvoXku5jmrL4nLFxyXG4gICAgICAgICAgICAgICAgICAgIG9yZGVyU3RhdGU6ICcxJ1xyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICBuYW1lOiAn5b6F5Y+C5YqgJyxcclxuICAgICAgICAgICAgICAgICAgICBvcmRlclN0YXRlOiAnMidcclxuICAgICAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgICAgICBuYW1lOiAn5bey5a6M5oiQJyxcclxuICAgICAgICAgICAgICAgICAgICBvcmRlclN0YXRlOiAnMydcclxuICAgICAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgICAgICBuYW1lOiAn5b6F5ou85ZuiJyxcclxuICAgICAgICAgICAgICAgICAgICBvcmRlclN0YXRlOiAnNSdcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgb3JkZXJTdGF0ZToge1xyXG4gICAgICAgICAgICAgICAgMTogJ+W+heS7mOasvicsXHJcbiAgICAgICAgICAgICAgICAyOiAn5b6F5Y+C5YqgJyxcclxuICAgICAgICAgICAgICAgIDM6ICflt7LlrozmiJAnLFxyXG4gICAgICAgICAgICAgICAgNDogJ+W3suWPlua2iCcsXHJcbiAgICAgICAgICAgICAgICA1OiAn5ou85Zui5LitJ1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBvcmRlclN0YXRzOiB7fSxcclxuICAgICAgICAgICAgVGFiQ3VyOiAwLFxyXG4gICAgICAgICAgICBzY3JvbGxMZWZ0OiAwLFxyXG4gICAgICAgICAgICBwYWdlSW5kZXg6IDEsXHJcbiAgICAgICAgICAgIG9yZGVyczogW10sXHJcbiAgICAgICAgICAgIHRvbG9hZDogZmFsc2UsXHJcbiAgICAgICAgICAgIGlzbG9hZDogdHJ1ZSxcclxuICAgICAgICAgICAgbG9hZG1vcmluZzogZmFsc2UsXHJcbiAgICAgICAgfTtcclxuICAgICAgICBhc3luYyBvbkxvYWQob3B0KSB7XHJcbiAgICAgICAgICAgIHRoaXMuVGFiQ3VyID0gdGhpcy5vcmRlclR5cGUuZmluZEluZGV4KGUgPT4ge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGUub3JkZXJTdGF0ZSA9PSBvcHQuaWRcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgdGhpcy5zY3JvbGxMZWZ0ID0gKHRoaXMuVGFiQ3VyIC0gMSkgKiAxMjBcclxuICAgICAgICAgICAgYXdhaXQgdGhpcy5sb2FkRGF0YSgpXHJcbiAgICAgICAgICAgIHRoaXMuaXNsb2FkID0gZmFsc2VcclxuICAgICAgICB9XHJcbiAgICAgICAgYXN5bmMgb25TaG93KCkge1xyXG4gICAgICAgICAgICBpZiAoIXRoaXMuaXNsb2FkKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmxvYWRtb3JpbmcgPSBmYWxzZVxyXG4gICAgICAgICAgICAgICAgdGhpcy5wYWdlSW5kZXggPSAxXHJcbiAgICAgICAgICAgICAgICBhd2FpdCB0aGlzLmxvYWREYXRhKDEpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgYXN5bmMgbG9hZERhdGEocGFnZUluZGV4KSB7XHJcbiAgICAgICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgICAgICBvcmRlclN0YXRlOiB0aGlzLm9yZGVyVHlwZVt0aGlzLlRhYkN1cl0ub3JkZXJTdGF0ZSxcclxuICAgICAgICAgICAgICAgIHBhZ2VJbmRleDogcGFnZUluZGV4IHx8IHRoaXMucGFnZUluZGV4LFxyXG4gICAgICAgICAgICAgICAgcGFnZVNpemU6IDEwXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGNvbmZpZy5vcmRlcnMocGFyYW1zKVxyXG4gICAgICAgICAgICBpZiAocmVzLmVycmNvZGUgPT0gMjAwKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgb3JkZXJzTGlzdCA9IHJlcy5kYXRhLm9yZGVyc0xpc3RcclxuICAgICAgICAgICAgICAgIHRoaXMub3JkZXJTdGF0cyA9IHJlcy5kYXRhLm9yZGVyU3RhdHNcclxuICAgICAgICAgICAgICAgIGlmICghb3JkZXJzTGlzdC5sZW5ndGgpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAocGFnZUluZGV4ID09IDEpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5vcmRlcnMgPSBvcmRlcnNMaXN0XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMucGFnZUluZGV4ID0gcGFnZUluZGV4XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy50b2xvYWQgPSB0cnVlXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5sb2FkbW9yaW5nID0gdHJ1ZVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHBhZ2VJbmRleCA+IDEpIHRoaXMucGFnZUluZGV4ID0gcGFnZUluZGV4XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHBhZ2VJbmRleCA9PSAxKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMub3JkZXJzID0gb3JkZXJzTGlzdFxyXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMub3JkZXJzID0gdGhpcy5vcmRlcnMuY29uY2F0KG9yZGVyc0xpc3QpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubG9hZG1vcmluZyA9IGZhbHNlXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICAgICAgb25TaGFyZUFwcE1lc3NhZ2UocmVzKSB7XHJcbiAgICAgICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgICAgICB0aXRsZTogJycsXHJcbiAgICAgICAgICAgICAgICBpbWFnZVVybDonJyxcclxuICAgICAgICAgICAgICAgIHBhdGg6ICcnXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKHJlcy5mcm9tID09PSAnYnV0dG9uJykge1xyXG4gICAgICAgICAgICAgICAgLy8g5p2l6Ieq6aG16Z2i5YaF6L2s5Y+R5oyJ6ZKuXHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhyZXMudGFyZ2V0KVxyXG4gICAgICAgICAgICAgICAgbGV0IHRhciA9IHJlcy50YXJnZXRcclxuICAgICAgICAgICAgICAgIGlmKHRhci5kYXRhc2V0LmFjdCA9PSAncHQnKXtcclxuICAgICAgICAgICAgICAgICAgICBwYXJhbXMudGl0bGUgPSB0YXIuZGF0YXNldC50aXRsZVxyXG4gICAgICAgICAgICAgICAgICAgIHBhcmFtcy5pbWFnZVVybCA9IHRhci5kYXRhc2V0LmltYWdlc1xyXG4gICAgICAgICAgICAgICAgICAgIHBhcmFtcy5wYXRoID0nL3BhZ2VzL2FjdGl2aXR5L3BpbnR1YW4/YWlkPScgKyAgdGFyLmRhdGFzZXQuYWN0aWRcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgIHRpdGxlOiBwYXJhbXMudGl0bGUsXHJcbiAgICAgICAgICAgICAgICBpbWFnZVVybDpwYXJhbXMuaW1hZ2VVcmwsXHJcbiAgICAgICAgICAgICAgICBwYXRoOnBhcmFtcy5wYXRoXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgbWV0aG9kcyA9IHtcclxuICAgICAgICAgICAgcmVtYXJrKGlkKSB7XHJcbiAgICAgICAgICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICAgICAgICAgIHVybDogJy9wYWdlcy9tZWV0L2NvbW1pUmVtYXJrZT9pZD0nICsgaWRcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBhc3luYyBnZXRNb3JlKCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMubG9hZG1vcmluZykge1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgdGhpcy5sb2FkbW9yaW5nID0gdHJ1ZVxyXG4gICAgICAgICAgICAgICAgdGhpcy50b2xvYWQgPSBmYWxzZVxyXG4gICAgICAgICAgICAgICAgYXdhaXQgdGhpcy5sb2FkRGF0YSh0aGlzLnBhZ2VJbmRleCArIDEpXHJcbiAgICAgICAgICAgICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGNhbmNsZShpZCkge1xyXG4gICAgICAgICAgICAgICAgbGV0IHNlbGYgPSB0aGlzXHJcbiAgICAgICAgICAgICAgICB3eC5zaG93TW9kYWwoe1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnRlbnQ6ICflj5bmtojorqLljZXlkI7lsIbml6Dms5XmgaLlpI3vvIHmmK/lkKbnu6fnu63vvJ8nLFxyXG4gICAgICAgICAgICAgICAgICAgIC8vIGNvbmZpcm1UZXh0OixcclxuICAgICAgICAgICAgICAgICAgICBzdWNjZXNzOiBhc3luYyBmdW5jdGlvbihyZXMpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlcy5jb25maXJtKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgcmVzID0gYXdhaXQgY29uZmlnLmNhbmNhbG9yZGVyKGlkKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlcy5lcnJjb2RlID09IDIwMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF3YWl0IHNlbGYubG9hZERhdGEoMSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKHJlcylcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChyZXMuY2FuY2VsKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygn55So5oi354K55Ye75Y+W5raIJylcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGFzeW5jIHRhYlNlbGVjdChpZCwgZSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuVGFiQ3VyID09IGUuY3VycmVudFRhcmdldC5kYXRhc2V0LmlkKSByZXR1cm4gZmFsc2VcclxuICAgICAgICAgICAgICAgIHRoaXMuVGFiQ3VyID0gZS5jdXJyZW50VGFyZ2V0LmRhdGFzZXQuaWQ7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNjcm9sbExlZnQgPSAoZS5jdXJyZW50VGFyZ2V0LmRhdGFzZXQuaWQgLSAxKSAqIDEyMFxyXG4gICAgICAgICAgICAgICAgdGhpcy5wYWdlSW5kZXggPSAxXHJcbiAgICAgICAgICAgICAgICBhd2FpdCB0aGlzLmxvYWREYXRhKDEpXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHRvZGV0YWlsZShpZCkge1xyXG4gICAgICAgICAgICAgICAgd2VweS5uYXZpZ2F0ZVRvKHtcclxuICAgICAgICAgICAgICAgICAgICB1cmw6ICcuL29yZGVyP2lkPScgKyBpZFxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGFzeW5jIHBheShlKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgX2NvZGUgPSBhd2FpdCBjb25maWcud3hwYXl0b3BheSh7XHJcbiAgICAgICAgICAgICAgICAgICAgb3JkZXJQYXlTbjogZS5wYXlTbixcclxuICAgICAgICAgICAgICAgICAgICBkZXNjcmliZTogJ+aPj+i/sCcsXHJcbiAgICAgICAgICAgICAgICAgICAgbW9uZXk6IGUubW9uZXlPcmRlciAqIDEwMFxyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgIFd4VXRpbHMud3hQYXkoX2NvZGUuZGF0YSkudGhlbihyZXMgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIFRpcHMudG9hc3QoXCLmlK/ku5jmiJDlip9cIiwgcmVzID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgV3hVdGlscy5iYWNrT3JSZWRpcmVjdChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGAvcGFnZXMvbXkvb3JkZXI/aWQ9YCArIGUuaWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9O1xyXG4gICAgfVxyXG4iXX0=