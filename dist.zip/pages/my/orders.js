"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

var _WxUtils = require('./../../utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
    _inherits(Dialog, _wepy$page);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
            navigationBarTitleText: "我的订单"
        }, _this.data = {
            theme: _wepy2.default.$instance.globalData.themeColor,
            orderType: [{
                name: '全部',
                orderState: '0'
            }, {
                name: '待付款',
                orderState: '1'
            }, {
                name: '待参加',
                orderState: '2'
            }, {
                name: '已完成',
                orderState: '3'
            }],
            orderState: {
                1: '待付款',
                2: '待参加',
                3: '已完成',
                4: '已取消'
            },
            orderStats: {},
            TabCur: 0,
            scrollLeft: 0,
            pageIndex: 1,
            orders: [],
            toload: false,
            isload: true,
            loadmoring: false
        }, _this.methods = {
            remark: function remark(id) {
                _wepy2.default.navigateTo({
                    url: '/pages/meet/commiRemarke?id=' + id
                });
            },
            getMore: function () {
                var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
                    return regeneratorRuntime.wrap(function _callee$(_context) {
                        while (1) {
                            switch (_context.prev = _context.next) {
                                case 0:
                                    if (!this.loadmoring) {
                                        _context.next = 2;
                                        break;
                                    }

                                    return _context.abrupt("return", false);

                                case 2:
                                    this.loadmoring = true;
                                    this.toload = false;
                                    _context.next = 6;
                                    return this.loadData(this.pageIndex + 1);

                                case 6:
                                    this.$apply();

                                case 7:
                                case "end":
                                    return _context.stop();
                            }
                        }
                    }, _callee, this);
                }));

                function getMore() {
                    return _ref2.apply(this, arguments);
                }

                return getMore;
            }(),
            cancle: function cancle(id) {
                var self = this;
                wx.showModal({
                    content: '取消订单后将无法恢复！是否继续？',
                    // confirmText:,
                    success: function () {
                        var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(res) {
                            var _res;

                            return regeneratorRuntime.wrap(function _callee2$(_context2) {
                                while (1) {
                                    switch (_context2.prev = _context2.next) {
                                        case 0:
                                            if (!res.confirm) {
                                                _context2.next = 10;
                                                break;
                                            }

                                            _context2.next = 3;
                                            return _config2.default.cancalorder(id);

                                        case 3:
                                            _res = _context2.sent;

                                            if (!(_res.errcode == 200)) {
                                                _context2.next = 7;
                                                break;
                                            }

                                            _context2.next = 7;
                                            return self.loadData(1);

                                        case 7:
                                            console.log(_res);
                                            _context2.next = 11;
                                            break;

                                        case 10:
                                            if (res.cancel) {
                                                console.log('用户点击取消');
                                            }

                                        case 11:
                                        case "end":
                                            return _context2.stop();
                                    }
                                }
                            }, _callee2, this);
                        }));

                        function success(_x) {
                            return _ref3.apply(this, arguments);
                        }

                        return success;
                    }()
                });
            },
            tabSelect: function () {
                var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(id, e) {
                    return regeneratorRuntime.wrap(function _callee3$(_context3) {
                        while (1) {
                            switch (_context3.prev = _context3.next) {
                                case 0:
                                    if (!(this.TabCur == e.currentTarget.dataset.id)) {
                                        _context3.next = 2;
                                        break;
                                    }

                                    return _context3.abrupt("return", false);

                                case 2:
                                    this.TabCur = e.currentTarget.dataset.id;
                                    this.scrollLeft = (e.currentTarget.dataset.id - 1) * 120;
                                    this.pageIndex = 1;
                                    _context3.next = 7;
                                    return this.loadData(1);

                                case 7:
                                case "end":
                                    return _context3.stop();
                            }
                        }
                    }, _callee3, this);
                }));

                function tabSelect(_x2, _x3) {
                    return _ref4.apply(this, arguments);
                }

                return tabSelect;
            }(),
            todetaile: function todetaile(id) {
                _wepy2.default.navigateTo({
                    url: './order?id=' + id
                });
            },
            pay: function () {
                var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4(e) {
                    var _code;

                    return regeneratorRuntime.wrap(function _callee4$(_context4) {
                        while (1) {
                            switch (_context4.prev = _context4.next) {
                                case 0:
                                    _context4.next = 2;
                                    return _config2.default.wxpaytopay({
                                        orderPaySn: e.paySn,
                                        describe: '描述',
                                        money: e.paymentType == 1 ? parseInt(e.moneyOrder * 100) : parseInt(e.earnesMoney * 100)
                                    });

                                case 2:
                                    _code = _context4.sent;

                                    _WxUtils2.default.wxPay(_code.data).then(function (res) {
                                        _Tips2.default.toast("支付成功", function (res) {
                                            _WxUtils2.default.backOrRedirect("/pages/my/order?id=" + e.id);
                                        });
                                    });

                                case 4:
                                case "end":
                                    return _context4.stop();
                            }
                        }
                    }, _callee4, this);
                }));

                function pay(_x4) {
                    return _ref5.apply(this, arguments);
                }

                return pay;
            }()
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(Dialog, [{
        key: "onLoad",
        value: function () {
            var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5(opt) {
                return regeneratorRuntime.wrap(function _callee5$(_context5) {
                    while (1) {
                        switch (_context5.prev = _context5.next) {
                            case 0:
                                this.TabCur = this.orderType.findIndex(function (e) {
                                    return e.orderState == opt.id;
                                });
                                this.scrollLeft = (this.TabCur - 1) * 120;
                                _context5.next = 4;
                                return this.loadData();

                            case 4:
                                this.isload = false;

                            case 5:
                            case "end":
                                return _context5.stop();
                        }
                    }
                }, _callee5, this);
            }));

            function onLoad(_x5) {
                return _ref6.apply(this, arguments);
            }

            return onLoad;
        }()
    }, {
        key: "onShow",
        value: function () {
            var _ref7 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
                return regeneratorRuntime.wrap(function _callee6$(_context6) {
                    while (1) {
                        switch (_context6.prev = _context6.next) {
                            case 0:
                                if (this.isload) {
                                    _context6.next = 5;
                                    break;
                                }

                                this.loadmoring = false;
                                this.pageIndex = 1;
                                _context6.next = 5;
                                return this.loadData(1);

                            case 5:
                            case "end":
                                return _context6.stop();
                        }
                    }
                }, _callee6, this);
            }));

            function onShow() {
                return _ref7.apply(this, arguments);
            }

            return onShow;
        }()
    }, {
        key: "loadData",
        value: function () {
            var _ref8 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee7(pageIndex) {
                var params, res, ordersList;
                return regeneratorRuntime.wrap(function _callee7$(_context7) {
                    while (1) {
                        switch (_context7.prev = _context7.next) {
                            case 0:
                                params = {
                                    orderState: this.orderType[this.TabCur].orderState,
                                    pageIndex: pageIndex || this.pageIndex,
                                    pageSize: 10
                                };
                                _context7.next = 3;
                                return _config2.default.orders(params);

                            case 3:
                                res = _context7.sent;

                                if (!(res.errcode == 200)) {
                                    _context7.next = 20;
                                    break;
                                }

                                ordersList = res.data.ordersList;

                                this.orderStats = res.data.orderStats;

                                if (ordersList.length) {
                                    _context7.next = 16;
                                    break;
                                }

                                if (pageIndex == 1) {
                                    this.orders = ordersList;
                                }
                                this.pageIndex = pageIndex;
                                this.toload = true;
                                this.loadmoring = true;
                                this.$apply();
                                return _context7.abrupt("return", false);

                            case 16:
                                if (pageIndex > 1) this.pageIndex = pageIndex;
                                if (pageIndex == 1) {
                                    this.orders = ordersList;
                                } else {
                                    this.orders = this.orders.concat(ordersList);
                                }
                                this.loadmoring = false;

                            case 19:
                                this.$apply();

                            case 20:
                            case "end":
                                return _context7.stop();
                        }
                    }
                }, _callee7, this);
            }));

            function loadData(_x6) {
                return _ref8.apply(this, arguments);
            }

            return loadData;
        }()
    }, {
        key: "onShareAppMessage",
        value: function onShareAppMessage(res) {
            var params = {
                title: '',
                imageUrl: '',
                path: ''
            };
            if (res.from === 'button') {
                // 来自页面内转发按钮
                console.log(res.target);
                var tar = res.target;
                if (tar.dataset.act == 'pt') {
                    params.title = tar.dataset.title;
                    params.imageUrl = tar.dataset.images;
                    params.path = '/pages/activity/pintuan?aid=' + tar.dataset.actid;
                }
            }
            return {
                title: params.title,
                imageUrl: params.imageUrl,
                path: params.path
            };
        }
    }]);

    return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/my/orders'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm9yZGVycy5qcyJdLCJuYW1lcyI6WyJEaWFsb2ciLCJjb25maWciLCJuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0IiwiZGF0YSIsInRoZW1lIiwid2VweSIsIiRpbnN0YW5jZSIsImdsb2JhbERhdGEiLCJ0aGVtZUNvbG9yIiwib3JkZXJUeXBlIiwibmFtZSIsIm9yZGVyU3RhdGUiLCJvcmRlclN0YXRzIiwiVGFiQ3VyIiwic2Nyb2xsTGVmdCIsInBhZ2VJbmRleCIsIm9yZGVycyIsInRvbG9hZCIsImlzbG9hZCIsImxvYWRtb3JpbmciLCJtZXRob2RzIiwicmVtYXJrIiwiaWQiLCJuYXZpZ2F0ZVRvIiwidXJsIiwiZ2V0TW9yZSIsImxvYWREYXRhIiwiJGFwcGx5IiwiY2FuY2xlIiwic2VsZiIsInd4Iiwic2hvd01vZGFsIiwiY29udGVudCIsInN1Y2Nlc3MiLCJyZXMiLCJjb25maXJtIiwiY2FuY2Fsb3JkZXIiLCJlcnJjb2RlIiwiY29uc29sZSIsImxvZyIsImNhbmNlbCIsInRhYlNlbGVjdCIsImUiLCJjdXJyZW50VGFyZ2V0IiwiZGF0YXNldCIsInRvZGV0YWlsZSIsInBheSIsInd4cGF5dG9wYXkiLCJvcmRlclBheVNuIiwicGF5U24iLCJkZXNjcmliZSIsIm1vbmV5IiwicGF5bWVudFR5cGUiLCJwYXJzZUludCIsIm1vbmV5T3JkZXIiLCJlYXJuZXNNb25leSIsIl9jb2RlIiwiV3hVdGlscyIsInd4UGF5IiwidGhlbiIsIlRpcHMiLCJ0b2FzdCIsImJhY2tPclJlZGlyZWN0Iiwib3B0IiwiZmluZEluZGV4IiwicGFyYW1zIiwicGFnZVNpemUiLCJvcmRlcnNMaXN0IiwibGVuZ3RoIiwiY29uY2F0IiwidGl0bGUiLCJpbWFnZVVybCIsInBhdGgiLCJmcm9tIiwidGFyZ2V0IiwidGFyIiwiYWN0IiwiaW1hZ2VzIiwiYWN0aWQiLCJwYWdlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFDSTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7Ozs7Ozs7Ozs7Ozs7SUFDcUJBLE07Ozs7Ozs7Ozs7Ozs7OzBMQUNqQkMsTSxHQUFTO0FBQ0xDLG9DQUF3QjtBQURuQixTLFFBR1RDLEksR0FBTztBQUNIQyxtQkFBT0MsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCQyxVQUQ5QjtBQUVIQyx1QkFBVyxDQUFDO0FBQ0pDLHNCQUFNLElBREY7QUFFSkMsNEJBQVk7QUFGUixhQUFELEVBR0o7QUFDQ0Qsc0JBQU0sS0FEUDtBQUVDQyw0QkFBWTtBQUZiLGFBSEksRUFPUDtBQUNJRCxzQkFBTSxLQURWO0FBRUlDLDRCQUFZO0FBRmhCLGFBUE8sRUFVSjtBQUNDRCxzQkFBTSxLQURQO0FBRUNDLDRCQUFZO0FBRmIsYUFWSSxDQUZSO0FBaUJIQSx3QkFBWTtBQUNSLG1CQUFHLEtBREs7QUFFUixtQkFBRyxLQUZLO0FBR1IsbUJBQUcsS0FISztBQUlSLG1CQUFHO0FBSkssYUFqQlQ7QUF1QkhDLHdCQUFZLEVBdkJUO0FBd0JIQyxvQkFBUSxDQXhCTDtBQXlCSEMsd0JBQVksQ0F6QlQ7QUEwQkhDLHVCQUFXLENBMUJSO0FBMkJIQyxvQkFBUSxFQTNCTDtBQTRCSEMsb0JBQVEsS0E1Qkw7QUE2QkhDLG9CQUFRLElBN0JMO0FBOEJIQyx3QkFBWTtBQTlCVCxTLFFBb0dQQyxPLEdBQVU7QUFDTkMsa0JBRE0sa0JBQ0NDLEVBREQsRUFDSztBQUNQakIsK0JBQUtrQixVQUFMLENBQWdCO0FBQ1pDLHlCQUFLLGlDQUFpQ0Y7QUFEMUIsaUJBQWhCO0FBR0gsYUFMSztBQU1BRyxtQkFOQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5Q0FPRSxLQUFLTixVQVBQO0FBQUE7QUFBQTtBQUFBOztBQUFBLHFFQVFTLEtBUlQ7O0FBQUE7QUFVRix5Q0FBS0EsVUFBTCxHQUFrQixJQUFsQjtBQUNBLHlDQUFLRixNQUFMLEdBQWMsS0FBZDtBQVhFO0FBQUEsMkNBWUksS0FBS1MsUUFBTCxDQUFjLEtBQUtYLFNBQUwsR0FBaUIsQ0FBL0IsQ0FaSjs7QUFBQTtBQWFGLHlDQUFLWSxNQUFMOztBQWJFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBZU5DLGtCQWZNLGtCQWVDTixFQWZELEVBZUs7QUFDUCxvQkFBSU8sT0FBTyxJQUFYO0FBQ0FDLG1CQUFHQyxTQUFILENBQWE7QUFDVEMsNkJBQVMsa0JBREE7QUFFVDtBQUNBQztBQUFBLDRGQUFTLGtCQUFlQyxHQUFmO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpREFDREEsSUFBSUMsT0FESDtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBLG1EQUVlbEMsaUJBQU9tQyxXQUFQLENBQW1CZCxFQUFuQixDQUZmOztBQUFBO0FBRUdZLGdEQUZIOztBQUFBLGtEQUdHQSxLQUFJRyxPQUFKLElBQWUsR0FIbEI7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQSxtREFJU1IsS0FBS0gsUUFBTCxDQUFjLENBQWQsQ0FKVDs7QUFBQTtBQU1EWSxvREFBUUMsR0FBUixDQUFZTCxJQUFaO0FBTkM7QUFBQTs7QUFBQTtBQU9FLGdEQUFJQSxJQUFJTSxNQUFSLEVBQWdCO0FBQ25CRix3REFBUUMsR0FBUixDQUFZLFFBQVo7QUFDSDs7QUFUSTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBVDs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUhTLGlCQUFiO0FBZUgsYUFoQ0s7QUFpQ0FFLHFCQWpDQTtBQUFBLHNHQWlDVW5CLEVBakNWLEVBaUNjb0IsQ0FqQ2Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBDQWtDRSxLQUFLN0IsTUFBTCxJQUFlNkIsRUFBRUMsYUFBRixDQUFnQkMsT0FBaEIsQ0FBd0J0QixFQWxDekM7QUFBQTtBQUFBO0FBQUE7O0FBQUEsc0VBa0NvRCxLQWxDcEQ7O0FBQUE7QUFtQ0YseUNBQUtULE1BQUwsR0FBYzZCLEVBQUVDLGFBQUYsQ0FBZ0JDLE9BQWhCLENBQXdCdEIsRUFBdEM7QUFDQSx5Q0FBS1IsVUFBTCxHQUFrQixDQUFDNEIsRUFBRUMsYUFBRixDQUFnQkMsT0FBaEIsQ0FBd0J0QixFQUF4QixHQUE2QixDQUE5QixJQUFtQyxHQUFyRDtBQUNBLHlDQUFLUCxTQUFMLEdBQWlCLENBQWpCO0FBckNFO0FBQUEsMkNBc0NJLEtBQUtXLFFBQUwsQ0FBYyxDQUFkLENBdENKOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBd0NObUIscUJBeENNLHFCQXdDSXZCLEVBeENKLEVBd0NRO0FBQ1ZqQiwrQkFBS2tCLFVBQUwsQ0FBZ0I7QUFDWkMseUJBQUssZ0JBQWdCRjtBQURULGlCQUFoQjtBQUdILGFBNUNLO0FBNkNBd0IsZUE3Q0E7QUFBQSxzR0E2Q0lKLENBN0NKO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJDQThDZ0J6QyxpQkFBTzhDLFVBQVAsQ0FBa0I7QUFDaENDLG9EQUFZTixFQUFFTyxLQURrQjtBQUVoQ0Msa0RBQVUsSUFGc0I7QUFHaENDLCtDQUFPVCxFQUFFVSxXQUFGLElBQWlCLENBQWpCLEdBQXFCQyxTQUFTWCxFQUFFWSxVQUFGLEdBQWUsR0FBeEIsQ0FBckIsR0FBb0RELFNBQVNYLEVBQUVhLFdBQUYsR0FBZ0IsR0FBekI7QUFIM0IscUNBQWxCLENBOUNoQjs7QUFBQTtBQThDRUMseUNBOUNGOztBQW1ERkMsc0RBQVFDLEtBQVIsQ0FBY0YsTUFBTXJELElBQXBCLEVBQTBCd0QsSUFBMUIsQ0FBK0IsZUFBTztBQUNsQ0MsdURBQUtDLEtBQUwsQ0FBVyxNQUFYLEVBQW1CLGVBQU87QUFDdEJKLDhEQUFRSyxjQUFSLENBQ0ksd0JBQXdCcEIsRUFBRXBCLEVBRDlCO0FBR0gseUNBSkQ7QUFLSCxxQ0FORDs7QUFuREU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQSxTOzs7Ozs7a0dBcEVHeUMsRzs7Ozs7QUFDVCxxQ0FBS2xELE1BQUwsR0FBYyxLQUFLSixTQUFMLENBQWV1RCxTQUFmLENBQXlCLGFBQUs7QUFDeEMsMkNBQU90QixFQUFFL0IsVUFBRixJQUFnQm9ELElBQUl6QyxFQUEzQjtBQUNILGlDQUZhLENBQWQ7QUFHQSxxQ0FBS1IsVUFBTCxHQUFrQixDQUFDLEtBQUtELE1BQUwsR0FBYyxDQUFmLElBQW9CLEdBQXRDOzt1Q0FDTSxLQUFLYSxRQUFMLEU7OztBQUNOLHFDQUFLUixNQUFMLEdBQWMsS0FBZDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O29DQUdLLEtBQUtBLE07Ozs7O0FBQ04scUNBQUtDLFVBQUwsR0FBa0IsS0FBbEI7QUFDQSxxQ0FBS0osU0FBTCxHQUFpQixDQUFqQjs7dUNBQ00sS0FBS1csUUFBTCxDQUFjLENBQWQsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztrR0FHQ1gsUzs7Ozs7O0FBQ1BrRCxzQyxHQUFTO0FBQ1R0RCxnREFBWSxLQUFLRixTQUFMLENBQWUsS0FBS0ksTUFBcEIsRUFBNEJGLFVBRC9CO0FBRVRJLCtDQUFXQSxhQUFhLEtBQUtBLFNBRnBCO0FBR1RtRCw4Q0FBVTtBQUhELGlDOzt1Q0FLR2pFLGlCQUFPZSxNQUFQLENBQWNpRCxNQUFkLEM7OztBQUFaL0IsbUM7O3NDQUNBQSxJQUFJRyxPQUFKLElBQWUsRzs7Ozs7QUFDWDhCLDBDLEdBQWFqQyxJQUFJL0IsSUFBSixDQUFTZ0UsVTs7QUFDMUIscUNBQUt2RCxVQUFMLEdBQWtCc0IsSUFBSS9CLElBQUosQ0FBU1MsVUFBM0I7O29DQUNLdUQsV0FBV0MsTTs7Ozs7QUFDWixvQ0FBSXJELGFBQWEsQ0FBakIsRUFBb0I7QUFDaEIseUNBQUtDLE1BQUwsR0FBY21ELFVBQWQ7QUFDSDtBQUNELHFDQUFLcEQsU0FBTCxHQUFpQkEsU0FBakI7QUFDQSxxQ0FBS0UsTUFBTCxHQUFjLElBQWQ7QUFDQSxxQ0FBS0UsVUFBTCxHQUFrQixJQUFsQjtBQUNBLHFDQUFLUSxNQUFMO2tFQUNPLEs7OztBQUVQLG9DQUFJWixZQUFZLENBQWhCLEVBQW1CLEtBQUtBLFNBQUwsR0FBaUJBLFNBQWpCO0FBQ25CLG9DQUFJQSxhQUFhLENBQWpCLEVBQW9CO0FBQ2hCLHlDQUFLQyxNQUFMLEdBQWNtRCxVQUFkO0FBQ0gsaUNBRkQsTUFFTztBQUNILHlDQUFLbkQsTUFBTCxHQUFjLEtBQUtBLE1BQUwsQ0FBWXFELE1BQVosQ0FBbUJGLFVBQW5CLENBQWQ7QUFDSDtBQUNELHFDQUFLaEQsVUFBTCxHQUFrQixLQUFsQjs7O0FBRUoscUNBQUtRLE1BQUw7Ozs7Ozs7Ozs7Ozs7Ozs7OzswQ0FHVU8sRyxFQUFLO0FBQ25CLGdCQUFJK0IsU0FBUztBQUNUSyx1QkFBTyxFQURFO0FBRVRDLDBCQUFVLEVBRkQ7QUFHVEMsc0JBQU07QUFIRyxhQUFiO0FBS0EsZ0JBQUl0QyxJQUFJdUMsSUFBSixLQUFhLFFBQWpCLEVBQTJCO0FBQ3ZCO0FBQ0FuQyx3QkFBUUMsR0FBUixDQUFZTCxJQUFJd0MsTUFBaEI7QUFDQSxvQkFBSUMsTUFBTXpDLElBQUl3QyxNQUFkO0FBQ0Esb0JBQUlDLElBQUkvQixPQUFKLENBQVlnQyxHQUFaLElBQW1CLElBQXZCLEVBQTZCO0FBQ3pCWCwyQkFBT0ssS0FBUCxHQUFlSyxJQUFJL0IsT0FBSixDQUFZMEIsS0FBM0I7QUFDQUwsMkJBQU9NLFFBQVAsR0FBa0JJLElBQUkvQixPQUFKLENBQVlpQyxNQUE5QjtBQUNBWiwyQkFBT08sSUFBUCxHQUFjLGlDQUFpQ0csSUFBSS9CLE9BQUosQ0FBWWtDLEtBQTNEO0FBQ0g7QUFDSjtBQUNELG1CQUFPO0FBQ0hSLHVCQUFPTCxPQUFPSyxLQURYO0FBRUhDLDBCQUFVTixPQUFPTSxRQUZkO0FBR0hDLHNCQUFNUCxPQUFPTztBQUhWLGFBQVA7QUFLSDs7OztFQXZHK0JuRSxlQUFLMEUsSTs7a0JBQXBCL0UsTSIsImZpbGUiOiJvcmRlcnMuanMiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuICAgIGltcG9ydCB3ZXB5IGZyb20gXCJ3ZXB5XCJcclxuICAgIGltcG9ydCBjb25maWcgZnJvbSBcIkAvYXBpL2NvbmZpZ1wiXHJcbiAgICBpbXBvcnQgVGlwcyBmcm9tIFwiQC91dGlscy9UaXBzXCJcclxuICAgIGltcG9ydCBXeFV0aWxzIGZyb20gXCJAL3V0aWxzL1d4VXRpbHNcIlxyXG4gICAgZXhwb3J0IGRlZmF1bHQgY2xhc3MgRGlhbG9nIGV4dGVuZHMgd2VweS5wYWdlIHtcclxuICAgICAgICBjb25maWcgPSB7XHJcbiAgICAgICAgICAgIG5hdmlnYXRpb25CYXJUaXRsZVRleHQ6IFwi5oiR55qE6K6i5Y2VXCJcclxuICAgICAgICB9O1xyXG4gICAgICAgIGRhdGEgPSB7XHJcbiAgICAgICAgICAgIHRoZW1lOiB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnRoZW1lQ29sb3IsXHJcbiAgICAgICAgICAgIG9yZGVyVHlwZTogW3tcclxuICAgICAgICAgICAgICAgICAgICBuYW1lOiAn5YWo6YOoJyxcclxuICAgICAgICAgICAgICAgICAgICBvcmRlclN0YXRlOiAnMCdcclxuICAgICAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgICAgICBuYW1lOiAn5b6F5LuY5qy+JyxcclxuICAgICAgICAgICAgICAgICAgICBvcmRlclN0YXRlOiAnMSdcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZTogJ+W+heWPguWKoCcsXHJcbiAgICAgICAgICAgICAgICAgICAgb3JkZXJTdGF0ZTogJzInXHJcbiAgICAgICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZTogJ+W3suWujOaIkCcsXHJcbiAgICAgICAgICAgICAgICAgICAgb3JkZXJTdGF0ZTogJzMnXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgIG9yZGVyU3RhdGU6IHtcclxuICAgICAgICAgICAgICAgIDE6ICflvoXku5jmrL4nLFxyXG4gICAgICAgICAgICAgICAgMjogJ+W+heWPguWKoCcsXHJcbiAgICAgICAgICAgICAgICAzOiAn5bey5a6M5oiQJyxcclxuICAgICAgICAgICAgICAgIDQ6ICflt7Llj5bmtognXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIG9yZGVyU3RhdHM6IHt9LFxyXG4gICAgICAgICAgICBUYWJDdXI6IDAsXHJcbiAgICAgICAgICAgIHNjcm9sbExlZnQ6IDAsXHJcbiAgICAgICAgICAgIHBhZ2VJbmRleDogMSxcclxuICAgICAgICAgICAgb3JkZXJzOiBbXSxcclxuICAgICAgICAgICAgdG9sb2FkOiBmYWxzZSxcclxuICAgICAgICAgICAgaXNsb2FkOiB0cnVlLFxyXG4gICAgICAgICAgICBsb2FkbW9yaW5nOiBmYWxzZSxcclxuICAgICAgICB9O1xyXG4gICAgICAgIGFzeW5jIG9uTG9hZChvcHQpIHtcclxuICAgICAgICAgICAgdGhpcy5UYWJDdXIgPSB0aGlzLm9yZGVyVHlwZS5maW5kSW5kZXgoZSA9PiB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZS5vcmRlclN0YXRlID09IG9wdC5pZFxyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICB0aGlzLnNjcm9sbExlZnQgPSAodGhpcy5UYWJDdXIgLSAxKSAqIDEyMFxyXG4gICAgICAgICAgICBhd2FpdCB0aGlzLmxvYWREYXRhKClcclxuICAgICAgICAgICAgdGhpcy5pc2xvYWQgPSBmYWxzZVxyXG4gICAgICAgIH1cclxuICAgICAgICBhc3luYyBvblNob3coKSB7XHJcbiAgICAgICAgICAgIGlmICghdGhpcy5pc2xvYWQpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMubG9hZG1vcmluZyA9IGZhbHNlXHJcbiAgICAgICAgICAgICAgICB0aGlzLnBhZ2VJbmRleCA9IDFcclxuICAgICAgICAgICAgICAgIGF3YWl0IHRoaXMubG9hZERhdGEoMSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBhc3luYyBsb2FkRGF0YShwYWdlSW5kZXgpIHtcclxuICAgICAgICAgICAgbGV0IHBhcmFtcyA9IHtcclxuICAgICAgICAgICAgICAgIG9yZGVyU3RhdGU6IHRoaXMub3JkZXJUeXBlW3RoaXMuVGFiQ3VyXS5vcmRlclN0YXRlLFxyXG4gICAgICAgICAgICAgICAgcGFnZUluZGV4OiBwYWdlSW5kZXggfHwgdGhpcy5wYWdlSW5kZXgsXHJcbiAgICAgICAgICAgICAgICBwYWdlU2l6ZTogMTBcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBsZXQgcmVzID0gYXdhaXQgY29uZmlnLm9yZGVycyhwYXJhbXMpXHJcbiAgICAgICAgICAgIGlmIChyZXMuZXJyY29kZSA9PSAyMDApIHtcclxuICAgICAgICAgICAgICAgIGxldCBvcmRlcnNMaXN0ID0gcmVzLmRhdGEub3JkZXJzTGlzdFxyXG4gICAgICAgICAgICAgICAgdGhpcy5vcmRlclN0YXRzID0gcmVzLmRhdGEub3JkZXJTdGF0c1xyXG4gICAgICAgICAgICAgICAgaWYgKCFvcmRlcnNMaXN0Lmxlbmd0aCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChwYWdlSW5kZXggPT0gMSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm9yZGVycyA9IG9yZGVyc0xpc3RcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5wYWdlSW5kZXggPSBwYWdlSW5kZXhcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnRvbG9hZCA9IHRydWVcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmxvYWRtb3JpbmcgPSB0cnVlXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZVxyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAocGFnZUluZGV4ID4gMSkgdGhpcy5wYWdlSW5kZXggPSBwYWdlSW5kZXhcclxuICAgICAgICAgICAgICAgICAgICBpZiAocGFnZUluZGV4ID09IDEpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5vcmRlcnMgPSBvcmRlcnNMaXN0XHJcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5vcmRlcnMgPSB0aGlzLm9yZGVycy5jb25jYXQob3JkZXJzTGlzdClcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5sb2FkbW9yaW5nID0gZmFsc2VcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBvblNoYXJlQXBwTWVzc2FnZShyZXMpIHtcclxuICAgICAgICAgICAgbGV0IHBhcmFtcyA9IHtcclxuICAgICAgICAgICAgICAgIHRpdGxlOiAnJyxcclxuICAgICAgICAgICAgICAgIGltYWdlVXJsOiAnJyxcclxuICAgICAgICAgICAgICAgIHBhdGg6ICcnXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKHJlcy5mcm9tID09PSAnYnV0dG9uJykge1xyXG4gICAgICAgICAgICAgICAgLy8g5p2l6Ieq6aG16Z2i5YaF6L2s5Y+R5oyJ6ZKuXHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhyZXMudGFyZ2V0KVxyXG4gICAgICAgICAgICAgICAgbGV0IHRhciA9IHJlcy50YXJnZXRcclxuICAgICAgICAgICAgICAgIGlmICh0YXIuZGF0YXNldC5hY3QgPT0gJ3B0Jykge1xyXG4gICAgICAgICAgICAgICAgICAgIHBhcmFtcy50aXRsZSA9IHRhci5kYXRhc2V0LnRpdGxlXHJcbiAgICAgICAgICAgICAgICAgICAgcGFyYW1zLmltYWdlVXJsID0gdGFyLmRhdGFzZXQuaW1hZ2VzXHJcbiAgICAgICAgICAgICAgICAgICAgcGFyYW1zLnBhdGggPSAnL3BhZ2VzL2FjdGl2aXR5L3BpbnR1YW4/YWlkPScgKyB0YXIuZGF0YXNldC5hY3RpZFxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICB0aXRsZTogcGFyYW1zLnRpdGxlLFxyXG4gICAgICAgICAgICAgICAgaW1hZ2VVcmw6IHBhcmFtcy5pbWFnZVVybCxcclxuICAgICAgICAgICAgICAgIHBhdGg6IHBhcmFtcy5wYXRoXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgbWV0aG9kcyA9IHtcclxuICAgICAgICAgICAgcmVtYXJrKGlkKSB7XHJcbiAgICAgICAgICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICAgICAgICAgIHVybDogJy9wYWdlcy9tZWV0L2NvbW1pUmVtYXJrZT9pZD0nICsgaWRcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBhc3luYyBnZXRNb3JlKCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMubG9hZG1vcmluZykge1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgdGhpcy5sb2FkbW9yaW5nID0gdHJ1ZVxyXG4gICAgICAgICAgICAgICAgdGhpcy50b2xvYWQgPSBmYWxzZVxyXG4gICAgICAgICAgICAgICAgYXdhaXQgdGhpcy5sb2FkRGF0YSh0aGlzLnBhZ2VJbmRleCArIDEpXHJcbiAgICAgICAgICAgICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGNhbmNsZShpZCkge1xyXG4gICAgICAgICAgICAgICAgbGV0IHNlbGYgPSB0aGlzXHJcbiAgICAgICAgICAgICAgICB3eC5zaG93TW9kYWwoe1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnRlbnQ6ICflj5bmtojorqLljZXlkI7lsIbml6Dms5XmgaLlpI3vvIHmmK/lkKbnu6fnu63vvJ8nLFxyXG4gICAgICAgICAgICAgICAgICAgIC8vIGNvbmZpcm1UZXh0OixcclxuICAgICAgICAgICAgICAgICAgICBzdWNjZXNzOiBhc3luYyBmdW5jdGlvbihyZXMpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlcy5jb25maXJtKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgcmVzID0gYXdhaXQgY29uZmlnLmNhbmNhbG9yZGVyKGlkKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlcy5lcnJjb2RlID09IDIwMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF3YWl0IHNlbGYubG9hZERhdGEoMSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKHJlcylcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChyZXMuY2FuY2VsKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygn55So5oi354K55Ye75Y+W5raIJylcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGFzeW5jIHRhYlNlbGVjdChpZCwgZSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuVGFiQ3VyID09IGUuY3VycmVudFRhcmdldC5kYXRhc2V0LmlkKSByZXR1cm4gZmFsc2VcclxuICAgICAgICAgICAgICAgIHRoaXMuVGFiQ3VyID0gZS5jdXJyZW50VGFyZ2V0LmRhdGFzZXQuaWQ7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNjcm9sbExlZnQgPSAoZS5jdXJyZW50VGFyZ2V0LmRhdGFzZXQuaWQgLSAxKSAqIDEyMFxyXG4gICAgICAgICAgICAgICAgdGhpcy5wYWdlSW5kZXggPSAxXHJcbiAgICAgICAgICAgICAgICBhd2FpdCB0aGlzLmxvYWREYXRhKDEpXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHRvZGV0YWlsZShpZCkge1xyXG4gICAgICAgICAgICAgICAgd2VweS5uYXZpZ2F0ZVRvKHtcclxuICAgICAgICAgICAgICAgICAgICB1cmw6ICcuL29yZGVyP2lkPScgKyBpZFxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGFzeW5jIHBheShlKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgX2NvZGUgPSBhd2FpdCBjb25maWcud3hwYXl0b3BheSh7XHJcbiAgICAgICAgICAgICAgICAgICAgb3JkZXJQYXlTbjogZS5wYXlTbixcclxuICAgICAgICAgICAgICAgICAgICBkZXNjcmliZTogJ+aPj+i/sCcsXHJcbiAgICAgICAgICAgICAgICAgICAgbW9uZXk6IGUucGF5bWVudFR5cGUgPT0gMSA/IHBhcnNlSW50KGUubW9uZXlPcmRlciAqIDEwMCkgOiBwYXJzZUludChlLmVhcm5lc01vbmV5ICogMTAwKVxyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgIFd4VXRpbHMud3hQYXkoX2NvZGUuZGF0YSkudGhlbihyZXMgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIFRpcHMudG9hc3QoXCLmlK/ku5jmiJDlip9cIiwgcmVzID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgV3hVdGlscy5iYWNrT3JSZWRpcmVjdChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGAvcGFnZXMvbXkvb3JkZXI/aWQ9YCArIGUuaWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9O1xyXG4gICAgfVxyXG4iXX0=