"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

var _WxUtils = require('./../../utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

var _contact = require('./../../components/common/contact.js');

var _contact2 = _interopRequireDefault(_contact);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
    _inherits(Dialog, _wepy$page);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
            navigationBarTitleText: "订单详情"
        }, _this.data = {
            orderInfo: {},
            states: {
                1: '待付款',
                2: '待使用',
                3: '已使用',
                4: '已失效'
            },
            id: '',
            opt: {}
        }, _this.components = {
            contact: _contact2.default
        }, _this.methods = {
            remark: function remark(id) {
                _wepy2.default.navigateTo({
                    url: '/pages/meet/commiRemarke?id=' + id
                });
            },
            cancle: function cancle(id) {
                var self = this;
                wx.showModal({
                    content: '取消订单后将无法恢复！是否继续？',
                    success: function () {
                        var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(res) {
                            var _res;

                            return regeneratorRuntime.wrap(function _callee$(_context) {
                                while (1) {
                                    switch (_context.prev = _context.next) {
                                        case 0:
                                            if (!res.confirm) {
                                                _context.next = 7;
                                                break;
                                            }

                                            _context.next = 3;
                                            return _config2.default.cancalorder(id);

                                        case 3:
                                            _res = _context.sent;

                                            if (_res.errcode == 200) {
                                                _wepy2.default.reLaunch({
                                                    url: '/pages/home/index'
                                                });
                                            }
                                            _context.next = 8;
                                            break;

                                        case 7:
                                            if (res.cancel) {}

                                        case 8:
                                        case "end":
                                            return _context.stop();
                                    }
                                }
                            }, _callee, this);
                        }));

                        function success(_x) {
                            return _ref2.apply(this, arguments);
                        }

                        return success;
                    }()
                });
            },
            pay: function () {
                var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(id) {
                    var _this2 = this;

                    var _code;

                    return regeneratorRuntime.wrap(function _callee2$(_context2) {
                        while (1) {
                            switch (_context2.prev = _context2.next) {
                                case 0:
                                    _context2.next = 2;
                                    return _config2.default.wxpaytopay({
                                        orderPaySn: this.orderInfo.paySn,
                                        describe: '描述',
                                        money: this.orderInfo.paymentType == 1 ? parseInt(this.orderInfo.moneyOrder * 100) : parseInt(this.orderInfo.earnesMoney * 100)
                                    });

                                case 2:
                                    _code = _context2.sent;

                                    _WxUtils2.default.wxPay(_code.data).then(function (res) {
                                        _Tips2.default.toast("支付成功", function (res) {
                                            _this2.loadData(id);
                                        });
                                    });

                                case 4:
                                case "end":
                                    return _context2.stop();
                            }
                        }
                    }, _callee2, this);
                }));

                function pay(_x2) {
                    return _ref3.apply(this, arguments);
                }

                return pay;
            }()
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(Dialog, [{
        key: "loadData",
        value: function () {
            var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(id) {
                var res;
                return regeneratorRuntime.wrap(function _callee3$(_context3) {
                    while (1) {
                        switch (_context3.prev = _context3.next) {
                            case 0:
                                _context3.next = 2;
                                return _config2.default.orderdetail(id);

                            case 2:
                                res = _context3.sent;

                                this.orderInfo = res.data.detail;
                                this.$apply();

                            case 5:
                            case "end":
                                return _context3.stop();
                        }
                    }
                }, _callee3, this);
            }));

            function loadData(_x3) {
                return _ref4.apply(this, arguments);
            }

            return loadData;
        }()
    }, {
        key: "onLoad",
        value: function () {
            var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4(opt) {
                return regeneratorRuntime.wrap(function _callee4$(_context4) {
                    while (1) {
                        switch (_context4.prev = _context4.next) {
                            case 0:
                                this.opt = opt;
                                this.id = opt.id;
                                _context4.next = 4;
                                return this.loadData(opt.id);

                            case 4:
                            case "end":
                                return _context4.stop();
                        }
                    }
                }, _callee4, this);
            }));

            function onLoad(_x4) {
                return _ref5.apply(this, arguments);
            }

            return onLoad;
        }()
    }, {
        key: "onPullDownRefresh",
        value: function () {
            var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
                return regeneratorRuntime.wrap(function _callee5$(_context5) {
                    while (1) {
                        switch (_context5.prev = _context5.next) {
                            case 0:
                                _context5.next = 2;
                                return this.loadData(this.id);

                            case 2:
                                wx.stopPullDownRefresh();

                            case 3:
                            case "end":
                                return _context5.stop();
                        }
                    }
                }, _callee5, this);
            }));

            function onPullDownRefresh() {
                return _ref6.apply(this, arguments);
            }

            return onPullDownRefresh;
        }()
    }, {
        key: "onShareAppMessage",
        value: function onShareAppMessage(res) {
            var params = {
                title: '',
                imageUrl: '',
                path: ''
            };
            if (res.from === 'button') {
                // 来自页面内转发按钮
                console.log(res.target);
                var tar = res.target;
                if (tar.dataset.act == 'pt') {
                    params.title = tar.dataset.title;
                    params.imageUrl = tar.dataset.images;
                    params.path = '/pages/activity/pintuan?aid=' + tar.dataset.actid;
                }
            }
            return {
                title: params.title,
                imageUrl: params.imageUrl,
                path: params.path
            };
        }
    }]);

    return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/my/order'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm9yZGVyLmpzIl0sIm5hbWVzIjpbIkRpYWxvZyIsImNvbmZpZyIsIm5hdmlnYXRpb25CYXJUaXRsZVRleHQiLCJkYXRhIiwib3JkZXJJbmZvIiwic3RhdGVzIiwiaWQiLCJvcHQiLCJjb21wb25lbnRzIiwiY29udGFjdCIsIm1ldGhvZHMiLCJyZW1hcmsiLCJ3ZXB5IiwibmF2aWdhdGVUbyIsInVybCIsImNhbmNsZSIsInNlbGYiLCJ3eCIsInNob3dNb2RhbCIsImNvbnRlbnQiLCJzdWNjZXNzIiwicmVzIiwiY29uZmlybSIsImNhbmNhbG9yZGVyIiwiZXJyY29kZSIsInJlTGF1bmNoIiwiY2FuY2VsIiwicGF5Iiwid3hwYXl0b3BheSIsIm9yZGVyUGF5U24iLCJwYXlTbiIsImRlc2NyaWJlIiwibW9uZXkiLCJwYXltZW50VHlwZSIsInBhcnNlSW50IiwibW9uZXlPcmRlciIsImVhcm5lc01vbmV5IiwiX2NvZGUiLCJXeFV0aWxzIiwid3hQYXkiLCJ0aGVuIiwiVGlwcyIsInRvYXN0IiwibG9hZERhdGEiLCJvcmRlcmRldGFpbCIsImRldGFpbCIsIiRhcHBseSIsInN0b3BQdWxsRG93blJlZnJlc2giLCJwYXJhbXMiLCJ0aXRsZSIsImltYWdlVXJsIiwicGF0aCIsImZyb20iLCJjb25zb2xlIiwibG9nIiwidGFyZ2V0IiwidGFyIiwiZGF0YXNldCIsImFjdCIsImltYWdlcyIsImFjdGlkIiwicGFnZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQ0k7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7Ozs7Ozs7Ozs7Ozs7SUFDcUJBLE07Ozs7Ozs7Ozs7Ozs7OzBMQUNqQkMsTSxHQUFTO0FBQ0xDLG9DQUF3QjtBQURuQixTLFFBR1RDLEksR0FBTztBQUNIQyx1QkFBVyxFQURSO0FBRUhDLG9CQUFRO0FBQ0osbUJBQUcsS0FEQztBQUVKLG1CQUFHLEtBRkM7QUFHSixtQkFBRyxLQUhDO0FBSUosbUJBQUc7QUFKQyxhQUZMO0FBUUhDLGdCQUFJLEVBUkQ7QUFTSEMsaUJBQUs7QUFURixTLFFBV1BDLFUsR0FBYTtBQUNUQztBQURTLFMsUUF1Q2JDLE8sR0FBVTtBQUNOQyxrQkFETSxrQkFDQ0wsRUFERCxFQUNLO0FBQ1BNLCtCQUFLQyxVQUFMLENBQWdCO0FBQ1pDLHlCQUFLLGlDQUFpQ1I7QUFEMUIsaUJBQWhCO0FBR0gsYUFMSztBQU1OUyxrQkFOTSxrQkFNQ1QsRUFORCxFQU1LO0FBQ1Asb0JBQUlVLE9BQU8sSUFBWDtBQUNBQyxtQkFBR0MsU0FBSCxDQUFhO0FBQ1RDLDZCQUFTLGtCQURBO0FBRVRDO0FBQUEsNEZBQVMsaUJBQWVDLEdBQWY7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlEQUNEQSxJQUFJQyxPQURIO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUEsbURBRWVyQixpQkFBT3NCLFdBQVAsQ0FBbUJqQixFQUFuQixDQUZmOztBQUFBO0FBRUdlLGdEQUZIOztBQUdELGdEQUFJQSxLQUFJRyxPQUFKLElBQWUsR0FBbkIsRUFBd0I7QUFDcEJaLCtEQUFLYSxRQUFMLENBQWM7QUFDVlgseURBQUs7QUFESyxpREFBZDtBQUdIO0FBUEE7QUFBQTs7QUFBQTtBQVFFLGdEQUFJTyxJQUFJSyxNQUFSLEVBQWdCLENBQUU7O0FBUnBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFUOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBRlMsaUJBQWI7QUFhSCxhQXJCSztBQXNCQUMsZUF0QkE7QUFBQSxzR0FzQklyQixFQXRCSjtBQUFBOztBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQ0F1QmdCTCxpQkFBTzJCLFVBQVAsQ0FBa0I7QUFDaENDLG9EQUFZLEtBQUt6QixTQUFMLENBQWUwQixLQURLO0FBRWhDQyxrREFBVSxJQUZzQjtBQUdoQ0MsK0NBQU8sS0FBSzVCLFNBQUwsQ0FBZTZCLFdBQWYsSUFBOEIsQ0FBOUIsR0FBa0NDLFNBQVMsS0FBSzlCLFNBQUwsQ0FBZStCLFVBQWYsR0FBNEIsR0FBckMsQ0FBbEMsR0FBOEVELFNBQVMsS0FBSzlCLFNBQUwsQ0FBZWdDLFdBQWYsR0FBNkIsR0FBdEM7QUFIckQscUNBQWxCLENBdkJoQjs7QUFBQTtBQXVCRUMseUNBdkJGOztBQTRCRkMsc0RBQVFDLEtBQVIsQ0FBY0YsTUFBTWxDLElBQXBCLEVBQTBCcUMsSUFBMUIsQ0FBK0IsZUFBTztBQUNsQ0MsdURBQUtDLEtBQUwsQ0FBVyxNQUFYLEVBQW1CLGVBQU87QUFDdEIsbURBQUtDLFFBQUwsQ0FBY3JDLEVBQWQ7QUFDSCx5Q0FGRDtBQUdILHFDQUpEOztBQTVCRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBLFM7Ozs7OztrR0FwQ0tBLEU7Ozs7Ozs7dUNBQ0tMLGlCQUFPMkMsV0FBUCxDQUFtQnRDLEVBQW5CLEM7OztBQUFaZSxtQzs7QUFDSixxQ0FBS2pCLFNBQUwsR0FBaUJpQixJQUFJbEIsSUFBSixDQUFTMEMsTUFBMUI7QUFDQSxxQ0FBS0MsTUFBTDs7Ozs7Ozs7Ozs7Ozs7Ozs7OztrR0FFU3ZDLEc7Ozs7O0FBQ1QscUNBQUtBLEdBQUwsR0FBV0EsR0FBWDtBQUNBLHFDQUFLRCxFQUFMLEdBQVVDLElBQUlELEVBQWQ7O3VDQUNNLEtBQUtxQyxRQUFMLENBQWNwQyxJQUFJRCxFQUFsQixDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3VDQUdBLEtBQUtxQyxRQUFMLENBQWMsS0FBS3JDLEVBQW5CLEM7OztBQUNOVyxtQ0FBRzhCLG1CQUFIOzs7Ozs7Ozs7Ozs7Ozs7Ozs7MENBRWMxQixHLEVBQUs7QUFDbkIsZ0JBQUkyQixTQUFTO0FBQ1RDLHVCQUFPLEVBREU7QUFFVEMsMEJBQVUsRUFGRDtBQUdUQyxzQkFBTTtBQUhHLGFBQWI7QUFLQSxnQkFBSTlCLElBQUkrQixJQUFKLEtBQWEsUUFBakIsRUFBMkI7QUFDdkI7QUFDQUMsd0JBQVFDLEdBQVIsQ0FBWWpDLElBQUlrQyxNQUFoQjtBQUNBLG9CQUFJQyxNQUFNbkMsSUFBSWtDLE1BQWQ7QUFDQSxvQkFBSUMsSUFBSUMsT0FBSixDQUFZQyxHQUFaLElBQW1CLElBQXZCLEVBQTZCO0FBQ3pCViwyQkFBT0MsS0FBUCxHQUFlTyxJQUFJQyxPQUFKLENBQVlSLEtBQTNCO0FBQ0FELDJCQUFPRSxRQUFQLEdBQWtCTSxJQUFJQyxPQUFKLENBQVlFLE1BQTlCO0FBQ0FYLDJCQUFPRyxJQUFQLEdBQWMsaUNBQWlDSyxJQUFJQyxPQUFKLENBQVlHLEtBQTNEO0FBQ0g7QUFDSjtBQUNELG1CQUFPO0FBQ0hYLHVCQUFPRCxPQUFPQyxLQURYO0FBRUhDLDBCQUFVRixPQUFPRSxRQUZkO0FBR0hDLHNCQUFNSCxPQUFPRztBQUhWLGFBQVA7QUFLSDs7OztFQXJEK0J2QyxlQUFLaUQsSTs7a0JBQXBCN0QsTSIsImZpbGUiOiJvcmRlci5qcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4gICAgaW1wb3J0IHdlcHkgZnJvbSBcIndlcHlcIjtcclxuICAgIGltcG9ydCBjb25maWcgZnJvbSBcIkAvYXBpL2NvbmZpZ1wiXHJcbiAgICBpbXBvcnQgVGlwcyBmcm9tIFwiQC91dGlscy9UaXBzXCJcclxuICAgIGltcG9ydCBXeFV0aWxzIGZyb20gXCJAL3V0aWxzL1d4VXRpbHNcIlxyXG4gICAgaW1wb3J0IGNvbnRhY3QgZnJvbSBcIkAvY29tcG9uZW50cy9jb21tb24vY29udGFjdFwiXHJcbiAgICBleHBvcnQgZGVmYXVsdCBjbGFzcyBEaWFsb2cgZXh0ZW5kcyB3ZXB5LnBhZ2Uge1xyXG4gICAgICAgIGNvbmZpZyA9IHtcclxuICAgICAgICAgICAgbmF2aWdhdGlvbkJhclRpdGxlVGV4dDogXCLorqLljZXor6bmg4VcIlxyXG4gICAgICAgIH07XHJcbiAgICAgICAgZGF0YSA9IHtcclxuICAgICAgICAgICAgb3JkZXJJbmZvOiB7fSxcclxuICAgICAgICAgICAgc3RhdGVzOiB7XHJcbiAgICAgICAgICAgICAgICAxOiAn5b6F5LuY5qy+JyxcclxuICAgICAgICAgICAgICAgIDI6ICflvoXkvb/nlKgnLFxyXG4gICAgICAgICAgICAgICAgMzogJ+W3suS9v+eUqCcsXHJcbiAgICAgICAgICAgICAgICA0OiAn5bey5aSx5pWIJ1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBpZDogJycsXHJcbiAgICAgICAgICAgIG9wdDoge31cclxuICAgICAgICB9O1xyXG4gICAgICAgIGNvbXBvbmVudHMgPSB7XHJcbiAgICAgICAgICAgIGNvbnRhY3RcclxuICAgICAgICB9XHJcbiAgICAgICAgYXN5bmMgbG9hZERhdGEoaWQpIHtcclxuICAgICAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGNvbmZpZy5vcmRlcmRldGFpbChpZClcclxuICAgICAgICAgICAgdGhpcy5vcmRlckluZm8gPSByZXMuZGF0YS5kZXRhaWxcclxuICAgICAgICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgICAgIH1cclxuICAgICAgICBhc3luYyBvbkxvYWQob3B0KSB7XHJcbiAgICAgICAgICAgIHRoaXMub3B0ID0gb3B0XHJcbiAgICAgICAgICAgIHRoaXMuaWQgPSBvcHQuaWRcclxuICAgICAgICAgICAgYXdhaXQgdGhpcy5sb2FkRGF0YShvcHQuaWQpXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGFzeW5jIG9uUHVsbERvd25SZWZyZXNoKCkge1xyXG4gICAgICAgICAgICBhd2FpdCB0aGlzLmxvYWREYXRhKHRoaXMuaWQpXHJcbiAgICAgICAgICAgIHd4LnN0b3BQdWxsRG93blJlZnJlc2goKVxyXG4gICAgICAgIH1cclxuICAgICAgICBvblNoYXJlQXBwTWVzc2FnZShyZXMpIHtcclxuICAgICAgICAgICAgbGV0IHBhcmFtcyA9IHtcclxuICAgICAgICAgICAgICAgIHRpdGxlOiAnJyxcclxuICAgICAgICAgICAgICAgIGltYWdlVXJsOiAnJyxcclxuICAgICAgICAgICAgICAgIHBhdGg6ICcnXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKHJlcy5mcm9tID09PSAnYnV0dG9uJykge1xyXG4gICAgICAgICAgICAgICAgLy8g5p2l6Ieq6aG16Z2i5YaF6L2s5Y+R5oyJ6ZKuXHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhyZXMudGFyZ2V0KVxyXG4gICAgICAgICAgICAgICAgbGV0IHRhciA9IHJlcy50YXJnZXRcclxuICAgICAgICAgICAgICAgIGlmICh0YXIuZGF0YXNldC5hY3QgPT0gJ3B0Jykge1xyXG4gICAgICAgICAgICAgICAgICAgIHBhcmFtcy50aXRsZSA9IHRhci5kYXRhc2V0LnRpdGxlXHJcbiAgICAgICAgICAgICAgICAgICAgcGFyYW1zLmltYWdlVXJsID0gdGFyLmRhdGFzZXQuaW1hZ2VzXHJcbiAgICAgICAgICAgICAgICAgICAgcGFyYW1zLnBhdGggPSAnL3BhZ2VzL2FjdGl2aXR5L3BpbnR1YW4/YWlkPScgKyB0YXIuZGF0YXNldC5hY3RpZFxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICB0aXRsZTogcGFyYW1zLnRpdGxlLFxyXG4gICAgICAgICAgICAgICAgaW1hZ2VVcmw6IHBhcmFtcy5pbWFnZVVybCxcclxuICAgICAgICAgICAgICAgIHBhdGg6IHBhcmFtcy5wYXRoXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgbWV0aG9kcyA9IHtcclxuICAgICAgICAgICAgcmVtYXJrKGlkKSB7XHJcbiAgICAgICAgICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICAgICAgICAgIHVybDogJy9wYWdlcy9tZWV0L2NvbW1pUmVtYXJrZT9pZD0nICsgaWRcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBjYW5jbGUoaWQpIHtcclxuICAgICAgICAgICAgICAgIGxldCBzZWxmID0gdGhpc1xyXG4gICAgICAgICAgICAgICAgd3guc2hvd01vZGFsKHtcclxuICAgICAgICAgICAgICAgICAgICBjb250ZW50OiAn5Y+W5raI6K6i5Y2V5ZCO5bCG5peg5rOV5oGi5aSN77yB5piv5ZCm57un57ut77yfJyxcclxuICAgICAgICAgICAgICAgICAgICBzdWNjZXNzOiBhc3luYyBmdW5jdGlvbihyZXMpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlcy5jb25maXJtKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgcmVzID0gYXdhaXQgY29uZmlnLmNhbmNhbG9yZGVyKGlkKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlcy5lcnJjb2RlID09IDIwMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdlcHkucmVMYXVuY2goe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cmw6ICcvcGFnZXMvaG9tZS9pbmRleCdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChyZXMuY2FuY2VsKSB7fVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGFzeW5jIHBheShpZCkge1xyXG4gICAgICAgICAgICAgICAgbGV0IF9jb2RlID0gYXdhaXQgY29uZmlnLnd4cGF5dG9wYXkoe1xyXG4gICAgICAgICAgICAgICAgICAgIG9yZGVyUGF5U246IHRoaXMub3JkZXJJbmZvLnBheVNuLFxyXG4gICAgICAgICAgICAgICAgICAgIGRlc2NyaWJlOiAn5o+P6L+wJyxcclxuICAgICAgICAgICAgICAgICAgICBtb25leTogdGhpcy5vcmRlckluZm8ucGF5bWVudFR5cGUgPT0gMSA/IHBhcnNlSW50KHRoaXMub3JkZXJJbmZvLm1vbmV5T3JkZXIgKiAxMDApIDogcGFyc2VJbnQodGhpcy5vcmRlckluZm8uZWFybmVzTW9uZXkgKiAxMDApXHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgV3hVdGlscy53eFBheShfY29kZS5kYXRhKS50aGVuKHJlcyA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgVGlwcy50b2FzdChcIuaUr+S7mOaIkOWKn1wiLCByZXMgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmxvYWREYXRhKGlkKVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH07XHJcbiAgICB9XHJcbiJdfQ==