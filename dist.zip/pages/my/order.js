"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

var _WxUtils = require('./../../utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
    _inherits(Dialog, _wepy$page);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
            navigationBarTitleText: "订单详情"
        }, _this.data = {
            orderInfo: {},
            states: {
                1: '待付款',
                2: '待使用',
                3: '已使用',
                4: '已失效'
            },
            id: ''
        }, _this.methods = {
            remark: function remark(id) {
                _wepy2.default.navigateTo({
                    url: '/pages/meet/commiRemarke?id=' + id
                });
            },
            cancle: function cancle(id) {
                var self = this;
                wx.showModal({
                    content: '取消订单后将无法恢复！是否继续？',
                    // confirmText:,
                    success: function () {
                        var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(res) {
                            var _res;

                            return regeneratorRuntime.wrap(function _callee$(_context) {
                                while (1) {
                                    switch (_context.prev = _context.next) {
                                        case 0:
                                            if (!res.confirm) {
                                                _context.next = 8;
                                                break;
                                            }

                                            _context.next = 3;
                                            return _config2.default.cancalorder(id);

                                        case 3:
                                            _res = _context.sent;

                                            if (_res.errcode == 200) {
                                                _wepy2.default.navigateBack({
                                                    delta: 1 //返回的页面数，如果 delta 大于现有页面数，则返回到首页,
                                                });
                                            }
                                            console.log(_res);
                                            _context.next = 9;
                                            break;

                                        case 8:
                                            if (res.cancel) {
                                                console.log('用户点击取消');
                                            }

                                        case 9:
                                        case "end":
                                            return _context.stop();
                                    }
                                }
                            }, _callee, this);
                        }));

                        function success(_x) {
                            return _ref2.apply(this, arguments);
                        }

                        return success;
                    }()
                });
            },
            pay: function () {
                var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(id) {
                    var _this2 = this;

                    var _code;

                    return regeneratorRuntime.wrap(function _callee2$(_context2) {
                        while (1) {
                            switch (_context2.prev = _context2.next) {
                                case 0:
                                    _context2.next = 2;
                                    return _config2.default.wxpaytopay({
                                        orderPaySn: this.orderInfo.paySn,
                                        describe: '描述',
                                        money: this.orderInfo.moneyOrder * 100
                                    });

                                case 2:
                                    _code = _context2.sent;

                                    _WxUtils2.default.wxPay(_code.data).then(function (res) {
                                        _Tips2.default.toast("支付成功", function (res) {
                                            _this2.loadData(id);
                                        });
                                    });

                                case 4:
                                case "end":
                                    return _context2.stop();
                            }
                        }
                    }, _callee2, this);
                }));

                function pay(_x2) {
                    return _ref3.apply(this, arguments);
                }

                return pay;
            }()
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(Dialog, [{
        key: "loadData",
        value: function () {
            var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(id) {
                var res;
                return regeneratorRuntime.wrap(function _callee3$(_context3) {
                    while (1) {
                        switch (_context3.prev = _context3.next) {
                            case 0:
                                _context3.next = 2;
                                return _config2.default.orderdetail(id);

                            case 2:
                                res = _context3.sent;

                                this.orderInfo = res.data.detail;
                                this.$apply();

                            case 5:
                            case "end":
                                return _context3.stop();
                        }
                    }
                }, _callee3, this);
            }));

            function loadData(_x3) {
                return _ref4.apply(this, arguments);
            }

            return loadData;
        }()
    }, {
        key: "onLoad",
        value: function () {
            var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4(opt) {
                return regeneratorRuntime.wrap(function _callee4$(_context4) {
                    while (1) {
                        switch (_context4.prev = _context4.next) {
                            case 0:
                                this.id = opt.id;
                                _context4.next = 3;
                                return this.loadData(opt.id);

                            case 3:
                            case "end":
                                return _context4.stop();
                        }
                    }
                }, _callee4, this);
            }));

            function onLoad(_x4) {
                return _ref5.apply(this, arguments);
            }

            return onLoad;
        }()
    }, {
        key: "onPullDownRefresh",
        value: function () {
            var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
                return regeneratorRuntime.wrap(function _callee5$(_context5) {
                    while (1) {
                        switch (_context5.prev = _context5.next) {
                            case 0:
                                _context5.next = 2;
                                return this.loadData(this.id);

                            case 2:
                                wx.stopPullDownRefresh();

                            case 3:
                            case "end":
                                return _context5.stop();
                        }
                    }
                }, _callee5, this);
            }));

            function onPullDownRefresh() {
                return _ref6.apply(this, arguments);
            }

            return onPullDownRefresh;
        }()
    }, {
        key: "onShareAppMessage",
        value: function onShareAppMessage(res) {
            var params = {
                title: '',
                imageUrl: '',
                path: ''
            };
            if (res.from === 'button') {
                // 来自页面内转发按钮
                console.log(res.target);
                var tar = res.target;
                if (tar.dataset.act == 'pt') {
                    params.title = tar.dataset.title;
                    params.imageUrl = tar.dataset.images;
                    params.path = '/pages/activity/pintuan?aid=' + tar.dataset.actid;
                }
            }
            return {
                title: params.title,
                imageUrl: params.imageUrl,
                path: params.path
            };
        }
    }]);

    return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/my/order'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm9yZGVyLmpzIl0sIm5hbWVzIjpbIkRpYWxvZyIsImNvbmZpZyIsIm5hdmlnYXRpb25CYXJUaXRsZVRleHQiLCJkYXRhIiwib3JkZXJJbmZvIiwic3RhdGVzIiwiaWQiLCJtZXRob2RzIiwicmVtYXJrIiwid2VweSIsIm5hdmlnYXRlVG8iLCJ1cmwiLCJjYW5jbGUiLCJzZWxmIiwid3giLCJzaG93TW9kYWwiLCJjb250ZW50Iiwic3VjY2VzcyIsInJlcyIsImNvbmZpcm0iLCJjYW5jYWxvcmRlciIsImVycmNvZGUiLCJuYXZpZ2F0ZUJhY2siLCJkZWx0YSIsImNvbnNvbGUiLCJsb2ciLCJjYW5jZWwiLCJwYXkiLCJ3eHBheXRvcGF5Iiwib3JkZXJQYXlTbiIsInBheVNuIiwiZGVzY3JpYmUiLCJtb25leSIsIm1vbmV5T3JkZXIiLCJfY29kZSIsIld4VXRpbHMiLCJ3eFBheSIsInRoZW4iLCJUaXBzIiwidG9hc3QiLCJsb2FkRGF0YSIsIm9yZGVyZGV0YWlsIiwiZGV0YWlsIiwiJGFwcGx5Iiwib3B0Iiwic3RvcFB1bGxEb3duUmVmcmVzaCIsInBhcmFtcyIsInRpdGxlIiwiaW1hZ2VVcmwiLCJwYXRoIiwiZnJvbSIsInRhcmdldCIsInRhciIsImRhdGFzZXQiLCJhY3QiLCJpbWFnZXMiLCJhY3RpZCIsInBhZ2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUNJOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7Ozs7Ozs7Ozs7OztJQUNxQkEsTTs7Ozs7Ozs7Ozs7Ozs7MExBQ2pCQyxNLEdBQVM7QUFDTEMsb0NBQXdCO0FBRG5CLFMsUUFHVEMsSSxHQUFPO0FBQ0hDLHVCQUFXLEVBRFI7QUFFSEMsb0JBQVE7QUFDSixtQkFBRyxLQURDO0FBRUosbUJBQUcsS0FGQztBQUdKLG1CQUFHLEtBSEM7QUFJSixtQkFBRztBQUpDLGFBRkw7QUFRSEMsZ0JBQUc7QUFSQSxTLFFBOENQQyxPLEdBQVU7QUFDTEMsa0JBREssa0JBQ0VGLEVBREYsRUFDTTtBQUNSRywrQkFBS0MsVUFBTCxDQUFnQjtBQUNaQyx5QkFBSyxpQ0FBaUNMO0FBRDFCLGlCQUFoQjtBQUdILGFBTEs7QUFNTk0sa0JBTk0sa0JBTUNOLEVBTkQsRUFNSztBQUNQLG9CQUFJTyxPQUFPLElBQVg7QUFDQUMsbUJBQUdDLFNBQUgsQ0FBYTtBQUNUQyw2QkFBUyxrQkFEQTtBQUVUO0FBQ0FDO0FBQUEsNEZBQVMsaUJBQWVDLEdBQWY7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlEQUNEQSxJQUFJQyxPQURIO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUEsbURBRWVsQixpQkFBT21CLFdBQVAsQ0FBbUJkLEVBQW5CLENBRmY7O0FBQUE7QUFFR1ksZ0RBRkg7O0FBR0QsZ0RBQUlBLEtBQUlHLE9BQUosSUFBZSxHQUFuQixFQUF3QjtBQUNwQlosK0RBQUthLFlBQUwsQ0FBa0I7QUFDZEMsMkRBQU8sQ0FETyxDQUNMO0FBREssaURBQWxCO0FBR0g7QUFDREMsb0RBQVFDLEdBQVIsQ0FBWVAsSUFBWjtBQVJDO0FBQUE7O0FBQUE7QUFTRSxnREFBSUEsSUFBSVEsTUFBUixFQUFnQjtBQUNuQkYsd0RBQVFDLEdBQVIsQ0FBWSxRQUFaO0FBQ0g7O0FBWEk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQVQ7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFIUyxpQkFBYjtBQWlCSCxhQXpCSztBQTBCQUUsZUExQkE7QUFBQSxzR0EwQklyQixFQTFCSjtBQUFBOztBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQ0EyQmdCTCxpQkFBTzJCLFVBQVAsQ0FBa0I7QUFDaENDLG9EQUFZLEtBQUt6QixTQUFMLENBQWUwQixLQURLO0FBRWhDQyxrREFBVSxJQUZzQjtBQUdoQ0MsK0NBQU8sS0FBSzVCLFNBQUwsQ0FBZTZCLFVBQWYsR0FBNEI7QUFISCxxQ0FBbEIsQ0EzQmhCOztBQUFBO0FBMkJFQyx5Q0EzQkY7O0FBZ0NGQyxzREFBUUMsS0FBUixDQUFjRixNQUFNL0IsSUFBcEIsRUFBMEJrQyxJQUExQixDQUErQixlQUFPO0FBQ2xDQyx1REFBS0MsS0FBTCxDQUFXLE1BQVgsRUFBbUIsZUFBTztBQUN0QixtREFBS0MsUUFBTCxDQUFjbEMsRUFBZDtBQUNILHlDQUZEO0FBR0gscUNBSkQ7O0FBaENFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUEsUzs7Ozs7O2tHQXBDS0EsRTs7Ozs7Ozt1Q0FDS0wsaUJBQU93QyxXQUFQLENBQW1CbkMsRUFBbkIsQzs7O0FBQVpZLG1DOztBQUNKLHFDQUFLZCxTQUFMLEdBQWlCYyxJQUFJZixJQUFKLENBQVN1QyxNQUExQjtBQUNBLHFDQUFLQyxNQUFMOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O2tHQUVTQyxHOzs7OztBQUNULHFDQUFLdEMsRUFBTCxHQUFVc0MsSUFBSXRDLEVBQWQ7O3VDQUNNLEtBQUtrQyxRQUFMLENBQWNJLElBQUl0QyxFQUFsQixDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3VDQUdBLEtBQUtrQyxRQUFMLENBQWMsS0FBS2xDLEVBQW5CLEM7OztBQUNOUSxtQ0FBRytCLG1CQUFIOzs7Ozs7Ozs7Ozs7Ozs7Ozs7MENBRWMzQixHLEVBQUs7QUFDbkIsZ0JBQUk0QixTQUFTO0FBQ1RDLHVCQUFPLEVBREU7QUFFVEMsMEJBQVMsRUFGQTtBQUdUQyxzQkFBTTtBQUhHLGFBQWI7QUFLQSxnQkFBSS9CLElBQUlnQyxJQUFKLEtBQWEsUUFBakIsRUFBMkI7QUFDdkI7QUFDQTFCLHdCQUFRQyxHQUFSLENBQVlQLElBQUlpQyxNQUFoQjtBQUNBLG9CQUFJQyxNQUFNbEMsSUFBSWlDLE1BQWQ7QUFDQSxvQkFBR0MsSUFBSUMsT0FBSixDQUFZQyxHQUFaLElBQW1CLElBQXRCLEVBQTJCO0FBQ3ZCUiwyQkFBT0MsS0FBUCxHQUFlSyxJQUFJQyxPQUFKLENBQVlOLEtBQTNCO0FBQ0FELDJCQUFPRSxRQUFQLEdBQWtCSSxJQUFJQyxPQUFKLENBQVlFLE1BQTlCO0FBQ0FULDJCQUFPRyxJQUFQLEdBQWEsaUNBQWtDRyxJQUFJQyxPQUFKLENBQVlHLEtBQTNEO0FBQ0g7QUFFSjtBQUNELG1CQUFPO0FBQ0hULHVCQUFPRCxPQUFPQyxLQURYO0FBRUhDLDBCQUFTRixPQUFPRSxRQUZiO0FBR0hDLHNCQUFLSCxPQUFPRztBQUhULGFBQVA7QUFLSDs7OztFQWpEK0J4QyxlQUFLZ0QsSTs7a0JBQXBCekQsTSIsImZpbGUiOiJvcmRlci5qcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4gICAgaW1wb3J0IHdlcHkgZnJvbSBcIndlcHlcIjtcclxuICAgIGltcG9ydCBjb25maWcgZnJvbSBcIkAvYXBpL2NvbmZpZ1wiXHJcbiAgICBpbXBvcnQgVGlwcyBmcm9tIFwiQC91dGlscy9UaXBzXCJcclxuICAgIGltcG9ydCBXeFV0aWxzIGZyb20gXCJAL3V0aWxzL1d4VXRpbHNcIlxyXG4gICAgZXhwb3J0IGRlZmF1bHQgY2xhc3MgRGlhbG9nIGV4dGVuZHMgd2VweS5wYWdlIHtcclxuICAgICAgICBjb25maWcgPSB7XHJcbiAgICAgICAgICAgIG5hdmlnYXRpb25CYXJUaXRsZVRleHQ6IFwi6K6i5Y2V6K+m5oOFXCJcclxuICAgICAgICB9O1xyXG4gICAgICAgIGRhdGEgPSB7XHJcbiAgICAgICAgICAgIG9yZGVySW5mbzoge30sXHJcbiAgICAgICAgICAgIHN0YXRlczoge1xyXG4gICAgICAgICAgICAgICAgMTogJ+W+heS7mOasvicsXHJcbiAgICAgICAgICAgICAgICAyOiAn5b6F5L2/55SoJyxcclxuICAgICAgICAgICAgICAgIDM6ICflt7Lkvb/nlKgnLFxyXG4gICAgICAgICAgICAgICAgNDogJ+W3suWkseaViCdcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgaWQ6JydcclxuICAgICAgICB9O1xyXG4gICAgICAgIGFzeW5jIGxvYWREYXRhKGlkKSB7XHJcbiAgICAgICAgICAgIGxldCByZXMgPSBhd2FpdCBjb25maWcub3JkZXJkZXRhaWwoaWQpXHJcbiAgICAgICAgICAgIHRoaXMub3JkZXJJbmZvID0gcmVzLmRhdGEuZGV0YWlsXHJcbiAgICAgICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgICB9XHJcbiAgICAgICAgYXN5bmMgb25Mb2FkKG9wdCkge1xyXG4gICAgICAgICAgICB0aGlzLmlkID0gb3B0LmlkXHJcbiAgICAgICAgICAgIGF3YWl0IHRoaXMubG9hZERhdGEob3B0LmlkKVxyXG4gICAgICAgIH1cclxuICAgICAgICBhc3luYyBvblB1bGxEb3duUmVmcmVzaCgpIHtcclxuICAgICAgICAgICAgYXdhaXQgdGhpcy5sb2FkRGF0YSh0aGlzLmlkKVxyXG4gICAgICAgICAgICB3eC5zdG9wUHVsbERvd25SZWZyZXNoKClcclxuICAgICAgICB9XHJcbiAgICAgICAgb25TaGFyZUFwcE1lc3NhZ2UocmVzKSB7XHJcbiAgICAgICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgICAgICB0aXRsZTogJycsXHJcbiAgICAgICAgICAgICAgICBpbWFnZVVybDonJyxcclxuICAgICAgICAgICAgICAgIHBhdGg6ICcnXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKHJlcy5mcm9tID09PSAnYnV0dG9uJykge1xyXG4gICAgICAgICAgICAgICAgLy8g5p2l6Ieq6aG16Z2i5YaF6L2s5Y+R5oyJ6ZKuXHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhyZXMudGFyZ2V0KVxyXG4gICAgICAgICAgICAgICAgbGV0IHRhciA9IHJlcy50YXJnZXRcclxuICAgICAgICAgICAgICAgIGlmKHRhci5kYXRhc2V0LmFjdCA9PSAncHQnKXtcclxuICAgICAgICAgICAgICAgICAgICBwYXJhbXMudGl0bGUgPSB0YXIuZGF0YXNldC50aXRsZVxyXG4gICAgICAgICAgICAgICAgICAgIHBhcmFtcy5pbWFnZVVybCA9IHRhci5kYXRhc2V0LmltYWdlc1xyXG4gICAgICAgICAgICAgICAgICAgIHBhcmFtcy5wYXRoID0nL3BhZ2VzL2FjdGl2aXR5L3BpbnR1YW4/YWlkPScgKyAgdGFyLmRhdGFzZXQuYWN0aWRcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgIHRpdGxlOiBwYXJhbXMudGl0bGUsXHJcbiAgICAgICAgICAgICAgICBpbWFnZVVybDpwYXJhbXMuaW1hZ2VVcmwsXHJcbiAgICAgICAgICAgICAgICBwYXRoOnBhcmFtcy5wYXRoXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgbWV0aG9kcyA9IHtcclxuICAgICAgICAgICAgIHJlbWFyayhpZCkge1xyXG4gICAgICAgICAgICAgICAgd2VweS5uYXZpZ2F0ZVRvKHtcclxuICAgICAgICAgICAgICAgICAgICB1cmw6ICcvcGFnZXMvbWVldC9jb21taVJlbWFya2U/aWQ9JyArIGlkXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgY2FuY2xlKGlkKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgc2VsZiA9IHRoaXNcclxuICAgICAgICAgICAgICAgIHd4LnNob3dNb2RhbCh7XHJcbiAgICAgICAgICAgICAgICAgICAgY29udGVudDogJ+WPlua2iOiuouWNleWQjuWwhuaXoOazleaBouWkje+8geaYr+WQpue7p+e7re+8nycsXHJcbiAgICAgICAgICAgICAgICAgICAgLy8gY29uZmlybVRleHQ6LFxyXG4gICAgICAgICAgICAgICAgICAgIHN1Y2Nlc3M6IGFzeW5jIGZ1bmN0aW9uKHJlcykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzLmNvbmZpcm0pIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCByZXMgPSBhd2FpdCBjb25maWcuY2FuY2Fsb3JkZXIoaWQpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzLmVycmNvZGUgPT0gMjAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgd2VweS5uYXZpZ2F0ZUJhY2soe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZWx0YTogMSAvL+i/lOWbnueahOmhtemdouaVsO+8jOWmguaenCBkZWx0YSDlpKfkuo7njrDmnInpobXpnaLmlbDvvIzliJnov5Tlm57liLDpppbpobUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhyZXMpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAocmVzLmNhbmNlbCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ+eUqOaIt+eCueWHu+WPlua2iCcpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBhc3luYyBwYXkoaWQpIHtcclxuICAgICAgICAgICAgICAgIGxldCBfY29kZSA9IGF3YWl0IGNvbmZpZy53eHBheXRvcGF5KHtcclxuICAgICAgICAgICAgICAgICAgICBvcmRlclBheVNuOiB0aGlzLm9yZGVySW5mby5wYXlTbixcclxuICAgICAgICAgICAgICAgICAgICBkZXNjcmliZTogJ+aPj+i/sCcsXHJcbiAgICAgICAgICAgICAgICAgICAgbW9uZXk6IHRoaXMub3JkZXJJbmZvLm1vbmV5T3JkZXIgKiAxMDBcclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICBXeFV0aWxzLnd4UGF5KF9jb2RlLmRhdGEpLnRoZW4ocmVzID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBUaXBzLnRvYXN0KFwi5pSv5LuY5oiQ5YqfXCIsIHJlcyA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubG9hZERhdGEoaWQpXHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuIl19