"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

var _WxUtils = require('./../../utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

var _contact = require('./../../components/common/contact.js');

var _contact2 = _interopRequireDefault(_contact);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
    _inherits(Dialog, _wepy$page);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
            navigationBarTitleText: "订单详情"
        }, _this.data = {
            orderInfo: {},
            states: {
                1: '待付款',
                2: '待使用',
                3: '已使用',
                4: '已失效'
            },
            id: '',
            opt: {}
        }, _this.components = { contact: _contact2.default }, _this.methods = {
            remark: function remark(id) {
                _wepy2.default.navigateTo({
                    url: '/pages/meet/commiRemarke?id=' + id
                });
            },
            cancle: function cancle(id) {
                var self = this;
                wx.showModal({
                    content: '取消订单后将无法恢复！是否继续？',
                    // confirmText:,
                    success: function () {
                        var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(res) {
                            var _res;

                            return regeneratorRuntime.wrap(function _callee$(_context) {
                                while (1) {
                                    switch (_context.prev = _context.next) {
                                        case 0:
                                            if (!res.confirm) {
                                                _context.next = 8;
                                                break;
                                            }

                                            _context.next = 3;
                                            return _config2.default.cancalorder(id);

                                        case 3:
                                            _res = _context.sent;

                                            if (_res.errcode == 200) {
                                                _wepy2.default.navigateBack({
                                                    delta: 1 //返回的页面数，如果 delta 大于现有页面数，则返回到首页,
                                                });
                                            }
                                            console.log(_res);
                                            _context.next = 9;
                                            break;

                                        case 8:
                                            if (res.cancel) {
                                                console.log('用户点击取消');
                                            }

                                        case 9:
                                        case "end":
                                            return _context.stop();
                                    }
                                }
                            }, _callee, this);
                        }));

                        function success(_x) {
                            return _ref2.apply(this, arguments);
                        }

                        return success;
                    }()
                });
            },
            pay: function () {
                var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(id) {
                    var _this2 = this;

                    var _code;

                    return regeneratorRuntime.wrap(function _callee2$(_context2) {
                        while (1) {
                            switch (_context2.prev = _context2.next) {
                                case 0:
                                    _context2.next = 2;
                                    return _config2.default.wxpaytopay({
                                        orderPaySn: this.orderInfo.paySn,
                                        describe: '描述',
                                        money: this.orderInfo.paymentType == 1 ? parseInt(this.orderInfo.moneyOrder * 100) : parseInt(this.orderInfo.earnesMoney * 100)
                                    });

                                case 2:
                                    _code = _context2.sent;

                                    _WxUtils2.default.wxPay(_code.data).then(function (res) {
                                        _Tips2.default.toast("支付成功", function (res) {
                                            _this2.loadData(id);
                                        });
                                    });

                                case 4:
                                case "end":
                                    return _context2.stop();
                            }
                        }
                    }, _callee2, this);
                }));

                function pay(_x2) {
                    return _ref3.apply(this, arguments);
                }

                return pay;
            }()
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(Dialog, [{
        key: "loadData",
        value: function () {
            var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(id) {
                var res;
                return regeneratorRuntime.wrap(function _callee3$(_context3) {
                    while (1) {
                        switch (_context3.prev = _context3.next) {
                            case 0:
                                _context3.next = 2;
                                return _config2.default.orderdetail(id);

                            case 2:
                                res = _context3.sent;

                                this.orderInfo = res.data.detail;
                                this.$apply();

                            case 5:
                            case "end":
                                return _context3.stop();
                        }
                    }
                }, _callee3, this);
            }));

            function loadData(_x3) {
                return _ref4.apply(this, arguments);
            }

            return loadData;
        }()
    }, {
        key: "onLoad",
        value: function () {
            var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4(opt) {
                return regeneratorRuntime.wrap(function _callee4$(_context4) {
                    while (1) {
                        switch (_context4.prev = _context4.next) {
                            case 0:
                                this.opt = opt;
                                this.id = opt.id;
                                _context4.next = 4;
                                return this.loadData(opt.id);

                            case 4:
                            case "end":
                                return _context4.stop();
                        }
                    }
                }, _callee4, this);
            }));

            function onLoad(_x4) {
                return _ref5.apply(this, arguments);
            }

            return onLoad;
        }()
    }, {
        key: "onPullDownRefresh",
        value: function () {
            var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
                return regeneratorRuntime.wrap(function _callee5$(_context5) {
                    while (1) {
                        switch (_context5.prev = _context5.next) {
                            case 0:
                                _context5.next = 2;
                                return this.loadData(this.id);

                            case 2:
                                wx.stopPullDownRefresh();

                            case 3:
                            case "end":
                                return _context5.stop();
                        }
                    }
                }, _callee5, this);
            }));

            function onPullDownRefresh() {
                return _ref6.apply(this, arguments);
            }

            return onPullDownRefresh;
        }()
    }, {
        key: "onShareAppMessage",
        value: function onShareAppMessage(res) {
            var params = {
                title: '',
                imageUrl: '',
                path: ''
            };
            if (res.from === 'button') {
                // 来自页面内转发按钮
                console.log(res.target);
                var tar = res.target;
                if (tar.dataset.act == 'pt') {
                    params.title = tar.dataset.title;
                    params.imageUrl = tar.dataset.images;
                    params.path = '/pages/activity/pintuan?aid=' + tar.dataset.actid;
                }
            }
            return {
                title: params.title,
                imageUrl: params.imageUrl,
                path: params.path
            };
        }
    }]);

    return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/my/order'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm9yZGVyLmpzIl0sIm5hbWVzIjpbIkRpYWxvZyIsImNvbmZpZyIsIm5hdmlnYXRpb25CYXJUaXRsZVRleHQiLCJkYXRhIiwib3JkZXJJbmZvIiwic3RhdGVzIiwiaWQiLCJvcHQiLCJjb21wb25lbnRzIiwiY29udGFjdCIsIm1ldGhvZHMiLCJyZW1hcmsiLCJ3ZXB5IiwibmF2aWdhdGVUbyIsInVybCIsImNhbmNsZSIsInNlbGYiLCJ3eCIsInNob3dNb2RhbCIsImNvbnRlbnQiLCJzdWNjZXNzIiwicmVzIiwiY29uZmlybSIsImNhbmNhbG9yZGVyIiwiZXJyY29kZSIsIm5hdmlnYXRlQmFjayIsImRlbHRhIiwiY29uc29sZSIsImxvZyIsImNhbmNlbCIsInBheSIsInd4cGF5dG9wYXkiLCJvcmRlclBheVNuIiwicGF5U24iLCJkZXNjcmliZSIsIm1vbmV5IiwicGF5bWVudFR5cGUiLCJwYXJzZUludCIsIm1vbmV5T3JkZXIiLCJlYXJuZXNNb25leSIsIl9jb2RlIiwiV3hVdGlscyIsInd4UGF5IiwidGhlbiIsIlRpcHMiLCJ0b2FzdCIsImxvYWREYXRhIiwib3JkZXJkZXRhaWwiLCJkZXRhaWwiLCIkYXBwbHkiLCJzdG9wUHVsbERvd25SZWZyZXNoIiwicGFyYW1zIiwidGl0bGUiLCJpbWFnZVVybCIsInBhdGgiLCJmcm9tIiwidGFyZ2V0IiwidGFyIiwiZGF0YXNldCIsImFjdCIsImltYWdlcyIsImFjdGlkIiwicGFnZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQ0k7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7Ozs7Ozs7Ozs7Ozs7SUFDcUJBLE07Ozs7Ozs7Ozs7Ozs7OzBMQUNqQkMsTSxHQUFTO0FBQ0xDLG9DQUF3QjtBQURuQixTLFFBR1RDLEksR0FBTztBQUNIQyx1QkFBVyxFQURSO0FBRUhDLG9CQUFRO0FBQ0osbUJBQUcsS0FEQztBQUVKLG1CQUFHLEtBRkM7QUFHSixtQkFBRyxLQUhDO0FBSUosbUJBQUc7QUFKQyxhQUZMO0FBUUhDLGdCQUFHLEVBUkE7QUFTSEMsaUJBQUk7QUFURCxTLFFBV1BDLFUsR0FBVyxFQUFDQywwQkFBRCxFLFFBc0NYQyxPLEdBQVU7QUFDTEMsa0JBREssa0JBQ0VMLEVBREYsRUFDTTtBQUNSTSwrQkFBS0MsVUFBTCxDQUFnQjtBQUNaQyx5QkFBSyxpQ0FBaUNSO0FBRDFCLGlCQUFoQjtBQUdILGFBTEs7QUFNTlMsa0JBTk0sa0JBTUNULEVBTkQsRUFNSztBQUNQLG9CQUFJVSxPQUFPLElBQVg7QUFDQUMsbUJBQUdDLFNBQUgsQ0FBYTtBQUNUQyw2QkFBUyxrQkFEQTtBQUVUO0FBQ0FDO0FBQUEsNEZBQVMsaUJBQWVDLEdBQWY7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlEQUNEQSxJQUFJQyxPQURIO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUEsbURBRWVyQixpQkFBT3NCLFdBQVAsQ0FBbUJqQixFQUFuQixDQUZmOztBQUFBO0FBRUdlLGdEQUZIOztBQUdELGdEQUFJQSxLQUFJRyxPQUFKLElBQWUsR0FBbkIsRUFBd0I7QUFDcEJaLCtEQUFLYSxZQUFMLENBQWtCO0FBQ2RDLDJEQUFPLENBRE8sQ0FDTDtBQURLLGlEQUFsQjtBQUdIO0FBQ0RDLG9EQUFRQyxHQUFSLENBQVlQLElBQVo7QUFSQztBQUFBOztBQUFBO0FBU0UsZ0RBQUlBLElBQUlRLE1BQVIsRUFBZ0I7QUFDbkJGLHdEQUFRQyxHQUFSLENBQVksUUFBWjtBQUNIOztBQVhJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFUOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBSFMsaUJBQWI7QUFpQkgsYUF6Qks7QUEwQkFFLGVBMUJBO0FBQUEsc0dBMEJJeEIsRUExQko7QUFBQTs7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkNBMkJnQkwsaUJBQU84QixVQUFQLENBQWtCO0FBQ2hDQyxvREFBWSxLQUFLNUIsU0FBTCxDQUFlNkIsS0FESztBQUVoQ0Msa0RBQVUsSUFGc0I7QUFHaENDLCtDQUFPLEtBQUsvQixTQUFMLENBQWVnQyxXQUFmLElBQThCLENBQTlCLEdBQWtDQyxTQUFTLEtBQUtqQyxTQUFMLENBQWVrQyxVQUFmLEdBQTRCLEdBQXJDLENBQWxDLEdBQThFRCxTQUFTLEtBQUtqQyxTQUFMLENBQWVtQyxXQUFmLEdBQTZCLEdBQXRDO0FBSHJELHFDQUFsQixDQTNCaEI7O0FBQUE7QUEyQkVDLHlDQTNCRjs7QUFnQ0ZDLHNEQUFRQyxLQUFSLENBQWNGLE1BQU1yQyxJQUFwQixFQUEwQndDLElBQTFCLENBQStCLGVBQU87QUFDbENDLHVEQUFLQyxLQUFMLENBQVcsTUFBWCxFQUFtQixlQUFPO0FBQ3RCLG1EQUFLQyxRQUFMLENBQWN4QyxFQUFkO0FBQ0gseUNBRkQ7QUFHSCxxQ0FKRDs7QUFoQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQSxTOzs7Ozs7a0dBckNLQSxFOzs7Ozs7O3VDQUNLTCxpQkFBTzhDLFdBQVAsQ0FBbUJ6QyxFQUFuQixDOzs7QUFBWmUsbUM7O0FBQ0oscUNBQUtqQixTQUFMLEdBQWlCaUIsSUFBSWxCLElBQUosQ0FBUzZDLE1BQTFCO0FBQ0EscUNBQUtDLE1BQUw7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7a0dBRVMxQyxHOzs7OztBQUNULHFDQUFLQSxHQUFMLEdBQVdBLEdBQVg7QUFDQSxxQ0FBS0QsRUFBTCxHQUFVQyxJQUFJRCxFQUFkOzt1Q0FDTSxLQUFLd0MsUUFBTCxDQUFjdkMsSUFBSUQsRUFBbEIsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozt1Q0FHQSxLQUFLd0MsUUFBTCxDQUFjLEtBQUt4QyxFQUFuQixDOzs7QUFDTlcsbUNBQUdpQyxtQkFBSDs7Ozs7Ozs7Ozs7Ozs7Ozs7OzBDQUVjN0IsRyxFQUFLO0FBQ25CLGdCQUFJOEIsU0FBUztBQUNUQyx1QkFBTyxFQURFO0FBRVRDLDBCQUFTLEVBRkE7QUFHVEMsc0JBQU07QUFIRyxhQUFiO0FBS0EsZ0JBQUlqQyxJQUFJa0MsSUFBSixLQUFhLFFBQWpCLEVBQTJCO0FBQ3ZCO0FBQ0E1Qix3QkFBUUMsR0FBUixDQUFZUCxJQUFJbUMsTUFBaEI7QUFDQSxvQkFBSUMsTUFBTXBDLElBQUltQyxNQUFkO0FBQ0Esb0JBQUdDLElBQUlDLE9BQUosQ0FBWUMsR0FBWixJQUFtQixJQUF0QixFQUEyQjtBQUN2QlIsMkJBQU9DLEtBQVAsR0FBZUssSUFBSUMsT0FBSixDQUFZTixLQUEzQjtBQUNBRCwyQkFBT0UsUUFBUCxHQUFrQkksSUFBSUMsT0FBSixDQUFZRSxNQUE5QjtBQUNBVCwyQkFBT0csSUFBUCxHQUFhLGlDQUFrQ0csSUFBSUMsT0FBSixDQUFZRyxLQUEzRDtBQUNIO0FBRUo7QUFDRCxtQkFBTztBQUNIVCx1QkFBT0QsT0FBT0MsS0FEWDtBQUVIQywwQkFBU0YsT0FBT0UsUUFGYjtBQUdIQyxzQkFBS0gsT0FBT0c7QUFIVCxhQUFQO0FBS0g7Ozs7RUFwRCtCMUMsZUFBS2tELEk7O2tCQUFwQjlELE0iLCJmaWxlIjoib3JkZXIuanMiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuICAgIGltcG9ydCB3ZXB5IGZyb20gXCJ3ZXB5XCI7XHJcbiAgICBpbXBvcnQgY29uZmlnIGZyb20gXCJAL2FwaS9jb25maWdcIlxyXG4gICAgaW1wb3J0IFRpcHMgZnJvbSBcIkAvdXRpbHMvVGlwc1wiXHJcbiAgICBpbXBvcnQgV3hVdGlscyBmcm9tIFwiQC91dGlscy9XeFV0aWxzXCJcclxuICAgIGltcG9ydCBjb250YWN0IGZyb20gXCJAL2NvbXBvbmVudHMvY29tbW9uL2NvbnRhY3RcIlxyXG4gICAgZXhwb3J0IGRlZmF1bHQgY2xhc3MgRGlhbG9nIGV4dGVuZHMgd2VweS5wYWdlIHtcclxuICAgICAgICBjb25maWcgPSB7XHJcbiAgICAgICAgICAgIG5hdmlnYXRpb25CYXJUaXRsZVRleHQ6IFwi6K6i5Y2V6K+m5oOFXCJcclxuICAgICAgICB9O1xyXG4gICAgICAgIGRhdGEgPSB7XHJcbiAgICAgICAgICAgIG9yZGVySW5mbzoge30sXHJcbiAgICAgICAgICAgIHN0YXRlczoge1xyXG4gICAgICAgICAgICAgICAgMTogJ+W+heS7mOasvicsXHJcbiAgICAgICAgICAgICAgICAyOiAn5b6F5L2/55SoJyxcclxuICAgICAgICAgICAgICAgIDM6ICflt7Lkvb/nlKgnLFxyXG4gICAgICAgICAgICAgICAgNDogJ+W3suWkseaViCdcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgaWQ6JycsXHJcbiAgICAgICAgICAgIG9wdDp7fVxyXG4gICAgICAgIH07XHJcbiAgICAgICAgY29tcG9uZW50cz17Y29udGFjdH1cclxuICAgICAgICBhc3luYyBsb2FkRGF0YShpZCkge1xyXG4gICAgICAgICAgICBsZXQgcmVzID0gYXdhaXQgY29uZmlnLm9yZGVyZGV0YWlsKGlkKVxyXG4gICAgICAgICAgICB0aGlzLm9yZGVySW5mbyA9IHJlcy5kYXRhLmRldGFpbFxyXG4gICAgICAgICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGFzeW5jIG9uTG9hZChvcHQpIHtcclxuICAgICAgICAgICAgdGhpcy5vcHQgPSBvcHRcclxuICAgICAgICAgICAgdGhpcy5pZCA9IG9wdC5pZFxyXG4gICAgICAgICAgICBhd2FpdCB0aGlzLmxvYWREYXRhKG9wdC5pZClcclxuICAgICAgICB9XHJcbiAgICAgICAgYXN5bmMgb25QdWxsRG93blJlZnJlc2goKSB7XHJcbiAgICAgICAgICAgIGF3YWl0IHRoaXMubG9hZERhdGEodGhpcy5pZClcclxuICAgICAgICAgICAgd3guc3RvcFB1bGxEb3duUmVmcmVzaCgpXHJcbiAgICAgICAgfVxyXG4gICAgICAgIG9uU2hhcmVBcHBNZXNzYWdlKHJlcykge1xyXG4gICAgICAgICAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICAgICAgICAgICAgdGl0bGU6ICcnLFxyXG4gICAgICAgICAgICAgICAgaW1hZ2VVcmw6JycsXHJcbiAgICAgICAgICAgICAgICBwYXRoOiAnJ1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChyZXMuZnJvbSA9PT0gJ2J1dHRvbicpIHtcclxuICAgICAgICAgICAgICAgIC8vIOadpeiHqumhtemdouWGhei9rOWPkeaMiemSrlxyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2cocmVzLnRhcmdldClcclxuICAgICAgICAgICAgICAgIGxldCB0YXIgPSByZXMudGFyZ2V0XHJcbiAgICAgICAgICAgICAgICBpZih0YXIuZGF0YXNldC5hY3QgPT0gJ3B0Jyl7XHJcbiAgICAgICAgICAgICAgICAgICAgcGFyYW1zLnRpdGxlID0gdGFyLmRhdGFzZXQudGl0bGVcclxuICAgICAgICAgICAgICAgICAgICBwYXJhbXMuaW1hZ2VVcmwgPSB0YXIuZGF0YXNldC5pbWFnZXNcclxuICAgICAgICAgICAgICAgICAgICBwYXJhbXMucGF0aCA9Jy9wYWdlcy9hY3Rpdml0eS9waW50dWFuP2FpZD0nICsgIHRhci5kYXRhc2V0LmFjdGlkXHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICB0aXRsZTogcGFyYW1zLnRpdGxlLFxyXG4gICAgICAgICAgICAgICAgaW1hZ2VVcmw6cGFyYW1zLmltYWdlVXJsLFxyXG4gICAgICAgICAgICAgICAgcGF0aDpwYXJhbXMucGF0aFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIG1ldGhvZHMgPSB7XHJcbiAgICAgICAgICAgICByZW1hcmsoaWQpIHtcclxuICAgICAgICAgICAgICAgIHdlcHkubmF2aWdhdGVUbyh7XHJcbiAgICAgICAgICAgICAgICAgICAgdXJsOiAnL3BhZ2VzL21lZXQvY29tbWlSZW1hcmtlP2lkPScgKyBpZFxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGNhbmNsZShpZCkge1xyXG4gICAgICAgICAgICAgICAgbGV0IHNlbGYgPSB0aGlzXHJcbiAgICAgICAgICAgICAgICB3eC5zaG93TW9kYWwoe1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnRlbnQ6ICflj5bmtojorqLljZXlkI7lsIbml6Dms5XmgaLlpI3vvIHmmK/lkKbnu6fnu63vvJ8nLFxyXG4gICAgICAgICAgICAgICAgICAgIC8vIGNvbmZpcm1UZXh0OixcclxuICAgICAgICAgICAgICAgICAgICBzdWNjZXNzOiBhc3luYyBmdW5jdGlvbihyZXMpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlcy5jb25maXJtKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgcmVzID0gYXdhaXQgY29uZmlnLmNhbmNhbG9yZGVyKGlkKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlcy5lcnJjb2RlID09IDIwMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdlcHkubmF2aWdhdGVCYWNrKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVsdGE6IDEgLy/ov5Tlm57nmoTpobXpnaLmlbDvvIzlpoLmnpwgZGVsdGEg5aSn5LqO546w5pyJ6aG16Z2i5pWw77yM5YiZ6L+U5Zue5Yiw6aaW6aG1LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2cocmVzKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKHJlcy5jYW5jZWwpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCfnlKjmiLfngrnlh7vlj5bmtognKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgYXN5bmMgcGF5KGlkKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgX2NvZGUgPSBhd2FpdCBjb25maWcud3hwYXl0b3BheSh7XHJcbiAgICAgICAgICAgICAgICAgICAgb3JkZXJQYXlTbjogdGhpcy5vcmRlckluZm8ucGF5U24sXHJcbiAgICAgICAgICAgICAgICAgICAgZGVzY3JpYmU6ICfmj4/ov7AnLFxyXG4gICAgICAgICAgICAgICAgICAgIG1vbmV5OiB0aGlzLm9yZGVySW5mby5wYXltZW50VHlwZSA9PSAxID8gcGFyc2VJbnQodGhpcy5vcmRlckluZm8ubW9uZXlPcmRlciAqIDEwMCkgOiBwYXJzZUludCh0aGlzLm9yZGVySW5mby5lYXJuZXNNb25leSAqIDEwMClcclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICBXeFV0aWxzLnd4UGF5KF9jb2RlLmRhdGEpLnRoZW4ocmVzID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBUaXBzLnRvYXN0KFwi5pSv5LuY5oiQ5YqfXCIsIHJlcyA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubG9hZERhdGEoaWQpXHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuIl19