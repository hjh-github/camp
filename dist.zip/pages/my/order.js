"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

var _WxUtils = require('./../../utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
    _inherits(Dialog, _wepy$page);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
            navigationBarTitleText: "订单详情"
        }, _this.data = {
            orderInfo: {},
            states: {
                1: '待付款',
                2: '待使用',
                3: '已使用',
                4: '已失效'
            },
            id: ''
        }, _this.methods = {
            remark: function remark(id) {
                _wepy2.default.navigateTo({
                    url: '/pages/meet/commiRemarke?id=' + id
                });
            },
            cancle: function cancle(id) {
                var self = this;
                wx.showModal({
                    content: '取消订单后将无法恢复！是否继续？',
                    // confirmText:,
                    success: function () {
                        var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(res) {
                            var _res;

                            return regeneratorRuntime.wrap(function _callee$(_context) {
                                while (1) {
                                    switch (_context.prev = _context.next) {
                                        case 0:
                                            if (!res.confirm) {
                                                _context.next = 8;
                                                break;
                                            }

                                            _context.next = 3;
                                            return _config2.default.cancalorder(id);

                                        case 3:
                                            _res = _context.sent;

                                            if (_res.errcode == 200) {
                                                _wepy2.default.navigateBack({
                                                    delta: 1 //返回的页面数，如果 delta 大于现有页面数，则返回到首页,
                                                });
                                            }
                                            console.log(_res);
                                            _context.next = 9;
                                            break;

                                        case 8:
                                            if (res.cancel) {
                                                console.log('用户点击取消');
                                            }

                                        case 9:
                                        case "end":
                                            return _context.stop();
                                    }
                                }
                            }, _callee, this);
                        }));

                        function success(_x) {
                            return _ref2.apply(this, arguments);
                        }

                        return success;
                    }()
                });
            },
            pay: function () {
                var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(id) {
                    var _this2 = this;

                    var _code;

                    return regeneratorRuntime.wrap(function _callee2$(_context2) {
                        while (1) {
                            switch (_context2.prev = _context2.next) {
                                case 0:
                                    _context2.next = 2;
                                    return _config2.default.wxpaytopay({
                                        orderPaySn: this.orderInfo.paySn,
                                        describe: '描述',
                                        money: this.orderInfo.paymentType == 1 ? parseInt(this.orderInfo.moneyOrder * 100) : parseInt(this.orderInfo.earnesMoney * 100)
                                    });

                                case 2:
                                    _code = _context2.sent;

                                    _WxUtils2.default.wxPay(_code.data).then(function (res) {
                                        _Tips2.default.toast("支付成功", function (res) {
                                            _this2.loadData(id);
                                        });
                                    });

                                case 4:
                                case "end":
                                    return _context2.stop();
                            }
                        }
                    }, _callee2, this);
                }));

                function pay(_x2) {
                    return _ref3.apply(this, arguments);
                }

                return pay;
            }()
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(Dialog, [{
        key: "loadData",
        value: function () {
            var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(id) {
                var res;
                return regeneratorRuntime.wrap(function _callee3$(_context3) {
                    while (1) {
                        switch (_context3.prev = _context3.next) {
                            case 0:
                                _context3.next = 2;
                                return _config2.default.orderdetail(id);

                            case 2:
                                res = _context3.sent;

                                this.orderInfo = res.data.detail;
                                this.$apply();

                            case 5:
                            case "end":
                                return _context3.stop();
                        }
                    }
                }, _callee3, this);
            }));

            function loadData(_x3) {
                return _ref4.apply(this, arguments);
            }

            return loadData;
        }()
    }, {
        key: "onLoad",
        value: function () {
            var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4(opt) {
                return regeneratorRuntime.wrap(function _callee4$(_context4) {
                    while (1) {
                        switch (_context4.prev = _context4.next) {
                            case 0:
                                this.id = opt.id;
                                _context4.next = 3;
                                return this.loadData(opt.id);

                            case 3:
                            case "end":
                                return _context4.stop();
                        }
                    }
                }, _callee4, this);
            }));

            function onLoad(_x4) {
                return _ref5.apply(this, arguments);
            }

            return onLoad;
        }()
    }, {
        key: "onPullDownRefresh",
        value: function () {
            var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
                return regeneratorRuntime.wrap(function _callee5$(_context5) {
                    while (1) {
                        switch (_context5.prev = _context5.next) {
                            case 0:
                                _context5.next = 2;
                                return this.loadData(this.id);

                            case 2:
                                wx.stopPullDownRefresh();

                            case 3:
                            case "end":
                                return _context5.stop();
                        }
                    }
                }, _callee5, this);
            }));

            function onPullDownRefresh() {
                return _ref6.apply(this, arguments);
            }

            return onPullDownRefresh;
        }()
    }, {
        key: "onShareAppMessage",
        value: function onShareAppMessage(res) {
            var params = {
                title: '',
                imageUrl: '',
                path: ''
            };
            if (res.from === 'button') {
                // 来自页面内转发按钮
                console.log(res.target);
                var tar = res.target;
                if (tar.dataset.act == 'pt') {
                    params.title = tar.dataset.title;
                    params.imageUrl = tar.dataset.images;
                    params.path = '/pages/activity/pintuan?aid=' + tar.dataset.actid;
                }
            }
            return {
                title: params.title,
                imageUrl: params.imageUrl,
                path: params.path
            };
        }
    }]);

    return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/my/order'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm9yZGVyLmpzIl0sIm5hbWVzIjpbIkRpYWxvZyIsImNvbmZpZyIsIm5hdmlnYXRpb25CYXJUaXRsZVRleHQiLCJkYXRhIiwib3JkZXJJbmZvIiwic3RhdGVzIiwiaWQiLCJtZXRob2RzIiwicmVtYXJrIiwid2VweSIsIm5hdmlnYXRlVG8iLCJ1cmwiLCJjYW5jbGUiLCJzZWxmIiwid3giLCJzaG93TW9kYWwiLCJjb250ZW50Iiwic3VjY2VzcyIsInJlcyIsImNvbmZpcm0iLCJjYW5jYWxvcmRlciIsImVycmNvZGUiLCJuYXZpZ2F0ZUJhY2siLCJkZWx0YSIsImNvbnNvbGUiLCJsb2ciLCJjYW5jZWwiLCJwYXkiLCJ3eHBheXRvcGF5Iiwib3JkZXJQYXlTbiIsInBheVNuIiwiZGVzY3JpYmUiLCJtb25leSIsInBheW1lbnRUeXBlIiwicGFyc2VJbnQiLCJtb25leU9yZGVyIiwiZWFybmVzTW9uZXkiLCJfY29kZSIsIld4VXRpbHMiLCJ3eFBheSIsInRoZW4iLCJUaXBzIiwidG9hc3QiLCJsb2FkRGF0YSIsIm9yZGVyZGV0YWlsIiwiZGV0YWlsIiwiJGFwcGx5Iiwib3B0Iiwic3RvcFB1bGxEb3duUmVmcmVzaCIsInBhcmFtcyIsInRpdGxlIiwiaW1hZ2VVcmwiLCJwYXRoIiwiZnJvbSIsInRhcmdldCIsInRhciIsImRhdGFzZXQiLCJhY3QiLCJpbWFnZXMiLCJhY3RpZCIsInBhZ2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUNJOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7Ozs7Ozs7Ozs7OztJQUNxQkEsTTs7Ozs7Ozs7Ozs7Ozs7MExBQ2pCQyxNLEdBQVM7QUFDTEMsb0NBQXdCO0FBRG5CLFMsUUFHVEMsSSxHQUFPO0FBQ0hDLHVCQUFXLEVBRFI7QUFFSEMsb0JBQVE7QUFDSixtQkFBRyxLQURDO0FBRUosbUJBQUcsS0FGQztBQUdKLG1CQUFHLEtBSEM7QUFJSixtQkFBRztBQUpDLGFBRkw7QUFRSEMsZ0JBQUc7QUFSQSxTLFFBOENQQyxPLEdBQVU7QUFDTEMsa0JBREssa0JBQ0VGLEVBREYsRUFDTTtBQUNSRywrQkFBS0MsVUFBTCxDQUFnQjtBQUNaQyx5QkFBSyxpQ0FBaUNMO0FBRDFCLGlCQUFoQjtBQUdILGFBTEs7QUFNTk0sa0JBTk0sa0JBTUNOLEVBTkQsRUFNSztBQUNQLG9CQUFJTyxPQUFPLElBQVg7QUFDQUMsbUJBQUdDLFNBQUgsQ0FBYTtBQUNUQyw2QkFBUyxrQkFEQTtBQUVUO0FBQ0FDO0FBQUEsNEZBQVMsaUJBQWVDLEdBQWY7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlEQUNEQSxJQUFJQyxPQURIO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUEsbURBRWVsQixpQkFBT21CLFdBQVAsQ0FBbUJkLEVBQW5CLENBRmY7O0FBQUE7QUFFR1ksZ0RBRkg7O0FBR0QsZ0RBQUlBLEtBQUlHLE9BQUosSUFBZSxHQUFuQixFQUF3QjtBQUNwQlosK0RBQUthLFlBQUwsQ0FBa0I7QUFDZEMsMkRBQU8sQ0FETyxDQUNMO0FBREssaURBQWxCO0FBR0g7QUFDREMsb0RBQVFDLEdBQVIsQ0FBWVAsSUFBWjtBQVJDO0FBQUE7O0FBQUE7QUFTRSxnREFBSUEsSUFBSVEsTUFBUixFQUFnQjtBQUNuQkYsd0RBQVFDLEdBQVIsQ0FBWSxRQUFaO0FBQ0g7O0FBWEk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQVQ7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFIUyxpQkFBYjtBQWlCSCxhQXpCSztBQTBCQUUsZUExQkE7QUFBQSxzR0EwQklyQixFQTFCSjtBQUFBOztBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQ0EyQmdCTCxpQkFBTzJCLFVBQVAsQ0FBa0I7QUFDaENDLG9EQUFZLEtBQUt6QixTQUFMLENBQWUwQixLQURLO0FBRWhDQyxrREFBVSxJQUZzQjtBQUdoQ0MsK0NBQU8sS0FBSzVCLFNBQUwsQ0FBZTZCLFdBQWYsSUFBOEIsQ0FBOUIsR0FBa0NDLFNBQVMsS0FBSzlCLFNBQUwsQ0FBZStCLFVBQWYsR0FBNEIsR0FBckMsQ0FBbEMsR0FBOEVELFNBQVMsS0FBSzlCLFNBQUwsQ0FBZWdDLFdBQWYsR0FBNkIsR0FBdEM7QUFIckQscUNBQWxCLENBM0JoQjs7QUFBQTtBQTJCRUMseUNBM0JGOztBQWdDRkMsc0RBQVFDLEtBQVIsQ0FBY0YsTUFBTWxDLElBQXBCLEVBQTBCcUMsSUFBMUIsQ0FBK0IsZUFBTztBQUNsQ0MsdURBQUtDLEtBQUwsQ0FBVyxNQUFYLEVBQW1CLGVBQU87QUFDdEIsbURBQUtDLFFBQUwsQ0FBY3JDLEVBQWQ7QUFDSCx5Q0FGRDtBQUdILHFDQUpEOztBQWhDRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBLFM7Ozs7OztrR0FwQ0tBLEU7Ozs7Ozs7dUNBQ0tMLGlCQUFPMkMsV0FBUCxDQUFtQnRDLEVBQW5CLEM7OztBQUFaWSxtQzs7QUFDSixxQ0FBS2QsU0FBTCxHQUFpQmMsSUFBSWYsSUFBSixDQUFTMEMsTUFBMUI7QUFDQSxxQ0FBS0MsTUFBTDs7Ozs7Ozs7Ozs7Ozs7Ozs7OztrR0FFU0MsRzs7Ozs7QUFDVCxxQ0FBS3pDLEVBQUwsR0FBVXlDLElBQUl6QyxFQUFkOzt1Q0FDTSxLQUFLcUMsUUFBTCxDQUFjSSxJQUFJekMsRUFBbEIsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozt1Q0FHQSxLQUFLcUMsUUFBTCxDQUFjLEtBQUtyQyxFQUFuQixDOzs7QUFDTlEsbUNBQUdrQyxtQkFBSDs7Ozs7Ozs7Ozs7Ozs7Ozs7OzBDQUVjOUIsRyxFQUFLO0FBQ25CLGdCQUFJK0IsU0FBUztBQUNUQyx1QkFBTyxFQURFO0FBRVRDLDBCQUFTLEVBRkE7QUFHVEMsc0JBQU07QUFIRyxhQUFiO0FBS0EsZ0JBQUlsQyxJQUFJbUMsSUFBSixLQUFhLFFBQWpCLEVBQTJCO0FBQ3ZCO0FBQ0E3Qix3QkFBUUMsR0FBUixDQUFZUCxJQUFJb0MsTUFBaEI7QUFDQSxvQkFBSUMsTUFBTXJDLElBQUlvQyxNQUFkO0FBQ0Esb0JBQUdDLElBQUlDLE9BQUosQ0FBWUMsR0FBWixJQUFtQixJQUF0QixFQUEyQjtBQUN2QlIsMkJBQU9DLEtBQVAsR0FBZUssSUFBSUMsT0FBSixDQUFZTixLQUEzQjtBQUNBRCwyQkFBT0UsUUFBUCxHQUFrQkksSUFBSUMsT0FBSixDQUFZRSxNQUE5QjtBQUNBVCwyQkFBT0csSUFBUCxHQUFhLGlDQUFrQ0csSUFBSUMsT0FBSixDQUFZRyxLQUEzRDtBQUNIO0FBRUo7QUFDRCxtQkFBTztBQUNIVCx1QkFBT0QsT0FBT0MsS0FEWDtBQUVIQywwQkFBU0YsT0FBT0UsUUFGYjtBQUdIQyxzQkFBS0gsT0FBT0c7QUFIVCxhQUFQO0FBS0g7Ozs7RUFqRCtCM0MsZUFBS21ELEk7O2tCQUFwQjVELE0iLCJmaWxlIjoib3JkZXIuanMiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuICAgIGltcG9ydCB3ZXB5IGZyb20gXCJ3ZXB5XCI7XHJcbiAgICBpbXBvcnQgY29uZmlnIGZyb20gXCJAL2FwaS9jb25maWdcIlxyXG4gICAgaW1wb3J0IFRpcHMgZnJvbSBcIkAvdXRpbHMvVGlwc1wiXHJcbiAgICBpbXBvcnQgV3hVdGlscyBmcm9tIFwiQC91dGlscy9XeFV0aWxzXCJcclxuICAgIGV4cG9ydCBkZWZhdWx0IGNsYXNzIERpYWxvZyBleHRlbmRzIHdlcHkucGFnZSB7XHJcbiAgICAgICAgY29uZmlnID0ge1xyXG4gICAgICAgICAgICBuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0OiBcIuiuouWNleivpuaDhVwiXHJcbiAgICAgICAgfTtcclxuICAgICAgICBkYXRhID0ge1xyXG4gICAgICAgICAgICBvcmRlckluZm86IHt9LFxyXG4gICAgICAgICAgICBzdGF0ZXM6IHtcclxuICAgICAgICAgICAgICAgIDE6ICflvoXku5jmrL4nLFxyXG4gICAgICAgICAgICAgICAgMjogJ+W+heS9v+eUqCcsXHJcbiAgICAgICAgICAgICAgICAzOiAn5bey5L2/55SoJyxcclxuICAgICAgICAgICAgICAgIDQ6ICflt7LlpLHmlYgnXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGlkOicnXHJcbiAgICAgICAgfTtcclxuICAgICAgICBhc3luYyBsb2FkRGF0YShpZCkge1xyXG4gICAgICAgICAgICBsZXQgcmVzID0gYXdhaXQgY29uZmlnLm9yZGVyZGV0YWlsKGlkKVxyXG4gICAgICAgICAgICB0aGlzLm9yZGVySW5mbyA9IHJlcy5kYXRhLmRldGFpbFxyXG4gICAgICAgICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGFzeW5jIG9uTG9hZChvcHQpIHtcclxuICAgICAgICAgICAgdGhpcy5pZCA9IG9wdC5pZFxyXG4gICAgICAgICAgICBhd2FpdCB0aGlzLmxvYWREYXRhKG9wdC5pZClcclxuICAgICAgICB9XHJcbiAgICAgICAgYXN5bmMgb25QdWxsRG93blJlZnJlc2goKSB7XHJcbiAgICAgICAgICAgIGF3YWl0IHRoaXMubG9hZERhdGEodGhpcy5pZClcclxuICAgICAgICAgICAgd3guc3RvcFB1bGxEb3duUmVmcmVzaCgpXHJcbiAgICAgICAgfVxyXG4gICAgICAgIG9uU2hhcmVBcHBNZXNzYWdlKHJlcykge1xyXG4gICAgICAgICAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICAgICAgICAgICAgdGl0bGU6ICcnLFxyXG4gICAgICAgICAgICAgICAgaW1hZ2VVcmw6JycsXHJcbiAgICAgICAgICAgICAgICBwYXRoOiAnJ1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChyZXMuZnJvbSA9PT0gJ2J1dHRvbicpIHtcclxuICAgICAgICAgICAgICAgIC8vIOadpeiHqumhtemdouWGhei9rOWPkeaMiemSrlxyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2cocmVzLnRhcmdldClcclxuICAgICAgICAgICAgICAgIGxldCB0YXIgPSByZXMudGFyZ2V0XHJcbiAgICAgICAgICAgICAgICBpZih0YXIuZGF0YXNldC5hY3QgPT0gJ3B0Jyl7XHJcbiAgICAgICAgICAgICAgICAgICAgcGFyYW1zLnRpdGxlID0gdGFyLmRhdGFzZXQudGl0bGVcclxuICAgICAgICAgICAgICAgICAgICBwYXJhbXMuaW1hZ2VVcmwgPSB0YXIuZGF0YXNldC5pbWFnZXNcclxuICAgICAgICAgICAgICAgICAgICBwYXJhbXMucGF0aCA9Jy9wYWdlcy9hY3Rpdml0eS9waW50dWFuP2FpZD0nICsgIHRhci5kYXRhc2V0LmFjdGlkXHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICB0aXRsZTogcGFyYW1zLnRpdGxlLFxyXG4gICAgICAgICAgICAgICAgaW1hZ2VVcmw6cGFyYW1zLmltYWdlVXJsLFxyXG4gICAgICAgICAgICAgICAgcGF0aDpwYXJhbXMucGF0aFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIG1ldGhvZHMgPSB7XHJcbiAgICAgICAgICAgICByZW1hcmsoaWQpIHtcclxuICAgICAgICAgICAgICAgIHdlcHkubmF2aWdhdGVUbyh7XHJcbiAgICAgICAgICAgICAgICAgICAgdXJsOiAnL3BhZ2VzL21lZXQvY29tbWlSZW1hcmtlP2lkPScgKyBpZFxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGNhbmNsZShpZCkge1xyXG4gICAgICAgICAgICAgICAgbGV0IHNlbGYgPSB0aGlzXHJcbiAgICAgICAgICAgICAgICB3eC5zaG93TW9kYWwoe1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnRlbnQ6ICflj5bmtojorqLljZXlkI7lsIbml6Dms5XmgaLlpI3vvIHmmK/lkKbnu6fnu63vvJ8nLFxyXG4gICAgICAgICAgICAgICAgICAgIC8vIGNvbmZpcm1UZXh0OixcclxuICAgICAgICAgICAgICAgICAgICBzdWNjZXNzOiBhc3luYyBmdW5jdGlvbihyZXMpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlcy5jb25maXJtKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgcmVzID0gYXdhaXQgY29uZmlnLmNhbmNhbG9yZGVyKGlkKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlcy5lcnJjb2RlID09IDIwMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdlcHkubmF2aWdhdGVCYWNrKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVsdGE6IDEgLy/ov5Tlm57nmoTpobXpnaLmlbDvvIzlpoLmnpwgZGVsdGEg5aSn5LqO546w5pyJ6aG16Z2i5pWw77yM5YiZ6L+U5Zue5Yiw6aaW6aG1LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2cocmVzKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKHJlcy5jYW5jZWwpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCfnlKjmiLfngrnlh7vlj5bmtognKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgYXN5bmMgcGF5KGlkKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgX2NvZGUgPSBhd2FpdCBjb25maWcud3hwYXl0b3BheSh7XHJcbiAgICAgICAgICAgICAgICAgICAgb3JkZXJQYXlTbjogdGhpcy5vcmRlckluZm8ucGF5U24sXHJcbiAgICAgICAgICAgICAgICAgICAgZGVzY3JpYmU6ICfmj4/ov7AnLFxyXG4gICAgICAgICAgICAgICAgICAgIG1vbmV5OiB0aGlzLm9yZGVySW5mby5wYXltZW50VHlwZSA9PSAxID8gcGFyc2VJbnQodGhpcy5vcmRlckluZm8ubW9uZXlPcmRlciAqIDEwMCkgOiBwYXJzZUludCh0aGlzLm9yZGVySW5mby5lYXJuZXNNb25leSAqIDEwMClcclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICBXeFV0aWxzLnd4UGF5KF9jb2RlLmRhdGEpLnRoZW4ocmVzID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBUaXBzLnRvYXN0KFwi5pSv5LuY5oiQ5YqfXCIsIHJlcyA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubG9hZERhdGEoaWQpXHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuIl19