"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _WxUtils = require('./../../utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

var _contact = require('./../../components/common/contact.js');

var _contact2 = _interopRequireDefault(_contact);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var My = function (_wepy$page) {
  _inherits(My, _wepy$page);

  function My() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, My);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = My.__proto__ || Object.getPrototypeOf(My)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
      navigationBarTitleText: "我的"
    }, _this.components = {
      contact: _contact2.default
    }, _this.data = {
      // 资产
      assets: {
        total: null,
        mains: [{
          name: '优惠券',
          unit: '张',
          count: '0',
          path: '/coupons/pages/myCoupons'
        }, {
          name: '宝妈代理',
          unit: '元',
          count: '0',
          path: '/agent/pages/my'
        }, {
          name: '积分',
          unit: '分',
          count: '0',
          path: ''
        }]
      },
      // 会员
      carditems: [{
        name: '多倍积分',
        icon: '/static/images/b_m.png',
        style: 'width:39rpx;height:37rpx'
      }, {
        name: '风险把控',
        icon: '/static/images/tc.png',
        style: 'width:40rpx;height:42rpx'
      }, {
        name: '专属空间',
        icon: '/static/images/st.png',
        style: 'width:40rpx;height:30rpx'
      }, {
        name: '分享礼包',
        icon: '/static/images/hb.png',
        style: 'width:32rpx;height:36rpx'
      }],
      // 学籍系统
      bookItems: [{
        name: '学籍信息',
        icon: 'cuIcon-profilefill',
        path: '/student/pages/index'
      }, {
        name: '专属相册',
        icon: 'cuIcon-picfill',
        path: ''
      }],
      // 订单
      orderType: [{
        name: '全部',
        orderState: '0',
        icon: 'cuIcon-apps'
      }, {
        name: '待付款',
        orderState: '1',
        icon: 'cuIcon-pay'
      }, {
        name: '待参加',
        orderState: '2',
        icon: 'cuIcon-activity'
      }, {
        name: '已完成',
        orderState: '3',
        icon: 'cuIcon-comment'
      }],
      myInfo: {},
      childsData: null,
      childIndex: 0
    }, _this.methods = {
      navi: function navi(e) {
        var url = e.currentTarget.dataset.url || e.target.dataset.url;
        if (url) {
          _WxUtils2.default.backOrNavigate(url);
        }
      },
      navi2auth: function navi2auth(e) {
        var url = e.currentTarget.dataset.url || e.target.dataset.url;
        if (!url) {
          _Tips2.default.toast('功能即将上线，敬请期待', function () {}, 'none');
          return;
        }
        if (this.myInfo.children.length) {

          if (url) {
            _WxUtils2.default.backOrNavigate(url + '?childId=' + this.childsData.id);
          }
        } else {
          _Tips2.default.toast('需要先报名课程哦~', function () {
            _wepy2.default.switchTab({
              url: '/pages/home/index'
            });
          }, 'none');
        }
      },
      PickerChange: function PickerChange(e) {
        this.childIndex = e.detail.value;
        this.childsData = this.myInfo.children[this.childIndex];
      },
      bargaining: function bargaining() {
        _wepy2.default.navigateTo({
          url: './bargaining'
        });
      },
      agent: function agent() {
        _wepy2.default.navigateTo({
          url: '/agent/pages/index'
        });
      },
      pintuan: function pintuan() {
        _wepy2.default.navigateTo({
          url: './pintuan'
        });
      },
      childs: function childs() {
        if (_wepy2.default.getStorageSync('mobile')) {
          _wepy2.default.navigateTo({
            url: '/pages/meet/childs'
          });
        } else {
          _Tips2.default.toast('需要先绑定手机号哦~', function () {
            _wepy2.default.switchTab({
              url: '/pages/meet/meet'
            });
          }, 'none');
        }
      },
      toOrder: function toOrder(id) {
        _wepy2.default.navigateTo({
          url: './orders?id=' + id
        });
      }
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(My, [{
    key: "onShow",
    value: function () {
      var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
        var res;
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return _config2.default.center();

              case 2:
                res = _context.sent;

                this.myInfo = res;
                if (this.myInfo.children.length && !this.childsData) {
                  this.childsData = this.myInfo.children[0];
                }
                // this.myInfo.memberTypeId = 2
                // 刷新我的资产
                this.myAssets();
                this.$apply();

              case 7:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function onShow() {
        return _ref2.apply(this, arguments);
      }

      return onShow;
    }()
  }, {
    key: "myAssets",
    value: function myAssets() {
      this.assets.mains[0].count = this.myInfo.myAssets.countCoupon;
      this.assets.mains[1].count = this.myInfo.myAssets.totalAmount;
      this.assets.mains[2].count = this.myInfo.myAssets.integral;
      this.assets.total = this.myInfo.myAssets.totalAssets;
    }
  }]);

  return My;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(My , 'pages/my/my'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm15LmpzIl0sIm5hbWVzIjpbIk15IiwiY29uZmlnIiwibmF2aWdhdGlvbkJhclRpdGxlVGV4dCIsImNvbXBvbmVudHMiLCJjb250YWN0IiwiZGF0YSIsImFzc2V0cyIsInRvdGFsIiwibWFpbnMiLCJuYW1lIiwidW5pdCIsImNvdW50IiwicGF0aCIsImNhcmRpdGVtcyIsImljb24iLCJzdHlsZSIsImJvb2tJdGVtcyIsIm9yZGVyVHlwZSIsIm9yZGVyU3RhdGUiLCJteUluZm8iLCJjaGlsZHNEYXRhIiwiY2hpbGRJbmRleCIsIm1ldGhvZHMiLCJuYXZpIiwiZSIsInVybCIsImN1cnJlbnRUYXJnZXQiLCJkYXRhc2V0IiwidGFyZ2V0IiwiV3hVdGlscyIsImJhY2tPck5hdmlnYXRlIiwibmF2aTJhdXRoIiwiVGlwcyIsInRvYXN0IiwiY2hpbGRyZW4iLCJsZW5ndGgiLCJpZCIsIndlcHkiLCJzd2l0Y2hUYWIiLCJQaWNrZXJDaGFuZ2UiLCJkZXRhaWwiLCJ2YWx1ZSIsImJhcmdhaW5pbmciLCJuYXZpZ2F0ZVRvIiwiYWdlbnQiLCJwaW50dWFuIiwiY2hpbGRzIiwiZ2V0U3RvcmFnZVN5bmMiLCJ0b09yZGVyIiwiY2VudGVyIiwicmVzIiwibXlBc3NldHMiLCIkYXBwbHkiLCJjb3VudENvdXBvbiIsInRvdGFsQW1vdW50IiwiaW50ZWdyYWwiLCJ0b3RhbEFzc2V0cyIsInBhZ2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUNFOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7Ozs7Ozs7Ozs7O0lBQ3FCQSxFOzs7Ozs7Ozs7Ozs7Ozs4S0FDbkJDLE0sR0FBUztBQUNQQyw4QkFBd0I7QUFEakIsSyxRQUdUQyxVLEdBQWE7QUFDWEM7QUFEVyxLLFFBR2JDLEksR0FBTztBQUNMO0FBQ0FDLGNBQVE7QUFDTkMsZUFBTyxJQUREO0FBRU5DLGVBQU8sQ0FBQztBQUNKQyxnQkFBTSxLQURGO0FBRUpDLGdCQUFNLEdBRkY7QUFHSkMsaUJBQU8sR0FISDtBQUlKQyxnQkFBTTtBQUpGLFNBQUQsRUFLRjtBQUNESCxnQkFBTSxNQURMO0FBRURDLGdCQUFNLEdBRkw7QUFHREMsaUJBQU8sR0FITjtBQUlEQyxnQkFBTTtBQUpMLFNBTEUsRUFXTDtBQUNFSCxnQkFBTSxJQURSO0FBRUVDLGdCQUFNLEdBRlI7QUFHRUMsaUJBQU8sR0FIVDtBQUlFQyxnQkFBTTtBQUpSLFNBWEs7QUFGRCxPQUZIO0FBdUJMO0FBQ0FDLGlCQUFXLENBQUM7QUFDUkosY0FBTSxNQURFO0FBRVJLLGNBQU0sd0JBRkU7QUFHUkMsZUFBTztBQUhDLE9BQUQsRUFJTjtBQUNETixjQUFNLE1BREw7QUFFREssY0FBTSx1QkFGTDtBQUdEQyxlQUFPO0FBSE4sT0FKTSxFQVNUO0FBQ0VOLGNBQU0sTUFEUjtBQUVFSyxjQUFNLHVCQUZSO0FBR0VDLGVBQU87QUFIVCxPQVRTLEVBYU47QUFDRE4sY0FBTSxNQURMO0FBRURLLGNBQU0sdUJBRkw7QUFHREMsZUFBTztBQUhOLE9BYk0sQ0F4Qk47QUEyQ0w7QUFDQUMsaUJBQVcsQ0FBQztBQUNWUCxjQUFNLE1BREk7QUFFVkssY0FBTSxvQkFGSTtBQUdWRixjQUFLO0FBSEssT0FBRCxFQUlSO0FBQ0RILGNBQU0sTUFETDtBQUVESyxjQUFNLGdCQUZMO0FBR0RGLGNBQUs7QUFISixPQUpRLENBNUNOO0FBcURMO0FBQ0FLLGlCQUFXLENBQUM7QUFDUlIsY0FBTSxJQURFO0FBRVJTLG9CQUFZLEdBRko7QUFHUkosY0FBTTtBQUhFLE9BQUQsRUFJTjtBQUNETCxjQUFNLEtBREw7QUFFRFMsb0JBQVksR0FGWDtBQUdESixjQUFNO0FBSEwsT0FKTSxFQVNUO0FBQ0VMLGNBQU0sS0FEUjtBQUVFUyxvQkFBWSxHQUZkO0FBR0VKLGNBQU07QUFIUixPQVRTLEVBYU47QUFDREwsY0FBTSxLQURMO0FBRURTLG9CQUFZLEdBRlg7QUFHREosY0FBTTtBQUhMLE9BYk0sQ0F0RE47QUF5RUxLLGNBQVEsRUF6RUg7QUEwRUxDLGtCQUFXLElBMUVOO0FBMkVMQyxrQkFBVztBQTNFTixLLFFBOEZQQyxPLEdBQVU7QUFDUkMsVUFEUSxnQkFDSEMsQ0FERyxFQUNBO0FBQ04sWUFBSUMsTUFBTUQsRUFBRUUsYUFBRixDQUFnQkMsT0FBaEIsQ0FBd0JGLEdBQXhCLElBQStCRCxFQUFFSSxNQUFGLENBQVNELE9BQVQsQ0FBaUJGLEdBQTFEO0FBQ0EsWUFBSUEsR0FBSixFQUFTO0FBQ1BJLDRCQUFRQyxjQUFSLENBQXVCTCxHQUF2QjtBQUNEO0FBQ0YsT0FOTztBQU9STSxlQVBRLHFCQU9FUCxDQVBGLEVBT0k7QUFDVixZQUFJQyxNQUFNRCxFQUFFRSxhQUFGLENBQWdCQyxPQUFoQixDQUF3QkYsR0FBeEIsSUFBK0JELEVBQUVJLE1BQUYsQ0FBU0QsT0FBVCxDQUFpQkYsR0FBMUQ7QUFDQSxZQUFHLENBQUNBLEdBQUosRUFBUTtBQUNOTyx5QkFBS0MsS0FBTCxDQUFXLGFBQVgsRUFBMEIsWUFBTSxDQUFFLENBQWxDLEVBQW9DLE1BQXBDO0FBQ0E7QUFDRDtBQUNELFlBQUcsS0FBS2QsTUFBTCxDQUFZZSxRQUFaLENBQXFCQyxNQUF4QixFQUErQjs7QUFFN0IsY0FBSVYsR0FBSixFQUFTO0FBQ1BJLDhCQUFRQyxjQUFSLENBQXVCTCxNQUFNLFdBQU4sR0FBb0IsS0FBS0wsVUFBTCxDQUFnQmdCLEVBQTNEO0FBQ0Q7QUFDRixTQUxELE1BS0s7QUFDSEoseUJBQUtDLEtBQUwsQ0FBVyxXQUFYLEVBQXdCLFlBQU07QUFDNUJJLDJCQUFLQyxTQUFMLENBQWU7QUFDYmIsbUJBQUs7QUFEUSxhQUFmO0FBR0QsV0FKRCxFQUlHLE1BSkg7QUFLRDtBQUNGLE9BekJPO0FBMEJSYyxrQkExQlEsd0JBMEJLZixDQTFCTCxFQTBCUTtBQUNaLGFBQUtILFVBQUwsR0FBa0JHLEVBQUVnQixNQUFGLENBQVNDLEtBQTNCO0FBQ0EsYUFBS3JCLFVBQUwsR0FBa0IsS0FBS0QsTUFBTCxDQUFZZSxRQUFaLENBQXFCLEtBQUtiLFVBQTFCLENBQWxCO0FBQ0gsT0E3Qk87QUE4QlJxQixnQkE5QlEsd0JBOEJLO0FBQ1hMLHVCQUFLTSxVQUFMLENBQWdCO0FBQ2RsQixlQUFLO0FBRFMsU0FBaEI7QUFHRCxPQWxDTztBQW1DUm1CLFdBbkNRLG1CQW1DQTtBQUNOUCx1QkFBS00sVUFBTCxDQUFnQjtBQUNkbEIsZUFBSztBQURTLFNBQWhCO0FBR0QsT0F2Q087QUF3Q1JvQixhQXhDUSxxQkF3Q0U7QUFDUlIsdUJBQUtNLFVBQUwsQ0FBZ0I7QUFDZGxCLGVBQUs7QUFEUyxTQUFoQjtBQUdELE9BNUNPO0FBNkNScUIsWUE3Q1Esb0JBNkNDO0FBQ1AsWUFBSVQsZUFBS1UsY0FBTCxDQUFvQixRQUFwQixDQUFKLEVBQW1DO0FBQ2pDVix5QkFBS00sVUFBTCxDQUFnQjtBQUNkbEIsaUJBQUs7QUFEUyxXQUFoQjtBQUdELFNBSkQsTUFJTztBQUNMTyx5QkFBS0MsS0FBTCxDQUFXLFlBQVgsRUFBeUIsWUFBTTtBQUM3QkksMkJBQUtDLFNBQUwsQ0FBZTtBQUNiYixtQkFBSztBQURRLGFBQWY7QUFHRCxXQUpELEVBSUcsTUFKSDtBQUtEO0FBQ0YsT0F6RE87QUEwRFJ1QixhQTFEUSxtQkEwREFaLEVBMURBLEVBMERJO0FBQ1ZDLHVCQUFLTSxVQUFMLENBQWdCO0FBQ2RsQixlQUFLLGlCQUFpQlc7QUFEUixTQUFoQjtBQUdEO0FBOURPLEs7Ozs7Ozs7Ozs7Ozs7dUJBaEJRbkMsaUJBQU9nRCxNQUFQLEU7OztBQUFaQyxtQjs7QUFDSixxQkFBSy9CLE1BQUwsR0FBYytCLEdBQWQ7QUFDQSxvQkFBRyxLQUFLL0IsTUFBTCxDQUFZZSxRQUFaLENBQXFCQyxNQUFyQixJQUErQixDQUFDLEtBQUtmLFVBQXhDLEVBQW1EO0FBQ2pELHVCQUFLQSxVQUFMLEdBQWtCLEtBQUtELE1BQUwsQ0FBWWUsUUFBWixDQUFxQixDQUFyQixDQUFsQjtBQUNEO0FBQ0Q7QUFDQTtBQUNBLHFCQUFLaUIsUUFBTDtBQUNBLHFCQUFLQyxNQUFMOzs7Ozs7Ozs7Ozs7Ozs7Ozs7K0JBRVM7QUFDVCxXQUFLOUMsTUFBTCxDQUFZRSxLQUFaLENBQWtCLENBQWxCLEVBQXFCRyxLQUFyQixHQUE2QixLQUFLUSxNQUFMLENBQVlnQyxRQUFaLENBQXFCRSxXQUFsRDtBQUNBLFdBQUsvQyxNQUFMLENBQVlFLEtBQVosQ0FBa0IsQ0FBbEIsRUFBcUJHLEtBQXJCLEdBQTZCLEtBQUtRLE1BQUwsQ0FBWWdDLFFBQVosQ0FBcUJHLFdBQWxEO0FBQ0EsV0FBS2hELE1BQUwsQ0FBWUUsS0FBWixDQUFrQixDQUFsQixFQUFxQkcsS0FBckIsR0FBNkIsS0FBS1EsTUFBTCxDQUFZZ0MsUUFBWixDQUFxQkksUUFBbEQ7QUFDQSxXQUFLakQsTUFBTCxDQUFZQyxLQUFaLEdBQW9CLEtBQUtZLE1BQUwsQ0FBWWdDLFFBQVosQ0FBcUJLLFdBQXpDO0FBQ0Q7Ozs7RUFwRzZCbkIsZUFBS29CLEk7O2tCQUFoQnpELEUiLCJmaWxlIjoibXkuanMiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuICBpbXBvcnQgd2VweSBmcm9tIFwid2VweVwiO1xyXG4gIGltcG9ydCBUaXBzIGZyb20gXCJAL3V0aWxzL1RpcHNcIlxyXG4gIGltcG9ydCBjb25maWcgZnJvbSBcIkAvYXBpL2NvbmZpZ1wiXHJcbiAgaW1wb3J0IFd4VXRpbHMgZnJvbSBcIkAvdXRpbHMvV3hVdGlsc1wiXHJcbiAgaW1wb3J0IGNvbnRhY3QgZnJvbSBcIkAvY29tcG9uZW50cy9jb21tb24vY29udGFjdFwiXHJcbiAgZXhwb3J0IGRlZmF1bHQgY2xhc3MgTXkgZXh0ZW5kcyB3ZXB5LnBhZ2Uge1xyXG4gICAgY29uZmlnID0ge1xyXG4gICAgICBuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0OiBcIuaIkeeahFwiXHJcbiAgICB9O1xyXG4gICAgY29tcG9uZW50cyA9IHtcclxuICAgICAgY29udGFjdFxyXG4gICAgfVxyXG4gICAgZGF0YSA9IHtcbiAgICAgIC8vIOi1hOS6p1xyXG4gICAgICBhc3NldHM6IHtcclxuICAgICAgICB0b3RhbDogbnVsbCxcclxuICAgICAgICBtYWluczogW3tcclxuICAgICAgICAgICAgbmFtZTogJ+S8mOaDoOWIuCcsXHJcbiAgICAgICAgICAgIHVuaXQ6ICflvKAnLFxyXG4gICAgICAgICAgICBjb3VudDogJzAnLFxyXG4gICAgICAgICAgICBwYXRoOiAnL2NvdXBvbnMvcGFnZXMvbXlDb3Vwb25zJ1xyXG4gICAgICAgICAgfSwge1xyXG4gICAgICAgICAgICBuYW1lOiAn5a6d5aaI5Luj55CGJyxcclxuICAgICAgICAgICAgdW5pdDogJ+WFgycsXHJcbiAgICAgICAgICAgIGNvdW50OiAnMCcsXHJcbiAgICAgICAgICAgIHBhdGg6ICcvYWdlbnQvcGFnZXMvbXknXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBuYW1lOiAn56ev5YiGJyxcclxuICAgICAgICAgICAgdW5pdDogJ+WIhicsXHJcbiAgICAgICAgICAgIGNvdW50OiAnMCcsXHJcbiAgICAgICAgICAgIHBhdGg6ICcnXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgXVxyXG4gICAgICB9LFxuICAgICAgLy8g5Lya5ZGYXHJcbiAgICAgIGNhcmRpdGVtczogW3tcclxuICAgICAgICAgIG5hbWU6ICflpJrlgI3np6/liIYnLFxyXG4gICAgICAgICAgaWNvbjogJy9zdGF0aWMvaW1hZ2VzL2JfbS5wbmcnLFxyXG4gICAgICAgICAgc3R5bGU6ICd3aWR0aDozOXJweDtoZWlnaHQ6MzdycHgnXHJcbiAgICAgICAgfSwge1xyXG4gICAgICAgICAgbmFtZTogJ+mjjumZqeaKiuaOpycsXHJcbiAgICAgICAgICBpY29uOiAnL3N0YXRpYy9pbWFnZXMvdGMucG5nJyxcclxuICAgICAgICAgIHN0eWxlOiAnd2lkdGg6NDBycHg7aGVpZ2h0OjQycnB4J1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgbmFtZTogJ+S4k+WxnuepuumXtCcsXHJcbiAgICAgICAgICBpY29uOiAnL3N0YXRpYy9pbWFnZXMvc3QucG5nJyxcclxuICAgICAgICAgIHN0eWxlOiAnd2lkdGg6NDBycHg7aGVpZ2h0OjMwcnB4J1xyXG4gICAgICAgIH0sIHtcclxuICAgICAgICAgIG5hbWU6ICfliIbkuqvnpLzljIUnLFxyXG4gICAgICAgICAgaWNvbjogJy9zdGF0aWMvaW1hZ2VzL2hiLnBuZycsXHJcbiAgICAgICAgICBzdHlsZTogJ3dpZHRoOjMycnB4O2hlaWdodDozNnJweCdcclxuICAgICAgICB9XHJcbiAgICAgIF0sXG4gICAgICAvLyDlrabnsY3ns7vnu59cclxuICAgICAgYm9va0l0ZW1zOiBbe1xyXG4gICAgICAgIG5hbWU6ICflrabnsY3kv6Hmga8nLFxyXG4gICAgICAgIGljb246ICdjdUljb24tcHJvZmlsZWZpbGwnLFxuICAgICAgICBwYXRoOicvc3R1ZGVudC9wYWdlcy9pbmRleCdcclxuICAgICAgfSwge1xyXG4gICAgICAgIG5hbWU6ICfkuJPlsZ7nm7jlhownLFxyXG4gICAgICAgIGljb246ICdjdUljb24tcGljZmlsbCcsXG4gICAgICAgIHBhdGg6JydcclxuICAgICAgfV0sXG4gICAgICAvLyDorqLljZVcclxuICAgICAgb3JkZXJUeXBlOiBbe1xyXG4gICAgICAgICAgbmFtZTogJ+WFqOmDqCcsXHJcbiAgICAgICAgICBvcmRlclN0YXRlOiAnMCcsXHJcbiAgICAgICAgICBpY29uOiAnY3VJY29uLWFwcHMnXHJcbiAgICAgICAgfSwge1xyXG4gICAgICAgICAgbmFtZTogJ+W+heS7mOasvicsXHJcbiAgICAgICAgICBvcmRlclN0YXRlOiAnMScsXHJcbiAgICAgICAgICBpY29uOiAnY3VJY29uLXBheSdcclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIG5hbWU6ICflvoXlj4LliqAnLFxyXG4gICAgICAgICAgb3JkZXJTdGF0ZTogJzInLFxyXG4gICAgICAgICAgaWNvbjogJ2N1SWNvbi1hY3Rpdml0eSdcclxuICAgICAgICB9LCB7XHJcbiAgICAgICAgICBuYW1lOiAn5bey5a6M5oiQJyxcclxuICAgICAgICAgIG9yZGVyU3RhdGU6ICczJyxcclxuICAgICAgICAgIGljb246ICdjdUljb24tY29tbWVudCdcclxuICAgICAgICB9XHJcbiAgICAgIF0sXHJcbiAgICAgIG15SW5mbzoge30sXG4gICAgICBjaGlsZHNEYXRhOm51bGwsXG4gICAgICBjaGlsZEluZGV4OjBcclxuICAgIH07XHJcbiAgICBhc3luYyBvblNob3coKSB7XHJcbiAgICAgIGxldCByZXMgPSBhd2FpdCBjb25maWcuY2VudGVyKClcclxuICAgICAgdGhpcy5teUluZm8gPSByZXNcbiAgICAgIGlmKHRoaXMubXlJbmZvLmNoaWxkcmVuLmxlbmd0aCAmJiAhdGhpcy5jaGlsZHNEYXRhKXtcbiAgICAgICAgdGhpcy5jaGlsZHNEYXRhID0gdGhpcy5teUluZm8uY2hpbGRyZW5bMF1cbiAgICAgIH1cclxuICAgICAgLy8gdGhpcy5teUluZm8ubWVtYmVyVHlwZUlkID0gMlxyXG4gICAgICAvLyDliLfmlrDmiJHnmoTotYTkuqdcclxuICAgICAgdGhpcy5teUFzc2V0cygpXHJcbiAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgIH1cclxuICAgIG15QXNzZXRzKCkge1xyXG4gICAgICB0aGlzLmFzc2V0cy5tYWluc1swXS5jb3VudCA9IHRoaXMubXlJbmZvLm15QXNzZXRzLmNvdW50Q291cG9uXHJcbiAgICAgIHRoaXMuYXNzZXRzLm1haW5zWzFdLmNvdW50ID0gdGhpcy5teUluZm8ubXlBc3NldHMudG90YWxBbW91bnRcclxuICAgICAgdGhpcy5hc3NldHMubWFpbnNbMl0uY291bnQgPSB0aGlzLm15SW5mby5teUFzc2V0cy5pbnRlZ3JhbFxyXG4gICAgICB0aGlzLmFzc2V0cy50b3RhbCA9IHRoaXMubXlJbmZvLm15QXNzZXRzLnRvdGFsQXNzZXRzXHJcbiAgICB9XHJcbiAgICBtZXRob2RzID0ge1xyXG4gICAgICBuYXZpKGUpIHtcclxuICAgICAgICBsZXQgdXJsID0gZS5jdXJyZW50VGFyZ2V0LmRhdGFzZXQudXJsIHx8IGUudGFyZ2V0LmRhdGFzZXQudXJsXHJcbiAgICAgICAgaWYgKHVybCkge1xyXG4gICAgICAgICAgV3hVdGlscy5iYWNrT3JOYXZpZ2F0ZSh1cmwpXHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxuICAgICAgbmF2aTJhdXRoKGUpe1xuICAgICAgICBsZXQgdXJsID0gZS5jdXJyZW50VGFyZ2V0LmRhdGFzZXQudXJsIHx8IGUudGFyZ2V0LmRhdGFzZXQudXJsXG4gICAgICAgIGlmKCF1cmwpe1xuICAgICAgICAgIFRpcHMudG9hc3QoJ+WKn+iDveWNs+WwhuS4iue6v++8jOaVrOivt+acn+W+hScsICgpID0+IHt9LCAnbm9uZScpXG4gICAgICAgICAgcmV0dXJuXG4gICAgICAgIH1cbiAgICAgICAgaWYodGhpcy5teUluZm8uY2hpbGRyZW4ubGVuZ3RoKXtcbiAgICAgICAgICBcbiAgICAgICAgICBpZiAodXJsKSB7XG4gICAgICAgICAgICBXeFV0aWxzLmJhY2tPck5hdmlnYXRlKHVybCArICc/Y2hpbGRJZD0nICsgdGhpcy5jaGlsZHNEYXRhLmlkKVxuICAgICAgICAgIH1cbiAgICAgICAgfWVsc2V7XG4gICAgICAgICAgVGlwcy50b2FzdCgn6ZyA6KaB5YWI5oql5ZCN6K++56iL5ZOmficsICgpID0+IHtcbiAgICAgICAgICAgIHdlcHkuc3dpdGNoVGFiKHtcbiAgICAgICAgICAgICAgdXJsOiAnL3BhZ2VzL2hvbWUvaW5kZXgnXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9LCAnbm9uZScpXG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBQaWNrZXJDaGFuZ2UoZSkge1xuICAgICAgICAgIHRoaXMuY2hpbGRJbmRleCA9IGUuZGV0YWlsLnZhbHVlXG4gICAgICAgICAgdGhpcy5jaGlsZHNEYXRhID0gdGhpcy5teUluZm8uY2hpbGRyZW5bdGhpcy5jaGlsZEluZGV4XVxuICAgICAgfSxcclxuICAgICAgYmFyZ2FpbmluZygpIHtcclxuICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgdXJsOiAnLi9iYXJnYWluaW5nJ1xyXG4gICAgICAgIH0pO1xyXG4gICAgICB9LFxyXG4gICAgICBhZ2VudCgpIHtcclxuICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgdXJsOiAnL2FnZW50L3BhZ2VzL2luZGV4J1xyXG4gICAgICAgIH0pO1xyXG4gICAgICB9LFxyXG4gICAgICBwaW50dWFuKCkge1xyXG4gICAgICAgIHdlcHkubmF2aWdhdGVUbyh7XHJcbiAgICAgICAgICB1cmw6ICcuL3BpbnR1YW4nXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0sXHJcbiAgICAgIGNoaWxkcygpIHtcclxuICAgICAgICBpZiAod2VweS5nZXRTdG9yYWdlU3luYygnbW9iaWxlJykpIHtcclxuICAgICAgICAgIHdlcHkubmF2aWdhdGVUbyh7XHJcbiAgICAgICAgICAgIHVybDogJy9wYWdlcy9tZWV0L2NoaWxkcydcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBUaXBzLnRvYXN0KCfpnIDopoHlhYjnu5HlrprmiYvmnLrlj7flk6Z+JywgKCkgPT4ge1xyXG4gICAgICAgICAgICB3ZXB5LnN3aXRjaFRhYih7XHJcbiAgICAgICAgICAgICAgdXJsOiAnL3BhZ2VzL21lZXQvbWVldCdcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICB9LCAnbm9uZScpXHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG4gICAgICB0b09yZGVyKGlkKSB7XHJcbiAgICAgICAgd2VweS5uYXZpZ2F0ZVRvKHtcclxuICAgICAgICAgIHVybDogJy4vb3JkZXJzP2lkPScgKyBpZFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gIH1cclxuIl19