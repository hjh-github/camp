"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _contact = require('./../../components/common/contact.js');

var _contact2 = _interopRequireDefault(_contact);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var My = function (_wepy$page) {
  _inherits(My, _wepy$page);

  function My() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, My);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = My.__proto__ || Object.getPrototypeOf(My)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
      navigationBarTitleText: "我的"
    }, _this.components = {
      contact: _contact2.default
    }, _this.data = {
      assets: {
        total: null,
        mains: [{
          name: '优惠券',
          unit: '张',
          count: '0',
          path: '/coupons/pages/myCoupons'
        }, {
          name: '宝妈代理',
          unit: '元',
          count: '0',
          path: '/agent/pages/my'
        }, {
          name: '积分',
          unit: '分',
          count: '0',
          path: ''
        }]
      },
      carditems: [{
        name: '多倍积分',
        icon: '/static/images/b_m.png',
        style: 'width:39rpx;height:37rpx'
      }, {
        name: '风险把控',
        icon: '/static/images/tc.png',
        style: 'width:40rpx;height:42rpx'
      }, {
        name: '专属空间',
        icon: '/static/images/st.png',
        style: 'width:40rpx;height:30rpx'
      }, {
        name: '分享礼包',
        icon: '/static/images/hb.png',
        style: 'width:32rpx;height:36rpx'
      }],
      orderType: [{
        name: '全部',
        orderState: '0',
        icon: 'cuIcon-apps'
      }, {
        name: '待付款',
        orderState: '1',
        icon: 'cuIcon-pay'
      }, {
        name: '待参加',
        orderState: '2',
        icon: 'cuIcon-activity'
      }, {
        name: '已完成',
        orderState: '3',
        icon: 'cuIcon-comment'
      }],
      myInfo: {}
    }, _this.methods = {
      navi: function navi(e) {
        var url = e.currentTarget.dataset.url || e.target.dataset.url;
        if (url) {
          _wepy2.default.navigateTo({
            url: url
          });
        }
      },
      bargaining: function bargaining() {
        _wepy2.default.navigateTo({
          url: './bargaining'
        });
      },
      agent: function agent() {
        _wepy2.default.navigateTo({
          url: '/agent/pages/index'
        });
      },
      pintuan: function pintuan() {
        _wepy2.default.navigateTo({
          url: './pintuan'
        });
      },
      childs: function childs() {
        if (_wepy2.default.getStorageSync('mobile')) {
          _wepy2.default.navigateTo({
            url: '/pages/meet/childs'
          });
        } else {
          _Tips2.default.toast('需要先绑定手机号哦~', function () {
            _wepy2.default.switchTab({
              url: '/pages/meet/meet'
            });
          }, 'none');
        }
      },
      toOrder: function toOrder(id) {
        _wepy2.default.navigateTo({
          url: './orders?id=' + id
        });
      }
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(My, [{
    key: "onShow",
    value: function () {
      var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
        var res;
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return _config2.default.center();

              case 2:
                res = _context.sent;

                this.myInfo = res;
                // this.myInfo.memberTypeId = 2
                // 刷新我的资产
                this.myAssets();
                this.$apply();

              case 6:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function onShow() {
        return _ref2.apply(this, arguments);
      }

      return onShow;
    }()
  }, {
    key: "myAssets",
    value: function myAssets() {
      this.assets.mains[0].count = this.myInfo.myAssets.countCoupon;
      this.assets.mains[1].count = this.myInfo.myAssets.totalAmount;
      this.assets.mains[2].count = this.myInfo.myAssets.integral;
      this.assets.total = this.myInfo.myAssets.totalAssets;
    }
  }]);

  return My;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(My , 'pages/my/my'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm15LmpzIl0sIm5hbWVzIjpbIk15IiwiY29uZmlnIiwibmF2aWdhdGlvbkJhclRpdGxlVGV4dCIsImNvbXBvbmVudHMiLCJjb250YWN0IiwiZGF0YSIsImFzc2V0cyIsInRvdGFsIiwibWFpbnMiLCJuYW1lIiwidW5pdCIsImNvdW50IiwicGF0aCIsImNhcmRpdGVtcyIsImljb24iLCJzdHlsZSIsIm9yZGVyVHlwZSIsIm9yZGVyU3RhdGUiLCJteUluZm8iLCJtZXRob2RzIiwibmF2aSIsImUiLCJ1cmwiLCJjdXJyZW50VGFyZ2V0IiwiZGF0YXNldCIsInRhcmdldCIsIndlcHkiLCJuYXZpZ2F0ZVRvIiwiYmFyZ2FpbmluZyIsImFnZW50IiwicGludHVhbiIsImNoaWxkcyIsImdldFN0b3JhZ2VTeW5jIiwiVGlwcyIsInRvYXN0Iiwic3dpdGNoVGFiIiwidG9PcmRlciIsImlkIiwiY2VudGVyIiwicmVzIiwibXlBc3NldHMiLCIkYXBwbHkiLCJjb3VudENvdXBvbiIsInRvdGFsQW1vdW50IiwiaW50ZWdyYWwiLCJ0b3RhbEFzc2V0cyIsInBhZ2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUNFOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7Ozs7Ozs7Ozs7OztJQUNxQkEsRTs7Ozs7Ozs7Ozs7Ozs7OEtBQ25CQyxNLEdBQVM7QUFDUEMsOEJBQXdCO0FBRGpCLEssUUFHVEMsVSxHQUFhO0FBQ1hDO0FBRFcsSyxRQUdiQyxJLEdBQU87QUFDTEMsY0FBUTtBQUNOQyxlQUFPLElBREQ7QUFFTkMsZUFBTyxDQUFDO0FBQ0pDLGdCQUFNLEtBREY7QUFFSkMsZ0JBQU0sR0FGRjtBQUdKQyxpQkFBTyxHQUhIO0FBSUpDLGdCQUFNO0FBSkYsU0FBRCxFQUtGO0FBQ0RILGdCQUFNLE1BREw7QUFFREMsZ0JBQU0sR0FGTDtBQUdEQyxpQkFBTyxHQUhOO0FBSURDLGdCQUFNO0FBSkwsU0FMRSxFQVdMO0FBQ0VILGdCQUFNLElBRFI7QUFFRUMsZ0JBQU0sR0FGUjtBQUdFQyxpQkFBTyxHQUhUO0FBSUVDLGdCQUFNO0FBSlIsU0FYSztBQUZELE9BREg7QUFzQkxDLGlCQUFXLENBQUM7QUFDUkosY0FBTSxNQURFO0FBRVJLLGNBQU0sd0JBRkU7QUFHUkMsZUFBTztBQUhDLE9BQUQsRUFJTjtBQUNETixjQUFNLE1BREw7QUFFREssY0FBTSx1QkFGTDtBQUdEQyxlQUFPO0FBSE4sT0FKTSxFQVNUO0FBQ0VOLGNBQU0sTUFEUjtBQUVFSyxjQUFNLHVCQUZSO0FBR0VDLGVBQU87QUFIVCxPQVRTLEVBYU47QUFDRE4sY0FBTSxNQURMO0FBRURLLGNBQU0sdUJBRkw7QUFHREMsZUFBTztBQUhOLE9BYk0sQ0F0Qk47QUF5Q0xDLGlCQUFXLENBQUM7QUFDUlAsY0FBTSxJQURFO0FBRVJRLG9CQUFZLEdBRko7QUFHUkgsY0FBTTtBQUhFLE9BQUQsRUFJTjtBQUNETCxjQUFNLEtBREw7QUFFRFEsb0JBQVksR0FGWDtBQUdESCxjQUFNO0FBSEwsT0FKTSxFQVNUO0FBQ0VMLGNBQU0sS0FEUjtBQUVFUSxvQkFBWSxHQUZkO0FBR0VILGNBQU07QUFIUixPQVRTLEVBYU47QUFDREwsY0FBTSxLQURMO0FBRURRLG9CQUFZLEdBRlg7QUFHREgsY0FBTTtBQUhMLE9BYk0sQ0F6Q047QUE0RExJLGNBQVE7QUE1REgsSyxRQTRFUEMsTyxHQUFVO0FBQ1JDLFVBRFEsZ0JBQ0hDLENBREcsRUFDQTtBQUNOLFlBQUlDLE1BQU1ELEVBQUVFLGFBQUYsQ0FBZ0JDLE9BQWhCLENBQXdCRixHQUF4QixJQUErQkQsRUFBRUksTUFBRixDQUFTRCxPQUFULENBQWlCRixHQUExRDtBQUNBLFlBQUlBLEdBQUosRUFBUztBQUNQSSx5QkFBS0MsVUFBTCxDQUFnQjtBQUNkTDtBQURjLFdBQWhCO0FBR0Q7QUFDRixPQVJPO0FBU1JNLGdCQVRRLHdCQVNLO0FBQ1hGLHVCQUFLQyxVQUFMLENBQWdCO0FBQ2RMLGVBQUs7QUFEUyxTQUFoQjtBQUdELE9BYk87QUFjUk8sV0FkUSxtQkFjQTtBQUNOSCx1QkFBS0MsVUFBTCxDQUFnQjtBQUNkTCxlQUFLO0FBRFMsU0FBaEI7QUFHRCxPQWxCTztBQW1CUlEsYUFuQlEscUJBbUJFO0FBQ1JKLHVCQUFLQyxVQUFMLENBQWdCO0FBQ2RMLGVBQUs7QUFEUyxTQUFoQjtBQUdELE9BdkJPO0FBd0JSUyxZQXhCUSxvQkF3QkM7QUFDUCxZQUFJTCxlQUFLTSxjQUFMLENBQW9CLFFBQXBCLENBQUosRUFBbUM7QUFDakNOLHlCQUFLQyxVQUFMLENBQWdCO0FBQ2RMLGlCQUFLO0FBRFMsV0FBaEI7QUFHRCxTQUpELE1BSU87QUFDTFcseUJBQUtDLEtBQUwsQ0FBVyxZQUFYLEVBQXlCLFlBQU07QUFDN0JSLDJCQUFLUyxTQUFMLENBQWU7QUFDYmIsbUJBQUs7QUFEUSxhQUFmO0FBR0QsV0FKRCxFQUlHLE1BSkg7QUFLRDtBQUNGLE9BcENPO0FBcUNSYyxhQXJDUSxtQkFxQ0FDLEVBckNBLEVBcUNJO0FBQ1ZYLHVCQUFLQyxVQUFMLENBQWdCO0FBQ2RMLGVBQUssaUJBQWlCZTtBQURSLFNBQWhCO0FBR0Q7QUF6Q08sSzs7Ozs7Ozs7Ozs7Ozt1QkFiUXBDLGlCQUFPcUMsTUFBUCxFOzs7QUFBWkMsbUI7O0FBQ0oscUJBQUtyQixNQUFMLEdBQWNxQixHQUFkO0FBQ0E7QUFDQTtBQUNBLHFCQUFLQyxRQUFMO0FBQ0EscUJBQUtDLE1BQUw7Ozs7Ozs7Ozs7Ozs7Ozs7OzsrQkFFUztBQUNULFdBQUtuQyxNQUFMLENBQVlFLEtBQVosQ0FBa0IsQ0FBbEIsRUFBcUJHLEtBQXJCLEdBQTZCLEtBQUtPLE1BQUwsQ0FBWXNCLFFBQVosQ0FBcUJFLFdBQWxEO0FBQ0EsV0FBS3BDLE1BQUwsQ0FBWUUsS0FBWixDQUFrQixDQUFsQixFQUFxQkcsS0FBckIsR0FBNkIsS0FBS08sTUFBTCxDQUFZc0IsUUFBWixDQUFxQkcsV0FBbEQ7QUFDQSxXQUFLckMsTUFBTCxDQUFZRSxLQUFaLENBQWtCLENBQWxCLEVBQXFCRyxLQUFyQixHQUE2QixLQUFLTyxNQUFMLENBQVlzQixRQUFaLENBQXFCSSxRQUFsRDtBQUNBLFdBQUt0QyxNQUFMLENBQVlDLEtBQVosR0FBb0IsS0FBS1csTUFBTCxDQUFZc0IsUUFBWixDQUFxQkssV0FBekM7QUFDRDs7OztFQWxGNkJuQixlQUFLb0IsSTs7a0JBQWhCOUMsRSIsImZpbGUiOiJteS5qcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4gIGltcG9ydCB3ZXB5IGZyb20gXCJ3ZXB5XCI7XHJcbiAgaW1wb3J0IFRpcHMgZnJvbSBcIkAvdXRpbHMvVGlwc1wiXHJcbiAgaW1wb3J0IGNvbmZpZyBmcm9tIFwiQC9hcGkvY29uZmlnXCJcclxuICBpbXBvcnQgY29udGFjdCBmcm9tIFwiQC9jb21wb25lbnRzL2NvbW1vbi9jb250YWN0XCJcclxuICBleHBvcnQgZGVmYXVsdCBjbGFzcyBNeSBleHRlbmRzIHdlcHkucGFnZSB7XHJcbiAgICBjb25maWcgPSB7XHJcbiAgICAgIG5hdmlnYXRpb25CYXJUaXRsZVRleHQ6IFwi5oiR55qEXCJcclxuICAgIH07XHJcbiAgICBjb21wb25lbnRzID0ge1xyXG4gICAgICBjb250YWN0XHJcbiAgICB9XHJcbiAgICBkYXRhID0ge1xyXG4gICAgICBhc3NldHM6IHtcclxuICAgICAgICB0b3RhbDogbnVsbCxcclxuICAgICAgICBtYWluczogW3tcclxuICAgICAgICAgICAgbmFtZTogJ+S8mOaDoOWIuCcsXHJcbiAgICAgICAgICAgIHVuaXQ6ICflvKAnLFxyXG4gICAgICAgICAgICBjb3VudDogJzAnLFxyXG4gICAgICAgICAgICBwYXRoOiAnL2NvdXBvbnMvcGFnZXMvbXlDb3Vwb25zJ1xyXG4gICAgICAgICAgfSwge1xyXG4gICAgICAgICAgICBuYW1lOiAn5a6d5aaI5Luj55CGJyxcclxuICAgICAgICAgICAgdW5pdDogJ+WFgycsXHJcbiAgICAgICAgICAgIGNvdW50OiAnMCcsXHJcbiAgICAgICAgICAgIHBhdGg6ICcvYWdlbnQvcGFnZXMvbXknXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBuYW1lOiAn56ev5YiGJyxcclxuICAgICAgICAgICAgdW5pdDogJ+WIhicsXHJcbiAgICAgICAgICAgIGNvdW50OiAnMCcsXHJcbiAgICAgICAgICAgIHBhdGg6ICcnXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgXVxyXG4gICAgICB9LFxyXG4gICAgICBjYXJkaXRlbXM6IFt7XHJcbiAgICAgICAgICBuYW1lOiAn5aSa5YCN56ev5YiGJyxcclxuICAgICAgICAgIGljb246ICcvc3RhdGljL2ltYWdlcy9iX20ucG5nJyxcclxuICAgICAgICAgIHN0eWxlOiAnd2lkdGg6MzlycHg7aGVpZ2h0OjM3cnB4J1xyXG4gICAgICAgIH0sIHtcclxuICAgICAgICAgIG5hbWU6ICfpo47pmanmiormjqcnLFxyXG4gICAgICAgICAgaWNvbjogJy9zdGF0aWMvaW1hZ2VzL3RjLnBuZycsXHJcbiAgICAgICAgICBzdHlsZTogJ3dpZHRoOjQwcnB4O2hlaWdodDo0MnJweCdcclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIG5hbWU6ICfkuJPlsZ7nqbrpl7QnLFxyXG4gICAgICAgICAgaWNvbjogJy9zdGF0aWMvaW1hZ2VzL3N0LnBuZycsXHJcbiAgICAgICAgICBzdHlsZTogJ3dpZHRoOjQwcnB4O2hlaWdodDozMHJweCdcclxuICAgICAgICB9LCB7XHJcbiAgICAgICAgICBuYW1lOiAn5YiG5Lqr56S85YyFJyxcclxuICAgICAgICAgIGljb246ICcvc3RhdGljL2ltYWdlcy9oYi5wbmcnLFxyXG4gICAgICAgICAgc3R5bGU6ICd3aWR0aDozMnJweDtoZWlnaHQ6MzZycHgnXHJcbiAgICAgICAgfVxyXG4gICAgICBdLFxyXG4gICAgICBvcmRlclR5cGU6IFt7XHJcbiAgICAgICAgICBuYW1lOiAn5YWo6YOoJyxcclxuICAgICAgICAgIG9yZGVyU3RhdGU6ICcwJyxcclxuICAgICAgICAgIGljb246ICdjdUljb24tYXBwcydcclxuICAgICAgICB9LCB7XHJcbiAgICAgICAgICBuYW1lOiAn5b6F5LuY5qy+JyxcclxuICAgICAgICAgIG9yZGVyU3RhdGU6ICcxJyxcclxuICAgICAgICAgIGljb246ICdjdUljb24tcGF5J1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgbmFtZTogJ+W+heWPguWKoCcsXHJcbiAgICAgICAgICBvcmRlclN0YXRlOiAnMicsXHJcbiAgICAgICAgICBpY29uOiAnY3VJY29uLWFjdGl2aXR5J1xyXG4gICAgICAgIH0sIHtcclxuICAgICAgICAgIG5hbWU6ICflt7LlrozmiJAnLFxyXG4gICAgICAgICAgb3JkZXJTdGF0ZTogJzMnLFxyXG4gICAgICAgICAgaWNvbjogJ2N1SWNvbi1jb21tZW50J1xyXG4gICAgICAgIH1cclxuICAgICAgXSxcclxuICAgICAgbXlJbmZvOiB7fVxyXG4gICAgfTtcclxuICAgIGFzeW5jIG9uU2hvdygpIHtcclxuICAgICAgbGV0IHJlcyA9IGF3YWl0IGNvbmZpZy5jZW50ZXIoKVxyXG4gICAgICB0aGlzLm15SW5mbyA9IHJlc1xyXG4gICAgICAvLyB0aGlzLm15SW5mby5tZW1iZXJUeXBlSWQgPSAyXHJcbiAgICAgIC8vIOWIt+aWsOaIkeeahOi1hOS6p1xyXG4gICAgICB0aGlzLm15QXNzZXRzKClcclxuICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgfVxyXG4gICAgbXlBc3NldHMoKSB7XHJcbiAgICAgIHRoaXMuYXNzZXRzLm1haW5zWzBdLmNvdW50ID0gdGhpcy5teUluZm8ubXlBc3NldHMuY291bnRDb3Vwb25cclxuICAgICAgdGhpcy5hc3NldHMubWFpbnNbMV0uY291bnQgPSB0aGlzLm15SW5mby5teUFzc2V0cy50b3RhbEFtb3VudFxyXG4gICAgICB0aGlzLmFzc2V0cy5tYWluc1syXS5jb3VudCA9IHRoaXMubXlJbmZvLm15QXNzZXRzLmludGVncmFsXHJcbiAgICAgIHRoaXMuYXNzZXRzLnRvdGFsID0gdGhpcy5teUluZm8ubXlBc3NldHMudG90YWxBc3NldHNcclxuICAgIH1cclxuICAgIG1ldGhvZHMgPSB7XHJcbiAgICAgIG5hdmkoZSkge1xyXG4gICAgICAgIGxldCB1cmwgPSBlLmN1cnJlbnRUYXJnZXQuZGF0YXNldC51cmwgfHwgZS50YXJnZXQuZGF0YXNldC51cmxcclxuICAgICAgICBpZiAodXJsKSB7XHJcbiAgICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICB1cmxcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgfSxcclxuICAgICAgYmFyZ2FpbmluZygpIHtcclxuICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgdXJsOiAnLi9iYXJnYWluaW5nJ1xyXG4gICAgICAgIH0pO1xyXG4gICAgICB9LFxyXG4gICAgICBhZ2VudCgpIHtcclxuICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgdXJsOiAnL2FnZW50L3BhZ2VzL2luZGV4J1xyXG4gICAgICAgIH0pO1xyXG4gICAgICB9LFxyXG4gICAgICBwaW50dWFuKCkge1xyXG4gICAgICAgIHdlcHkubmF2aWdhdGVUbyh7XHJcbiAgICAgICAgICB1cmw6ICcuL3BpbnR1YW4nXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0sXHJcbiAgICAgIGNoaWxkcygpIHtcclxuICAgICAgICBpZiAod2VweS5nZXRTdG9yYWdlU3luYygnbW9iaWxlJykpIHtcclxuICAgICAgICAgIHdlcHkubmF2aWdhdGVUbyh7XHJcbiAgICAgICAgICAgIHVybDogJy9wYWdlcy9tZWV0L2NoaWxkcydcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBUaXBzLnRvYXN0KCfpnIDopoHlhYjnu5HlrprmiYvmnLrlj7flk6Z+JywgKCkgPT4ge1xyXG4gICAgICAgICAgICB3ZXB5LnN3aXRjaFRhYih7XHJcbiAgICAgICAgICAgICAgdXJsOiAnL3BhZ2VzL21lZXQvbWVldCdcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICB9LCAnbm9uZScpXHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG4gICAgICB0b09yZGVyKGlkKSB7XHJcbiAgICAgICAgd2VweS5uYXZpZ2F0ZVRvKHtcclxuICAgICAgICAgIHVybDogJy4vb3JkZXJzP2lkPScgKyBpZFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gIH1cclxuIl19