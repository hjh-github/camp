"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

var _WxUtils = require('./../../utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
    _inherits(Dialog, _wepy$page);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
            navigationBarTitleText: "我的砍价"
        }, _this.data = {
            theme: _wepy2.default.$instance.globalData.themeColor,
            orderState: {
                0: '砍价中',
                1: '待付款',
                2: '已完成',
                3: '已过期'
            },
            orderStats: {},
            scrollLeft: 0,
            pageIndex: 1,
            orders: [],
            toload: false,
            isload: true,
            loadmoring: false
        }, _this.methods = {
            tocut: function tocut(e) {
                _wepy2.default.navigateTo({
                    url: '/pages/activity/bargain?regId=' + e.id
                });
            }
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(Dialog, [{
        key: "onLoad",
        value: function () {
            var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(opt) {
                return regeneratorRuntime.wrap(function _callee$(_context) {
                    while (1) {
                        switch (_context.prev = _context.next) {
                            case 0:
                                _context.next = 2;
                                return this.loadData();

                            case 2:
                                this.isload = false;

                            case 3:
                            case "end":
                                return _context.stop();
                        }
                    }
                }, _callee, this);
            }));

            function onLoad(_x) {
                return _ref2.apply(this, arguments);
            }

            return onLoad;
        }()
    }, {
        key: "loadData",
        value: function () {
            var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(pageIndex) {
                var params, res, ordersList;
                return regeneratorRuntime.wrap(function _callee2$(_context2) {
                    while (1) {
                        switch (_context2.prev = _context2.next) {
                            case 0:
                                params = {
                                    pageIndex: pageIndex || this.pageIndex,
                                    pageSize: 10
                                };
                                _context2.next = 3;
                                return _config2.default.bargains(params);

                            case 3:
                                res = _context2.sent;

                                if (!(res.errcode == 200)) {
                                    _context2.next = 19;
                                    break;
                                }

                                ordersList = res.data.reg;

                                if (ordersList.length) {
                                    _context2.next = 15;
                                    break;
                                }

                                if (pageIndex == 1) {
                                    this.orders = ordersList;
                                }
                                this.pageIndex = pageIndex;
                                this.toload = true;
                                this.loadmoring = true;
                                this.$apply();
                                return _context2.abrupt("return", false);

                            case 15:
                                if (pageIndex > 1) this.pageIndex = pageIndex;
                                if (pageIndex == 1) {
                                    this.orders = ordersList;
                                } else {
                                    this.orders = this.orders.concat(ordersList);
                                }
                                this.loadmoring = false;

                            case 18:
                                this.$apply();

                            case 19:
                            case "end":
                                return _context2.stop();
                        }
                    }
                }, _callee2, this);
            }));

            function loadData(_x2) {
                return _ref3.apply(this, arguments);
            }

            return loadData;
        }()
    }, {
        key: "onShareAppMessage",
        value: function onShareAppMessage(res) {
            var id = '';
            if (res.from === 'button') {
                // 来自页面内转发按钮
                console.log(res.target);
                id = res.target.dataset.id;
            }
            return {
                title: '我发现了一件好货，来一起砍价优惠购！',
                path: '/pages/activity/bargain?regId=' + id
            };
        }
    }, {
        key: "onReachBottom",
        value: function () {
            var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
                return regeneratorRuntime.wrap(function _callee3$(_context3) {
                    while (1) {
                        switch (_context3.prev = _context3.next) {
                            case 0:
                                _context3.next = 2;
                                return this.getMore();

                            case 2:
                            case "end":
                                return _context3.stop();
                        }
                    }
                }, _callee3, this);
            }));

            function onReachBottom() {
                return _ref4.apply(this, arguments);
            }

            return onReachBottom;
        }()
    }, {
        key: "getMore",
        value: function () {
            var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
                return regeneratorRuntime.wrap(function _callee4$(_context4) {
                    while (1) {
                        switch (_context4.prev = _context4.next) {
                            case 0:
                                if (!this.loadmoring) {
                                    _context4.next = 2;
                                    break;
                                }

                                return _context4.abrupt("return", false);

                            case 2:
                                this.loadmoring = true;
                                this.toload = false;
                                _context4.next = 6;
                                return this.loadData(this.pageIndex + 1);

                            case 6:
                                this.$apply();

                            case 7:
                            case "end":
                                return _context4.stop();
                        }
                    }
                }, _callee4, this);
            }));

            function getMore() {
                return _ref5.apply(this, arguments);
            }

            return getMore;
        }()
    }]);

    return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/my/bargaining'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImJhcmdhaW5pbmcuanMiXSwibmFtZXMiOlsiRGlhbG9nIiwiY29uZmlnIiwibmF2aWdhdGlvbkJhclRpdGxlVGV4dCIsImRhdGEiLCJ0aGVtZSIsIndlcHkiLCIkaW5zdGFuY2UiLCJnbG9iYWxEYXRhIiwidGhlbWVDb2xvciIsIm9yZGVyU3RhdGUiLCJvcmRlclN0YXRzIiwic2Nyb2xsTGVmdCIsInBhZ2VJbmRleCIsIm9yZGVycyIsInRvbG9hZCIsImlzbG9hZCIsImxvYWRtb3JpbmciLCJtZXRob2RzIiwidG9jdXQiLCJlIiwibmF2aWdhdGVUbyIsInVybCIsImlkIiwib3B0IiwibG9hZERhdGEiLCJwYXJhbXMiLCJwYWdlU2l6ZSIsImJhcmdhaW5zIiwicmVzIiwiZXJyY29kZSIsIm9yZGVyc0xpc3QiLCJyZWciLCJsZW5ndGgiLCIkYXBwbHkiLCJjb25jYXQiLCJmcm9tIiwiY29uc29sZSIsImxvZyIsInRhcmdldCIsImRhdGFzZXQiLCJ0aXRsZSIsInBhdGgiLCJnZXRNb3JlIiwicGFnZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQ0k7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7Ozs7Ozs7Ozs7O0lBQ3FCQSxNOzs7Ozs7Ozs7Ozs7OzswTEFDakJDLE0sR0FBUztBQUNMQyxvQ0FBd0I7QUFEbkIsUyxRQUdUQyxJLEdBQU87QUFDSEMsbUJBQU9DLGVBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQkMsVUFEOUI7QUFFSEMsd0JBQVk7QUFDUixtQkFBRyxLQURLO0FBRVIsbUJBQUcsS0FGSztBQUdSLG1CQUFHLEtBSEs7QUFJUixtQkFBRztBQUpLLGFBRlQ7QUFRSEMsd0JBQVksRUFSVDtBQVNIQyx3QkFBWSxDQVRUO0FBVUhDLHVCQUFXLENBVlI7QUFXSEMsb0JBQVEsRUFYTDtBQVlIQyxvQkFBUSxLQVpMO0FBYUhDLG9CQUFRLElBYkw7QUFjSEMsd0JBQVk7QUFkVCxTLFFBeUVQQyxPLEdBQVU7QUFDTkMsaUJBRE0saUJBQ0FDLENBREEsRUFDRTtBQUNKZCwrQkFBS2UsVUFBTCxDQUFnQjtBQUNaQyx5QkFBSyxtQ0FBbUNGLEVBQUVHO0FBRDlCLGlCQUFoQjtBQUdIO0FBTEssUzs7Ozs7O2lHQXpER0MsRzs7Ozs7O3VDQUNILEtBQUtDLFFBQUwsRTs7O0FBQ04scUNBQUtULE1BQUwsR0FBYyxLQUFkOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O2tHQUVXSCxTOzs7Ozs7QUFDUGEsc0MsR0FBUztBQUNUYiwrQ0FBV0EsYUFBYSxLQUFLQSxTQURwQjtBQUVUYyw4Q0FBVTtBQUZELGlDOzt1Q0FJR3pCLGlCQUFPMEIsUUFBUCxDQUFnQkYsTUFBaEIsQzs7O0FBQVpHLG1DOztzQ0FDQUEsSUFBSUMsT0FBSixJQUFlLEc7Ozs7O0FBQ1hDLDBDLEdBQWFGLElBQUl6QixJQUFKLENBQVM0QixHOztvQ0FDckJELFdBQVdFLE07Ozs7O0FBQ1osb0NBQUlwQixhQUFhLENBQWpCLEVBQW9CO0FBQ2hCLHlDQUFLQyxNQUFMLEdBQWNpQixVQUFkO0FBQ0g7QUFDRCxxQ0FBS2xCLFNBQUwsR0FBaUJBLFNBQWpCO0FBQ0EscUNBQUtFLE1BQUwsR0FBYyxJQUFkO0FBQ0EscUNBQUtFLFVBQUwsR0FBa0IsSUFBbEI7QUFDQSxxQ0FBS2lCLE1BQUw7a0VBQ08sSzs7O0FBRVAsb0NBQUlyQixZQUFZLENBQWhCLEVBQW1CLEtBQUtBLFNBQUwsR0FBaUJBLFNBQWpCO0FBQ25CLG9DQUFJQSxhQUFhLENBQWpCLEVBQW9CO0FBQ2hCLHlDQUFLQyxNQUFMLEdBQWNpQixVQUFkO0FBQ0gsaUNBRkQsTUFFTztBQUNILHlDQUFLakIsTUFBTCxHQUFjLEtBQUtBLE1BQUwsQ0FBWXFCLE1BQVosQ0FBbUJKLFVBQW5CLENBQWQ7QUFDSDtBQUNELHFDQUFLZCxVQUFMLEdBQWtCLEtBQWxCOzs7QUFFSixxQ0FBS2lCLE1BQUw7Ozs7Ozs7Ozs7Ozs7Ozs7OzswQ0FHVUwsRyxFQUFLO0FBQ25CLGdCQUFJTixLQUFLLEVBQVQ7QUFDQSxnQkFBSU0sSUFBSU8sSUFBSixLQUFhLFFBQWpCLEVBQTJCO0FBQ3ZCO0FBQ0FDLHdCQUFRQyxHQUFSLENBQVlULElBQUlVLE1BQWhCO0FBQ0FoQixxQkFBS00sSUFBSVUsTUFBSixDQUFXQyxPQUFYLENBQW1CakIsRUFBeEI7QUFDSDtBQUNELG1CQUFPO0FBQ0hrQix1QkFBTyxvQkFESjtBQUVIQyxzQkFBTSxtQ0FBbUNuQjtBQUZ0QyxhQUFQO0FBSUg7Ozs7Ozs7Ozs7dUNBRVMsS0FBS29CLE9BQUwsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3FDQUdGLEtBQUsxQixVOzs7OztrRUFDRSxLOzs7QUFFWCxxQ0FBS0EsVUFBTCxHQUFrQixJQUFsQjtBQUNBLHFDQUFLRixNQUFMLEdBQWMsS0FBZDs7dUNBQ00sS0FBS1UsUUFBTCxDQUFjLEtBQUtaLFNBQUwsR0FBaUIsQ0FBL0IsQzs7O0FBQ04scUNBQUtxQixNQUFMOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBM0U0QjVCLGVBQUtzQyxJOztrQkFBcEIzQyxNIiwiZmlsZSI6ImJhcmdhaW5pbmcuanMiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuICAgIGltcG9ydCB3ZXB5IGZyb20gXCJ3ZXB5XCJcclxuICAgIGltcG9ydCBjb25maWcgZnJvbSBcIkAvYXBpL2NvbmZpZ1wiXHJcbiAgICBpbXBvcnQgVGlwcyBmcm9tIFwiQC91dGlscy9UaXBzXCJcclxuICAgIGltcG9ydCBXeFV0aWxzIGZyb20gXCJAL3V0aWxzL1d4VXRpbHNcIlxyXG4gICAgZXhwb3J0IGRlZmF1bHQgY2xhc3MgRGlhbG9nIGV4dGVuZHMgd2VweS5wYWdlIHtcclxuICAgICAgICBjb25maWcgPSB7XHJcbiAgICAgICAgICAgIG5hdmlnYXRpb25CYXJUaXRsZVRleHQ6IFwi5oiR55qE56CN5Lu3XCJcclxuICAgICAgICB9O1xyXG4gICAgICAgIGRhdGEgPSB7XHJcbiAgICAgICAgICAgIHRoZW1lOiB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnRoZW1lQ29sb3IsXHJcbiAgICAgICAgICAgIG9yZGVyU3RhdGU6IHtcclxuICAgICAgICAgICAgICAgIDA6ICfnoI3ku7fkuK0nLFxyXG4gICAgICAgICAgICAgICAgMTogJ+W+heS7mOasvicsXHJcbiAgICAgICAgICAgICAgICAyOiAn5bey5a6M5oiQJyxcclxuICAgICAgICAgICAgICAgIDM6ICflt7Lov4fmnJ8nXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIG9yZGVyU3RhdHM6IHt9LFxyXG4gICAgICAgICAgICBzY3JvbGxMZWZ0OiAwLFxyXG4gICAgICAgICAgICBwYWdlSW5kZXg6IDEsXHJcbiAgICAgICAgICAgIG9yZGVyczogW10sXHJcbiAgICAgICAgICAgIHRvbG9hZDogZmFsc2UsXHJcbiAgICAgICAgICAgIGlzbG9hZDogdHJ1ZSxcclxuICAgICAgICAgICAgbG9hZG1vcmluZzogZmFsc2UsXHJcbiAgICAgICAgfTtcclxuICAgICAgICBhc3luYyBvbkxvYWQob3B0KSB7XHJcbiAgICAgICAgICAgIGF3YWl0IHRoaXMubG9hZERhdGEoKVxyXG4gICAgICAgICAgICB0aGlzLmlzbG9hZCA9IGZhbHNlXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGFzeW5jIGxvYWREYXRhKHBhZ2VJbmRleCkge1xyXG4gICAgICAgICAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICAgICAgICAgICAgcGFnZUluZGV4OiBwYWdlSW5kZXggfHwgdGhpcy5wYWdlSW5kZXgsXHJcbiAgICAgICAgICAgICAgICBwYWdlU2l6ZTogMTBcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBsZXQgcmVzID0gYXdhaXQgY29uZmlnLmJhcmdhaW5zKHBhcmFtcylcclxuICAgICAgICAgICAgaWYgKHJlcy5lcnJjb2RlID09IDIwMCkge1xyXG4gICAgICAgICAgICAgICAgbGV0IG9yZGVyc0xpc3QgPSByZXMuZGF0YS5yZWdcclxuICAgICAgICAgICAgICAgIGlmICghb3JkZXJzTGlzdC5sZW5ndGgpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAocGFnZUluZGV4ID09IDEpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5vcmRlcnMgPSBvcmRlcnNMaXN0XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMucGFnZUluZGV4ID0gcGFnZUluZGV4XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy50b2xvYWQgPSB0cnVlXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5sb2FkbW9yaW5nID0gdHJ1ZVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHBhZ2VJbmRleCA+IDEpIHRoaXMucGFnZUluZGV4ID0gcGFnZUluZGV4XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHBhZ2VJbmRleCA9PSAxKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMub3JkZXJzID0gb3JkZXJzTGlzdFxyXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMub3JkZXJzID0gdGhpcy5vcmRlcnMuY29uY2F0KG9yZGVyc0xpc3QpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubG9hZG1vcmluZyA9IGZhbHNlXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgb25TaGFyZUFwcE1lc3NhZ2UocmVzKSB7XHJcbiAgICAgICAgICAgIGxldCBpZCA9ICcnXHJcbiAgICAgICAgICAgIGlmIChyZXMuZnJvbSA9PT0gJ2J1dHRvbicpIHtcclxuICAgICAgICAgICAgICAgIC8vIOadpeiHqumhtemdouWGhei9rOWPkeaMiemSrlxyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2cocmVzLnRhcmdldClcclxuICAgICAgICAgICAgICAgIGlkID0gcmVzLnRhcmdldC5kYXRhc2V0LmlkXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgIHRpdGxlOiAn5oiR5Y+R546w5LqG5LiA5Lu25aW96LSn77yM5p2l5LiA6LW356CN5Lu35LyY5oOg6LSt77yBJyxcclxuICAgICAgICAgICAgICAgIHBhdGg6ICcvcGFnZXMvYWN0aXZpdHkvYmFyZ2Fpbj9yZWdJZD0nICsgaWRcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBhc3luYyBvblJlYWNoQm90dG9tKCkge1xyXG4gICAgICAgICAgICBhd2FpdCB0aGlzLmdldE1vcmUoKVxyXG4gICAgICAgIH1cclxuICAgICAgICBhc3luYyBnZXRNb3JlKCkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5sb2FkbW9yaW5nKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0aGlzLmxvYWRtb3JpbmcgPSB0cnVlXHJcbiAgICAgICAgICAgIHRoaXMudG9sb2FkID0gZmFsc2VcclxuICAgICAgICAgICAgYXdhaXQgdGhpcy5sb2FkRGF0YSh0aGlzLnBhZ2VJbmRleCArIDEpXHJcbiAgICAgICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgICB9XHJcbiAgICAgICAgbWV0aG9kcyA9IHtcclxuICAgICAgICAgICAgdG9jdXQoZSl7XHJcbiAgICAgICAgICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICAgICAgICAgIHVybDogJy9wYWdlcy9hY3Rpdml0eS9iYXJnYWluP3JlZ0lkPScgKyBlLmlkXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH07XHJcbiAgICB9XHJcbiJdfQ==