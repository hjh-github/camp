"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

var _WxUtils = require('./../../utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
    _inherits(Dialog, _wepy$page);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
            navigationBarTitleText: "我的拼团"
        }, _this.data = {
            theme: _wepy2.default.$instance.globalData.themeColor,
            orderState: {
                0: '拼团取消',
                1: '进行中',
                2: '拼团成功',
                3: '拼图失败'
            },
            orderStats: {},
            scrollLeft: 0,
            pageIndex: 1,
            orders: [],
            toload: false,
            isload: true,
            loadmoring: false
        }, _this.methods = {
            todetaile: function todetaile(id) {
                _wepy2.default.navigateTo({
                    url: '/pages/activity/pintuan?id=' + id
                });
            }
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(Dialog, [{
        key: "onLoad",
        value: function () {
            var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(opt) {
                return regeneratorRuntime.wrap(function _callee$(_context) {
                    while (1) {
                        switch (_context.prev = _context.next) {
                            case 0:
                                _context.next = 2;
                                return this.loadData();

                            case 2:
                                this.isload = false;

                            case 3:
                            case "end":
                                return _context.stop();
                        }
                    }
                }, _callee, this);
            }));

            function onLoad(_x) {
                return _ref2.apply(this, arguments);
            }

            return onLoad;
        }()
    }, {
        key: "loadData",
        value: function () {
            var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(pageIndex) {
                var params, res, ordersList;
                return regeneratorRuntime.wrap(function _callee2$(_context2) {
                    while (1) {
                        switch (_context2.prev = _context2.next) {
                            case 0:
                                params = {
                                    pageIndex: pageIndex || this.pageIndex,
                                    pageSize: 10
                                };
                                _context2.next = 3;
                                return _config2.default.pintuans(params);

                            case 3:
                                res = _context2.sent;

                                if (!(res.errcode == 200)) {
                                    _context2.next = 19;
                                    break;
                                }

                                ordersList = res.data.pintuan;

                                if (ordersList.length) {
                                    _context2.next = 15;
                                    break;
                                }

                                if (pageIndex == 1) {
                                    this.orders = ordersList;
                                }
                                this.pageIndex = pageIndex;
                                this.toload = true;
                                this.loadmoring = true;
                                this.$apply();
                                return _context2.abrupt("return", false);

                            case 15:
                                if (pageIndex > 1) this.pageIndex = pageIndex;
                                if (pageIndex == 1) {
                                    this.orders = ordersList;
                                } else {
                                    this.orders = this.orders.concat(ordersList);
                                }
                                this.loadmoring = false;

                            case 18:
                                this.$apply();

                            case 19:
                            case "end":
                                return _context2.stop();
                        }
                    }
                }, _callee2, this);
            }));

            function loadData(_x2) {
                return _ref3.apply(this, arguments);
            }

            return loadData;
        }()
    }, {
        key: "onShareAppMessage",
        value: function onShareAppMessage(res) {
            var params = {
                title: '',
                imageUrl: '',
                path: ''
            };
            if (res.from === 'button') {
                // 来自页面内转发按钮
                console.log(res.target);
                var tar = res.target;
                if (tar.dataset.act == 'pt') {
                    params.title = tar.dataset.title;
                    params.imageUrl = tar.dataset.images;
                    params.path = '/pages/activity/pintuan?id=' + tar.dataset.actid;
                }
            }
            return {
                title: params.title,
                imageUrl: params.imageUrl,
                path: params.path
            };
        }
    }, {
        key: "onReachBottom",
        value: function () {
            var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
                return regeneratorRuntime.wrap(function _callee3$(_context3) {
                    while (1) {
                        switch (_context3.prev = _context3.next) {
                            case 0:
                                _context3.next = 2;
                                return this.getMore();

                            case 2:
                            case "end":
                                return _context3.stop();
                        }
                    }
                }, _callee3, this);
            }));

            function onReachBottom() {
                return _ref4.apply(this, arguments);
            }

            return onReachBottom;
        }()
    }, {
        key: "getMore",
        value: function () {
            var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
                return regeneratorRuntime.wrap(function _callee4$(_context4) {
                    while (1) {
                        switch (_context4.prev = _context4.next) {
                            case 0:
                                if (!this.loadmoring) {
                                    _context4.next = 2;
                                    break;
                                }

                                return _context4.abrupt("return", false);

                            case 2:
                                this.loadmoring = true;
                                this.toload = false;
                                _context4.next = 6;
                                return this.loadData(this.pageIndex + 1);

                            case 6:
                                this.$apply();

                            case 7:
                            case "end":
                                return _context4.stop();
                        }
                    }
                }, _callee4, this);
            }));

            function getMore() {
                return _ref5.apply(this, arguments);
            }

            return getMore;
        }()
    }]);

    return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/my/pintuan'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBpbnR1YW4uanMiXSwibmFtZXMiOlsiRGlhbG9nIiwiY29uZmlnIiwibmF2aWdhdGlvbkJhclRpdGxlVGV4dCIsImRhdGEiLCJ0aGVtZSIsIndlcHkiLCIkaW5zdGFuY2UiLCJnbG9iYWxEYXRhIiwidGhlbWVDb2xvciIsIm9yZGVyU3RhdGUiLCJvcmRlclN0YXRzIiwic2Nyb2xsTGVmdCIsInBhZ2VJbmRleCIsIm9yZGVycyIsInRvbG9hZCIsImlzbG9hZCIsImxvYWRtb3JpbmciLCJtZXRob2RzIiwidG9kZXRhaWxlIiwiaWQiLCJuYXZpZ2F0ZVRvIiwidXJsIiwib3B0IiwibG9hZERhdGEiLCJwYXJhbXMiLCJwYWdlU2l6ZSIsInBpbnR1YW5zIiwicmVzIiwiZXJyY29kZSIsIm9yZGVyc0xpc3QiLCJwaW50dWFuIiwibGVuZ3RoIiwiJGFwcGx5IiwiY29uY2F0IiwidGl0bGUiLCJpbWFnZVVybCIsInBhdGgiLCJmcm9tIiwiY29uc29sZSIsImxvZyIsInRhcmdldCIsInRhciIsImRhdGFzZXQiLCJhY3QiLCJpbWFnZXMiLCJhY3RpZCIsImdldE1vcmUiLCJwYWdlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFDSTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7Ozs7Ozs7Ozs7Ozs7SUFDcUJBLE07Ozs7Ozs7Ozs7Ozs7OzBMQUNqQkMsTSxHQUFTO0FBQ0xDLG9DQUF3QjtBQURuQixTLFFBR1RDLEksR0FBTztBQUNIQyxtQkFBT0MsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCQyxVQUQ5QjtBQUVIQyx3QkFBWTtBQUNSLG1CQUFHLE1BREs7QUFFUixtQkFBRyxLQUZLO0FBR1IsbUJBQUcsTUFISztBQUlSLG1CQUFHO0FBSkssYUFGVDtBQVFIQyx3QkFBWSxFQVJUO0FBU0hDLHdCQUFZLENBVFQ7QUFVSEMsdUJBQVcsQ0FWUjtBQVdIQyxvQkFBUSxFQVhMO0FBWUhDLG9CQUFRLEtBWkw7QUFhSEMsb0JBQVEsSUFiTDtBQWNIQyx3QkFBWTtBQWRULFMsUUFvRlBDLE8sR0FBVTtBQUNOQyxxQkFETSxxQkFDSUMsRUFESixFQUNRO0FBQ1ZkLCtCQUFLZSxVQUFMLENBQWdCO0FBQ1pDLHlCQUFLLGdDQUFnQ0Y7QUFEekIsaUJBQWhCO0FBR0g7QUFMSyxTOzs7Ozs7aUdBcEVHRyxHOzs7Ozs7dUNBQ0gsS0FBS0MsUUFBTCxFOzs7QUFDTixxQ0FBS1IsTUFBTCxHQUFjLEtBQWQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7a0dBRVdILFM7Ozs7OztBQUNQWSxzQyxHQUFTO0FBQ1RaLCtDQUFXQSxhQUFhLEtBQUtBLFNBRHBCO0FBRVRhLDhDQUFVO0FBRkQsaUM7O3VDQUlHeEIsaUJBQU95QixRQUFQLENBQWdCRixNQUFoQixDOzs7QUFBWkcsbUM7O3NDQUNBQSxJQUFJQyxPQUFKLElBQWUsRzs7Ozs7QUFDWEMsMEMsR0FBYUYsSUFBSXhCLElBQUosQ0FBUzJCLE87O29DQUNyQkQsV0FBV0UsTTs7Ozs7QUFDWixvQ0FBSW5CLGFBQWEsQ0FBakIsRUFBb0I7QUFDaEIseUNBQUtDLE1BQUwsR0FBY2dCLFVBQWQ7QUFDSDtBQUNELHFDQUFLakIsU0FBTCxHQUFpQkEsU0FBakI7QUFDQSxxQ0FBS0UsTUFBTCxHQUFjLElBQWQ7QUFDQSxxQ0FBS0UsVUFBTCxHQUFrQixJQUFsQjtBQUNBLHFDQUFLZ0IsTUFBTDtrRUFDTyxLOzs7QUFFUCxvQ0FBSXBCLFlBQVksQ0FBaEIsRUFBbUIsS0FBS0EsU0FBTCxHQUFpQkEsU0FBakI7QUFDbkIsb0NBQUlBLGFBQWEsQ0FBakIsRUFBb0I7QUFDaEIseUNBQUtDLE1BQUwsR0FBY2dCLFVBQWQ7QUFDSCxpQ0FGRCxNQUVPO0FBQ0gseUNBQUtoQixNQUFMLEdBQWMsS0FBS0EsTUFBTCxDQUFZb0IsTUFBWixDQUFtQkosVUFBbkIsQ0FBZDtBQUNIO0FBQ0QscUNBQUtiLFVBQUwsR0FBa0IsS0FBbEI7OztBQUVKLHFDQUFLZ0IsTUFBTDs7Ozs7Ozs7Ozs7Ozs7Ozs7OzBDQUdVTCxHLEVBQUs7QUFDbkIsZ0JBQUlILFNBQVM7QUFDVFUsdUJBQU8sRUFERTtBQUVUQywwQkFBUyxFQUZBO0FBR1RDLHNCQUFNO0FBSEcsYUFBYjtBQUtBLGdCQUFJVCxJQUFJVSxJQUFKLEtBQWEsUUFBakIsRUFBMkI7QUFDdkI7QUFDQUMsd0JBQVFDLEdBQVIsQ0FBWVosSUFBSWEsTUFBaEI7QUFDQSxvQkFBSUMsTUFBTWQsSUFBSWEsTUFBZDtBQUNBLG9CQUFHQyxJQUFJQyxPQUFKLENBQVlDLEdBQVosSUFBbUIsSUFBdEIsRUFBMkI7QUFDdkJuQiwyQkFBT1UsS0FBUCxHQUFlTyxJQUFJQyxPQUFKLENBQVlSLEtBQTNCO0FBQ0FWLDJCQUFPVyxRQUFQLEdBQWtCTSxJQUFJQyxPQUFKLENBQVlFLE1BQTlCO0FBQ0FwQiwyQkFBT1ksSUFBUCxHQUFhLGdDQUFpQ0ssSUFBSUMsT0FBSixDQUFZRyxLQUExRDtBQUNIO0FBRUo7QUFDRCxtQkFBTztBQUNIWCx1QkFBT1YsT0FBT1UsS0FEWDtBQUVIQywwQkFBU1gsT0FBT1csUUFGYjtBQUdIQyxzQkFBS1osT0FBT1k7QUFIVCxhQUFQO0FBS0g7Ozs7Ozs7Ozs7dUNBRVMsS0FBS1UsT0FBTCxFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7cUNBR0YsS0FBSzlCLFU7Ozs7O2tFQUNFLEs7OztBQUVYLHFDQUFLQSxVQUFMLEdBQWtCLElBQWxCO0FBQ0EscUNBQUtGLE1BQUwsR0FBYyxLQUFkOzt1Q0FDTSxLQUFLUyxRQUFMLENBQWMsS0FBS1gsU0FBTCxHQUFpQixDQUEvQixDOzs7QUFDTixxQ0FBS29CLE1BQUw7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUF0RjRCM0IsZUFBSzBDLEk7O2tCQUFwQi9DLE0iLCJmaWxlIjoicGludHVhbi5qcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4gICAgaW1wb3J0IHdlcHkgZnJvbSBcIndlcHlcIlxyXG4gICAgaW1wb3J0IGNvbmZpZyBmcm9tIFwiQC9hcGkvY29uZmlnXCJcclxuICAgIGltcG9ydCBUaXBzIGZyb20gXCJAL3V0aWxzL1RpcHNcIlxyXG4gICAgaW1wb3J0IFd4VXRpbHMgZnJvbSBcIkAvdXRpbHMvV3hVdGlsc1wiXHJcbiAgICBleHBvcnQgZGVmYXVsdCBjbGFzcyBEaWFsb2cgZXh0ZW5kcyB3ZXB5LnBhZ2Uge1xyXG4gICAgICAgIGNvbmZpZyA9IHtcclxuICAgICAgICAgICAgbmF2aWdhdGlvbkJhclRpdGxlVGV4dDogXCLmiJHnmoTmi7zlm6JcIlxyXG4gICAgICAgIH07XHJcbiAgICAgICAgZGF0YSA9IHtcclxuICAgICAgICAgICAgdGhlbWU6IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEudGhlbWVDb2xvcixcclxuICAgICAgICAgICAgb3JkZXJTdGF0ZToge1xyXG4gICAgICAgICAgICAgICAgMDogJ+aLvOWbouWPlua2iCcsXHJcbiAgICAgICAgICAgICAgICAxOiAn6L+b6KGM5LitJyxcclxuICAgICAgICAgICAgICAgIDI6ICfmi7zlm6LmiJDlip8nLFxyXG4gICAgICAgICAgICAgICAgMzogJ+aLvOWbvuWksei0pSdcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgb3JkZXJTdGF0czoge30sXHJcbiAgICAgICAgICAgIHNjcm9sbExlZnQ6IDAsXHJcbiAgICAgICAgICAgIHBhZ2VJbmRleDogMSxcclxuICAgICAgICAgICAgb3JkZXJzOiBbXSxcclxuICAgICAgICAgICAgdG9sb2FkOiBmYWxzZSxcclxuICAgICAgICAgICAgaXNsb2FkOiB0cnVlLFxyXG4gICAgICAgICAgICBsb2FkbW9yaW5nOiBmYWxzZSxcclxuICAgICAgICB9O1xyXG4gICAgICAgIGFzeW5jIG9uTG9hZChvcHQpIHtcclxuICAgICAgICAgICAgYXdhaXQgdGhpcy5sb2FkRGF0YSgpXHJcbiAgICAgICAgICAgIHRoaXMuaXNsb2FkID0gZmFsc2VcclxuICAgICAgICB9XHJcbiAgICAgICAgYXN5bmMgbG9hZERhdGEocGFnZUluZGV4KSB7XHJcbiAgICAgICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgICAgICBwYWdlSW5kZXg6IHBhZ2VJbmRleCB8fCB0aGlzLnBhZ2VJbmRleCxcclxuICAgICAgICAgICAgICAgIHBhZ2VTaXplOiAxMFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGxldCByZXMgPSBhd2FpdCBjb25maWcucGludHVhbnMocGFyYW1zKVxyXG4gICAgICAgICAgICBpZiAocmVzLmVycmNvZGUgPT0gMjAwKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgb3JkZXJzTGlzdCA9IHJlcy5kYXRhLnBpbnR1YW5cclxuICAgICAgICAgICAgICAgIGlmICghb3JkZXJzTGlzdC5sZW5ndGgpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAocGFnZUluZGV4ID09IDEpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5vcmRlcnMgPSBvcmRlcnNMaXN0XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMucGFnZUluZGV4ID0gcGFnZUluZGV4XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy50b2xvYWQgPSB0cnVlXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5sb2FkbW9yaW5nID0gdHJ1ZVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHBhZ2VJbmRleCA+IDEpIHRoaXMucGFnZUluZGV4ID0gcGFnZUluZGV4XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHBhZ2VJbmRleCA9PSAxKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMub3JkZXJzID0gb3JkZXJzTGlzdFxyXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMub3JkZXJzID0gdGhpcy5vcmRlcnMuY29uY2F0KG9yZGVyc0xpc3QpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubG9hZG1vcmluZyA9IGZhbHNlXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgb25TaGFyZUFwcE1lc3NhZ2UocmVzKSB7XHJcbiAgICAgICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgICAgICB0aXRsZTogJycsXHJcbiAgICAgICAgICAgICAgICBpbWFnZVVybDonJyxcclxuICAgICAgICAgICAgICAgIHBhdGg6ICcnXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKHJlcy5mcm9tID09PSAnYnV0dG9uJykge1xyXG4gICAgICAgICAgICAgICAgLy8g5p2l6Ieq6aG16Z2i5YaF6L2s5Y+R5oyJ6ZKuXHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhyZXMudGFyZ2V0KVxyXG4gICAgICAgICAgICAgICAgbGV0IHRhciA9IHJlcy50YXJnZXRcclxuICAgICAgICAgICAgICAgIGlmKHRhci5kYXRhc2V0LmFjdCA9PSAncHQnKXtcclxuICAgICAgICAgICAgICAgICAgICBwYXJhbXMudGl0bGUgPSB0YXIuZGF0YXNldC50aXRsZVxyXG4gICAgICAgICAgICAgICAgICAgIHBhcmFtcy5pbWFnZVVybCA9IHRhci5kYXRhc2V0LmltYWdlc1xyXG4gICAgICAgICAgICAgICAgICAgIHBhcmFtcy5wYXRoID0nL3BhZ2VzL2FjdGl2aXR5L3BpbnR1YW4/aWQ9JyArICB0YXIuZGF0YXNldC5hY3RpZFxyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgdGl0bGU6IHBhcmFtcy50aXRsZSxcclxuICAgICAgICAgICAgICAgIGltYWdlVXJsOnBhcmFtcy5pbWFnZVVybCxcclxuICAgICAgICAgICAgICAgIHBhdGg6cGFyYW1zLnBhdGhcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBhc3luYyBvblJlYWNoQm90dG9tKCkge1xyXG4gICAgICAgICAgICBhd2FpdCB0aGlzLmdldE1vcmUoKVxyXG4gICAgICAgIH1cclxuICAgICAgICBhc3luYyBnZXRNb3JlKCkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5sb2FkbW9yaW5nKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0aGlzLmxvYWRtb3JpbmcgPSB0cnVlXHJcbiAgICAgICAgICAgIHRoaXMudG9sb2FkID0gZmFsc2VcclxuICAgICAgICAgICAgYXdhaXQgdGhpcy5sb2FkRGF0YSh0aGlzLnBhZ2VJbmRleCArIDEpXHJcbiAgICAgICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgICB9XHJcbiAgICAgICAgbWV0aG9kcyA9IHtcclxuICAgICAgICAgICAgdG9kZXRhaWxlKGlkKSB7XHJcbiAgICAgICAgICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICAgICAgICAgIHVybDogJy9wYWdlcy9hY3Rpdml0eS9waW50dWFuP2lkPScgKyBpZCBcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgIH07XHJcbiAgICB9XHJcbiJdfQ==