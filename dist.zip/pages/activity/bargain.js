"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

var _Lang = require('./../../utils/Lang.js');

var _Lang2 = _interopRequireDefault(_Lang);

var _utils = require('./../../store/utils.js');

var _utils2 = _interopRequireDefault(_utils);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
    _inherits(Dialog, _wepy$page);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.data = {
            close: "/static/images/close.png",
            active: true,
            routes: 0,
            regId: '',
            courseInfo: {},
            ActBargainReg: {
                invalidTime: ''
            },
            bargainRecords: [],
            dj: 3000,
            percent: 0,
            info: {},
            modalName: '',
            status: {
                0: {
                    a: '砍价中',
                    b: ''
                },
                1: {
                    a: '砍价完成',
                    b: '待支付'
                },
                2: {
                    a: '砍价完成',
                    b: '已支付'
                },
                3: {
                    a: '已过期',
                    b: '砍价失败'
                }
            }
        }, _this.config = {
            navigationBarBackgroundColor: '#ed1c24',
            navigationBarTitleText: '砍价',
            "usingComponents": {
                "l-countdown": "../../components/countdown/index"
            }
        }, _this.computed = {
            cutPrice: function cutPrice() {
                if (this.ActBargainReg) {
                    var act = this.ActBargainReg;
                    var _p = _Lang2.default.sum([act.coursePrice, -act.courseNewPrice], 2),
                        _sp = _Lang2.default.sum([act.coursePrice, 0], 2);
                    this.percent = parseInt(_p / _sp * 100);
                    return _p;
                }
            }
        }, _this.methods = {
            hideModal: function hideModal() {
                this.modalName = '';
            },
            createImg: function () {
                var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(e) {
                    return regeneratorRuntime.wrap(function _callee$(_context) {
                        while (1) {
                            switch (_context.prev = _context.next) {
                                case 0:
                                    if (!(e.detail.errMsg == "getUserInfo:ok")) {
                                        _context.next = 5;
                                        break;
                                    }

                                    _context.next = 3;
                                    return _auth2.default.getUserinfo(e.detail);

                                case 3:
                                    _utils2.default.save('shareInfo', {
                                        course: this.courseInfo,
                                        path: 'pages/activity/bargain',
                                        id: this.ActBargainReg.id
                                    });
                                    _wepy2.default.navigateTo({
                                        url: '/pages/home/share'
                                    });

                                case 5:
                                case "end":
                                    return _context.stop();
                            }
                        }
                    }, _callee, this);
                }));

                function createImg(_x) {
                    return _ref2.apply(this, arguments);
                }

                return createImg;
            }(),
            toshare: function toshare() {
                this.modalName = 'share';
            },
            tocut: function tocut() {
                _wepy2.default.navigateTo({
                    url: "/pages/detaile/detaile?id=" + this.courseInfo.id
                });
            },
            buy: function buy() {
                _wepy2.default.navigateTo({
                    url: "/pages/detaile/sureOrder?type=2&pid=" + this.info.reg.periodId + "&cid=" + this.info.reg.courseId + "&num=1&aid=" + this.info.regId + "&actpid=0"
                });
            },
            topay: function topay() {
                _wepy2.default.navigateTo({
                    url: "/pages/my/order?id=" + this.info.orderId
                });
            },
            onGotUserInfo: function () {
                var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(e) {
                    return regeneratorRuntime.wrap(function _callee2$(_context2) {
                        while (1) {
                            switch (_context2.prev = _context2.next) {
                                case 0:
                                    if (!(e.detail.errMsg == "getUserInfo:ok")) {
                                        _context2.next = 8;
                                        break;
                                    }

                                    _context2.next = 3;
                                    return _auth2.default.getUserinfo(e.detail);

                                case 3:
                                    _context2.next = 5;
                                    return this.helpBargain();

                                case 5:
                                    _context2.next = 7;
                                    return this.load();

                                case 7:
                                    this.$apply();

                                case 8:
                                case "end":
                                    return _context2.stop();
                            }
                        }
                    }, _callee2, this);
                }));

                function onGotUserInfo(_x2) {
                    return _ref3.apply(this, arguments);
                }

                return onGotUserInfo;
            }()
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(Dialog, [{
        key: "onShareAppMessage",
        value: function onShareAppMessage(res) {
            if (res.from === 'button') {
                // 来自页面内转发按钮
                // console.log(res.target)
            }
            return {
                title: this.courseInfo.courseTittle,
                imageUrl: this.courseInfo.image,
                path: '/pages/activity/bargain?id=' + this.ActBargainReg.id
            };
        }
    }, {
        key: "onLoad",
        value: function () {
            var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(opt) {
                return regeneratorRuntime.wrap(function _callee3$(_context3) {
                    while (1) {
                        switch (_context3.prev = _context3.next) {
                            case 0:
                                console.log(opt);
                                this.regId = opt.id || opt.scene;
                                this.routes = getCurrentPages();
                                _context3.next = 5;
                                return _auth2.default.login();

                            case 5:
                                _context3.next = 7;
                                return this.load();

                            case 7:
                                this.$apply();

                            case 8:
                            case "end":
                                return _context3.stop();
                        }
                    }
                }, _callee3, this);
            }));

            function onLoad(_x3) {
                return _ref4.apply(this, arguments);
            }

            return onLoad;
        }()
    }, {
        key: "helpBargain",
        value: function () {
            var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
                var res;
                return regeneratorRuntime.wrap(function _callee4$(_context4) {
                    while (1) {
                        switch (_context4.prev = _context4.next) {
                            case 0:
                                _context4.next = 2;
                                return _config2.default.helpBargain(this.regId);

                            case 2:
                                res = _context4.sent;

                            case 3:
                            case "end":
                                return _context4.stop();
                        }
                    }
                }, _callee4, this);
            }));

            function helpBargain() {
                return _ref5.apply(this, arguments);
            }

            return helpBargain;
        }()
    }, {
        key: "load",
        value: function () {
            var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
                var _ref7, errcode, data;

                return regeneratorRuntime.wrap(function _callee5$(_context5) {
                    while (1) {
                        switch (_context5.prev = _context5.next) {
                            case 0:
                                _context5.next = 2;
                                return _config2.default.toCutDetai(this.regId);

                            case 2:
                                _ref7 = _context5.sent;
                                errcode = _ref7.errcode;
                                data = _ref7.data;

                                if (errcode == 200) {
                                    this.info = data;
                                    this.courseInfo = data.courseInfo;
                                    this.ActBargainReg = data.reg;
                                    console.log(this.ActBargainReg.invalidTime);
                                    this.bargainRecords = data.bargainRecords;
                                }

                            case 6:
                            case "end":
                                return _context5.stop();
                        }
                    }
                }, _callee5, this);
            }));

            function load() {
                return _ref6.apply(this, arguments);
            }

            return load;
        }()
    }]);

    return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/activity/bargain'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImJhcmdhaW4uanMiXSwibmFtZXMiOlsiRGlhbG9nIiwiZGF0YSIsImNsb3NlIiwiYWN0aXZlIiwicm91dGVzIiwicmVnSWQiLCJjb3Vyc2VJbmZvIiwiQWN0QmFyZ2FpblJlZyIsImludmFsaWRUaW1lIiwiYmFyZ2FpblJlY29yZHMiLCJkaiIsInBlcmNlbnQiLCJpbmZvIiwibW9kYWxOYW1lIiwic3RhdHVzIiwiYSIsImIiLCJjb25maWciLCJuYXZpZ2F0aW9uQmFyQmFja2dyb3VuZENvbG9yIiwibmF2aWdhdGlvbkJhclRpdGxlVGV4dCIsImNvbXB1dGVkIiwiY3V0UHJpY2UiLCJhY3QiLCJfcCIsIkxhbmciLCJzdW0iLCJjb3Vyc2VQcmljZSIsImNvdXJzZU5ld1ByaWNlIiwiX3NwIiwicGFyc2VJbnQiLCJtZXRob2RzIiwiaGlkZU1vZGFsIiwiY3JlYXRlSW1nIiwiZSIsImRldGFpbCIsImVyck1zZyIsImF1dGgiLCJnZXRVc2VyaW5mbyIsInN0b3JlIiwic2F2ZSIsImNvdXJzZSIsInBhdGgiLCJpZCIsIndlcHkiLCJuYXZpZ2F0ZVRvIiwidXJsIiwidG9zaGFyZSIsInRvY3V0IiwiYnV5IiwicmVnIiwicGVyaW9kSWQiLCJjb3Vyc2VJZCIsInRvcGF5Iiwib3JkZXJJZCIsIm9uR290VXNlckluZm8iLCJoZWxwQmFyZ2FpbiIsImxvYWQiLCIkYXBwbHkiLCJyZXMiLCJmcm9tIiwidGl0bGUiLCJjb3Vyc2VUaXR0bGUiLCJpbWFnZVVybCIsImltYWdlIiwib3B0IiwiY29uc29sZSIsImxvZyIsInNjZW5lIiwiZ2V0Q3VycmVudFBhZ2VzIiwibG9naW4iLCJ0b0N1dERldGFpIiwiZXJyY29kZSIsInBhZ2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUNJOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7Ozs7Ozs7Ozs7O0lBQ3FCQSxNOzs7Ozs7Ozs7Ozs7OzswTEFDakJDLEksR0FBTztBQUNIQyxtQkFBTywwQkFESjtBQUVIQyxvQkFBUSxJQUZMO0FBR0hDLG9CQUFRLENBSEw7QUFJSEMsbUJBQU8sRUFKSjtBQUtIQyx3QkFBWSxFQUxUO0FBTUhDLDJCQUFlO0FBQ1hDLDZCQUFZO0FBREQsYUFOWjtBQVNIQyw0QkFBZ0IsRUFUYjtBQVVIQyxnQkFBSSxJQVZEO0FBV0hDLHFCQUFTLENBWE47QUFZSEMsa0JBQU0sRUFaSDtBQWFIQyx1QkFBVSxFQWJQO0FBY0hDLG9CQUFRO0FBQ0osbUJBQUc7QUFDQ0MsdUJBQUcsS0FESjtBQUVDQyx1QkFBRztBQUZKLGlCQURDO0FBS0osbUJBQUc7QUFDQ0QsdUJBQUcsTUFESjtBQUVDQyx1QkFBRztBQUZKLGlCQUxDO0FBU0osbUJBQUc7QUFDQ0QsdUJBQUcsTUFESjtBQUVDQyx1QkFBRztBQUZKLGlCQVRDO0FBYUosbUJBQUc7QUFDQ0QsdUJBQUcsS0FESjtBQUVDQyx1QkFBRztBQUZKO0FBYkM7QUFkTCxTLFFBaUNQQyxNLEdBQVM7QUFDTEMsMENBQThCLFNBRHpCO0FBRUxDLG9DQUF3QixJQUZuQjtBQUdMLCtCQUFtQjtBQUNmLCtCQUFlO0FBREE7QUFIZCxTLFFBT1RDLFEsR0FBVztBQUNQQyxvQkFETyxzQkFDSTtBQUNQLG9CQUFJLEtBQUtkLGFBQVQsRUFBd0I7QUFDcEIsd0JBQUllLE1BQU0sS0FBS2YsYUFBZjtBQUNBLHdCQUFJZ0IsS0FBS0MsZUFBS0MsR0FBTCxDQUFTLENBQUNILElBQUlJLFdBQUwsRUFBa0IsQ0FBQ0osSUFBSUssY0FBdkIsQ0FBVCxFQUFpRCxDQUFqRCxDQUFUO0FBQUEsd0JBQ0lDLE1BQU1KLGVBQUtDLEdBQUwsQ0FBUyxDQUFDSCxJQUFJSSxXQUFMLEVBQWtCLENBQWxCLENBQVQsRUFBK0IsQ0FBL0IsQ0FEVjtBQUVBLHlCQUFLZixPQUFMLEdBQWVrQixTQUFTTixLQUFLSyxHQUFMLEdBQVcsR0FBcEIsQ0FBZjtBQUNBLDJCQUFPTCxFQUFQO0FBQ0g7QUFDSjtBQVRNLFMsUUE4QlhPLE8sR0FBVTtBQUNOQyxxQkFETSx1QkFDSztBQUNQLHFCQUFLbEIsU0FBTCxHQUFpQixFQUFqQjtBQUNILGFBSEs7QUFJQW1CLHFCQUpBO0FBQUEscUdBSVVDLENBSlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBDQUtFQSxFQUFFQyxNQUFGLENBQVNDLE1BQVQsSUFBbUIsZ0JBTHJCO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUEsMkNBTVFDLGVBQUtDLFdBQUwsQ0FBaUJKLEVBQUVDLE1BQW5CLENBTlI7O0FBQUE7QUFPRUksb0RBQU1DLElBQU4sQ0FBVyxXQUFYLEVBQXdCO0FBQ3BCQyxnREFBUSxLQUFLbEMsVUFETztBQUVwQm1DLDhDQUFNLHdCQUZjO0FBR3BCQyw0Q0FBSSxLQUFLbkMsYUFBTCxDQUFtQm1DO0FBSEgscUNBQXhCO0FBS0FDLG1EQUFLQyxVQUFMLENBQWdCO0FBQ1pDLDZDQUFLO0FBRE8scUNBQWhCOztBQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBaUJOQyxtQkFqQk0scUJBaUJJO0FBQ04scUJBQUtqQyxTQUFMLEdBQWlCLE9BQWpCO0FBQ0gsYUFuQks7QUFvQk5rQyxpQkFwQk0sbUJBb0JFO0FBQ0pKLCtCQUFLQyxVQUFMLENBQWdCO0FBQ1pDLHdEQUFrQyxLQUFLdkMsVUFBTCxDQUFnQm9DO0FBRHRDLGlCQUFoQjtBQUdILGFBeEJLO0FBeUJOTSxlQXpCTSxpQkF5QkE7QUFDRkwsK0JBQUtDLFVBQUwsQ0FBZ0I7QUFDWkMsa0VBQTRDLEtBQUtqQyxJQUFMLENBQVVxQyxHQUFWLENBQWNDLFFBQTFELGFBQTBFLEtBQUt0QyxJQUFMLENBQVVxQyxHQUFWLENBQWNFLFFBQXhGLG1CQUE4RyxLQUFLdkMsSUFBTCxDQUFVUCxLQUF4SDtBQURZLGlCQUFoQjtBQUdILGFBN0JLO0FBOEJOK0MsaUJBOUJNLG1CQThCRTtBQUNKVCwrQkFBS0MsVUFBTCxDQUFnQjtBQUNaQyxpREFBMkIsS0FBS2pDLElBQUwsQ0FBVXlDO0FBRHpCLGlCQUFoQjtBQUdILGFBbENLO0FBbUNBQyx5QkFuQ0E7QUFBQSxzR0FtQ2NyQixDQW5DZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMENBb0NFQSxFQUFFQyxNQUFGLENBQVNDLE1BQVQsSUFBbUIsZ0JBcENyQjtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBLDJDQXFDUUMsZUFBS0MsV0FBTCxDQUFpQkosRUFBRUMsTUFBbkIsQ0FyQ1I7O0FBQUE7QUFBQTtBQUFBLDJDQXNDUSxLQUFLcUIsV0FBTCxFQXRDUjs7QUFBQTtBQUFBO0FBQUEsMkNBdUNRLEtBQUtDLElBQUwsRUF2Q1I7O0FBQUE7QUF3Q0UseUNBQUtDLE1BQUw7O0FBeENGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUEsUzs7Ozs7MENBbkJRQyxHLEVBQUs7QUFDbkIsZ0JBQUlBLElBQUlDLElBQUosS0FBYSxRQUFqQixFQUEyQjtBQUN2QjtBQUNBO0FBQ0g7QUFDRCxtQkFBTztBQUNIQyx1QkFBTyxLQUFLdEQsVUFBTCxDQUFnQnVELFlBRHBCO0FBRUhDLDBCQUFTLEtBQUt4RCxVQUFMLENBQWdCeUQsS0FGdEI7QUFHSHRCLHNCQUFNLGdDQUFnQyxLQUFLbEMsYUFBTCxDQUFtQm1DO0FBSHRELGFBQVA7QUFLSDs7OztrR0FDWXNCLEc7Ozs7O0FBQ1RDLHdDQUFRQyxHQUFSLENBQVlGLEdBQVo7QUFDQSxxQ0FBSzNELEtBQUwsR0FBYTJELElBQUl0QixFQUFKLElBQVVzQixJQUFJRyxLQUEzQjtBQUNBLHFDQUFLL0QsTUFBTCxHQUFjZ0UsaUJBQWQ7O3VDQUNNaEMsZUFBS2lDLEtBQUwsRTs7Ozt1Q0FDQSxLQUFLYixJQUFMLEU7OztBQUNOLHFDQUFLQyxNQUFMOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozt1Q0ErQ2dCeEMsaUJBQU9zQyxXQUFQLENBQW1CLEtBQUtsRCxLQUF4QixDOzs7QUFBWnFELG1DOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7dUNBTU16QyxpQkFBT3FELFVBQVAsQ0FBa0IsS0FBS2pFLEtBQXZCLEM7Ozs7QUFGTmtFLHVDLFNBQUFBLE87QUFDQXRFLG9DLFNBQUFBLEk7O0FBRUosb0NBQUlzRSxXQUFXLEdBQWYsRUFBb0I7QUFDaEIseUNBQUszRCxJQUFMLEdBQVlYLElBQVo7QUFDQSx5Q0FBS0ssVUFBTCxHQUFrQkwsS0FBS0ssVUFBdkI7QUFDQSx5Q0FBS0MsYUFBTCxHQUFxQk4sS0FBS2dELEdBQTFCO0FBQ0FnQiw0Q0FBUUMsR0FBUixDQUFZLEtBQUszRCxhQUFMLENBQW1CQyxXQUEvQjtBQUNBLHlDQUFLQyxjQUFMLEdBQXNCUixLQUFLUSxjQUEzQjtBQUNIOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBakkyQmtDLGVBQUs2QixJOztrQkFBcEJ4RSxNIiwiZmlsZSI6ImJhcmdhaW4uanMiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuICAgIGltcG9ydCB3ZXB5IGZyb20gXCJ3ZXB5XCJcclxuICAgIGltcG9ydCBjb25maWcgZnJvbSBcIkAvYXBpL2NvbmZpZ1wiXHJcbiAgICBpbXBvcnQgYXV0aCBmcm9tIFwiQC9hcGkvYXV0aFwiXHJcbiAgICBpbXBvcnQgTGFuZyBmcm9tIFwiQC91dGlscy9MYW5nXCJcclxuICAgIGltcG9ydCBzdG9yZSBmcm9tIFwiQC9zdG9yZS91dGlsc1wiXHJcbiAgICBleHBvcnQgZGVmYXVsdCBjbGFzcyBEaWFsb2cgZXh0ZW5kcyB3ZXB5LnBhZ2Uge1xyXG4gICAgICAgIGRhdGEgPSB7XHJcbiAgICAgICAgICAgIGNsb3NlOiBcIi9zdGF0aWMvaW1hZ2VzL2Nsb3NlLnBuZ1wiLFxyXG4gICAgICAgICAgICBhY3RpdmU6IHRydWUsXHJcbiAgICAgICAgICAgIHJvdXRlczogMCxcclxuICAgICAgICAgICAgcmVnSWQ6ICcnLFxyXG4gICAgICAgICAgICBjb3Vyc2VJbmZvOiB7fSxcclxuICAgICAgICAgICAgQWN0QmFyZ2FpblJlZzoge1xyXG4gICAgICAgICAgICAgICAgaW52YWxpZFRpbWU6JydcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgYmFyZ2FpblJlY29yZHM6IFtdLFxyXG4gICAgICAgICAgICBkajogMzAwMCxcclxuICAgICAgICAgICAgcGVyY2VudDogMCxcclxuICAgICAgICAgICAgaW5mbzoge30sXHJcbiAgICAgICAgICAgIG1vZGFsTmFtZTonJyxcclxuICAgICAgICAgICAgc3RhdHVzOiB7XHJcbiAgICAgICAgICAgICAgICAwOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgYTogJ+egjeS7t+S4rScsXHJcbiAgICAgICAgICAgICAgICAgICAgYjogJydcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAxOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgYTogJ+egjeS7t+WujOaIkCcsXHJcbiAgICAgICAgICAgICAgICAgICAgYjogJ+W+heaUr+S7mCdcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAyOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgYTogJ+egjeS7t+WujOaIkCcsXHJcbiAgICAgICAgICAgICAgICAgICAgYjogJ+W3suaUr+S7mCdcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAzOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgYTogJ+W3sui/h+acnycsXHJcbiAgICAgICAgICAgICAgICAgICAgYjogJ+egjeS7t+Wksei0pSdcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH07XHJcbiAgICAgICAgY29uZmlnID0ge1xyXG4gICAgICAgICAgICBuYXZpZ2F0aW9uQmFyQmFja2dyb3VuZENvbG9yOiAnI2VkMWMyNCcsXHJcbiAgICAgICAgICAgIG5hdmlnYXRpb25CYXJUaXRsZVRleHQ6ICfnoI3ku7cnLFxyXG4gICAgICAgICAgICBcInVzaW5nQ29tcG9uZW50c1wiOiB7XHJcbiAgICAgICAgICAgICAgICBcImwtY291bnRkb3duXCI6IFwiLi4vLi4vY29tcG9uZW50cy9jb3VudGRvd24vaW5kZXhcIlxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbXB1dGVkID0ge1xyXG4gICAgICAgICAgICBjdXRQcmljZSgpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLkFjdEJhcmdhaW5SZWcpIHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgYWN0ID0gdGhpcy5BY3RCYXJnYWluUmVnXHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IF9wID0gTGFuZy5zdW0oW2FjdC5jb3Vyc2VQcmljZSwgLWFjdC5jb3Vyc2VOZXdQcmljZV0sIDIpLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBfc3AgPSBMYW5nLnN1bShbYWN0LmNvdXJzZVByaWNlLCAwXSwgMilcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnBlcmNlbnQgPSBwYXJzZUludChfcCAvIF9zcCAqIDEwMClcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gX3BcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBvblNoYXJlQXBwTWVzc2FnZShyZXMpIHtcclxuICAgICAgICAgICAgaWYgKHJlcy5mcm9tID09PSAnYnV0dG9uJykge1xyXG4gICAgICAgICAgICAgICAgLy8g5p2l6Ieq6aG16Z2i5YaF6L2s5Y+R5oyJ6ZKuXHJcbiAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhyZXMudGFyZ2V0KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICB0aXRsZTogdGhpcy5jb3Vyc2VJbmZvLmNvdXJzZVRpdHRsZSxcclxuICAgICAgICAgICAgICAgIGltYWdlVXJsOnRoaXMuY291cnNlSW5mby5pbWFnZSxcclxuICAgICAgICAgICAgICAgIHBhdGg6ICcvcGFnZXMvYWN0aXZpdHkvYmFyZ2Fpbj9pZD0nICsgdGhpcy5BY3RCYXJnYWluUmVnLmlkXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgYXN5bmMgb25Mb2FkKG9wdCkge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhvcHQpXHJcbiAgICAgICAgICAgIHRoaXMucmVnSWQgPSBvcHQuaWQgfHwgb3B0LnNjZW5lXHJcbiAgICAgICAgICAgIHRoaXMucm91dGVzID0gZ2V0Q3VycmVudFBhZ2VzKClcclxuICAgICAgICAgICAgYXdhaXQgYXV0aC5sb2dpbigpXHJcbiAgICAgICAgICAgIGF3YWl0IHRoaXMubG9hZCgpXHJcbiAgICAgICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgICB9XHJcbiAgICAgICAgbWV0aG9kcyA9IHtcclxuICAgICAgICAgICAgaGlkZU1vZGFsKCl7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGFsTmFtZSA9ICcnXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGFzeW5jIGNyZWF0ZUltZyhlKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoZS5kZXRhaWwuZXJyTXNnID09IFwiZ2V0VXNlckluZm86b2tcIikge1xyXG4gICAgICAgICAgICAgICAgICAgIGF3YWl0IGF1dGguZ2V0VXNlcmluZm8oZS5kZXRhaWwpXHJcbiAgICAgICAgICAgICAgICAgICAgc3RvcmUuc2F2ZSgnc2hhcmVJbmZvJywge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb3Vyc2U6IHRoaXMuY291cnNlSW5mbyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGF0aDogJ3BhZ2VzL2FjdGl2aXR5L2JhcmdhaW4nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZDogdGhpcy5BY3RCYXJnYWluUmVnLmlkXHJcbiAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB1cmw6ICcvcGFnZXMvaG9tZS9zaGFyZSdcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgdG9zaGFyZSgpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kYWxOYW1lID0gJ3NoYXJlJ1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB0b2N1dCgpIHtcclxuICAgICAgICAgICAgICAgIHdlcHkubmF2aWdhdGVUbyh7XHJcbiAgICAgICAgICAgICAgICAgICAgdXJsOiBgL3BhZ2VzL2RldGFpbGUvZGV0YWlsZT9pZD0ke3RoaXMuY291cnNlSW5mby5pZH1gXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgYnV5KCkge1xyXG4gICAgICAgICAgICAgICAgd2VweS5uYXZpZ2F0ZVRvKHtcclxuICAgICAgICAgICAgICAgICAgICB1cmw6IGAvcGFnZXMvZGV0YWlsZS9zdXJlT3JkZXI/dHlwZT0yJnBpZD0ke3RoaXMuaW5mby5yZWcucGVyaW9kSWR9JmNpZD0ke3RoaXMuaW5mby5yZWcuY291cnNlSWR9Jm51bT0xJmFpZD0ke3RoaXMuaW5mby5yZWdJZH0mYWN0cGlkPTBgXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgdG9wYXkoKSB7XHJcbiAgICAgICAgICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICAgICAgICAgIHVybDogYC9wYWdlcy9teS9vcmRlcj9pZD0ke3RoaXMuaW5mby5vcmRlcklkfWBcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBhc3luYyBvbkdvdFVzZXJJbmZvKGUpIHtcclxuICAgICAgICAgICAgICAgIGlmIChlLmRldGFpbC5lcnJNc2cgPT0gXCJnZXRVc2VySW5mbzpva1wiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYXdhaXQgYXV0aC5nZXRVc2VyaW5mbyhlLmRldGFpbClcclxuICAgICAgICAgICAgICAgICAgICBhd2FpdCB0aGlzLmhlbHBCYXJnYWluKClcclxuICAgICAgICAgICAgICAgICAgICBhd2FpdCB0aGlzLmxvYWQoKVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICB9O1xyXG4gICAgICAgIGFzeW5jIGhlbHBCYXJnYWluKCkge1xyXG4gICAgICAgICAgICBsZXQgcmVzID0gYXdhaXQgY29uZmlnLmhlbHBCYXJnYWluKHRoaXMucmVnSWQpXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGFzeW5jIGxvYWQoKSB7XHJcbiAgICAgICAgICAgIGxldCB7XHJcbiAgICAgICAgICAgICAgICBlcnJjb2RlLFxyXG4gICAgICAgICAgICAgICAgZGF0YVxyXG4gICAgICAgICAgICB9ID0gYXdhaXQgY29uZmlnLnRvQ3V0RGV0YWkodGhpcy5yZWdJZClcclxuICAgICAgICAgICAgaWYgKGVycmNvZGUgPT0gMjAwKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmluZm8gPSBkYXRhXHJcbiAgICAgICAgICAgICAgICB0aGlzLmNvdXJzZUluZm8gPSBkYXRhLmNvdXJzZUluZm9cclxuICAgICAgICAgICAgICAgIHRoaXMuQWN0QmFyZ2FpblJlZyA9IGRhdGEucmVnXHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyh0aGlzLkFjdEJhcmdhaW5SZWcuaW52YWxpZFRpbWUpXHJcbiAgICAgICAgICAgICAgICB0aGlzLmJhcmdhaW5SZWNvcmRzID0gZGF0YS5iYXJnYWluUmVjb3Jkc1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4iXX0=