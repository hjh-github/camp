"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

var _Lang = require('./../../utils/Lang.js');

var _Lang2 = _interopRequireDefault(_Lang);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
    _inherits(Dialog, _wepy$page);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.data = {
            close: "/static/images/close.png",
            active: true,
            routes: 0,
            regId: '',
            courseInfo: {},
            ActBargainReg: null,
            bargainRecords: [],
            dj: 3000,
            percent: 0,
            info: {},
            status: {
                0: {
                    a: '砍价中',
                    b: ''
                },
                1: {
                    a: '砍价完成',
                    b: '待支付'
                },
                2: {
                    a: '砍价完成',
                    b: '已支付'
                },
                3: {
                    a: '已过期',
                    b: '砍价失败'
                }
            }
        }, _this.config = {
            navigationBarBackgroundColor: '#ed1c24',
            navigationBarTitleText: '砍价'
        }, _this.computed = {
            cutPrice: function cutPrice() {
                if (this.ActBargainReg) {
                    var act = this.ActBargainReg;
                    var _p = _Lang2.default.sum([act.coursePrice, -act.courseNewPrice], 2),
                        _sp = _Lang2.default.sum([act.coursePrice, -2000], 2);
                    this.percent = parseInt(_p / _sp * 100);
                    return _p;
                }
            }
        }, _this.methods = {
            tocut: function tocut() {
                _wepy2.default.navigateTo({
                    url: "/pages/detaile/detaile?id=" + this.courseInfo.id
                });
            },
            buy: function buy() {
                _wepy2.default.navigateTo({
                    url: "/pages/detaile/sureOrder?type=2&pid=" + this.info.reg.periodId + "&cid=" + this.info.reg.courseId + "&num=1&aid=" + this.info.regId
                });
            },
            topay: function topay() {
                _wepy2.default.navigateTo({
                    url: "/pages/my/order?id=" + this.info.orderId
                });
            },
            onGotUserInfo: function () {
                var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(e) {
                    return regeneratorRuntime.wrap(function _callee$(_context) {
                        while (1) {
                            switch (_context.prev = _context.next) {
                                case 0:
                                    if (!(e.detail.errMsg == "getUserInfo:ok")) {
                                        _context.next = 8;
                                        break;
                                    }

                                    _context.next = 3;
                                    return _auth2.default.getUserinfo(e.detail);

                                case 3:
                                    _context.next = 5;
                                    return this.helpBargain();

                                case 5:
                                    _context.next = 7;
                                    return this.load();

                                case 7:
                                    this.$apply();

                                case 8:
                                case "end":
                                    return _context.stop();
                            }
                        }
                    }, _callee, this);
                }));

                function onGotUserInfo(_x) {
                    return _ref2.apply(this, arguments);
                }

                return onGotUserInfo;
            }()
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(Dialog, [{
        key: "onShareAppMessage",
        value: function onShareAppMessage(res) {
            if (res.from === 'button') {
                // 来自页面内转发按钮
                // console.log(res.target)
            }
            return {
                title: '我发现了一件好货，来一起砍价优惠购！',
                path: '/pages/activity/bargain?regId=' + this.ActBargainReg.id
            };
        }
    }, {
        key: "onLoad",
        value: function () {
            var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(opt) {
                return regeneratorRuntime.wrap(function _callee2$(_context2) {
                    while (1) {
                        switch (_context2.prev = _context2.next) {
                            case 0:
                                this.regId = opt.regId;
                                this.routes = getCurrentPages();
                                _context2.next = 4;
                                return _auth2.default.login();

                            case 4:
                                _context2.next = 6;
                                return this.load();

                            case 6:
                                this.$apply();

                            case 7:
                            case "end":
                                return _context2.stop();
                        }
                    }
                }, _callee2, this);
            }));

            function onLoad(_x2) {
                return _ref3.apply(this, arguments);
            }

            return onLoad;
        }()
    }, {
        key: "helpBargain",
        value: function () {
            var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
                var res;
                return regeneratorRuntime.wrap(function _callee3$(_context3) {
                    while (1) {
                        switch (_context3.prev = _context3.next) {
                            case 0:
                                _context3.next = 2;
                                return _config2.default.helpBargain(this.regId);

                            case 2:
                                res = _context3.sent;

                            case 3:
                            case "end":
                                return _context3.stop();
                        }
                    }
                }, _callee3, this);
            }));

            function helpBargain() {
                return _ref4.apply(this, arguments);
            }

            return helpBargain;
        }()
    }, {
        key: "load",
        value: function () {
            var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
                var _ref6, errcode, data;

                return regeneratorRuntime.wrap(function _callee4$(_context4) {
                    while (1) {
                        switch (_context4.prev = _context4.next) {
                            case 0:
                                _context4.next = 2;
                                return _config2.default.toCutDetai(this.regId);

                            case 2:
                                _ref6 = _context4.sent;
                                errcode = _ref6.errcode;
                                data = _ref6.data;

                                if (errcode == 200) {
                                    this.info = data;
                                    this.courseInfo = data.courseInfo;
                                    this.ActBargainReg = data.reg;
                                    this.bargainRecords = data.bargainRecords;
                                }

                            case 6:
                            case "end":
                                return _context4.stop();
                        }
                    }
                }, _callee4, this);
            }));

            function load() {
                return _ref5.apply(this, arguments);
            }

            return load;
        }()
    }]);

    return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/activity/bargain'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImJhcmdhaW4uanMiXSwibmFtZXMiOlsiRGlhbG9nIiwiZGF0YSIsImNsb3NlIiwiYWN0aXZlIiwicm91dGVzIiwicmVnSWQiLCJjb3Vyc2VJbmZvIiwiQWN0QmFyZ2FpblJlZyIsImJhcmdhaW5SZWNvcmRzIiwiZGoiLCJwZXJjZW50IiwiaW5mbyIsInN0YXR1cyIsImEiLCJiIiwiY29uZmlnIiwibmF2aWdhdGlvbkJhckJhY2tncm91bmRDb2xvciIsIm5hdmlnYXRpb25CYXJUaXRsZVRleHQiLCJjb21wdXRlZCIsImN1dFByaWNlIiwiYWN0IiwiX3AiLCJMYW5nIiwic3VtIiwiY291cnNlUHJpY2UiLCJjb3Vyc2VOZXdQcmljZSIsIl9zcCIsInBhcnNlSW50IiwibWV0aG9kcyIsInRvY3V0Iiwid2VweSIsIm5hdmlnYXRlVG8iLCJ1cmwiLCJpZCIsImJ1eSIsInJlZyIsInBlcmlvZElkIiwiY291cnNlSWQiLCJ0b3BheSIsIm9yZGVySWQiLCJvbkdvdFVzZXJJbmZvIiwiZSIsImRldGFpbCIsImVyck1zZyIsImF1dGgiLCJnZXRVc2VyaW5mbyIsImhlbHBCYXJnYWluIiwibG9hZCIsIiRhcHBseSIsInJlcyIsImZyb20iLCJ0aXRsZSIsInBhdGgiLCJvcHQiLCJnZXRDdXJyZW50UGFnZXMiLCJsb2dpbiIsInRvQ3V0RGV0YWkiLCJlcnJjb2RlIiwicGFnZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQ0k7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7Ozs7Ozs7Ozs7O0lBQ3FCQSxNOzs7Ozs7Ozs7Ozs7OzswTEFDakJDLEksR0FBTztBQUNIQyxtQkFBTywwQkFESjtBQUVIQyxvQkFBUSxJQUZMO0FBR0hDLG9CQUFRLENBSEw7QUFJSEMsbUJBQU8sRUFKSjtBQUtIQyx3QkFBWSxFQUxUO0FBTUhDLDJCQUFlLElBTlo7QUFPSEMsNEJBQWdCLEVBUGI7QUFRSEMsZ0JBQUksSUFSRDtBQVNIQyxxQkFBUyxDQVROO0FBVUhDLGtCQUFNLEVBVkg7QUFXSEMsb0JBQVE7QUFDSixtQkFBRztBQUNDQyx1QkFBRyxLQURKO0FBRUNDLHVCQUFHO0FBRkosaUJBREM7QUFLSixtQkFBRztBQUNDRCx1QkFBRyxNQURKO0FBRUNDLHVCQUFHO0FBRkosaUJBTEM7QUFTSixtQkFBRztBQUNDRCx1QkFBRyxNQURKO0FBRUNDLHVCQUFHO0FBRkosaUJBVEM7QUFhSixtQkFBRztBQUNDRCx1QkFBRyxLQURKO0FBRUNDLHVCQUFHO0FBRko7QUFiQztBQVhMLFMsUUE4QlBDLE0sR0FBUztBQUNMQywwQ0FBOEIsU0FEekI7QUFFTEMsb0NBQXdCO0FBRm5CLFMsUUFJVEMsUSxHQUFXO0FBQ1BDLG9CQURPLHNCQUNJO0FBQ1Asb0JBQUksS0FBS1osYUFBVCxFQUF3QjtBQUNwQix3QkFBSWEsTUFBTSxLQUFLYixhQUFmO0FBQ0Esd0JBQUljLEtBQUtDLGVBQUtDLEdBQUwsQ0FBUyxDQUFDSCxJQUFJSSxXQUFMLEVBQWtCLENBQUNKLElBQUlLLGNBQXZCLENBQVQsRUFBaUQsQ0FBakQsQ0FBVDtBQUFBLHdCQUNJQyxNQUFNSixlQUFLQyxHQUFMLENBQVMsQ0FBQ0gsSUFBSUksV0FBTCxFQUFrQixDQUFDLElBQW5CLENBQVQsRUFBbUMsQ0FBbkMsQ0FEVjtBQUVBLHlCQUFLZCxPQUFMLEdBQWVpQixTQUFTTixLQUFLSyxHQUFMLEdBQVcsR0FBcEIsQ0FBZjtBQUNBLDJCQUFPTCxFQUFQO0FBQ0g7QUFDSjtBQVRNLFMsUUE0QlhPLE8sR0FBVTtBQUNOQyxpQkFETSxtQkFDQztBQUNIQywrQkFBS0MsVUFBTCxDQUFnQjtBQUNaQyx3REFBa0MsS0FBSzFCLFVBQUwsQ0FBZ0IyQjtBQUR0QyxpQkFBaEI7QUFHSCxhQUxLO0FBTU5DLGVBTk0saUJBTUE7QUFDRkosK0JBQUtDLFVBQUwsQ0FBZ0I7QUFDWkMsa0VBQTRDLEtBQUtyQixJQUFMLENBQVV3QixHQUFWLENBQWNDLFFBQTFELGFBQTBFLEtBQUt6QixJQUFMLENBQVV3QixHQUFWLENBQWNFLFFBQXhGLG1CQUE4RyxLQUFLMUIsSUFBTCxDQUFVTjtBQUQ1RyxpQkFBaEI7QUFHSCxhQVZLO0FBV05pQyxpQkFYTSxtQkFXQztBQUNIUiwrQkFBS0MsVUFBTCxDQUFnQjtBQUNaQyxpREFBMkIsS0FBS3JCLElBQUwsQ0FBVTRCO0FBRHpCLGlCQUFoQjtBQUdILGFBZks7QUFnQkFDLHlCQWhCQTtBQUFBLHFHQWdCY0MsQ0FoQmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBDQWlCRUEsRUFBRUMsTUFBRixDQUFTQyxNQUFULElBQW1CLGdCQWpCckI7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQSwyQ0FrQlFDLGVBQUtDLFdBQUwsQ0FBaUJKLEVBQUVDLE1BQW5CLENBbEJSOztBQUFBO0FBQUE7QUFBQSwyQ0FtQlEsS0FBS0ksV0FBTCxFQW5CUjs7QUFBQTtBQUFBO0FBQUEsMkNBb0JRLEtBQUtDLElBQUwsRUFwQlI7O0FBQUE7QUFxQkUseUNBQUtDLE1BQUw7O0FBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUEsUzs7Ozs7MENBakJRQyxHLEVBQUs7QUFDbkIsZ0JBQUlBLElBQUlDLElBQUosS0FBYSxRQUFqQixFQUEyQjtBQUN2QjtBQUNBO0FBQ0g7QUFDRCxtQkFBTztBQUNIQyx1QkFBTyxvQkFESjtBQUVIQyxzQkFBTSxtQ0FBbUMsS0FBSzdDLGFBQUwsQ0FBbUIwQjtBQUZ6RCxhQUFQO0FBSUg7Ozs7a0dBQ1lvQixHOzs7OztBQUNULHFDQUFLaEQsS0FBTCxHQUFhZ0QsSUFBSWhELEtBQWpCO0FBQ0EscUNBQUtELE1BQUwsR0FBY2tELGlCQUFkOzt1Q0FDTVYsZUFBS1csS0FBTCxFOzs7O3VDQUNBLEtBQUtSLElBQUwsRTs7O0FBQ04scUNBQUtDLE1BQUw7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3VDQTRCZ0JqQyxpQkFBTytCLFdBQVAsQ0FBbUIsS0FBS3pDLEtBQXhCLEM7OztBQUFaNEMsbUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozt1Q0FNTWxDLGlCQUFPeUMsVUFBUCxDQUFrQixLQUFLbkQsS0FBdkIsQzs7OztBQUZOb0QsdUMsU0FBQUEsTztBQUNBeEQsb0MsU0FBQUEsSTs7QUFFSixvQ0FBSXdELFdBQVcsR0FBZixFQUFvQjtBQUNoQix5Q0FBSzlDLElBQUwsR0FBWVYsSUFBWjtBQUNBLHlDQUFLSyxVQUFMLEdBQWtCTCxLQUFLSyxVQUF2QjtBQUNBLHlDQUFLQyxhQUFMLEdBQXFCTixLQUFLa0MsR0FBMUI7QUFDQSx5Q0FBSzNCLGNBQUwsR0FBc0JQLEtBQUtPLGNBQTNCO0FBQ0g7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUFyRzJCc0IsZUFBSzRCLEk7O2tCQUFwQjFELE0iLCJmaWxlIjoiYmFyZ2Fpbi5qcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4gICAgaW1wb3J0IHdlcHkgZnJvbSBcIndlcHlcIlxyXG4gICAgaW1wb3J0IGNvbmZpZyBmcm9tIFwiQC9hcGkvY29uZmlnXCJcclxuICAgIGltcG9ydCBhdXRoIGZyb20gXCJAL2FwaS9hdXRoXCJcclxuICAgIGltcG9ydCBMYW5nIGZyb20gXCJAL3V0aWxzL0xhbmdcIlxyXG4gICAgZXhwb3J0IGRlZmF1bHQgY2xhc3MgRGlhbG9nIGV4dGVuZHMgd2VweS5wYWdlIHtcclxuICAgICAgICBkYXRhID0ge1xyXG4gICAgICAgICAgICBjbG9zZTogXCIvc3RhdGljL2ltYWdlcy9jbG9zZS5wbmdcIixcclxuICAgICAgICAgICAgYWN0aXZlOiB0cnVlLFxyXG4gICAgICAgICAgICByb3V0ZXM6IDAsXHJcbiAgICAgICAgICAgIHJlZ0lkOiAnJyxcclxuICAgICAgICAgICAgY291cnNlSW5mbzoge30sXHJcbiAgICAgICAgICAgIEFjdEJhcmdhaW5SZWc6IG51bGwsXHJcbiAgICAgICAgICAgIGJhcmdhaW5SZWNvcmRzOiBbXSxcclxuICAgICAgICAgICAgZGo6IDMwMDAsXHJcbiAgICAgICAgICAgIHBlcmNlbnQ6IDAsXHJcbiAgICAgICAgICAgIGluZm86IHt9LFxyXG4gICAgICAgICAgICBzdGF0dXM6IHtcclxuICAgICAgICAgICAgICAgIDA6IHtcclxuICAgICAgICAgICAgICAgICAgICBhOiAn56CN5Lu35LitJyxcclxuICAgICAgICAgICAgICAgICAgICBiOiAnJ1xyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIDE6IHtcclxuICAgICAgICAgICAgICAgICAgICBhOiAn56CN5Lu35a6M5oiQJyxcclxuICAgICAgICAgICAgICAgICAgICBiOiAn5b6F5pSv5LuYJ1xyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIDI6IHtcclxuICAgICAgICAgICAgICAgICAgICBhOiAn56CN5Lu35a6M5oiQJyxcclxuICAgICAgICAgICAgICAgICAgICBiOiAn5bey5pSv5LuYJ1xyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIDM6IHtcclxuICAgICAgICAgICAgICAgICAgICBhOiAn5bey6L+H5pyfJyxcclxuICAgICAgICAgICAgICAgICAgICBiOiAn56CN5Lu35aSx6LSlJ1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuICAgICAgICBjb25maWcgPSB7XHJcbiAgICAgICAgICAgIG5hdmlnYXRpb25CYXJCYWNrZ3JvdW5kQ29sb3I6ICcjZWQxYzI0JyxcclxuICAgICAgICAgICAgbmF2aWdhdGlvbkJhclRpdGxlVGV4dDogJ+egjeS7tydcclxuICAgICAgICB9XHJcbiAgICAgICAgY29tcHV0ZWQgPSB7XHJcbiAgICAgICAgICAgIGN1dFByaWNlKCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuQWN0QmFyZ2FpblJlZykge1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBhY3QgPSB0aGlzLkFjdEJhcmdhaW5SZWdcclxuICAgICAgICAgICAgICAgICAgICBsZXQgX3AgPSBMYW5nLnN1bShbYWN0LmNvdXJzZVByaWNlLCAtYWN0LmNvdXJzZU5ld1ByaWNlXSwgMiksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIF9zcCA9IExhbmcuc3VtKFthY3QuY291cnNlUHJpY2UsIC0yMDAwXSwgMilcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnBlcmNlbnQgPSBwYXJzZUludChfcCAvIF9zcCAqIDEwMClcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gX3BcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBvblNoYXJlQXBwTWVzc2FnZShyZXMpIHtcclxuICAgICAgICAgICAgaWYgKHJlcy5mcm9tID09PSAnYnV0dG9uJykge1xyXG4gICAgICAgICAgICAgICAgLy8g5p2l6Ieq6aG16Z2i5YaF6L2s5Y+R5oyJ6ZKuXHJcbiAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhyZXMudGFyZ2V0KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICB0aXRsZTogJ+aIkeWPkeeOsOS6huS4gOS7tuWlvei0p++8jOadpeS4gOi1t+egjeS7t+S8mOaDoOi0re+8gScsXHJcbiAgICAgICAgICAgICAgICBwYXRoOiAnL3BhZ2VzL2FjdGl2aXR5L2JhcmdhaW4/cmVnSWQ9JyArIHRoaXMuQWN0QmFyZ2FpblJlZy5pZFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGFzeW5jIG9uTG9hZChvcHQpIHtcclxuICAgICAgICAgICAgdGhpcy5yZWdJZCA9IG9wdC5yZWdJZFxyXG4gICAgICAgICAgICB0aGlzLnJvdXRlcyA9IGdldEN1cnJlbnRQYWdlcygpXHJcbiAgICAgICAgICAgIGF3YWl0IGF1dGgubG9naW4oKVxyXG4gICAgICAgICAgICBhd2FpdCB0aGlzLmxvYWQoKVxyXG4gICAgICAgICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICAgICAgfVxyXG4gICAgICAgIG1ldGhvZHMgPSB7XHJcbiAgICAgICAgICAgIHRvY3V0KCl7XHJcbiAgICAgICAgICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICAgICAgICAgIHVybDogYC9wYWdlcy9kZXRhaWxlL2RldGFpbGU/aWQ9JHt0aGlzLmNvdXJzZUluZm8uaWR9YFxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGJ1eSgpIHtcclxuICAgICAgICAgICAgICAgIHdlcHkubmF2aWdhdGVUbyh7XHJcbiAgICAgICAgICAgICAgICAgICAgdXJsOiBgL3BhZ2VzL2RldGFpbGUvc3VyZU9yZGVyP3R5cGU9MiZwaWQ9JHt0aGlzLmluZm8ucmVnLnBlcmlvZElkfSZjaWQ9JHt0aGlzLmluZm8ucmVnLmNvdXJzZUlkfSZudW09MSZhaWQ9JHt0aGlzLmluZm8ucmVnSWR9YFxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHRvcGF5KCl7XHJcbiAgICAgICAgICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICAgICAgICAgIHVybDogYC9wYWdlcy9teS9vcmRlcj9pZD0ke3RoaXMuaW5mby5vcmRlcklkfWBcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBhc3luYyBvbkdvdFVzZXJJbmZvKGUpIHtcclxuICAgICAgICAgICAgICAgIGlmIChlLmRldGFpbC5lcnJNc2cgPT0gXCJnZXRVc2VySW5mbzpva1wiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYXdhaXQgYXV0aC5nZXRVc2VyaW5mbyhlLmRldGFpbClcclxuICAgICAgICAgICAgICAgICAgICBhd2FpdCB0aGlzLmhlbHBCYXJnYWluKClcclxuICAgICAgICAgICAgICAgICAgICBhd2FpdCB0aGlzLmxvYWQoKVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICB9O1xyXG4gICAgICAgIGFzeW5jIGhlbHBCYXJnYWluKCkge1xyXG4gICAgICAgICAgICBsZXQgcmVzID0gYXdhaXQgY29uZmlnLmhlbHBCYXJnYWluKHRoaXMucmVnSWQpXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGFzeW5jIGxvYWQoKSB7XHJcbiAgICAgICAgICAgIGxldCB7XHJcbiAgICAgICAgICAgICAgICBlcnJjb2RlLFxyXG4gICAgICAgICAgICAgICAgZGF0YVxyXG4gICAgICAgICAgICB9ID0gYXdhaXQgY29uZmlnLnRvQ3V0RGV0YWkodGhpcy5yZWdJZClcclxuICAgICAgICAgICAgaWYgKGVycmNvZGUgPT0gMjAwKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmluZm8gPSBkYXRhXHJcbiAgICAgICAgICAgICAgICB0aGlzLmNvdXJzZUluZm8gPSBkYXRhLmNvdXJzZUluZm9cclxuICAgICAgICAgICAgICAgIHRoaXMuQWN0QmFyZ2FpblJlZyA9IGRhdGEucmVnXHJcbiAgICAgICAgICAgICAgICB0aGlzLmJhcmdhaW5SZWNvcmRzID0gZGF0YS5iYXJnYWluUmVjb3Jkc1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4iXX0=