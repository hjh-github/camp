"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

var _Lang = require('./../../utils/Lang.js');

var _Lang2 = _interopRequireDefault(_Lang);

var _utils = require('./../../store/utils.js');

var _utils2 = _interopRequireDefault(_utils);

var _contact = require('./../../components/common/contact.js');

var _contact2 = _interopRequireDefault(_contact);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
    _inherits(Dialog, _wepy$page);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.data = {
            close: "/static/images/close.png",
            active: true,
            routes: 0,
            regId: '',
            courseInfo: {},
            ActBargainReg: {
                invalidTime: ''
            },
            bargainRecords: [],
            dj: 3000,
            percent: 0,
            info: {},
            modalName: '',
            status: {
                0: {
                    a: '砍价中',
                    b: ''
                },
                1: {
                    a: '砍价完成',
                    b: '待支付'
                },
                2: {
                    a: '砍价完成',
                    b: '已支付'
                },
                3: {
                    a: '已过期',
                    b: '砍价结束'
                }
            }
        }, _this.config = {
            navigationBarBackgroundColor: '#ed1c24',
            navigationBarTitleText: '砍价',
            "usingComponents": {
                "l-countdown": "../../components/countdown/index"
            }
        }, _this.components = {
            contact: _contact2.default
        }, _this.computed = {
            cutPrice: function cutPrice() {
                if (this.ActBargainReg) {
                    var act = this.ActBargainReg;
                    var _p = _Lang2.default.sum([act.coursePrice, -act.courseNewPrice], 2),
                        _sp = _Lang2.default.sum([act.coursePrice, 0], 2);
                    this.percent = parseInt(_p / _sp * 100);
                    return _p;
                }
            }
        }, _this.methods = {
            hideModal: function hideModal() {
                this.modalName = '';
            },
            createImg: function () {
                var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(e) {
                    return regeneratorRuntime.wrap(function _callee$(_context) {
                        while (1) {
                            switch (_context.prev = _context.next) {
                                case 0:
                                    if (!(e.detail.errMsg == "getUserInfo:ok")) {
                                        _context.next = 5;
                                        break;
                                    }

                                    _context.next = 3;
                                    return _auth2.default.getUserinfo(e.detail);

                                case 3:
                                    _utils2.default.save('shareInfo', {
                                        course: this.courseInfo,
                                        path: 'pages/activity/bargain',
                                        id: this.ActBargainReg.id
                                    });
                                    _wepy2.default.navigateTo({
                                        url: '/pages/home/share'
                                    });

                                case 5:
                                case "end":
                                    return _context.stop();
                            }
                        }
                    }, _callee, this);
                }));

                function createImg(_x) {
                    return _ref2.apply(this, arguments);
                }

                return createImg;
            }(),
            toshare: function toshare() {
                this.modalName = 'share';
            },
            tocut: function () {
                var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(e) {
                    return regeneratorRuntime.wrap(function _callee2$(_context2) {
                        while (1) {
                            switch (_context2.prev = _context2.next) {
                                case 0:
                                    if (!(e.detail.errMsg == "getUserInfo:ok")) {
                                        _context2.next = 4;
                                        break;
                                    }

                                    _context2.next = 3;
                                    return _auth2.default.getUserinfo(e.detail);

                                case 3:
                                    _wepy2.default.navigateTo({
                                        url: "/pages/detaile/detaile?id=" + this.courseInfo.id
                                    });

                                case 4:
                                case "end":
                                    return _context2.stop();
                            }
                        }
                    }, _callee2, this);
                }));

                function tocut(_x2) {
                    return _ref3.apply(this, arguments);
                }

                return tocut;
            }(),
            buy: function buy() {
                _wepy2.default.navigateTo({
                    url: "/pages/detaile/sureOrder?type=2&pid=" + this.info.reg.periodId + "&cid=" + this.info.reg.courseId + "&num=1&aid=" + this.info.regId + "&actpid=0"
                });
            },
            topay: function topay() {
                _wepy2.default.navigateTo({
                    url: "/pages/my/order?id=" + this.info.orderId
                });
            },
            onGotUserInfo: function () {
                var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(e) {
                    return regeneratorRuntime.wrap(function _callee3$(_context3) {
                        while (1) {
                            switch (_context3.prev = _context3.next) {
                                case 0:
                                    if (!(e.detail.errMsg == "getUserInfo:ok")) {
                                        _context3.next = 8;
                                        break;
                                    }

                                    _context3.next = 3;
                                    return _auth2.default.getUserinfo(e.detail);

                                case 3:
                                    _context3.next = 5;
                                    return this.helpBargain();

                                case 5:
                                    _context3.next = 7;
                                    return this.load();

                                case 7:
                                    this.$apply();

                                case 8:
                                case "end":
                                    return _context3.stop();
                            }
                        }
                    }, _callee3, this);
                }));

                function onGotUserInfo(_x3) {
                    return _ref4.apply(this, arguments);
                }

                return onGotUserInfo;
            }()
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(Dialog, [{
        key: "onShareAppMessage",
        value: function onShareAppMessage(res) {
            if (res.from === 'button') {
                // 来自页面内转发按钮
                // console.log(res.target)
            }
            return {
                title: this.courseInfo.courseTittle,
                imageUrl: this.courseInfo.image,
                path: '/pages/activity/bargain?id=' + this.ActBargainReg.id + '&agentId=' + this.member.agentId
            };
        }
    }, {
        key: "onLoad",
        value: function () {
            var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4(opt) {
                return regeneratorRuntime.wrap(function _callee4$(_context4) {
                    while (1) {
                        switch (_context4.prev = _context4.next) {
                            case 0:
                                this.regId = opt.id || opt.scene;
                                this.routes = getCurrentPages();
                                _context4.next = 4;
                                return _auth2.default.login();

                            case 4:
                                this.member = _wepy2.default.getStorageSync('member');
                                _context4.next = 7;
                                return this.load();

                            case 7:
                                this.$apply();

                            case 8:
                            case "end":
                                return _context4.stop();
                        }
                    }
                }, _callee4, this);
            }));

            function onLoad(_x4) {
                return _ref5.apply(this, arguments);
            }

            return onLoad;
        }()
    }, {
        key: "helpBargain",
        value: function () {
            var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
                var res;
                return regeneratorRuntime.wrap(function _callee5$(_context5) {
                    while (1) {
                        switch (_context5.prev = _context5.next) {
                            case 0:
                                _context5.next = 2;
                                return _config2.default.helpBargain(this.regId);

                            case 2:
                                res = _context5.sent;

                            case 3:
                            case "end":
                                return _context5.stop();
                        }
                    }
                }, _callee5, this);
            }));

            function helpBargain() {
                return _ref6.apply(this, arguments);
            }

            return helpBargain;
        }()
    }, {
        key: "load",
        value: function () {
            var _ref7 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
                var _ref8, errcode, data;

                return regeneratorRuntime.wrap(function _callee6$(_context6) {
                    while (1) {
                        switch (_context6.prev = _context6.next) {
                            case 0:
                                _context6.next = 2;
                                return _config2.default.toCutDetai(this.regId);

                            case 2:
                                _ref8 = _context6.sent;
                                errcode = _ref8.errcode;
                                data = _ref8.data;

                                if (errcode == 200) {
                                    this.info = data;
                                    this.courseInfo = data.courseInfo;
                                    this.ActBargainReg = data.reg;
                                    console.log(this.ActBargainReg.invalidTime);
                                    this.bargainRecords = data.bargainRecords;
                                }

                            case 6:
                            case "end":
                                return _context6.stop();
                        }
                    }
                }, _callee6, this);
            }));

            function load() {
                return _ref7.apply(this, arguments);
            }

            return load;
        }()
    }]);

    return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/activity/bargain'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImJhcmdhaW4uanMiXSwibmFtZXMiOlsiRGlhbG9nIiwiZGF0YSIsImNsb3NlIiwiYWN0aXZlIiwicm91dGVzIiwicmVnSWQiLCJjb3Vyc2VJbmZvIiwiQWN0QmFyZ2FpblJlZyIsImludmFsaWRUaW1lIiwiYmFyZ2FpblJlY29yZHMiLCJkaiIsInBlcmNlbnQiLCJpbmZvIiwibW9kYWxOYW1lIiwic3RhdHVzIiwiYSIsImIiLCJjb25maWciLCJuYXZpZ2F0aW9uQmFyQmFja2dyb3VuZENvbG9yIiwibmF2aWdhdGlvbkJhclRpdGxlVGV4dCIsImNvbXBvbmVudHMiLCJjb250YWN0IiwiY29tcHV0ZWQiLCJjdXRQcmljZSIsImFjdCIsIl9wIiwiTGFuZyIsInN1bSIsImNvdXJzZVByaWNlIiwiY291cnNlTmV3UHJpY2UiLCJfc3AiLCJwYXJzZUludCIsIm1ldGhvZHMiLCJoaWRlTW9kYWwiLCJjcmVhdGVJbWciLCJlIiwiZGV0YWlsIiwiZXJyTXNnIiwiYXV0aCIsImdldFVzZXJpbmZvIiwic3RvcmUiLCJzYXZlIiwiY291cnNlIiwicGF0aCIsImlkIiwid2VweSIsIm5hdmlnYXRlVG8iLCJ1cmwiLCJ0b3NoYXJlIiwidG9jdXQiLCJidXkiLCJyZWciLCJwZXJpb2RJZCIsImNvdXJzZUlkIiwidG9wYXkiLCJvcmRlcklkIiwib25Hb3RVc2VySW5mbyIsImhlbHBCYXJnYWluIiwibG9hZCIsIiRhcHBseSIsInJlcyIsImZyb20iLCJ0aXRsZSIsImNvdXJzZVRpdHRsZSIsImltYWdlVXJsIiwiaW1hZ2UiLCJtZW1iZXIiLCJhZ2VudElkIiwib3B0Iiwic2NlbmUiLCJnZXRDdXJyZW50UGFnZXMiLCJsb2dpbiIsImdldFN0b3JhZ2VTeW5jIiwidG9DdXREZXRhaSIsImVycmNvZGUiLCJjb25zb2xlIiwibG9nIiwicGFnZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQ0k7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7Ozs7Ozs7Ozs7OztJQUNxQkEsTTs7Ozs7Ozs7Ozs7Ozs7MExBQ2pCQyxJLEdBQU87QUFDSEMsbUJBQU8sMEJBREo7QUFFSEMsb0JBQVEsSUFGTDtBQUdIQyxvQkFBUSxDQUhMO0FBSUhDLG1CQUFPLEVBSko7QUFLSEMsd0JBQVksRUFMVDtBQU1IQywyQkFBZTtBQUNYQyw2QkFBYTtBQURGLGFBTlo7QUFTSEMsNEJBQWdCLEVBVGI7QUFVSEMsZ0JBQUksSUFWRDtBQVdIQyxxQkFBUyxDQVhOO0FBWUhDLGtCQUFNLEVBWkg7QUFhSEMsdUJBQVcsRUFiUjtBQWNIQyxvQkFBUTtBQUNKLG1CQUFHO0FBQ0NDLHVCQUFHLEtBREo7QUFFQ0MsdUJBQUc7QUFGSixpQkFEQztBQUtKLG1CQUFHO0FBQ0NELHVCQUFHLE1BREo7QUFFQ0MsdUJBQUc7QUFGSixpQkFMQztBQVNKLG1CQUFHO0FBQ0NELHVCQUFHLE1BREo7QUFFQ0MsdUJBQUc7QUFGSixpQkFUQztBQWFKLG1CQUFHO0FBQ0NELHVCQUFHLEtBREo7QUFFQ0MsdUJBQUc7QUFGSjtBQWJDO0FBZEwsUyxRQWlDUEMsTSxHQUFTO0FBQ0xDLDBDQUE4QixTQUR6QjtBQUVMQyxvQ0FBd0IsSUFGbkI7QUFHTCwrQkFBbUI7QUFDZiwrQkFBZTtBQURBO0FBSGQsUyxRQU9UQyxVLEdBQWE7QUFDVEM7QUFEUyxTLFFBR2JDLFEsR0FBVztBQUNQQyxvQkFETyxzQkFDSTtBQUNQLG9CQUFJLEtBQUtoQixhQUFULEVBQXdCO0FBQ3BCLHdCQUFJaUIsTUFBTSxLQUFLakIsYUFBZjtBQUNBLHdCQUFJa0IsS0FBS0MsZUFBS0MsR0FBTCxDQUFTLENBQUNILElBQUlJLFdBQUwsRUFBa0IsQ0FBQ0osSUFBSUssY0FBdkIsQ0FBVCxFQUFpRCxDQUFqRCxDQUFUO0FBQUEsd0JBQ0lDLE1BQU1KLGVBQUtDLEdBQUwsQ0FBUyxDQUFDSCxJQUFJSSxXQUFMLEVBQWtCLENBQWxCLENBQVQsRUFBK0IsQ0FBL0IsQ0FEVjtBQUVBLHlCQUFLakIsT0FBTCxHQUFlb0IsU0FBU04sS0FBS0ssR0FBTCxHQUFXLEdBQXBCLENBQWY7QUFDQSwyQkFBT0wsRUFBUDtBQUNIO0FBQ0o7QUFUTSxTLFFBOEJYTyxPLEdBQVU7QUFDTkMscUJBRE0sdUJBQ007QUFDUixxQkFBS3BCLFNBQUwsR0FBaUIsRUFBakI7QUFDSCxhQUhLO0FBSUFxQixxQkFKQTtBQUFBLHFHQUlVQyxDQUpWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQ0FLRUEsRUFBRUMsTUFBRixDQUFTQyxNQUFULElBQW1CLGdCQUxyQjtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBLDJDQU1RQyxlQUFLQyxXQUFMLENBQWlCSixFQUFFQyxNQUFuQixDQU5SOztBQUFBO0FBT0VJLG9EQUFNQyxJQUFOLENBQVcsV0FBWCxFQUF3QjtBQUNwQkMsZ0RBQVEsS0FBS3BDLFVBRE87QUFFcEJxQyw4Q0FBTSx3QkFGYztBQUdwQkMsNENBQUksS0FBS3JDLGFBQUwsQ0FBbUJxQztBQUhILHFDQUF4QjtBQUtBQyxtREFBS0MsVUFBTCxDQUFnQjtBQUNaQyw2Q0FBSztBQURPLHFDQUFoQjs7QUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQWlCTkMsbUJBakJNLHFCQWlCSTtBQUNOLHFCQUFLbkMsU0FBTCxHQUFpQixPQUFqQjtBQUNILGFBbkJLO0FBb0JBb0MsaUJBcEJBO0FBQUEsc0dBb0JNZCxDQXBCTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMENBcUJFQSxFQUFFQyxNQUFGLENBQVNDLE1BQVQsSUFBbUIsZ0JBckJyQjtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBLDJDQXNCUUMsZUFBS0MsV0FBTCxDQUFpQkosRUFBRUMsTUFBbkIsQ0F0QlI7O0FBQUE7QUF1QkVTLG1EQUFLQyxVQUFMLENBQWdCO0FBQ1pDLDRFQUFrQyxLQUFLekMsVUFBTCxDQUFnQnNDO0FBRHRDLHFDQUFoQjs7QUF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUE0Qk5NLGVBNUJNLGlCQTRCQTtBQUNGTCwrQkFBS0MsVUFBTCxDQUFnQjtBQUNaQyxrRUFBNEMsS0FBS25DLElBQUwsQ0FBVXVDLEdBQVYsQ0FBY0MsUUFBMUQsYUFBMEUsS0FBS3hDLElBQUwsQ0FBVXVDLEdBQVYsQ0FBY0UsUUFBeEYsbUJBQThHLEtBQUt6QyxJQUFMLENBQVVQLEtBQXhIO0FBRFksaUJBQWhCO0FBR0gsYUFoQ0s7QUFpQ05pRCxpQkFqQ00sbUJBaUNFO0FBQ0pULCtCQUFLQyxVQUFMLENBQWdCO0FBQ1pDLGlEQUEyQixLQUFLbkMsSUFBTCxDQUFVMkM7QUFEekIsaUJBQWhCO0FBR0gsYUFyQ0s7QUFzQ0FDLHlCQXRDQTtBQUFBLHNHQXNDY3JCLENBdENkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQ0F1Q0VBLEVBQUVDLE1BQUYsQ0FBU0MsTUFBVCxJQUFtQixnQkF2Q3JCO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUEsMkNBd0NRQyxlQUFLQyxXQUFMLENBQWlCSixFQUFFQyxNQUFuQixDQXhDUjs7QUFBQTtBQUFBO0FBQUEsMkNBeUNRLEtBQUtxQixXQUFMLEVBekNSOztBQUFBO0FBQUE7QUFBQSwyQ0EwQ1EsS0FBS0MsSUFBTCxFQTFDUjs7QUFBQTtBQTJDRSx5Q0FBS0MsTUFBTDs7QUEzQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQSxTOzs7OzswQ0FuQlFDLEcsRUFBSztBQUNuQixnQkFBSUEsSUFBSUMsSUFBSixLQUFhLFFBQWpCLEVBQTJCO0FBQ3ZCO0FBQ0E7QUFDSDtBQUNELG1CQUFPO0FBQ0hDLHVCQUFPLEtBQUt4RCxVQUFMLENBQWdCeUQsWUFEcEI7QUFFSEMsMEJBQVUsS0FBSzFELFVBQUwsQ0FBZ0IyRCxLQUZ2QjtBQUdIdEIsc0JBQU0sZ0NBQWdDLEtBQUtwQyxhQUFMLENBQW1CcUMsRUFBbkQsR0FBd0QsV0FBeEQsR0FBc0UsS0FBS3NCLE1BQUwsQ0FBWUM7QUFIckYsYUFBUDtBQUtIOzs7O2tHQUNZQyxHOzs7OztBQUNULHFDQUFLL0QsS0FBTCxHQUFhK0QsSUFBSXhCLEVBQUosSUFBVXdCLElBQUlDLEtBQTNCO0FBQ0EscUNBQUtqRSxNQUFMLEdBQWNrRSxpQkFBZDs7dUNBQ01oQyxlQUFLaUMsS0FBTCxFOzs7QUFDTixxQ0FBS0wsTUFBTCxHQUFjckIsZUFBSzJCLGNBQUwsQ0FBb0IsUUFBcEIsQ0FBZDs7dUNBQ00sS0FBS2QsSUFBTCxFOzs7QUFDTixxQ0FBS0MsTUFBTDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7dUNBa0RnQjFDLGlCQUFPd0MsV0FBUCxDQUFtQixLQUFLcEQsS0FBeEIsQzs7O0FBQVp1RCxtQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3VDQU1NM0MsaUJBQU93RCxVQUFQLENBQWtCLEtBQUtwRSxLQUF2QixDOzs7O0FBRk5xRSx1QyxTQUFBQSxPO0FBQ0F6RSxvQyxTQUFBQSxJOztBQUVKLG9DQUFJeUUsV0FBVyxHQUFmLEVBQW9CO0FBQ2hCLHlDQUFLOUQsSUFBTCxHQUFZWCxJQUFaO0FBQ0EseUNBQUtLLFVBQUwsR0FBa0JMLEtBQUtLLFVBQXZCO0FBQ0EseUNBQUtDLGFBQUwsR0FBcUJOLEtBQUtrRCxHQUExQjtBQUNBd0IsNENBQVFDLEdBQVIsQ0FBWSxLQUFLckUsYUFBTCxDQUFtQkMsV0FBL0I7QUFDQSx5Q0FBS0MsY0FBTCxHQUFzQlIsS0FBS1EsY0FBM0I7QUFDSDs7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQXZJMkJvQyxlQUFLZ0MsSTs7a0JBQXBCN0UsTSIsImZpbGUiOiJiYXJnYWluLmpzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbiAgICBpbXBvcnQgd2VweSBmcm9tIFwid2VweVwiXHJcbiAgICBpbXBvcnQgY29uZmlnIGZyb20gXCJAL2FwaS9jb25maWdcIlxyXG4gICAgaW1wb3J0IGF1dGggZnJvbSBcIkAvYXBpL2F1dGhcIlxyXG4gICAgaW1wb3J0IExhbmcgZnJvbSBcIkAvdXRpbHMvTGFuZ1wiXHJcbiAgICBpbXBvcnQgc3RvcmUgZnJvbSBcIkAvc3RvcmUvdXRpbHNcIlxyXG4gICAgaW1wb3J0IGNvbnRhY3QgZnJvbSBcIkAvY29tcG9uZW50cy9jb21tb24vY29udGFjdFwiXHJcbiAgICBleHBvcnQgZGVmYXVsdCBjbGFzcyBEaWFsb2cgZXh0ZW5kcyB3ZXB5LnBhZ2Uge1xyXG4gICAgICAgIGRhdGEgPSB7XHJcbiAgICAgICAgICAgIGNsb3NlOiBcIi9zdGF0aWMvaW1hZ2VzL2Nsb3NlLnBuZ1wiLFxyXG4gICAgICAgICAgICBhY3RpdmU6IHRydWUsXHJcbiAgICAgICAgICAgIHJvdXRlczogMCxcclxuICAgICAgICAgICAgcmVnSWQ6ICcnLFxyXG4gICAgICAgICAgICBjb3Vyc2VJbmZvOiB7fSxcclxuICAgICAgICAgICAgQWN0QmFyZ2FpblJlZzoge1xyXG4gICAgICAgICAgICAgICAgaW52YWxpZFRpbWU6ICcnXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGJhcmdhaW5SZWNvcmRzOiBbXSxcclxuICAgICAgICAgICAgZGo6IDMwMDAsXHJcbiAgICAgICAgICAgIHBlcmNlbnQ6IDAsXHJcbiAgICAgICAgICAgIGluZm86IHt9LFxyXG4gICAgICAgICAgICBtb2RhbE5hbWU6ICcnLFxyXG4gICAgICAgICAgICBzdGF0dXM6IHtcclxuICAgICAgICAgICAgICAgIDA6IHtcclxuICAgICAgICAgICAgICAgICAgICBhOiAn56CN5Lu35LitJyxcclxuICAgICAgICAgICAgICAgICAgICBiOiAnJ1xyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIDE6IHtcclxuICAgICAgICAgICAgICAgICAgICBhOiAn56CN5Lu35a6M5oiQJyxcclxuICAgICAgICAgICAgICAgICAgICBiOiAn5b6F5pSv5LuYJ1xyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIDI6IHtcclxuICAgICAgICAgICAgICAgICAgICBhOiAn56CN5Lu35a6M5oiQJyxcclxuICAgICAgICAgICAgICAgICAgICBiOiAn5bey5pSv5LuYJ1xyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIDM6IHtcclxuICAgICAgICAgICAgICAgICAgICBhOiAn5bey6L+H5pyfJyxcclxuICAgICAgICAgICAgICAgICAgICBiOiAn56CN5Lu357uT5p2fJ1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuICAgICAgICBjb25maWcgPSB7XHJcbiAgICAgICAgICAgIG5hdmlnYXRpb25CYXJCYWNrZ3JvdW5kQ29sb3I6ICcjZWQxYzI0JyxcclxuICAgICAgICAgICAgbmF2aWdhdGlvbkJhclRpdGxlVGV4dDogJ+egjeS7tycsXHJcbiAgICAgICAgICAgIFwidXNpbmdDb21wb25lbnRzXCI6IHtcclxuICAgICAgICAgICAgICAgIFwibC1jb3VudGRvd25cIjogXCIuLi8uLi9jb21wb25lbnRzL2NvdW50ZG93bi9pbmRleFwiXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgY29tcG9uZW50cyA9IHtcclxuICAgICAgICAgICAgY29udGFjdFxyXG4gICAgICAgIH1cclxuICAgICAgICBjb21wdXRlZCA9IHtcclxuICAgICAgICAgICAgY3V0UHJpY2UoKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5BY3RCYXJnYWluUmVnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGFjdCA9IHRoaXMuQWN0QmFyZ2FpblJlZ1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBfcCA9IExhbmcuc3VtKFthY3QuY291cnNlUHJpY2UsIC1hY3QuY291cnNlTmV3UHJpY2VdLCAyKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgX3NwID0gTGFuZy5zdW0oW2FjdC5jb3Vyc2VQcmljZSwgMF0sIDIpXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5wZXJjZW50ID0gcGFyc2VJbnQoX3AgLyBfc3AgKiAxMDApXHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIF9wXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgb25TaGFyZUFwcE1lc3NhZ2UocmVzKSB7XHJcbiAgICAgICAgICAgIGlmIChyZXMuZnJvbSA9PT0gJ2J1dHRvbicpIHtcclxuICAgICAgICAgICAgICAgIC8vIOadpeiHqumhtemdouWGhei9rOWPkeaMiemSrlxyXG4gICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2cocmVzLnRhcmdldClcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgdGl0bGU6IHRoaXMuY291cnNlSW5mby5jb3Vyc2VUaXR0bGUsXHJcbiAgICAgICAgICAgICAgICBpbWFnZVVybDogdGhpcy5jb3Vyc2VJbmZvLmltYWdlLFxyXG4gICAgICAgICAgICAgICAgcGF0aDogJy9wYWdlcy9hY3Rpdml0eS9iYXJnYWluP2lkPScgKyB0aGlzLkFjdEJhcmdhaW5SZWcuaWQgKyAnJmFnZW50SWQ9JyArIHRoaXMubWVtYmVyLmFnZW50SWQgXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgYXN5bmMgb25Mb2FkKG9wdCkge1xyXG4gICAgICAgICAgICB0aGlzLnJlZ0lkID0gb3B0LmlkIHx8IG9wdC5zY2VuZVxyXG4gICAgICAgICAgICB0aGlzLnJvdXRlcyA9IGdldEN1cnJlbnRQYWdlcygpXHJcbiAgICAgICAgICAgIGF3YWl0IGF1dGgubG9naW4oKVxyXG4gICAgICAgICAgICB0aGlzLm1lbWJlciA9IHdlcHkuZ2V0U3RvcmFnZVN5bmMoJ21lbWJlcicpO1xyXG4gICAgICAgICAgICBhd2FpdCB0aGlzLmxvYWQoKVxyXG4gICAgICAgICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICAgICAgfVxyXG4gICAgICAgIG1ldGhvZHMgPSB7XHJcbiAgICAgICAgICAgIGhpZGVNb2RhbCgpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kYWxOYW1lID0gJydcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgYXN5bmMgY3JlYXRlSW1nKGUpIHtcclxuICAgICAgICAgICAgICAgIGlmIChlLmRldGFpbC5lcnJNc2cgPT0gXCJnZXRVc2VySW5mbzpva1wiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYXdhaXQgYXV0aC5nZXRVc2VyaW5mbyhlLmRldGFpbClcclxuICAgICAgICAgICAgICAgICAgICBzdG9yZS5zYXZlKCdzaGFyZUluZm8nLCB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvdXJzZTogdGhpcy5jb3Vyc2VJbmZvLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYXRoOiAncGFnZXMvYWN0aXZpdHkvYmFyZ2FpbicsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkOiB0aGlzLkFjdEJhcmdhaW5SZWcuaWRcclxuICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgIHdlcHkubmF2aWdhdGVUbyh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHVybDogJy9wYWdlcy9ob21lL3NoYXJlJ1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB0b3NoYXJlKCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RhbE5hbWUgPSAnc2hhcmUnXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGFzeW5jIHRvY3V0KGUpIHtcclxuICAgICAgICAgICAgICAgIGlmIChlLmRldGFpbC5lcnJNc2cgPT0gXCJnZXRVc2VySW5mbzpva1wiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYXdhaXQgYXV0aC5nZXRVc2VyaW5mbyhlLmRldGFpbClcclxuICAgICAgICAgICAgICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB1cmw6IGAvcGFnZXMvZGV0YWlsZS9kZXRhaWxlP2lkPSR7dGhpcy5jb3Vyc2VJbmZvLmlkfWBcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgYnV5KCkge1xyXG4gICAgICAgICAgICAgICAgd2VweS5uYXZpZ2F0ZVRvKHtcclxuICAgICAgICAgICAgICAgICAgICB1cmw6IGAvcGFnZXMvZGV0YWlsZS9zdXJlT3JkZXI/dHlwZT0yJnBpZD0ke3RoaXMuaW5mby5yZWcucGVyaW9kSWR9JmNpZD0ke3RoaXMuaW5mby5yZWcuY291cnNlSWR9Jm51bT0xJmFpZD0ke3RoaXMuaW5mby5yZWdJZH0mYWN0cGlkPTBgXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgdG9wYXkoKSB7XHJcbiAgICAgICAgICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICAgICAgICAgIHVybDogYC9wYWdlcy9teS9vcmRlcj9pZD0ke3RoaXMuaW5mby5vcmRlcklkfWBcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBhc3luYyBvbkdvdFVzZXJJbmZvKGUpIHtcclxuICAgICAgICAgICAgICAgIGlmIChlLmRldGFpbC5lcnJNc2cgPT0gXCJnZXRVc2VySW5mbzpva1wiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYXdhaXQgYXV0aC5nZXRVc2VyaW5mbyhlLmRldGFpbClcclxuICAgICAgICAgICAgICAgICAgICBhd2FpdCB0aGlzLmhlbHBCYXJnYWluKClcclxuICAgICAgICAgICAgICAgICAgICBhd2FpdCB0aGlzLmxvYWQoKVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICB9O1xyXG4gICAgICAgIGFzeW5jIGhlbHBCYXJnYWluKCkge1xyXG4gICAgICAgICAgICBsZXQgcmVzID0gYXdhaXQgY29uZmlnLmhlbHBCYXJnYWluKHRoaXMucmVnSWQpXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGFzeW5jIGxvYWQoKSB7XHJcbiAgICAgICAgICAgIGxldCB7XHJcbiAgICAgICAgICAgICAgICBlcnJjb2RlLFxyXG4gICAgICAgICAgICAgICAgZGF0YVxyXG4gICAgICAgICAgICB9ID0gYXdhaXQgY29uZmlnLnRvQ3V0RGV0YWkodGhpcy5yZWdJZClcclxuICAgICAgICAgICAgaWYgKGVycmNvZGUgPT0gMjAwKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmluZm8gPSBkYXRhXHJcbiAgICAgICAgICAgICAgICB0aGlzLmNvdXJzZUluZm8gPSBkYXRhLmNvdXJzZUluZm9cclxuICAgICAgICAgICAgICAgIHRoaXMuQWN0QmFyZ2FpblJlZyA9IGRhdGEucmVnXHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyh0aGlzLkFjdEJhcmdhaW5SZWcuaW52YWxpZFRpbWUpXHJcbiAgICAgICAgICAgICAgICB0aGlzLmJhcmdhaW5SZWNvcmRzID0gZGF0YS5iYXJnYWluUmVjb3Jkc1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4iXX0=