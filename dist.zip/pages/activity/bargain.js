"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

var _Lang = require('./../../utils/Lang.js');

var _Lang2 = _interopRequireDefault(_Lang);

var _utils = require('./../../store/utils.js');

var _utils2 = _interopRequireDefault(_utils);

var _contact = require('./../../components/common/contact.js');

var _contact2 = _interopRequireDefault(_contact);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
    _inherits(Dialog, _wepy$page);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.data = {
            close: "/static/images/close.png",
            active: true,
            routes: 0,
            regId: '',
            courseInfo: {},
            ActBargainReg: {
                invalidTime: ''
            },
            bargainRecords: [],
            dj: 3000,
            percent: 0,
            info: {},
            modalName: '',
            status: {
                0: {
                    a: '砍价中',
                    b: ''
                },
                1: {
                    a: '砍价完成',
                    b: '待支付'
                },
                2: {
                    a: '砍价完成',
                    b: '已支付'
                },
                3: {
                    a: '已过期',
                    b: '砍价结束'
                }
            }
        }, _this.config = {
            navigationBarBackgroundColor: '#215E21',
            navigationBarTitleText: '砍价',
            "usingComponents": {
                "l-countdown": "../../components/countdown/index"
            }
        }, _this.components = {
            contact: _contact2.default
        }, _this.computed = {
            cutPrice: function cutPrice() {
                if (this.ActBargainReg) {
                    var act = this.ActBargainReg;
                    var _p = _Lang2.default.sum([act.coursePrice, -act.courseNewPrice], 2),
                        _sp = _Lang2.default.sum([act.coursePrice - act.cutMinPrice], 2);
                    this.percent = parseInt(_p / _sp * 100);
                    return _p;
                }
            }
        }, _this.methods = {
            hideModal: function hideModal() {
                this.modalName = '';
            },
            createImg: function () {
                var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(e) {
                    return regeneratorRuntime.wrap(function _callee$(_context) {
                        while (1) {
                            switch (_context.prev = _context.next) {
                                case 0:
                                    if (!(e.detail.errMsg == "getUserInfo:ok")) {
                                        _context.next = 5;
                                        break;
                                    }

                                    _context.next = 3;
                                    return _auth2.default.getUserinfo(e.detail);

                                case 3:
                                    _utils2.default.save('shareInfo', {
                                        course: this.courseInfo,
                                        path: 'pages/activity/bargain',
                                        id: this.ActBargainReg.id,
                                        type: 3,
                                        courseId: this.courseInfo.id
                                    });
                                    _wepy2.default.navigateTo({
                                        url: '/pages/home/share'
                                    });

                                case 5:
                                case "end":
                                    return _context.stop();
                            }
                        }
                    }, _callee, this);
                }));

                function createImg(_x) {
                    return _ref2.apply(this, arguments);
                }

                return createImg;
            }(),
            toshare: function toshare() {
                this.modalName = 'share';
            },
            tocut: function () {
                var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(e) {
                    return regeneratorRuntime.wrap(function _callee2$(_context2) {
                        while (1) {
                            switch (_context2.prev = _context2.next) {
                                case 0:
                                    if (!(e.detail.errMsg == "getUserInfo:ok")) {
                                        _context2.next = 4;
                                        break;
                                    }

                                    _context2.next = 3;
                                    return _auth2.default.getUserinfo(e.detail);

                                case 3:
                                    _wepy2.default.navigateTo({
                                        url: "/pages/detaile/detaile?id=" + this.courseInfo.id
                                    });

                                case 4:
                                case "end":
                                    return _context2.stop();
                            }
                        }
                    }, _callee2, this);
                }));

                function tocut(_x2) {
                    return _ref3.apply(this, arguments);
                }

                return tocut;
            }(),
            buy: function buy() {
                _wepy2.default.navigateTo({
                    url: "/pages/detaile/sureOrder?type=2&pid=" + this.info.reg.periodId + "&cid=" + this.info.reg.courseId + "&num=1&aid=" + this.info.regId + "&actpid=0"
                });
            },
            topay: function topay() {
                _wepy2.default.navigateTo({
                    url: "/pages/my/order?id=" + this.info.orderId
                });
            },
            onGotUserInfo: function () {
                var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(e) {
                    return regeneratorRuntime.wrap(function _callee3$(_context3) {
                        while (1) {
                            switch (_context3.prev = _context3.next) {
                                case 0:
                                    if (!(_wepy2.default.getStorageSync('mobile') == '' || !_wepy2.default.getStorageSync('mobile') || _wepy2.default.getStorageSync('isFans') != 1)) {
                                        _context3.next = 4;
                                        break;
                                    }

                                    _wepy2.default.navigateTo({
                                        url: "/pages/home/auth"
                                    });
                                    _context3.next = 9;
                                    break;

                                case 4:
                                    _context3.next = 6;
                                    return this.helpBargain();

                                case 6:
                                    _context3.next = 8;
                                    return this.load();

                                case 8:
                                    this.$apply();

                                case 9:
                                case "end":
                                    return _context3.stop();
                            }
                        }
                    }, _callee3, this);
                }));

                function onGotUserInfo(_x3) {
                    return _ref4.apply(this, arguments);
                }

                return onGotUserInfo;
            }()
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(Dialog, [{
        key: "onShareAppMessage",
        value: function onShareAppMessage(res) {
            if (res.from === 'button') {
                // 来自页面内转发按钮
                // console.log(res.target)
            }
            return {
                title: this.courseInfo.courseTittle,
                imageUrl: this.courseInfo.image,
                path: '/pages/activity/bargain?id=' + this.ActBargainReg.id + '&agentId=' + this.member.agentId
            };
        }
    }, {
        key: "onLoad",
        value: function () {
            var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4(opt) {
                return regeneratorRuntime.wrap(function _callee4$(_context4) {
                    while (1) {
                        switch (_context4.prev = _context4.next) {
                            case 0:
                                this.regId = opt.id || _wepy2.default.$instance.globalData.query.id;
                                this.routes = getCurrentPages();
                                _context4.next = 4;
                                return _auth2.default.login();

                            case 4:
                                this.member = _wepy2.default.getStorageSync('member');
                                _context4.next = 7;
                                return this.load();

                            case 7:
                                this.$apply();

                            case 8:
                            case "end":
                                return _context4.stop();
                        }
                    }
                }, _callee4, this);
            }));

            function onLoad(_x4) {
                return _ref5.apply(this, arguments);
            }

            return onLoad;
        }()
    }, {
        key: "helpBargain",
        value: function () {
            var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
                var res;
                return regeneratorRuntime.wrap(function _callee5$(_context5) {
                    while (1) {
                        switch (_context5.prev = _context5.next) {
                            case 0:
                                _context5.next = 2;
                                return _config2.default.helpBargain(this.regId);

                            case 2:
                                res = _context5.sent;

                            case 3:
                            case "end":
                                return _context5.stop();
                        }
                    }
                }, _callee5, this);
            }));

            function helpBargain() {
                return _ref6.apply(this, arguments);
            }

            return helpBargain;
        }()
    }, {
        key: "load",
        value: function () {
            var _ref7 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
                var _ref8, errcode, data;

                return regeneratorRuntime.wrap(function _callee6$(_context6) {
                    while (1) {
                        switch (_context6.prev = _context6.next) {
                            case 0:
                                _context6.next = 2;
                                return _config2.default.toCutDetai(this.regId);

                            case 2:
                                _ref8 = _context6.sent;
                                errcode = _ref8.errcode;
                                data = _ref8.data;

                                if (errcode == 200) {
                                    this.info = data;
                                    this.courseInfo = data.courseInfo;
                                    this.ActBargainReg = data.reg;
                                    console.log(this.ActBargainReg.invalidTime);
                                    this.bargainRecords = data.bargainRecords;
                                }

                            case 6:
                            case "end":
                                return _context6.stop();
                        }
                    }
                }, _callee6, this);
            }));

            function load() {
                return _ref7.apply(this, arguments);
            }

            return load;
        }()
    }]);

    return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/activity/bargain'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImJhcmdhaW4uanMiXSwibmFtZXMiOlsiRGlhbG9nIiwiZGF0YSIsImNsb3NlIiwiYWN0aXZlIiwicm91dGVzIiwicmVnSWQiLCJjb3Vyc2VJbmZvIiwiQWN0QmFyZ2FpblJlZyIsImludmFsaWRUaW1lIiwiYmFyZ2FpblJlY29yZHMiLCJkaiIsInBlcmNlbnQiLCJpbmZvIiwibW9kYWxOYW1lIiwic3RhdHVzIiwiYSIsImIiLCJjb25maWciLCJuYXZpZ2F0aW9uQmFyQmFja2dyb3VuZENvbG9yIiwibmF2aWdhdGlvbkJhclRpdGxlVGV4dCIsImNvbXBvbmVudHMiLCJjb250YWN0IiwiY29tcHV0ZWQiLCJjdXRQcmljZSIsImFjdCIsIl9wIiwiTGFuZyIsInN1bSIsImNvdXJzZVByaWNlIiwiY291cnNlTmV3UHJpY2UiLCJfc3AiLCJjdXRNaW5QcmljZSIsInBhcnNlSW50IiwibWV0aG9kcyIsImhpZGVNb2RhbCIsImNyZWF0ZUltZyIsImUiLCJkZXRhaWwiLCJlcnJNc2ciLCJhdXRoIiwiZ2V0VXNlcmluZm8iLCJzdG9yZSIsInNhdmUiLCJjb3Vyc2UiLCJwYXRoIiwiaWQiLCJ0eXBlIiwiY291cnNlSWQiLCJ3ZXB5IiwibmF2aWdhdGVUbyIsInVybCIsInRvc2hhcmUiLCJ0b2N1dCIsImJ1eSIsInJlZyIsInBlcmlvZElkIiwidG9wYXkiLCJvcmRlcklkIiwib25Hb3RVc2VySW5mbyIsImdldFN0b3JhZ2VTeW5jIiwiaGVscEJhcmdhaW4iLCJsb2FkIiwiJGFwcGx5IiwicmVzIiwiZnJvbSIsInRpdGxlIiwiY291cnNlVGl0dGxlIiwiaW1hZ2VVcmwiLCJpbWFnZSIsIm1lbWJlciIsImFnZW50SWQiLCJvcHQiLCIkaW5zdGFuY2UiLCJnbG9iYWxEYXRhIiwicXVlcnkiLCJnZXRDdXJyZW50UGFnZXMiLCJsb2dpbiIsInRvQ3V0RGV0YWkiLCJlcnJjb2RlIiwiY29uc29sZSIsImxvZyIsInBhZ2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUNJOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7Ozs7Ozs7Ozs7Ozs7SUFDcUJBLE07Ozs7Ozs7Ozs7Ozs7OzBMQUNqQkMsSSxHQUFPO0FBQ0hDLG1CQUFPLDBCQURKO0FBRUhDLG9CQUFRLElBRkw7QUFHSEMsb0JBQVEsQ0FITDtBQUlIQyxtQkFBTyxFQUpKO0FBS0hDLHdCQUFZLEVBTFQ7QUFNSEMsMkJBQWU7QUFDWEMsNkJBQWE7QUFERixhQU5aO0FBU0hDLDRCQUFnQixFQVRiO0FBVUhDLGdCQUFJLElBVkQ7QUFXSEMscUJBQVMsQ0FYTjtBQVlIQyxrQkFBTSxFQVpIO0FBYUhDLHVCQUFXLEVBYlI7QUFjSEMsb0JBQVE7QUFDSixtQkFBRztBQUNDQyx1QkFBRyxLQURKO0FBRUNDLHVCQUFHO0FBRkosaUJBREM7QUFLSixtQkFBRztBQUNDRCx1QkFBRyxNQURKO0FBRUNDLHVCQUFHO0FBRkosaUJBTEM7QUFTSixtQkFBRztBQUNDRCx1QkFBRyxNQURKO0FBRUNDLHVCQUFHO0FBRkosaUJBVEM7QUFhSixtQkFBRztBQUNDRCx1QkFBRyxLQURKO0FBRUNDLHVCQUFHO0FBRko7QUFiQztBQWRMLFMsUUFpQ1BDLE0sR0FBUztBQUNMQywwQ0FBOEIsU0FEekI7QUFFTEMsb0NBQXdCLElBRm5CO0FBR0wsK0JBQW1CO0FBQ2YsK0JBQWU7QUFEQTtBQUhkLFMsUUFPVEMsVSxHQUFhO0FBQ1RDO0FBRFMsUyxRQUdiQyxRLEdBQVc7QUFDUEMsb0JBRE8sc0JBQ0k7QUFDUCxvQkFBSSxLQUFLaEIsYUFBVCxFQUF3QjtBQUNwQix3QkFBSWlCLE1BQU0sS0FBS2pCLGFBQWY7QUFDQSx3QkFBSWtCLEtBQUtDLGVBQUtDLEdBQUwsQ0FBUyxDQUFDSCxJQUFJSSxXQUFMLEVBQWtCLENBQUNKLElBQUlLLGNBQXZCLENBQVQsRUFBaUQsQ0FBakQsQ0FBVDtBQUFBLHdCQUNJQyxNQUFNSixlQUFLQyxHQUFMLENBQVMsQ0FBQ0gsSUFBSUksV0FBSixHQUFpQkosSUFBSU8sV0FBdEIsQ0FBVCxFQUE2QyxDQUE3QyxDQURWO0FBRUEseUJBQUtwQixPQUFMLEdBQWVxQixTQUFTUCxLQUFLSyxHQUFMLEdBQVcsR0FBcEIsQ0FBZjtBQUNBLDJCQUFPTCxFQUFQO0FBQ0g7QUFDSjtBQVRNLFMsUUE4QlhRLE8sR0FBVTtBQUNOQyxxQkFETSx1QkFDTTtBQUNSLHFCQUFLckIsU0FBTCxHQUFpQixFQUFqQjtBQUNILGFBSEs7QUFJQXNCLHFCQUpBO0FBQUEscUdBSVVDLENBSlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBDQUtFQSxFQUFFQyxNQUFGLENBQVNDLE1BQVQsSUFBbUIsZ0JBTHJCO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUEsMkNBTVFDLGVBQUtDLFdBQUwsQ0FBaUJKLEVBQUVDLE1BQW5CLENBTlI7O0FBQUE7QUFPRUksb0RBQU1DLElBQU4sQ0FBVyxXQUFYLEVBQXdCO0FBQ3BCQyxnREFBUSxLQUFLckMsVUFETztBQUVwQnNDLDhDQUFNLHdCQUZjO0FBR3BCQyw0Q0FBSSxLQUFLdEMsYUFBTCxDQUFtQnNDLEVBSEg7QUFJcEJDLDhDQUFLLENBSmU7QUFLcEJDLGtEQUFTLEtBQUt6QyxVQUFMLENBQWdCdUM7QUFMTCxxQ0FBeEI7QUFPQUcsbURBQUtDLFVBQUwsQ0FBZ0I7QUFDWkMsNkNBQUs7QUFETyxxQ0FBaEI7O0FBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFtQk5DLG1CQW5CTSxxQkFtQkk7QUFDTixxQkFBS3RDLFNBQUwsR0FBaUIsT0FBakI7QUFDSCxhQXJCSztBQXNCQXVDLGlCQXRCQTtBQUFBLHNHQXNCTWhCLENBdEJOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQ0F1QkVBLEVBQUVDLE1BQUYsQ0FBU0MsTUFBVCxJQUFtQixnQkF2QnJCO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUEsMkNBd0JRQyxlQUFLQyxXQUFMLENBQWlCSixFQUFFQyxNQUFuQixDQXhCUjs7QUFBQTtBQXlCRVcsbURBQUtDLFVBQUwsQ0FBZ0I7QUFDWkMsNEVBQWtDLEtBQUs1QyxVQUFMLENBQWdCdUM7QUFEdEMscUNBQWhCOztBQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQThCTlEsZUE5Qk0saUJBOEJBO0FBQ0ZMLCtCQUFLQyxVQUFMLENBQWdCO0FBQ1pDLGtFQUE0QyxLQUFLdEMsSUFBTCxDQUFVMEMsR0FBVixDQUFjQyxRQUExRCxhQUEwRSxLQUFLM0MsSUFBTCxDQUFVMEMsR0FBVixDQUFjUCxRQUF4RixtQkFBOEcsS0FBS25DLElBQUwsQ0FBVVAsS0FBeEg7QUFEWSxpQkFBaEI7QUFHSCxhQWxDSztBQW1DTm1ELGlCQW5DTSxtQkFtQ0U7QUFDSlIsK0JBQUtDLFVBQUwsQ0FBZ0I7QUFDWkMsaURBQTJCLEtBQUt0QyxJQUFMLENBQVU2QztBQUR6QixpQkFBaEI7QUFHSCxhQXZDSztBQXdDQUMseUJBeENBO0FBQUEsc0dBd0NjdEIsQ0F4Q2Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBDQXlDRVksZUFBS1csY0FBTCxDQUFvQixRQUFwQixLQUFpQyxFQUFqQyxJQUF1QyxDQUFDWCxlQUFLVyxjQUFMLENBQW9CLFFBQXBCLENBQXhDLElBQXlFWCxlQUFLVyxjQUFMLENBQW9CLFFBQXBCLEtBQWlDLENBekM1RztBQUFBO0FBQUE7QUFBQTs7QUEwQ0VYLG1EQUFLQyxVQUFMLENBQWdCO0FBQ1pDO0FBRFkscUNBQWhCO0FBMUNGO0FBQUE7O0FBQUE7QUFBQTtBQUFBLDJDQThDUSxLQUFLVSxXQUFMLEVBOUNSOztBQUFBO0FBQUE7QUFBQSwyQ0ErQ1EsS0FBS0MsSUFBTCxFQS9DUjs7QUFBQTtBQWdERSx5Q0FBS0MsTUFBTDs7QUFoREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQSxTOzs7OzswQ0FuQlFDLEcsRUFBSztBQUNuQixnQkFBSUEsSUFBSUMsSUFBSixLQUFhLFFBQWpCLEVBQTJCO0FBQ3ZCO0FBQ0E7QUFDSDtBQUNELG1CQUFPO0FBQ0hDLHVCQUFPLEtBQUszRCxVQUFMLENBQWdCNEQsWUFEcEI7QUFFSEMsMEJBQVUsS0FBSzdELFVBQUwsQ0FBZ0I4RCxLQUZ2QjtBQUdIeEIsc0JBQU0sZ0NBQWdDLEtBQUtyQyxhQUFMLENBQW1Cc0MsRUFBbkQsR0FBd0QsV0FBeEQsR0FBc0UsS0FBS3dCLE1BQUwsQ0FBWUM7QUFIckYsYUFBUDtBQUtIOzs7O2tHQUNZQyxHOzs7OztBQUNULHFDQUFLbEUsS0FBTCxHQUFha0UsSUFBSTFCLEVBQUosSUFBVUcsZUFBS3dCLFNBQUwsQ0FBZUMsVUFBZixDQUEwQkMsS0FBMUIsQ0FBZ0M3QixFQUF2RDtBQUNBLHFDQUFLekMsTUFBTCxHQUFjdUUsaUJBQWQ7O3VDQUNNcEMsZUFBS3FDLEtBQUwsRTs7O0FBQ04scUNBQUtQLE1BQUwsR0FBY3JCLGVBQUtXLGNBQUwsQ0FBb0IsUUFBcEIsQ0FBZDs7dUNBQ00sS0FBS0UsSUFBTCxFOzs7QUFDTixxQ0FBS0MsTUFBTDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7dUNBdURnQjdDLGlCQUFPMkMsV0FBUCxDQUFtQixLQUFLdkQsS0FBeEIsQzs7O0FBQVowRCxtQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3VDQU1NOUMsaUJBQU80RCxVQUFQLENBQWtCLEtBQUt4RSxLQUF2QixDOzs7O0FBRk55RSx1QyxTQUFBQSxPO0FBQ0E3RSxvQyxTQUFBQSxJOztBQUVKLG9DQUFJNkUsV0FBVyxHQUFmLEVBQW9CO0FBQ2hCLHlDQUFLbEUsSUFBTCxHQUFZWCxJQUFaO0FBQ0EseUNBQUtLLFVBQUwsR0FBa0JMLEtBQUtLLFVBQXZCO0FBQ0EseUNBQUtDLGFBQUwsR0FBcUJOLEtBQUtxRCxHQUExQjtBQUNBeUIsNENBQVFDLEdBQVIsQ0FBWSxLQUFLekUsYUFBTCxDQUFtQkMsV0FBL0I7QUFDQSx5Q0FBS0MsY0FBTCxHQUFzQlIsS0FBS1EsY0FBM0I7QUFDSDs7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQTVJMkJ1QyxlQUFLaUMsSTs7a0JBQXBCakYsTSIsImZpbGUiOiJiYXJnYWluLmpzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbiAgICBpbXBvcnQgd2VweSBmcm9tIFwid2VweVwiXHJcbiAgICBpbXBvcnQgY29uZmlnIGZyb20gXCJAL2FwaS9jb25maWdcIlxyXG4gICAgaW1wb3J0IGF1dGggZnJvbSBcIkAvYXBpL2F1dGhcIlxyXG4gICAgaW1wb3J0IExhbmcgZnJvbSBcIkAvdXRpbHMvTGFuZ1wiXHJcbiAgICBpbXBvcnQgc3RvcmUgZnJvbSBcIkAvc3RvcmUvdXRpbHNcIlxyXG4gICAgaW1wb3J0IGNvbnRhY3QgZnJvbSBcIkAvY29tcG9uZW50cy9jb21tb24vY29udGFjdFwiXHJcbiAgICBleHBvcnQgZGVmYXVsdCBjbGFzcyBEaWFsb2cgZXh0ZW5kcyB3ZXB5LnBhZ2Uge1xyXG4gICAgICAgIGRhdGEgPSB7XHJcbiAgICAgICAgICAgIGNsb3NlOiBcIi9zdGF0aWMvaW1hZ2VzL2Nsb3NlLnBuZ1wiLFxyXG4gICAgICAgICAgICBhY3RpdmU6IHRydWUsXHJcbiAgICAgICAgICAgIHJvdXRlczogMCxcclxuICAgICAgICAgICAgcmVnSWQ6ICcnLFxyXG4gICAgICAgICAgICBjb3Vyc2VJbmZvOiB7fSxcclxuICAgICAgICAgICAgQWN0QmFyZ2FpblJlZzoge1xyXG4gICAgICAgICAgICAgICAgaW52YWxpZFRpbWU6ICcnXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGJhcmdhaW5SZWNvcmRzOiBbXSxcclxuICAgICAgICAgICAgZGo6IDMwMDAsXHJcbiAgICAgICAgICAgIHBlcmNlbnQ6IDAsXHJcbiAgICAgICAgICAgIGluZm86IHt9LFxyXG4gICAgICAgICAgICBtb2RhbE5hbWU6ICcnLFxyXG4gICAgICAgICAgICBzdGF0dXM6IHtcclxuICAgICAgICAgICAgICAgIDA6IHtcclxuICAgICAgICAgICAgICAgICAgICBhOiAn56CN5Lu35LitJyxcclxuICAgICAgICAgICAgICAgICAgICBiOiAnJ1xyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIDE6IHtcclxuICAgICAgICAgICAgICAgICAgICBhOiAn56CN5Lu35a6M5oiQJyxcclxuICAgICAgICAgICAgICAgICAgICBiOiAn5b6F5pSv5LuYJ1xyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIDI6IHtcclxuICAgICAgICAgICAgICAgICAgICBhOiAn56CN5Lu35a6M5oiQJyxcclxuICAgICAgICAgICAgICAgICAgICBiOiAn5bey5pSv5LuYJ1xyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIDM6IHtcclxuICAgICAgICAgICAgICAgICAgICBhOiAn5bey6L+H5pyfJyxcclxuICAgICAgICAgICAgICAgICAgICBiOiAn56CN5Lu357uT5p2fJ1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuICAgICAgICBjb25maWcgPSB7XHJcbiAgICAgICAgICAgIG5hdmlnYXRpb25CYXJCYWNrZ3JvdW5kQ29sb3I6ICcjMjE1RTIxJyxcclxuICAgICAgICAgICAgbmF2aWdhdGlvbkJhclRpdGxlVGV4dDogJ+egjeS7tycsXHJcbiAgICAgICAgICAgIFwidXNpbmdDb21wb25lbnRzXCI6IHtcclxuICAgICAgICAgICAgICAgIFwibC1jb3VudGRvd25cIjogXCIuLi8uLi9jb21wb25lbnRzL2NvdW50ZG93bi9pbmRleFwiXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgY29tcG9uZW50cyA9IHtcclxuICAgICAgICAgICAgY29udGFjdFxyXG4gICAgICAgIH1cclxuICAgICAgICBjb21wdXRlZCA9IHtcclxuICAgICAgICAgICAgY3V0UHJpY2UoKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5BY3RCYXJnYWluUmVnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGFjdCA9IHRoaXMuQWN0QmFyZ2FpblJlZ1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBfcCA9IExhbmcuc3VtKFthY3QuY291cnNlUHJpY2UsIC1hY3QuY291cnNlTmV3UHJpY2VdLCAyKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgX3NwID0gTGFuZy5zdW0oW2FjdC5jb3Vyc2VQcmljZSAtYWN0LmN1dE1pblByaWNlXSwgMilcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnBlcmNlbnQgPSBwYXJzZUludChfcCAvIF9zcCAqIDEwMClcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gX3BcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBvblNoYXJlQXBwTWVzc2FnZShyZXMpIHtcclxuICAgICAgICAgICAgaWYgKHJlcy5mcm9tID09PSAnYnV0dG9uJykge1xyXG4gICAgICAgICAgICAgICAgLy8g5p2l6Ieq6aG16Z2i5YaF6L2s5Y+R5oyJ6ZKuXHJcbiAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhyZXMudGFyZ2V0KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICB0aXRsZTogdGhpcy5jb3Vyc2VJbmZvLmNvdXJzZVRpdHRsZSxcclxuICAgICAgICAgICAgICAgIGltYWdlVXJsOiB0aGlzLmNvdXJzZUluZm8uaW1hZ2UsXHJcbiAgICAgICAgICAgICAgICBwYXRoOiAnL3BhZ2VzL2FjdGl2aXR5L2JhcmdhaW4/aWQ9JyArIHRoaXMuQWN0QmFyZ2FpblJlZy5pZCArICcmYWdlbnRJZD0nICsgdGhpcy5tZW1iZXIuYWdlbnRJZFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGFzeW5jIG9uTG9hZChvcHQpIHtcclxuICAgICAgICAgICAgdGhpcy5yZWdJZCA9IG9wdC5pZCB8fCB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnF1ZXJ5LmlkXHJcbiAgICAgICAgICAgIHRoaXMucm91dGVzID0gZ2V0Q3VycmVudFBhZ2VzKClcclxuICAgICAgICAgICAgYXdhaXQgYXV0aC5sb2dpbigpXHJcbiAgICAgICAgICAgIHRoaXMubWVtYmVyID0gd2VweS5nZXRTdG9yYWdlU3luYygnbWVtYmVyJyk7XHJcbiAgICAgICAgICAgIGF3YWl0IHRoaXMubG9hZCgpXHJcbiAgICAgICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgICB9XHJcbiAgICAgICAgbWV0aG9kcyA9IHtcclxuICAgICAgICAgICAgaGlkZU1vZGFsKCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RhbE5hbWUgPSAnJ1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBhc3luYyBjcmVhdGVJbWcoZSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKGUuZGV0YWlsLmVyck1zZyA9PSBcImdldFVzZXJJbmZvOm9rXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICBhd2FpdCBhdXRoLmdldFVzZXJpbmZvKGUuZGV0YWlsKVxyXG4gICAgICAgICAgICAgICAgICAgIHN0b3JlLnNhdmUoJ3NoYXJlSW5mbycsIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY291cnNlOiB0aGlzLmNvdXJzZUluZm8sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhdGg6ICdwYWdlcy9hY3Rpdml0eS9iYXJnYWluJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IHRoaXMuQWN0QmFyZ2FpblJlZy5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6MyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvdXJzZUlkOnRoaXMuY291cnNlSW5mby5pZFxyXG4gICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgd2VweS5uYXZpZ2F0ZVRvKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdXJsOiAnL3BhZ2VzL2hvbWUvc2hhcmUnXHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHRvc2hhcmUoKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGFsTmFtZSA9ICdzaGFyZSdcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgYXN5bmMgdG9jdXQoZSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKGUuZGV0YWlsLmVyck1zZyA9PSBcImdldFVzZXJJbmZvOm9rXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICBhd2FpdCBhdXRoLmdldFVzZXJpbmZvKGUuZGV0YWlsKVxyXG4gICAgICAgICAgICAgICAgICAgIHdlcHkubmF2aWdhdGVUbyh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHVybDogYC9wYWdlcy9kZXRhaWxlL2RldGFpbGU/aWQ9JHt0aGlzLmNvdXJzZUluZm8uaWR9YFxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBidXkoKSB7XHJcbiAgICAgICAgICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICAgICAgICAgIHVybDogYC9wYWdlcy9kZXRhaWxlL3N1cmVPcmRlcj90eXBlPTImcGlkPSR7dGhpcy5pbmZvLnJlZy5wZXJpb2RJZH0mY2lkPSR7dGhpcy5pbmZvLnJlZy5jb3Vyc2VJZH0mbnVtPTEmYWlkPSR7dGhpcy5pbmZvLnJlZ0lkfSZhY3RwaWQ9MGBcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB0b3BheSgpIHtcclxuICAgICAgICAgICAgICAgIHdlcHkubmF2aWdhdGVUbyh7XHJcbiAgICAgICAgICAgICAgICAgICAgdXJsOiBgL3BhZ2VzL215L29yZGVyP2lkPSR7dGhpcy5pbmZvLm9yZGVySWR9YFxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGFzeW5jIG9uR290VXNlckluZm8oZSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHdlcHkuZ2V0U3RvcmFnZVN5bmMoJ21vYmlsZScpID09ICcnIHx8ICF3ZXB5LmdldFN0b3JhZ2VTeW5jKCdtb2JpbGUnKSB8fCB3ZXB5LmdldFN0b3JhZ2VTeW5jKCdpc0ZhbnMnKSAhPSAxKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgd2VweS5uYXZpZ2F0ZVRvKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdXJsOiBgL3BhZ2VzL2hvbWUvYXV0aGBcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYXdhaXQgdGhpcy5oZWxwQmFyZ2FpbigpXHJcbiAgICAgICAgICAgICAgICAgICAgYXdhaXQgdGhpcy5sb2FkKClcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgfTtcclxuICAgICAgICBhc3luYyBoZWxwQmFyZ2FpbigpIHtcclxuICAgICAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGNvbmZpZy5oZWxwQmFyZ2Fpbih0aGlzLnJlZ0lkKVxyXG4gICAgICAgIH1cclxuICAgICAgICBhc3luYyBsb2FkKCkge1xyXG4gICAgICAgICAgICBsZXQge1xyXG4gICAgICAgICAgICAgICAgZXJyY29kZSxcclxuICAgICAgICAgICAgICAgIGRhdGFcclxuICAgICAgICAgICAgfSA9IGF3YWl0IGNvbmZpZy50b0N1dERldGFpKHRoaXMucmVnSWQpXHJcbiAgICAgICAgICAgIGlmIChlcnJjb2RlID09IDIwMCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5pbmZvID0gZGF0YVxyXG4gICAgICAgICAgICAgICAgdGhpcy5jb3Vyc2VJbmZvID0gZGF0YS5jb3Vyc2VJbmZvXHJcbiAgICAgICAgICAgICAgICB0aGlzLkFjdEJhcmdhaW5SZWcgPSBkYXRhLnJlZ1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2codGhpcy5BY3RCYXJnYWluUmVnLmludmFsaWRUaW1lKVxyXG4gICAgICAgICAgICAgICAgdGhpcy5iYXJnYWluUmVjb3JkcyA9IGRhdGEuYmFyZ2FpblJlY29yZHNcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuIl19