"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

var _Lang = require('./../../utils/Lang.js');

var _Lang2 = _interopRequireDefault(_Lang);

var _utils = require('./../../store/utils.js');

var _utils2 = _interopRequireDefault(_utils);

var _contact = require('./../../components/common/contact.js');

var _contact2 = _interopRequireDefault(_contact);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
    _inherits(Dialog, _wepy$page);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.data = {
            close: "/static/images/close.png",
            active: true,
            routes: 0,
            regId: '',
            courseInfo: {},
            ActBargainReg: {
                invalidTime: ''
            },
            bargainRecords: [],
            dj: 3000,
            percent: 0,
            info: {},
            modalName: '',
            status: {
                0: {
                    a: '砍价中',
                    b: ''
                },
                1: {
                    a: '砍价完成',
                    b: '待支付'
                },
                2: {
                    a: '砍价完成',
                    b: '已支付'
                },
                3: {
                    a: '已过期',
                    b: '砍价结束'
                }
            }
        }, _this.config = {
            navigationBarBackgroundColor: '#ed1c24',
            navigationBarTitleText: '砍价',
            "usingComponents": {
                "l-countdown": "../../components/countdown/index"
            }
        }, _this.components = {
            contact: _contact2.default
        }, _this.computed = {
            cutPrice: function cutPrice() {
                if (this.ActBargainReg) {
                    var act = this.ActBargainReg;
                    var _p = _Lang2.default.sum([act.coursePrice, -act.courseNewPrice], 2),
                        _sp = _Lang2.default.sum([act.coursePrice - act.cutMinPrice], 2);
                    this.percent = parseInt(_p / _sp * 100);
                    return _p;
                }
            }
        }, _this.methods = {
            hideModal: function hideModal() {
                this.modalName = '';
            },
            createImg: function () {
                var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(e) {
                    return regeneratorRuntime.wrap(function _callee$(_context) {
                        while (1) {
                            switch (_context.prev = _context.next) {
                                case 0:
                                    if (!(e.detail.errMsg == "getUserInfo:ok")) {
                                        _context.next = 5;
                                        break;
                                    }

                                    _context.next = 3;
                                    return _auth2.default.getUserinfo(e.detail);

                                case 3:
                                    _utils2.default.save('shareInfo', {
                                        course: this.courseInfo,
                                        path: 'pages/activity/bargain',
                                        id: this.ActBargainReg.id,
                                        type: 3,
                                        courseId: this.courseInfo.id
                                    });
                                    _wepy2.default.navigateTo({
                                        url: '/pages/home/share'
                                    });

                                case 5:
                                case "end":
                                    return _context.stop();
                            }
                        }
                    }, _callee, this);
                }));

                function createImg(_x) {
                    return _ref2.apply(this, arguments);
                }

                return createImg;
            }(),
            toshare: function toshare() {
                this.modalName = 'share';
            },
            tocut: function () {
                var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(e) {
                    return regeneratorRuntime.wrap(function _callee2$(_context2) {
                        while (1) {
                            switch (_context2.prev = _context2.next) {
                                case 0:
                                    if (!(e.detail.errMsg == "getUserInfo:ok")) {
                                        _context2.next = 4;
                                        break;
                                    }

                                    _context2.next = 3;
                                    return _auth2.default.getUserinfo(e.detail);

                                case 3:
                                    _wepy2.default.navigateTo({
                                        url: "/pages/detaile/detaile?id=" + this.courseInfo.id
                                    });

                                case 4:
                                case "end":
                                    return _context2.stop();
                            }
                        }
                    }, _callee2, this);
                }));

                function tocut(_x2) {
                    return _ref3.apply(this, arguments);
                }

                return tocut;
            }(),
            buy: function buy() {
                _wepy2.default.navigateTo({
                    url: "/pages/detaile/sureOrder?type=2&pid=" + this.info.reg.periodId + "&cid=" + this.info.reg.courseId + "&num=1&aid=" + this.info.regId + "&actpid=0"
                });
            },
            topay: function topay() {
                _wepy2.default.navigateTo({
                    url: "/pages/my/order?id=" + this.info.orderId
                });
            },
            onGotUserInfo: function () {
                var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(e) {
                    return regeneratorRuntime.wrap(function _callee3$(_context3) {
                        while (1) {
                            switch (_context3.prev = _context3.next) {
                                case 0:
                                    if (!(_wepy2.default.getStorageSync('mobile') == '' || !_wepy2.default.getStorageSync('mobile') || _wepy2.default.getStorageSync('isFans') != 1)) {
                                        _context3.next = 4;
                                        break;
                                    }

                                    _wepy2.default.navigateTo({
                                        url: "/pages/home/auth"
                                    });
                                    _context3.next = 9;
                                    break;

                                case 4:
                                    _context3.next = 6;
                                    return this.helpBargain();

                                case 6:
                                    _context3.next = 8;
                                    return this.load();

                                case 8:
                                    this.$apply();

                                case 9:
                                case "end":
                                    return _context3.stop();
                            }
                        }
                    }, _callee3, this);
                }));

                function onGotUserInfo(_x3) {
                    return _ref4.apply(this, arguments);
                }

                return onGotUserInfo;
            }()
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(Dialog, [{
        key: "onShareAppMessage",
        value: function onShareAppMessage(res) {
            if (res.from === 'button') {
                // 来自页面内转发按钮
                // console.log(res.target)
            }
            return {
                title: this.courseInfo.courseTittle,
                imageUrl: this.courseInfo.image,
                path: '/pages/activity/bargain?id=' + this.ActBargainReg.id + '&agentId=' + this.member.agentId
            };
        }
    }, {
        key: "onLoad",
        value: function () {
            var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4(opt) {
                return regeneratorRuntime.wrap(function _callee4$(_context4) {
                    while (1) {
                        switch (_context4.prev = _context4.next) {
                            case 0:
                                this.regId = opt.id || opt.scene;
                                this.routes = getCurrentPages();
                                _context4.next = 4;
                                return _auth2.default.login();

                            case 4:
                                this.member = _wepy2.default.getStorageSync('member');
                                _context4.next = 7;
                                return this.load();

                            case 7:
                                this.$apply();

                            case 8:
                            case "end":
                                return _context4.stop();
                        }
                    }
                }, _callee4, this);
            }));

            function onLoad(_x4) {
                return _ref5.apply(this, arguments);
            }

            return onLoad;
        }()
    }, {
        key: "helpBargain",
        value: function () {
            var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
                var res;
                return regeneratorRuntime.wrap(function _callee5$(_context5) {
                    while (1) {
                        switch (_context5.prev = _context5.next) {
                            case 0:
                                _context5.next = 2;
                                return _config2.default.helpBargain(this.regId);

                            case 2:
                                res = _context5.sent;

                            case 3:
                            case "end":
                                return _context5.stop();
                        }
                    }
                }, _callee5, this);
            }));

            function helpBargain() {
                return _ref6.apply(this, arguments);
            }

            return helpBargain;
        }()
    }, {
        key: "load",
        value: function () {
            var _ref7 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
                var _ref8, errcode, data;

                return regeneratorRuntime.wrap(function _callee6$(_context6) {
                    while (1) {
                        switch (_context6.prev = _context6.next) {
                            case 0:
                                _context6.next = 2;
                                return _config2.default.toCutDetai(this.regId);

                            case 2:
                                _ref8 = _context6.sent;
                                errcode = _ref8.errcode;
                                data = _ref8.data;

                                if (errcode == 200) {
                                    this.info = data;
                                    this.courseInfo = data.courseInfo;
                                    this.ActBargainReg = data.reg;
                                    console.log(this.ActBargainReg.invalidTime);
                                    this.bargainRecords = data.bargainRecords;
                                }

                            case 6:
                            case "end":
                                return _context6.stop();
                        }
                    }
                }, _callee6, this);
            }));

            function load() {
                return _ref7.apply(this, arguments);
            }

            return load;
        }()
    }]);

    return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/activity/bargain'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImJhcmdhaW4uanMiXSwibmFtZXMiOlsiRGlhbG9nIiwiZGF0YSIsImNsb3NlIiwiYWN0aXZlIiwicm91dGVzIiwicmVnSWQiLCJjb3Vyc2VJbmZvIiwiQWN0QmFyZ2FpblJlZyIsImludmFsaWRUaW1lIiwiYmFyZ2FpblJlY29yZHMiLCJkaiIsInBlcmNlbnQiLCJpbmZvIiwibW9kYWxOYW1lIiwic3RhdHVzIiwiYSIsImIiLCJjb25maWciLCJuYXZpZ2F0aW9uQmFyQmFja2dyb3VuZENvbG9yIiwibmF2aWdhdGlvbkJhclRpdGxlVGV4dCIsImNvbXBvbmVudHMiLCJjb250YWN0IiwiY29tcHV0ZWQiLCJjdXRQcmljZSIsImFjdCIsIl9wIiwiTGFuZyIsInN1bSIsImNvdXJzZVByaWNlIiwiY291cnNlTmV3UHJpY2UiLCJfc3AiLCJjdXRNaW5QcmljZSIsInBhcnNlSW50IiwibWV0aG9kcyIsImhpZGVNb2RhbCIsImNyZWF0ZUltZyIsImUiLCJkZXRhaWwiLCJlcnJNc2ciLCJhdXRoIiwiZ2V0VXNlcmluZm8iLCJzdG9yZSIsInNhdmUiLCJjb3Vyc2UiLCJwYXRoIiwiaWQiLCJ0eXBlIiwiY291cnNlSWQiLCJ3ZXB5IiwibmF2aWdhdGVUbyIsInVybCIsInRvc2hhcmUiLCJ0b2N1dCIsImJ1eSIsInJlZyIsInBlcmlvZElkIiwidG9wYXkiLCJvcmRlcklkIiwib25Hb3RVc2VySW5mbyIsImdldFN0b3JhZ2VTeW5jIiwiaGVscEJhcmdhaW4iLCJsb2FkIiwiJGFwcGx5IiwicmVzIiwiZnJvbSIsInRpdGxlIiwiY291cnNlVGl0dGxlIiwiaW1hZ2VVcmwiLCJpbWFnZSIsIm1lbWJlciIsImFnZW50SWQiLCJvcHQiLCJzY2VuZSIsImdldEN1cnJlbnRQYWdlcyIsImxvZ2luIiwidG9DdXREZXRhaSIsImVycmNvZGUiLCJjb25zb2xlIiwibG9nIiwicGFnZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQ0k7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7Ozs7Ozs7Ozs7OztJQUNxQkEsTTs7Ozs7Ozs7Ozs7Ozs7MExBQ2pCQyxJLEdBQU87QUFDSEMsbUJBQU8sMEJBREo7QUFFSEMsb0JBQVEsSUFGTDtBQUdIQyxvQkFBUSxDQUhMO0FBSUhDLG1CQUFPLEVBSko7QUFLSEMsd0JBQVksRUFMVDtBQU1IQywyQkFBZTtBQUNYQyw2QkFBYTtBQURGLGFBTlo7QUFTSEMsNEJBQWdCLEVBVGI7QUFVSEMsZ0JBQUksSUFWRDtBQVdIQyxxQkFBUyxDQVhOO0FBWUhDLGtCQUFNLEVBWkg7QUFhSEMsdUJBQVcsRUFiUjtBQWNIQyxvQkFBUTtBQUNKLG1CQUFHO0FBQ0NDLHVCQUFHLEtBREo7QUFFQ0MsdUJBQUc7QUFGSixpQkFEQztBQUtKLG1CQUFHO0FBQ0NELHVCQUFHLE1BREo7QUFFQ0MsdUJBQUc7QUFGSixpQkFMQztBQVNKLG1CQUFHO0FBQ0NELHVCQUFHLE1BREo7QUFFQ0MsdUJBQUc7QUFGSixpQkFUQztBQWFKLG1CQUFHO0FBQ0NELHVCQUFHLEtBREo7QUFFQ0MsdUJBQUc7QUFGSjtBQWJDO0FBZEwsUyxRQWlDUEMsTSxHQUFTO0FBQ0xDLDBDQUE4QixTQUR6QjtBQUVMQyxvQ0FBd0IsSUFGbkI7QUFHTCwrQkFBbUI7QUFDZiwrQkFBZTtBQURBO0FBSGQsUyxRQU9UQyxVLEdBQWE7QUFDVEM7QUFEUyxTLFFBR2JDLFEsR0FBVztBQUNQQyxvQkFETyxzQkFDSTtBQUNQLG9CQUFJLEtBQUtoQixhQUFULEVBQXdCO0FBQ3BCLHdCQUFJaUIsTUFBTSxLQUFLakIsYUFBZjtBQUNBLHdCQUFJa0IsS0FBS0MsZUFBS0MsR0FBTCxDQUFTLENBQUNILElBQUlJLFdBQUwsRUFBa0IsQ0FBQ0osSUFBSUssY0FBdkIsQ0FBVCxFQUFpRCxDQUFqRCxDQUFUO0FBQUEsd0JBQ0lDLE1BQU1KLGVBQUtDLEdBQUwsQ0FBUyxDQUFDSCxJQUFJSSxXQUFKLEdBQWlCSixJQUFJTyxXQUF0QixDQUFULEVBQTZDLENBQTdDLENBRFY7QUFFQSx5QkFBS3BCLE9BQUwsR0FBZXFCLFNBQVNQLEtBQUtLLEdBQUwsR0FBVyxHQUFwQixDQUFmO0FBQ0EsMkJBQU9MLEVBQVA7QUFDSDtBQUNKO0FBVE0sUyxRQThCWFEsTyxHQUFVO0FBQ05DLHFCQURNLHVCQUNNO0FBQ1IscUJBQUtyQixTQUFMLEdBQWlCLEVBQWpCO0FBQ0gsYUFISztBQUlBc0IscUJBSkE7QUFBQSxxR0FJVUMsQ0FKVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMENBS0VBLEVBQUVDLE1BQUYsQ0FBU0MsTUFBVCxJQUFtQixnQkFMckI7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQSwyQ0FNUUMsZUFBS0MsV0FBTCxDQUFpQkosRUFBRUMsTUFBbkIsQ0FOUjs7QUFBQTtBQU9FSSxvREFBTUMsSUFBTixDQUFXLFdBQVgsRUFBd0I7QUFDcEJDLGdEQUFRLEtBQUtyQyxVQURPO0FBRXBCc0MsOENBQU0sd0JBRmM7QUFHcEJDLDRDQUFJLEtBQUt0QyxhQUFMLENBQW1Cc0MsRUFISDtBQUlwQkMsOENBQUssQ0FKZTtBQUtwQkMsa0RBQVMsS0FBS3pDLFVBQUwsQ0FBZ0J1QztBQUxMLHFDQUF4QjtBQU9BRyxtREFBS0MsVUFBTCxDQUFnQjtBQUNaQyw2Q0FBSztBQURPLHFDQUFoQjs7QUFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQW1CTkMsbUJBbkJNLHFCQW1CSTtBQUNOLHFCQUFLdEMsU0FBTCxHQUFpQixPQUFqQjtBQUNILGFBckJLO0FBc0JBdUMsaUJBdEJBO0FBQUEsc0dBc0JNaEIsQ0F0Qk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBDQXVCRUEsRUFBRUMsTUFBRixDQUFTQyxNQUFULElBQW1CLGdCQXZCckI7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQSwyQ0F3QlFDLGVBQUtDLFdBQUwsQ0FBaUJKLEVBQUVDLE1BQW5CLENBeEJSOztBQUFBO0FBeUJFVyxtREFBS0MsVUFBTCxDQUFnQjtBQUNaQyw0RUFBa0MsS0FBSzVDLFVBQUwsQ0FBZ0J1QztBQUR0QyxxQ0FBaEI7O0FBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBOEJOUSxlQTlCTSxpQkE4QkE7QUFDRkwsK0JBQUtDLFVBQUwsQ0FBZ0I7QUFDWkMsa0VBQTRDLEtBQUt0QyxJQUFMLENBQVUwQyxHQUFWLENBQWNDLFFBQTFELGFBQTBFLEtBQUszQyxJQUFMLENBQVUwQyxHQUFWLENBQWNQLFFBQXhGLG1CQUE4RyxLQUFLbkMsSUFBTCxDQUFVUCxLQUF4SDtBQURZLGlCQUFoQjtBQUdILGFBbENLO0FBbUNObUQsaUJBbkNNLG1CQW1DRTtBQUNKUiwrQkFBS0MsVUFBTCxDQUFnQjtBQUNaQyxpREFBMkIsS0FBS3RDLElBQUwsQ0FBVTZDO0FBRHpCLGlCQUFoQjtBQUdILGFBdkNLO0FBd0NBQyx5QkF4Q0E7QUFBQSxzR0F3Q2N0QixDQXhDZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMENBeUNFWSxlQUFLVyxjQUFMLENBQW9CLFFBQXBCLEtBQWlDLEVBQWpDLElBQXVDLENBQUNYLGVBQUtXLGNBQUwsQ0FBb0IsUUFBcEIsQ0FBeEMsSUFBeUVYLGVBQUtXLGNBQUwsQ0FBb0IsUUFBcEIsS0FBaUMsQ0F6QzVHO0FBQUE7QUFBQTtBQUFBOztBQTBDRVgsbURBQUtDLFVBQUwsQ0FBZ0I7QUFDWkM7QUFEWSxxQ0FBaEI7QUExQ0Y7QUFBQTs7QUFBQTtBQUFBO0FBQUEsMkNBOENRLEtBQUtVLFdBQUwsRUE5Q1I7O0FBQUE7QUFBQTtBQUFBLDJDQStDUSxLQUFLQyxJQUFMLEVBL0NSOztBQUFBO0FBZ0RFLHlDQUFLQyxNQUFMOztBQWhERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBLFM7Ozs7OzBDQW5CUUMsRyxFQUFLO0FBQ25CLGdCQUFJQSxJQUFJQyxJQUFKLEtBQWEsUUFBakIsRUFBMkI7QUFDdkI7QUFDQTtBQUNIO0FBQ0QsbUJBQU87QUFDSEMsdUJBQU8sS0FBSzNELFVBQUwsQ0FBZ0I0RCxZQURwQjtBQUVIQywwQkFBVSxLQUFLN0QsVUFBTCxDQUFnQjhELEtBRnZCO0FBR0h4QixzQkFBTSxnQ0FBZ0MsS0FBS3JDLGFBQUwsQ0FBbUJzQyxFQUFuRCxHQUF3RCxXQUF4RCxHQUFzRSxLQUFLd0IsTUFBTCxDQUFZQztBQUhyRixhQUFQO0FBS0g7Ozs7a0dBQ1lDLEc7Ozs7O0FBQ1QscUNBQUtsRSxLQUFMLEdBQWFrRSxJQUFJMUIsRUFBSixJQUFVMEIsSUFBSUMsS0FBM0I7QUFDQSxxQ0FBS3BFLE1BQUwsR0FBY3FFLGlCQUFkOzt1Q0FDTWxDLGVBQUttQyxLQUFMLEU7OztBQUNOLHFDQUFLTCxNQUFMLEdBQWNyQixlQUFLVyxjQUFMLENBQW9CLFFBQXBCLENBQWQ7O3VDQUNNLEtBQUtFLElBQUwsRTs7O0FBQ04scUNBQUtDLE1BQUw7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3VDQXVEZ0I3QyxpQkFBTzJDLFdBQVAsQ0FBbUIsS0FBS3ZELEtBQXhCLEM7OztBQUFaMEQsbUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozt1Q0FNTTlDLGlCQUFPMEQsVUFBUCxDQUFrQixLQUFLdEUsS0FBdkIsQzs7OztBQUZOdUUsdUMsU0FBQUEsTztBQUNBM0Usb0MsU0FBQUEsSTs7QUFFSixvQ0FBSTJFLFdBQVcsR0FBZixFQUFvQjtBQUNoQix5Q0FBS2hFLElBQUwsR0FBWVgsSUFBWjtBQUNBLHlDQUFLSyxVQUFMLEdBQWtCTCxLQUFLSyxVQUF2QjtBQUNBLHlDQUFLQyxhQUFMLEdBQXFCTixLQUFLcUQsR0FBMUI7QUFDQXVCLDRDQUFRQyxHQUFSLENBQVksS0FBS3ZFLGFBQUwsQ0FBbUJDLFdBQS9CO0FBQ0EseUNBQUtDLGNBQUwsR0FBc0JSLEtBQUtRLGNBQTNCO0FBQ0g7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUE1STJCdUMsZUFBSytCLEk7O2tCQUFwQi9FLE0iLCJmaWxlIjoiYmFyZ2Fpbi5qcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4gICAgaW1wb3J0IHdlcHkgZnJvbSBcIndlcHlcIlxyXG4gICAgaW1wb3J0IGNvbmZpZyBmcm9tIFwiQC9hcGkvY29uZmlnXCJcclxuICAgIGltcG9ydCBhdXRoIGZyb20gXCJAL2FwaS9hdXRoXCJcclxuICAgIGltcG9ydCBMYW5nIGZyb20gXCJAL3V0aWxzL0xhbmdcIlxyXG4gICAgaW1wb3J0IHN0b3JlIGZyb20gXCJAL3N0b3JlL3V0aWxzXCJcclxuICAgIGltcG9ydCBjb250YWN0IGZyb20gXCJAL2NvbXBvbmVudHMvY29tbW9uL2NvbnRhY3RcIlxyXG4gICAgZXhwb3J0IGRlZmF1bHQgY2xhc3MgRGlhbG9nIGV4dGVuZHMgd2VweS5wYWdlIHtcclxuICAgICAgICBkYXRhID0ge1xyXG4gICAgICAgICAgICBjbG9zZTogXCIvc3RhdGljL2ltYWdlcy9jbG9zZS5wbmdcIixcclxuICAgICAgICAgICAgYWN0aXZlOiB0cnVlLFxyXG4gICAgICAgICAgICByb3V0ZXM6IDAsXHJcbiAgICAgICAgICAgIHJlZ0lkOiAnJyxcclxuICAgICAgICAgICAgY291cnNlSW5mbzoge30sXHJcbiAgICAgICAgICAgIEFjdEJhcmdhaW5SZWc6IHtcclxuICAgICAgICAgICAgICAgIGludmFsaWRUaW1lOiAnJ1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBiYXJnYWluUmVjb3JkczogW10sXHJcbiAgICAgICAgICAgIGRqOiAzMDAwLFxyXG4gICAgICAgICAgICBwZXJjZW50OiAwLFxyXG4gICAgICAgICAgICBpbmZvOiB7fSxcclxuICAgICAgICAgICAgbW9kYWxOYW1lOiAnJyxcclxuICAgICAgICAgICAgc3RhdHVzOiB7XHJcbiAgICAgICAgICAgICAgICAwOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgYTogJ+egjeS7t+S4rScsXHJcbiAgICAgICAgICAgICAgICAgICAgYjogJydcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAxOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgYTogJ+egjeS7t+WujOaIkCcsXHJcbiAgICAgICAgICAgICAgICAgICAgYjogJ+W+heaUr+S7mCdcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAyOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgYTogJ+egjeS7t+WujOaIkCcsXHJcbiAgICAgICAgICAgICAgICAgICAgYjogJ+W3suaUr+S7mCdcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAzOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgYTogJ+W3sui/h+acnycsXHJcbiAgICAgICAgICAgICAgICAgICAgYjogJ+egjeS7t+e7k+adnydcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH07XHJcbiAgICAgICAgY29uZmlnID0ge1xyXG4gICAgICAgICAgICBuYXZpZ2F0aW9uQmFyQmFja2dyb3VuZENvbG9yOiAnI2VkMWMyNCcsXHJcbiAgICAgICAgICAgIG5hdmlnYXRpb25CYXJUaXRsZVRleHQ6ICfnoI3ku7cnLFxyXG4gICAgICAgICAgICBcInVzaW5nQ29tcG9uZW50c1wiOiB7XHJcbiAgICAgICAgICAgICAgICBcImwtY291bnRkb3duXCI6IFwiLi4vLi4vY29tcG9uZW50cy9jb3VudGRvd24vaW5kZXhcIlxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbXBvbmVudHMgPSB7XHJcbiAgICAgICAgICAgIGNvbnRhY3RcclxuICAgICAgICB9XHJcbiAgICAgICAgY29tcHV0ZWQgPSB7XHJcbiAgICAgICAgICAgIGN1dFByaWNlKCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuQWN0QmFyZ2FpblJlZykge1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBhY3QgPSB0aGlzLkFjdEJhcmdhaW5SZWdcclxuICAgICAgICAgICAgICAgICAgICBsZXQgX3AgPSBMYW5nLnN1bShbYWN0LmNvdXJzZVByaWNlLCAtYWN0LmNvdXJzZU5ld1ByaWNlXSwgMiksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIF9zcCA9IExhbmcuc3VtKFthY3QuY291cnNlUHJpY2UgLWFjdC5jdXRNaW5QcmljZV0sIDIpXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5wZXJjZW50ID0gcGFyc2VJbnQoX3AgLyBfc3AgKiAxMDApXHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIF9wXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgb25TaGFyZUFwcE1lc3NhZ2UocmVzKSB7XHJcbiAgICAgICAgICAgIGlmIChyZXMuZnJvbSA9PT0gJ2J1dHRvbicpIHtcclxuICAgICAgICAgICAgICAgIC8vIOadpeiHqumhtemdouWGhei9rOWPkeaMiemSrlxyXG4gICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2cocmVzLnRhcmdldClcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgdGl0bGU6IHRoaXMuY291cnNlSW5mby5jb3Vyc2VUaXR0bGUsXHJcbiAgICAgICAgICAgICAgICBpbWFnZVVybDogdGhpcy5jb3Vyc2VJbmZvLmltYWdlLFxyXG4gICAgICAgICAgICAgICAgcGF0aDogJy9wYWdlcy9hY3Rpdml0eS9iYXJnYWluP2lkPScgKyB0aGlzLkFjdEJhcmdhaW5SZWcuaWQgKyAnJmFnZW50SWQ9JyArIHRoaXMubWVtYmVyLmFnZW50SWRcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBhc3luYyBvbkxvYWQob3B0KSB7XHJcbiAgICAgICAgICAgIHRoaXMucmVnSWQgPSBvcHQuaWQgfHwgb3B0LnNjZW5lXHJcbiAgICAgICAgICAgIHRoaXMucm91dGVzID0gZ2V0Q3VycmVudFBhZ2VzKClcclxuICAgICAgICAgICAgYXdhaXQgYXV0aC5sb2dpbigpXHJcbiAgICAgICAgICAgIHRoaXMubWVtYmVyID0gd2VweS5nZXRTdG9yYWdlU3luYygnbWVtYmVyJyk7XHJcbiAgICAgICAgICAgIGF3YWl0IHRoaXMubG9hZCgpXHJcbiAgICAgICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgICB9XHJcbiAgICAgICAgbWV0aG9kcyA9IHtcclxuICAgICAgICAgICAgaGlkZU1vZGFsKCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RhbE5hbWUgPSAnJ1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBhc3luYyBjcmVhdGVJbWcoZSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKGUuZGV0YWlsLmVyck1zZyA9PSBcImdldFVzZXJJbmZvOm9rXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICBhd2FpdCBhdXRoLmdldFVzZXJpbmZvKGUuZGV0YWlsKVxyXG4gICAgICAgICAgICAgICAgICAgIHN0b3JlLnNhdmUoJ3NoYXJlSW5mbycsIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY291cnNlOiB0aGlzLmNvdXJzZUluZm8sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhdGg6ICdwYWdlcy9hY3Rpdml0eS9iYXJnYWluJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IHRoaXMuQWN0QmFyZ2FpblJlZy5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6MyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvdXJzZUlkOnRoaXMuY291cnNlSW5mby5pZFxyXG4gICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgd2VweS5uYXZpZ2F0ZVRvKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdXJsOiAnL3BhZ2VzL2hvbWUvc2hhcmUnXHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHRvc2hhcmUoKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGFsTmFtZSA9ICdzaGFyZSdcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgYXN5bmMgdG9jdXQoZSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKGUuZGV0YWlsLmVyck1zZyA9PSBcImdldFVzZXJJbmZvOm9rXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICBhd2FpdCBhdXRoLmdldFVzZXJpbmZvKGUuZGV0YWlsKVxyXG4gICAgICAgICAgICAgICAgICAgIHdlcHkubmF2aWdhdGVUbyh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHVybDogYC9wYWdlcy9kZXRhaWxlL2RldGFpbGU/aWQ9JHt0aGlzLmNvdXJzZUluZm8uaWR9YFxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBidXkoKSB7XHJcbiAgICAgICAgICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICAgICAgICAgIHVybDogYC9wYWdlcy9kZXRhaWxlL3N1cmVPcmRlcj90eXBlPTImcGlkPSR7dGhpcy5pbmZvLnJlZy5wZXJpb2RJZH0mY2lkPSR7dGhpcy5pbmZvLnJlZy5jb3Vyc2VJZH0mbnVtPTEmYWlkPSR7dGhpcy5pbmZvLnJlZ0lkfSZhY3RwaWQ9MGBcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB0b3BheSgpIHtcclxuICAgICAgICAgICAgICAgIHdlcHkubmF2aWdhdGVUbyh7XHJcbiAgICAgICAgICAgICAgICAgICAgdXJsOiBgL3BhZ2VzL215L29yZGVyP2lkPSR7dGhpcy5pbmZvLm9yZGVySWR9YFxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGFzeW5jIG9uR290VXNlckluZm8oZSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHdlcHkuZ2V0U3RvcmFnZVN5bmMoJ21vYmlsZScpID09ICcnIHx8ICF3ZXB5LmdldFN0b3JhZ2VTeW5jKCdtb2JpbGUnKSB8fCB3ZXB5LmdldFN0b3JhZ2VTeW5jKCdpc0ZhbnMnKSAhPSAxKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgd2VweS5uYXZpZ2F0ZVRvKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdXJsOiBgL3BhZ2VzL2hvbWUvYXV0aGBcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYXdhaXQgdGhpcy5oZWxwQmFyZ2FpbigpXHJcbiAgICAgICAgICAgICAgICAgICAgYXdhaXQgdGhpcy5sb2FkKClcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgfTtcclxuICAgICAgICBhc3luYyBoZWxwQmFyZ2FpbigpIHtcclxuICAgICAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGNvbmZpZy5oZWxwQmFyZ2Fpbih0aGlzLnJlZ0lkKVxyXG4gICAgICAgIH1cclxuICAgICAgICBhc3luYyBsb2FkKCkge1xyXG4gICAgICAgICAgICBsZXQge1xyXG4gICAgICAgICAgICAgICAgZXJyY29kZSxcclxuICAgICAgICAgICAgICAgIGRhdGFcclxuICAgICAgICAgICAgfSA9IGF3YWl0IGNvbmZpZy50b0N1dERldGFpKHRoaXMucmVnSWQpXHJcbiAgICAgICAgICAgIGlmIChlcnJjb2RlID09IDIwMCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5pbmZvID0gZGF0YVxyXG4gICAgICAgICAgICAgICAgdGhpcy5jb3Vyc2VJbmZvID0gZGF0YS5jb3Vyc2VJbmZvXHJcbiAgICAgICAgICAgICAgICB0aGlzLkFjdEJhcmdhaW5SZWcgPSBkYXRhLnJlZ1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2codGhpcy5BY3RCYXJnYWluUmVnLmludmFsaWRUaW1lKVxyXG4gICAgICAgICAgICAgICAgdGhpcy5iYXJnYWluUmVjb3JkcyA9IGRhdGEuYmFyZ2FpblJlY29yZHNcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuIl19