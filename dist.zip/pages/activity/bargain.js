"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

var _Lang = require('./../../utils/Lang.js');

var _Lang2 = _interopRequireDefault(_Lang);

var _utils = require('./../../store/utils.js');

var _utils2 = _interopRequireDefault(_utils);

var _contact = require('./../../components/common/contact.js');

var _contact2 = _interopRequireDefault(_contact);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
    _inherits(Dialog, _wepy$page);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.data = {
            close: "/static/images/close.png",
            active: true,
            routes: 0,
            regId: '',
            courseInfo: {},
            ActBargainReg: {
                invalidTime: ''
            },
            bargainRecords: [],
            dj: 3000,
            percent: 0,
            info: {},
            modalName: '',
            status: {
                0: {
                    a: '砍价中',
                    b: ''
                },
                1: {
                    a: '砍价完成',
                    b: '待支付'
                },
                2: {
                    a: '砍价完成',
                    b: '已支付'
                },
                3: {
                    a: '已过期',
                    b: '砍价结束'
                }
            }
        }, _this.config = {
            navigationBarBackgroundColor: '#ed1c24',
            navigationBarTitleText: '砍价',
            "usingComponents": {
                "l-countdown": "../../components/countdown/index"
            }
        }, _this.components = {
            contact: _contact2.default
        }, _this.computed = {
            cutPrice: function cutPrice() {
                if (this.ActBargainReg) {
                    var act = this.ActBargainReg;
                    var _p = _Lang2.default.sum([act.coursePrice, -act.courseNewPrice], 2),
                        _sp = _Lang2.default.sum([act.coursePrice - act.cutMinPrice], 2);
                    this.percent = parseInt(_p / _sp * 100);
                    return _p;
                }
            }
        }, _this.methods = {
            hideModal: function hideModal() {
                this.modalName = '';
            },
            createImg: function () {
                var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(e) {
                    return regeneratorRuntime.wrap(function _callee$(_context) {
                        while (1) {
                            switch (_context.prev = _context.next) {
                                case 0:
                                    if (!(e.detail.errMsg == "getUserInfo:ok")) {
                                        _context.next = 5;
                                        break;
                                    }

                                    _context.next = 3;
                                    return _auth2.default.getUserinfo(e.detail);

                                case 3:
                                    _utils2.default.save('shareInfo', {
                                        course: this.courseInfo,
                                        path: 'pages/activity/bargain',
                                        id: this.ActBargainReg.id
                                    });
                                    _wepy2.default.navigateTo({
                                        url: '/pages/home/share'
                                    });

                                case 5:
                                case "end":
                                    return _context.stop();
                            }
                        }
                    }, _callee, this);
                }));

                function createImg(_x) {
                    return _ref2.apply(this, arguments);
                }

                return createImg;
            }(),
            toshare: function toshare() {
                this.modalName = 'share';
            },
            tocut: function () {
                var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(e) {
                    return regeneratorRuntime.wrap(function _callee2$(_context2) {
                        while (1) {
                            switch (_context2.prev = _context2.next) {
                                case 0:
                                    if (!(e.detail.errMsg == "getUserInfo:ok")) {
                                        _context2.next = 4;
                                        break;
                                    }

                                    _context2.next = 3;
                                    return _auth2.default.getUserinfo(e.detail);

                                case 3:
                                    _wepy2.default.navigateTo({
                                        url: "/pages/detaile/detaile?id=" + this.courseInfo.id
                                    });

                                case 4:
                                case "end":
                                    return _context2.stop();
                            }
                        }
                    }, _callee2, this);
                }));

                function tocut(_x2) {
                    return _ref3.apply(this, arguments);
                }

                return tocut;
            }(),
            buy: function buy() {
                _wepy2.default.navigateTo({
                    url: "/pages/detaile/sureOrder?type=2&pid=" + this.info.reg.periodId + "&cid=" + this.info.reg.courseId + "&num=1&aid=" + this.info.regId + "&actpid=0"
                });
            },
            topay: function topay() {
                _wepy2.default.navigateTo({
                    url: "/pages/my/order?id=" + this.info.orderId
                });
            },
            onGotUserInfo: function () {
                var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(e) {
                    return regeneratorRuntime.wrap(function _callee3$(_context3) {
                        while (1) {
                            switch (_context3.prev = _context3.next) {
                                case 0:
                                    if (!(_wepy2.default.getStorageSync('mobile') == '' || !_wepy2.default.getStorageSync('mobile') || _wepy2.default.getStorageSync('isFans') != 1)) {
                                        _context3.next = 4;
                                        break;
                                    }

                                    _wepy2.default.navigateTo({
                                        url: "/pages/home/auth"
                                    });
                                    _context3.next = 9;
                                    break;

                                case 4:
                                    _context3.next = 6;
                                    return this.helpBargain();

                                case 6:
                                    _context3.next = 8;
                                    return this.load();

                                case 8:
                                    this.$apply();

                                case 9:
                                case "end":
                                    return _context3.stop();
                            }
                        }
                    }, _callee3, this);
                }));

                function onGotUserInfo(_x3) {
                    return _ref4.apply(this, arguments);
                }

                return onGotUserInfo;
            }()
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(Dialog, [{
        key: "onShareAppMessage",
        value: function onShareAppMessage(res) {
            if (res.from === 'button') {
                // 来自页面内转发按钮
                // console.log(res.target)
            }
            return {
                title: this.courseInfo.courseTittle,
                imageUrl: this.courseInfo.image,
                path: '/pages/activity/bargain?id=' + this.ActBargainReg.id + '&agentId=' + this.member.agentId
            };
        }
    }, {
        key: "onLoad",
        value: function () {
            var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4(opt) {
                return regeneratorRuntime.wrap(function _callee4$(_context4) {
                    while (1) {
                        switch (_context4.prev = _context4.next) {
                            case 0:
                                this.regId = opt.id || opt.scene;
                                this.routes = getCurrentPages();
                                _context4.next = 4;
                                return _auth2.default.login();

                            case 4:
                                this.member = _wepy2.default.getStorageSync('member');
                                _context4.next = 7;
                                return this.load();

                            case 7:
                                this.$apply();

                            case 8:
                            case "end":
                                return _context4.stop();
                        }
                    }
                }, _callee4, this);
            }));

            function onLoad(_x4) {
                return _ref5.apply(this, arguments);
            }

            return onLoad;
        }()
    }, {
        key: "helpBargain",
        value: function () {
            var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
                var res;
                return regeneratorRuntime.wrap(function _callee5$(_context5) {
                    while (1) {
                        switch (_context5.prev = _context5.next) {
                            case 0:
                                _context5.next = 2;
                                return _config2.default.helpBargain(this.regId);

                            case 2:
                                res = _context5.sent;

                            case 3:
                            case "end":
                                return _context5.stop();
                        }
                    }
                }, _callee5, this);
            }));

            function helpBargain() {
                return _ref6.apply(this, arguments);
            }

            return helpBargain;
        }()
    }, {
        key: "load",
        value: function () {
            var _ref7 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
                var _ref8, errcode, data;

                return regeneratorRuntime.wrap(function _callee6$(_context6) {
                    while (1) {
                        switch (_context6.prev = _context6.next) {
                            case 0:
                                _context6.next = 2;
                                return _config2.default.toCutDetai(this.regId);

                            case 2:
                                _ref8 = _context6.sent;
                                errcode = _ref8.errcode;
                                data = _ref8.data;

                                if (errcode == 200) {
                                    this.info = data;
                                    this.courseInfo = data.courseInfo;
                                    this.ActBargainReg = data.reg;
                                    console.log(this.ActBargainReg.invalidTime);
                                    this.bargainRecords = data.bargainRecords;
                                }

                            case 6:
                            case "end":
                                return _context6.stop();
                        }
                    }
                }, _callee6, this);
            }));

            function load() {
                return _ref7.apply(this, arguments);
            }

            return load;
        }()
    }]);

    return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/activity/bargain'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImJhcmdhaW4uanMiXSwibmFtZXMiOlsiRGlhbG9nIiwiZGF0YSIsImNsb3NlIiwiYWN0aXZlIiwicm91dGVzIiwicmVnSWQiLCJjb3Vyc2VJbmZvIiwiQWN0QmFyZ2FpblJlZyIsImludmFsaWRUaW1lIiwiYmFyZ2FpblJlY29yZHMiLCJkaiIsInBlcmNlbnQiLCJpbmZvIiwibW9kYWxOYW1lIiwic3RhdHVzIiwiYSIsImIiLCJjb25maWciLCJuYXZpZ2F0aW9uQmFyQmFja2dyb3VuZENvbG9yIiwibmF2aWdhdGlvbkJhclRpdGxlVGV4dCIsImNvbXBvbmVudHMiLCJjb250YWN0IiwiY29tcHV0ZWQiLCJjdXRQcmljZSIsImFjdCIsIl9wIiwiTGFuZyIsInN1bSIsImNvdXJzZVByaWNlIiwiY291cnNlTmV3UHJpY2UiLCJfc3AiLCJjdXRNaW5QcmljZSIsInBhcnNlSW50IiwibWV0aG9kcyIsImhpZGVNb2RhbCIsImNyZWF0ZUltZyIsImUiLCJkZXRhaWwiLCJlcnJNc2ciLCJhdXRoIiwiZ2V0VXNlcmluZm8iLCJzdG9yZSIsInNhdmUiLCJjb3Vyc2UiLCJwYXRoIiwiaWQiLCJ3ZXB5IiwibmF2aWdhdGVUbyIsInVybCIsInRvc2hhcmUiLCJ0b2N1dCIsImJ1eSIsInJlZyIsInBlcmlvZElkIiwiY291cnNlSWQiLCJ0b3BheSIsIm9yZGVySWQiLCJvbkdvdFVzZXJJbmZvIiwiZ2V0U3RvcmFnZVN5bmMiLCJoZWxwQmFyZ2FpbiIsImxvYWQiLCIkYXBwbHkiLCJyZXMiLCJmcm9tIiwidGl0bGUiLCJjb3Vyc2VUaXR0bGUiLCJpbWFnZVVybCIsImltYWdlIiwibWVtYmVyIiwiYWdlbnRJZCIsIm9wdCIsInNjZW5lIiwiZ2V0Q3VycmVudFBhZ2VzIiwibG9naW4iLCJ0b0N1dERldGFpIiwiZXJyY29kZSIsImNvbnNvbGUiLCJsb2ciLCJwYWdlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFDSTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7Ozs7Ozs7Ozs7O0lBQ3FCQSxNOzs7Ozs7Ozs7Ozs7OzswTEFDakJDLEksR0FBTztBQUNIQyxtQkFBTywwQkFESjtBQUVIQyxvQkFBUSxJQUZMO0FBR0hDLG9CQUFRLENBSEw7QUFJSEMsbUJBQU8sRUFKSjtBQUtIQyx3QkFBWSxFQUxUO0FBTUhDLDJCQUFlO0FBQ1hDLDZCQUFhO0FBREYsYUFOWjtBQVNIQyw0QkFBZ0IsRUFUYjtBQVVIQyxnQkFBSSxJQVZEO0FBV0hDLHFCQUFTLENBWE47QUFZSEMsa0JBQU0sRUFaSDtBQWFIQyx1QkFBVyxFQWJSO0FBY0hDLG9CQUFRO0FBQ0osbUJBQUc7QUFDQ0MsdUJBQUcsS0FESjtBQUVDQyx1QkFBRztBQUZKLGlCQURDO0FBS0osbUJBQUc7QUFDQ0QsdUJBQUcsTUFESjtBQUVDQyx1QkFBRztBQUZKLGlCQUxDO0FBU0osbUJBQUc7QUFDQ0QsdUJBQUcsTUFESjtBQUVDQyx1QkFBRztBQUZKLGlCQVRDO0FBYUosbUJBQUc7QUFDQ0QsdUJBQUcsS0FESjtBQUVDQyx1QkFBRztBQUZKO0FBYkM7QUFkTCxTLFFBaUNQQyxNLEdBQVM7QUFDTEMsMENBQThCLFNBRHpCO0FBRUxDLG9DQUF3QixJQUZuQjtBQUdMLCtCQUFtQjtBQUNmLCtCQUFlO0FBREE7QUFIZCxTLFFBT1RDLFUsR0FBYTtBQUNUQztBQURTLFMsUUFHYkMsUSxHQUFXO0FBQ1BDLG9CQURPLHNCQUNJO0FBQ1Asb0JBQUksS0FBS2hCLGFBQVQsRUFBd0I7QUFDcEIsd0JBQUlpQixNQUFNLEtBQUtqQixhQUFmO0FBQ0Esd0JBQUlrQixLQUFLQyxlQUFLQyxHQUFMLENBQVMsQ0FBQ0gsSUFBSUksV0FBTCxFQUFrQixDQUFDSixJQUFJSyxjQUF2QixDQUFULEVBQWlELENBQWpELENBQVQ7QUFBQSx3QkFDSUMsTUFBTUosZUFBS0MsR0FBTCxDQUFTLENBQUNILElBQUlJLFdBQUosR0FBaUJKLElBQUlPLFdBQXRCLENBQVQsRUFBNkMsQ0FBN0MsQ0FEVjtBQUVBLHlCQUFLcEIsT0FBTCxHQUFlcUIsU0FBU1AsS0FBS0ssR0FBTCxHQUFXLEdBQXBCLENBQWY7QUFDQSwyQkFBT0wsRUFBUDtBQUNIO0FBQ0o7QUFUTSxTLFFBOEJYUSxPLEdBQVU7QUFDTkMscUJBRE0sdUJBQ007QUFDUixxQkFBS3JCLFNBQUwsR0FBaUIsRUFBakI7QUFDSCxhQUhLO0FBSUFzQixxQkFKQTtBQUFBLHFHQUlVQyxDQUpWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQ0FLRUEsRUFBRUMsTUFBRixDQUFTQyxNQUFULElBQW1CLGdCQUxyQjtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBLDJDQU1RQyxlQUFLQyxXQUFMLENBQWlCSixFQUFFQyxNQUFuQixDQU5SOztBQUFBO0FBT0VJLG9EQUFNQyxJQUFOLENBQVcsV0FBWCxFQUF3QjtBQUNwQkMsZ0RBQVEsS0FBS3JDLFVBRE87QUFFcEJzQyw4Q0FBTSx3QkFGYztBQUdwQkMsNENBQUksS0FBS3RDLGFBQUwsQ0FBbUJzQztBQUhILHFDQUF4QjtBQUtBQyxtREFBS0MsVUFBTCxDQUFnQjtBQUNaQyw2Q0FBSztBQURPLHFDQUFoQjs7QUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQWlCTkMsbUJBakJNLHFCQWlCSTtBQUNOLHFCQUFLcEMsU0FBTCxHQUFpQixPQUFqQjtBQUNILGFBbkJLO0FBb0JBcUMsaUJBcEJBO0FBQUEsc0dBb0JNZCxDQXBCTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMENBcUJFQSxFQUFFQyxNQUFGLENBQVNDLE1BQVQsSUFBbUIsZ0JBckJyQjtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBLDJDQXNCUUMsZUFBS0MsV0FBTCxDQUFpQkosRUFBRUMsTUFBbkIsQ0F0QlI7O0FBQUE7QUF1QkVTLG1EQUFLQyxVQUFMLENBQWdCO0FBQ1pDLDRFQUFrQyxLQUFLMUMsVUFBTCxDQUFnQnVDO0FBRHRDLHFDQUFoQjs7QUF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUE0Qk5NLGVBNUJNLGlCQTRCQTtBQUNGTCwrQkFBS0MsVUFBTCxDQUFnQjtBQUNaQyxrRUFBNEMsS0FBS3BDLElBQUwsQ0FBVXdDLEdBQVYsQ0FBY0MsUUFBMUQsYUFBMEUsS0FBS3pDLElBQUwsQ0FBVXdDLEdBQVYsQ0FBY0UsUUFBeEYsbUJBQThHLEtBQUsxQyxJQUFMLENBQVVQLEtBQXhIO0FBRFksaUJBQWhCO0FBR0gsYUFoQ0s7QUFpQ05rRCxpQkFqQ00sbUJBaUNFO0FBQ0pULCtCQUFLQyxVQUFMLENBQWdCO0FBQ1pDLGlEQUEyQixLQUFLcEMsSUFBTCxDQUFVNEM7QUFEekIsaUJBQWhCO0FBR0gsYUFyQ0s7QUFzQ0FDLHlCQXRDQTtBQUFBLHNHQXNDY3JCLENBdENkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQ0F1Q0VVLGVBQUtZLGNBQUwsQ0FBb0IsUUFBcEIsS0FBaUMsRUFBakMsSUFBdUMsQ0FBQ1osZUFBS1ksY0FBTCxDQUFvQixRQUFwQixDQUF4QyxJQUF5RVosZUFBS1ksY0FBTCxDQUFvQixRQUFwQixLQUFpQyxDQXZDNUc7QUFBQTtBQUFBO0FBQUE7O0FBd0NFWixtREFBS0MsVUFBTCxDQUFnQjtBQUNaQztBQURZLHFDQUFoQjtBQXhDRjtBQUFBOztBQUFBO0FBQUE7QUFBQSwyQ0E0Q1EsS0FBS1csV0FBTCxFQTVDUjs7QUFBQTtBQUFBO0FBQUEsMkNBNkNRLEtBQUtDLElBQUwsRUE3Q1I7O0FBQUE7QUE4Q0UseUNBQUtDLE1BQUw7O0FBOUNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUEsUzs7Ozs7MENBbkJRQyxHLEVBQUs7QUFDbkIsZ0JBQUlBLElBQUlDLElBQUosS0FBYSxRQUFqQixFQUEyQjtBQUN2QjtBQUNBO0FBQ0g7QUFDRCxtQkFBTztBQUNIQyx1QkFBTyxLQUFLMUQsVUFBTCxDQUFnQjJELFlBRHBCO0FBRUhDLDBCQUFVLEtBQUs1RCxVQUFMLENBQWdCNkQsS0FGdkI7QUFHSHZCLHNCQUFNLGdDQUFnQyxLQUFLckMsYUFBTCxDQUFtQnNDLEVBQW5ELEdBQXdELFdBQXhELEdBQXNFLEtBQUt1QixNQUFMLENBQVlDO0FBSHJGLGFBQVA7QUFLSDs7OztrR0FDWUMsRzs7Ozs7QUFDVCxxQ0FBS2pFLEtBQUwsR0FBYWlFLElBQUl6QixFQUFKLElBQVV5QixJQUFJQyxLQUEzQjtBQUNBLHFDQUFLbkUsTUFBTCxHQUFjb0UsaUJBQWQ7O3VDQUNNakMsZUFBS2tDLEtBQUwsRTs7O0FBQ04scUNBQUtMLE1BQUwsR0FBY3RCLGVBQUtZLGNBQUwsQ0FBb0IsUUFBcEIsQ0FBZDs7dUNBQ00sS0FBS0UsSUFBTCxFOzs7QUFDTixxQ0FBS0MsTUFBTDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7dUNBcURnQjVDLGlCQUFPMEMsV0FBUCxDQUFtQixLQUFLdEQsS0FBeEIsQzs7O0FBQVp5RCxtQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3VDQU1NN0MsaUJBQU95RCxVQUFQLENBQWtCLEtBQUtyRSxLQUF2QixDOzs7O0FBRk5zRSx1QyxTQUFBQSxPO0FBQ0ExRSxvQyxTQUFBQSxJOztBQUVKLG9DQUFJMEUsV0FBVyxHQUFmLEVBQW9CO0FBQ2hCLHlDQUFLL0QsSUFBTCxHQUFZWCxJQUFaO0FBQ0EseUNBQUtLLFVBQUwsR0FBa0JMLEtBQUtLLFVBQXZCO0FBQ0EseUNBQUtDLGFBQUwsR0FBcUJOLEtBQUttRCxHQUExQjtBQUNBd0IsNENBQVFDLEdBQVIsQ0FBWSxLQUFLdEUsYUFBTCxDQUFtQkMsV0FBL0I7QUFDQSx5Q0FBS0MsY0FBTCxHQUFzQlIsS0FBS1EsY0FBM0I7QUFDSDs7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQTFJMkJxQyxlQUFLZ0MsSTs7a0JBQXBCOUUsTSIsImZpbGUiOiJiYXJnYWluLmpzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbiAgICBpbXBvcnQgd2VweSBmcm9tIFwid2VweVwiXHJcbiAgICBpbXBvcnQgY29uZmlnIGZyb20gXCJAL2FwaS9jb25maWdcIlxyXG4gICAgaW1wb3J0IGF1dGggZnJvbSBcIkAvYXBpL2F1dGhcIlxyXG4gICAgaW1wb3J0IExhbmcgZnJvbSBcIkAvdXRpbHMvTGFuZ1wiXHJcbiAgICBpbXBvcnQgc3RvcmUgZnJvbSBcIkAvc3RvcmUvdXRpbHNcIlxyXG4gICAgaW1wb3J0IGNvbnRhY3QgZnJvbSBcIkAvY29tcG9uZW50cy9jb21tb24vY29udGFjdFwiXHJcbiAgICBleHBvcnQgZGVmYXVsdCBjbGFzcyBEaWFsb2cgZXh0ZW5kcyB3ZXB5LnBhZ2Uge1xyXG4gICAgICAgIGRhdGEgPSB7XHJcbiAgICAgICAgICAgIGNsb3NlOiBcIi9zdGF0aWMvaW1hZ2VzL2Nsb3NlLnBuZ1wiLFxyXG4gICAgICAgICAgICBhY3RpdmU6IHRydWUsXHJcbiAgICAgICAgICAgIHJvdXRlczogMCxcclxuICAgICAgICAgICAgcmVnSWQ6ICcnLFxyXG4gICAgICAgICAgICBjb3Vyc2VJbmZvOiB7fSxcclxuICAgICAgICAgICAgQWN0QmFyZ2FpblJlZzoge1xyXG4gICAgICAgICAgICAgICAgaW52YWxpZFRpbWU6ICcnXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGJhcmdhaW5SZWNvcmRzOiBbXSxcclxuICAgICAgICAgICAgZGo6IDMwMDAsXHJcbiAgICAgICAgICAgIHBlcmNlbnQ6IDAsXHJcbiAgICAgICAgICAgIGluZm86IHt9LFxyXG4gICAgICAgICAgICBtb2RhbE5hbWU6ICcnLFxyXG4gICAgICAgICAgICBzdGF0dXM6IHtcclxuICAgICAgICAgICAgICAgIDA6IHtcclxuICAgICAgICAgICAgICAgICAgICBhOiAn56CN5Lu35LitJyxcclxuICAgICAgICAgICAgICAgICAgICBiOiAnJ1xyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIDE6IHtcclxuICAgICAgICAgICAgICAgICAgICBhOiAn56CN5Lu35a6M5oiQJyxcclxuICAgICAgICAgICAgICAgICAgICBiOiAn5b6F5pSv5LuYJ1xyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIDI6IHtcclxuICAgICAgICAgICAgICAgICAgICBhOiAn56CN5Lu35a6M5oiQJyxcclxuICAgICAgICAgICAgICAgICAgICBiOiAn5bey5pSv5LuYJ1xyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIDM6IHtcclxuICAgICAgICAgICAgICAgICAgICBhOiAn5bey6L+H5pyfJyxcclxuICAgICAgICAgICAgICAgICAgICBiOiAn56CN5Lu357uT5p2fJ1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuICAgICAgICBjb25maWcgPSB7XHJcbiAgICAgICAgICAgIG5hdmlnYXRpb25CYXJCYWNrZ3JvdW5kQ29sb3I6ICcjZWQxYzI0JyxcclxuICAgICAgICAgICAgbmF2aWdhdGlvbkJhclRpdGxlVGV4dDogJ+egjeS7tycsXHJcbiAgICAgICAgICAgIFwidXNpbmdDb21wb25lbnRzXCI6IHtcclxuICAgICAgICAgICAgICAgIFwibC1jb3VudGRvd25cIjogXCIuLi8uLi9jb21wb25lbnRzL2NvdW50ZG93bi9pbmRleFwiXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgY29tcG9uZW50cyA9IHtcclxuICAgICAgICAgICAgY29udGFjdFxyXG4gICAgICAgIH1cclxuICAgICAgICBjb21wdXRlZCA9IHtcclxuICAgICAgICAgICAgY3V0UHJpY2UoKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5BY3RCYXJnYWluUmVnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGFjdCA9IHRoaXMuQWN0QmFyZ2FpblJlZ1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBfcCA9IExhbmcuc3VtKFthY3QuY291cnNlUHJpY2UsIC1hY3QuY291cnNlTmV3UHJpY2VdLCAyKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgX3NwID0gTGFuZy5zdW0oW2FjdC5jb3Vyc2VQcmljZSAtYWN0LmN1dE1pblByaWNlXSwgMilcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnBlcmNlbnQgPSBwYXJzZUludChfcCAvIF9zcCAqIDEwMClcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gX3BcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBvblNoYXJlQXBwTWVzc2FnZShyZXMpIHtcclxuICAgICAgICAgICAgaWYgKHJlcy5mcm9tID09PSAnYnV0dG9uJykge1xyXG4gICAgICAgICAgICAgICAgLy8g5p2l6Ieq6aG16Z2i5YaF6L2s5Y+R5oyJ6ZKuXHJcbiAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhyZXMudGFyZ2V0KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICB0aXRsZTogdGhpcy5jb3Vyc2VJbmZvLmNvdXJzZVRpdHRsZSxcclxuICAgICAgICAgICAgICAgIGltYWdlVXJsOiB0aGlzLmNvdXJzZUluZm8uaW1hZ2UsXHJcbiAgICAgICAgICAgICAgICBwYXRoOiAnL3BhZ2VzL2FjdGl2aXR5L2JhcmdhaW4/aWQ9JyArIHRoaXMuQWN0QmFyZ2FpblJlZy5pZCArICcmYWdlbnRJZD0nICsgdGhpcy5tZW1iZXIuYWdlbnRJZFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGFzeW5jIG9uTG9hZChvcHQpIHtcclxuICAgICAgICAgICAgdGhpcy5yZWdJZCA9IG9wdC5pZCB8fCBvcHQuc2NlbmVcclxuICAgICAgICAgICAgdGhpcy5yb3V0ZXMgPSBnZXRDdXJyZW50UGFnZXMoKVxyXG4gICAgICAgICAgICBhd2FpdCBhdXRoLmxvZ2luKClcclxuICAgICAgICAgICAgdGhpcy5tZW1iZXIgPSB3ZXB5LmdldFN0b3JhZ2VTeW5jKCdtZW1iZXInKTtcclxuICAgICAgICAgICAgYXdhaXQgdGhpcy5sb2FkKClcclxuICAgICAgICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgICAgIH1cclxuICAgICAgICBtZXRob2RzID0ge1xyXG4gICAgICAgICAgICBoaWRlTW9kYWwoKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGFsTmFtZSA9ICcnXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGFzeW5jIGNyZWF0ZUltZyhlKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoZS5kZXRhaWwuZXJyTXNnID09IFwiZ2V0VXNlckluZm86b2tcIikge1xyXG4gICAgICAgICAgICAgICAgICAgIGF3YWl0IGF1dGguZ2V0VXNlcmluZm8oZS5kZXRhaWwpXHJcbiAgICAgICAgICAgICAgICAgICAgc3RvcmUuc2F2ZSgnc2hhcmVJbmZvJywge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb3Vyc2U6IHRoaXMuY291cnNlSW5mbyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGF0aDogJ3BhZ2VzL2FjdGl2aXR5L2JhcmdhaW4nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZDogdGhpcy5BY3RCYXJnYWluUmVnLmlkXHJcbiAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB1cmw6ICcvcGFnZXMvaG9tZS9zaGFyZSdcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgdG9zaGFyZSgpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kYWxOYW1lID0gJ3NoYXJlJ1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBhc3luYyB0b2N1dChlKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoZS5kZXRhaWwuZXJyTXNnID09IFwiZ2V0VXNlckluZm86b2tcIikge1xyXG4gICAgICAgICAgICAgICAgICAgIGF3YWl0IGF1dGguZ2V0VXNlcmluZm8oZS5kZXRhaWwpXHJcbiAgICAgICAgICAgICAgICAgICAgd2VweS5uYXZpZ2F0ZVRvKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdXJsOiBgL3BhZ2VzL2RldGFpbGUvZGV0YWlsZT9pZD0ke3RoaXMuY291cnNlSW5mby5pZH1gXHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGJ1eSgpIHtcclxuICAgICAgICAgICAgICAgIHdlcHkubmF2aWdhdGVUbyh7XHJcbiAgICAgICAgICAgICAgICAgICAgdXJsOiBgL3BhZ2VzL2RldGFpbGUvc3VyZU9yZGVyP3R5cGU9MiZwaWQ9JHt0aGlzLmluZm8ucmVnLnBlcmlvZElkfSZjaWQ9JHt0aGlzLmluZm8ucmVnLmNvdXJzZUlkfSZudW09MSZhaWQ9JHt0aGlzLmluZm8ucmVnSWR9JmFjdHBpZD0wYFxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHRvcGF5KCkge1xyXG4gICAgICAgICAgICAgICAgd2VweS5uYXZpZ2F0ZVRvKHtcclxuICAgICAgICAgICAgICAgICAgICB1cmw6IGAvcGFnZXMvbXkvb3JkZXI/aWQ9JHt0aGlzLmluZm8ub3JkZXJJZH1gXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgYXN5bmMgb25Hb3RVc2VySW5mbyhlKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAod2VweS5nZXRTdG9yYWdlU3luYygnbW9iaWxlJykgPT0gJycgfHwgIXdlcHkuZ2V0U3RvcmFnZVN5bmMoJ21vYmlsZScpIHx8IHdlcHkuZ2V0U3RvcmFnZVN5bmMoJ2lzRmFucycpICE9IDEpIHtcclxuICAgICAgICAgICAgICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB1cmw6IGAvcGFnZXMvaG9tZS9hdXRoYFxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBhd2FpdCB0aGlzLmhlbHBCYXJnYWluKClcclxuICAgICAgICAgICAgICAgICAgICBhd2FpdCB0aGlzLmxvYWQoKVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICB9O1xyXG4gICAgICAgIGFzeW5jIGhlbHBCYXJnYWluKCkge1xyXG4gICAgICAgICAgICBsZXQgcmVzID0gYXdhaXQgY29uZmlnLmhlbHBCYXJnYWluKHRoaXMucmVnSWQpXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGFzeW5jIGxvYWQoKSB7XHJcbiAgICAgICAgICAgIGxldCB7XHJcbiAgICAgICAgICAgICAgICBlcnJjb2RlLFxyXG4gICAgICAgICAgICAgICAgZGF0YVxyXG4gICAgICAgICAgICB9ID0gYXdhaXQgY29uZmlnLnRvQ3V0RGV0YWkodGhpcy5yZWdJZClcclxuICAgICAgICAgICAgaWYgKGVycmNvZGUgPT0gMjAwKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmluZm8gPSBkYXRhXHJcbiAgICAgICAgICAgICAgICB0aGlzLmNvdXJzZUluZm8gPSBkYXRhLmNvdXJzZUluZm9cclxuICAgICAgICAgICAgICAgIHRoaXMuQWN0QmFyZ2FpblJlZyA9IGRhdGEucmVnXHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyh0aGlzLkFjdEJhcmdhaW5SZWcuaW52YWxpZFRpbWUpXHJcbiAgICAgICAgICAgICAgICB0aGlzLmJhcmdhaW5SZWNvcmRzID0gZGF0YS5iYXJnYWluUmVjb3Jkc1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4iXX0=