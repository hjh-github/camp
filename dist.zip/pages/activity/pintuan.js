"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _swiper = require('./../../components/common/swiper.js');

var _swiper2 = _interopRequireDefault(_swiper);

var _title = require('./../../components/detaile/title.js');

var _title2 = _interopRequireDefault(_title);

var _info = require('./../../components/detaile/info.js');

var _info2 = _interopRequireDefault(_info);

var _remake = require('./../../components/detaile/remake.js');

var _remake2 = _interopRequireDefault(_remake);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

var _WxUtils = require('./../../utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
    _inherits(Dialog, _wepy$page);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.data = {
            TabCur: 0,
            close: "/static/images/close.png",
            swipers: {
                type: 1,
                list: [{
                    id: 0,
                    type: "image",
                    url: "",
                    link: "/pages/meet/meet",
                    linkType: "switchTab"
                }]
            },
            actPintuanActivity: {},
            ActPintuanMember: {},
            ActPintuan: {},
            mainHeight: 0,
            courseInfo: {},
            nodes: ["name", "attrs", "attrs"],
            num: 1,
            showSku: false,
            buyTypt: 'normal',
            courseInx: -1,
            companions: [],
            statistics: {},
            CourseComment: {},
            sign_states: {
                0: '火热招生中',
                1: '少量名额',
                2: '已满员'
            },
            toPintuan: false,
            numList: [{
                name: '参团',
                name1: '支付完成'
            }, {
                name: '获得更多优惠',
                name1: '分享活动'
            }, {
                name: '拼团成功',
                name1: '老师主动联系您'
            }]
        }, _this.$repeat = {}, _this.$props = { "cSwiper": { "xmlns:v-bind": "", "v-bind:model.sync": "swipers" }, "ctitle": { "v-bind:model.sync": "courseInfo" }, "cInfo": { "v-bind:model.sync": "courseInfo", "v-bind:companions.sync": "companions" }, "cRemake": { "v-bind:model.sync": "courseInfo", "v-bind:statistics.sync": "statistics", "v-bind:CourseComment.sync": "CourseComment" } }, _this.$events = {}, _this.components = {
            cSwiper: _swiper2.default,
            ctitle: _title2.default,
            cInfo: _info2.default,
            cRemake: _remake2.default
        }, _this.config = {
            navigationBarTitleText: "活动详情"
        }, _this.methods = {
            toPintuanfy: function toPintuanfy() {
                this.toPintuan = true;
            },
            ret: function ret() {
                return false;
            },
            tabSelect: function tabSelect(e) {
                console.log(e);
                this.TabCur = e.currentTarget.dataset.id || e.detail.current;
            },
            hideModal: function hideModal() {
                this.toPintuan = false;
                this.showSku = false;
            },
            sku: function sku() {
                var type = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'normal';

                this.showSku = true;
                this.toPintuan = false;
                this.buyTypt = type;
            },
            plus: function plus() {
                wx.vibrateShort();
                this.num = this.num + 1;
            },
            minus: function minus() {
                if (this.num > 1) {
                    wx.vibrateShort();
                    this.num = this.num - 1;
                }
            },
            course: function course(inx) {
                this.courseInx = inx;
            },
            buy: function () {
                var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
                    var aid = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;
                    var ot = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1;
                    return regeneratorRuntime.wrap(function _callee$(_context) {
                        while (1) {
                            switch (_context.prev = _context.next) {
                                case 0:
                                    if (!(this.courseInx == -1)) {
                                        _context.next = 3;
                                        break;
                                    }

                                    _Tips2.default.toast("请选择一个营期", function (res) {}, 'none');
                                    return _context.abrupt("return", false);

                                case 3:
                                    _wepy2.default.navigateTo({
                                        url: "../detaile/sureOrder?type=" + ot + "&pid=" + this.courseInfo.periodList[this.courseInx].id + "&cid=" + this.courseInfo.id + "&num=" + this.num + "&aid=" + aid + "&actpid=" + this.courseInfo.pintuanId
                                    });

                                case 4:
                                case "end":
                                    return _context.stop();
                            }
                        }
                    }, _callee, this);
                }));

                function buy() {
                    return _ref2.apply(this, arguments);
                }

                return buy;
            }()
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(Dialog, [{
        key: "onShareAppMessage",

        // 转发暂时先不开启
        value: function onShareAppMessage(res) {
            if (res.from === 'button') {
                // 来自页面内转发按钮
                console.log(res.target);
            }
            return {
                title: this.courseInfo.courseTittle,
                path: '/pages/detaile/detaile?id=' + this.courseInfo.id
            };
        }
    }, {
        key: "onLoad",
        value: function () {
            var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(opt) {
                var _this2 = this;

                var view, res, _res$data, course, companions, statistics, CourseComment, actPintuanActivity, ActPintuan, ActPintuanMember;

                return regeneratorRuntime.wrap(function _callee2$(_context2) {
                    while (1) {
                        switch (_context2.prev = _context2.next) {
                            case 0:
                                console.log(opt);
                                // 获取主内容高度，用于悬浮详情导航
                                view = wx.createSelectorQuery().select("#info-box");

                                view.fields({
                                    size: true
                                }, function (data) {
                                    console.log(data.height);
                                    _this2.mainHeight = data.height;
                                }).exec();
                                _context2.next = 5;
                                return _auth2.default.login();

                            case 5:
                                _context2.next = 7;
                                return _config2.default.pintuanDetai(opt.aid);

                            case 7:
                                res = _context2.sent;
                                _res$data = res.data, course = _res$data.course, companions = _res$data.companions, statistics = _res$data.statistics, CourseComment = _res$data.CourseComment, actPintuanActivity = _res$data.actPintuanActivity, ActPintuan = _res$data.ActPintuan, ActPintuanMember = _res$data.ActPintuanMember;

                                this.swipers.list[0].url = course.image;
                                course.courseChar = course.courseChar.split("|");
                                this.courseInfo = course;
                                _wepy2.default.$instance.globalData.courseInfo = course;
                                this.companions = companions;
                                this.statistics = statistics;
                                this.CourseComment = CourseComment;
                                this.actPintuanActivity = actPintuanActivity;
                                this.ActPintuan = ActPintuan;
                                this.ActPintuanMember = ActPintuanMember;
                                this.$apply();

                            case 20:
                            case "end":
                                return _context2.stop();
                        }
                    }
                }, _callee2, this);
            }));

            function onLoad(_x4) {
                return _ref3.apply(this, arguments);
            }

            return onLoad;
        }()
    }]);

    return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/activity/pintuan'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBpbnR1YW4uanMiXSwibmFtZXMiOlsiRGlhbG9nIiwiZGF0YSIsIlRhYkN1ciIsImNsb3NlIiwic3dpcGVycyIsInR5cGUiLCJsaXN0IiwiaWQiLCJ1cmwiLCJsaW5rIiwibGlua1R5cGUiLCJhY3RQaW50dWFuQWN0aXZpdHkiLCJBY3RQaW50dWFuTWVtYmVyIiwiQWN0UGludHVhbiIsIm1haW5IZWlnaHQiLCJjb3Vyc2VJbmZvIiwibm9kZXMiLCJudW0iLCJzaG93U2t1IiwiYnV5VHlwdCIsImNvdXJzZUlueCIsImNvbXBhbmlvbnMiLCJzdGF0aXN0aWNzIiwiQ291cnNlQ29tbWVudCIsInNpZ25fc3RhdGVzIiwidG9QaW50dWFuIiwibnVtTGlzdCIsIm5hbWUiLCJuYW1lMSIsIiRyZXBlYXQiLCIkcHJvcHMiLCIkZXZlbnRzIiwiY29tcG9uZW50cyIsImNTd2lwZXIiLCJjdGl0bGUiLCJjSW5mbyIsImNSZW1ha2UiLCJjb25maWciLCJuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0IiwibWV0aG9kcyIsInRvUGludHVhbmZ5IiwicmV0IiwidGFiU2VsZWN0IiwiZSIsImNvbnNvbGUiLCJsb2ciLCJjdXJyZW50VGFyZ2V0IiwiZGF0YXNldCIsImRldGFpbCIsImN1cnJlbnQiLCJoaWRlTW9kYWwiLCJza3UiLCJwbHVzIiwid3giLCJ2aWJyYXRlU2hvcnQiLCJtaW51cyIsImNvdXJzZSIsImlueCIsImJ1eSIsImFpZCIsIm90IiwiVGlwcyIsInRvYXN0Iiwid2VweSIsIm5hdmlnYXRlVG8iLCJwZXJpb2RMaXN0IiwicGludHVhbklkIiwicmVzIiwiZnJvbSIsInRhcmdldCIsInRpdGxlIiwiY291cnNlVGl0dGxlIiwicGF0aCIsIm9wdCIsInZpZXciLCJjcmVhdGVTZWxlY3RvclF1ZXJ5Iiwic2VsZWN0IiwiZmllbGRzIiwic2l6ZSIsImhlaWdodCIsImV4ZWMiLCJhdXRoIiwibG9naW4iLCJwaW50dWFuRGV0YWkiLCJpbWFnZSIsImNvdXJzZUNoYXIiLCJzcGxpdCIsIiRpbnN0YW5jZSIsImdsb2JhbERhdGEiLCIkYXBwbHkiLCJwYWdlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFDSTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7Ozs7Ozs7Ozs7O0lBQ3FCQSxNOzs7Ozs7Ozs7Ozs7OzswTEFDakJDLEksR0FBTztBQUNIQyxvQkFBUSxDQURMO0FBRUhDLG1CQUFPLDBCQUZKO0FBR0hDLHFCQUFTO0FBQ0xDLHNCQUFNLENBREQ7QUFFTEMsc0JBQU0sQ0FBQztBQUNIQyx3QkFBSSxDQUREO0FBRUhGLDBCQUFNLE9BRkg7QUFHSEcseUJBQUssRUFIRjtBQUlIQywwQkFBTSxrQkFKSDtBQUtIQyw4QkFBVTtBQUxQLGlCQUFEO0FBRkQsYUFITjtBQWFIQyxnQ0FBbUIsRUFiaEI7QUFjSEMsOEJBQWlCLEVBZGQ7QUFlSEMsd0JBQVcsRUFmUjtBQWdCSEMsd0JBQVksQ0FoQlQ7QUFpQkhDLHdCQUFZLEVBakJUO0FBa0JIQyxtQkFBTyxDQUFDLE1BQUQsRUFBUyxPQUFULEVBQWtCLE9BQWxCLENBbEJKO0FBbUJIQyxpQkFBSyxDQW5CRjtBQW9CSEMscUJBQVMsS0FwQk47QUFxQkhDLHFCQUFTLFFBckJOO0FBc0JIQyx1QkFBVyxDQUFDLENBdEJUO0FBdUJIQyx3QkFBWSxFQXZCVDtBQXdCSEMsd0JBQVksRUF4QlQ7QUF5QkhDLDJCQUFlLEVBekJaO0FBMEJIQyx5QkFBYTtBQUNULG1CQUFHLE9BRE07QUFFVCxtQkFBRyxNQUZNO0FBR1QsbUJBQUc7QUFITSxhQTFCVjtBQStCSEMsdUJBQVcsS0EvQlI7QUFnQ0hDLHFCQUFTLENBQUM7QUFDTkMsc0JBQU0sSUFEQTtBQUVOQyx1QkFBTztBQUZELGFBQUQsRUFHTjtBQUNDRCxzQkFBTSxRQURQO0FBRUNDLHVCQUFPO0FBRlIsYUFITSxFQU1OO0FBQ0NELHNCQUFNLE1BRFA7QUFFQ0MsdUJBQU87QUFGUixhQU5NO0FBaENOLFMsUUEyQ1JDLE8sR0FBVSxFLFFBQ2pCQyxNLEdBQVMsRUFBQyxXQUFVLEVBQUMsZ0JBQWUsRUFBaEIsRUFBbUIscUJBQW9CLFNBQXZDLEVBQVgsRUFBNkQsVUFBUyxFQUFDLHFCQUFvQixZQUFyQixFQUF0RSxFQUF5RyxTQUFRLEVBQUMscUJBQW9CLFlBQXJCLEVBQWtDLDBCQUF5QixZQUEzRCxFQUFqSCxFQUEwTCxXQUFVLEVBQUMscUJBQW9CLFlBQXJCLEVBQWtDLDBCQUF5QixZQUEzRCxFQUF3RSw2QkFBNEIsZUFBcEcsRUFBcE0sRSxRQUNUQyxPLEdBQVUsRSxRQUNUQyxVLEdBQWE7QUFDRkMscUNBREU7QUFFRkMsbUNBRkU7QUFHRkMsaUNBSEU7QUFJRkM7QUFKRSxTLFFBTU5DLE0sR0FBUztBQUNMQyxvQ0FBd0I7QUFEbkIsUyxRQW1EVEMsTyxHQUFVO0FBQ05DLHVCQURNLHlCQUNRO0FBQ1YscUJBQUtmLFNBQUwsR0FBaUIsSUFBakI7QUFDSCxhQUhLO0FBSU5nQixlQUpNLGlCQUlBO0FBQ0YsdUJBQU8sS0FBUDtBQUNILGFBTks7QUFPTkMscUJBUE0scUJBT0lDLENBUEosRUFPTztBQUNUQyx3QkFBUUMsR0FBUixDQUFZRixDQUFaO0FBQ0EscUJBQUt6QyxNQUFMLEdBQWN5QyxFQUFFRyxhQUFGLENBQWdCQyxPQUFoQixDQUF3QnhDLEVBQXhCLElBQThCb0MsRUFBRUssTUFBRixDQUFTQyxPQUFyRDtBQUNILGFBVks7QUFXTkMscUJBWE0sdUJBV007QUFDUixxQkFBS3pCLFNBQUwsR0FBaUIsS0FBakI7QUFDQSxxQkFBS1AsT0FBTCxHQUFlLEtBQWY7QUFDSCxhQWRLO0FBZU5pQyxlQWZNLGlCQWVlO0FBQUEsb0JBQWpCOUMsSUFBaUIsdUVBQVYsUUFBVTs7QUFDakIscUJBQUthLE9BQUwsR0FBZSxJQUFmO0FBQ0EscUJBQUtPLFNBQUwsR0FBaUIsS0FBakI7QUFDQSxxQkFBS04sT0FBTCxHQUFlZCxJQUFmO0FBQ0gsYUFuQks7QUFvQk4rQyxnQkFwQk0sa0JBb0JDO0FBQ0hDLG1CQUFHQyxZQUFIO0FBQ0EscUJBQUtyQyxHQUFMLEdBQVcsS0FBS0EsR0FBTCxHQUFXLENBQXRCO0FBQ0gsYUF2Qks7QUF3Qk5zQyxpQkF4Qk0sbUJBd0JFO0FBQ0osb0JBQUksS0FBS3RDLEdBQUwsR0FBVyxDQUFmLEVBQWtCO0FBQ2RvQyx1QkFBR0MsWUFBSDtBQUNBLHlCQUFLckMsR0FBTCxHQUFXLEtBQUtBLEdBQUwsR0FBVyxDQUF0QjtBQUNIO0FBQ0osYUE3Qks7QUE4Qk51QyxrQkE5Qk0sa0JBOEJDQyxHQTlCRCxFQThCTTtBQUNSLHFCQUFLckMsU0FBTCxHQUFpQnFDLEdBQWpCO0FBQ0gsYUFoQ0s7QUFpQ0FDLGVBakNBO0FBQUE7QUFBQSx3QkFpQ0lDLEdBakNKLHVFQWlDVSxDQWpDVjtBQUFBLHdCQWlDYUMsRUFqQ2IsdUVBaUNrQixDQWpDbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBDQWtDRSxLQUFLeEMsU0FBTCxJQUFrQixDQUFDLENBbENyQjtBQUFBO0FBQUE7QUFBQTs7QUFtQ0V5QyxtREFBS0MsS0FBTCxDQUFXLFNBQVgsRUFBc0IsZUFBTyxDQUFFLENBQS9CLEVBQWlDLE1BQWpDO0FBbkNGLHFFQW9DUyxLQXBDVDs7QUFBQTtBQXNDRkMsbURBQUtDLFVBQUwsQ0FBZ0I7QUFDWnhELDRFQUFrQ29ELEVBQWxDLGFBQTRDLEtBQUs3QyxVQUFMLENBQWdCa0QsVUFBaEIsQ0FBMkIsS0FBSzdDLFNBQWhDLEVBQTJDYixFQUF2RixhQUFpRyxLQUFLUSxVQUFMLENBQWdCUixFQUFqSCxhQUEySCxLQUFLVSxHQUFoSSxhQUEySTBDLEdBQTNJLGdCQUF5SixLQUFLNUMsVUFBTCxDQUFnQm1EO0FBRDdKLHFDQUFoQjs7QUF0Q0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQSxTOzs7Ozs7QUFoRFY7MENBQ2tCQyxHLEVBQUs7QUFDbkIsZ0JBQUlBLElBQUlDLElBQUosS0FBYSxRQUFqQixFQUEyQjtBQUN2QjtBQUNBeEIsd0JBQVFDLEdBQVIsQ0FBWXNCLElBQUlFLE1BQWhCO0FBQ0g7QUFDRCxtQkFBTztBQUNIQyx1QkFBTyxLQUFLdkQsVUFBTCxDQUFnQndELFlBRHBCO0FBRUhDLHNCQUFNLCtCQUErQixLQUFLekQsVUFBTCxDQUFnQlI7QUFGbEQsYUFBUDtBQUlIOzs7O2tHQUNZa0UsRzs7Ozs7Ozs7O0FBQ1Q3Qix3Q0FBUUMsR0FBUixDQUFZNEIsR0FBWjtBQUNBO0FBQ0lDLG9DLEdBQU9yQixHQUFHc0IsbUJBQUgsR0FBeUJDLE1BQXpCLENBQWdDLFdBQWhDLEM7O0FBQ1hGLHFDQUNLRyxNQURMLENBQ1k7QUFDQUMsMENBQU07QUFETixpQ0FEWixFQUlRLGdCQUFRO0FBQ0psQyw0Q0FBUUMsR0FBUixDQUFZNUMsS0FBSzhFLE1BQWpCO0FBQ0EsMkNBQUtqRSxVQUFMLEdBQWtCYixLQUFLOEUsTUFBdkI7QUFDSCxpQ0FQVCxFQVNLQyxJQVRMOzt1Q0FVTUMsZUFBS0MsS0FBTCxFOzs7O3VDQUNVN0MsaUJBQU84QyxZQUFQLENBQW9CVixJQUFJZCxHQUF4QixDOzs7QUFBWlEsbUM7NENBU0FBLElBQUlsRSxJLEVBUEp1RCxNLGFBQUFBLE0sRUFDQW5DLFUsYUFBQUEsVSxFQUNBQyxVLGFBQUFBLFUsRUFDQUMsYSxhQUFBQSxhLEVBQ0FaLGtCLGFBQUFBLGtCLEVBQ0FFLFUsYUFBQUEsVSxFQUNBRCxnQixhQUFBQSxnQjs7QUFFSixxQ0FBS1IsT0FBTCxDQUFhRSxJQUFiLENBQWtCLENBQWxCLEVBQXFCRSxHQUFyQixHQUEyQmdELE9BQU80QixLQUFsQztBQUNBNUIsdUNBQU82QixVQUFQLEdBQW9CN0IsT0FBTzZCLFVBQVAsQ0FBa0JDLEtBQWxCLENBQXdCLEdBQXhCLENBQXBCO0FBQ0EscUNBQUt2RSxVQUFMLEdBQWtCeUMsTUFBbEI7QUFDQU8sK0NBQUt3QixTQUFMLENBQWVDLFVBQWYsQ0FBMEJ6RSxVQUExQixHQUF1Q3lDLE1BQXZDO0FBQ0EscUNBQUtuQyxVQUFMLEdBQWtCQSxVQUFsQjtBQUNBLHFDQUFLQyxVQUFMLEdBQWtCQSxVQUFsQjtBQUNBLHFDQUFLQyxhQUFMLEdBQXFCQSxhQUFyQjtBQUNBLHFDQUFLWixrQkFBTCxHQUEwQkEsa0JBQTFCO0FBQ0EscUNBQUtFLFVBQUwsR0FBa0JBLFVBQWxCO0FBQ0EscUNBQUtELGdCQUFMLEdBQXdCQSxnQkFBeEI7QUFDQSxxQ0FBSzZFLE1BQUw7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUF0RzRCMUIsZUFBSzJCLEk7O2tCQUFwQjFGLE0iLCJmaWxlIjoicGludHVhbi5qcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4gICAgaW1wb3J0IHdlcHkgZnJvbSBcIndlcHlcIjtcclxuICAgIGltcG9ydCBjU3dpcGVyIGZyb20gXCJAL2NvbXBvbmVudHMvY29tbW9uL3N3aXBlclwiO1xyXG4gICAgaW1wb3J0IGN0aXRsZSBmcm9tIFwiQC9jb21wb25lbnRzL2RldGFpbGUvdGl0bGVcIjtcclxuICAgIGltcG9ydCBjSW5mbyBmcm9tIFwiQC9jb21wb25lbnRzL2RldGFpbGUvaW5mb1wiO1xyXG4gICAgaW1wb3J0IGNSZW1ha2UgZnJvbSBcIkAvY29tcG9uZW50cy9kZXRhaWxlL3JlbWFrZVwiO1xyXG4gICAgaW1wb3J0IGNvbmZpZyBmcm9tIFwiQC9hcGkvY29uZmlnXCI7XHJcbiAgICBpbXBvcnQgYXV0aCBmcm9tIFwiQC9hcGkvYXV0aFwiO1xyXG4gICAgaW1wb3J0IFd4VXRpbHMgZnJvbSBcIkAvdXRpbHMvV3hVdGlsc1wiO1xyXG4gICAgaW1wb3J0IFRpcHMgZnJvbSBcIkAvdXRpbHMvVGlwc1wiO1xyXG4gICAgZXhwb3J0IGRlZmF1bHQgY2xhc3MgRGlhbG9nIGV4dGVuZHMgd2VweS5wYWdlIHtcclxuICAgICAgICBkYXRhID0ge1xyXG4gICAgICAgICAgICBUYWJDdXI6IDAsXHJcbiAgICAgICAgICAgIGNsb3NlOiBcIi9zdGF0aWMvaW1hZ2VzL2Nsb3NlLnBuZ1wiLFxyXG4gICAgICAgICAgICBzd2lwZXJzOiB7XHJcbiAgICAgICAgICAgICAgICB0eXBlOiAxLFxyXG4gICAgICAgICAgICAgICAgbGlzdDogW3tcclxuICAgICAgICAgICAgICAgICAgICBpZDogMCxcclxuICAgICAgICAgICAgICAgICAgICB0eXBlOiBcImltYWdlXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgdXJsOiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgICAgIGxpbms6IFwiL3BhZ2VzL21lZXQvbWVldFwiLFxyXG4gICAgICAgICAgICAgICAgICAgIGxpbmtUeXBlOiBcInN3aXRjaFRhYlwiXHJcbiAgICAgICAgICAgICAgICB9XVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBhY3RQaW50dWFuQWN0aXZpdHk6e30sXHJcbiAgICAgICAgICAgIEFjdFBpbnR1YW5NZW1iZXI6e30sXHJcbiAgICAgICAgICAgIEFjdFBpbnR1YW46e30sXHJcbiAgICAgICAgICAgIG1haW5IZWlnaHQ6IDAsXHJcbiAgICAgICAgICAgIGNvdXJzZUluZm86IHt9LFxyXG4gICAgICAgICAgICBub2RlczogW1wibmFtZVwiLCBcImF0dHJzXCIsIFwiYXR0cnNcIl0sXHJcbiAgICAgICAgICAgIG51bTogMSxcclxuICAgICAgICAgICAgc2hvd1NrdTogZmFsc2UsXHJcbiAgICAgICAgICAgIGJ1eVR5cHQ6ICdub3JtYWwnLFxyXG4gICAgICAgICAgICBjb3Vyc2VJbng6IC0xLFxyXG4gICAgICAgICAgICBjb21wYW5pb25zOiBbXSxcclxuICAgICAgICAgICAgc3RhdGlzdGljczoge30sXHJcbiAgICAgICAgICAgIENvdXJzZUNvbW1lbnQ6IHt9LFxyXG4gICAgICAgICAgICBzaWduX3N0YXRlczoge1xyXG4gICAgICAgICAgICAgICAgMDogJ+eBq+eDreaLm+eUn+S4rScsXHJcbiAgICAgICAgICAgICAgICAxOiAn5bCR6YeP5ZCN6aKdJyxcclxuICAgICAgICAgICAgICAgIDI6ICflt7Lmu6HlkZgnXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHRvUGludHVhbjogZmFsc2UsXHJcbiAgICAgICAgICAgIG51bUxpc3Q6IFt7XHJcbiAgICAgICAgICAgICAgICBuYW1lOiAn5Y+C5ZuiJyxcclxuICAgICAgICAgICAgICAgIG5hbWUxOiAn5pSv5LuY5a6M5oiQJ1xyXG4gICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICBuYW1lOiAn6I635b6X5pu05aSa5LyY5oOgJyxcclxuICAgICAgICAgICAgICAgIG5hbWUxOiAn5YiG5Lqr5rS75YqoJ1xyXG4gICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICBuYW1lOiAn5ou85Zui5oiQ5YqfJyxcclxuICAgICAgICAgICAgICAgIG5hbWUxOiAn6ICB5biI5Li75Yqo6IGU57O75oKoJ1xyXG4gICAgICAgICAgICB9XVxyXG4gICAgICAgIH07XHJcbiAgICAgICAkcmVwZWF0ID0ge307XHJcbiRwcm9wcyA9IHtcImNTd2lwZXJcIjp7XCJ4bWxuczp2LWJpbmRcIjpcIlwiLFwidi1iaW5kOm1vZGVsLnN5bmNcIjpcInN3aXBlcnNcIn0sXCJjdGl0bGVcIjp7XCJ2LWJpbmQ6bW9kZWwuc3luY1wiOlwiY291cnNlSW5mb1wifSxcImNJbmZvXCI6e1widi1iaW5kOm1vZGVsLnN5bmNcIjpcImNvdXJzZUluZm9cIixcInYtYmluZDpjb21wYW5pb25zLnN5bmNcIjpcImNvbXBhbmlvbnNcIn0sXCJjUmVtYWtlXCI6e1widi1iaW5kOm1vZGVsLnN5bmNcIjpcImNvdXJzZUluZm9cIixcInYtYmluZDpzdGF0aXN0aWNzLnN5bmNcIjpcInN0YXRpc3RpY3NcIixcInYtYmluZDpDb3Vyc2VDb21tZW50LnN5bmNcIjpcIkNvdXJzZUNvbW1lbnRcIn19O1xyXG4kZXZlbnRzID0ge307XHJcbiBjb21wb25lbnRzID0ge1xyXG4gICAgICAgICAgICBjU3dpcGVyLFxyXG4gICAgICAgICAgICBjdGl0bGUsXHJcbiAgICAgICAgICAgIGNJbmZvLFxyXG4gICAgICAgICAgICBjUmVtYWtlXHJcbiAgICAgICAgfTtcclxuICAgICAgICBjb25maWcgPSB7XHJcbiAgICAgICAgICAgIG5hdmlnYXRpb25CYXJUaXRsZVRleHQ6IFwi5rS75Yqo6K+m5oOFXCJcclxuICAgICAgICB9O1xyXG4gICAgICAgIC8vIOi9rOWPkeaaguaXtuWFiOS4jeW8gOWQr1xyXG4gICAgICAgIG9uU2hhcmVBcHBNZXNzYWdlKHJlcykge1xyXG4gICAgICAgICAgICBpZiAocmVzLmZyb20gPT09ICdidXR0b24nKSB7XHJcbiAgICAgICAgICAgICAgICAvLyDmnaXoh6rpobXpnaLlhoXovazlj5HmjInpkq5cclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKHJlcy50YXJnZXQpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgIHRpdGxlOiB0aGlzLmNvdXJzZUluZm8uY291cnNlVGl0dGxlLFxyXG4gICAgICAgICAgICAgICAgcGF0aDogJy9wYWdlcy9kZXRhaWxlL2RldGFpbGU/aWQ9JyArIHRoaXMuY291cnNlSW5mby5pZFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGFzeW5jIG9uTG9hZChvcHQpIHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2cob3B0KVxyXG4gICAgICAgICAgICAvLyDojrflj5bkuLvlhoXlrrnpq5jluqbvvIznlKjkuo7mgqzmta7or6bmg4Xlr7zoiKpcclxuICAgICAgICAgICAgbGV0IHZpZXcgPSB3eC5jcmVhdGVTZWxlY3RvclF1ZXJ5KCkuc2VsZWN0KFwiI2luZm8tYm94XCIpO1xyXG4gICAgICAgICAgICB2aWV3XHJcbiAgICAgICAgICAgICAgICAuZmllbGRzKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZTogdHJ1ZVxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgZGF0YSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGRhdGEuaGVpZ2h0KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5tYWluSGVpZ2h0ID0gZGF0YS5oZWlnaHQ7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgLmV4ZWMoKTtcclxuICAgICAgICAgICAgYXdhaXQgYXV0aC5sb2dpbigpXHJcbiAgICAgICAgICAgIGxldCByZXMgPSBhd2FpdCBjb25maWcucGludHVhbkRldGFpKG9wdC5haWQpXHJcbiAgICAgICAgICAgIGxldCB7XHJcbiAgICAgICAgICAgICAgICBjb3Vyc2UsXHJcbiAgICAgICAgICAgICAgICBjb21wYW5pb25zLFxyXG4gICAgICAgICAgICAgICAgc3RhdGlzdGljcyxcclxuICAgICAgICAgICAgICAgIENvdXJzZUNvbW1lbnQsXHJcbiAgICAgICAgICAgICAgICBhY3RQaW50dWFuQWN0aXZpdHksXHJcbiAgICAgICAgICAgICAgICBBY3RQaW50dWFuLFxyXG4gICAgICAgICAgICAgICAgQWN0UGludHVhbk1lbWJlclxyXG4gICAgICAgICAgICB9ID0gcmVzLmRhdGFcclxuICAgICAgICAgICAgdGhpcy5zd2lwZXJzLmxpc3RbMF0udXJsID0gY291cnNlLmltYWdlXHJcbiAgICAgICAgICAgIGNvdXJzZS5jb3Vyc2VDaGFyID0gY291cnNlLmNvdXJzZUNoYXIuc3BsaXQoXCJ8XCIpXHJcbiAgICAgICAgICAgIHRoaXMuY291cnNlSW5mbyA9IGNvdXJzZVxyXG4gICAgICAgICAgICB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLmNvdXJzZUluZm8gPSBjb3Vyc2VcclxuICAgICAgICAgICAgdGhpcy5jb21wYW5pb25zID0gY29tcGFuaW9uc1xyXG4gICAgICAgICAgICB0aGlzLnN0YXRpc3RpY3MgPSBzdGF0aXN0aWNzXHJcbiAgICAgICAgICAgIHRoaXMuQ291cnNlQ29tbWVudCA9IENvdXJzZUNvbW1lbnRcclxuICAgICAgICAgICAgdGhpcy5hY3RQaW50dWFuQWN0aXZpdHkgPSBhY3RQaW50dWFuQWN0aXZpdHlcclxuICAgICAgICAgICAgdGhpcy5BY3RQaW50dWFuID0gQWN0UGludHVhblxyXG4gICAgICAgICAgICB0aGlzLkFjdFBpbnR1YW5NZW1iZXIgPSBBY3RQaW50dWFuTWVtYmVyXHJcbiAgICAgICAgICAgIHRoaXMuJGFwcGx5KCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIG1ldGhvZHMgPSB7XHJcbiAgICAgICAgICAgIHRvUGludHVhbmZ5KCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy50b1BpbnR1YW4gPSB0cnVlXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHJldCgpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB0YWJTZWxlY3QoZSkge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLlRhYkN1ciA9IGUuY3VycmVudFRhcmdldC5kYXRhc2V0LmlkIHx8IGUuZGV0YWlsLmN1cnJlbnQ7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGhpZGVNb2RhbCgpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMudG9QaW50dWFuID0gZmFsc2VcclxuICAgICAgICAgICAgICAgIHRoaXMuc2hvd1NrdSA9IGZhbHNlXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHNrdSh0eXBlID0gJ25vcm1hbCcpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuc2hvd1NrdSA9IHRydWVcclxuICAgICAgICAgICAgICAgIHRoaXMudG9QaW50dWFuID0gZmFsc2VcclxuICAgICAgICAgICAgICAgIHRoaXMuYnV5VHlwdCA9IHR5cGVcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgcGx1cygpIHtcclxuICAgICAgICAgICAgICAgIHd4LnZpYnJhdGVTaG9ydCgpXHJcbiAgICAgICAgICAgICAgICB0aGlzLm51bSA9IHRoaXMubnVtICsgMVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBtaW51cygpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLm51bSA+IDEpIHtcclxuICAgICAgICAgICAgICAgICAgICB3eC52aWJyYXRlU2hvcnQoKVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubnVtID0gdGhpcy5udW0gLSAxXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGNvdXJzZShpbngpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuY291cnNlSW54ID0gaW54XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGFzeW5jIGJ1eShhaWQgPSAwLCBvdCA9IDEsICkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuY291cnNlSW54ID09IC0xKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgVGlwcy50b2FzdChcIuivt+mAieaLqeS4gOS4quiQpeacn1wiLCByZXMgPT4ge30sICdub25lJylcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHdlcHkubmF2aWdhdGVUbyh7XHJcbiAgICAgICAgICAgICAgICAgICAgdXJsOiBgLi4vZGV0YWlsZS9zdXJlT3JkZXI/dHlwZT0ke290fSZwaWQ9JHt0aGlzLmNvdXJzZUluZm8ucGVyaW9kTGlzdFt0aGlzLmNvdXJzZUlueF0uaWR9JmNpZD0ke3RoaXMuY291cnNlSW5mby5pZH0mbnVtPSR7dGhpcy5udW19JmFpZD0ke2FpZH0mYWN0cGlkPSR7dGhpcy5jb3Vyc2VJbmZvLnBpbnR1YW5JZH1gXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH07XHJcbiAgICB9XHJcbiJdfQ==