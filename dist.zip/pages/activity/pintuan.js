"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _swiper = require('./../../components/common/swiper.js');

var _swiper2 = _interopRequireDefault(_swiper);

var _title = require('./../../components/detaile/title.js');

var _title2 = _interopRequireDefault(_title);

var _info = require('./../../components/detaile/info.js');

var _info2 = _interopRequireDefault(_info);

var _remake = require('./../../components/detaile/remake.js');

var _remake2 = _interopRequireDefault(_remake);

var _contact = require('./../../components/common/contact.js');

var _contact2 = _interopRequireDefault(_contact);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

var _WxUtils = require('./../../utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

var _utils = require('./../../store/utils.js');

var _utils2 = _interopRequireDefault(_utils);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
    _inherits(Dialog, _wepy$page);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.data = {
            TabCur: 0,
            close: "/static/images/close.png",
            swipers: {
                type: 1,
                list: [{
                    id: 0,
                    type: "image",
                    url: "",
                    link: "/pages/meet/meet",
                    linkType: "switchTab"
                }]
            },
            actPintuanActivity: {},
            ActPintuanMember: {},
            ActPintuan: {},
            mainHeight: 0,
            courseInfo: {},
            modalName: '',
            nodes: ["name", "attrs", "attrs"],
            num: 1,
            isIn: '',
            showSku: false,
            buyTypt: 'normal',
            courseInx: -1,
            companions: [],
            statistics: {},
            CourseComment: {},
            sign_states: {
                0: '火热招生中',
                1: '少量名额',
                2: '已满员'
            },
            toPintuan: false,
            numList: [{
                name: '参团',
                name1: '支付完成'
            }, {
                name: '获得更多优惠',
                name1: '分享活动'
            }, {
                name: '拼团成功',
                name1: '老师主动联系您'
            }],
            member: {}
        }, _this.$repeat = {}, _this.$props = { "cSwiper": { "xmlns:v-bind": "", "v-bind:model.sync": "swipers" }, "ctitle": { "v-bind:model.sync": "courseInfo" }, "cInfo": { "v-bind:model.sync": "courseInfo", "v-bind:companions.sync": "companions" }, "cRemake": { "v-bind:model.sync": "courseInfo", "v-bind:statistics.sync": "statistics", "v-bind:CourseComment.sync": "CourseComment" } }, _this.$events = {}, _this.components = {
            cSwiper: _swiper2.default,
            ctitle: _title2.default,
            cInfo: _info2.default,
            cRemake: _remake2.default,
            contact: _contact2.default
        }, _this.config = {
            navigationBarTitleText: "活动详情"
        }, _this.methods = {
            createImg: function () {
                var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(e) {
                    return regeneratorRuntime.wrap(function _callee$(_context) {
                        while (1) {
                            switch (_context.prev = _context.next) {
                                case 0:
                                    if (!(e.detail.errMsg == "getUserInfo:ok")) {
                                        _context.next = 5;
                                        break;
                                    }

                                    _context.next = 3;
                                    return _auth2.default.getUserinfo(e.detail);

                                case 3:
                                    _utils2.default.save('shareInfo', {
                                        course: this.courseInfo,
                                        path: 'pages/activity/pintuan',
                                        id: this.actPintuanActivity.id,
                                        type: 3,
                                        courseId: this.courseInfo.id
                                    });
                                    _wepy2.default.navigateTo({
                                        url: '/pages/home/share'
                                    });

                                case 5:
                                case "end":
                                    return _context.stop();
                            }
                        }
                    }, _callee, this);
                }));

                function createImg(_x) {
                    return _ref2.apply(this, arguments);
                }

                return createImg;
            }(),
            toshare: function toshare() {
                this.modalName = 'share';
            },
            toPintuanfy: function toPintuanfy() {
                this.toPintuan = true;
            },
            ret: function ret() {
                return false;
            },
            tabSelect: function tabSelect(e) {
                console.log(e);
                this.TabCur = e.currentTarget.dataset.id || e.detail.current;
            },
            hideModal: function hideModal() {
                this.toPintuan = false;
                this.showSku = false;
                this.modalName = '';
            },
            sku: function sku() {
                var type = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'normal';

                this.showSku = true;
                this.toPintuan = false;
                this.buyTypt = type;
            },
            plus: function plus() {
                wx.vibrateShort();
                this.num = this.num + 1;
            },
            minus: function minus() {
                if (this.num > 1) {
                    wx.vibrateShort();
                    this.num = this.num - 1;
                }
            },
            course: function course(inx) {
                this.courseInx = inx;
            },
            buy: function () {
                var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
                    var aid = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;
                    var ot = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1;
                    return regeneratorRuntime.wrap(function _callee2$(_context2) {
                        while (1) {
                            switch (_context2.prev = _context2.next) {
                                case 0:
                                    if (!(this.courseInx == -1)) {
                                        _context2.next = 3;
                                        break;
                                    }

                                    _Tips2.default.toast("请选择一个营期", function (res) {}, 'none');
                                    return _context2.abrupt("return", false);

                                case 3:
                                    _wepy2.default.navigateTo({
                                        url: "../detaile/sureOrder?type=" + ot + "&pid=" + this.courseInfo.periodList[this.courseInx].id + "&cid=" + this.courseInfo.id + "&num=" + this.num + "&aid=" + this.actPintuanActivity.id + "&actpid=" + this.courseInfo.pintuanId
                                    });

                                case 4:
                                case "end":
                                    return _context2.stop();
                            }
                        }
                    }, _callee2, this);
                }));

                function buy() {
                    return _ref3.apply(this, arguments);
                }

                return buy;
            }()
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(Dialog, [{
        key: "onShareAppMessage",

        // 转发暂时先不开启
        value: function onShareAppMessage(res) {
            if (res.from === 'button') {
                // 来自页面内转发按钮
                console.log(res.target);
            }
            return {
                title: this.courseInfo.courseTittle,
                imageUrl: this.courseInfo.image,
                path: '/pages/activity/pintuan?id=' + this.actPintuanActivity.id + '&agentId=' + this.member.agentId
            };
        }
    }, {
        key: "onLoad",
        value: function () {
            var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(opt) {
                var _this2 = this;

                var view, res, _res$data, course, companions, statistics, CourseComment, actPintuanActivity, ActPintuan, ActPintuanMember, isIn;

                return regeneratorRuntime.wrap(function _callee3$(_context3) {
                    while (1) {
                        switch (_context3.prev = _context3.next) {
                            case 0:
                                console.log(opt);
                                // 获取主内容高度，用于悬浮详情导航
                                view = wx.createSelectorQuery().select("#info-box");

                                view.fields({
                                    size: true
                                }, function (data) {
                                    console.log(data.height);
                                    _this2.mainHeight = data.height;
                                }).exec();
                                _context3.next = 5;
                                return _auth2.default.login();

                            case 5:
                                this.member = _wepy2.default.getStorageSync('member');
                                _context3.next = 8;
                                return _config2.default.pintuanDetai(opt.id || opt.scene);

                            case 8:
                                res = _context3.sent;
                                _res$data = res.data, course = _res$data.course, companions = _res$data.companions, statistics = _res$data.statistics, CourseComment = _res$data.CourseComment, actPintuanActivity = _res$data.actPintuanActivity, ActPintuan = _res$data.ActPintuan, ActPintuanMember = _res$data.ActPintuanMember, isIn = _res$data.isIn;

                                this.swipers.list[0].url = course.image;
                                course.courseChar = course.courseChar.split("|");
                                this.courseInfo = course;
                                _wepy2.default.$instance.globalData.courseInfo = course;
                                this.companions = companions;
                                this.statistics = statistics;
                                this.CourseComment = CourseComment;
                                this.actPintuanActivity = actPintuanActivity;
                                this.ActPintuan = ActPintuan;
                                this.ActPintuanMember = ActPintuanMember;
                                this.isIn = isIn;
                                this.$apply();

                            case 22:
                            case "end":
                                return _context3.stop();
                        }
                    }
                }, _callee3, this);
            }));

            function onLoad(_x5) {
                return _ref4.apply(this, arguments);
            }

            return onLoad;
        }()
    }]);

    return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/activity/pintuan'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBpbnR1YW4uanMiXSwibmFtZXMiOlsiRGlhbG9nIiwiZGF0YSIsIlRhYkN1ciIsImNsb3NlIiwic3dpcGVycyIsInR5cGUiLCJsaXN0IiwiaWQiLCJ1cmwiLCJsaW5rIiwibGlua1R5cGUiLCJhY3RQaW50dWFuQWN0aXZpdHkiLCJBY3RQaW50dWFuTWVtYmVyIiwiQWN0UGludHVhbiIsIm1haW5IZWlnaHQiLCJjb3Vyc2VJbmZvIiwibW9kYWxOYW1lIiwibm9kZXMiLCJudW0iLCJpc0luIiwic2hvd1NrdSIsImJ1eVR5cHQiLCJjb3Vyc2VJbngiLCJjb21wYW5pb25zIiwic3RhdGlzdGljcyIsIkNvdXJzZUNvbW1lbnQiLCJzaWduX3N0YXRlcyIsInRvUGludHVhbiIsIm51bUxpc3QiLCJuYW1lIiwibmFtZTEiLCJtZW1iZXIiLCIkcmVwZWF0IiwiJHByb3BzIiwiJGV2ZW50cyIsImNvbXBvbmVudHMiLCJjU3dpcGVyIiwiY3RpdGxlIiwiY0luZm8iLCJjUmVtYWtlIiwiY29udGFjdCIsImNvbmZpZyIsIm5hdmlnYXRpb25CYXJUaXRsZVRleHQiLCJtZXRob2RzIiwiY3JlYXRlSW1nIiwiZSIsImRldGFpbCIsImVyck1zZyIsImF1dGgiLCJnZXRVc2VyaW5mbyIsInN0b3JlIiwic2F2ZSIsImNvdXJzZSIsInBhdGgiLCJjb3Vyc2VJZCIsIndlcHkiLCJuYXZpZ2F0ZVRvIiwidG9zaGFyZSIsInRvUGludHVhbmZ5IiwicmV0IiwidGFiU2VsZWN0IiwiY29uc29sZSIsImxvZyIsImN1cnJlbnRUYXJnZXQiLCJkYXRhc2V0IiwiY3VycmVudCIsImhpZGVNb2RhbCIsInNrdSIsInBsdXMiLCJ3eCIsInZpYnJhdGVTaG9ydCIsIm1pbnVzIiwiaW54IiwiYnV5IiwiYWlkIiwib3QiLCJUaXBzIiwidG9hc3QiLCJwZXJpb2RMaXN0IiwicGludHVhbklkIiwicmVzIiwiZnJvbSIsInRhcmdldCIsInRpdGxlIiwiY291cnNlVGl0dGxlIiwiaW1hZ2VVcmwiLCJpbWFnZSIsImFnZW50SWQiLCJvcHQiLCJ2aWV3IiwiY3JlYXRlU2VsZWN0b3JRdWVyeSIsInNlbGVjdCIsImZpZWxkcyIsInNpemUiLCJoZWlnaHQiLCJleGVjIiwibG9naW4iLCJnZXRTdG9yYWdlU3luYyIsInBpbnR1YW5EZXRhaSIsInNjZW5lIiwiY291cnNlQ2hhciIsInNwbGl0IiwiJGluc3RhbmNlIiwiZ2xvYmFsRGF0YSIsIiRhcHBseSIsInBhZ2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUNJOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7Ozs7Ozs7Ozs7O0lBQ3FCQSxNOzs7Ozs7Ozs7Ozs7OzswTEFDakJDLEksR0FBTztBQUNIQyxvQkFBUSxDQURMO0FBRUhDLG1CQUFPLDBCQUZKO0FBR0hDLHFCQUFTO0FBQ0xDLHNCQUFNLENBREQ7QUFFTEMsc0JBQU0sQ0FBQztBQUNIQyx3QkFBSSxDQUREO0FBRUhGLDBCQUFNLE9BRkg7QUFHSEcseUJBQUssRUFIRjtBQUlIQywwQkFBTSxrQkFKSDtBQUtIQyw4QkFBVTtBQUxQLGlCQUFEO0FBRkQsYUFITjtBQWFIQyxnQ0FBbUIsRUFiaEI7QUFjSEMsOEJBQWlCLEVBZGQ7QUFlSEMsd0JBQVcsRUFmUjtBQWdCSEMsd0JBQVksQ0FoQlQ7QUFpQkhDLHdCQUFZLEVBakJUO0FBa0JIQyx1QkFBVSxFQWxCUDtBQW1CSEMsbUJBQU8sQ0FBQyxNQUFELEVBQVMsT0FBVCxFQUFrQixPQUFsQixDQW5CSjtBQW9CSEMsaUJBQUssQ0FwQkY7QUFxQkhDLGtCQUFLLEVBckJGO0FBc0JIQyxxQkFBUyxLQXRCTjtBQXVCSEMscUJBQVMsUUF2Qk47QUF3QkhDLHVCQUFXLENBQUMsQ0F4QlQ7QUF5QkhDLHdCQUFZLEVBekJUO0FBMEJIQyx3QkFBWSxFQTFCVDtBQTJCSEMsMkJBQWUsRUEzQlo7QUE0QkhDLHlCQUFhO0FBQ1QsbUJBQUcsT0FETTtBQUVULG1CQUFHLE1BRk07QUFHVCxtQkFBRztBQUhNLGFBNUJWO0FBaUNIQyx1QkFBVyxLQWpDUjtBQWtDSEMscUJBQVMsQ0FBQztBQUNOQyxzQkFBTSxJQURBO0FBRU5DLHVCQUFPO0FBRkQsYUFBRCxFQUdOO0FBQ0NELHNCQUFNLFFBRFA7QUFFQ0MsdUJBQU87QUFGUixhQUhNLEVBTU47QUFDQ0Qsc0JBQU0sTUFEUDtBQUVDQyx1QkFBTztBQUZSLGFBTk0sQ0FsQ047QUE0Q0hDLG9CQUFPO0FBNUNKLFMsUUE4Q1JDLE8sR0FBVSxFLFFBQ2pCQyxNLEdBQVMsRUFBQyxXQUFVLEVBQUMsZ0JBQWUsRUFBaEIsRUFBbUIscUJBQW9CLFNBQXZDLEVBQVgsRUFBNkQsVUFBUyxFQUFDLHFCQUFvQixZQUFyQixFQUF0RSxFQUF5RyxTQUFRLEVBQUMscUJBQW9CLFlBQXJCLEVBQWtDLDBCQUF5QixZQUEzRCxFQUFqSCxFQUEwTCxXQUFVLEVBQUMscUJBQW9CLFlBQXJCLEVBQWtDLDBCQUF5QixZQUEzRCxFQUF3RSw2QkFBNEIsZUFBcEcsRUFBcE0sRSxRQUNUQyxPLEdBQVUsRSxRQUNUQyxVLEdBQWE7QUFDRkMscUNBREU7QUFFRkMsbUNBRkU7QUFHRkMsaUNBSEU7QUFJRkMscUNBSkU7QUFLRkM7QUFMRSxTLFFBT05DLE0sR0FBUztBQUNMQyxvQ0FBd0I7QUFEbkIsUyxRQXVEVEMsTyxHQUFVO0FBQ0FDLHFCQURBO0FBQUEscUdBQ1VDLENBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBDQUVFQSxFQUFFQyxNQUFGLENBQVNDLE1BQVQsSUFBbUIsZ0JBRnJCO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUEsMkNBR1FDLGVBQUtDLFdBQUwsQ0FBaUJKLEVBQUVDLE1BQW5CLENBSFI7O0FBQUE7QUFJRUksb0RBQU1DLElBQU4sQ0FBVyxXQUFYLEVBQXdCO0FBQ3BCQyxnREFBUSxLQUFLckMsVUFETztBQUVwQnNDLDhDQUFNLHdCQUZjO0FBR3BCOUMsNENBQUksS0FBS0ksa0JBQUwsQ0FBd0JKLEVBSFI7QUFJcEJGLDhDQUFLLENBSmU7QUFLcEJpRCxrREFBUyxLQUFLdkMsVUFBTCxDQUFnQlI7QUFMTCxxQ0FBeEI7QUFPQWdELG1EQUFLQyxVQUFMLENBQWdCO0FBQ1poRCw2Q0FBSztBQURPLHFDQUFoQjs7QUFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQWdCTmlELG1CQWhCTSxxQkFnQkk7QUFDTixxQkFBS3pDLFNBQUwsR0FBaUIsT0FBakI7QUFDSCxhQWxCSztBQW1CTjBDLHVCQW5CTSx5QkFtQlE7QUFDVixxQkFBSy9CLFNBQUwsR0FBaUIsSUFBakI7QUFDSCxhQXJCSztBQXNCTmdDLGVBdEJNLGlCQXNCQTtBQUNGLHVCQUFPLEtBQVA7QUFDSCxhQXhCSztBQXlCTkMscUJBekJNLHFCQXlCSWYsQ0F6QkosRUF5Qk87QUFDVGdCLHdCQUFRQyxHQUFSLENBQVlqQixDQUFaO0FBQ0EscUJBQUszQyxNQUFMLEdBQWMyQyxFQUFFa0IsYUFBRixDQUFnQkMsT0FBaEIsQ0FBd0J6RCxFQUF4QixJQUE4QnNDLEVBQUVDLE1BQUYsQ0FBU21CLE9BQXJEO0FBQ0gsYUE1Qks7QUE2Qk5DLHFCQTdCTSx1QkE2Qk07QUFDUixxQkFBS3ZDLFNBQUwsR0FBaUIsS0FBakI7QUFDQSxxQkFBS1AsT0FBTCxHQUFlLEtBQWY7QUFDQSxxQkFBS0osU0FBTCxHQUFpQixFQUFqQjtBQUNILGFBakNLO0FBa0NObUQsZUFsQ00saUJBa0NlO0FBQUEsb0JBQWpCOUQsSUFBaUIsdUVBQVYsUUFBVTs7QUFDakIscUJBQUtlLE9BQUwsR0FBZSxJQUFmO0FBQ0EscUJBQUtPLFNBQUwsR0FBaUIsS0FBakI7QUFDQSxxQkFBS04sT0FBTCxHQUFlaEIsSUFBZjtBQUNILGFBdENLO0FBdUNOK0QsZ0JBdkNNLGtCQXVDQztBQUNIQyxtQkFBR0MsWUFBSDtBQUNBLHFCQUFLcEQsR0FBTCxHQUFXLEtBQUtBLEdBQUwsR0FBVyxDQUF0QjtBQUNILGFBMUNLO0FBMkNOcUQsaUJBM0NNLG1CQTJDRTtBQUNKLG9CQUFJLEtBQUtyRCxHQUFMLEdBQVcsQ0FBZixFQUFrQjtBQUNkbUQsdUJBQUdDLFlBQUg7QUFDQSx5QkFBS3BELEdBQUwsR0FBVyxLQUFLQSxHQUFMLEdBQVcsQ0FBdEI7QUFDSDtBQUNKLGFBaERLO0FBaUROa0Msa0JBakRNLGtCQWlEQ29CLEdBakRELEVBaURNO0FBQ1IscUJBQUtsRCxTQUFMLEdBQWlCa0QsR0FBakI7QUFDSCxhQW5ESztBQW9EQUMsZUFwREE7QUFBQTtBQUFBLHdCQW9ESUMsR0FwREosdUVBb0RVLENBcERWO0FBQUEsd0JBb0RhQyxFQXBEYix1RUFvRGtCLENBcERsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMENBcURFLEtBQUtyRCxTQUFMLElBQWtCLENBQUMsQ0FyRHJCO0FBQUE7QUFBQTtBQUFBOztBQXNERXNELG1EQUFLQyxLQUFMLENBQVcsU0FBWCxFQUFzQixlQUFPLENBQUUsQ0FBL0IsRUFBaUMsTUFBakM7QUF0REYsc0VBdURTLEtBdkRUOztBQUFBO0FBeURGdEIsbURBQUtDLFVBQUwsQ0FBZ0I7QUFDWmhELDRFQUFrQ21FLEVBQWxDLGFBQTRDLEtBQUs1RCxVQUFMLENBQWdCK0QsVUFBaEIsQ0FBMkIsS0FBS3hELFNBQWhDLEVBQTJDZixFQUF2RixhQUFpRyxLQUFLUSxVQUFMLENBQWdCUixFQUFqSCxhQUEySCxLQUFLVyxHQUFoSSxhQUEySSxLQUFLUCxrQkFBTCxDQUF3QkosRUFBbkssZ0JBQWdMLEtBQUtRLFVBQUwsQ0FBZ0JnRTtBQURwTCxxQ0FBaEI7O0FBekRFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUEsUzs7Ozs7O0FBcERWOzBDQUNrQkMsRyxFQUFLO0FBQ25CLGdCQUFJQSxJQUFJQyxJQUFKLEtBQWEsUUFBakIsRUFBMkI7QUFDdkI7QUFDQXBCLHdCQUFRQyxHQUFSLENBQVlrQixJQUFJRSxNQUFoQjtBQUNIO0FBQ0QsbUJBQU87QUFDSEMsdUJBQU8sS0FBS3BFLFVBQUwsQ0FBZ0JxRSxZQURwQjtBQUVIQywwQkFBUyxLQUFLdEUsVUFBTCxDQUFnQnVFLEtBRnRCO0FBR0hqQyxzQkFBTSxnQ0FBZ0MsS0FBSzFDLGtCQUFMLENBQXdCSixFQUF4RCxHQUE2RCxXQUE3RCxHQUEyRSxLQUFLd0IsTUFBTCxDQUFZd0Q7QUFIMUYsYUFBUDtBQUtIOzs7O2tHQUNZQyxHOzs7Ozs7Ozs7QUFDVDNCLHdDQUFRQyxHQUFSLENBQVkwQixHQUFaO0FBQ0E7QUFDSUMsb0MsR0FBT3BCLEdBQUdxQixtQkFBSCxHQUF5QkMsTUFBekIsQ0FBZ0MsV0FBaEMsQzs7QUFDWEYscUNBQ0tHLE1BREwsQ0FDWTtBQUNBQywwQ0FBTTtBQUROLGlDQURaLEVBSVEsZ0JBQVE7QUFDSmhDLDRDQUFRQyxHQUFSLENBQVk3RCxLQUFLNkYsTUFBakI7QUFDQSwyQ0FBS2hGLFVBQUwsR0FBa0JiLEtBQUs2RixNQUF2QjtBQUNILGlDQVBULEVBU0tDLElBVEw7O3VDQVVNL0MsZUFBS2dELEtBQUwsRTs7O0FBQ04scUNBQUtqRSxNQUFMLEdBQWN3QixlQUFLMEMsY0FBTCxDQUFvQixRQUFwQixDQUFkOzt1Q0FDZ0J4RCxpQkFBT3lELFlBQVAsQ0FBb0JWLElBQUlqRixFQUFKLElBQVVpRixJQUFJVyxLQUFsQyxDOzs7QUFBWm5CLG1DOzRDQVVBQSxJQUFJL0UsSSxFQVJKbUQsTSxhQUFBQSxNLEVBQ0E3QixVLGFBQUFBLFUsRUFDQUMsVSxhQUFBQSxVLEVBQ0FDLGEsYUFBQUEsYSxFQUNBZCxrQixhQUFBQSxrQixFQUNBRSxVLGFBQUFBLFUsRUFDQUQsZ0IsYUFBQUEsZ0IsRUFDQU8sSSxhQUFBQSxJOztBQUVKLHFDQUFLZixPQUFMLENBQWFFLElBQWIsQ0FBa0IsQ0FBbEIsRUFBcUJFLEdBQXJCLEdBQTJCNEMsT0FBT2tDLEtBQWxDO0FBQ0FsQyx1Q0FBT2dELFVBQVAsR0FBb0JoRCxPQUFPZ0QsVUFBUCxDQUFrQkMsS0FBbEIsQ0FBd0IsR0FBeEIsQ0FBcEI7QUFDQSxxQ0FBS3RGLFVBQUwsR0FBa0JxQyxNQUFsQjtBQUNBRywrQ0FBSytDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQnhGLFVBQTFCLEdBQXVDcUMsTUFBdkM7QUFDQSxxQ0FBSzdCLFVBQUwsR0FBa0JBLFVBQWxCO0FBQ0EscUNBQUtDLFVBQUwsR0FBa0JBLFVBQWxCO0FBQ0EscUNBQUtDLGFBQUwsR0FBcUJBLGFBQXJCO0FBQ0EscUNBQUtkLGtCQUFMLEdBQTBCQSxrQkFBMUI7QUFDQSxxQ0FBS0UsVUFBTCxHQUFrQkEsVUFBbEI7QUFDQSxxQ0FBS0QsZ0JBQUwsR0FBd0JBLGdCQUF4QjtBQUNBLHFDQUFLTyxJQUFMLEdBQVlBLElBQVo7QUFDQSxxQ0FBS3FGLE1BQUw7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUE5RzRCakQsZUFBS2tELEk7O2tCQUFwQnpHLE0iLCJmaWxlIjoicGludHVhbi5qcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4gICAgaW1wb3J0IHdlcHkgZnJvbSBcIndlcHlcIjtcclxuICAgIGltcG9ydCBjU3dpcGVyIGZyb20gXCJAL2NvbXBvbmVudHMvY29tbW9uL3N3aXBlclwiO1xyXG4gICAgaW1wb3J0IGN0aXRsZSBmcm9tIFwiQC9jb21wb25lbnRzL2RldGFpbGUvdGl0bGVcIjtcclxuICAgIGltcG9ydCBjSW5mbyBmcm9tIFwiQC9jb21wb25lbnRzL2RldGFpbGUvaW5mb1wiO1xyXG4gICAgaW1wb3J0IGNSZW1ha2UgZnJvbSBcIkAvY29tcG9uZW50cy9kZXRhaWxlL3JlbWFrZVwiO1xyXG4gICAgaW1wb3J0IGNvbnRhY3QgZnJvbSBcIkAvY29tcG9uZW50cy9jb21tb24vY29udGFjdFwiXHJcbiAgICBpbXBvcnQgY29uZmlnIGZyb20gXCJAL2FwaS9jb25maWdcIjtcclxuICAgIGltcG9ydCBhdXRoIGZyb20gXCJAL2FwaS9hdXRoXCI7XHJcbiAgICBpbXBvcnQgV3hVdGlscyBmcm9tIFwiQC91dGlscy9XeFV0aWxzXCI7XHJcbiAgICBpbXBvcnQgVGlwcyBmcm9tIFwiQC91dGlscy9UaXBzXCI7XHJcbiAgICBpbXBvcnQgc3RvcmUgZnJvbSBcIkAvc3RvcmUvdXRpbHNcIlxyXG4gICAgZXhwb3J0IGRlZmF1bHQgY2xhc3MgRGlhbG9nIGV4dGVuZHMgd2VweS5wYWdlIHtcclxuICAgICAgICBkYXRhID0ge1xyXG4gICAgICAgICAgICBUYWJDdXI6IDAsXHJcbiAgICAgICAgICAgIGNsb3NlOiBcIi9zdGF0aWMvaW1hZ2VzL2Nsb3NlLnBuZ1wiLFxyXG4gICAgICAgICAgICBzd2lwZXJzOiB7XHJcbiAgICAgICAgICAgICAgICB0eXBlOiAxLFxyXG4gICAgICAgICAgICAgICAgbGlzdDogW3tcclxuICAgICAgICAgICAgICAgICAgICBpZDogMCxcclxuICAgICAgICAgICAgICAgICAgICB0eXBlOiBcImltYWdlXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgdXJsOiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgICAgIGxpbms6IFwiL3BhZ2VzL21lZXQvbWVldFwiLFxyXG4gICAgICAgICAgICAgICAgICAgIGxpbmtUeXBlOiBcInN3aXRjaFRhYlwiXHJcbiAgICAgICAgICAgICAgICB9XVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBhY3RQaW50dWFuQWN0aXZpdHk6e30sXHJcbiAgICAgICAgICAgIEFjdFBpbnR1YW5NZW1iZXI6e30sXHJcbiAgICAgICAgICAgIEFjdFBpbnR1YW46e30sXHJcbiAgICAgICAgICAgIG1haW5IZWlnaHQ6IDAsXHJcbiAgICAgICAgICAgIGNvdXJzZUluZm86IHt9LFxyXG4gICAgICAgICAgICBtb2RhbE5hbWU6JycsXHJcbiAgICAgICAgICAgIG5vZGVzOiBbXCJuYW1lXCIsIFwiYXR0cnNcIiwgXCJhdHRyc1wiXSxcclxuICAgICAgICAgICAgbnVtOiAxLFxyXG4gICAgICAgICAgICBpc0luOicnLFxyXG4gICAgICAgICAgICBzaG93U2t1OiBmYWxzZSxcclxuICAgICAgICAgICAgYnV5VHlwdDogJ25vcm1hbCcsXHJcbiAgICAgICAgICAgIGNvdXJzZUlueDogLTEsXHJcbiAgICAgICAgICAgIGNvbXBhbmlvbnM6IFtdLFxyXG4gICAgICAgICAgICBzdGF0aXN0aWNzOiB7fSxcclxuICAgICAgICAgICAgQ291cnNlQ29tbWVudDoge30sXHJcbiAgICAgICAgICAgIHNpZ25fc3RhdGVzOiB7XHJcbiAgICAgICAgICAgICAgICAwOiAn54Gr54Ot5oub55Sf5LitJyxcclxuICAgICAgICAgICAgICAgIDE6ICflsJHph4/lkI3pop0nLFxyXG4gICAgICAgICAgICAgICAgMjogJ+W3sua7oeWRmCdcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgdG9QaW50dWFuOiBmYWxzZSxcclxuICAgICAgICAgICAgbnVtTGlzdDogW3tcclxuICAgICAgICAgICAgICAgIG5hbWU6ICflj4Llm6InLFxyXG4gICAgICAgICAgICAgICAgbmFtZTE6ICfmlK/ku5jlrozmiJAnXHJcbiAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgIG5hbWU6ICfojrflvpfmm7TlpJrkvJjmg6AnLFxyXG4gICAgICAgICAgICAgICAgbmFtZTE6ICfliIbkuqvmtLvliqgnXHJcbiAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgIG5hbWU6ICfmi7zlm6LmiJDlip8nLFxyXG4gICAgICAgICAgICAgICAgbmFtZTE6ICfogIHluIjkuLvliqjogZTns7vmgqgnXHJcbiAgICAgICAgICAgIH1dLFxyXG4gICAgICAgICAgICBtZW1iZXI6e31cclxuICAgICAgICB9O1xyXG4gICAgICAgJHJlcGVhdCA9IHt9O1xyXG4kcHJvcHMgPSB7XCJjU3dpcGVyXCI6e1wieG1sbnM6di1iaW5kXCI6XCJcIixcInYtYmluZDptb2RlbC5zeW5jXCI6XCJzd2lwZXJzXCJ9LFwiY3RpdGxlXCI6e1widi1iaW5kOm1vZGVsLnN5bmNcIjpcImNvdXJzZUluZm9cIn0sXCJjSW5mb1wiOntcInYtYmluZDptb2RlbC5zeW5jXCI6XCJjb3Vyc2VJbmZvXCIsXCJ2LWJpbmQ6Y29tcGFuaW9ucy5zeW5jXCI6XCJjb21wYW5pb25zXCJ9LFwiY1JlbWFrZVwiOntcInYtYmluZDptb2RlbC5zeW5jXCI6XCJjb3Vyc2VJbmZvXCIsXCJ2LWJpbmQ6c3RhdGlzdGljcy5zeW5jXCI6XCJzdGF0aXN0aWNzXCIsXCJ2LWJpbmQ6Q291cnNlQ29tbWVudC5zeW5jXCI6XCJDb3Vyc2VDb21tZW50XCJ9fTtcclxuJGV2ZW50cyA9IHt9O1xyXG4gY29tcG9uZW50cyA9IHtcclxuICAgICAgICAgICAgY1N3aXBlcixcclxuICAgICAgICAgICAgY3RpdGxlLFxyXG4gICAgICAgICAgICBjSW5mbyxcclxuICAgICAgICAgICAgY1JlbWFrZSxcclxuICAgICAgICAgICAgY29udGFjdFxyXG4gICAgICAgIH07XHJcbiAgICAgICAgY29uZmlnID0ge1xyXG4gICAgICAgICAgICBuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0OiBcIua0u+WKqOivpuaDhVwiXHJcbiAgICAgICAgfTtcclxuICAgICAgICAvLyDovazlj5HmmoLml7blhYjkuI3lvIDlkK9cclxuICAgICAgICBvblNoYXJlQXBwTWVzc2FnZShyZXMpIHtcclxuICAgICAgICAgICAgaWYgKHJlcy5mcm9tID09PSAnYnV0dG9uJykge1xyXG4gICAgICAgICAgICAgICAgLy8g5p2l6Ieq6aG16Z2i5YaF6L2s5Y+R5oyJ6ZKuXHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhyZXMudGFyZ2V0KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICB0aXRsZTogdGhpcy5jb3Vyc2VJbmZvLmNvdXJzZVRpdHRsZSxcclxuICAgICAgICAgICAgICAgIGltYWdlVXJsOnRoaXMuY291cnNlSW5mby5pbWFnZSxcclxuICAgICAgICAgICAgICAgIHBhdGg6ICcvcGFnZXMvYWN0aXZpdHkvcGludHVhbj9pZD0nICsgdGhpcy5hY3RQaW50dWFuQWN0aXZpdHkuaWQgKyAnJmFnZW50SWQ9JyArIHRoaXMubWVtYmVyLmFnZW50SWRcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBhc3luYyBvbkxvYWQob3B0KSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKG9wdClcclxuICAgICAgICAgICAgLy8g6I635Y+W5Li75YaF5a656auY5bqm77yM55So5LqO5oKs5rWu6K+m5oOF5a+86IiqXHJcbiAgICAgICAgICAgIGxldCB2aWV3ID0gd3guY3JlYXRlU2VsZWN0b3JRdWVyeSgpLnNlbGVjdChcIiNpbmZvLWJveFwiKTtcclxuICAgICAgICAgICAgdmlld1xyXG4gICAgICAgICAgICAgICAgLmZpZWxkcyh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNpemU6IHRydWVcclxuICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGEgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhkYXRhLmhlaWdodCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubWFpbkhlaWdodCA9IGRhdGEuaGVpZ2h0O1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgIC5leGVjKCk7XHJcbiAgICAgICAgICAgIGF3YWl0IGF1dGgubG9naW4oKVxyXG4gICAgICAgICAgICB0aGlzLm1lbWJlciA9IHdlcHkuZ2V0U3RvcmFnZVN5bmMoJ21lbWJlcicpO1xyXG4gICAgICAgICAgICBsZXQgcmVzID0gYXdhaXQgY29uZmlnLnBpbnR1YW5EZXRhaShvcHQuaWQgfHwgb3B0LnNjZW5lKVxyXG4gICAgICAgICAgICBsZXQge1xyXG4gICAgICAgICAgICAgICAgY291cnNlLFxyXG4gICAgICAgICAgICAgICAgY29tcGFuaW9ucyxcclxuICAgICAgICAgICAgICAgIHN0YXRpc3RpY3MsXHJcbiAgICAgICAgICAgICAgICBDb3Vyc2VDb21tZW50LFxyXG4gICAgICAgICAgICAgICAgYWN0UGludHVhbkFjdGl2aXR5LFxyXG4gICAgICAgICAgICAgICAgQWN0UGludHVhbixcclxuICAgICAgICAgICAgICAgIEFjdFBpbnR1YW5NZW1iZXIsXHJcbiAgICAgICAgICAgICAgICBpc0luXHJcbiAgICAgICAgICAgIH0gPSByZXMuZGF0YVxyXG4gICAgICAgICAgICB0aGlzLnN3aXBlcnMubGlzdFswXS51cmwgPSBjb3Vyc2UuaW1hZ2VcclxuICAgICAgICAgICAgY291cnNlLmNvdXJzZUNoYXIgPSBjb3Vyc2UuY291cnNlQ2hhci5zcGxpdChcInxcIilcclxuICAgICAgICAgICAgdGhpcy5jb3Vyc2VJbmZvID0gY291cnNlXHJcbiAgICAgICAgICAgIHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuY291cnNlSW5mbyA9IGNvdXJzZVxyXG4gICAgICAgICAgICB0aGlzLmNvbXBhbmlvbnMgPSBjb21wYW5pb25zXHJcbiAgICAgICAgICAgIHRoaXMuc3RhdGlzdGljcyA9IHN0YXRpc3RpY3NcclxuICAgICAgICAgICAgdGhpcy5Db3Vyc2VDb21tZW50ID0gQ291cnNlQ29tbWVudFxyXG4gICAgICAgICAgICB0aGlzLmFjdFBpbnR1YW5BY3Rpdml0eSA9IGFjdFBpbnR1YW5BY3Rpdml0eVxyXG4gICAgICAgICAgICB0aGlzLkFjdFBpbnR1YW4gPSBBY3RQaW50dWFuXHJcbiAgICAgICAgICAgIHRoaXMuQWN0UGludHVhbk1lbWJlciA9IEFjdFBpbnR1YW5NZW1iZXJcclxuICAgICAgICAgICAgdGhpcy5pc0luID0gaXNJblxyXG4gICAgICAgICAgICB0aGlzLiRhcHBseSgpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBtZXRob2RzID0ge1xyXG4gICAgICAgICAgICBhc3luYyBjcmVhdGVJbWcoZSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKGUuZGV0YWlsLmVyck1zZyA9PSBcImdldFVzZXJJbmZvOm9rXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICBhd2FpdCBhdXRoLmdldFVzZXJpbmZvKGUuZGV0YWlsKVxyXG4gICAgICAgICAgICAgICAgICAgIHN0b3JlLnNhdmUoJ3NoYXJlSW5mbycsIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY291cnNlOiB0aGlzLmNvdXJzZUluZm8sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhdGg6ICdwYWdlcy9hY3Rpdml0eS9waW50dWFuJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IHRoaXMuYWN0UGludHVhbkFjdGl2aXR5LmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTozLFxuICAgICAgICAgICAgICAgICAgICAgICAgY291cnNlSWQ6dGhpcy5jb3Vyc2VJbmZvLmlkXHJcbiAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB1cmw6ICcvcGFnZXMvaG9tZS9zaGFyZSdcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgdG9zaGFyZSgpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kYWxOYW1lID0gJ3NoYXJlJ1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB0b1BpbnR1YW5meSgpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMudG9QaW50dWFuID0gdHJ1ZVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICByZXQoKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgdGFiU2VsZWN0KGUpIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5UYWJDdXIgPSBlLmN1cnJlbnRUYXJnZXQuZGF0YXNldC5pZCB8fCBlLmRldGFpbC5jdXJyZW50O1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBoaWRlTW9kYWwoKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnRvUGludHVhbiA9IGZhbHNlXHJcbiAgICAgICAgICAgICAgICB0aGlzLnNob3dTa3UgPSBmYWxzZVxyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RhbE5hbWUgPSAnJ1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBza3UodHlwZSA9ICdub3JtYWwnKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNob3dTa3UgPSB0cnVlXHJcbiAgICAgICAgICAgICAgICB0aGlzLnRvUGludHVhbiA9IGZhbHNlXHJcbiAgICAgICAgICAgICAgICB0aGlzLmJ1eVR5cHQgPSB0eXBlXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHBsdXMoKSB7XHJcbiAgICAgICAgICAgICAgICB3eC52aWJyYXRlU2hvcnQoKVxyXG4gICAgICAgICAgICAgICAgdGhpcy5udW0gPSB0aGlzLm51bSArIDFcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgbWludXMoKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5udW0gPiAxKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgd3gudmlicmF0ZVNob3J0KClcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm51bSA9IHRoaXMubnVtIC0gMVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBjb3Vyc2UoaW54KSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNvdXJzZUlueCA9IGlueFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBhc3luYyBidXkoYWlkID0gMCwgb3QgPSAxLCApIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmNvdXJzZUlueCA9PSAtMSkge1xyXG4gICAgICAgICAgICAgICAgICAgIFRpcHMudG9hc3QoXCLor7fpgInmi6nkuIDkuKrokKXmnJ9cIiwgcmVzID0+IHt9LCAnbm9uZScpXHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICAgICAgICAgIHVybDogYC4uL2RldGFpbGUvc3VyZU9yZGVyP3R5cGU9JHtvdH0mcGlkPSR7dGhpcy5jb3Vyc2VJbmZvLnBlcmlvZExpc3RbdGhpcy5jb3Vyc2VJbnhdLmlkfSZjaWQ9JHt0aGlzLmNvdXJzZUluZm8uaWR9Jm51bT0ke3RoaXMubnVtfSZhaWQ9JHt0aGlzLmFjdFBpbnR1YW5BY3Rpdml0eS5pZH0mYWN0cGlkPSR7dGhpcy5jb3Vyc2VJbmZvLnBpbnR1YW5JZH1gXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH07XHJcbiAgICB9XHJcbiJdfQ==