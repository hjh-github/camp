"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _swiper = require('./../../components/common/swiper.js');

var _swiper2 = _interopRequireDefault(_swiper);

var _title = require('./../../components/detaile/title.js');

var _title2 = _interopRequireDefault(_title);

var _info = require('./../../components/detaile/info.js');

var _info2 = _interopRequireDefault(_info);

var _remake = require('./../../components/detaile/remake.js');

var _remake2 = _interopRequireDefault(_remake);

var _contact = require('./../../components/common/contact.js');

var _contact2 = _interopRequireDefault(_contact);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

var _WxUtils = require('./../../utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

var _utils = require('./../../store/utils.js');

var _utils2 = _interopRequireDefault(_utils);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
  _inherits(Dialog, _wepy$page);

  function Dialog() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, Dialog);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.data = {
      TabCur: 0,
      close: "/static/images/close.png",
      swipers: {
        type: 1,
        list: [{
          id: 0,
          type: "image",
          url: "",
          link: "/pages/meet/meet",
          linkType: "switchTab"
        }]
      },
      actPintuanActivity: {},
      ActPintuanMember: {},
      ActPintuan: {},
      mainHeight: 0,
      courseInfo: {},
      modalName: '',
      nodes: ["name", "attrs", "attrs"],
      num: 1,
      isIn: '',
      showSku: false,
      buyTypt: 'normal',
      courseInx: -1,
      companions: [],
      statistics: {},
      CourseComment: {},
      sign_states: {
        0: '火热招生中',
        1: '少量名额',
        2: '已满员'
      },
      toPintuan: false,
      numList: [{
        name: '参团',
        name1: '支付完成'
      }, {
        name: '获得更多优惠',
        name1: '分享活动'
      }, {
        name: '拼团成功',
        name1: '老师主动联系您'
      }],
      member: {}
    }, _this.$repeat = {}, _this.$props = { "cSwiper": { "xmlns:v-bind": "", "v-bind:model.sync": "swipers" }, "ctitle": { "v-bind:model.sync": "courseInfo" }, "cInfo": { "v-bind:model.sync": "courseInfo", "v-bind:companions.sync": "companions" }, "cRemake": { "v-bind:model.sync": "courseInfo", "v-bind:statistics.sync": "statistics", "v-bind:CourseComment.sync": "CourseComment" } }, _this.$events = {}, _this.components = {
      cSwiper: _swiper2.default,
      ctitle: _title2.default,
      cInfo: _info2.default,
      cRemake: _remake2.default,
      contact: _contact2.default
    }, _this.config = {
      navigationBarTitleText: "活动详情"
    }, _this.methods = {
      createImg: function () {
        var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(e) {
          return regeneratorRuntime.wrap(function _callee$(_context) {
            while (1) {
              switch (_context.prev = _context.next) {
                case 0:
                  if (!(e.detail.errMsg == "getUserInfo:ok")) {
                    _context.next = 5;
                    break;
                  }

                  _context.next = 3;
                  return _auth2.default.getUserinfo(e.detail);

                case 3:
                  _utils2.default.save('shareInfo', {
                    course: this.courseInfo,
                    path: 'pages/activity/pintuan',
                    id: this.actPintuanActivity.id,
                    type: 3,
                    courseId: this.courseInfo.id
                  });
                  _wepy2.default.navigateTo({
                    url: '/pages/home/share'
                  });

                case 5:
                case "end":
                  return _context.stop();
              }
            }
          }, _callee, this);
        }));

        function createImg(_x) {
          return _ref2.apply(this, arguments);
        }

        return createImg;
      }(),
      toshare: function toshare() {
        this.modalName = 'share';
      },
      toPintuanfy: function toPintuanfy() {
        this.toPintuan = true;
      },
      ret: function ret() {
        return false;
      },
      tabSelect: function tabSelect(e) {
        console.log(e);
        this.TabCur = e.currentTarget.dataset.id || e.detail.current;
      },
      hideModal: function hideModal() {
        this.toPintuan = false;
        this.showSku = false;
        this.modalName = '';
      },
      sku: function sku() {
        var type = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'normal';

        this.showSku = true;
        this.toPintuan = false;
        this.buyTypt = type;
      },
      plus: function plus() {
        wx.vibrateShort();
        this.num = this.num + 1;
      },
      minus: function minus() {
        if (this.num > 1) {
          wx.vibrateShort();
          this.num = this.num - 1;
        }
      },
      course: function course(inx) {
        this.courseInx = inx;
      },
      buy: function () {
        var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
          var aid = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;
          var ot = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1;
          return regeneratorRuntime.wrap(function _callee2$(_context2) {
            while (1) {
              switch (_context2.prev = _context2.next) {
                case 0:
                  if (!(this.courseInx == -1)) {
                    _context2.next = 3;
                    break;
                  }

                  _Tips2.default.toast("请选择一个营期", function (res) {}, 'none');
                  return _context2.abrupt("return", false);

                case 3:
                  _wepy2.default.navigateTo({
                    url: "../detaile/sureOrder?type=" + ot + "&pid=" + this.courseInfo.periodList[this.courseInx].id + "&cid=" + this.courseInfo.id + "&num=" + this.num + "&aid=" + this.actPintuanActivity.id + "&actpid=" + this.courseInfo.pintuanId
                  });

                case 4:
                case "end":
                  return _context2.stop();
              }
            }
          }, _callee2, this);
        }));

        function buy() {
          return _ref3.apply(this, arguments);
        }

        return buy;
      }()
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(Dialog, [{
    key: "onShareAppMessage",

    // 转发暂时先不开启
    value: function onShareAppMessage(res) {
      if (res.from === 'button') {
        // 来自页面内转发按钮
        console.log(res.target);
      }
      return {
        title: this.courseInfo.courseTittle,
        imageUrl: this.courseInfo.image,
        path: '/pages/activity/pintuan?id=' + this.actPintuanActivity.id + '&agentId=' + this.member.agentId
      };
    }
  }, {
    key: "onLoad",
    value: function () {
      var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(opt) {
        var _this2 = this;

        var view, res, _res$data, course, companions, statistics, CourseComment, actPintuanActivity, ActPintuan, ActPintuanMember, isIn;

        return regeneratorRuntime.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                console.log(opt);
                // 获取主内容高度，用于悬浮详情导航
                view = wx.createSelectorQuery().select("#info-box");

                view.fields({
                  size: true
                }, function (data) {
                  console.log(data.height);
                  _this2.mainHeight = data.height;
                }).exec();
                _context3.next = 5;
                return _auth2.default.login();

              case 5:
                this.member = _wepy2.default.getStorageSync('member');
                _context3.next = 8;
                return _config2.default.pintuanDetai(opt.id || _wepy2.default.$instance.globalData.query.id);

              case 8:
                res = _context3.sent;
                _res$data = res.data, course = _res$data.course, companions = _res$data.companions, statistics = _res$data.statistics, CourseComment = _res$data.CourseComment, actPintuanActivity = _res$data.actPintuanActivity, ActPintuan = _res$data.ActPintuan, ActPintuanMember = _res$data.ActPintuanMember, isIn = _res$data.isIn;

                this.swipers.list[0].url = course.image;
                course.courseChar = course.courseChar.split("|");
                this.courseInfo = course;
                _wepy2.default.$instance.globalData.courseInfo = course;
                this.companions = companions;
                this.statistics = statistics;
                this.CourseComment = CourseComment;
                this.actPintuanActivity = actPintuanActivity;
                this.ActPintuan = ActPintuan;
                this.ActPintuanMember = ActPintuanMember;
                this.isIn = isIn;
                this.$apply();

              case 22:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this);
      }));

      function onLoad(_x5) {
        return _ref4.apply(this, arguments);
      }

      return onLoad;
    }()
  }]);

  return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/activity/pintuan'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBpbnR1YW4uanMiXSwibmFtZXMiOlsiRGlhbG9nIiwiZGF0YSIsIlRhYkN1ciIsImNsb3NlIiwic3dpcGVycyIsInR5cGUiLCJsaXN0IiwiaWQiLCJ1cmwiLCJsaW5rIiwibGlua1R5cGUiLCJhY3RQaW50dWFuQWN0aXZpdHkiLCJBY3RQaW50dWFuTWVtYmVyIiwiQWN0UGludHVhbiIsIm1haW5IZWlnaHQiLCJjb3Vyc2VJbmZvIiwibW9kYWxOYW1lIiwibm9kZXMiLCJudW0iLCJpc0luIiwic2hvd1NrdSIsImJ1eVR5cHQiLCJjb3Vyc2VJbngiLCJjb21wYW5pb25zIiwic3RhdGlzdGljcyIsIkNvdXJzZUNvbW1lbnQiLCJzaWduX3N0YXRlcyIsInRvUGludHVhbiIsIm51bUxpc3QiLCJuYW1lIiwibmFtZTEiLCJtZW1iZXIiLCIkcmVwZWF0IiwiJHByb3BzIiwiJGV2ZW50cyIsImNvbXBvbmVudHMiLCJjU3dpcGVyIiwiY3RpdGxlIiwiY0luZm8iLCJjUmVtYWtlIiwiY29udGFjdCIsImNvbmZpZyIsIm5hdmlnYXRpb25CYXJUaXRsZVRleHQiLCJtZXRob2RzIiwiY3JlYXRlSW1nIiwiZSIsImRldGFpbCIsImVyck1zZyIsImF1dGgiLCJnZXRVc2VyaW5mbyIsInN0b3JlIiwic2F2ZSIsImNvdXJzZSIsInBhdGgiLCJjb3Vyc2VJZCIsIndlcHkiLCJuYXZpZ2F0ZVRvIiwidG9zaGFyZSIsInRvUGludHVhbmZ5IiwicmV0IiwidGFiU2VsZWN0IiwiY29uc29sZSIsImxvZyIsImN1cnJlbnRUYXJnZXQiLCJkYXRhc2V0IiwiY3VycmVudCIsImhpZGVNb2RhbCIsInNrdSIsInBsdXMiLCJ3eCIsInZpYnJhdGVTaG9ydCIsIm1pbnVzIiwiaW54IiwiYnV5IiwiYWlkIiwib3QiLCJUaXBzIiwidG9hc3QiLCJwZXJpb2RMaXN0IiwicGludHVhbklkIiwicmVzIiwiZnJvbSIsInRhcmdldCIsInRpdGxlIiwiY291cnNlVGl0dGxlIiwiaW1hZ2VVcmwiLCJpbWFnZSIsImFnZW50SWQiLCJvcHQiLCJ2aWV3IiwiY3JlYXRlU2VsZWN0b3JRdWVyeSIsInNlbGVjdCIsImZpZWxkcyIsInNpemUiLCJoZWlnaHQiLCJleGVjIiwibG9naW4iLCJnZXRTdG9yYWdlU3luYyIsInBpbnR1YW5EZXRhaSIsIiRpbnN0YW5jZSIsImdsb2JhbERhdGEiLCJxdWVyeSIsImNvdXJzZUNoYXIiLCJzcGxpdCIsIiRhcHBseSIsInBhZ2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUNFOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7Ozs7Ozs7Ozs7O0lBQ3FCQSxNOzs7Ozs7Ozs7Ozs7OztzTEFDbkJDLEksR0FBTztBQUNMQyxjQUFRLENBREg7QUFFTEMsYUFBTywwQkFGRjtBQUdMQyxlQUFTO0FBQ1BDLGNBQU0sQ0FEQztBQUVQQyxjQUFNLENBQUM7QUFDTEMsY0FBSSxDQURDO0FBRUxGLGdCQUFNLE9BRkQ7QUFHTEcsZUFBSyxFQUhBO0FBSUxDLGdCQUFNLGtCQUpEO0FBS0xDLG9CQUFVO0FBTEwsU0FBRDtBQUZDLE9BSEo7QUFhTEMsMEJBQW9CLEVBYmY7QUFjTEMsd0JBQWtCLEVBZGI7QUFlTEMsa0JBQVksRUFmUDtBQWdCTEMsa0JBQVksQ0FoQlA7QUFpQkxDLGtCQUFZLEVBakJQO0FBa0JMQyxpQkFBVyxFQWxCTjtBQW1CTEMsYUFBTyxDQUFDLE1BQUQsRUFBUyxPQUFULEVBQWtCLE9BQWxCLENBbkJGO0FBb0JMQyxXQUFLLENBcEJBO0FBcUJMQyxZQUFNLEVBckJEO0FBc0JMQyxlQUFTLEtBdEJKO0FBdUJMQyxlQUFTLFFBdkJKO0FBd0JMQyxpQkFBVyxDQUFDLENBeEJQO0FBeUJMQyxrQkFBWSxFQXpCUDtBQTBCTEMsa0JBQVksRUExQlA7QUEyQkxDLHFCQUFlLEVBM0JWO0FBNEJMQyxtQkFBYTtBQUNYLFdBQUcsT0FEUTtBQUVYLFdBQUcsTUFGUTtBQUdYLFdBQUc7QUFIUSxPQTVCUjtBQWlDTEMsaUJBQVcsS0FqQ047QUFrQ0xDLGVBQVMsQ0FBQztBQUNSQyxjQUFNLElBREU7QUFFUkMsZUFBTztBQUZDLE9BQUQsRUFHTjtBQUNERCxjQUFNLFFBREw7QUFFREMsZUFBTztBQUZOLE9BSE0sRUFNTjtBQUNERCxjQUFNLE1BREw7QUFFREMsZUFBTztBQUZOLE9BTk0sQ0FsQ0o7QUE0Q0xDLGNBQVE7QUE1Q0gsSyxRQThDUkMsTyxHQUFVLEUsUUFDYkMsTSxHQUFTLEVBQUMsV0FBVSxFQUFDLGdCQUFlLEVBQWhCLEVBQW1CLHFCQUFvQixTQUF2QyxFQUFYLEVBQTZELFVBQVMsRUFBQyxxQkFBb0IsWUFBckIsRUFBdEUsRUFBeUcsU0FBUSxFQUFDLHFCQUFvQixZQUFyQixFQUFrQywwQkFBeUIsWUFBM0QsRUFBakgsRUFBMEwsV0FBVSxFQUFDLHFCQUFvQixZQUFyQixFQUFrQywwQkFBeUIsWUFBM0QsRUFBd0UsNkJBQTRCLGVBQXBHLEVBQXBNLEUsUUFDVEMsTyxHQUFVLEUsUUFDVEMsVSxHQUFhO0FBQ1JDLCtCQURRO0FBRVJDLDZCQUZRO0FBR1JDLDJCQUhRO0FBSVJDLCtCQUpRO0FBS1JDO0FBTFEsSyxRQU9WQyxNLEdBQVM7QUFDUEMsOEJBQXdCO0FBRGpCLEssUUF1RFRDLE8sR0FBVTtBQUNGQyxlQURFO0FBQUEsNkZBQ1FDLENBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQUVGQSxFQUFFQyxNQUFGLENBQVNDLE1BQVQsSUFBbUIsZ0JBRmpCO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUEseUJBR0VDLGVBQUtDLFdBQUwsQ0FBaUJKLEVBQUVDLE1BQW5CLENBSEY7O0FBQUE7QUFJSkksa0NBQU1DLElBQU4sQ0FBVyxXQUFYLEVBQXdCO0FBQ3RCQyw0QkFBUSxLQUFLckMsVUFEUztBQUV0QnNDLDBCQUFNLHdCQUZnQjtBQUd0QjlDLHdCQUFJLEtBQUtJLGtCQUFMLENBQXdCSixFQUhOO0FBSXRCRiwwQkFBTSxDQUpnQjtBQUt0QmlELDhCQUFVLEtBQUt2QyxVQUFMLENBQWdCUjtBQUxKLG1CQUF4QjtBQU9BZ0QsaUNBQUtDLFVBQUwsQ0FBZ0I7QUFDZGhELHlCQUFLO0FBRFMsbUJBQWhCOztBQVhJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBZ0JSaUQsYUFoQlEscUJBZ0JFO0FBQ1IsYUFBS3pDLFNBQUwsR0FBaUIsT0FBakI7QUFDRCxPQWxCTztBQW1CUjBDLGlCQW5CUSx5QkFtQk07QUFDWixhQUFLL0IsU0FBTCxHQUFpQixJQUFqQjtBQUNELE9BckJPO0FBc0JSZ0MsU0F0QlEsaUJBc0JGO0FBQ0osZUFBTyxLQUFQO0FBQ0QsT0F4Qk87QUF5QlJDLGVBekJRLHFCQXlCRWYsQ0F6QkYsRUF5Qks7QUFDWGdCLGdCQUFRQyxHQUFSLENBQVlqQixDQUFaO0FBQ0EsYUFBSzNDLE1BQUwsR0FBYzJDLEVBQUVrQixhQUFGLENBQWdCQyxPQUFoQixDQUF3QnpELEVBQXhCLElBQThCc0MsRUFBRUMsTUFBRixDQUFTbUIsT0FBckQ7QUFDRCxPQTVCTztBQTZCUkMsZUE3QlEsdUJBNkJJO0FBQ1YsYUFBS3ZDLFNBQUwsR0FBaUIsS0FBakI7QUFDQSxhQUFLUCxPQUFMLEdBQWUsS0FBZjtBQUNBLGFBQUtKLFNBQUwsR0FBaUIsRUFBakI7QUFDRCxPQWpDTztBQWtDUm1ELFNBbENRLGlCQWtDYTtBQUFBLFlBQWpCOUQsSUFBaUIsdUVBQVYsUUFBVTs7QUFDbkIsYUFBS2UsT0FBTCxHQUFlLElBQWY7QUFDQSxhQUFLTyxTQUFMLEdBQWlCLEtBQWpCO0FBQ0EsYUFBS04sT0FBTCxHQUFlaEIsSUFBZjtBQUNELE9BdENPO0FBdUNSK0QsVUF2Q1Esa0JBdUNEO0FBQ0xDLFdBQUdDLFlBQUg7QUFDQSxhQUFLcEQsR0FBTCxHQUFXLEtBQUtBLEdBQUwsR0FBVyxDQUF0QjtBQUNELE9BMUNPO0FBMkNScUQsV0EzQ1EsbUJBMkNBO0FBQ04sWUFBSSxLQUFLckQsR0FBTCxHQUFXLENBQWYsRUFBa0I7QUFDaEJtRCxhQUFHQyxZQUFIO0FBQ0EsZUFBS3BELEdBQUwsR0FBVyxLQUFLQSxHQUFMLEdBQVcsQ0FBdEI7QUFDRDtBQUNGLE9BaERPO0FBaURSa0MsWUFqRFEsa0JBaUREb0IsR0FqREMsRUFpREk7QUFDVixhQUFLbEQsU0FBTCxHQUFpQmtELEdBQWpCO0FBQ0QsT0FuRE87QUFvREZDLFNBcERFO0FBQUE7QUFBQSxjQW9ERUMsR0FwREYsdUVBb0RRLENBcERSO0FBQUEsY0FvRFdDLEVBcERYLHVFQW9EZ0IsQ0FwRGhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFxREYsS0FBS3JELFNBQUwsSUFBa0IsQ0FBQyxDQXJEakI7QUFBQTtBQUFBO0FBQUE7O0FBc0RKc0QsaUNBQUtDLEtBQUwsQ0FBVyxTQUFYLEVBQXNCLGVBQU8sQ0FBRSxDQUEvQixFQUFpQyxNQUFqQztBQXRESSxvREF1REcsS0F2REg7O0FBQUE7QUF5RE50QixpQ0FBS0MsVUFBTCxDQUFnQjtBQUNkaEQsd0RBQWtDbUUsRUFBbEMsYUFBNEMsS0FBSzVELFVBQUwsQ0FBZ0IrRCxVQUFoQixDQUEyQixLQUFLeEQsU0FBaEMsRUFBMkNmLEVBQXZGLGFBQWlHLEtBQUtRLFVBQUwsQ0FBZ0JSLEVBQWpILGFBQTJILEtBQUtXLEdBQWhJLGFBQTJJLEtBQUtQLGtCQUFMLENBQXdCSixFQUFuSyxnQkFBZ0wsS0FBS1EsVUFBTCxDQUFnQmdFO0FBRGxMLG1CQUFoQjs7QUF6RE07QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQSxLOzs7Ozs7QUFwRFY7c0NBQ2tCQyxHLEVBQUs7QUFDckIsVUFBSUEsSUFBSUMsSUFBSixLQUFhLFFBQWpCLEVBQTJCO0FBQ3pCO0FBQ0FwQixnQkFBUUMsR0FBUixDQUFZa0IsSUFBSUUsTUFBaEI7QUFDRDtBQUNELGFBQU87QUFDTEMsZUFBTyxLQUFLcEUsVUFBTCxDQUFnQnFFLFlBRGxCO0FBRUxDLGtCQUFVLEtBQUt0RSxVQUFMLENBQWdCdUUsS0FGckI7QUFHTGpDLGNBQU0sZ0NBQWdDLEtBQUsxQyxrQkFBTCxDQUF3QkosRUFBeEQsR0FBNkQsV0FBN0QsR0FBMkUsS0FBS3dCLE1BQUwsQ0FBWXdEO0FBSHhGLE9BQVA7QUFLRDs7Ozs0RkFDWUMsRzs7Ozs7Ozs7O0FBQ1gzQix3QkFBUUMsR0FBUixDQUFZMEIsR0FBWjtBQUNBO0FBQ0lDLG9CLEdBQU9wQixHQUFHcUIsbUJBQUgsR0FBeUJDLE1BQXpCLENBQWdDLFdBQWhDLEM7O0FBQ1hGLHFCQUNHRyxNQURILENBQ1U7QUFDSkMsd0JBQU07QUFERixpQkFEVixFQUlJLGdCQUFRO0FBQ05oQywwQkFBUUMsR0FBUixDQUFZN0QsS0FBSzZGLE1BQWpCO0FBQ0EseUJBQUtoRixVQUFMLEdBQWtCYixLQUFLNkYsTUFBdkI7QUFDRCxpQkFQTCxFQVNHQyxJQVRIOzt1QkFVTS9DLGVBQUtnRCxLQUFMLEU7OztBQUNOLHFCQUFLakUsTUFBTCxHQUFjd0IsZUFBSzBDLGNBQUwsQ0FBb0IsUUFBcEIsQ0FBZDs7dUJBQ2dCeEQsaUJBQU95RCxZQUFQLENBQW9CVixJQUFJakYsRUFBSixJQUFVZ0QsZUFBSzRDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQkMsS0FBMUIsQ0FBZ0M5RixFQUE5RCxDOzs7QUFBWnlFLG1COzRCQVVBQSxJQUFJL0UsSSxFQVJObUQsTSxhQUFBQSxNLEVBQ0E3QixVLGFBQUFBLFUsRUFDQUMsVSxhQUFBQSxVLEVBQ0FDLGEsYUFBQUEsYSxFQUNBZCxrQixhQUFBQSxrQixFQUNBRSxVLGFBQUFBLFUsRUFDQUQsZ0IsYUFBQUEsZ0IsRUFDQU8sSSxhQUFBQSxJOztBQUVGLHFCQUFLZixPQUFMLENBQWFFLElBQWIsQ0FBa0IsQ0FBbEIsRUFBcUJFLEdBQXJCLEdBQTJCNEMsT0FBT2tDLEtBQWxDO0FBQ0FsQyx1QkFBT2tELFVBQVAsR0FBb0JsRCxPQUFPa0QsVUFBUCxDQUFrQkMsS0FBbEIsQ0FBd0IsR0FBeEIsQ0FBcEI7QUFDQSxxQkFBS3hGLFVBQUwsR0FBa0JxQyxNQUFsQjtBQUNBRywrQkFBSzRDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQnJGLFVBQTFCLEdBQXVDcUMsTUFBdkM7QUFDQSxxQkFBSzdCLFVBQUwsR0FBa0JBLFVBQWxCO0FBQ0EscUJBQUtDLFVBQUwsR0FBa0JBLFVBQWxCO0FBQ0EscUJBQUtDLGFBQUwsR0FBcUJBLGFBQXJCO0FBQ0EscUJBQUtkLGtCQUFMLEdBQTBCQSxrQkFBMUI7QUFDQSxxQkFBS0UsVUFBTCxHQUFrQkEsVUFBbEI7QUFDQSxxQkFBS0QsZ0JBQUwsR0FBd0JBLGdCQUF4QjtBQUNBLHFCQUFLTyxJQUFMLEdBQVlBLElBQVo7QUFDQSxxQkFBS3FGLE1BQUw7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUE5R2dDakQsZUFBS2tELEk7O2tCQUFwQnpHLE0iLCJmaWxlIjoicGludHVhbi5qcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4gIGltcG9ydCB3ZXB5IGZyb20gXCJ3ZXB5XCI7XHJcbiAgaW1wb3J0IGNTd2lwZXIgZnJvbSBcIkAvY29tcG9uZW50cy9jb21tb24vc3dpcGVyXCI7XHJcbiAgaW1wb3J0IGN0aXRsZSBmcm9tIFwiQC9jb21wb25lbnRzL2RldGFpbGUvdGl0bGVcIjtcclxuICBpbXBvcnQgY0luZm8gZnJvbSBcIkAvY29tcG9uZW50cy9kZXRhaWxlL2luZm9cIjtcclxuICBpbXBvcnQgY1JlbWFrZSBmcm9tIFwiQC9jb21wb25lbnRzL2RldGFpbGUvcmVtYWtlXCI7XHJcbiAgaW1wb3J0IGNvbnRhY3QgZnJvbSBcIkAvY29tcG9uZW50cy9jb21tb24vY29udGFjdFwiXHJcbiAgaW1wb3J0IGNvbmZpZyBmcm9tIFwiQC9hcGkvY29uZmlnXCI7XHJcbiAgaW1wb3J0IGF1dGggZnJvbSBcIkAvYXBpL2F1dGhcIjtcclxuICBpbXBvcnQgV3hVdGlscyBmcm9tIFwiQC91dGlscy9XeFV0aWxzXCI7XHJcbiAgaW1wb3J0IFRpcHMgZnJvbSBcIkAvdXRpbHMvVGlwc1wiO1xyXG4gIGltcG9ydCBzdG9yZSBmcm9tIFwiQC9zdG9yZS91dGlsc1wiXHJcbiAgZXhwb3J0IGRlZmF1bHQgY2xhc3MgRGlhbG9nIGV4dGVuZHMgd2VweS5wYWdlIHtcclxuICAgIGRhdGEgPSB7XHJcbiAgICAgIFRhYkN1cjogMCxcclxuICAgICAgY2xvc2U6IFwiL3N0YXRpYy9pbWFnZXMvY2xvc2UucG5nXCIsXHJcbiAgICAgIHN3aXBlcnM6IHtcclxuICAgICAgICB0eXBlOiAxLFxyXG4gICAgICAgIGxpc3Q6IFt7XHJcbiAgICAgICAgICBpZDogMCxcclxuICAgICAgICAgIHR5cGU6IFwiaW1hZ2VcIixcclxuICAgICAgICAgIHVybDogXCJcIixcclxuICAgICAgICAgIGxpbms6IFwiL3BhZ2VzL21lZXQvbWVldFwiLFxyXG4gICAgICAgICAgbGlua1R5cGU6IFwic3dpdGNoVGFiXCJcclxuICAgICAgICB9XVxyXG4gICAgICB9LFxyXG4gICAgICBhY3RQaW50dWFuQWN0aXZpdHk6IHt9LFxyXG4gICAgICBBY3RQaW50dWFuTWVtYmVyOiB7fSxcclxuICAgICAgQWN0UGludHVhbjoge30sXHJcbiAgICAgIG1haW5IZWlnaHQ6IDAsXHJcbiAgICAgIGNvdXJzZUluZm86IHt9LFxyXG4gICAgICBtb2RhbE5hbWU6ICcnLFxyXG4gICAgICBub2RlczogW1wibmFtZVwiLCBcImF0dHJzXCIsIFwiYXR0cnNcIl0sXHJcbiAgICAgIG51bTogMSxcclxuICAgICAgaXNJbjogJycsXHJcbiAgICAgIHNob3dTa3U6IGZhbHNlLFxyXG4gICAgICBidXlUeXB0OiAnbm9ybWFsJyxcclxuICAgICAgY291cnNlSW54OiAtMSxcclxuICAgICAgY29tcGFuaW9uczogW10sXHJcbiAgICAgIHN0YXRpc3RpY3M6IHt9LFxyXG4gICAgICBDb3Vyc2VDb21tZW50OiB7fSxcclxuICAgICAgc2lnbl9zdGF0ZXM6IHtcclxuICAgICAgICAwOiAn54Gr54Ot5oub55Sf5LitJyxcclxuICAgICAgICAxOiAn5bCR6YeP5ZCN6aKdJyxcclxuICAgICAgICAyOiAn5bey5ruh5ZGYJ1xyXG4gICAgICB9LFxyXG4gICAgICB0b1BpbnR1YW46IGZhbHNlLFxyXG4gICAgICBudW1MaXN0OiBbe1xyXG4gICAgICAgIG5hbWU6ICflj4Llm6InLFxyXG4gICAgICAgIG5hbWUxOiAn5pSv5LuY5a6M5oiQJ1xyXG4gICAgICB9LCB7XHJcbiAgICAgICAgbmFtZTogJ+iOt+W+l+abtOWkmuS8mOaDoCcsXHJcbiAgICAgICAgbmFtZTE6ICfliIbkuqvmtLvliqgnXHJcbiAgICAgIH0sIHtcclxuICAgICAgICBuYW1lOiAn5ou85Zui5oiQ5YqfJyxcclxuICAgICAgICBuYW1lMTogJ+iAgeW4iOS4u+WKqOiBlOezu+aCqCdcclxuICAgICAgfV0sXHJcbiAgICAgIG1lbWJlcjoge31cclxuICAgIH07XHJcbiAgICRyZXBlYXQgPSB7fTtcclxuJHByb3BzID0ge1wiY1N3aXBlclwiOntcInhtbG5zOnYtYmluZFwiOlwiXCIsXCJ2LWJpbmQ6bW9kZWwuc3luY1wiOlwic3dpcGVyc1wifSxcImN0aXRsZVwiOntcInYtYmluZDptb2RlbC5zeW5jXCI6XCJjb3Vyc2VJbmZvXCJ9LFwiY0luZm9cIjp7XCJ2LWJpbmQ6bW9kZWwuc3luY1wiOlwiY291cnNlSW5mb1wiLFwidi1iaW5kOmNvbXBhbmlvbnMuc3luY1wiOlwiY29tcGFuaW9uc1wifSxcImNSZW1ha2VcIjp7XCJ2LWJpbmQ6bW9kZWwuc3luY1wiOlwiY291cnNlSW5mb1wiLFwidi1iaW5kOnN0YXRpc3RpY3Muc3luY1wiOlwic3RhdGlzdGljc1wiLFwidi1iaW5kOkNvdXJzZUNvbW1lbnQuc3luY1wiOlwiQ291cnNlQ29tbWVudFwifX07XHJcbiRldmVudHMgPSB7fTtcclxuIGNvbXBvbmVudHMgPSB7XHJcbiAgICAgIGNTd2lwZXIsXHJcbiAgICAgIGN0aXRsZSxcclxuICAgICAgY0luZm8sXHJcbiAgICAgIGNSZW1ha2UsXHJcbiAgICAgIGNvbnRhY3RcclxuICAgIH07XHJcbiAgICBjb25maWcgPSB7XHJcbiAgICAgIG5hdmlnYXRpb25CYXJUaXRsZVRleHQ6IFwi5rS75Yqo6K+m5oOFXCJcclxuICAgIH07XHJcbiAgICAvLyDovazlj5HmmoLml7blhYjkuI3lvIDlkK9cclxuICAgIG9uU2hhcmVBcHBNZXNzYWdlKHJlcykge1xyXG4gICAgICBpZiAocmVzLmZyb20gPT09ICdidXR0b24nKSB7XHJcbiAgICAgICAgLy8g5p2l6Ieq6aG16Z2i5YaF6L2s5Y+R5oyJ6ZKuXHJcbiAgICAgICAgY29uc29sZS5sb2cocmVzLnRhcmdldClcclxuICAgICAgfVxyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIHRpdGxlOiB0aGlzLmNvdXJzZUluZm8uY291cnNlVGl0dGxlLFxyXG4gICAgICAgIGltYWdlVXJsOiB0aGlzLmNvdXJzZUluZm8uaW1hZ2UsXHJcbiAgICAgICAgcGF0aDogJy9wYWdlcy9hY3Rpdml0eS9waW50dWFuP2lkPScgKyB0aGlzLmFjdFBpbnR1YW5BY3Rpdml0eS5pZCArICcmYWdlbnRJZD0nICsgdGhpcy5tZW1iZXIuYWdlbnRJZFxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBhc3luYyBvbkxvYWQob3B0KSB7XHJcbiAgICAgIGNvbnNvbGUubG9nKG9wdClcclxuICAgICAgLy8g6I635Y+W5Li75YaF5a656auY5bqm77yM55So5LqO5oKs5rWu6K+m5oOF5a+86IiqXHJcbiAgICAgIGxldCB2aWV3ID0gd3guY3JlYXRlU2VsZWN0b3JRdWVyeSgpLnNlbGVjdChcIiNpbmZvLWJveFwiKTtcclxuICAgICAgdmlld1xyXG4gICAgICAgIC5maWVsZHMoe1xyXG4gICAgICAgICAgICBzaXplOiB0cnVlXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgZGF0YSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGRhdGEuaGVpZ2h0KTtcclxuICAgICAgICAgICAgdGhpcy5tYWluSGVpZ2h0ID0gZGF0YS5oZWlnaHQ7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgKVxyXG4gICAgICAgIC5leGVjKCk7XHJcbiAgICAgIGF3YWl0IGF1dGgubG9naW4oKVxyXG4gICAgICB0aGlzLm1lbWJlciA9IHdlcHkuZ2V0U3RvcmFnZVN5bmMoJ21lbWJlcicpO1xyXG4gICAgICBsZXQgcmVzID0gYXdhaXQgY29uZmlnLnBpbnR1YW5EZXRhaShvcHQuaWQgfHwgd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5xdWVyeS5pZClcclxuICAgICAgbGV0IHtcclxuICAgICAgICBjb3Vyc2UsXHJcbiAgICAgICAgY29tcGFuaW9ucyxcclxuICAgICAgICBzdGF0aXN0aWNzLFxyXG4gICAgICAgIENvdXJzZUNvbW1lbnQsXHJcbiAgICAgICAgYWN0UGludHVhbkFjdGl2aXR5LFxyXG4gICAgICAgIEFjdFBpbnR1YW4sXHJcbiAgICAgICAgQWN0UGludHVhbk1lbWJlcixcclxuICAgICAgICBpc0luXHJcbiAgICAgIH0gPSByZXMuZGF0YVxyXG4gICAgICB0aGlzLnN3aXBlcnMubGlzdFswXS51cmwgPSBjb3Vyc2UuaW1hZ2VcclxuICAgICAgY291cnNlLmNvdXJzZUNoYXIgPSBjb3Vyc2UuY291cnNlQ2hhci5zcGxpdChcInxcIilcclxuICAgICAgdGhpcy5jb3Vyc2VJbmZvID0gY291cnNlXHJcbiAgICAgIHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuY291cnNlSW5mbyA9IGNvdXJzZVxyXG4gICAgICB0aGlzLmNvbXBhbmlvbnMgPSBjb21wYW5pb25zXHJcbiAgICAgIHRoaXMuc3RhdGlzdGljcyA9IHN0YXRpc3RpY3NcclxuICAgICAgdGhpcy5Db3Vyc2VDb21tZW50ID0gQ291cnNlQ29tbWVudFxyXG4gICAgICB0aGlzLmFjdFBpbnR1YW5BY3Rpdml0eSA9IGFjdFBpbnR1YW5BY3Rpdml0eVxyXG4gICAgICB0aGlzLkFjdFBpbnR1YW4gPSBBY3RQaW50dWFuXHJcbiAgICAgIHRoaXMuQWN0UGludHVhbk1lbWJlciA9IEFjdFBpbnR1YW5NZW1iZXJcclxuICAgICAgdGhpcy5pc0luID0gaXNJblxyXG4gICAgICB0aGlzLiRhcHBseSgpO1xyXG4gICAgfVxyXG4gICAgbWV0aG9kcyA9IHtcclxuICAgICAgYXN5bmMgY3JlYXRlSW1nKGUpIHtcclxuICAgICAgICBpZiAoZS5kZXRhaWwuZXJyTXNnID09IFwiZ2V0VXNlckluZm86b2tcIikge1xyXG4gICAgICAgICAgYXdhaXQgYXV0aC5nZXRVc2VyaW5mbyhlLmRldGFpbClcclxuICAgICAgICAgIHN0b3JlLnNhdmUoJ3NoYXJlSW5mbycsIHtcclxuICAgICAgICAgICAgY291cnNlOiB0aGlzLmNvdXJzZUluZm8sXHJcbiAgICAgICAgICAgIHBhdGg6ICdwYWdlcy9hY3Rpdml0eS9waW50dWFuJyxcclxuICAgICAgICAgICAgaWQ6IHRoaXMuYWN0UGludHVhbkFjdGl2aXR5LmlkLFxyXG4gICAgICAgICAgICB0eXBlOiAzLFxyXG4gICAgICAgICAgICBjb3Vyc2VJZDogdGhpcy5jb3Vyc2VJbmZvLmlkXHJcbiAgICAgICAgICB9KVxyXG4gICAgICAgICAgd2VweS5uYXZpZ2F0ZVRvKHtcclxuICAgICAgICAgICAgdXJsOiAnL3BhZ2VzL2hvbWUvc2hhcmUnXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgIH0sXHJcbiAgICAgIHRvc2hhcmUoKSB7XHJcbiAgICAgICAgdGhpcy5tb2RhbE5hbWUgPSAnc2hhcmUnXHJcbiAgICAgIH0sXHJcbiAgICAgIHRvUGludHVhbmZ5KCkge1xyXG4gICAgICAgIHRoaXMudG9QaW50dWFuID0gdHJ1ZVxyXG4gICAgICB9LFxyXG4gICAgICByZXQoKSB7XHJcbiAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgIH0sXHJcbiAgICAgIHRhYlNlbGVjdChlKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coZSk7XHJcbiAgICAgICAgdGhpcy5UYWJDdXIgPSBlLmN1cnJlbnRUYXJnZXQuZGF0YXNldC5pZCB8fCBlLmRldGFpbC5jdXJyZW50O1xyXG4gICAgICB9LFxyXG4gICAgICBoaWRlTW9kYWwoKSB7XHJcbiAgICAgICAgdGhpcy50b1BpbnR1YW4gPSBmYWxzZVxyXG4gICAgICAgIHRoaXMuc2hvd1NrdSA9IGZhbHNlXHJcbiAgICAgICAgdGhpcy5tb2RhbE5hbWUgPSAnJ1xyXG4gICAgICB9LFxyXG4gICAgICBza3UodHlwZSA9ICdub3JtYWwnKSB7XHJcbiAgICAgICAgdGhpcy5zaG93U2t1ID0gdHJ1ZVxyXG4gICAgICAgIHRoaXMudG9QaW50dWFuID0gZmFsc2VcclxuICAgICAgICB0aGlzLmJ1eVR5cHQgPSB0eXBlXHJcbiAgICAgIH0sXHJcbiAgICAgIHBsdXMoKSB7XHJcbiAgICAgICAgd3gudmlicmF0ZVNob3J0KClcclxuICAgICAgICB0aGlzLm51bSA9IHRoaXMubnVtICsgMVxyXG4gICAgICB9LFxyXG4gICAgICBtaW51cygpIHtcclxuICAgICAgICBpZiAodGhpcy5udW0gPiAxKSB7XHJcbiAgICAgICAgICB3eC52aWJyYXRlU2hvcnQoKVxyXG4gICAgICAgICAgdGhpcy5udW0gPSB0aGlzLm51bSAtIDFcclxuICAgICAgICB9XHJcbiAgICAgIH0sXHJcbiAgICAgIGNvdXJzZShpbngpIHtcclxuICAgICAgICB0aGlzLmNvdXJzZUlueCA9IGlueFxyXG4gICAgICB9LFxyXG4gICAgICBhc3luYyBidXkoYWlkID0gMCwgb3QgPSAxLCApIHtcclxuICAgICAgICBpZiAodGhpcy5jb3Vyc2VJbnggPT0gLTEpIHtcclxuICAgICAgICAgIFRpcHMudG9hc3QoXCLor7fpgInmi6nkuIDkuKrokKXmnJ9cIiwgcmVzID0+IHt9LCAnbm9uZScpXHJcbiAgICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgICB9XHJcbiAgICAgICAgd2VweS5uYXZpZ2F0ZVRvKHtcclxuICAgICAgICAgIHVybDogYC4uL2RldGFpbGUvc3VyZU9yZGVyP3R5cGU9JHtvdH0mcGlkPSR7dGhpcy5jb3Vyc2VJbmZvLnBlcmlvZExpc3RbdGhpcy5jb3Vyc2VJbnhdLmlkfSZjaWQ9JHt0aGlzLmNvdXJzZUluZm8uaWR9Jm51bT0ke3RoaXMubnVtfSZhaWQ9JHt0aGlzLmFjdFBpbnR1YW5BY3Rpdml0eS5pZH0mYWN0cGlkPSR7dGhpcy5jb3Vyc2VJbmZvLnBpbnR1YW5JZH1gXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgfVxyXG4iXX0=