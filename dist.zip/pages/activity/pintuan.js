"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _swiper = require('./../../components/common/swiper.js');

var _swiper2 = _interopRequireDefault(_swiper);

var _title = require('./../../components/detaile/title.js');

var _title2 = _interopRequireDefault(_title);

var _info = require('./../../components/detaile/info.js');

var _info2 = _interopRequireDefault(_info);

var _remake = require('./../../components/detaile/remake.js');

var _remake2 = _interopRequireDefault(_remake);

var _contact = require('./../../components/common/contact.js');

var _contact2 = _interopRequireDefault(_contact);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

var _WxUtils = require('./../../utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

var _utils = require('./../../store/utils.js');

var _utils2 = _interopRequireDefault(_utils);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
  _inherits(Dialog, _wepy$page);

  function Dialog() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, Dialog);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.data = {
      TabCur: 0,
      close: "/static/images/close.png",
      swipers: {
        type: 1,
        list: [{
          id: 0,
          type: "image",
          url: "",
          link: "/pages/meet/meet",
          linkType: "switchTab"
        }]
      },
      actPintuanActivity: {},
      ActPintuanMember: {},
      ActPintuan: {},
      mainHeight: 0,
      courseInfo: {},
      modalName: '',
      nodes: ["name", "attrs", "attrs"],
      num: 1,
      isIn: '',
      showSku: false,
      buyTypt: 'normal',
      courseInx: -1,
      companions: [],
      statistics: {},
      CourseComment: {},
      sign_states: {
        0: '火热招生中',
        1: '少量名额',
        2: '已满员'
      },
      toPintuan: false,
      numList: [{
        name: '参团',
        name1: '支付完成'
      }, {
        name: '获得更多优惠',
        name1: '分享活动'
      }, {
        name: '拼团成功',
        name1: '老师主动联系您'
      }],
      member: {}
    }, _this.$repeat = {}, _this.$props = { "cSwiper": { "xmlns:v-bind": "", "v-bind:model.sync": "swipers" }, "ctitle": { "v-bind:model.sync": "courseInfo" }, "cInfo": { "v-bind:model.sync": "courseInfo", "v-bind:companions.sync": "companions" }, "cRemake": { "v-bind:model.sync": "courseInfo", "v-bind:statistics.sync": "statistics", "v-bind:CourseComment.sync": "CourseComment" } }, _this.$events = {}, _this.components = {
      cSwiper: _swiper2.default,
      ctitle: _title2.default,
      cInfo: _info2.default,
      cRemake: _remake2.default,
      contact: _contact2.default
    }, _this.config = {
      navigationBarTitleText: "活动详情"
    }, _this.methods = {
      createImg: function () {
        var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(e) {
          return regeneratorRuntime.wrap(function _callee$(_context) {
            while (1) {
              switch (_context.prev = _context.next) {
                case 0:
                  if (!(e.detail.errMsg == "getUserInfo:ok")) {
                    _context.next = 5;
                    break;
                  }

                  _context.next = 3;
                  return _auth2.default.getUserinfo(e.detail);

                case 3:
                  _utils2.default.save('shareInfo', {
                    course: this.courseInfo,
                    path: 'pages/activity/pintuan',
                    id: this.actPintuanActivity.id,
                    type: 3,
                    courseId: this.courseInfo.id
                  });
                  _wepy2.default.navigateTo({
                    url: '/pages/home/share'
                  });

                case 5:
                case "end":
                  return _context.stop();
              }
            }
          }, _callee, this);
        }));

        function createImg(_x) {
          return _ref2.apply(this, arguments);
        }

        return createImg;
      }(),
      toshare: function toshare() {
        this.modalName = 'share';
      },
      toPintuanfy: function toPintuanfy() {
        this.toPintuan = true;
      },
      ret: function ret() {
        return false;
      },
      tabSelect: function tabSelect(e) {
        console.log(e);
        this.TabCur = e.currentTarget.dataset.id || e.detail.current;
      },
      hideModal: function hideModal() {
        this.toPintuan = false;
        this.showSku = false;
        this.modalName = '';
      },
      sku: function sku() {
        var type = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'normal';

        this.showSku = true;
        this.toPintuan = false;
        this.buyTypt = type;
      },
      plus: function plus() {
        wx.vibrateShort();
        this.num = this.num + 1;
      },
      minus: function minus() {
        if (this.num > 1) {
          wx.vibrateShort();
          this.num = this.num - 1;
        }
      },
      course: function course(inx) {
        this.courseInx = inx;
      },
      buy: function () {
        var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
          var aid = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;
          var ot = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1;
          return regeneratorRuntime.wrap(function _callee2$(_context2) {
            while (1) {
              switch (_context2.prev = _context2.next) {
                case 0:
                  if (!(this.courseInx == -1)) {
                    _context2.next = 3;
                    break;
                  }

                  _Tips2.default.toast("请选择一个营期", function (res) {}, 'none');
                  return _context2.abrupt("return", false);

                case 3:
                  _wepy2.default.navigateTo({
                    url: "../detaile/sureOrder?type=" + ot + "&pid=" + this.courseInfo.periodList[this.courseInx].id + "&cid=" + this.courseInfo.id + "&num=" + this.num + "&aid=" + this.actPintuanActivity.id + "&actpid=" + this.courseInfo.pintuanId
                  });

                case 4:
                case "end":
                  return _context2.stop();
              }
            }
          }, _callee2, this);
        }));

        function buy() {
          return _ref3.apply(this, arguments);
        }

        return buy;
      }()
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(Dialog, [{
    key: "onShareAppMessage",

    // 转发暂时先不开启
    value: function onShareAppMessage(res) {
      if (res.from === 'button') {
        // 来自页面内转发按钮
        console.log(res.target);
      }
      return {
        title: this.courseInfo.courseTittle,
        imageUrl: this.courseInfo.image,
        path: '/pages/activity/pintuan?id=' + this.actPintuanActivity.id + '&agentId=' + this.member.agentId
      };
    }
  }, {
    key: "onLoad",
    value: function () {
      var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(opt) {
        var _this2 = this;

        var view, res, _res$data, course, companions, statistics, CourseComment, actPintuanActivity, ActPintuan, ActPintuanMember, isIn;

        return regeneratorRuntime.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                console.log(opt);
                // 获取主内容高度，用于悬浮详情导航
                view = wx.createSelectorQuery().select("#info-box");

                view.fields({
                  size: true
                }, function (data) {
                  console.log(data.height);
                  _this2.mainHeight = data.height;
                }).exec();
                _context3.next = 5;
                return _auth2.default.login();

              case 5:
                this.member = _wepy2.default.getStorageSync('member');
                _context3.next = 8;
                return _config2.default.pintuanDetai(opt.id || opt.scene);

              case 8:
                res = _context3.sent;
                _res$data = res.data, course = _res$data.course, companions = _res$data.companions, statistics = _res$data.statistics, CourseComment = _res$data.CourseComment, actPintuanActivity = _res$data.actPintuanActivity, ActPintuan = _res$data.ActPintuan, ActPintuanMember = _res$data.ActPintuanMember, isIn = _res$data.isIn;

                this.swipers.list[0].url = course.image;
                course.courseChar = course.courseChar.split("|");
                this.courseInfo = course;
                _wepy2.default.$instance.globalData.courseInfo = course;
                this.companions = companions;
                this.statistics = statistics;
                this.CourseComment = CourseComment;
                this.actPintuanActivity = actPintuanActivity;
                this.ActPintuan = ActPintuan;
                this.ActPintuanMember = ActPintuanMember;
                this.isIn = isIn;
                this.$apply();

              case 22:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this);
      }));

      function onLoad(_x5) {
        return _ref4.apply(this, arguments);
      }

      return onLoad;
    }()
  }]);

  return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/activity/pintuan'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBpbnR1YW4uanMiXSwibmFtZXMiOlsiRGlhbG9nIiwiZGF0YSIsIlRhYkN1ciIsImNsb3NlIiwic3dpcGVycyIsInR5cGUiLCJsaXN0IiwiaWQiLCJ1cmwiLCJsaW5rIiwibGlua1R5cGUiLCJhY3RQaW50dWFuQWN0aXZpdHkiLCJBY3RQaW50dWFuTWVtYmVyIiwiQWN0UGludHVhbiIsIm1haW5IZWlnaHQiLCJjb3Vyc2VJbmZvIiwibW9kYWxOYW1lIiwibm9kZXMiLCJudW0iLCJpc0luIiwic2hvd1NrdSIsImJ1eVR5cHQiLCJjb3Vyc2VJbngiLCJjb21wYW5pb25zIiwic3RhdGlzdGljcyIsIkNvdXJzZUNvbW1lbnQiLCJzaWduX3N0YXRlcyIsInRvUGludHVhbiIsIm51bUxpc3QiLCJuYW1lIiwibmFtZTEiLCJtZW1iZXIiLCIkcmVwZWF0IiwiJHByb3BzIiwiJGV2ZW50cyIsImNvbXBvbmVudHMiLCJjU3dpcGVyIiwiY3RpdGxlIiwiY0luZm8iLCJjUmVtYWtlIiwiY29udGFjdCIsImNvbmZpZyIsIm5hdmlnYXRpb25CYXJUaXRsZVRleHQiLCJtZXRob2RzIiwiY3JlYXRlSW1nIiwiZSIsImRldGFpbCIsImVyck1zZyIsImF1dGgiLCJnZXRVc2VyaW5mbyIsInN0b3JlIiwic2F2ZSIsImNvdXJzZSIsInBhdGgiLCJjb3Vyc2VJZCIsIndlcHkiLCJuYXZpZ2F0ZVRvIiwidG9zaGFyZSIsInRvUGludHVhbmZ5IiwicmV0IiwidGFiU2VsZWN0IiwiY29uc29sZSIsImxvZyIsImN1cnJlbnRUYXJnZXQiLCJkYXRhc2V0IiwiY3VycmVudCIsImhpZGVNb2RhbCIsInNrdSIsInBsdXMiLCJ3eCIsInZpYnJhdGVTaG9ydCIsIm1pbnVzIiwiaW54IiwiYnV5IiwiYWlkIiwib3QiLCJUaXBzIiwidG9hc3QiLCJwZXJpb2RMaXN0IiwicGludHVhbklkIiwicmVzIiwiZnJvbSIsInRhcmdldCIsInRpdGxlIiwiY291cnNlVGl0dGxlIiwiaW1hZ2VVcmwiLCJpbWFnZSIsImFnZW50SWQiLCJvcHQiLCJ2aWV3IiwiY3JlYXRlU2VsZWN0b3JRdWVyeSIsInNlbGVjdCIsImZpZWxkcyIsInNpemUiLCJoZWlnaHQiLCJleGVjIiwibG9naW4iLCJnZXRTdG9yYWdlU3luYyIsInBpbnR1YW5EZXRhaSIsInNjZW5lIiwiY291cnNlQ2hhciIsInNwbGl0IiwiJGluc3RhbmNlIiwiZ2xvYmFsRGF0YSIsIiRhcHBseSIsInBhZ2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUNFOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7Ozs7Ozs7Ozs7O0lBQ3FCQSxNOzs7Ozs7Ozs7Ozs7OztzTEFDbkJDLEksR0FBTztBQUNMQyxjQUFRLENBREg7QUFFTEMsYUFBTywwQkFGRjtBQUdMQyxlQUFTO0FBQ1BDLGNBQU0sQ0FEQztBQUVQQyxjQUFNLENBQUM7QUFDTEMsY0FBSSxDQURDO0FBRUxGLGdCQUFNLE9BRkQ7QUFHTEcsZUFBSyxFQUhBO0FBSUxDLGdCQUFNLGtCQUpEO0FBS0xDLG9CQUFVO0FBTEwsU0FBRDtBQUZDLE9BSEo7QUFhTEMsMEJBQW9CLEVBYmY7QUFjTEMsd0JBQWtCLEVBZGI7QUFlTEMsa0JBQVksRUFmUDtBQWdCTEMsa0JBQVksQ0FoQlA7QUFpQkxDLGtCQUFZLEVBakJQO0FBa0JMQyxpQkFBVyxFQWxCTjtBQW1CTEMsYUFBTyxDQUFDLE1BQUQsRUFBUyxPQUFULEVBQWtCLE9BQWxCLENBbkJGO0FBb0JMQyxXQUFLLENBcEJBO0FBcUJMQyxZQUFNLEVBckJEO0FBc0JMQyxlQUFTLEtBdEJKO0FBdUJMQyxlQUFTLFFBdkJKO0FBd0JMQyxpQkFBVyxDQUFDLENBeEJQO0FBeUJMQyxrQkFBWSxFQXpCUDtBQTBCTEMsa0JBQVksRUExQlA7QUEyQkxDLHFCQUFlLEVBM0JWO0FBNEJMQyxtQkFBYTtBQUNYLFdBQUcsT0FEUTtBQUVYLFdBQUcsTUFGUTtBQUdYLFdBQUc7QUFIUSxPQTVCUjtBQWlDTEMsaUJBQVcsS0FqQ047QUFrQ0xDLGVBQVMsQ0FBQztBQUNSQyxjQUFNLElBREU7QUFFUkMsZUFBTztBQUZDLE9BQUQsRUFHTjtBQUNERCxjQUFNLFFBREw7QUFFREMsZUFBTztBQUZOLE9BSE0sRUFNTjtBQUNERCxjQUFNLE1BREw7QUFFREMsZUFBTztBQUZOLE9BTk0sQ0FsQ0o7QUE0Q0xDLGNBQVE7QUE1Q0gsSyxRQThDUkMsTyxHQUFVLEUsUUFDYkMsTSxHQUFTLEVBQUMsV0FBVSxFQUFDLGdCQUFlLEVBQWhCLEVBQW1CLHFCQUFvQixTQUF2QyxFQUFYLEVBQTZELFVBQVMsRUFBQyxxQkFBb0IsWUFBckIsRUFBdEUsRUFBeUcsU0FBUSxFQUFDLHFCQUFvQixZQUFyQixFQUFrQywwQkFBeUIsWUFBM0QsRUFBakgsRUFBMEwsV0FBVSxFQUFDLHFCQUFvQixZQUFyQixFQUFrQywwQkFBeUIsWUFBM0QsRUFBd0UsNkJBQTRCLGVBQXBHLEVBQXBNLEUsUUFDVEMsTyxHQUFVLEUsUUFDVEMsVSxHQUFhO0FBQ1JDLCtCQURRO0FBRVJDLDZCQUZRO0FBR1JDLDJCQUhRO0FBSVJDLCtCQUpRO0FBS1JDO0FBTFEsSyxRQU9WQyxNLEdBQVM7QUFDUEMsOEJBQXdCO0FBRGpCLEssUUF1RFRDLE8sR0FBVTtBQUNGQyxlQURFO0FBQUEsNkZBQ1FDLENBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQUVGQSxFQUFFQyxNQUFGLENBQVNDLE1BQVQsSUFBbUIsZ0JBRmpCO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUEseUJBR0VDLGVBQUtDLFdBQUwsQ0FBaUJKLEVBQUVDLE1BQW5CLENBSEY7O0FBQUE7QUFJSkksa0NBQU1DLElBQU4sQ0FBVyxXQUFYLEVBQXdCO0FBQ3RCQyw0QkFBUSxLQUFLckMsVUFEUztBQUV0QnNDLDBCQUFNLHdCQUZnQjtBQUd0QjlDLHdCQUFJLEtBQUtJLGtCQUFMLENBQXdCSixFQUhOO0FBSXRCRiwwQkFBTSxDQUpnQjtBQUt0QmlELDhCQUFVLEtBQUt2QyxVQUFMLENBQWdCUjtBQUxKLG1CQUF4QjtBQU9BZ0QsaUNBQUtDLFVBQUwsQ0FBZ0I7QUFDZGhELHlCQUFLO0FBRFMsbUJBQWhCOztBQVhJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBZ0JSaUQsYUFoQlEscUJBZ0JFO0FBQ1IsYUFBS3pDLFNBQUwsR0FBaUIsT0FBakI7QUFDRCxPQWxCTztBQW1CUjBDLGlCQW5CUSx5QkFtQk07QUFDWixhQUFLL0IsU0FBTCxHQUFpQixJQUFqQjtBQUNELE9BckJPO0FBc0JSZ0MsU0F0QlEsaUJBc0JGO0FBQ0osZUFBTyxLQUFQO0FBQ0QsT0F4Qk87QUF5QlJDLGVBekJRLHFCQXlCRWYsQ0F6QkYsRUF5Qks7QUFDWGdCLGdCQUFRQyxHQUFSLENBQVlqQixDQUFaO0FBQ0EsYUFBSzNDLE1BQUwsR0FBYzJDLEVBQUVrQixhQUFGLENBQWdCQyxPQUFoQixDQUF3QnpELEVBQXhCLElBQThCc0MsRUFBRUMsTUFBRixDQUFTbUIsT0FBckQ7QUFDRCxPQTVCTztBQTZCUkMsZUE3QlEsdUJBNkJJO0FBQ1YsYUFBS3ZDLFNBQUwsR0FBaUIsS0FBakI7QUFDQSxhQUFLUCxPQUFMLEdBQWUsS0FBZjtBQUNBLGFBQUtKLFNBQUwsR0FBaUIsRUFBakI7QUFDRCxPQWpDTztBQWtDUm1ELFNBbENRLGlCQWtDYTtBQUFBLFlBQWpCOUQsSUFBaUIsdUVBQVYsUUFBVTs7QUFDbkIsYUFBS2UsT0FBTCxHQUFlLElBQWY7QUFDQSxhQUFLTyxTQUFMLEdBQWlCLEtBQWpCO0FBQ0EsYUFBS04sT0FBTCxHQUFlaEIsSUFBZjtBQUNELE9BdENPO0FBdUNSK0QsVUF2Q1Esa0JBdUNEO0FBQ0xDLFdBQUdDLFlBQUg7QUFDQSxhQUFLcEQsR0FBTCxHQUFXLEtBQUtBLEdBQUwsR0FBVyxDQUF0QjtBQUNELE9BMUNPO0FBMkNScUQsV0EzQ1EsbUJBMkNBO0FBQ04sWUFBSSxLQUFLckQsR0FBTCxHQUFXLENBQWYsRUFBa0I7QUFDaEJtRCxhQUFHQyxZQUFIO0FBQ0EsZUFBS3BELEdBQUwsR0FBVyxLQUFLQSxHQUFMLEdBQVcsQ0FBdEI7QUFDRDtBQUNGLE9BaERPO0FBaURSa0MsWUFqRFEsa0JBaUREb0IsR0FqREMsRUFpREk7QUFDVixhQUFLbEQsU0FBTCxHQUFpQmtELEdBQWpCO0FBQ0QsT0FuRE87QUFvREZDLFNBcERFO0FBQUE7QUFBQSxjQW9ERUMsR0FwREYsdUVBb0RRLENBcERSO0FBQUEsY0FvRFdDLEVBcERYLHVFQW9EZ0IsQ0FwRGhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFxREYsS0FBS3JELFNBQUwsSUFBa0IsQ0FBQyxDQXJEakI7QUFBQTtBQUFBO0FBQUE7O0FBc0RKc0QsaUNBQUtDLEtBQUwsQ0FBVyxTQUFYLEVBQXNCLGVBQU8sQ0FBRSxDQUEvQixFQUFpQyxNQUFqQztBQXRESSxvREF1REcsS0F2REg7O0FBQUE7QUF5RE50QixpQ0FBS0MsVUFBTCxDQUFnQjtBQUNkaEQsd0RBQWtDbUUsRUFBbEMsYUFBNEMsS0FBSzVELFVBQUwsQ0FBZ0IrRCxVQUFoQixDQUEyQixLQUFLeEQsU0FBaEMsRUFBMkNmLEVBQXZGLGFBQWlHLEtBQUtRLFVBQUwsQ0FBZ0JSLEVBQWpILGFBQTJILEtBQUtXLEdBQWhJLGFBQTJJLEtBQUtQLGtCQUFMLENBQXdCSixFQUFuSyxnQkFBZ0wsS0FBS1EsVUFBTCxDQUFnQmdFO0FBRGxMLG1CQUFoQjs7QUF6RE07QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQSxLOzs7Ozs7QUFwRFY7c0NBQ2tCQyxHLEVBQUs7QUFDckIsVUFBSUEsSUFBSUMsSUFBSixLQUFhLFFBQWpCLEVBQTJCO0FBQ3pCO0FBQ0FwQixnQkFBUUMsR0FBUixDQUFZa0IsSUFBSUUsTUFBaEI7QUFDRDtBQUNELGFBQU87QUFDTEMsZUFBTyxLQUFLcEUsVUFBTCxDQUFnQnFFLFlBRGxCO0FBRUxDLGtCQUFVLEtBQUt0RSxVQUFMLENBQWdCdUUsS0FGckI7QUFHTGpDLGNBQU0sZ0NBQWdDLEtBQUsxQyxrQkFBTCxDQUF3QkosRUFBeEQsR0FBNkQsV0FBN0QsR0FBMkUsS0FBS3dCLE1BQUwsQ0FBWXdEO0FBSHhGLE9BQVA7QUFLRDs7Ozs0RkFDWUMsRzs7Ozs7Ozs7O0FBQ1gzQix3QkFBUUMsR0FBUixDQUFZMEIsR0FBWjtBQUNBO0FBQ0lDLG9CLEdBQU9wQixHQUFHcUIsbUJBQUgsR0FBeUJDLE1BQXpCLENBQWdDLFdBQWhDLEM7O0FBQ1hGLHFCQUNHRyxNQURILENBQ1U7QUFDSkMsd0JBQU07QUFERixpQkFEVixFQUlJLGdCQUFRO0FBQ05oQywwQkFBUUMsR0FBUixDQUFZN0QsS0FBSzZGLE1BQWpCO0FBQ0EseUJBQUtoRixVQUFMLEdBQWtCYixLQUFLNkYsTUFBdkI7QUFDRCxpQkFQTCxFQVNHQyxJQVRIOzt1QkFVTS9DLGVBQUtnRCxLQUFMLEU7OztBQUNOLHFCQUFLakUsTUFBTCxHQUFjd0IsZUFBSzBDLGNBQUwsQ0FBb0IsUUFBcEIsQ0FBZDs7dUJBQ2dCeEQsaUJBQU95RCxZQUFQLENBQW9CVixJQUFJakYsRUFBSixJQUFVaUYsSUFBSVcsS0FBbEMsQzs7O0FBQVpuQixtQjs0QkFVQUEsSUFBSS9FLEksRUFSTm1ELE0sYUFBQUEsTSxFQUNBN0IsVSxhQUFBQSxVLEVBQ0FDLFUsYUFBQUEsVSxFQUNBQyxhLGFBQUFBLGEsRUFDQWQsa0IsYUFBQUEsa0IsRUFDQUUsVSxhQUFBQSxVLEVBQ0FELGdCLGFBQUFBLGdCLEVBQ0FPLEksYUFBQUEsSTs7QUFFRixxQkFBS2YsT0FBTCxDQUFhRSxJQUFiLENBQWtCLENBQWxCLEVBQXFCRSxHQUFyQixHQUEyQjRDLE9BQU9rQyxLQUFsQztBQUNBbEMsdUJBQU9nRCxVQUFQLEdBQW9CaEQsT0FBT2dELFVBQVAsQ0FBa0JDLEtBQWxCLENBQXdCLEdBQXhCLENBQXBCO0FBQ0EscUJBQUt0RixVQUFMLEdBQWtCcUMsTUFBbEI7QUFDQUcsK0JBQUsrQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJ4RixVQUExQixHQUF1Q3FDLE1BQXZDO0FBQ0EscUJBQUs3QixVQUFMLEdBQWtCQSxVQUFsQjtBQUNBLHFCQUFLQyxVQUFMLEdBQWtCQSxVQUFsQjtBQUNBLHFCQUFLQyxhQUFMLEdBQXFCQSxhQUFyQjtBQUNBLHFCQUFLZCxrQkFBTCxHQUEwQkEsa0JBQTFCO0FBQ0EscUJBQUtFLFVBQUwsR0FBa0JBLFVBQWxCO0FBQ0EscUJBQUtELGdCQUFMLEdBQXdCQSxnQkFBeEI7QUFDQSxxQkFBS08sSUFBTCxHQUFZQSxJQUFaO0FBQ0EscUJBQUtxRixNQUFMOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBOUdnQ2pELGVBQUtrRCxJOztrQkFBcEJ6RyxNIiwiZmlsZSI6InBpbnR1YW4uanMiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuICBpbXBvcnQgd2VweSBmcm9tIFwid2VweVwiO1xyXG4gIGltcG9ydCBjU3dpcGVyIGZyb20gXCJAL2NvbXBvbmVudHMvY29tbW9uL3N3aXBlclwiO1xyXG4gIGltcG9ydCBjdGl0bGUgZnJvbSBcIkAvY29tcG9uZW50cy9kZXRhaWxlL3RpdGxlXCI7XHJcbiAgaW1wb3J0IGNJbmZvIGZyb20gXCJAL2NvbXBvbmVudHMvZGV0YWlsZS9pbmZvXCI7XHJcbiAgaW1wb3J0IGNSZW1ha2UgZnJvbSBcIkAvY29tcG9uZW50cy9kZXRhaWxlL3JlbWFrZVwiO1xyXG4gIGltcG9ydCBjb250YWN0IGZyb20gXCJAL2NvbXBvbmVudHMvY29tbW9uL2NvbnRhY3RcIlxyXG4gIGltcG9ydCBjb25maWcgZnJvbSBcIkAvYXBpL2NvbmZpZ1wiO1xyXG4gIGltcG9ydCBhdXRoIGZyb20gXCJAL2FwaS9hdXRoXCI7XHJcbiAgaW1wb3J0IFd4VXRpbHMgZnJvbSBcIkAvdXRpbHMvV3hVdGlsc1wiO1xyXG4gIGltcG9ydCBUaXBzIGZyb20gXCJAL3V0aWxzL1RpcHNcIjtcclxuICBpbXBvcnQgc3RvcmUgZnJvbSBcIkAvc3RvcmUvdXRpbHNcIlxyXG4gIGV4cG9ydCBkZWZhdWx0IGNsYXNzIERpYWxvZyBleHRlbmRzIHdlcHkucGFnZSB7XHJcbiAgICBkYXRhID0ge1xyXG4gICAgICBUYWJDdXI6IDAsXHJcbiAgICAgIGNsb3NlOiBcIi9zdGF0aWMvaW1hZ2VzL2Nsb3NlLnBuZ1wiLFxyXG4gICAgICBzd2lwZXJzOiB7XHJcbiAgICAgICAgdHlwZTogMSxcclxuICAgICAgICBsaXN0OiBbe1xyXG4gICAgICAgICAgaWQ6IDAsXHJcbiAgICAgICAgICB0eXBlOiBcImltYWdlXCIsXHJcbiAgICAgICAgICB1cmw6IFwiXCIsXHJcbiAgICAgICAgICBsaW5rOiBcIi9wYWdlcy9tZWV0L21lZXRcIixcclxuICAgICAgICAgIGxpbmtUeXBlOiBcInN3aXRjaFRhYlwiXHJcbiAgICAgICAgfV1cclxuICAgICAgfSxcclxuICAgICAgYWN0UGludHVhbkFjdGl2aXR5OiB7fSxcclxuICAgICAgQWN0UGludHVhbk1lbWJlcjoge30sXHJcbiAgICAgIEFjdFBpbnR1YW46IHt9LFxyXG4gICAgICBtYWluSGVpZ2h0OiAwLFxyXG4gICAgICBjb3Vyc2VJbmZvOiB7fSxcclxuICAgICAgbW9kYWxOYW1lOiAnJyxcclxuICAgICAgbm9kZXM6IFtcIm5hbWVcIiwgXCJhdHRyc1wiLCBcImF0dHJzXCJdLFxyXG4gICAgICBudW06IDEsXHJcbiAgICAgIGlzSW46ICcnLFxyXG4gICAgICBzaG93U2t1OiBmYWxzZSxcclxuICAgICAgYnV5VHlwdDogJ25vcm1hbCcsXHJcbiAgICAgIGNvdXJzZUlueDogLTEsXHJcbiAgICAgIGNvbXBhbmlvbnM6IFtdLFxyXG4gICAgICBzdGF0aXN0aWNzOiB7fSxcclxuICAgICAgQ291cnNlQ29tbWVudDoge30sXHJcbiAgICAgIHNpZ25fc3RhdGVzOiB7XHJcbiAgICAgICAgMDogJ+eBq+eDreaLm+eUn+S4rScsXHJcbiAgICAgICAgMTogJ+WwkemHj+WQjeminScsXHJcbiAgICAgICAgMjogJ+W3sua7oeWRmCdcclxuICAgICAgfSxcclxuICAgICAgdG9QaW50dWFuOiBmYWxzZSxcclxuICAgICAgbnVtTGlzdDogW3tcclxuICAgICAgICBuYW1lOiAn5Y+C5ZuiJyxcclxuICAgICAgICBuYW1lMTogJ+aUr+S7mOWujOaIkCdcclxuICAgICAgfSwge1xyXG4gICAgICAgIG5hbWU6ICfojrflvpfmm7TlpJrkvJjmg6AnLFxyXG4gICAgICAgIG5hbWUxOiAn5YiG5Lqr5rS75YqoJ1xyXG4gICAgICB9LCB7XHJcbiAgICAgICAgbmFtZTogJ+aLvOWbouaIkOWKnycsXHJcbiAgICAgICAgbmFtZTE6ICfogIHluIjkuLvliqjogZTns7vmgqgnXHJcbiAgICAgIH1dLFxyXG4gICAgICBtZW1iZXI6IHt9XHJcbiAgICB9O1xyXG4gICAkcmVwZWF0ID0ge307XHJcbiRwcm9wcyA9IHtcImNTd2lwZXJcIjp7XCJ4bWxuczp2LWJpbmRcIjpcIlwiLFwidi1iaW5kOm1vZGVsLnN5bmNcIjpcInN3aXBlcnNcIn0sXCJjdGl0bGVcIjp7XCJ2LWJpbmQ6bW9kZWwuc3luY1wiOlwiY291cnNlSW5mb1wifSxcImNJbmZvXCI6e1widi1iaW5kOm1vZGVsLnN5bmNcIjpcImNvdXJzZUluZm9cIixcInYtYmluZDpjb21wYW5pb25zLnN5bmNcIjpcImNvbXBhbmlvbnNcIn0sXCJjUmVtYWtlXCI6e1widi1iaW5kOm1vZGVsLnN5bmNcIjpcImNvdXJzZUluZm9cIixcInYtYmluZDpzdGF0aXN0aWNzLnN5bmNcIjpcInN0YXRpc3RpY3NcIixcInYtYmluZDpDb3Vyc2VDb21tZW50LnN5bmNcIjpcIkNvdXJzZUNvbW1lbnRcIn19O1xyXG4kZXZlbnRzID0ge307XHJcbiBjb21wb25lbnRzID0ge1xyXG4gICAgICBjU3dpcGVyLFxyXG4gICAgICBjdGl0bGUsXHJcbiAgICAgIGNJbmZvLFxyXG4gICAgICBjUmVtYWtlLFxyXG4gICAgICBjb250YWN0XHJcbiAgICB9O1xyXG4gICAgY29uZmlnID0ge1xyXG4gICAgICBuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0OiBcIua0u+WKqOivpuaDhVwiXHJcbiAgICB9O1xyXG4gICAgLy8g6L2s5Y+R5pqC5pe25YWI5LiN5byA5ZCvXHJcbiAgICBvblNoYXJlQXBwTWVzc2FnZShyZXMpIHtcclxuICAgICAgaWYgKHJlcy5mcm9tID09PSAnYnV0dG9uJykge1xyXG4gICAgICAgIC8vIOadpeiHqumhtemdouWGhei9rOWPkeaMiemSrlxyXG4gICAgICAgIGNvbnNvbGUubG9nKHJlcy50YXJnZXQpXHJcbiAgICAgIH1cclxuICAgICAgcmV0dXJuIHtcclxuICAgICAgICB0aXRsZTogdGhpcy5jb3Vyc2VJbmZvLmNvdXJzZVRpdHRsZSxcclxuICAgICAgICBpbWFnZVVybDogdGhpcy5jb3Vyc2VJbmZvLmltYWdlLFxyXG4gICAgICAgIHBhdGg6ICcvcGFnZXMvYWN0aXZpdHkvcGludHVhbj9pZD0nICsgdGhpcy5hY3RQaW50dWFuQWN0aXZpdHkuaWQgKyAnJmFnZW50SWQ9JyArIHRoaXMubWVtYmVyLmFnZW50SWRcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgYXN5bmMgb25Mb2FkKG9wdCkge1xyXG4gICAgICBjb25zb2xlLmxvZyhvcHQpXHJcbiAgICAgIC8vIOiOt+WPluS4u+WGheWuuemrmOW6pu+8jOeUqOS6juaCrOa1ruivpuaDheWvvOiIqlxyXG4gICAgICBsZXQgdmlldyA9IHd4LmNyZWF0ZVNlbGVjdG9yUXVlcnkoKS5zZWxlY3QoXCIjaW5mby1ib3hcIik7XHJcbiAgICAgIHZpZXdcclxuICAgICAgICAuZmllbGRzKHtcclxuICAgICAgICAgICAgc2l6ZTogdHJ1ZVxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIGRhdGEgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhkYXRhLmhlaWdodCk7XHJcbiAgICAgICAgICAgIHRoaXMubWFpbkhlaWdodCA9IGRhdGEuaGVpZ2h0O1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIClcclxuICAgICAgICAuZXhlYygpO1xyXG4gICAgICBhd2FpdCBhdXRoLmxvZ2luKClcclxuICAgICAgdGhpcy5tZW1iZXIgPSB3ZXB5LmdldFN0b3JhZ2VTeW5jKCdtZW1iZXInKTtcclxuICAgICAgbGV0IHJlcyA9IGF3YWl0IGNvbmZpZy5waW50dWFuRGV0YWkob3B0LmlkIHx8IG9wdC5zY2VuZSlcclxuICAgICAgbGV0IHtcclxuICAgICAgICBjb3Vyc2UsXHJcbiAgICAgICAgY29tcGFuaW9ucyxcclxuICAgICAgICBzdGF0aXN0aWNzLFxyXG4gICAgICAgIENvdXJzZUNvbW1lbnQsXHJcbiAgICAgICAgYWN0UGludHVhbkFjdGl2aXR5LFxyXG4gICAgICAgIEFjdFBpbnR1YW4sXHJcbiAgICAgICAgQWN0UGludHVhbk1lbWJlcixcclxuICAgICAgICBpc0luXHJcbiAgICAgIH0gPSByZXMuZGF0YVxyXG4gICAgICB0aGlzLnN3aXBlcnMubGlzdFswXS51cmwgPSBjb3Vyc2UuaW1hZ2VcclxuICAgICAgY291cnNlLmNvdXJzZUNoYXIgPSBjb3Vyc2UuY291cnNlQ2hhci5zcGxpdChcInxcIilcclxuICAgICAgdGhpcy5jb3Vyc2VJbmZvID0gY291cnNlXHJcbiAgICAgIHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuY291cnNlSW5mbyA9IGNvdXJzZVxyXG4gICAgICB0aGlzLmNvbXBhbmlvbnMgPSBjb21wYW5pb25zXHJcbiAgICAgIHRoaXMuc3RhdGlzdGljcyA9IHN0YXRpc3RpY3NcclxuICAgICAgdGhpcy5Db3Vyc2VDb21tZW50ID0gQ291cnNlQ29tbWVudFxyXG4gICAgICB0aGlzLmFjdFBpbnR1YW5BY3Rpdml0eSA9IGFjdFBpbnR1YW5BY3Rpdml0eVxyXG4gICAgICB0aGlzLkFjdFBpbnR1YW4gPSBBY3RQaW50dWFuXHJcbiAgICAgIHRoaXMuQWN0UGludHVhbk1lbWJlciA9IEFjdFBpbnR1YW5NZW1iZXJcclxuICAgICAgdGhpcy5pc0luID0gaXNJblxyXG4gICAgICB0aGlzLiRhcHBseSgpO1xyXG4gICAgfVxyXG4gICAgbWV0aG9kcyA9IHtcclxuICAgICAgYXN5bmMgY3JlYXRlSW1nKGUpIHtcclxuICAgICAgICBpZiAoZS5kZXRhaWwuZXJyTXNnID09IFwiZ2V0VXNlckluZm86b2tcIikge1xyXG4gICAgICAgICAgYXdhaXQgYXV0aC5nZXRVc2VyaW5mbyhlLmRldGFpbClcclxuICAgICAgICAgIHN0b3JlLnNhdmUoJ3NoYXJlSW5mbycsIHtcclxuICAgICAgICAgICAgY291cnNlOiB0aGlzLmNvdXJzZUluZm8sXHJcbiAgICAgICAgICAgIHBhdGg6ICdwYWdlcy9hY3Rpdml0eS9waW50dWFuJyxcclxuICAgICAgICAgICAgaWQ6IHRoaXMuYWN0UGludHVhbkFjdGl2aXR5LmlkLFxyXG4gICAgICAgICAgICB0eXBlOiAzLFxyXG4gICAgICAgICAgICBjb3Vyc2VJZDogdGhpcy5jb3Vyc2VJbmZvLmlkXHJcbiAgICAgICAgICB9KVxyXG4gICAgICAgICAgd2VweS5uYXZpZ2F0ZVRvKHtcclxuICAgICAgICAgICAgdXJsOiAnL3BhZ2VzL2hvbWUvc2hhcmUnXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgIH0sXHJcbiAgICAgIHRvc2hhcmUoKSB7XHJcbiAgICAgICAgdGhpcy5tb2RhbE5hbWUgPSAnc2hhcmUnXHJcbiAgICAgIH0sXHJcbiAgICAgIHRvUGludHVhbmZ5KCkge1xyXG4gICAgICAgIHRoaXMudG9QaW50dWFuID0gdHJ1ZVxyXG4gICAgICB9LFxyXG4gICAgICByZXQoKSB7XHJcbiAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgIH0sXHJcbiAgICAgIHRhYlNlbGVjdChlKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coZSk7XHJcbiAgICAgICAgdGhpcy5UYWJDdXIgPSBlLmN1cnJlbnRUYXJnZXQuZGF0YXNldC5pZCB8fCBlLmRldGFpbC5jdXJyZW50O1xyXG4gICAgICB9LFxyXG4gICAgICBoaWRlTW9kYWwoKSB7XHJcbiAgICAgICAgdGhpcy50b1BpbnR1YW4gPSBmYWxzZVxyXG4gICAgICAgIHRoaXMuc2hvd1NrdSA9IGZhbHNlXHJcbiAgICAgICAgdGhpcy5tb2RhbE5hbWUgPSAnJ1xyXG4gICAgICB9LFxyXG4gICAgICBza3UodHlwZSA9ICdub3JtYWwnKSB7XHJcbiAgICAgICAgdGhpcy5zaG93U2t1ID0gdHJ1ZVxyXG4gICAgICAgIHRoaXMudG9QaW50dWFuID0gZmFsc2VcclxuICAgICAgICB0aGlzLmJ1eVR5cHQgPSB0eXBlXHJcbiAgICAgIH0sXHJcbiAgICAgIHBsdXMoKSB7XHJcbiAgICAgICAgd3gudmlicmF0ZVNob3J0KClcclxuICAgICAgICB0aGlzLm51bSA9IHRoaXMubnVtICsgMVxyXG4gICAgICB9LFxyXG4gICAgICBtaW51cygpIHtcclxuICAgICAgICBpZiAodGhpcy5udW0gPiAxKSB7XHJcbiAgICAgICAgICB3eC52aWJyYXRlU2hvcnQoKVxyXG4gICAgICAgICAgdGhpcy5udW0gPSB0aGlzLm51bSAtIDFcclxuICAgICAgICB9XHJcbiAgICAgIH0sXHJcbiAgICAgIGNvdXJzZShpbngpIHtcclxuICAgICAgICB0aGlzLmNvdXJzZUlueCA9IGlueFxyXG4gICAgICB9LFxyXG4gICAgICBhc3luYyBidXkoYWlkID0gMCwgb3QgPSAxLCApIHtcclxuICAgICAgICBpZiAodGhpcy5jb3Vyc2VJbnggPT0gLTEpIHtcclxuICAgICAgICAgIFRpcHMudG9hc3QoXCLor7fpgInmi6nkuIDkuKrokKXmnJ9cIiwgcmVzID0+IHt9LCAnbm9uZScpXHJcbiAgICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgICB9XHJcbiAgICAgICAgd2VweS5uYXZpZ2F0ZVRvKHtcclxuICAgICAgICAgIHVybDogYC4uL2RldGFpbGUvc3VyZU9yZGVyP3R5cGU9JHtvdH0mcGlkPSR7dGhpcy5jb3Vyc2VJbmZvLnBlcmlvZExpc3RbdGhpcy5jb3Vyc2VJbnhdLmlkfSZjaWQ9JHt0aGlzLmNvdXJzZUluZm8uaWR9Jm51bT0ke3RoaXMubnVtfSZhaWQ9JHt0aGlzLmFjdFBpbnR1YW5BY3Rpdml0eS5pZH0mYWN0cGlkPSR7dGhpcy5jb3Vyc2VJbmZvLnBpbnR1YW5JZH1gXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgfVxyXG4iXX0=