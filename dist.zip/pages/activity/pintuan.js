"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _swiper = require('./../../components/common/swiper.js');

var _swiper2 = _interopRequireDefault(_swiper);

var _title = require('./../../components/detaile/title.js');

var _title2 = _interopRequireDefault(_title);

var _info = require('./../../components/detaile/info.js');

var _info2 = _interopRequireDefault(_info);

var _remake = require('./../../components/detaile/remake.js');

var _remake2 = _interopRequireDefault(_remake);

var _contact = require('./../../components/common/contact.js');

var _contact2 = _interopRequireDefault(_contact);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

var _WxUtils = require('./../../utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

var _utils = require('./../../store/utils.js');

var _utils2 = _interopRequireDefault(_utils);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
    _inherits(Dialog, _wepy$page);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.data = {
            TabCur: 0,
            close: "/static/images/close.png",
            swipers: {
                type: 1,
                list: [{
                    id: 0,
                    type: "image",
                    url: "",
                    link: "/pages/meet/meet",
                    linkType: "switchTab"
                }]
            },
            actPintuanActivity: {},
            ActPintuanMember: {},
            ActPintuan: {},
            mainHeight: 0,
            courseInfo: {},
            modalName: '',
            nodes: ["name", "attrs", "attrs"],
            num: 1,
            isIn: '',
            showSku: false,
            buyTypt: 'normal',
            courseInx: -1,
            companions: [],
            statistics: {},
            CourseComment: {},
            sign_states: {
                0: '火热招生中',
                1: '少量名额',
                2: '已满员'
            },
            toPintuan: false,
            numList: [{
                name: '参团',
                name1: '支付完成'
            }, {
                name: '获得更多优惠',
                name1: '分享活动'
            }, {
                name: '拼团成功',
                name1: '老师主动联系您'
            }]
        }, _this.$repeat = {}, _this.$props = { "cSwiper": { "xmlns:v-bind": "", "v-bind:model.sync": "swipers" }, "ctitle": { "v-bind:model.sync": "courseInfo" }, "cInfo": { "v-bind:model.sync": "courseInfo", "v-bind:companions.sync": "companions" }, "cRemake": { "v-bind:model.sync": "courseInfo", "v-bind:statistics.sync": "statistics", "v-bind:CourseComment.sync": "CourseComment" } }, _this.$events = {}, _this.components = {
            cSwiper: _swiper2.default,
            ctitle: _title2.default,
            cInfo: _info2.default,
            cRemake: _remake2.default,
            contact: _contact2.default
        }, _this.config = {
            navigationBarTitleText: "活动详情"
        }, _this.methods = {
            createImg: function () {
                var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(e) {
                    return regeneratorRuntime.wrap(function _callee$(_context) {
                        while (1) {
                            switch (_context.prev = _context.next) {
                                case 0:
                                    if (!(e.detail.errMsg == "getUserInfo:ok")) {
                                        _context.next = 5;
                                        break;
                                    }

                                    _context.next = 3;
                                    return _auth2.default.getUserinfo(e.detail);

                                case 3:
                                    _utils2.default.save('shareInfo', {
                                        course: this.courseInfo,
                                        path: 'pages/activity/pintuan',
                                        id: this.actPintuanActivity.id
                                    });
                                    _wepy2.default.navigateTo({
                                        url: '/pages/home/share'
                                    });

                                case 5:
                                case "end":
                                    return _context.stop();
                            }
                        }
                    }, _callee, this);
                }));

                function createImg(_x) {
                    return _ref2.apply(this, arguments);
                }

                return createImg;
            }(),
            toshare: function toshare() {
                this.modalName = 'share';
            },
            toPintuanfy: function toPintuanfy() {
                this.toPintuan = true;
            },
            ret: function ret() {
                return false;
            },
            tabSelect: function tabSelect(e) {
                console.log(e);
                this.TabCur = e.currentTarget.dataset.id || e.detail.current;
            },
            hideModal: function hideModal() {
                this.toPintuan = false;
                this.showSku = false;
                this.modalName = '';
            },
            sku: function sku() {
                var type = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'normal';

                this.showSku = true;
                this.toPintuan = false;
                this.buyTypt = type;
            },
            plus: function plus() {
                wx.vibrateShort();
                this.num = this.num + 1;
            },
            minus: function minus() {
                if (this.num > 1) {
                    wx.vibrateShort();
                    this.num = this.num - 1;
                }
            },
            course: function course(inx) {
                this.courseInx = inx;
            },
            buy: function () {
                var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
                    var aid = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;
                    var ot = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1;
                    return regeneratorRuntime.wrap(function _callee2$(_context2) {
                        while (1) {
                            switch (_context2.prev = _context2.next) {
                                case 0:
                                    if (!(this.courseInx == -1)) {
                                        _context2.next = 3;
                                        break;
                                    }

                                    _Tips2.default.toast("请选择一个营期", function (res) {}, 'none');
                                    return _context2.abrupt("return", false);

                                case 3:
                                    _wepy2.default.navigateTo({
                                        url: "../detaile/sureOrder?type=" + ot + "&pid=" + this.courseInfo.periodList[this.courseInx].id + "&cid=" + this.courseInfo.id + "&num=" + this.num + "&aid=" + this.actPintuanActivity.id + "&actpid=" + this.courseInfo.pintuanId
                                    });

                                case 4:
                                case "end":
                                    return _context2.stop();
                            }
                        }
                    }, _callee2, this);
                }));

                function buy() {
                    return _ref3.apply(this, arguments);
                }

                return buy;
            }()
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(Dialog, [{
        key: "onShareAppMessage",

        // 转发暂时先不开启
        value: function onShareAppMessage(res) {
            if (res.from === 'button') {
                // 来自页面内转发按钮
                console.log(res.target);
            }
            return {
                title: this.courseInfo.courseTittle,
                imageUrl: this.courseInfo.image,
                path: '/pages/activity/pintuan?id=' + this.actPintuanActivity.id
            };
        }
    }, {
        key: "onLoad",
        value: function () {
            var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(opt) {
                var _this2 = this;

                var view, res, _res$data, course, companions, statistics, CourseComment, actPintuanActivity, ActPintuan, ActPintuanMember, isIn;

                return regeneratorRuntime.wrap(function _callee3$(_context3) {
                    while (1) {
                        switch (_context3.prev = _context3.next) {
                            case 0:
                                console.log(opt);
                                // 获取主内容高度，用于悬浮详情导航
                                view = wx.createSelectorQuery().select("#info-box");

                                view.fields({
                                    size: true
                                }, function (data) {
                                    console.log(data.height);
                                    _this2.mainHeight = data.height;
                                }).exec();
                                _context3.next = 5;
                                return _auth2.default.login();

                            case 5:
                                _context3.next = 7;
                                return _config2.default.pintuanDetai(opt.id || opt.scene);

                            case 7:
                                res = _context3.sent;
                                _res$data = res.data, course = _res$data.course, companions = _res$data.companions, statistics = _res$data.statistics, CourseComment = _res$data.CourseComment, actPintuanActivity = _res$data.actPintuanActivity, ActPintuan = _res$data.ActPintuan, ActPintuanMember = _res$data.ActPintuanMember, isIn = _res$data.isIn;

                                this.swipers.list[0].url = course.image;
                                course.courseChar = course.courseChar.split("|");
                                this.courseInfo = course;
                                _wepy2.default.$instance.globalData.courseInfo = course;
                                this.companions = companions;
                                this.statistics = statistics;
                                this.CourseComment = CourseComment;
                                this.actPintuanActivity = actPintuanActivity;
                                this.ActPintuan = ActPintuan;
                                this.ActPintuanMember = ActPintuanMember;
                                this.isIn = isIn;
                                this.$apply();

                            case 21:
                            case "end":
                                return _context3.stop();
                        }
                    }
                }, _callee3, this);
            }));

            function onLoad(_x5) {
                return _ref4.apply(this, arguments);
            }

            return onLoad;
        }()
    }]);

    return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/activity/pintuan'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBpbnR1YW4uanMiXSwibmFtZXMiOlsiRGlhbG9nIiwiZGF0YSIsIlRhYkN1ciIsImNsb3NlIiwic3dpcGVycyIsInR5cGUiLCJsaXN0IiwiaWQiLCJ1cmwiLCJsaW5rIiwibGlua1R5cGUiLCJhY3RQaW50dWFuQWN0aXZpdHkiLCJBY3RQaW50dWFuTWVtYmVyIiwiQWN0UGludHVhbiIsIm1haW5IZWlnaHQiLCJjb3Vyc2VJbmZvIiwibW9kYWxOYW1lIiwibm9kZXMiLCJudW0iLCJpc0luIiwic2hvd1NrdSIsImJ1eVR5cHQiLCJjb3Vyc2VJbngiLCJjb21wYW5pb25zIiwic3RhdGlzdGljcyIsIkNvdXJzZUNvbW1lbnQiLCJzaWduX3N0YXRlcyIsInRvUGludHVhbiIsIm51bUxpc3QiLCJuYW1lIiwibmFtZTEiLCIkcmVwZWF0IiwiJHByb3BzIiwiJGV2ZW50cyIsImNvbXBvbmVudHMiLCJjU3dpcGVyIiwiY3RpdGxlIiwiY0luZm8iLCJjUmVtYWtlIiwiY29udGFjdCIsImNvbmZpZyIsIm5hdmlnYXRpb25CYXJUaXRsZVRleHQiLCJtZXRob2RzIiwiY3JlYXRlSW1nIiwiZSIsImRldGFpbCIsImVyck1zZyIsImF1dGgiLCJnZXRVc2VyaW5mbyIsInN0b3JlIiwic2F2ZSIsImNvdXJzZSIsInBhdGgiLCJ3ZXB5IiwibmF2aWdhdGVUbyIsInRvc2hhcmUiLCJ0b1BpbnR1YW5meSIsInJldCIsInRhYlNlbGVjdCIsImNvbnNvbGUiLCJsb2ciLCJjdXJyZW50VGFyZ2V0IiwiZGF0YXNldCIsImN1cnJlbnQiLCJoaWRlTW9kYWwiLCJza3UiLCJwbHVzIiwid3giLCJ2aWJyYXRlU2hvcnQiLCJtaW51cyIsImlueCIsImJ1eSIsImFpZCIsIm90IiwiVGlwcyIsInRvYXN0IiwicGVyaW9kTGlzdCIsInBpbnR1YW5JZCIsInJlcyIsImZyb20iLCJ0YXJnZXQiLCJ0aXRsZSIsImNvdXJzZVRpdHRsZSIsImltYWdlVXJsIiwiaW1hZ2UiLCJvcHQiLCJ2aWV3IiwiY3JlYXRlU2VsZWN0b3JRdWVyeSIsInNlbGVjdCIsImZpZWxkcyIsInNpemUiLCJoZWlnaHQiLCJleGVjIiwibG9naW4iLCJwaW50dWFuRGV0YWkiLCJzY2VuZSIsImNvdXJzZUNoYXIiLCJzcGxpdCIsIiRpbnN0YW5jZSIsImdsb2JhbERhdGEiLCIkYXBwbHkiLCJwYWdlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFDSTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7Ozs7Ozs7Ozs7OztJQUNxQkEsTTs7Ozs7Ozs7Ozs7Ozs7MExBQ2pCQyxJLEdBQU87QUFDSEMsb0JBQVEsQ0FETDtBQUVIQyxtQkFBTywwQkFGSjtBQUdIQyxxQkFBUztBQUNMQyxzQkFBTSxDQUREO0FBRUxDLHNCQUFNLENBQUM7QUFDSEMsd0JBQUksQ0FERDtBQUVIRiwwQkFBTSxPQUZIO0FBR0hHLHlCQUFLLEVBSEY7QUFJSEMsMEJBQU0sa0JBSkg7QUFLSEMsOEJBQVU7QUFMUCxpQkFBRDtBQUZELGFBSE47QUFhSEMsZ0NBQW1CLEVBYmhCO0FBY0hDLDhCQUFpQixFQWRkO0FBZUhDLHdCQUFXLEVBZlI7QUFnQkhDLHdCQUFZLENBaEJUO0FBaUJIQyx3QkFBWSxFQWpCVDtBQWtCSEMsdUJBQVUsRUFsQlA7QUFtQkhDLG1CQUFPLENBQUMsTUFBRCxFQUFTLE9BQVQsRUFBa0IsT0FBbEIsQ0FuQko7QUFvQkhDLGlCQUFLLENBcEJGO0FBcUJIQyxrQkFBSyxFQXJCRjtBQXNCSEMscUJBQVMsS0F0Qk47QUF1QkhDLHFCQUFTLFFBdkJOO0FBd0JIQyx1QkFBVyxDQUFDLENBeEJUO0FBeUJIQyx3QkFBWSxFQXpCVDtBQTBCSEMsd0JBQVksRUExQlQ7QUEyQkhDLDJCQUFlLEVBM0JaO0FBNEJIQyx5QkFBYTtBQUNULG1CQUFHLE9BRE07QUFFVCxtQkFBRyxNQUZNO0FBR1QsbUJBQUc7QUFITSxhQTVCVjtBQWlDSEMsdUJBQVcsS0FqQ1I7QUFrQ0hDLHFCQUFTLENBQUM7QUFDTkMsc0JBQU0sSUFEQTtBQUVOQyx1QkFBTztBQUZELGFBQUQsRUFHTjtBQUNDRCxzQkFBTSxRQURQO0FBRUNDLHVCQUFPO0FBRlIsYUFITSxFQU1OO0FBQ0NELHNCQUFNLE1BRFA7QUFFQ0MsdUJBQU87QUFGUixhQU5NO0FBbENOLFMsUUE2Q1JDLE8sR0FBVSxFLFFBQ2pCQyxNLEdBQVMsRUFBQyxXQUFVLEVBQUMsZ0JBQWUsRUFBaEIsRUFBbUIscUJBQW9CLFNBQXZDLEVBQVgsRUFBNkQsVUFBUyxFQUFDLHFCQUFvQixZQUFyQixFQUF0RSxFQUF5RyxTQUFRLEVBQUMscUJBQW9CLFlBQXJCLEVBQWtDLDBCQUF5QixZQUEzRCxFQUFqSCxFQUEwTCxXQUFVLEVBQUMscUJBQW9CLFlBQXJCLEVBQWtDLDBCQUF5QixZQUEzRCxFQUF3RSw2QkFBNEIsZUFBcEcsRUFBcE0sRSxRQUNUQyxPLEdBQVUsRSxRQUNUQyxVLEdBQWE7QUFDRkMscUNBREU7QUFFRkMsbUNBRkU7QUFHRkMsaUNBSEU7QUFJRkMscUNBSkU7QUFLRkM7QUFMRSxTLFFBT05DLE0sR0FBUztBQUNMQyxvQ0FBd0I7QUFEbkIsUyxRQXVEVEMsTyxHQUFVO0FBQ0FDLHFCQURBO0FBQUEscUdBQ1VDLENBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBDQUVFQSxFQUFFQyxNQUFGLENBQVNDLE1BQVQsSUFBbUIsZ0JBRnJCO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUEsMkNBR1FDLGVBQUtDLFdBQUwsQ0FBaUJKLEVBQUVDLE1BQW5CLENBSFI7O0FBQUE7QUFJRUksb0RBQU1DLElBQU4sQ0FBVyxXQUFYLEVBQXdCO0FBQ3BCQyxnREFBUSxLQUFLcEMsVUFETztBQUVwQnFDLDhDQUFNLHdCQUZjO0FBR3BCN0MsNENBQUksS0FBS0ksa0JBQUwsQ0FBd0JKO0FBSFIscUNBQXhCO0FBS0E4QyxtREFBS0MsVUFBTCxDQUFnQjtBQUNaOUMsNkNBQUs7QUFETyxxQ0FBaEI7O0FBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFjTitDLG1CQWRNLHFCQWNJO0FBQ04scUJBQUt2QyxTQUFMLEdBQWlCLE9BQWpCO0FBQ0gsYUFoQks7QUFpQk53Qyx1QkFqQk0seUJBaUJRO0FBQ1YscUJBQUs3QixTQUFMLEdBQWlCLElBQWpCO0FBQ0gsYUFuQks7QUFvQk44QixlQXBCTSxpQkFvQkE7QUFDRix1QkFBTyxLQUFQO0FBQ0gsYUF0Qks7QUF1Qk5DLHFCQXZCTSxxQkF1QklkLENBdkJKLEVBdUJPO0FBQ1RlLHdCQUFRQyxHQUFSLENBQVloQixDQUFaO0FBQ0EscUJBQUsxQyxNQUFMLEdBQWMwQyxFQUFFaUIsYUFBRixDQUFnQkMsT0FBaEIsQ0FBd0J2RCxFQUF4QixJQUE4QnFDLEVBQUVDLE1BQUYsQ0FBU2tCLE9BQXJEO0FBQ0gsYUExQks7QUEyQk5DLHFCQTNCTSx1QkEyQk07QUFDUixxQkFBS3JDLFNBQUwsR0FBaUIsS0FBakI7QUFDQSxxQkFBS1AsT0FBTCxHQUFlLEtBQWY7QUFDQSxxQkFBS0osU0FBTCxHQUFpQixFQUFqQjtBQUNILGFBL0JLO0FBZ0NOaUQsZUFoQ00saUJBZ0NlO0FBQUEsb0JBQWpCNUQsSUFBaUIsdUVBQVYsUUFBVTs7QUFDakIscUJBQUtlLE9BQUwsR0FBZSxJQUFmO0FBQ0EscUJBQUtPLFNBQUwsR0FBaUIsS0FBakI7QUFDQSxxQkFBS04sT0FBTCxHQUFlaEIsSUFBZjtBQUNILGFBcENLO0FBcUNONkQsZ0JBckNNLGtCQXFDQztBQUNIQyxtQkFBR0MsWUFBSDtBQUNBLHFCQUFLbEQsR0FBTCxHQUFXLEtBQUtBLEdBQUwsR0FBVyxDQUF0QjtBQUNILGFBeENLO0FBeUNObUQsaUJBekNNLG1CQXlDRTtBQUNKLG9CQUFJLEtBQUtuRCxHQUFMLEdBQVcsQ0FBZixFQUFrQjtBQUNkaUQsdUJBQUdDLFlBQUg7QUFDQSx5QkFBS2xELEdBQUwsR0FBVyxLQUFLQSxHQUFMLEdBQVcsQ0FBdEI7QUFDSDtBQUNKLGFBOUNLO0FBK0NOaUMsa0JBL0NNLGtCQStDQ21CLEdBL0NELEVBK0NNO0FBQ1IscUJBQUtoRCxTQUFMLEdBQWlCZ0QsR0FBakI7QUFDSCxhQWpESztBQWtEQUMsZUFsREE7QUFBQTtBQUFBLHdCQWtESUMsR0FsREosdUVBa0RVLENBbERWO0FBQUEsd0JBa0RhQyxFQWxEYix1RUFrRGtCLENBbERsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMENBbURFLEtBQUtuRCxTQUFMLElBQWtCLENBQUMsQ0FuRHJCO0FBQUE7QUFBQTtBQUFBOztBQW9ERW9ELG1EQUFLQyxLQUFMLENBQVcsU0FBWCxFQUFzQixlQUFPLENBQUUsQ0FBL0IsRUFBaUMsTUFBakM7QUFwREYsc0VBcURTLEtBckRUOztBQUFBO0FBdURGdEIsbURBQUtDLFVBQUwsQ0FBZ0I7QUFDWjlDLDRFQUFrQ2lFLEVBQWxDLGFBQTRDLEtBQUsxRCxVQUFMLENBQWdCNkQsVUFBaEIsQ0FBMkIsS0FBS3RELFNBQWhDLEVBQTJDZixFQUF2RixhQUFpRyxLQUFLUSxVQUFMLENBQWdCUixFQUFqSCxhQUEySCxLQUFLVyxHQUFoSSxhQUEySSxLQUFLUCxrQkFBTCxDQUF3QkosRUFBbkssZ0JBQWdMLEtBQUtRLFVBQUwsQ0FBZ0I4RDtBQURwTCxxQ0FBaEI7O0FBdkRFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUEsUzs7Ozs7O0FBcERWOzBDQUNrQkMsRyxFQUFLO0FBQ25CLGdCQUFJQSxJQUFJQyxJQUFKLEtBQWEsUUFBakIsRUFBMkI7QUFDdkI7QUFDQXBCLHdCQUFRQyxHQUFSLENBQVlrQixJQUFJRSxNQUFoQjtBQUNIO0FBQ0QsbUJBQU87QUFDSEMsdUJBQU8sS0FBS2xFLFVBQUwsQ0FBZ0JtRSxZQURwQjtBQUVIQywwQkFBUyxLQUFLcEUsVUFBTCxDQUFnQnFFLEtBRnRCO0FBR0hoQyxzQkFBTSxnQ0FBZ0MsS0FBS3pDLGtCQUFMLENBQXdCSjtBQUgzRCxhQUFQO0FBS0g7Ozs7a0dBQ1k4RSxHOzs7Ozs7Ozs7QUFDVDFCLHdDQUFRQyxHQUFSLENBQVl5QixHQUFaO0FBQ0E7QUFDSUMsb0MsR0FBT25CLEdBQUdvQixtQkFBSCxHQUF5QkMsTUFBekIsQ0FBZ0MsV0FBaEMsQzs7QUFDWEYscUNBQ0tHLE1BREwsQ0FDWTtBQUNBQywwQ0FBTTtBQUROLGlDQURaLEVBSVEsZ0JBQVE7QUFDSi9CLDRDQUFRQyxHQUFSLENBQVkzRCxLQUFLMEYsTUFBakI7QUFDQSwyQ0FBSzdFLFVBQUwsR0FBa0JiLEtBQUswRixNQUF2QjtBQUNILGlDQVBULEVBU0tDLElBVEw7O3VDQVVNN0MsZUFBSzhDLEtBQUwsRTs7Ozt1Q0FFVXJELGlCQUFPc0QsWUFBUCxDQUFvQlQsSUFBSTlFLEVBQUosSUFBVThFLElBQUlVLEtBQWxDLEM7OztBQUFaakIsbUM7NENBVUFBLElBQUk3RSxJLEVBUkprRCxNLGFBQUFBLE0sRUFDQTVCLFUsYUFBQUEsVSxFQUNBQyxVLGFBQUFBLFUsRUFDQUMsYSxhQUFBQSxhLEVBQ0FkLGtCLGFBQUFBLGtCLEVBQ0FFLFUsYUFBQUEsVSxFQUNBRCxnQixhQUFBQSxnQixFQUNBTyxJLGFBQUFBLEk7O0FBRUoscUNBQUtmLE9BQUwsQ0FBYUUsSUFBYixDQUFrQixDQUFsQixFQUFxQkUsR0FBckIsR0FBMkIyQyxPQUFPaUMsS0FBbEM7QUFDQWpDLHVDQUFPNkMsVUFBUCxHQUFvQjdDLE9BQU82QyxVQUFQLENBQWtCQyxLQUFsQixDQUF3QixHQUF4QixDQUFwQjtBQUNBLHFDQUFLbEYsVUFBTCxHQUFrQm9DLE1BQWxCO0FBQ0FFLCtDQUFLNkMsU0FBTCxDQUFlQyxVQUFmLENBQTBCcEYsVUFBMUIsR0FBdUNvQyxNQUF2QztBQUNBLHFDQUFLNUIsVUFBTCxHQUFrQkEsVUFBbEI7QUFDQSxxQ0FBS0MsVUFBTCxHQUFrQkEsVUFBbEI7QUFDQSxxQ0FBS0MsYUFBTCxHQUFxQkEsYUFBckI7QUFDQSxxQ0FBS2Qsa0JBQUwsR0FBMEJBLGtCQUExQjtBQUNBLHFDQUFLRSxVQUFMLEdBQWtCQSxVQUFsQjtBQUNBLHFDQUFLRCxnQkFBTCxHQUF3QkEsZ0JBQXhCO0FBQ0EscUNBQUtPLElBQUwsR0FBWUEsSUFBWjtBQUNBLHFDQUFLaUYsTUFBTDs7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQTdHNEIvQyxlQUFLZ0QsSTs7a0JBQXBCckcsTSIsImZpbGUiOiJwaW50dWFuLmpzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbiAgICBpbXBvcnQgd2VweSBmcm9tIFwid2VweVwiO1xyXG4gICAgaW1wb3J0IGNTd2lwZXIgZnJvbSBcIkAvY29tcG9uZW50cy9jb21tb24vc3dpcGVyXCI7XHJcbiAgICBpbXBvcnQgY3RpdGxlIGZyb20gXCJAL2NvbXBvbmVudHMvZGV0YWlsZS90aXRsZVwiO1xyXG4gICAgaW1wb3J0IGNJbmZvIGZyb20gXCJAL2NvbXBvbmVudHMvZGV0YWlsZS9pbmZvXCI7XHJcbiAgICBpbXBvcnQgY1JlbWFrZSBmcm9tIFwiQC9jb21wb25lbnRzL2RldGFpbGUvcmVtYWtlXCI7XHJcbiAgICBpbXBvcnQgY29udGFjdCBmcm9tIFwiQC9jb21wb25lbnRzL2NvbW1vbi9jb250YWN0XCJcclxuICAgIGltcG9ydCBjb25maWcgZnJvbSBcIkAvYXBpL2NvbmZpZ1wiO1xyXG4gICAgaW1wb3J0IGF1dGggZnJvbSBcIkAvYXBpL2F1dGhcIjtcclxuICAgIGltcG9ydCBXeFV0aWxzIGZyb20gXCJAL3V0aWxzL1d4VXRpbHNcIjtcclxuICAgIGltcG9ydCBUaXBzIGZyb20gXCJAL3V0aWxzL1RpcHNcIjtcclxuICAgIGltcG9ydCBzdG9yZSBmcm9tIFwiQC9zdG9yZS91dGlsc1wiXHJcbiAgICBleHBvcnQgZGVmYXVsdCBjbGFzcyBEaWFsb2cgZXh0ZW5kcyB3ZXB5LnBhZ2Uge1xyXG4gICAgICAgIGRhdGEgPSB7XHJcbiAgICAgICAgICAgIFRhYkN1cjogMCxcclxuICAgICAgICAgICAgY2xvc2U6IFwiL3N0YXRpYy9pbWFnZXMvY2xvc2UucG5nXCIsXHJcbiAgICAgICAgICAgIHN3aXBlcnM6IHtcclxuICAgICAgICAgICAgICAgIHR5cGU6IDEsXHJcbiAgICAgICAgICAgICAgICBsaXN0OiBbe1xyXG4gICAgICAgICAgICAgICAgICAgIGlkOiAwLFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU6IFwiaW1hZ2VcIixcclxuICAgICAgICAgICAgICAgICAgICB1cmw6IFwiXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgbGluazogXCIvcGFnZXMvbWVldC9tZWV0XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgbGlua1R5cGU6IFwic3dpdGNoVGFiXCJcclxuICAgICAgICAgICAgICAgIH1dXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGFjdFBpbnR1YW5BY3Rpdml0eTp7fSxcclxuICAgICAgICAgICAgQWN0UGludHVhbk1lbWJlcjp7fSxcclxuICAgICAgICAgICAgQWN0UGludHVhbjp7fSxcclxuICAgICAgICAgICAgbWFpbkhlaWdodDogMCxcclxuICAgICAgICAgICAgY291cnNlSW5mbzoge30sXHJcbiAgICAgICAgICAgIG1vZGFsTmFtZTonJyxcclxuICAgICAgICAgICAgbm9kZXM6IFtcIm5hbWVcIiwgXCJhdHRyc1wiLCBcImF0dHJzXCJdLFxyXG4gICAgICAgICAgICBudW06IDEsXHJcbiAgICAgICAgICAgIGlzSW46JycsXHJcbiAgICAgICAgICAgIHNob3dTa3U6IGZhbHNlLFxyXG4gICAgICAgICAgICBidXlUeXB0OiAnbm9ybWFsJyxcclxuICAgICAgICAgICAgY291cnNlSW54OiAtMSxcclxuICAgICAgICAgICAgY29tcGFuaW9uczogW10sXHJcbiAgICAgICAgICAgIHN0YXRpc3RpY3M6IHt9LFxyXG4gICAgICAgICAgICBDb3Vyc2VDb21tZW50OiB7fSxcclxuICAgICAgICAgICAgc2lnbl9zdGF0ZXM6IHtcclxuICAgICAgICAgICAgICAgIDA6ICfngavng63mi5vnlJ/kuK0nLFxyXG4gICAgICAgICAgICAgICAgMTogJ+WwkemHj+WQjeminScsXHJcbiAgICAgICAgICAgICAgICAyOiAn5bey5ruh5ZGYJ1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB0b1BpbnR1YW46IGZhbHNlLFxyXG4gICAgICAgICAgICBudW1MaXN0OiBbe1xyXG4gICAgICAgICAgICAgICAgbmFtZTogJ+WPguWboicsXHJcbiAgICAgICAgICAgICAgICBuYW1lMTogJ+aUr+S7mOWujOaIkCdcclxuICAgICAgICAgICAgfSwge1xyXG4gICAgICAgICAgICAgICAgbmFtZTogJ+iOt+W+l+abtOWkmuS8mOaDoCcsXHJcbiAgICAgICAgICAgICAgICBuYW1lMTogJ+WIhuS6q+a0u+WKqCdcclxuICAgICAgICAgICAgfSwge1xyXG4gICAgICAgICAgICAgICAgbmFtZTogJ+aLvOWbouaIkOWKnycsXHJcbiAgICAgICAgICAgICAgICBuYW1lMTogJ+iAgeW4iOS4u+WKqOiBlOezu+aCqCdcclxuICAgICAgICAgICAgfV1cclxuICAgICAgICB9O1xyXG4gICAgICAgJHJlcGVhdCA9IHt9O1xyXG4kcHJvcHMgPSB7XCJjU3dpcGVyXCI6e1wieG1sbnM6di1iaW5kXCI6XCJcIixcInYtYmluZDptb2RlbC5zeW5jXCI6XCJzd2lwZXJzXCJ9LFwiY3RpdGxlXCI6e1widi1iaW5kOm1vZGVsLnN5bmNcIjpcImNvdXJzZUluZm9cIn0sXCJjSW5mb1wiOntcInYtYmluZDptb2RlbC5zeW5jXCI6XCJjb3Vyc2VJbmZvXCIsXCJ2LWJpbmQ6Y29tcGFuaW9ucy5zeW5jXCI6XCJjb21wYW5pb25zXCJ9LFwiY1JlbWFrZVwiOntcInYtYmluZDptb2RlbC5zeW5jXCI6XCJjb3Vyc2VJbmZvXCIsXCJ2LWJpbmQ6c3RhdGlzdGljcy5zeW5jXCI6XCJzdGF0aXN0aWNzXCIsXCJ2LWJpbmQ6Q291cnNlQ29tbWVudC5zeW5jXCI6XCJDb3Vyc2VDb21tZW50XCJ9fTtcclxuJGV2ZW50cyA9IHt9O1xyXG4gY29tcG9uZW50cyA9IHtcclxuICAgICAgICAgICAgY1N3aXBlcixcclxuICAgICAgICAgICAgY3RpdGxlLFxyXG4gICAgICAgICAgICBjSW5mbyxcclxuICAgICAgICAgICAgY1JlbWFrZSxcclxuICAgICAgICAgICAgY29udGFjdFxyXG4gICAgICAgIH07XHJcbiAgICAgICAgY29uZmlnID0ge1xyXG4gICAgICAgICAgICBuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0OiBcIua0u+WKqOivpuaDhVwiXHJcbiAgICAgICAgfTtcclxuICAgICAgICAvLyDovazlj5HmmoLml7blhYjkuI3lvIDlkK9cclxuICAgICAgICBvblNoYXJlQXBwTWVzc2FnZShyZXMpIHtcclxuICAgICAgICAgICAgaWYgKHJlcy5mcm9tID09PSAnYnV0dG9uJykge1xyXG4gICAgICAgICAgICAgICAgLy8g5p2l6Ieq6aG16Z2i5YaF6L2s5Y+R5oyJ6ZKuXHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhyZXMudGFyZ2V0KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICB0aXRsZTogdGhpcy5jb3Vyc2VJbmZvLmNvdXJzZVRpdHRsZSxcclxuICAgICAgICAgICAgICAgIGltYWdlVXJsOnRoaXMuY291cnNlSW5mby5pbWFnZSxcclxuICAgICAgICAgICAgICAgIHBhdGg6ICcvcGFnZXMvYWN0aXZpdHkvcGludHVhbj9pZD0nICsgdGhpcy5hY3RQaW50dWFuQWN0aXZpdHkuaWRcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBhc3luYyBvbkxvYWQob3B0KSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKG9wdClcclxuICAgICAgICAgICAgLy8g6I635Y+W5Li75YaF5a656auY5bqm77yM55So5LqO5oKs5rWu6K+m5oOF5a+86IiqXHJcbiAgICAgICAgICAgIGxldCB2aWV3ID0gd3guY3JlYXRlU2VsZWN0b3JRdWVyeSgpLnNlbGVjdChcIiNpbmZvLWJveFwiKTtcclxuICAgICAgICAgICAgdmlld1xyXG4gICAgICAgICAgICAgICAgLmZpZWxkcyh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNpemU6IHRydWVcclxuICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGEgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhkYXRhLmhlaWdodCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubWFpbkhlaWdodCA9IGRhdGEuaGVpZ2h0O1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgIC5leGVjKCk7XHJcbiAgICAgICAgICAgIGF3YWl0IGF1dGgubG9naW4oKVxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGNvbmZpZy5waW50dWFuRGV0YWkob3B0LmlkIHx8IG9wdC5zY2VuZSlcclxuICAgICAgICAgICAgbGV0IHtcclxuICAgICAgICAgICAgICAgIGNvdXJzZSxcclxuICAgICAgICAgICAgICAgIGNvbXBhbmlvbnMsXHJcbiAgICAgICAgICAgICAgICBzdGF0aXN0aWNzLFxyXG4gICAgICAgICAgICAgICAgQ291cnNlQ29tbWVudCxcclxuICAgICAgICAgICAgICAgIGFjdFBpbnR1YW5BY3Rpdml0eSxcclxuICAgICAgICAgICAgICAgIEFjdFBpbnR1YW4sXHJcbiAgICAgICAgICAgICAgICBBY3RQaW50dWFuTWVtYmVyLFxyXG4gICAgICAgICAgICAgICAgaXNJblxyXG4gICAgICAgICAgICB9ID0gcmVzLmRhdGFcclxuICAgICAgICAgICAgdGhpcy5zd2lwZXJzLmxpc3RbMF0udXJsID0gY291cnNlLmltYWdlXHJcbiAgICAgICAgICAgIGNvdXJzZS5jb3Vyc2VDaGFyID0gY291cnNlLmNvdXJzZUNoYXIuc3BsaXQoXCJ8XCIpXHJcbiAgICAgICAgICAgIHRoaXMuY291cnNlSW5mbyA9IGNvdXJzZVxyXG4gICAgICAgICAgICB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLmNvdXJzZUluZm8gPSBjb3Vyc2VcclxuICAgICAgICAgICAgdGhpcy5jb21wYW5pb25zID0gY29tcGFuaW9uc1xyXG4gICAgICAgICAgICB0aGlzLnN0YXRpc3RpY3MgPSBzdGF0aXN0aWNzXHJcbiAgICAgICAgICAgIHRoaXMuQ291cnNlQ29tbWVudCA9IENvdXJzZUNvbW1lbnRcclxuICAgICAgICAgICAgdGhpcy5hY3RQaW50dWFuQWN0aXZpdHkgPSBhY3RQaW50dWFuQWN0aXZpdHlcclxuICAgICAgICAgICAgdGhpcy5BY3RQaW50dWFuID0gQWN0UGludHVhblxyXG4gICAgICAgICAgICB0aGlzLkFjdFBpbnR1YW5NZW1iZXIgPSBBY3RQaW50dWFuTWVtYmVyXHJcbiAgICAgICAgICAgIHRoaXMuaXNJbiA9IGlzSW5cclxuICAgICAgICAgICAgdGhpcy4kYXBwbHkoKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgbWV0aG9kcyA9IHtcclxuICAgICAgICAgICAgYXN5bmMgY3JlYXRlSW1nKGUpIHtcclxuICAgICAgICAgICAgICAgIGlmIChlLmRldGFpbC5lcnJNc2cgPT0gXCJnZXRVc2VySW5mbzpva1wiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYXdhaXQgYXV0aC5nZXRVc2VyaW5mbyhlLmRldGFpbClcclxuICAgICAgICAgICAgICAgICAgICBzdG9yZS5zYXZlKCdzaGFyZUluZm8nLCB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvdXJzZTogdGhpcy5jb3Vyc2VJbmZvLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYXRoOiAncGFnZXMvYWN0aXZpdHkvcGludHVhbicsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkOiB0aGlzLmFjdFBpbnR1YW5BY3Rpdml0eS5pZFxyXG4gICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgd2VweS5uYXZpZ2F0ZVRvKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdXJsOiAnL3BhZ2VzL2hvbWUvc2hhcmUnXHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHRvc2hhcmUoKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGFsTmFtZSA9ICdzaGFyZSdcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgdG9QaW50dWFuZnkoKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnRvUGludHVhbiA9IHRydWVcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgcmV0KCkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHRhYlNlbGVjdChlKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuVGFiQ3VyID0gZS5jdXJyZW50VGFyZ2V0LmRhdGFzZXQuaWQgfHwgZS5kZXRhaWwuY3VycmVudDtcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgaGlkZU1vZGFsKCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy50b1BpbnR1YW4gPSBmYWxzZVxyXG4gICAgICAgICAgICAgICAgdGhpcy5zaG93U2t1ID0gZmFsc2VcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kYWxOYW1lID0gJydcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgc2t1KHR5cGUgPSAnbm9ybWFsJykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zaG93U2t1ID0gdHJ1ZVxyXG4gICAgICAgICAgICAgICAgdGhpcy50b1BpbnR1YW4gPSBmYWxzZVxyXG4gICAgICAgICAgICAgICAgdGhpcy5idXlUeXB0ID0gdHlwZVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBwbHVzKCkge1xyXG4gICAgICAgICAgICAgICAgd3gudmlicmF0ZVNob3J0KClcclxuICAgICAgICAgICAgICAgIHRoaXMubnVtID0gdGhpcy5udW0gKyAxXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIG1pbnVzKCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMubnVtID4gMSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHd4LnZpYnJhdGVTaG9ydCgpXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5udW0gPSB0aGlzLm51bSAtIDFcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgY291cnNlKGlueCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jb3Vyc2VJbnggPSBpbnhcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgYXN5bmMgYnV5KGFpZCA9IDAsIG90ID0gMSwgKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5jb3Vyc2VJbnggPT0gLTEpIHtcclxuICAgICAgICAgICAgICAgICAgICBUaXBzLnRvYXN0KFwi6K+36YCJ5oup5LiA5Liq6JCl5pyfXCIsIHJlcyA9PiB7fSwgJ25vbmUnKVxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgd2VweS5uYXZpZ2F0ZVRvKHtcclxuICAgICAgICAgICAgICAgICAgICB1cmw6IGAuLi9kZXRhaWxlL3N1cmVPcmRlcj90eXBlPSR7b3R9JnBpZD0ke3RoaXMuY291cnNlSW5mby5wZXJpb2RMaXN0W3RoaXMuY291cnNlSW54XS5pZH0mY2lkPSR7dGhpcy5jb3Vyc2VJbmZvLmlkfSZudW09JHt0aGlzLm51bX0mYWlkPSR7dGhpcy5hY3RQaW50dWFuQWN0aXZpdHkuaWR9JmFjdHBpZD0ke3RoaXMuY291cnNlSW5mby5waW50dWFuSWR9YFxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9O1xyXG4gICAgfVxyXG4iXX0=