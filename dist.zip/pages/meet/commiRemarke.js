"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
    _inherits(Dialog, _wepy$page);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
            navigationBarTitleText: "写评论"
        }, _this.data = {
            orderInfo: {},
            imgList: [],
            favor: 5,
            remark: '',
            imgloaded: [],
            imgloading: false,
            tags: {},
            tagsed: {}
        }, _this.methods = {
            setTag: function setTag(id) {
                if (this.tagsed[id]) {
                    delete this.tagsed[id];
                } else {
                    this.tagsed[id] = id;
                }
            },
            favor: function favor(inx) {
                this.favor = inx + 1;
            },
            ChooseImage: function ChooseImage() {
                var _this2 = this;

                wx.chooseImage({
                    count: 1, //默认9
                    sizeType: ['compressed'], //可以指定是原图还是压缩图，默认二者都有
                    sourceType: ['album', 'camera'], //从相册选择
                    success: function success(res) {
                        if (_this2.imgList.length != 0) {
                            _this2.imgList = _this2.imgList.concat(res.tempFilePaths);
                        } else {
                            _this2.imgList = res.tempFilePaths;
                        }
                        _this2.$apply();
                    }
                });
            },
            DelImg: function DelImg(e) {
                this.imgList.splice(e.currentTarget.dataset.index, 1);
            },
            textareaBInput: function textareaBInput(e) {
                this.remark = e.detail.value;
            },
            commit: function () {
                var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
                    var images, tags, params, res;
                    return regeneratorRuntime.wrap(function _callee$(_context) {
                        while (1) {
                            switch (_context.prev = _context.next) {
                                case 0:
                                    this.imgloading = true;
                                    _context.next = 3;
                                    return this.upImg();

                                case 3:
                                    images = _context.sent;

                                    this.imgloading = false;
                                    tags = this.getTags(this.tagsed);
                                    params = {
                                        grade: this.favor,
                                        content: this.remark,
                                        // content: encodeURIComponent(this.remark),
                                        images: images,
                                        tag: tags.join(','),
                                        orderSn: this.orderInfo.orderSn,
                                        courseId: this.orderInfo.courseId
                                    };
                                    _context.next = 9;
                                    return _config2.default.savecommen(params);

                                case 9:
                                    res = _context.sent;

                                    if (res.errcode == 200) {
                                        _Tips2.default.toast("评论成功", function (res) {
                                            _wepy2.default.navigateBack({
                                                delta: 1 //返回的页面数，如果 delta 大于现有页面数，则返回到首页,
                                            });
                                        });
                                    }

                                case 11:
                                case "end":
                                    return _context.stop();
                            }
                        }
                    }, _callee, this);
                }));

                function commit() {
                    return _ref2.apply(this, arguments);
                }

                return commit;
            }()
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(Dialog, [{
        key: "loadData",
        value: function () {
            var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(id) {
                var res;
                return regeneratorRuntime.wrap(function _callee2$(_context2) {
                    while (1) {
                        switch (_context2.prev = _context2.next) {
                            case 0:
                                _context2.next = 2;
                                return _config2.default.orderdetail(id);

                            case 2:
                                res = _context2.sent;

                                this.orderInfo = res.data.detail;
                                this.$apply();

                            case 5:
                            case "end":
                                return _context2.stop();
                        }
                    }
                }, _callee2, this);
            }));

            function loadData(_x) {
                return _ref3.apply(this, arguments);
            }

            return loadData;
        }()
    }, {
        key: "onLoad",
        value: function () {
            var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(opt) {
                return regeneratorRuntime.wrap(function _callee3$(_context3) {
                    while (1) {
                        switch (_context3.prev = _context3.next) {
                            case 0:
                                this.id = opt.id;
                                _context3.next = 3;
                                return this.loadData(opt.id);

                            case 3:
                                _context3.next = 5;
                                return _config2.default.commentTag();

                            case 5:
                                this.tags = _context3.sent;

                                // console.log(tags)
                                this.$apply();

                            case 7:
                            case "end":
                                return _context3.stop();
                        }
                    }
                }, _callee3, this);
            }));

            function onLoad(_x2) {
                return _ref4.apply(this, arguments);
            }

            return onLoad;
        }()
    }, {
        key: "getTags",
        value: function getTags(obj) {
            var arr = [];
            for (var i in obj) {
                arr.push(i);
            }
            return arr;
        }
    }, {
        key: "upImg",
        value: function upImg() {
            var promisess = [];
            this.imgList.forEach(function (e, i) {
                var _promise = new Promise(function (rs, rj) {
                    _config2.default.uploadFile(e).then(function (_res) {
                        rs(_res);
                    }).catch(function (err) {
                        rj('上传失败了');
                    });
                    // setTimeout(() => {
                    //     this.imgloaded.push(e)
                    //     rs(e)
                    // }, 2000)
                });
                promisess.push(_promise);
            });
            return Promise.all(promisess).then(function (res) {
                return res;
            }).catch(function (err) {
                return false;
            });
        }
    }]);

    return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/meet/commiRemarke'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbW1pUmVtYXJrZS5qcyJdLCJuYW1lcyI6WyJEaWFsb2ciLCJjb25maWciLCJuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0IiwiZGF0YSIsIm9yZGVySW5mbyIsImltZ0xpc3QiLCJmYXZvciIsInJlbWFyayIsImltZ2xvYWRlZCIsImltZ2xvYWRpbmciLCJ0YWdzIiwidGFnc2VkIiwibWV0aG9kcyIsInNldFRhZyIsImlkIiwiaW54IiwiQ2hvb3NlSW1hZ2UiLCJ3eCIsImNob29zZUltYWdlIiwiY291bnQiLCJzaXplVHlwZSIsInNvdXJjZVR5cGUiLCJzdWNjZXNzIiwicmVzIiwibGVuZ3RoIiwiY29uY2F0IiwidGVtcEZpbGVQYXRocyIsIiRhcHBseSIsIkRlbEltZyIsImUiLCJzcGxpY2UiLCJjdXJyZW50VGFyZ2V0IiwiZGF0YXNldCIsImluZGV4IiwidGV4dGFyZWFCSW5wdXQiLCJkZXRhaWwiLCJ2YWx1ZSIsImNvbW1pdCIsInVwSW1nIiwiaW1hZ2VzIiwiZ2V0VGFncyIsInBhcmFtcyIsImdyYWRlIiwiY29udGVudCIsInRhZyIsImpvaW4iLCJvcmRlclNuIiwiY291cnNlSWQiLCJzYXZlY29tbWVuIiwiZXJyY29kZSIsIlRpcHMiLCJ0b2FzdCIsIndlcHkiLCJuYXZpZ2F0ZUJhY2siLCJkZWx0YSIsIm9yZGVyZGV0YWlsIiwib3B0IiwibG9hZERhdGEiLCJjb21tZW50VGFnIiwib2JqIiwiYXJyIiwiaSIsInB1c2giLCJwcm9taXNlc3MiLCJmb3JFYWNoIiwiX3Byb21pc2UiLCJQcm9taXNlIiwicnMiLCJyaiIsInVwbG9hZEZpbGUiLCJ0aGVuIiwiX3JlcyIsImNhdGNoIiwiYWxsIiwicGFnZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQ0k7Ozs7QUFDQTs7OztBQUNBOzs7Ozs7Ozs7Ozs7OztJQUNxQkEsTTs7Ozs7Ozs7Ozs7Ozs7MExBQ2pCQyxNLEdBQVM7QUFDTEMsb0NBQXdCO0FBRG5CLFMsUUFHVEMsSSxHQUFPO0FBQ0hDLHVCQUFXLEVBRFI7QUFFSEMscUJBQVMsRUFGTjtBQUdIQyxtQkFBTyxDQUhKO0FBSUhDLG9CQUFRLEVBSkw7QUFLSEMsdUJBQVcsRUFMUjtBQU1IQyx3QkFBWSxLQU5UO0FBT0hDLGtCQUFNLEVBUEg7QUFRSEMsb0JBQVE7QUFSTCxTLFFBc0JQQyxPLEdBQVU7QUFDTkMsa0JBRE0sa0JBQ0NDLEVBREQsRUFDSztBQUNQLG9CQUFJLEtBQUtILE1BQUwsQ0FBWUcsRUFBWixDQUFKLEVBQXFCO0FBQ2pCLDJCQUFPLEtBQUtILE1BQUwsQ0FBWUcsRUFBWixDQUFQO0FBQ0gsaUJBRkQsTUFFTztBQUNILHlCQUFLSCxNQUFMLENBQVlHLEVBQVosSUFBa0JBLEVBQWxCO0FBQ0g7QUFDSixhQVBLO0FBUU5SLGlCQVJNLGlCQVFBUyxHQVJBLEVBUUs7QUFDUCxxQkFBS1QsS0FBTCxHQUFhUyxNQUFNLENBQW5CO0FBQ0gsYUFWSztBQVdOQyx1QkFYTSx5QkFXUTtBQUFBOztBQUNWQyxtQkFBR0MsV0FBSCxDQUFlO0FBQ1hDLDJCQUFPLENBREksRUFDRDtBQUNWQyw4QkFBVSxDQUFDLFlBQUQsQ0FGQyxFQUVlO0FBQzFCQyxnQ0FBWSxDQUFDLE9BQUQsRUFBVSxRQUFWLENBSEQsRUFHc0I7QUFDakNDLDZCQUFTLGlCQUFDQyxHQUFELEVBQVM7QUFDZCw0QkFBSSxPQUFLbEIsT0FBTCxDQUFhbUIsTUFBYixJQUF1QixDQUEzQixFQUE4QjtBQUMxQixtQ0FBS25CLE9BQUwsR0FBZSxPQUFLQSxPQUFMLENBQWFvQixNQUFiLENBQW9CRixJQUFJRyxhQUF4QixDQUFmO0FBQ0gseUJBRkQsTUFFTztBQUNILG1DQUFLckIsT0FBTCxHQUFla0IsSUFBSUcsYUFBbkI7QUFDSDtBQUNELCtCQUFLQyxNQUFMO0FBQ0g7QUFYVSxpQkFBZjtBQWFILGFBekJLO0FBMEJOQyxrQkExQk0sa0JBMEJDQyxDQTFCRCxFQTBCSTtBQUNOLHFCQUFLeEIsT0FBTCxDQUFheUIsTUFBYixDQUFvQkQsRUFBRUUsYUFBRixDQUFnQkMsT0FBaEIsQ0FBd0JDLEtBQTVDLEVBQW1ELENBQW5EO0FBQ0gsYUE1Qks7QUE2Qk5DLDBCQTdCTSwwQkE2QlNMLENBN0JULEVBNkJZO0FBQ2QscUJBQUt0QixNQUFMLEdBQWNzQixFQUFFTSxNQUFGLENBQVNDLEtBQXZCO0FBQ0gsYUEvQks7QUFnQ0FDLGtCQWhDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQWlDRix5Q0FBSzVCLFVBQUwsR0FBa0IsSUFBbEI7QUFqQ0U7QUFBQSwyQ0FrQ2lCLEtBQUs2QixLQUFMLEVBbENqQjs7QUFBQTtBQWtDRUMsMENBbENGOztBQW1DRix5Q0FBSzlCLFVBQUwsR0FBa0IsS0FBbEI7QUFDSUMsd0NBcENGLEdBb0NTLEtBQUs4QixPQUFMLENBQWEsS0FBSzdCLE1BQWxCLENBcENUO0FBcUNFOEIsMENBckNGLEdBcUNXO0FBQ1RDLCtDQUFPLEtBQUtwQyxLQURIO0FBRVRxQyxpREFBUyxLQUFLcEMsTUFGTDtBQUdUO0FBQ0FnQyxzREFKUztBQUtUSyw2Q0FBS2xDLEtBQUttQyxJQUFMLENBQVUsR0FBVixDQUxJO0FBTVRDLGlEQUFTLEtBQUsxQyxTQUFMLENBQWUwQyxPQU5mO0FBT1RDLGtEQUFVLEtBQUszQyxTQUFMLENBQWUyQztBQVBoQixxQ0FyQ1g7QUFBQTtBQUFBLDJDQThDYzlDLGlCQUFPK0MsVUFBUCxDQUFrQlAsTUFBbEIsQ0E5Q2Q7O0FBQUE7QUE4Q0VsQix1Q0E5Q0Y7O0FBK0NGLHdDQUFJQSxJQUFJMEIsT0FBSixJQUFlLEdBQW5CLEVBQXdCO0FBQ3BCQyx1REFBS0MsS0FBTCxDQUFXLE1BQVgsRUFBbUIsZUFBTztBQUN0QkMsMkRBQUtDLFlBQUwsQ0FBa0I7QUFDZEMsdURBQU8sQ0FETyxDQUNMO0FBREssNkNBQWxCO0FBR0gseUNBSkQ7QUFLSDs7QUFyREM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQSxTOzs7Ozs7a0dBWkt4QyxFOzs7Ozs7O3VDQUNLYixpQkFBT3NELFdBQVAsQ0FBbUJ6QyxFQUFuQixDOzs7QUFBWlMsbUM7O0FBQ0oscUNBQUtuQixTQUFMLEdBQWlCbUIsSUFBSXBCLElBQUosQ0FBU2dDLE1BQTFCO0FBQ0EscUNBQUtSLE1BQUw7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7a0dBRVM2QixHOzs7OztBQUNULHFDQUFLMUMsRUFBTCxHQUFVMEMsSUFBSTFDLEVBQWQ7O3VDQUNNLEtBQUsyQyxRQUFMLENBQWNELElBQUkxQyxFQUFsQixDOzs7O3VDQUNZYixpQkFBT3lELFVBQVAsRTs7O0FBQWxCLHFDQUFLaEQsSTs7QUFDTDtBQUNBLHFDQUFLaUIsTUFBTDs7Ozs7Ozs7Ozs7Ozs7Ozs7O2dDQTBESWdDLEcsRUFBSztBQUNULGdCQUFJQyxNQUFNLEVBQVY7QUFDQSxpQkFBSyxJQUFJQyxDQUFULElBQWNGLEdBQWQsRUFBbUI7QUFDZkMsb0JBQUlFLElBQUosQ0FBU0QsQ0FBVDtBQUNIO0FBQ0QsbUJBQU9ELEdBQVA7QUFDSDs7O2dDQUNPO0FBQ0osZ0JBQUlHLFlBQVksRUFBaEI7QUFDQSxpQkFBSzFELE9BQUwsQ0FBYTJELE9BQWIsQ0FBcUIsVUFBQ25DLENBQUQsRUFBSWdDLENBQUosRUFBVTtBQUMzQixvQkFBSUksV0FBVyxJQUFJQyxPQUFKLENBQVksVUFBQ0MsRUFBRCxFQUFLQyxFQUFMLEVBQVk7QUFDbkNuRSxxQ0FBT29FLFVBQVAsQ0FBa0J4QyxDQUFsQixFQUFxQnlDLElBQXJCLENBQTBCLGdCQUFRO0FBQzlCSCwyQkFBR0ksSUFBSDtBQUNILHFCQUZELEVBRUdDLEtBRkgsQ0FFUyxlQUFPO0FBQ1pKLDJCQUFHLE9BQUg7QUFDSCxxQkFKRDtBQUtBO0FBQ0E7QUFDQTtBQUNBO0FBQ0gsaUJBVmMsQ0FBZjtBQVdBTCwwQkFBVUQsSUFBVixDQUFlRyxRQUFmO0FBQ0gsYUFiRDtBQWNBLG1CQUFPQyxRQUFRTyxHQUFSLENBQVlWLFNBQVosRUFBdUJPLElBQXZCLENBQTRCLGVBQU87QUFDdEMsdUJBQU8vQyxHQUFQO0FBQ0gsYUFGTSxFQUVKaUQsS0FGSSxDQUVFLGVBQU87QUFDWix1QkFBTyxLQUFQO0FBQ0gsYUFKTSxDQUFQO0FBS0g7Ozs7RUE5RytCcEIsZUFBS3NCLEk7O2tCQUFwQjFFLE0iLCJmaWxlIjoiY29tbWlSZW1hcmtlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbiAgICBpbXBvcnQgd2VweSBmcm9tIFwid2VweVwiO1xyXG4gICAgaW1wb3J0IGNvbmZpZyBmcm9tIFwiQC9hcGkvY29uZmlnXCJcclxuICAgIGltcG9ydCBUaXBzIGZyb20gXCJAL3V0aWxzL1RpcHNcIlxyXG4gICAgZXhwb3J0IGRlZmF1bHQgY2xhc3MgRGlhbG9nIGV4dGVuZHMgd2VweS5wYWdlIHtcclxuICAgICAgICBjb25maWcgPSB7XHJcbiAgICAgICAgICAgIG5hdmlnYXRpb25CYXJUaXRsZVRleHQ6IFwi5YaZ6K+E6K66XCJcclxuICAgICAgICB9O1xyXG4gICAgICAgIGRhdGEgPSB7XHJcbiAgICAgICAgICAgIG9yZGVySW5mbzoge30sXHJcbiAgICAgICAgICAgIGltZ0xpc3Q6IFtdLFxyXG4gICAgICAgICAgICBmYXZvcjogNSxcclxuICAgICAgICAgICAgcmVtYXJrOiAnJyxcclxuICAgICAgICAgICAgaW1nbG9hZGVkOiBbXSxcclxuICAgICAgICAgICAgaW1nbG9hZGluZzogZmFsc2UsXHJcbiAgICAgICAgICAgIHRhZ3M6IHt9LFxyXG4gICAgICAgICAgICB0YWdzZWQ6IHt9XHJcbiAgICAgICAgfTtcclxuICAgICAgICBhc3luYyBsb2FkRGF0YShpZCkge1xyXG4gICAgICAgICAgICBsZXQgcmVzID0gYXdhaXQgY29uZmlnLm9yZGVyZGV0YWlsKGlkKVxyXG4gICAgICAgICAgICB0aGlzLm9yZGVySW5mbyA9IHJlcy5kYXRhLmRldGFpbFxyXG4gICAgICAgICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGFzeW5jIG9uTG9hZChvcHQpIHtcclxuICAgICAgICAgICAgdGhpcy5pZCA9IG9wdC5pZFxyXG4gICAgICAgICAgICBhd2FpdCB0aGlzLmxvYWREYXRhKG9wdC5pZClcclxuICAgICAgICAgICAgdGhpcy50YWdzID0gYXdhaXQgY29uZmlnLmNvbW1lbnRUYWcoKVxyXG4gICAgICAgICAgICAvLyBjb25zb2xlLmxvZyh0YWdzKVxyXG4gICAgICAgICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICAgICAgfVxyXG4gICAgICAgIG1ldGhvZHMgPSB7XHJcbiAgICAgICAgICAgIHNldFRhZyhpZCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMudGFnc2VkW2lkXSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGRlbGV0ZSB0aGlzLnRhZ3NlZFtpZF1cclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy50YWdzZWRbaWRdID0gaWRcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgZmF2b3IoaW54KSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmZhdm9yID0gaW54ICsgMVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBDaG9vc2VJbWFnZSgpIHtcclxuICAgICAgICAgICAgICAgIHd4LmNob29zZUltYWdlKHtcclxuICAgICAgICAgICAgICAgICAgICBjb3VudDogMSwgLy/pu5jorqQ5XHJcbiAgICAgICAgICAgICAgICAgICAgc2l6ZVR5cGU6IFsnY29tcHJlc3NlZCddLCAvL+WPr+S7peaMh+WumuaYr+WOn+Wbvui/mOaYr+WOi+e8qeWbvu+8jOm7mOiupOS6jOiAhemDveaciVxyXG4gICAgICAgICAgICAgICAgICAgIHNvdXJjZVR5cGU6IFsnYWxidW0nLCAnY2FtZXJhJ10sIC8v5LuO55u45YaM6YCJ5oupXHJcbiAgICAgICAgICAgICAgICAgICAgc3VjY2VzczogKHJlcykgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5pbWdMaXN0Lmxlbmd0aCAhPSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmltZ0xpc3QgPSB0aGlzLmltZ0xpc3QuY29uY2F0KHJlcy50ZW1wRmlsZVBhdGhzKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5pbWdMaXN0ID0gcmVzLnRlbXBGaWxlUGF0aHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIERlbEltZyhlKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmltZ0xpc3Quc3BsaWNlKGUuY3VycmVudFRhcmdldC5kYXRhc2V0LmluZGV4LCAxKTtcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgdGV4dGFyZWFCSW5wdXQoZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5yZW1hcmsgPSBlLmRldGFpbC52YWx1ZVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBhc3luYyBjb21taXQoKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmltZ2xvYWRpbmcgPSB0cnVlXHJcbiAgICAgICAgICAgICAgICBsZXQgaW1hZ2VzID0gYXdhaXQgdGhpcy51cEltZygpXHJcbiAgICAgICAgICAgICAgICB0aGlzLmltZ2xvYWRpbmcgPSBmYWxzZVxyXG4gICAgICAgICAgICAgICAgbGV0IHRhZ3MgPSB0aGlzLmdldFRhZ3ModGhpcy50YWdzZWQpXHJcbiAgICAgICAgICAgICAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICAgICAgICAgICAgICAgIGdyYWRlOiB0aGlzLmZhdm9yLFxyXG4gICAgICAgICAgICAgICAgICAgIGNvbnRlbnQ6IHRoaXMucmVtYXJrLFxyXG4gICAgICAgICAgICAgICAgICAgIC8vIGNvbnRlbnQ6IGVuY29kZVVSSUNvbXBvbmVudCh0aGlzLnJlbWFyayksXHJcbiAgICAgICAgICAgICAgICAgICAgaW1hZ2VzLFxyXG4gICAgICAgICAgICAgICAgICAgIHRhZzogdGFncy5qb2luKCcsJyksXHJcbiAgICAgICAgICAgICAgICAgICAgb3JkZXJTbjogdGhpcy5vcmRlckluZm8ub3JkZXJTbixcclxuICAgICAgICAgICAgICAgICAgICBjb3Vyc2VJZDogdGhpcy5vcmRlckluZm8uY291cnNlSWRcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGxldCByZXMgPSBhd2FpdCBjb25maWcuc2F2ZWNvbW1lbihwYXJhbXMpXHJcbiAgICAgICAgICAgICAgICBpZiAocmVzLmVycmNvZGUgPT0gMjAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgVGlwcy50b2FzdChcIuivhOiuuuaIkOWKn1wiLCByZXMgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB3ZXB5Lm5hdmlnYXRlQmFjayh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZWx0YTogMSAvL+i/lOWbnueahOmhtemdouaVsO+8jOWmguaenCBkZWx0YSDlpKfkuo7njrDmnInpobXpnaLmlbDvvIzliJnov5Tlm57liLDpppbpobUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuICAgICAgICBnZXRUYWdzKG9iaikge1xyXG4gICAgICAgICAgICBsZXQgYXJyID0gW11cclxuICAgICAgICAgICAgZm9yIChsZXQgaSBpbiBvYmopIHtcclxuICAgICAgICAgICAgICAgIGFyci5wdXNoKGkpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIGFyclxyXG4gICAgICAgIH1cclxuICAgICAgICB1cEltZygpIHtcclxuICAgICAgICAgICAgbGV0IHByb21pc2VzcyA9IFtdXHJcbiAgICAgICAgICAgIHRoaXMuaW1nTGlzdC5mb3JFYWNoKChlLCBpKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBsZXQgX3Byb21pc2UgPSBuZXcgUHJvbWlzZSgocnMsIHJqKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uZmlnLnVwbG9hZEZpbGUoZSkudGhlbihfcmVzID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcnMoX3JlcylcclxuICAgICAgICAgICAgICAgICAgICB9KS5jYXRjaChlcnIgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByaign5LiK5Lyg5aSx6LSl5LqGJylcclxuICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgIC8vIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIC8vICAgICB0aGlzLmltZ2xvYWRlZC5wdXNoKGUpXHJcbiAgICAgICAgICAgICAgICAgICAgLy8gICAgIHJzKGUpXHJcbiAgICAgICAgICAgICAgICAgICAgLy8gfSwgMjAwMClcclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICBwcm9taXNlc3MucHVzaChfcHJvbWlzZSlcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgcmV0dXJuIFByb21pc2UuYWxsKHByb21pc2VzcykudGhlbihyZXMgPT4ge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHJlc1xyXG4gICAgICAgICAgICB9KS5jYXRjaChlcnIgPT4ge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4iXX0=