"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _Lang = require('./../../utils/Lang.js');

var _Lang2 = _interopRequireDefault(_Lang);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
    _inherits(Dialog, _wepy$page);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
            navigationBarTitleText: "儿童信息编辑"
        }, _this.data = {
            modalName: '',
            gues: [],
            picker: [{
                name: '内地身份证号',
                type: 1
            }, {
                name: '护照号',
                type: 2
            }, {
                name: '军官证号',
                type: 3
            }, {
                name: '港澳通行证号',
                type: 4
            }, {
                name: '台胞证号',
                type: 5
            }, {
                name: '其他证号',
                type: 6
            }],
            cardInx: 0,
            manInx: 0,
            id: '',
            birthdayStr: "2015-09-01",
            end_date: '',
            form: {
                name: '',
                cardType: 1,
                cardNum: '',
                gender: 1,
                birthdayStr: '',
                height: '',
                weight: '',
                shapes: 1,
                guardianId: ''
            },
            rules: [{
                name: 'name',
                msg: '请填写儿童姓名'
            }, {
                name: 'cardNum',
                msg: '请填写儿童证件号码'
            }, {
                name: 'height',
                msg: '请填写儿童身高'
            }, {
                name: 'weight',
                msg: '请填写儿童体重'
            }, {
                name: 'guardianId',
                msg: '请选择一位监护人'
            }],
            isload: true
        }, _this.methods = {
            gender: function gender(_gender) {
                this.form.gender = _gender;
            },
            tips: function tips() {
                this.modalName = 'tips';
            },
            hideModal: function hideModal() {
                this.modalName = '';
            },
            PickerChange: function PickerChange(e) {
                this.cardInx = e.detail.value;
                this.form.cardType = this.picker[this.cardInx].type;
            },
            checkMan: function checkMan(inx) {
                this.manInx = inx;
                this.form.guardianId = this.gues[this.manInx].id;
            },
            toEdit: function toEdit(id) {
                _wepy2.default.navigateTo({
                    url: './addMan?id=' + id
                });
            },
            DateChange: function DateChange(e) {
                this.form.birthdayStr = e.detail.value;
            },
            input: function input(e) {
                var target = e.currentTarget.dataset.target || e.target.dataset.target,
                    type = e.currentTarget.dataset.type || e.target.dataset.type,
                    value = e.detail.value;
                if (target == 'cardNum' && type == 1) {
                    if (value.length == 18) {
                        var _res = _Lang2.default.getBirthdayByIdCard(value);
                        if ((typeof _res === "undefined" ? "undefined" : _typeof(_res)) == 'object') {
                            _Tips2.default.toast(_res.message, function () {}, 'none');
                        } else if (typeof _res == 'string') {
                            this.form.birthdayStr = _res;
                        }
                        this.form.gender = _Lang2.default.getSexByIdCard(value);
                    }
                }
                this.form[target] = value;
            },
            plus: function () {
                var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
                    var rules, res;
                    return regeneratorRuntime.wrap(function _callee$(_context) {
                        while (1) {
                            switch (_context.prev = _context.next) {
                                case 0:
                                    if (!this.rulesFn()) {
                                        _context.next = 11;
                                        break;
                                    }

                                    console.log(this.form);

                                    if (!(this.form.cardType == 1)) {
                                        _context.next = 7;
                                        break;
                                    }

                                    rules = _Lang2.default.checkIdCard(this.form.cardNum);

                                    if (rules.status) {
                                        _context.next = 7;
                                        break;
                                    }

                                    _Tips2.default.toast(rules.message, function () {}, 'none');
                                    return _context.abrupt("return", false);

                                case 7:
                                    _context.next = 9;
                                    return _config2.default.updateChild(this.form);

                                case 9:
                                    res = _context.sent;

                                    if (res.errcode == 200) {
                                        _Tips2.default.toast('保存成功', function () {
                                            _wepy2.default.navigateBack({
                                                delta: 1 //返回的页面数，如果 delta 大于现有页面数，则返回到首页,
                                            });
                                        }, 'none');
                                    }

                                case 11:
                                case "end":
                                    return _context.stop();
                            }
                        }
                    }, _callee, this);
                }));

                function plus() {
                    return _ref2.apply(this, arguments);
                }

                return plus;
            }(),
            delChild: function () {
                var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
                    var self;
                    return regeneratorRuntime.wrap(function _callee3$(_context3) {
                        while (1) {
                            switch (_context3.prev = _context3.next) {
                                case 0:
                                    self = this;

                                    wx.showModal({
                                        content: "\u786E\u5B9A\u5220\u9664" + self.form.name + "\u7684\u513F\u7AE5\u4FE1\u606F\u5417\uFF1F",
                                        success: function () {
                                            var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(res) {
                                                var _res2;

                                                return regeneratorRuntime.wrap(function _callee2$(_context2) {
                                                    while (1) {
                                                        switch (_context2.prev = _context2.next) {
                                                            case 0:
                                                                if (!res.confirm) {
                                                                    _context2.next = 7;
                                                                    break;
                                                                }

                                                                _context2.next = 3;
                                                                return _config2.default.delChild(self.id);

                                                            case 3:
                                                                _res2 = _context2.sent;

                                                                if (_res2.errcode == 200) {
                                                                    _Tips2.default.toast('删除成功', function () {
                                                                        _wepy2.default.navigateBack({
                                                                            delta: 1 //返回的页面数，如果 delta 大于现有页面数，则返回到首页,
                                                                        });
                                                                    }, 'none');
                                                                }
                                                                _context2.next = 8;
                                                                break;

                                                            case 7:
                                                                if (res.cancel) {}

                                                            case 8:
                                                            case "end":
                                                                return _context2.stop();
                                                        }
                                                    }
                                                }, _callee2, this);
                                            }));

                                            function success(_x) {
                                                return _ref4.apply(this, arguments);
                                            }

                                            return success;
                                        }()
                                    });

                                case 2:
                                case "end":
                                    return _context3.stop();
                            }
                        }
                    }, _callee3, this);
                }));

                function delChild() {
                    return _ref3.apply(this, arguments);
                }

                return delChild;
            }()
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(Dialog, [{
        key: "onLoad",
        value: function () {
            var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4(opt) {
                return regeneratorRuntime.wrap(function _callee4$(_context4) {
                    while (1) {
                        switch (_context4.prev = _context4.next) {
                            case 0:
                                this.id = opt.id;
                                this.end_date = _Lang2.default.dateFormate(new Date(), 'yyyy-MM-dd');
                                _context4.next = 4;
                                return this.updata();

                            case 4:
                                if (this.id == -1) {
                                    this.form.birthdayStr = this.end_date;
                                }
                                this.isload = false;

                            case 6:
                            case "end":
                                return _context4.stop();
                        }
                    }
                }, _callee4, this);
            }));

            function onLoad(_x2) {
                return _ref5.apply(this, arguments);
            }

            return onLoad;
        }()
    }, {
        key: "onShow",
        value: function onShow() {
            if (this.isload) {
                return false;
            }
            this.updata();
        }
    }, {
        key: "updata",
        value: function () {
            var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
                var _this2 = this;

                return regeneratorRuntime.wrap(function _callee5$(_context5) {
                    while (1) {
                        switch (_context5.prev = _context5.next) {
                            case 0:
                                _context5.next = 2;
                                return this.getGuaList();

                            case 2:
                                if (!(this.id != '-1')) {
                                    _context5.next = 5;
                                    break;
                                }

                                _context5.next = 5;
                                return this.getChild(this.id);

                            case 5:
                                // 重新选中，监护人项
                                if (this.gues.length) {
                                    if (this.form.guardianId) {
                                        this.manInx = this.gues.findIndex(function (e) {
                                            return e.id == _this2.form.guardianId;
                                        });
                                    } else {
                                        this.form.guardianId = this.gues[this.manInx].id;
                                    }
                                }
                                this.$apply();

                            case 7:
                            case "end":
                                return _context5.stop();
                        }
                    }
                }, _callee5, this);
            }));

            function updata() {
                return _ref6.apply(this, arguments);
            }

            return updata;
        }()
    }, {
        key: "getGuaList",
        value: function () {
            var _ref7 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
                var _ref8, guaList;

                return regeneratorRuntime.wrap(function _callee6$(_context6) {
                    while (1) {
                        switch (_context6.prev = _context6.next) {
                            case 0:
                                _context6.next = 2;
                                return _config2.default.getGuaList();

                            case 2:
                                _ref8 = _context6.sent;
                                guaList = _ref8.guaList;

                                this.gues = guaList;
                                this.$apply();

                            case 6:
                            case "end":
                                return _context6.stop();
                        }
                    }
                }, _callee6, this);
            }));

            function getGuaList() {
                return _ref7.apply(this, arguments);
            }

            return getGuaList;
        }()
    }, {
        key: "getChild",
        value: function () {
            var _ref9 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee7(id) {
                var res;
                return regeneratorRuntime.wrap(function _callee7$(_context7) {
                    while (1) {
                        switch (_context7.prev = _context7.next) {
                            case 0:
                                _context7.next = 2;
                                return _config2.default.getChild(id);

                            case 2:
                                res = _context7.sent;

                                this.form = {
                                    name: res.name,
                                    cardType: res.cardType,
                                    cardNum: res.cardNum,
                                    gender: res.gender,
                                    birthdayStr: res.birthday,
                                    height: res.height,
                                    weight: res.weight,
                                    shapes: res.shapes,
                                    guardianId: res.guardianId,
                                    id: res.id
                                };

                            case 4:
                            case "end":
                                return _context7.stop();
                        }
                    }
                }, _callee7, this);
            }));

            function getChild(_x3) {
                return _ref9.apply(this, arguments);
            }

            return getChild;
        }()
    }, {
        key: "rulesFn",
        value: function rulesFn() {
            var flag = true;
            var _iteratorNormalCompletion = true;
            var _didIteratorError = false;
            var _iteratorError = undefined;

            try {
                for (var _iterator = this.rules[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
                    var i = _step.value;

                    if (_Lang2.default.isEmpty(this.form[i.name])) {
                        _Tips2.default.toast(i.msg, function () {}, 'none');
                        flag = false;
                        break;
                    }
                }
            } catch (err) {
                _didIteratorError = true;
                _iteratorError = err;
            } finally {
                try {
                    if (!_iteratorNormalCompletion && _iterator.return) {
                        _iterator.return();
                    }
                } finally {
                    if (_didIteratorError) {
                        throw _iteratorError;
                    }
                }
            }

            return flag;
        }
    }]);

    return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/meet/addChild'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFkZENoaWxkLmpzIl0sIm5hbWVzIjpbIkRpYWxvZyIsImNvbmZpZyIsIm5hdmlnYXRpb25CYXJUaXRsZVRleHQiLCJkYXRhIiwibW9kYWxOYW1lIiwiZ3VlcyIsInBpY2tlciIsIm5hbWUiLCJ0eXBlIiwiY2FyZElueCIsIm1hbklueCIsImlkIiwiYmlydGhkYXlTdHIiLCJlbmRfZGF0ZSIsImZvcm0iLCJjYXJkVHlwZSIsImNhcmROdW0iLCJnZW5kZXIiLCJoZWlnaHQiLCJ3ZWlnaHQiLCJzaGFwZXMiLCJndWFyZGlhbklkIiwicnVsZXMiLCJtc2ciLCJpc2xvYWQiLCJtZXRob2RzIiwidGlwcyIsImhpZGVNb2RhbCIsIlBpY2tlckNoYW5nZSIsImUiLCJkZXRhaWwiLCJ2YWx1ZSIsImNoZWNrTWFuIiwiaW54IiwidG9FZGl0Iiwid2VweSIsIm5hdmlnYXRlVG8iLCJ1cmwiLCJEYXRlQ2hhbmdlIiwiaW5wdXQiLCJ0YXJnZXQiLCJjdXJyZW50VGFyZ2V0IiwiZGF0YXNldCIsImxlbmd0aCIsIl9yZXMiLCJMYW5nIiwiZ2V0QmlydGhkYXlCeUlkQ2FyZCIsIlRpcHMiLCJ0b2FzdCIsIm1lc3NhZ2UiLCJnZXRTZXhCeUlkQ2FyZCIsInBsdXMiLCJydWxlc0ZuIiwiY29uc29sZSIsImxvZyIsImNoZWNrSWRDYXJkIiwic3RhdHVzIiwidXBkYXRlQ2hpbGQiLCJyZXMiLCJlcnJjb2RlIiwibmF2aWdhdGVCYWNrIiwiZGVsdGEiLCJkZWxDaGlsZCIsInNlbGYiLCJ3eCIsInNob3dNb2RhbCIsImNvbnRlbnQiLCJzdWNjZXNzIiwiY29uZmlybSIsImNhbmNlbCIsIm9wdCIsImRhdGVGb3JtYXRlIiwiRGF0ZSIsInVwZGF0YSIsImdldEd1YUxpc3QiLCJnZXRDaGlsZCIsImZpbmRJbmRleCIsIiRhcHBseSIsImd1YUxpc3QiLCJiaXJ0aGRheSIsImZsYWciLCJpIiwiaXNFbXB0eSIsInBhZ2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7O0FBQ0k7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7Ozs7Ozs7Ozs7O0lBQ3FCQSxNOzs7Ozs7Ozs7Ozs7OzswTEFDakJDLE0sR0FBUztBQUNMQyxvQ0FBd0I7QUFEbkIsUyxRQUdUQyxJLEdBQU87QUFDSEMsdUJBQVcsRUFEUjtBQUVIQyxrQkFBTSxFQUZIO0FBR0hDLG9CQUFRLENBQUM7QUFDTEMsc0JBQU0sUUFERDtBQUVMQyxzQkFBTTtBQUZELGFBQUQsRUFHTDtBQUNDRCxzQkFBTSxLQURQO0FBRUNDLHNCQUFNO0FBRlAsYUFISyxFQU1MO0FBQ0NELHNCQUFNLE1BRFA7QUFFQ0Msc0JBQU07QUFGUCxhQU5LLEVBU0w7QUFDQ0Qsc0JBQU0sUUFEUDtBQUVDQyxzQkFBTTtBQUZQLGFBVEssRUFZTDtBQUNDRCxzQkFBTSxNQURQO0FBRUNDLHNCQUFNO0FBRlAsYUFaSyxFQWVMO0FBQ0NELHNCQUFNLE1BRFA7QUFFQ0Msc0JBQU07QUFGUCxhQWZLLENBSEw7QUFzQkhDLHFCQUFTLENBdEJOO0FBdUJIQyxvQkFBUSxDQXZCTDtBQXdCSEMsZ0JBQUksRUF4QkQ7QUF5QkhDLHlCQUFhLFlBekJWO0FBMEJIQyxzQkFBVSxFQTFCUDtBQTJCSEMsa0JBQU07QUFDRlAsc0JBQU0sRUFESjtBQUVGUSwwQkFBVSxDQUZSO0FBR0ZDLHlCQUFTLEVBSFA7QUFJRkMsd0JBQVEsQ0FKTjtBQUtGTCw2QkFBYSxFQUxYO0FBTUZNLHdCQUFRLEVBTk47QUFPRkMsd0JBQVEsRUFQTjtBQVFGQyx3QkFBUSxDQVJOO0FBU0ZDLDRCQUFZO0FBVFYsYUEzQkg7QUFzQ0hDLG1CQUFPLENBQUM7QUFDQWYsc0JBQU0sTUFETjtBQUVBZ0IscUJBQUs7QUFGTCxhQUFELEVBSUg7QUFDSWhCLHNCQUFNLFNBRFY7QUFFSWdCLHFCQUFLO0FBRlQsYUFKRyxFQVFIO0FBQ0loQixzQkFBTSxRQURWO0FBRUlnQixxQkFBSztBQUZULGFBUkcsRUFXQTtBQUNDaEIsc0JBQU0sUUFEUDtBQUVDZ0IscUJBQUs7QUFGTixhQVhBLEVBY0E7QUFDQ2hCLHNCQUFNLFlBRFA7QUFFQ2dCLHFCQUFLO0FBRk4sYUFkQSxDQXRDSjtBQXlESEMsb0JBQVE7QUF6REwsUyxRQTRIUEMsTyxHQUFVO0FBQ05SLGtCQURNLGtCQUNDQSxPQURELEVBQ1M7QUFDWCxxQkFBS0gsSUFBTCxDQUFVRyxNQUFWLEdBQW1CQSxPQUFuQjtBQUNILGFBSEs7QUFJTlMsZ0JBSk0sa0JBSUM7QUFDSCxxQkFBS3RCLFNBQUwsR0FBaUIsTUFBakI7QUFDSCxhQU5LO0FBT051QixxQkFQTSx1QkFPTTtBQUNSLHFCQUFLdkIsU0FBTCxHQUFpQixFQUFqQjtBQUNILGFBVEs7QUFVTndCLHdCQVZNLHdCQVVPQyxDQVZQLEVBVVU7QUFDWixxQkFBS3BCLE9BQUwsR0FBZW9CLEVBQUVDLE1BQUYsQ0FBU0MsS0FBeEI7QUFDQSxxQkFBS2pCLElBQUwsQ0FBVUMsUUFBVixHQUFxQixLQUFLVCxNQUFMLENBQVksS0FBS0csT0FBakIsRUFBMEJELElBQS9DO0FBQ0gsYUFiSztBQWNOd0Isb0JBZE0sb0JBY0dDLEdBZEgsRUFjUTtBQUNWLHFCQUFLdkIsTUFBTCxHQUFjdUIsR0FBZDtBQUNBLHFCQUFLbkIsSUFBTCxDQUFVTyxVQUFWLEdBQXVCLEtBQUtoQixJQUFMLENBQVUsS0FBS0ssTUFBZixFQUF1QkMsRUFBOUM7QUFDSCxhQWpCSztBQWtCTnVCLGtCQWxCTSxrQkFrQkN2QixFQWxCRCxFQWtCSztBQUNQd0IsK0JBQUtDLFVBQUwsQ0FBZ0I7QUFDWkMseUJBQUssaUJBQWlCMUI7QUFEVixpQkFBaEI7QUFHSCxhQXRCSztBQXVCTjJCLHNCQXZCTSxzQkF1QktULENBdkJMLEVBdUJRO0FBQ1YscUJBQUtmLElBQUwsQ0FBVUYsV0FBVixHQUF3QmlCLEVBQUVDLE1BQUYsQ0FBU0MsS0FBakM7QUFDSCxhQXpCSztBQTBCTlEsaUJBMUJNLGlCQTBCQVYsQ0ExQkEsRUEwQkc7QUFDTCxvQkFBSVcsU0FBU1gsRUFBRVksYUFBRixDQUFnQkMsT0FBaEIsQ0FBd0JGLE1BQXhCLElBQWtDWCxFQUFFVyxNQUFGLENBQVNFLE9BQVQsQ0FBaUJGLE1BQWhFO0FBQUEsb0JBQ0loQyxPQUFPcUIsRUFBRVksYUFBRixDQUFnQkMsT0FBaEIsQ0FBd0JsQyxJQUF4QixJQUFnQ3FCLEVBQUVXLE1BQUYsQ0FBU0UsT0FBVCxDQUFpQmxDLElBRDVEO0FBQUEsb0JBRUl1QixRQUFRRixFQUFFQyxNQUFGLENBQVNDLEtBRnJCO0FBR0Esb0JBQUlTLFVBQVUsU0FBVixJQUF1QmhDLFFBQVEsQ0FBbkMsRUFBc0M7QUFDbEMsd0JBQUl1QixNQUFNWSxNQUFOLElBQWdCLEVBQXBCLEVBQXdCO0FBQ3BCLDRCQUFJQyxPQUFPQyxlQUFLQyxtQkFBTCxDQUF5QmYsS0FBekIsQ0FBWDtBQUNBLDRCQUFJLFFBQU9hLElBQVAseUNBQU9BLElBQVAsTUFBZSxRQUFuQixFQUE2QjtBQUN6QkcsMkNBQUtDLEtBQUwsQ0FBV0osS0FBS0ssT0FBaEIsRUFBeUIsWUFBTSxDQUFFLENBQWpDLEVBQW1DLE1BQW5DO0FBQ0gseUJBRkQsTUFFTyxJQUFJLE9BQU9MLElBQVAsSUFBZSxRQUFuQixFQUE2QjtBQUNoQyxpQ0FBSzlCLElBQUwsQ0FBVUYsV0FBVixHQUF3QmdDLElBQXhCO0FBQ0g7QUFDRCw2QkFBSzlCLElBQUwsQ0FBVUcsTUFBVixHQUFtQjRCLGVBQUtLLGNBQUwsQ0FBb0JuQixLQUFwQixDQUFuQjtBQUNIO0FBQ0o7QUFDRCxxQkFBS2pCLElBQUwsQ0FBVTBCLE1BQVYsSUFBb0JULEtBQXBCO0FBQ0gsYUExQ0s7QUEyQ0FvQixnQkEzQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5Q0E0Q0UsS0FBS0MsT0FBTCxFQTVDRjtBQUFBO0FBQUE7QUFBQTs7QUE2Q0VDLDRDQUFRQyxHQUFSLENBQVksS0FBS3hDLElBQWpCOztBQTdDRiwwQ0E4Q00sS0FBS0EsSUFBTCxDQUFVQyxRQUFWLElBQXNCLENBOUM1QjtBQUFBO0FBQUE7QUFBQTs7QUErQ1VPLHlDQS9DVixHQStDa0J1QixlQUFLVSxXQUFMLENBQWlCLEtBQUt6QyxJQUFMLENBQVVFLE9BQTNCLENBL0NsQjs7QUFBQSx3Q0FnRFdNLE1BQU1rQyxNQWhEakI7QUFBQTtBQUFBO0FBQUE7O0FBaURVVCxtREFBS0MsS0FBTCxDQUFXMUIsTUFBTTJCLE9BQWpCLEVBQTBCLFlBQU0sQ0FBRSxDQUFsQyxFQUFvQyxNQUFwQztBQWpEVixxRUFrRGlCLEtBbERqQjs7QUFBQTtBQUFBO0FBQUEsMkNBcURrQmhELGlCQUFPd0QsV0FBUCxDQUFtQixLQUFLM0MsSUFBeEIsQ0FyRGxCOztBQUFBO0FBcURNNEMsdUNBckROOztBQXNERSx3Q0FBSUEsSUFBSUMsT0FBSixJQUFlLEdBQW5CLEVBQXdCO0FBQ3BCWix1REFBS0MsS0FBTCxDQUFXLE1BQVgsRUFBbUIsWUFBTTtBQUNyQmIsMkRBQUt5QixZQUFMLENBQWtCO0FBQ2RDLHVEQUFPLENBRE8sQ0FDTDtBQURLLDZDQUFsQjtBQUdILHlDQUpELEVBSUcsTUFKSDtBQUtIOztBQTVESDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQStEQUMsb0JBL0RBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBZ0VFQyx3Q0FoRUYsR0FnRVMsSUFoRVQ7O0FBaUVGQyx1Q0FBR0MsU0FBSCxDQUFhO0FBQ1RDLDhFQUFnQkgsS0FBS2pELElBQUwsQ0FBVVAsSUFBMUIsK0NBRFM7QUFFVDREO0FBQUEsZ0hBQVMsa0JBQWVULEdBQWY7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFFQUNEQSxJQUFJVSxPQURIO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUEsdUVBRWVuRSxpQkFBTzZELFFBQVAsQ0FBZ0JDLEtBQUtwRCxFQUFyQixDQUZmOztBQUFBO0FBRUcrQyxxRUFGSDs7QUFHRCxvRUFBSUEsTUFBSUMsT0FBSixJQUFlLEdBQW5CLEVBQXdCO0FBQ3BCWixtRkFBS0MsS0FBTCxDQUFXLE1BQVgsRUFBbUIsWUFBTTtBQUNyQmIsdUZBQUt5QixZQUFMLENBQWtCO0FBQ2RDLG1GQUFPLENBRE8sQ0FDTDtBQURLLHlFQUFsQjtBQUdILHFFQUpELEVBSUcsTUFKSDtBQUtIO0FBVEE7QUFBQTs7QUFBQTtBQVVFLG9FQUFJSCxJQUFJVyxNQUFSLEVBQWdCLENBQUU7O0FBVnBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZDQUFUOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBRlMscUNBQWI7O0FBakVFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUEsUzs7Ozs7O2tHQWpFR0MsRzs7Ozs7QUFDVCxxQ0FBSzNELEVBQUwsR0FBVTJELElBQUkzRCxFQUFkO0FBQ0EscUNBQUtFLFFBQUwsR0FBZ0JnQyxlQUFLMEIsV0FBTCxDQUFpQixJQUFJQyxJQUFKLEVBQWpCLEVBQTZCLFlBQTdCLENBQWhCOzt1Q0FDTSxLQUFLQyxNQUFMLEU7OztBQUNOLG9DQUFJLEtBQUs5RCxFQUFMLElBQVcsQ0FBQyxDQUFoQixFQUFtQjtBQUNmLHlDQUFLRyxJQUFMLENBQVVGLFdBQVYsR0FBd0IsS0FBS0MsUUFBN0I7QUFDSDtBQUNELHFDQUFLVyxNQUFMLEdBQWMsS0FBZDs7Ozs7Ozs7Ozs7Ozs7Ozs7O2lDQUVLO0FBQ0wsZ0JBQUksS0FBS0EsTUFBVCxFQUFpQjtBQUNiLHVCQUFPLEtBQVA7QUFDSDtBQUNELGlCQUFLaUQsTUFBTDtBQUNIOzs7Ozs7Ozs7Ozs7dUNBRVMsS0FBS0MsVUFBTCxFOzs7c0NBQ0YsS0FBSy9ELEVBQUwsSUFBVyxJOzs7Ozs7dUNBQ0wsS0FBS2dFLFFBQUwsQ0FBYyxLQUFLaEUsRUFBbkIsQzs7O0FBRVY7QUFDQSxvQ0FBSSxLQUFLTixJQUFMLENBQVVzQyxNQUFkLEVBQXNCO0FBQ2xCLHdDQUFJLEtBQUs3QixJQUFMLENBQVVPLFVBQWQsRUFBMEI7QUFDdEIsNkNBQUtYLE1BQUwsR0FBYyxLQUFLTCxJQUFMLENBQVV1RSxTQUFWLENBQW9CLGFBQUs7QUFDbkMsbURBQU8vQyxFQUFFbEIsRUFBRixJQUFRLE9BQUtHLElBQUwsQ0FBVU8sVUFBekI7QUFDSCx5Q0FGYSxDQUFkO0FBR0gscUNBSkQsTUFJTztBQUNILDZDQUFLUCxJQUFMLENBQVVPLFVBQVYsR0FBdUIsS0FBS2hCLElBQUwsQ0FBVSxLQUFLSyxNQUFmLEVBQXVCQyxFQUE5QztBQUNIO0FBQ0o7QUFDRCxxQ0FBS2tFLE1BQUw7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozt1Q0FLVTVFLGlCQUFPeUUsVUFBUCxFOzs7O0FBRE5JLHVDLFNBQUFBLE87O0FBRUoscUNBQUt6RSxJQUFMLEdBQVl5RSxPQUFaO0FBQ0EscUNBQUtELE1BQUw7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7a0dBRVdsRSxFOzs7Ozs7O3VDQUNLVixpQkFBTzBFLFFBQVAsQ0FBZ0JoRSxFQUFoQixDOzs7QUFBWitDLG1DOztBQUNKLHFDQUFLNUMsSUFBTCxHQUFZO0FBQ1JQLDBDQUFNbUQsSUFBSW5ELElBREY7QUFFUlEsOENBQVUyQyxJQUFJM0MsUUFGTjtBQUdSQyw2Q0FBUzBDLElBQUkxQyxPQUhMO0FBSVJDLDRDQUFReUMsSUFBSXpDLE1BSko7QUFLUkwsaURBQWE4QyxJQUFJcUIsUUFMVDtBQU1SN0QsNENBQVF3QyxJQUFJeEMsTUFOSjtBQU9SQyw0Q0FBUXVDLElBQUl2QyxNQVBKO0FBUVJDLDRDQUFRc0MsSUFBSXRDLE1BUko7QUFTUkMsZ0RBQVlxQyxJQUFJckMsVUFUUjtBQVVSVix3Q0FBSStDLElBQUkvQztBQVZBLGlDQUFaOzs7Ozs7Ozs7Ozs7Ozs7Ozs7a0NBYU07QUFDTixnQkFBSXFFLE9BQU8sSUFBWDtBQURNO0FBQUE7QUFBQTs7QUFBQTtBQUVOLHFDQUFjLEtBQUsxRCxLQUFuQiw4SEFBMEI7QUFBQSx3QkFBakIyRCxDQUFpQjs7QUFDdEIsd0JBQUlwQyxlQUFLcUMsT0FBTCxDQUFhLEtBQUtwRSxJQUFMLENBQVVtRSxFQUFFMUUsSUFBWixDQUFiLENBQUosRUFBcUM7QUFDakN3Qyx1Q0FBS0MsS0FBTCxDQUFXaUMsRUFBRTFELEdBQWIsRUFBa0IsWUFBTSxDQUFFLENBQTFCLEVBQTRCLE1BQTVCO0FBQ0F5RCwrQkFBTyxLQUFQO0FBQ0E7QUFDSDtBQUNKO0FBUks7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFTTixtQkFBT0EsSUFBUDtBQUNIOzs7O0VBL0grQjdDLGVBQUtnRCxJOztrQkFBcEJuRixNIiwiZmlsZSI6ImFkZENoaWxkLmpzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbiAgICBpbXBvcnQgd2VweSBmcm9tIFwid2VweVwiXHJcbiAgICBpbXBvcnQgTGFuZyBmcm9tIFwiQC91dGlscy9MYW5nXCJcclxuICAgIGltcG9ydCBUaXBzIGZyb20gXCJAL3V0aWxzL1RpcHNcIlxyXG4gICAgaW1wb3J0IGNvbmZpZyBmcm9tIFwiQC9hcGkvY29uZmlnXCJcclxuICAgIGV4cG9ydCBkZWZhdWx0IGNsYXNzIERpYWxvZyBleHRlbmRzIHdlcHkucGFnZSB7XHJcbiAgICAgICAgY29uZmlnID0ge1xyXG4gICAgICAgICAgICBuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0OiBcIuWEv+erpeS/oeaBr+e8lui+kVwiXHJcbiAgICAgICAgfTtcclxuICAgICAgICBkYXRhID0ge1xyXG4gICAgICAgICAgICBtb2RhbE5hbWU6ICcnLFxyXG4gICAgICAgICAgICBndWVzOiBbXSxcclxuICAgICAgICAgICAgcGlja2VyOiBbe1xyXG4gICAgICAgICAgICAgICAgbmFtZTogJ+WGheWcsOi6q+S7veivgeWPtycsXHJcbiAgICAgICAgICAgICAgICB0eXBlOiAxXHJcbiAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgIG5hbWU6ICfmiqTnhaflj7cnLFxyXG4gICAgICAgICAgICAgICAgdHlwZTogMlxyXG4gICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICBuYW1lOiAn5Yab5a6Y6K+B5Y+3JyxcclxuICAgICAgICAgICAgICAgIHR5cGU6IDNcclxuICAgICAgICAgICAgfSwge1xyXG4gICAgICAgICAgICAgICAgbmFtZTogJ+a4r+a+s+mAmuihjOivgeWPtycsXHJcbiAgICAgICAgICAgICAgICB0eXBlOiA0XHJcbiAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgIG5hbWU6ICflj7Dog57or4Hlj7cnLFxyXG4gICAgICAgICAgICAgICAgdHlwZTogNVxyXG4gICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICBuYW1lOiAn5YW25LuW6K+B5Y+3JyxcclxuICAgICAgICAgICAgICAgIHR5cGU6IDZcclxuICAgICAgICAgICAgfSwgXSxcclxuICAgICAgICAgICAgY2FyZElueDogMCxcclxuICAgICAgICAgICAgbWFuSW54OiAwLFxyXG4gICAgICAgICAgICBpZDogJycsXHJcbiAgICAgICAgICAgIGJpcnRoZGF5U3RyOiBcIjIwMTUtMDktMDFcIixcclxuICAgICAgICAgICAgZW5kX2RhdGU6ICcnLFxyXG4gICAgICAgICAgICBmb3JtOiB7XHJcbiAgICAgICAgICAgICAgICBuYW1lOiAnJyxcclxuICAgICAgICAgICAgICAgIGNhcmRUeXBlOiAxLFxyXG4gICAgICAgICAgICAgICAgY2FyZE51bTogJycsXHJcbiAgICAgICAgICAgICAgICBnZW5kZXI6IDEsXHJcbiAgICAgICAgICAgICAgICBiaXJ0aGRheVN0cjogJycsXHJcbiAgICAgICAgICAgICAgICBoZWlnaHQ6ICcnLFxyXG4gICAgICAgICAgICAgICAgd2VpZ2h0OiAnJyxcclxuICAgICAgICAgICAgICAgIHNoYXBlczogMSxcclxuICAgICAgICAgICAgICAgIGd1YXJkaWFuSWQ6ICcnXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHJ1bGVzOiBbe1xyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU6ICduYW1lJyxcclxuICAgICAgICAgICAgICAgICAgICBtc2c6ICfor7floavlhpnlhL/nq6Xlp5PlkI0nXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU6ICdjYXJkTnVtJyxcclxuICAgICAgICAgICAgICAgICAgICBtc2c6ICfor7floavlhpnlhL/nq6Xor4Hku7blj7fnoIEnXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU6ICdoZWlnaHQnLFxyXG4gICAgICAgICAgICAgICAgICAgIG1zZzogJ+ivt+Whq+WGmeWEv+erpei6q+mrmCdcclxuICAgICAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgICAgICBuYW1lOiAnd2VpZ2h0JyxcclxuICAgICAgICAgICAgICAgICAgICBtc2c6ICfor7floavlhpnlhL/nq6XkvZPph40nXHJcbiAgICAgICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZTogJ2d1YXJkaWFuSWQnLFxyXG4gICAgICAgICAgICAgICAgICAgIG1zZzogJ+ivt+mAieaLqeS4gOS9jeebkeaKpOS6uidcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgaXNsb2FkOiB0cnVlXHJcbiAgICAgICAgfTtcclxuICAgICAgICBhc3luYyBvbkxvYWQob3B0KSB7XHJcbiAgICAgICAgICAgIHRoaXMuaWQgPSBvcHQuaWRcclxuICAgICAgICAgICAgdGhpcy5lbmRfZGF0ZSA9IExhbmcuZGF0ZUZvcm1hdGUobmV3IERhdGUoKSwgJ3l5eXktTU0tZGQnKVxyXG4gICAgICAgICAgICBhd2FpdCB0aGlzLnVwZGF0YSgpXHJcbiAgICAgICAgICAgIGlmICh0aGlzLmlkID09IC0xKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmZvcm0uYmlydGhkYXlTdHIgPSB0aGlzLmVuZF9kYXRlXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdGhpcy5pc2xvYWQgPSBmYWxzZVxyXG4gICAgICAgIH1cclxuICAgICAgICBvblNob3coKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmlzbG9hZCkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdGhpcy51cGRhdGEoKVxyXG4gICAgICAgIH1cclxuICAgICAgICBhc3luYyB1cGRhdGEoKSB7XHJcbiAgICAgICAgICAgIGF3YWl0IHRoaXMuZ2V0R3VhTGlzdCgpXHJcbiAgICAgICAgICAgIGlmICh0aGlzLmlkICE9ICctMScpIHtcclxuICAgICAgICAgICAgICAgIGF3YWl0IHRoaXMuZ2V0Q2hpbGQodGhpcy5pZClcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAvLyDph43mlrDpgInkuK3vvIznm5HmiqTkurrpoblcclxuICAgICAgICAgICAgaWYgKHRoaXMuZ3Vlcy5sZW5ndGgpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmZvcm0uZ3VhcmRpYW5JZCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubWFuSW54ID0gdGhpcy5ndWVzLmZpbmRJbmRleChlID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGUuaWQgPT0gdGhpcy5mb3JtLmd1YXJkaWFuSWRcclxuICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmZvcm0uZ3VhcmRpYW5JZCA9IHRoaXMuZ3Vlc1t0aGlzLm1hbklueF0uaWRcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGFzeW5jIGdldEd1YUxpc3QoKSB7XHJcbiAgICAgICAgICAgIGxldCB7XHJcbiAgICAgICAgICAgICAgICBndWFMaXN0XHJcbiAgICAgICAgICAgIH0gPSBhd2FpdCBjb25maWcuZ2V0R3VhTGlzdCgpXHJcbiAgICAgICAgICAgIHRoaXMuZ3VlcyA9IGd1YUxpc3RcclxuICAgICAgICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgICAgIH1cclxuICAgICAgICBhc3luYyBnZXRDaGlsZChpZCkge1xyXG4gICAgICAgICAgICBsZXQgcmVzID0gYXdhaXQgY29uZmlnLmdldENoaWxkKGlkKVxyXG4gICAgICAgICAgICB0aGlzLmZvcm0gPSB7XHJcbiAgICAgICAgICAgICAgICBuYW1lOiByZXMubmFtZSxcclxuICAgICAgICAgICAgICAgIGNhcmRUeXBlOiByZXMuY2FyZFR5cGUsXHJcbiAgICAgICAgICAgICAgICBjYXJkTnVtOiByZXMuY2FyZE51bSxcclxuICAgICAgICAgICAgICAgIGdlbmRlcjogcmVzLmdlbmRlcixcclxuICAgICAgICAgICAgICAgIGJpcnRoZGF5U3RyOiByZXMuYmlydGhkYXksXHJcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IHJlcy5oZWlnaHQsXHJcbiAgICAgICAgICAgICAgICB3ZWlnaHQ6IHJlcy53ZWlnaHQsXHJcbiAgICAgICAgICAgICAgICBzaGFwZXM6IHJlcy5zaGFwZXMsXHJcbiAgICAgICAgICAgICAgICBndWFyZGlhbklkOiByZXMuZ3VhcmRpYW5JZCxcclxuICAgICAgICAgICAgICAgIGlkOiByZXMuaWRcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBydWxlc0ZuKCkge1xyXG4gICAgICAgICAgICBsZXQgZmxhZyA9IHRydWVcclxuICAgICAgICAgICAgZm9yIChsZXQgaSBvZiB0aGlzLnJ1bGVzKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoTGFuZy5pc0VtcHR5KHRoaXMuZm9ybVtpLm5hbWVdKSkge1xyXG4gICAgICAgICAgICAgICAgICAgIFRpcHMudG9hc3QoaS5tc2csICgpID0+IHt9LCAnbm9uZScpXHJcbiAgICAgICAgICAgICAgICAgICAgZmxhZyA9IGZhbHNlXHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gZmxhZ1xyXG4gICAgICAgIH1cclxuICAgICAgICBtZXRob2RzID0ge1xyXG4gICAgICAgICAgICBnZW5kZXIoZ2VuZGVyKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmZvcm0uZ2VuZGVyID0gZ2VuZGVyXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHRpcHMoKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGFsTmFtZSA9ICd0aXBzJ1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBoaWRlTW9kYWwoKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGFsTmFtZSA9ICcnXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIFBpY2tlckNoYW5nZShlKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNhcmRJbnggPSBlLmRldGFpbC52YWx1ZVxyXG4gICAgICAgICAgICAgICAgdGhpcy5mb3JtLmNhcmRUeXBlID0gdGhpcy5waWNrZXJbdGhpcy5jYXJkSW54XS50eXBlXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGNoZWNrTWFuKGlueCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tYW5JbnggPSBpbnhcclxuICAgICAgICAgICAgICAgIHRoaXMuZm9ybS5ndWFyZGlhbklkID0gdGhpcy5ndWVzW3RoaXMubWFuSW54XS5pZFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB0b0VkaXQoaWQpIHtcclxuICAgICAgICAgICAgICAgIHdlcHkubmF2aWdhdGVUbyh7XHJcbiAgICAgICAgICAgICAgICAgICAgdXJsOiAnLi9hZGRNYW4/aWQ9JyArIGlkXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgRGF0ZUNoYW5nZShlKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmZvcm0uYmlydGhkYXlTdHIgPSBlLmRldGFpbC52YWx1ZVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBpbnB1dChlKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgdGFyZ2V0ID0gZS5jdXJyZW50VGFyZ2V0LmRhdGFzZXQudGFyZ2V0IHx8IGUudGFyZ2V0LmRhdGFzZXQudGFyZ2V0LFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGUgPSBlLmN1cnJlbnRUYXJnZXQuZGF0YXNldC50eXBlIHx8IGUudGFyZ2V0LmRhdGFzZXQudHlwZSxcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZSA9IGUuZGV0YWlsLnZhbHVlO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRhcmdldCA9PSAnY2FyZE51bScgJiYgdHlwZSA9PSAxKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHZhbHVlLmxlbmd0aCA9PSAxOCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgX3JlcyA9IExhbmcuZ2V0QmlydGhkYXlCeUlkQ2FyZCh2YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBfcmVzID09ICdvYmplY3QnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBUaXBzLnRvYXN0KF9yZXMubWVzc2FnZSwgKCkgPT4ge30sICdub25lJylcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmICh0eXBlb2YgX3JlcyA9PSAnc3RyaW5nJykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5mb3JtLmJpcnRoZGF5U3RyID0gX3Jlc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZm9ybS5nZW5kZXIgPSBMYW5nLmdldFNleEJ5SWRDYXJkKHZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHRoaXMuZm9ybVt0YXJnZXRdID0gdmFsdWVcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgYXN5bmMgcGx1cygpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLnJ1bGVzRm4oKSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKHRoaXMuZm9ybSlcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5mb3JtLmNhcmRUeXBlID09IDEpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHJ1bGVzID0gTGFuZy5jaGVja0lkQ2FyZCh0aGlzLmZvcm0uY2FyZE51bSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFydWxlcy5zdGF0dXMpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRpcHMudG9hc3QocnVsZXMubWVzc2FnZSwgKCkgPT4ge30sICdub25lJylcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGxldCByZXMgPSBhd2FpdCBjb25maWcudXBkYXRlQ2hpbGQodGhpcy5mb3JtKVxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChyZXMuZXJyY29kZSA9PSAyMDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgVGlwcy50b2FzdCgn5L+d5a2Y5oiQ5YqfJywgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgd2VweS5uYXZpZ2F0ZUJhY2soe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlbHRhOiAxIC8v6L+U5Zue55qE6aG16Z2i5pWw77yM5aaC5p6cIGRlbHRhIOWkp+S6jueOsOaciemhtemdouaVsO+8jOWImei/lOWbnuWIsOmmlumhtSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LCAnbm9uZScpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBhc3luYyBkZWxDaGlsZCgpIHtcclxuICAgICAgICAgICAgICAgIGxldCBzZWxmID0gdGhpc1xyXG4gICAgICAgICAgICAgICAgd3guc2hvd01vZGFsKHtcclxuICAgICAgICAgICAgICAgICAgICBjb250ZW50OiBg56Gu5a6a5Yig6ZmkJHtzZWxmLmZvcm0ubmFtZX3nmoTlhL/nq6Xkv6Hmga/lkJfvvJ9gLFxyXG4gICAgICAgICAgICAgICAgICAgIHN1Y2Nlc3M6IGFzeW5jIGZ1bmN0aW9uKHJlcykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzLmNvbmZpcm0pIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCByZXMgPSBhd2FpdCBjb25maWcuZGVsQ2hpbGQoc2VsZi5pZClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXMuZXJyY29kZSA9PSAyMDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUaXBzLnRvYXN0KCfliKDpmaTmiJDlip8nLCAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdlcHkubmF2aWdhdGVCYWNrKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlbHRhOiAxIC8v6L+U5Zue55qE6aG16Z2i5pWw77yM5aaC5p6cIGRlbHRhIOWkp+S6jueOsOaciemhtemdouaVsO+8jOWImei/lOWbnuWIsOmmlumhtSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSwgJ25vbmUnKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKHJlcy5jYW5jZWwpIHt9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH07XHJcbiAgICB9XHJcbiJdfQ==