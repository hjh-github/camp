"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _Lang = require('./../../utils/Lang.js');

var _Lang2 = _interopRequireDefault(_Lang);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _Validate = require('./../../utils/Validate.js');

var _Validate2 = _interopRequireDefault(_Validate);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
    _inherits(Dialog, _wepy$page);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
            navigationBarTitleText: "儿童信息编辑"
        }, _this.data = {
            modalName: '',
            gues: [],
            picker: [{
                name: '内地身份证号',
                type: 1
            }, {
                name: '护照号',
                type: 2
            }, {
                name: '军官证号',
                type: 3
            }, {
                name: '港澳通行证号',
                type: 4
            }, {
                name: '台胞证号',
                type: 5
            }, {
                name: '其他证号',
                type: 6
            }],
            cardInx: 0,
            manInx: 0,
            id: '',
            birthdayStr: "2015-09-01",
            end_date: '',
            form: {
                name: '',
                cardType: 1,
                cardNum: '',
                gender: 1,
                birthdayStr: '',
                height: '',
                weight: '',
                shapes: 1,
                guardianId: ''
            },
            rules: [{
                name: 'name',
                msg: '请填写儿童姓名'
            }, {
                name: 'cardNum',
                msg: '请填写儿童证件号码'
            }, {
                name: 'height',
                msg: '请填写儿童身高'
            }, {
                name: 'weight',
                msg: '请填写儿童体重'
            }, {
                name: 'guardianId',
                msg: '请选择一位监护人'
            }],
            isload: true
        }, _this.methods = {
            gender: function gender(_gender) {
                this.form.gender = _gender;
            },
            tips: function tips() {
                this.modalName = 'tips';
            },
            hideModal: function hideModal() {
                this.modalName = '';
            },
            PickerChange: function PickerChange(e) {
                this.cardInx = e.detail.value;
                this.form.cardType = this.picker[this.cardInx].type;
            },
            checkMan: function checkMan(inx) {
                this.manInx = inx;
                this.form.guardianId = this.gues[this.manInx].id;
            },
            toEdit: function toEdit(id) {
                _wepy2.default.navigateTo({
                    url: './addMan?id=' + id
                });
            },
            DateChange: function DateChange(e) {
                this.form.birthdayStr = e.detail.value;
            },
            input: function input(e) {
                var target = e.currentTarget.dataset.target || e.target.dataset.target,
                    type = e.currentTarget.dataset.type || e.target.dataset.type,
                    value = e.detail.value;
                if (target == 'cardNum' && type == 1) {
                    if (value.length == 18) {
                        var _res = _Lang2.default.getBirthdayByIdCard(value);
                        if ((typeof _res === "undefined" ? "undefined" : _typeof(_res)) == 'object') {
                            _Tips2.default.toast(_res.message, function () {}, 'none');
                        } else if (typeof _res == 'string') {
                            this.form.birthdayStr = _res;
                        }
                        this.form.gender = _Lang2.default.getSexByIdCard(value);
                    }
                }
                this.form[target] = value;
            },
            plus: function () {
                var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
                    var rules, sg, tz, res;
                    return regeneratorRuntime.wrap(function _callee$(_context) {
                        while (1) {
                            switch (_context.prev = _context.next) {
                                case 0:
                                    if (!this.rulesFn()) {
                                        _context.next = 18;
                                        break;
                                    }

                                    console.log(this.form);

                                    if (!(this.form.cardType == 1)) {
                                        _context.next = 7;
                                        break;
                                    }

                                    rules = _Lang2.default.checkIdCard(this.form.cardNum);

                                    if (rules.status) {
                                        _context.next = 7;
                                        break;
                                    }

                                    _Tips2.default.toast(rules.message, function () {}, 'none');
                                    return _context.abrupt("return", false);

                                case 7:
                                    sg = _Validate2.default.digits(this.form.height), tz = _Validate2.default.digits(this.form.weight);

                                    if (sg) {
                                        _context.next = 11;
                                        break;
                                    }

                                    _Tips2.default.toast('请填写整数的身高', function () {}, 'none');
                                    return _context.abrupt("return", false);

                                case 11:
                                    if (tz) {
                                        _context.next = 14;
                                        break;
                                    }

                                    _Tips2.default.toast('请填写整数的体重', function () {}, 'none');
                                    return _context.abrupt("return", false);

                                case 14:
                                    _context.next = 16;
                                    return _config2.default.updateChild(this.form);

                                case 16:
                                    res = _context.sent;

                                    if (res.errcode == 200) {
                                        _Tips2.default.toast('保存成功', function () {
                                            _wepy2.default.navigateBack({
                                                delta: 1 //返回的页面数，如果 delta 大于现有页面数，则返回到首页,
                                            });
                                        }, 'none');
                                    }

                                case 18:
                                case "end":
                                    return _context.stop();
                            }
                        }
                    }, _callee, this);
                }));

                function plus() {
                    return _ref2.apply(this, arguments);
                }

                return plus;
            }(),
            delChild: function () {
                var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
                    var self;
                    return regeneratorRuntime.wrap(function _callee3$(_context3) {
                        while (1) {
                            switch (_context3.prev = _context3.next) {
                                case 0:
                                    self = this;

                                    wx.showModal({
                                        content: "\u786E\u5B9A\u5220\u9664" + self.form.name + "\u7684\u513F\u7AE5\u4FE1\u606F\u5417\uFF1F",
                                        success: function () {
                                            var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(res) {
                                                var _res2;

                                                return regeneratorRuntime.wrap(function _callee2$(_context2) {
                                                    while (1) {
                                                        switch (_context2.prev = _context2.next) {
                                                            case 0:
                                                                if (!res.confirm) {
                                                                    _context2.next = 7;
                                                                    break;
                                                                }

                                                                _context2.next = 3;
                                                                return _config2.default.delChild(self.id);

                                                            case 3:
                                                                _res2 = _context2.sent;

                                                                if (_res2.errcode == 200) {
                                                                    _Tips2.default.toast('删除成功', function () {
                                                                        _wepy2.default.navigateBack({
                                                                            delta: 1 //返回的页面数，如果 delta 大于现有页面数，则返回到首页,
                                                                        });
                                                                    }, 'none');
                                                                }
                                                                _context2.next = 8;
                                                                break;

                                                            case 7:
                                                                if (res.cancel) {}

                                                            case 8:
                                                            case "end":
                                                                return _context2.stop();
                                                        }
                                                    }
                                                }, _callee2, this);
                                            }));

                                            function success(_x) {
                                                return _ref4.apply(this, arguments);
                                            }

                                            return success;
                                        }()
                                    });

                                case 2:
                                case "end":
                                    return _context3.stop();
                            }
                        }
                    }, _callee3, this);
                }));

                function delChild() {
                    return _ref3.apply(this, arguments);
                }

                return delChild;
            }()
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(Dialog, [{
        key: "onLoad",
        value: function () {
            var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4(opt) {
                return regeneratorRuntime.wrap(function _callee4$(_context4) {
                    while (1) {
                        switch (_context4.prev = _context4.next) {
                            case 0:
                                this.id = opt.id;
                                this.end_date = _Lang2.default.dateFormate(new Date(), 'yyyy-MM-dd');
                                _context4.next = 4;
                                return this.updata();

                            case 4:
                                if (this.id == -1) {
                                    this.form.birthdayStr = this.end_date;
                                }
                                this.isload = false;

                            case 6:
                            case "end":
                                return _context4.stop();
                        }
                    }
                }, _callee4, this);
            }));

            function onLoad(_x2) {
                return _ref5.apply(this, arguments);
            }

            return onLoad;
        }()
    }, {
        key: "onShow",
        value: function onShow() {
            if (this.isload) {
                return false;
            }
            this.updata();
        }
    }, {
        key: "updata",
        value: function () {
            var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
                var _this2 = this;

                return regeneratorRuntime.wrap(function _callee5$(_context5) {
                    while (1) {
                        switch (_context5.prev = _context5.next) {
                            case 0:
                                _context5.next = 2;
                                return this.getGuaList();

                            case 2:
                                if (!(this.id != '-1')) {
                                    _context5.next = 5;
                                    break;
                                }

                                _context5.next = 5;
                                return this.getChild(this.id);

                            case 5:
                                // 重新选中，监护人项
                                if (this.gues.length) {
                                    if (this.form.guardianId) {
                                        this.manInx = this.gues.findIndex(function (e) {
                                            return e.id == _this2.form.guardianId;
                                        });
                                    } else {
                                        this.form.guardianId = this.gues[this.manInx].id;
                                    }
                                }
                                this.$apply();

                            case 7:
                            case "end":
                                return _context5.stop();
                        }
                    }
                }, _callee5, this);
            }));

            function updata() {
                return _ref6.apply(this, arguments);
            }

            return updata;
        }()
    }, {
        key: "getGuaList",
        value: function () {
            var _ref7 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
                var _ref8, guaList;

                return regeneratorRuntime.wrap(function _callee6$(_context6) {
                    while (1) {
                        switch (_context6.prev = _context6.next) {
                            case 0:
                                _context6.next = 2;
                                return _config2.default.getGuaList();

                            case 2:
                                _ref8 = _context6.sent;
                                guaList = _ref8.guaList;

                                this.gues = guaList;
                                this.$apply();

                            case 6:
                            case "end":
                                return _context6.stop();
                        }
                    }
                }, _callee6, this);
            }));

            function getGuaList() {
                return _ref7.apply(this, arguments);
            }

            return getGuaList;
        }()
    }, {
        key: "getChild",
        value: function () {
            var _ref9 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee7(id) {
                var res;
                return regeneratorRuntime.wrap(function _callee7$(_context7) {
                    while (1) {
                        switch (_context7.prev = _context7.next) {
                            case 0:
                                _context7.next = 2;
                                return _config2.default.getChild(id);

                            case 2:
                                res = _context7.sent;

                                this.form = {
                                    name: res.name,
                                    cardType: res.cardType,
                                    cardNum: res.cardNum,
                                    gender: res.gender,
                                    birthdayStr: res.birthday,
                                    height: res.height,
                                    weight: res.weight,
                                    shapes: res.shapes,
                                    guardianId: res.guardianId,
                                    id: res.id
                                };

                            case 4:
                            case "end":
                                return _context7.stop();
                        }
                    }
                }, _callee7, this);
            }));

            function getChild(_x3) {
                return _ref9.apply(this, arguments);
            }

            return getChild;
        }()
    }, {
        key: "rulesFn",
        value: function rulesFn() {
            var flag = true;
            var _iteratorNormalCompletion = true;
            var _didIteratorError = false;
            var _iteratorError = undefined;

            try {
                for (var _iterator = this.rules[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
                    var i = _step.value;

                    if (_Lang2.default.isEmpty(this.form[i.name])) {
                        _Tips2.default.toast(i.msg, function () {}, 'none');
                        flag = false;
                        break;
                    }
                }
            } catch (err) {
                _didIteratorError = true;
                _iteratorError = err;
            } finally {
                try {
                    if (!_iteratorNormalCompletion && _iterator.return) {
                        _iterator.return();
                    }
                } finally {
                    if (_didIteratorError) {
                        throw _iteratorError;
                    }
                }
            }

            return flag;
        }
    }]);

    return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/meet/addChild'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFkZENoaWxkLmpzIl0sIm5hbWVzIjpbIkRpYWxvZyIsImNvbmZpZyIsIm5hdmlnYXRpb25CYXJUaXRsZVRleHQiLCJkYXRhIiwibW9kYWxOYW1lIiwiZ3VlcyIsInBpY2tlciIsIm5hbWUiLCJ0eXBlIiwiY2FyZElueCIsIm1hbklueCIsImlkIiwiYmlydGhkYXlTdHIiLCJlbmRfZGF0ZSIsImZvcm0iLCJjYXJkVHlwZSIsImNhcmROdW0iLCJnZW5kZXIiLCJoZWlnaHQiLCJ3ZWlnaHQiLCJzaGFwZXMiLCJndWFyZGlhbklkIiwicnVsZXMiLCJtc2ciLCJpc2xvYWQiLCJtZXRob2RzIiwidGlwcyIsImhpZGVNb2RhbCIsIlBpY2tlckNoYW5nZSIsImUiLCJkZXRhaWwiLCJ2YWx1ZSIsImNoZWNrTWFuIiwiaW54IiwidG9FZGl0Iiwid2VweSIsIm5hdmlnYXRlVG8iLCJ1cmwiLCJEYXRlQ2hhbmdlIiwiaW5wdXQiLCJ0YXJnZXQiLCJjdXJyZW50VGFyZ2V0IiwiZGF0YXNldCIsImxlbmd0aCIsIl9yZXMiLCJMYW5nIiwiZ2V0QmlydGhkYXlCeUlkQ2FyZCIsIlRpcHMiLCJ0b2FzdCIsIm1lc3NhZ2UiLCJnZXRTZXhCeUlkQ2FyZCIsInBsdXMiLCJydWxlc0ZuIiwiY29uc29sZSIsImxvZyIsImNoZWNrSWRDYXJkIiwic3RhdHVzIiwic2ciLCJWYWxpZGF0ZSIsImRpZ2l0cyIsInR6IiwidXBkYXRlQ2hpbGQiLCJyZXMiLCJlcnJjb2RlIiwibmF2aWdhdGVCYWNrIiwiZGVsdGEiLCJkZWxDaGlsZCIsInNlbGYiLCJ3eCIsInNob3dNb2RhbCIsImNvbnRlbnQiLCJzdWNjZXNzIiwiY29uZmlybSIsImNhbmNlbCIsIm9wdCIsImRhdGVGb3JtYXRlIiwiRGF0ZSIsInVwZGF0YSIsImdldEd1YUxpc3QiLCJnZXRDaGlsZCIsImZpbmRJbmRleCIsIiRhcHBseSIsImd1YUxpc3QiLCJiaXJ0aGRheSIsImZsYWciLCJpIiwiaXNFbXB0eSIsInBhZ2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7O0FBQ0k7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7Ozs7Ozs7Ozs7Ozs7SUFDcUJBLE07Ozs7Ozs7Ozs7Ozs7OzBMQUNqQkMsTSxHQUFTO0FBQ0xDLG9DQUF3QjtBQURuQixTLFFBR1RDLEksR0FBTztBQUNIQyx1QkFBVyxFQURSO0FBRUhDLGtCQUFNLEVBRkg7QUFHSEMsb0JBQVEsQ0FBQztBQUNMQyxzQkFBTSxRQUREO0FBRUxDLHNCQUFNO0FBRkQsYUFBRCxFQUdMO0FBQ0NELHNCQUFNLEtBRFA7QUFFQ0Msc0JBQU07QUFGUCxhQUhLLEVBTUw7QUFDQ0Qsc0JBQU0sTUFEUDtBQUVDQyxzQkFBTTtBQUZQLGFBTkssRUFTTDtBQUNDRCxzQkFBTSxRQURQO0FBRUNDLHNCQUFNO0FBRlAsYUFUSyxFQVlMO0FBQ0NELHNCQUFNLE1BRFA7QUFFQ0Msc0JBQU07QUFGUCxhQVpLLEVBZUw7QUFDQ0Qsc0JBQU0sTUFEUDtBQUVDQyxzQkFBTTtBQUZQLGFBZkssQ0FITDtBQXNCSEMscUJBQVMsQ0F0Qk47QUF1QkhDLG9CQUFRLENBdkJMO0FBd0JIQyxnQkFBSSxFQXhCRDtBQXlCSEMseUJBQWEsWUF6QlY7QUEwQkhDLHNCQUFVLEVBMUJQO0FBMkJIQyxrQkFBTTtBQUNGUCxzQkFBTSxFQURKO0FBRUZRLDBCQUFVLENBRlI7QUFHRkMseUJBQVMsRUFIUDtBQUlGQyx3QkFBUSxDQUpOO0FBS0ZMLDZCQUFhLEVBTFg7QUFNRk0sd0JBQVEsRUFOTjtBQU9GQyx3QkFBUSxFQVBOO0FBUUZDLHdCQUFRLENBUk47QUFTRkMsNEJBQVk7QUFUVixhQTNCSDtBQXNDSEMsbUJBQU8sQ0FBQztBQUNBZixzQkFBTSxNQUROO0FBRUFnQixxQkFBSztBQUZMLGFBQUQsRUFJSDtBQUNJaEIsc0JBQU0sU0FEVjtBQUVJZ0IscUJBQUs7QUFGVCxhQUpHLEVBUUg7QUFDSWhCLHNCQUFNLFFBRFY7QUFFSWdCLHFCQUFLO0FBRlQsYUFSRyxFQVdBO0FBQ0NoQixzQkFBTSxRQURQO0FBRUNnQixxQkFBSztBQUZOLGFBWEEsRUFjQTtBQUNDaEIsc0JBQU0sWUFEUDtBQUVDZ0IscUJBQUs7QUFGTixhQWRBLENBdENKO0FBeURIQyxvQkFBUTtBQXpETCxTLFFBNEhQQyxPLEdBQVU7QUFDTlIsa0JBRE0sa0JBQ0NBLE9BREQsRUFDUztBQUNYLHFCQUFLSCxJQUFMLENBQVVHLE1BQVYsR0FBbUJBLE9BQW5CO0FBQ0gsYUFISztBQUlOUyxnQkFKTSxrQkFJQztBQUNILHFCQUFLdEIsU0FBTCxHQUFpQixNQUFqQjtBQUNILGFBTks7QUFPTnVCLHFCQVBNLHVCQU9NO0FBQ1IscUJBQUt2QixTQUFMLEdBQWlCLEVBQWpCO0FBQ0gsYUFUSztBQVVOd0Isd0JBVk0sd0JBVU9DLENBVlAsRUFVVTtBQUNaLHFCQUFLcEIsT0FBTCxHQUFlb0IsRUFBRUMsTUFBRixDQUFTQyxLQUF4QjtBQUNBLHFCQUFLakIsSUFBTCxDQUFVQyxRQUFWLEdBQXFCLEtBQUtULE1BQUwsQ0FBWSxLQUFLRyxPQUFqQixFQUEwQkQsSUFBL0M7QUFDSCxhQWJLO0FBY053QixvQkFkTSxvQkFjR0MsR0FkSCxFQWNRO0FBQ1YscUJBQUt2QixNQUFMLEdBQWN1QixHQUFkO0FBQ0EscUJBQUtuQixJQUFMLENBQVVPLFVBQVYsR0FBdUIsS0FBS2hCLElBQUwsQ0FBVSxLQUFLSyxNQUFmLEVBQXVCQyxFQUE5QztBQUNILGFBakJLO0FBa0JOdUIsa0JBbEJNLGtCQWtCQ3ZCLEVBbEJELEVBa0JLO0FBQ1B3QiwrQkFBS0MsVUFBTCxDQUFnQjtBQUNaQyx5QkFBSyxpQkFBaUIxQjtBQURWLGlCQUFoQjtBQUdILGFBdEJLO0FBdUJOMkIsc0JBdkJNLHNCQXVCS1QsQ0F2QkwsRUF1QlE7QUFDVixxQkFBS2YsSUFBTCxDQUFVRixXQUFWLEdBQXdCaUIsRUFBRUMsTUFBRixDQUFTQyxLQUFqQztBQUNILGFBekJLO0FBMEJOUSxpQkExQk0saUJBMEJBVixDQTFCQSxFQTBCRztBQUNMLG9CQUFJVyxTQUFTWCxFQUFFWSxhQUFGLENBQWdCQyxPQUFoQixDQUF3QkYsTUFBeEIsSUFBa0NYLEVBQUVXLE1BQUYsQ0FBU0UsT0FBVCxDQUFpQkYsTUFBaEU7QUFBQSxvQkFDSWhDLE9BQU9xQixFQUFFWSxhQUFGLENBQWdCQyxPQUFoQixDQUF3QmxDLElBQXhCLElBQWdDcUIsRUFBRVcsTUFBRixDQUFTRSxPQUFULENBQWlCbEMsSUFENUQ7QUFBQSxvQkFFSXVCLFFBQVFGLEVBQUVDLE1BQUYsQ0FBU0MsS0FGckI7QUFHQSxvQkFBSVMsVUFBVSxTQUFWLElBQXVCaEMsUUFBUSxDQUFuQyxFQUFzQztBQUNsQyx3QkFBSXVCLE1BQU1ZLE1BQU4sSUFBZ0IsRUFBcEIsRUFBd0I7QUFDcEIsNEJBQUlDLE9BQU9DLGVBQUtDLG1CQUFMLENBQXlCZixLQUF6QixDQUFYO0FBQ0EsNEJBQUksUUFBT2EsSUFBUCx5Q0FBT0EsSUFBUCxNQUFlLFFBQW5CLEVBQTZCO0FBQ3pCRywyQ0FBS0MsS0FBTCxDQUFXSixLQUFLSyxPQUFoQixFQUF5QixZQUFNLENBQUUsQ0FBakMsRUFBbUMsTUFBbkM7QUFDSCx5QkFGRCxNQUVPLElBQUksT0FBT0wsSUFBUCxJQUFlLFFBQW5CLEVBQTZCO0FBQ2hDLGlDQUFLOUIsSUFBTCxDQUFVRixXQUFWLEdBQXdCZ0MsSUFBeEI7QUFDSDtBQUNELDZCQUFLOUIsSUFBTCxDQUFVRyxNQUFWLEdBQW1CNEIsZUFBS0ssY0FBTCxDQUFvQm5CLEtBQXBCLENBQW5CO0FBQ0g7QUFDSjtBQUNELHFCQUFLakIsSUFBTCxDQUFVMEIsTUFBVixJQUFvQlQsS0FBcEI7QUFDSCxhQTFDSztBQTJDQW9CLGdCQTNDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlDQTRDRSxLQUFLQyxPQUFMLEVBNUNGO0FBQUE7QUFBQTtBQUFBOztBQTZDRUMsNENBQVFDLEdBQVIsQ0FBWSxLQUFLeEMsSUFBakI7O0FBN0NGLDBDQThDTSxLQUFLQSxJQUFMLENBQVVDLFFBQVYsSUFBc0IsQ0E5QzVCO0FBQUE7QUFBQTtBQUFBOztBQStDVU8seUNBL0NWLEdBK0NrQnVCLGVBQUtVLFdBQUwsQ0FBaUIsS0FBS3pDLElBQUwsQ0FBVUUsT0FBM0IsQ0EvQ2xCOztBQUFBLHdDQWdEV00sTUFBTWtDLE1BaERqQjtBQUFBO0FBQUE7QUFBQTs7QUFpRFVULG1EQUFLQyxLQUFMLENBQVcxQixNQUFNMkIsT0FBakIsRUFBMEIsWUFBTSxDQUFFLENBQWxDLEVBQW9DLE1BQXBDO0FBakRWLHFFQWtEaUIsS0FsRGpCOztBQUFBO0FBcURNUSxzQ0FyRE4sR0FxRFdDLG1CQUFTQyxNQUFULENBQWdCLEtBQUs3QyxJQUFMLENBQVVJLE1BQTFCLENBckRYLEVBc0RNMEMsRUF0RE4sR0FzRFdGLG1CQUFTQyxNQUFULENBQWdCLEtBQUs3QyxJQUFMLENBQVVLLE1BQTFCLENBdERYOztBQUFBLHdDQXVET3NDLEVBdkRQO0FBQUE7QUFBQTtBQUFBOztBQXdETVYsbURBQUtDLEtBQUwsQ0FBVyxVQUFYLEVBQXVCLFlBQU0sQ0FBRSxDQUEvQixFQUFpQyxNQUFqQztBQXhETixxRUF5RGEsS0F6RGI7O0FBQUE7QUFBQSx3Q0EyRE9ZLEVBM0RQO0FBQUE7QUFBQTtBQUFBOztBQTRETWIsbURBQUtDLEtBQUwsQ0FBVyxVQUFYLEVBQXVCLFlBQU0sQ0FBRSxDQUEvQixFQUFpQyxNQUFqQztBQTVETixxRUE2RGEsS0E3RGI7O0FBQUE7QUFBQTtBQUFBLDJDQStEa0IvQyxpQkFBTzRELFdBQVAsQ0FBbUIsS0FBSy9DLElBQXhCLENBL0RsQjs7QUFBQTtBQStETWdELHVDQS9ETjs7QUFnRUUsd0NBQUlBLElBQUlDLE9BQUosSUFBZSxHQUFuQixFQUF3QjtBQUNwQmhCLHVEQUFLQyxLQUFMLENBQVcsTUFBWCxFQUFtQixZQUFNO0FBQ3JCYiwyREFBSzZCLFlBQUwsQ0FBa0I7QUFDZEMsdURBQU8sQ0FETyxDQUNMO0FBREssNkNBQWxCO0FBR0gseUNBSkQsRUFJRyxNQUpIO0FBS0g7O0FBdEVIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBeUVBQyxvQkF6RUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUEwRUVDLHdDQTFFRixHQTBFUyxJQTFFVDs7QUEyRUZDLHVDQUFHQyxTQUFILENBQWE7QUFDVEMsOEVBQWdCSCxLQUFLckQsSUFBTCxDQUFVUCxJQUExQiwrQ0FEUztBQUVUZ0U7QUFBQSxnSEFBUyxrQkFBZVQsR0FBZjtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUVBQ0RBLElBQUlVLE9BREg7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQSx1RUFFZXZFLGlCQUFPaUUsUUFBUCxDQUFnQkMsS0FBS3hELEVBQXJCLENBRmY7O0FBQUE7QUFFR21ELHFFQUZIOztBQUdELG9FQUFJQSxNQUFJQyxPQUFKLElBQWUsR0FBbkIsRUFBd0I7QUFDcEJoQixtRkFBS0MsS0FBTCxDQUFXLE1BQVgsRUFBbUIsWUFBTTtBQUNyQmIsdUZBQUs2QixZQUFMLENBQWtCO0FBQ2RDLG1GQUFPLENBRE8sQ0FDTDtBQURLLHlFQUFsQjtBQUdILHFFQUpELEVBSUcsTUFKSDtBQUtIO0FBVEE7QUFBQTs7QUFBQTtBQVVFLG9FQUFJSCxJQUFJVyxNQUFSLEVBQWdCLENBQUU7O0FBVnBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZDQUFUOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBRlMscUNBQWI7O0FBM0VFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUEsUzs7Ozs7O2tHQWpFR0MsRzs7Ozs7QUFDVCxxQ0FBSy9ELEVBQUwsR0FBVStELElBQUkvRCxFQUFkO0FBQ0EscUNBQUtFLFFBQUwsR0FBZ0JnQyxlQUFLOEIsV0FBTCxDQUFpQixJQUFJQyxJQUFKLEVBQWpCLEVBQTZCLFlBQTdCLENBQWhCOzt1Q0FDTSxLQUFLQyxNQUFMLEU7OztBQUNOLG9DQUFJLEtBQUtsRSxFQUFMLElBQVcsQ0FBQyxDQUFoQixFQUFtQjtBQUNmLHlDQUFLRyxJQUFMLENBQVVGLFdBQVYsR0FBd0IsS0FBS0MsUUFBN0I7QUFDSDtBQUNELHFDQUFLVyxNQUFMLEdBQWMsS0FBZDs7Ozs7Ozs7Ozs7Ozs7Ozs7O2lDQUVLO0FBQ0wsZ0JBQUksS0FBS0EsTUFBVCxFQUFpQjtBQUNiLHVCQUFPLEtBQVA7QUFDSDtBQUNELGlCQUFLcUQsTUFBTDtBQUNIOzs7Ozs7Ozs7Ozs7dUNBRVMsS0FBS0MsVUFBTCxFOzs7c0NBQ0YsS0FBS25FLEVBQUwsSUFBVyxJOzs7Ozs7dUNBQ0wsS0FBS29FLFFBQUwsQ0FBYyxLQUFLcEUsRUFBbkIsQzs7O0FBRVY7QUFDQSxvQ0FBSSxLQUFLTixJQUFMLENBQVVzQyxNQUFkLEVBQXNCO0FBQ2xCLHdDQUFJLEtBQUs3QixJQUFMLENBQVVPLFVBQWQsRUFBMEI7QUFDdEIsNkNBQUtYLE1BQUwsR0FBYyxLQUFLTCxJQUFMLENBQVUyRSxTQUFWLENBQW9CLGFBQUs7QUFDbkMsbURBQU9uRCxFQUFFbEIsRUFBRixJQUFRLE9BQUtHLElBQUwsQ0FBVU8sVUFBekI7QUFDSCx5Q0FGYSxDQUFkO0FBR0gscUNBSkQsTUFJTztBQUNILDZDQUFLUCxJQUFMLENBQVVPLFVBQVYsR0FBdUIsS0FBS2hCLElBQUwsQ0FBVSxLQUFLSyxNQUFmLEVBQXVCQyxFQUE5QztBQUNIO0FBQ0o7QUFDRCxxQ0FBS3NFLE1BQUw7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozt1Q0FLVWhGLGlCQUFPNkUsVUFBUCxFOzs7O0FBRE5JLHVDLFNBQUFBLE87O0FBRUoscUNBQUs3RSxJQUFMLEdBQVk2RSxPQUFaO0FBQ0EscUNBQUtELE1BQUw7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7a0dBRVd0RSxFOzs7Ozs7O3VDQUNLVixpQkFBTzhFLFFBQVAsQ0FBZ0JwRSxFQUFoQixDOzs7QUFBWm1ELG1DOztBQUNKLHFDQUFLaEQsSUFBTCxHQUFZO0FBQ1JQLDBDQUFNdUQsSUFBSXZELElBREY7QUFFUlEsOENBQVUrQyxJQUFJL0MsUUFGTjtBQUdSQyw2Q0FBUzhDLElBQUk5QyxPQUhMO0FBSVJDLDRDQUFRNkMsSUFBSTdDLE1BSko7QUFLUkwsaURBQWFrRCxJQUFJcUIsUUFMVDtBQU1SakUsNENBQVE0QyxJQUFJNUMsTUFOSjtBQU9SQyw0Q0FBUTJDLElBQUkzQyxNQVBKO0FBUVJDLDRDQUFRMEMsSUFBSTFDLE1BUko7QUFTUkMsZ0RBQVl5QyxJQUFJekMsVUFUUjtBQVVSVix3Q0FBSW1ELElBQUluRDtBQVZBLGlDQUFaOzs7Ozs7Ozs7Ozs7Ozs7Ozs7a0NBYU07QUFDTixnQkFBSXlFLE9BQU8sSUFBWDtBQURNO0FBQUE7QUFBQTs7QUFBQTtBQUVOLHFDQUFjLEtBQUs5RCxLQUFuQiw4SEFBMEI7QUFBQSx3QkFBakIrRCxDQUFpQjs7QUFDdEIsd0JBQUl4QyxlQUFLeUMsT0FBTCxDQUFhLEtBQUt4RSxJQUFMLENBQVV1RSxFQUFFOUUsSUFBWixDQUFiLENBQUosRUFBcUM7QUFDakN3Qyx1Q0FBS0MsS0FBTCxDQUFXcUMsRUFBRTlELEdBQWIsRUFBa0IsWUFBTSxDQUFFLENBQTFCLEVBQTRCLE1BQTVCO0FBQ0E2RCwrQkFBTyxLQUFQO0FBQ0E7QUFDSDtBQUNKO0FBUks7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFTTixtQkFBT0EsSUFBUDtBQUNIOzs7O0VBL0grQmpELGVBQUtvRCxJOztrQkFBcEJ2RixNIiwiZmlsZSI6ImFkZENoaWxkLmpzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbiAgICBpbXBvcnQgd2VweSBmcm9tIFwid2VweVwiXHJcbiAgICBpbXBvcnQgTGFuZyBmcm9tIFwiQC91dGlscy9MYW5nXCJcclxuICAgIGltcG9ydCBUaXBzIGZyb20gXCJAL3V0aWxzL1RpcHNcIlxyXG4gICAgaW1wb3J0IGNvbmZpZyBmcm9tIFwiQC9hcGkvY29uZmlnXCJcclxuICAgIGltcG9ydCBWYWxpZGF0ZSBmcm9tIFwiQC91dGlscy9WYWxpZGF0ZVwiXHJcbiAgICBleHBvcnQgZGVmYXVsdCBjbGFzcyBEaWFsb2cgZXh0ZW5kcyB3ZXB5LnBhZ2Uge1xyXG4gICAgICAgIGNvbmZpZyA9IHtcclxuICAgICAgICAgICAgbmF2aWdhdGlvbkJhclRpdGxlVGV4dDogXCLlhL/nq6Xkv6Hmga/nvJbovpFcIlxyXG4gICAgICAgIH07XHJcbiAgICAgICAgZGF0YSA9IHtcclxuICAgICAgICAgICAgbW9kYWxOYW1lOiAnJyxcclxuICAgICAgICAgICAgZ3VlczogW10sXHJcbiAgICAgICAgICAgIHBpY2tlcjogW3tcclxuICAgICAgICAgICAgICAgIG5hbWU6ICflhoXlnLDouqvku73or4Hlj7cnLFxyXG4gICAgICAgICAgICAgICAgdHlwZTogMVxyXG4gICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICBuYW1lOiAn5oqk54Wn5Y+3JyxcclxuICAgICAgICAgICAgICAgIHR5cGU6IDJcclxuICAgICAgICAgICAgfSwge1xyXG4gICAgICAgICAgICAgICAgbmFtZTogJ+WGm+WumOivgeWPtycsXHJcbiAgICAgICAgICAgICAgICB0eXBlOiAzXHJcbiAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgIG5hbWU6ICfmuK/mvrPpgJrooYzor4Hlj7cnLFxyXG4gICAgICAgICAgICAgICAgdHlwZTogNFxyXG4gICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICBuYW1lOiAn5Y+w6IOe6K+B5Y+3JyxcclxuICAgICAgICAgICAgICAgIHR5cGU6IDVcclxuICAgICAgICAgICAgfSwge1xyXG4gICAgICAgICAgICAgICAgbmFtZTogJ+WFtuS7luivgeWPtycsXHJcbiAgICAgICAgICAgICAgICB0eXBlOiA2XHJcbiAgICAgICAgICAgIH0sIF0sXHJcbiAgICAgICAgICAgIGNhcmRJbng6IDAsXHJcbiAgICAgICAgICAgIG1hbklueDogMCxcclxuICAgICAgICAgICAgaWQ6ICcnLFxyXG4gICAgICAgICAgICBiaXJ0aGRheVN0cjogXCIyMDE1LTA5LTAxXCIsXHJcbiAgICAgICAgICAgIGVuZF9kYXRlOiAnJyxcclxuICAgICAgICAgICAgZm9ybToge1xyXG4gICAgICAgICAgICAgICAgbmFtZTogJycsXHJcbiAgICAgICAgICAgICAgICBjYXJkVHlwZTogMSxcclxuICAgICAgICAgICAgICAgIGNhcmROdW06ICcnLFxyXG4gICAgICAgICAgICAgICAgZ2VuZGVyOiAxLFxyXG4gICAgICAgICAgICAgICAgYmlydGhkYXlTdHI6ICcnLFxyXG4gICAgICAgICAgICAgICAgaGVpZ2h0OiAnJyxcclxuICAgICAgICAgICAgICAgIHdlaWdodDogJycsXHJcbiAgICAgICAgICAgICAgICBzaGFwZXM6IDEsXHJcbiAgICAgICAgICAgICAgICBndWFyZGlhbklkOiAnJ1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBydWxlczogW3tcclxuICAgICAgICAgICAgICAgICAgICBuYW1lOiAnbmFtZScsXHJcbiAgICAgICAgICAgICAgICAgICAgbXNnOiAn6K+35aGr5YaZ5YS/56ul5aeT5ZCNJ1xyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICBuYW1lOiAnY2FyZE51bScsXHJcbiAgICAgICAgICAgICAgICAgICAgbXNnOiAn6K+35aGr5YaZ5YS/56ul6K+B5Lu25Y+356CBJ1xyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICBuYW1lOiAnaGVpZ2h0JyxcclxuICAgICAgICAgICAgICAgICAgICBtc2c6ICfor7floavlhpnlhL/nq6Xouqvpq5gnXHJcbiAgICAgICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZTogJ3dlaWdodCcsXHJcbiAgICAgICAgICAgICAgICAgICAgbXNnOiAn6K+35aGr5YaZ5YS/56ul5L2T6YeNJ1xyXG4gICAgICAgICAgICAgICAgfSwge1xyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU6ICdndWFyZGlhbklkJyxcclxuICAgICAgICAgICAgICAgICAgICBtc2c6ICfor7fpgInmi6nkuIDkvY3nm5HmiqTkuronXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgIGlzbG9hZDogdHJ1ZVxyXG4gICAgICAgIH07XHJcbiAgICAgICAgYXN5bmMgb25Mb2FkKG9wdCkge1xyXG4gICAgICAgICAgICB0aGlzLmlkID0gb3B0LmlkXHJcbiAgICAgICAgICAgIHRoaXMuZW5kX2RhdGUgPSBMYW5nLmRhdGVGb3JtYXRlKG5ldyBEYXRlKCksICd5eXl5LU1NLWRkJylcclxuICAgICAgICAgICAgYXdhaXQgdGhpcy51cGRhdGEoKVxyXG4gICAgICAgICAgICBpZiAodGhpcy5pZCA9PSAtMSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5mb3JtLmJpcnRoZGF5U3RyID0gdGhpcy5lbmRfZGF0ZVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRoaXMuaXNsb2FkID0gZmFsc2VcclxuICAgICAgICB9XHJcbiAgICAgICAgb25TaG93KCkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5pc2xvYWQpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRoaXMudXBkYXRhKClcclxuICAgICAgICB9XHJcbiAgICAgICAgYXN5bmMgdXBkYXRhKCkge1xyXG4gICAgICAgICAgICBhd2FpdCB0aGlzLmdldEd1YUxpc3QoKVxyXG4gICAgICAgICAgICBpZiAodGhpcy5pZCAhPSAnLTEnKSB7XHJcbiAgICAgICAgICAgICAgICBhd2FpdCB0aGlzLmdldENoaWxkKHRoaXMuaWQpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgLy8g6YeN5paw6YCJ5Lit77yM55uR5oqk5Lq66aG5XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmd1ZXMubGVuZ3RoKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5mb3JtLmd1YXJkaWFuSWQpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm1hbklueCA9IHRoaXMuZ3Vlcy5maW5kSW5kZXgoZSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBlLmlkID09IHRoaXMuZm9ybS5ndWFyZGlhbklkXHJcbiAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5mb3JtLmd1YXJkaWFuSWQgPSB0aGlzLmd1ZXNbdGhpcy5tYW5JbnhdLmlkXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgICAgIH1cclxuICAgICAgICBhc3luYyBnZXRHdWFMaXN0KCkge1xyXG4gICAgICAgICAgICBsZXQge1xyXG4gICAgICAgICAgICAgICAgZ3VhTGlzdFxyXG4gICAgICAgICAgICB9ID0gYXdhaXQgY29uZmlnLmdldEd1YUxpc3QoKVxyXG4gICAgICAgICAgICB0aGlzLmd1ZXMgPSBndWFMaXN0XHJcbiAgICAgICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgICB9XHJcbiAgICAgICAgYXN5bmMgZ2V0Q2hpbGQoaWQpIHtcclxuICAgICAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGNvbmZpZy5nZXRDaGlsZChpZClcclxuICAgICAgICAgICAgdGhpcy5mb3JtID0ge1xyXG4gICAgICAgICAgICAgICAgbmFtZTogcmVzLm5hbWUsXHJcbiAgICAgICAgICAgICAgICBjYXJkVHlwZTogcmVzLmNhcmRUeXBlLFxyXG4gICAgICAgICAgICAgICAgY2FyZE51bTogcmVzLmNhcmROdW0sXHJcbiAgICAgICAgICAgICAgICBnZW5kZXI6IHJlcy5nZW5kZXIsXHJcbiAgICAgICAgICAgICAgICBiaXJ0aGRheVN0cjogcmVzLmJpcnRoZGF5LFxyXG4gICAgICAgICAgICAgICAgaGVpZ2h0OiByZXMuaGVpZ2h0LFxyXG4gICAgICAgICAgICAgICAgd2VpZ2h0OiByZXMud2VpZ2h0LFxyXG4gICAgICAgICAgICAgICAgc2hhcGVzOiByZXMuc2hhcGVzLFxyXG4gICAgICAgICAgICAgICAgZ3VhcmRpYW5JZDogcmVzLmd1YXJkaWFuSWQsXHJcbiAgICAgICAgICAgICAgICBpZDogcmVzLmlkXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgcnVsZXNGbigpIHtcclxuICAgICAgICAgICAgbGV0IGZsYWcgPSB0cnVlXHJcbiAgICAgICAgICAgIGZvciAobGV0IGkgb2YgdGhpcy5ydWxlcykge1xyXG4gICAgICAgICAgICAgICAgaWYgKExhbmcuaXNFbXB0eSh0aGlzLmZvcm1baS5uYW1lXSkpIHtcclxuICAgICAgICAgICAgICAgICAgICBUaXBzLnRvYXN0KGkubXNnLCAoKSA9PiB7fSwgJ25vbmUnKVxyXG4gICAgICAgICAgICAgICAgICAgIGZsYWcgPSBmYWxzZVxyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIGZsYWdcclxuICAgICAgICB9XHJcbiAgICAgICAgbWV0aG9kcyA9IHtcclxuICAgICAgICAgICAgZ2VuZGVyKGdlbmRlcikge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5mb3JtLmdlbmRlciA9IGdlbmRlclxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB0aXBzKCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RhbE5hbWUgPSAndGlwcydcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgaGlkZU1vZGFsKCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RhbE5hbWUgPSAnJ1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBQaWNrZXJDaGFuZ2UoZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jYXJkSW54ID0gZS5kZXRhaWwudmFsdWVcclxuICAgICAgICAgICAgICAgIHRoaXMuZm9ybS5jYXJkVHlwZSA9IHRoaXMucGlja2VyW3RoaXMuY2FyZElueF0udHlwZVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBjaGVja01hbihpbngpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMubWFuSW54ID0gaW54XHJcbiAgICAgICAgICAgICAgICB0aGlzLmZvcm0uZ3VhcmRpYW5JZCA9IHRoaXMuZ3Vlc1t0aGlzLm1hbklueF0uaWRcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgdG9FZGl0KGlkKSB7XHJcbiAgICAgICAgICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICAgICAgICAgIHVybDogJy4vYWRkTWFuP2lkPScgKyBpZFxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIERhdGVDaGFuZ2UoZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5mb3JtLmJpcnRoZGF5U3RyID0gZS5kZXRhaWwudmFsdWVcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgaW5wdXQoZSkge1xyXG4gICAgICAgICAgICAgICAgbGV0IHRhcmdldCA9IGUuY3VycmVudFRhcmdldC5kYXRhc2V0LnRhcmdldCB8fCBlLnRhcmdldC5kYXRhc2V0LnRhcmdldCxcclxuICAgICAgICAgICAgICAgICAgICB0eXBlID0gZS5jdXJyZW50VGFyZ2V0LmRhdGFzZXQudHlwZSB8fCBlLnRhcmdldC5kYXRhc2V0LnR5cGUsXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWUgPSBlLmRldGFpbC52YWx1ZTtcclxuICAgICAgICAgICAgICAgIGlmICh0YXJnZXQgPT0gJ2NhcmROdW0nICYmIHR5cGUgPT0gMSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh2YWx1ZS5sZW5ndGggPT0gMTgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IF9yZXMgPSBMYW5nLmdldEJpcnRoZGF5QnlJZENhcmQodmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgX3JlcyA9PSAnb2JqZWN0Jykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVGlwcy50b2FzdChfcmVzLm1lc3NhZ2UsICgpID0+IHt9LCAnbm9uZScpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAodHlwZW9mIF9yZXMgPT0gJ3N0cmluZycpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZm9ybS5iaXJ0aGRheVN0ciA9IF9yZXNcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmZvcm0uZ2VuZGVyID0gTGFuZy5nZXRTZXhCeUlkQ2FyZCh2YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB0aGlzLmZvcm1bdGFyZ2V0XSA9IHZhbHVlXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGFzeW5jIHBsdXMoKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5ydWxlc0ZuKCkpIHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyh0aGlzLmZvcm0pXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuZm9ybS5jYXJkVHlwZSA9PSAxKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBydWxlcyA9IExhbmcuY2hlY2tJZENhcmQodGhpcy5mb3JtLmNhcmROdW0pXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICghcnVsZXMuc3RhdHVzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBUaXBzLnRvYXN0KHJ1bGVzLm1lc3NhZ2UsICgpID0+IHt9LCAnbm9uZScpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBsZXQgc2cgPSBWYWxpZGF0ZS5kaWdpdHModGhpcy5mb3JtLmhlaWdodCksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR6ID0gVmFsaWRhdGUuZGlnaXRzKHRoaXMuZm9ybS53ZWlnaHQpXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFzZykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBUaXBzLnRvYXN0KCfor7floavlhpnmlbTmlbDnmoTouqvpq5gnLCAoKSA9PiB7fSwgJ25vbmUnKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKCF0eikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBUaXBzLnRvYXN0KCfor7floavlhpnmlbTmlbDnmoTkvZPph40nLCAoKSA9PiB7fSwgJ25vbmUnKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGNvbmZpZy51cGRhdGVDaGlsZCh0aGlzLmZvcm0pXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHJlcy5lcnJjb2RlID09IDIwMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBUaXBzLnRvYXN0KCfkv53lrZjmiJDlip8nLCAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB3ZXB5Lm5hdmlnYXRlQmFjayh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVsdGE6IDEgLy/ov5Tlm57nmoTpobXpnaLmlbDvvIzlpoLmnpwgZGVsdGEg5aSn5LqO546w5pyJ6aG16Z2i5pWw77yM5YiZ6L+U5Zue5Yiw6aaW6aG1LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sICdub25lJylcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGFzeW5jIGRlbENoaWxkKCkge1xyXG4gICAgICAgICAgICAgICAgbGV0IHNlbGYgPSB0aGlzXHJcbiAgICAgICAgICAgICAgICB3eC5zaG93TW9kYWwoe1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnRlbnQ6IGDnoa7lrprliKDpmaQke3NlbGYuZm9ybS5uYW1lfeeahOWEv+erpeS/oeaBr+WQl++8n2AsXHJcbiAgICAgICAgICAgICAgICAgICAgc3VjY2VzczogYXN5bmMgZnVuY3Rpb24ocmVzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXMuY29uZmlybSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGNvbmZpZy5kZWxDaGlsZChzZWxmLmlkKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlcy5lcnJjb2RlID09IDIwMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRpcHMudG9hc3QoJ+WIoOmZpOaIkOWKnycsICgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgd2VweS5uYXZpZ2F0ZUJhY2soe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVsdGE6IDEgLy/ov5Tlm57nmoTpobXpnaLmlbDvvIzlpoLmnpwgZGVsdGEg5aSn5LqO546w5pyJ6aG16Z2i5pWw77yM5YiZ6L+U5Zue5Yiw6aaW6aG1LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LCAnbm9uZScpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAocmVzLmNhbmNlbCkge31cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuIl19