"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _Lang = require('./../../utils/Lang.js');

var _Lang2 = _interopRequireDefault(_Lang);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
    _inherits(Dialog, _wepy$page);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
            navigationBarTitleText: "儿童信息编辑"
        }, _this.data = {
            modalName: '',
            gues: [],
            picker: [{
                name: '内地身份证号',
                type: 1
            }, {
                name: '护照号',
                type: 2
            }, {
                name: '军官证号',
                type: 3
            }, {
                name: '港澳通行证号',
                type: 4
            }, {
                name: '台胞证号',
                type: 5
            }, {
                name: '其他证号',
                type: 6
            }],
            cardInx: 0,
            manInx: 0,
            id: '',
            birthdayStr: "2015-09-01",
            end_date: '',
            form: {
                name: '',
                cardType: 1,
                cardNum: '',
                gender: 1,
                birthdayStr: '',
                height: '',
                weight: '',
                shapes: 1,
                guardianId: ''
            },
            rules: [{
                name: 'name',
                msg: '请填写儿童姓名'
            }, {
                name: 'cardNum',
                msg: '请填写儿童证件号码'
            }, {
                name: 'height',
                msg: '请填写儿童身高'
            }, {
                name: 'weight',
                msg: '请填写儿童体重'
            }, {
                name: 'guardianId',
                msg: '请选择一位监护人'
            }],
            isload: true
        }, _this.methods = {
            gender: function gender(_gender) {
                this.form.gender = _gender;
            },
            tips: function tips() {
                this.modalName = 'tips';
            },
            hideModal: function hideModal() {
                this.modalName = '';
            },
            PickerChange: function PickerChange(e) {
                this.cardInx = e.detail.value;
                this.form.cardType = this.picker[this.cardInx].type;
            },
            checkMan: function checkMan(inx) {
                this.manInx = inx;
                this.form.guardianId = this.gues[this.manInx].id;
            },
            toEdit: function toEdit(id) {
                _wepy2.default.navigateTo({
                    url: './addMan?id=' + id
                });
            },
            DateChange: function DateChange(e) {
                this.birthdayStr = e.detail.value;
            },
            input: function input(e) {
                var target = e.currentTarget.dataset.target || e.target.dataset.target,
                    type = e.currentTarget.dataset.type || e.target.dataset.type,
                    value = e.detail.value;
                if (target == 'cardNum' && type == 1) {
                    if (value.length == 18) {
                        var _res = _Lang2.default.getBirthdayByIdCard(value);
                        if ((typeof _res === "undefined" ? "undefined" : _typeof(_res)) == 'object') {
                            _Tips2.default.toast(_res.message, function () {}, 'none');
                        } else if (typeof _res == 'string') {
                            this.form.birthdayStr = _res;
                        }
                        this.form.gender = _Lang2.default.getSexByIdCard(value);
                    }
                }
                this.form[target] = value;
            },
            plus: function () {
                var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
                    var rules, res;
                    return regeneratorRuntime.wrap(function _callee$(_context) {
                        while (1) {
                            switch (_context.prev = _context.next) {
                                case 0:
                                    if (!this.rulesFn()) {
                                        _context.next = 11;
                                        break;
                                    }

                                    console.log(this.form);

                                    if (!(this.form.cardType == 1)) {
                                        _context.next = 7;
                                        break;
                                    }

                                    rules = _Lang2.default.checkIdCard(this.form.cardNum);

                                    if (rules.status) {
                                        _context.next = 7;
                                        break;
                                    }

                                    _Tips2.default.toast(rules.message, function () {}, 'none');
                                    return _context.abrupt("return", false);

                                case 7:
                                    _context.next = 9;
                                    return _config2.default.updateChild(this.form);

                                case 9:
                                    res = _context.sent;

                                    if (res.errcode == 200) {
                                        _Tips2.default.toast('保存成功', function () {
                                            _wepy2.default.navigateBack({
                                                delta: 1 //返回的页面数，如果 delta 大于现有页面数，则返回到首页,
                                            });
                                        }, 'none');
                                    }

                                case 11:
                                case "end":
                                    return _context.stop();
                            }
                        }
                    }, _callee, this);
                }));

                function plus() {
                    return _ref2.apply(this, arguments);
                }

                return plus;
            }(),
            delChild: function () {
                var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
                    var self;
                    return regeneratorRuntime.wrap(function _callee3$(_context3) {
                        while (1) {
                            switch (_context3.prev = _context3.next) {
                                case 0:
                                    self = this;

                                    wx.showModal({
                                        content: "\u786E\u5B9A\u5220\u9664" + self.form.name + "\u7684\u513F\u7AE5\u4FE1\u606F\u5417\uFF1F",
                                        success: function () {
                                            var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(res) {
                                                var _res2;

                                                return regeneratorRuntime.wrap(function _callee2$(_context2) {
                                                    while (1) {
                                                        switch (_context2.prev = _context2.next) {
                                                            case 0:
                                                                if (!res.confirm) {
                                                                    _context2.next = 7;
                                                                    break;
                                                                }

                                                                _context2.next = 3;
                                                                return _config2.default.delChild(self.id);

                                                            case 3:
                                                                _res2 = _context2.sent;

                                                                if (_res2.errcode == 200) {
                                                                    _Tips2.default.toast('删除成功', function () {
                                                                        _wepy2.default.navigateBack({
                                                                            delta: 1 //返回的页面数，如果 delta 大于现有页面数，则返回到首页,
                                                                        });
                                                                    }, 'none');
                                                                }
                                                                _context2.next = 8;
                                                                break;

                                                            case 7:
                                                                if (res.cancel) {}

                                                            case 8:
                                                            case "end":
                                                                return _context2.stop();
                                                        }
                                                    }
                                                }, _callee2, this);
                                            }));

                                            function success(_x) {
                                                return _ref4.apply(this, arguments);
                                            }

                                            return success;
                                        }()
                                    });

                                case 2:
                                case "end":
                                    return _context3.stop();
                            }
                        }
                    }, _callee3, this);
                }));

                function delChild() {
                    return _ref3.apply(this, arguments);
                }

                return delChild;
            }()
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(Dialog, [{
        key: "onLoad",
        value: function () {
            var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4(opt) {
                return regeneratorRuntime.wrap(function _callee4$(_context4) {
                    while (1) {
                        switch (_context4.prev = _context4.next) {
                            case 0:
                                this.id = opt.id;
                                this.end_date = _Lang2.default.dateFormate(new Date(), 'yyyy-MM-dd');
                                _context4.next = 4;
                                return this.updata();

                            case 4:
                                if (this.id == -1) {
                                    this.form.birthdayStr = this.end_date;
                                }
                                this.isload = false;

                            case 6:
                            case "end":
                                return _context4.stop();
                        }
                    }
                }, _callee4, this);
            }));

            function onLoad(_x2) {
                return _ref5.apply(this, arguments);
            }

            return onLoad;
        }()
    }, {
        key: "onShow",
        value: function onShow() {
            if (this.isload) {
                return false;
            }
            this.updata();
        }
    }, {
        key: "updata",
        value: function () {
            var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
                var _this2 = this;

                return regeneratorRuntime.wrap(function _callee5$(_context5) {
                    while (1) {
                        switch (_context5.prev = _context5.next) {
                            case 0:
                                _context5.next = 2;
                                return this.getGuaList();

                            case 2:
                                if (!(this.id != '-1')) {
                                    _context5.next = 5;
                                    break;
                                }

                                _context5.next = 5;
                                return this.getChild(this.id);

                            case 5:
                                // 重新选中，监护人项
                                if (this.gues.length) {
                                    if (this.form.guardianId) {
                                        this.manInx = this.gues.findIndex(function (e) {
                                            return e.id == _this2.form.guardianId;
                                        });
                                    } else {
                                        this.form.guardianId = this.gues[this.manInx].id;
                                    }
                                }
                                this.$apply();

                            case 7:
                            case "end":
                                return _context5.stop();
                        }
                    }
                }, _callee5, this);
            }));

            function updata() {
                return _ref6.apply(this, arguments);
            }

            return updata;
        }()
    }, {
        key: "getGuaList",
        value: function () {
            var _ref7 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
                var _ref8, guaList;

                return regeneratorRuntime.wrap(function _callee6$(_context6) {
                    while (1) {
                        switch (_context6.prev = _context6.next) {
                            case 0:
                                _context6.next = 2;
                                return _config2.default.getGuaList();

                            case 2:
                                _ref8 = _context6.sent;
                                guaList = _ref8.guaList;

                                this.gues = guaList;
                                this.$apply();

                            case 6:
                            case "end":
                                return _context6.stop();
                        }
                    }
                }, _callee6, this);
            }));

            function getGuaList() {
                return _ref7.apply(this, arguments);
            }

            return getGuaList;
        }()
    }, {
        key: "getChild",
        value: function () {
            var _ref9 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee7(id) {
                var res;
                return regeneratorRuntime.wrap(function _callee7$(_context7) {
                    while (1) {
                        switch (_context7.prev = _context7.next) {
                            case 0:
                                _context7.next = 2;
                                return _config2.default.getChild(id);

                            case 2:
                                res = _context7.sent;

                                this.form = {
                                    name: res.name,
                                    cardType: res.cardType,
                                    cardNum: res.cardNum,
                                    gender: res.gender,
                                    birthdayStr: res.birthday,
                                    height: res.height,
                                    weight: res.weight,
                                    shapes: res.shapes,
                                    guardianId: res.guardianId,
                                    id: res.id
                                };

                            case 4:
                            case "end":
                                return _context7.stop();
                        }
                    }
                }, _callee7, this);
            }));

            function getChild(_x3) {
                return _ref9.apply(this, arguments);
            }

            return getChild;
        }()
    }, {
        key: "rulesFn",
        value: function rulesFn() {
            var flag = true;
            var _iteratorNormalCompletion = true;
            var _didIteratorError = false;
            var _iteratorError = undefined;

            try {
                for (var _iterator = this.rules[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
                    var i = _step.value;

                    if (_Lang2.default.isEmpty(this.form[i.name])) {
                        _Tips2.default.toast(i.msg, function () {}, 'none');
                        flag = false;
                        break;
                    }
                }
            } catch (err) {
                _didIteratorError = true;
                _iteratorError = err;
            } finally {
                try {
                    if (!_iteratorNormalCompletion && _iterator.return) {
                        _iterator.return();
                    }
                } finally {
                    if (_didIteratorError) {
                        throw _iteratorError;
                    }
                }
            }

            return flag;
        }
    }]);

    return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/meet/addChild'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFkZENoaWxkLmpzIl0sIm5hbWVzIjpbIkRpYWxvZyIsImNvbmZpZyIsIm5hdmlnYXRpb25CYXJUaXRsZVRleHQiLCJkYXRhIiwibW9kYWxOYW1lIiwiZ3VlcyIsInBpY2tlciIsIm5hbWUiLCJ0eXBlIiwiY2FyZElueCIsIm1hbklueCIsImlkIiwiYmlydGhkYXlTdHIiLCJlbmRfZGF0ZSIsImZvcm0iLCJjYXJkVHlwZSIsImNhcmROdW0iLCJnZW5kZXIiLCJoZWlnaHQiLCJ3ZWlnaHQiLCJzaGFwZXMiLCJndWFyZGlhbklkIiwicnVsZXMiLCJtc2ciLCJpc2xvYWQiLCJtZXRob2RzIiwidGlwcyIsImhpZGVNb2RhbCIsIlBpY2tlckNoYW5nZSIsImUiLCJkZXRhaWwiLCJ2YWx1ZSIsImNoZWNrTWFuIiwiaW54IiwidG9FZGl0Iiwid2VweSIsIm5hdmlnYXRlVG8iLCJ1cmwiLCJEYXRlQ2hhbmdlIiwiaW5wdXQiLCJ0YXJnZXQiLCJjdXJyZW50VGFyZ2V0IiwiZGF0YXNldCIsImxlbmd0aCIsIl9yZXMiLCJMYW5nIiwiZ2V0QmlydGhkYXlCeUlkQ2FyZCIsIlRpcHMiLCJ0b2FzdCIsIm1lc3NhZ2UiLCJnZXRTZXhCeUlkQ2FyZCIsInBsdXMiLCJydWxlc0ZuIiwiY29uc29sZSIsImxvZyIsImNoZWNrSWRDYXJkIiwic3RhdHVzIiwidXBkYXRlQ2hpbGQiLCJyZXMiLCJlcnJjb2RlIiwibmF2aWdhdGVCYWNrIiwiZGVsdGEiLCJkZWxDaGlsZCIsInNlbGYiLCJ3eCIsInNob3dNb2RhbCIsImNvbnRlbnQiLCJzdWNjZXNzIiwiY29uZmlybSIsImNhbmNlbCIsIm9wdCIsImRhdGVGb3JtYXRlIiwiRGF0ZSIsInVwZGF0YSIsImdldEd1YUxpc3QiLCJnZXRDaGlsZCIsImZpbmRJbmRleCIsIiRhcHBseSIsImd1YUxpc3QiLCJiaXJ0aGRheSIsImZsYWciLCJpIiwiaXNFbXB0eSIsInBhZ2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7O0FBQ0k7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7Ozs7Ozs7Ozs7O0lBQ3FCQSxNOzs7Ozs7Ozs7Ozs7OzswTEFDakJDLE0sR0FBUztBQUNMQyxvQ0FBd0I7QUFEbkIsUyxRQUdUQyxJLEdBQU87QUFDSEMsdUJBQVcsRUFEUjtBQUVIQyxrQkFBTSxFQUZIO0FBR0hDLG9CQUFRLENBQUM7QUFDTEMsc0JBQU0sUUFERDtBQUVMQyxzQkFBTTtBQUZELGFBQUQsRUFHTDtBQUNDRCxzQkFBTSxLQURQO0FBRUNDLHNCQUFNO0FBRlAsYUFISyxFQU1MO0FBQ0NELHNCQUFNLE1BRFA7QUFFQ0Msc0JBQU07QUFGUCxhQU5LLEVBU0w7QUFDQ0Qsc0JBQU0sUUFEUDtBQUVDQyxzQkFBTTtBQUZQLGFBVEssRUFZTDtBQUNDRCxzQkFBTSxNQURQO0FBRUNDLHNCQUFNO0FBRlAsYUFaSyxFQWVMO0FBQ0NELHNCQUFNLE1BRFA7QUFFQ0Msc0JBQU07QUFGUCxhQWZLLENBSEw7QUFzQkhDLHFCQUFTLENBdEJOO0FBdUJIQyxvQkFBUSxDQXZCTDtBQXdCSEMsZ0JBQUksRUF4QkQ7QUF5QkhDLHlCQUFhLFlBekJWO0FBMEJIQyxzQkFBVSxFQTFCUDtBQTJCSEMsa0JBQU07QUFDRlAsc0JBQU0sRUFESjtBQUVGUSwwQkFBVSxDQUZSO0FBR0ZDLHlCQUFTLEVBSFA7QUFJRkMsd0JBQVEsQ0FKTjtBQUtGTCw2QkFBYSxFQUxYO0FBTUZNLHdCQUFRLEVBTk47QUFPRkMsd0JBQVEsRUFQTjtBQVFGQyx3QkFBUSxDQVJOO0FBU0ZDLDRCQUFZO0FBVFYsYUEzQkg7QUFzQ0hDLG1CQUFPLENBQUM7QUFDQWYsc0JBQU0sTUFETjtBQUVBZ0IscUJBQUs7QUFGTCxhQUFELEVBSUg7QUFDSWhCLHNCQUFNLFNBRFY7QUFFSWdCLHFCQUFLO0FBRlQsYUFKRyxFQVFIO0FBQ0loQixzQkFBTSxRQURWO0FBRUlnQixxQkFBSztBQUZULGFBUkcsRUFXQTtBQUNDaEIsc0JBQU0sUUFEUDtBQUVDZ0IscUJBQUs7QUFGTixhQVhBLEVBY0E7QUFDQ2hCLHNCQUFNLFlBRFA7QUFFQ2dCLHFCQUFLO0FBRk4sYUFkQSxDQXRDSjtBQXlESEMsb0JBQVE7QUF6REwsUyxRQTRIUEMsTyxHQUFVO0FBQ05SLGtCQURNLGtCQUNDQSxPQURELEVBQ1M7QUFDWCxxQkFBS0gsSUFBTCxDQUFVRyxNQUFWLEdBQW1CQSxPQUFuQjtBQUNILGFBSEs7QUFJTlMsZ0JBSk0sa0JBSUM7QUFDSCxxQkFBS3RCLFNBQUwsR0FBaUIsTUFBakI7QUFDSCxhQU5LO0FBT051QixxQkFQTSx1QkFPTTtBQUNSLHFCQUFLdkIsU0FBTCxHQUFpQixFQUFqQjtBQUNILGFBVEs7QUFVTndCLHdCQVZNLHdCQVVPQyxDQVZQLEVBVVU7QUFDWixxQkFBS3BCLE9BQUwsR0FBZW9CLEVBQUVDLE1BQUYsQ0FBU0MsS0FBeEI7QUFDQSxxQkFBS2pCLElBQUwsQ0FBVUMsUUFBVixHQUFxQixLQUFLVCxNQUFMLENBQVksS0FBS0csT0FBakIsRUFBMEJELElBQS9DO0FBQ0gsYUFiSztBQWNOd0Isb0JBZE0sb0JBY0dDLEdBZEgsRUFjUTtBQUNWLHFCQUFLdkIsTUFBTCxHQUFjdUIsR0FBZDtBQUNBLHFCQUFLbkIsSUFBTCxDQUFVTyxVQUFWLEdBQXVCLEtBQUtoQixJQUFMLENBQVUsS0FBS0ssTUFBZixFQUF1QkMsRUFBOUM7QUFDSCxhQWpCSztBQWtCTnVCLGtCQWxCTSxrQkFrQkN2QixFQWxCRCxFQWtCSztBQUNQd0IsK0JBQUtDLFVBQUwsQ0FBZ0I7QUFDWkMseUJBQUssaUJBQWlCMUI7QUFEVixpQkFBaEI7QUFHSCxhQXRCSztBQXVCTjJCLHNCQXZCTSxzQkF1QktULENBdkJMLEVBdUJRO0FBQ1YscUJBQUtqQixXQUFMLEdBQW1CaUIsRUFBRUMsTUFBRixDQUFTQyxLQUE1QjtBQUNILGFBekJLO0FBMEJOUSxpQkExQk0saUJBMEJBVixDQTFCQSxFQTBCRztBQUNMLG9CQUFJVyxTQUFTWCxFQUFFWSxhQUFGLENBQWdCQyxPQUFoQixDQUF3QkYsTUFBeEIsSUFBa0NYLEVBQUVXLE1BQUYsQ0FBU0UsT0FBVCxDQUFpQkYsTUFBaEU7QUFBQSxvQkFDSWhDLE9BQU9xQixFQUFFWSxhQUFGLENBQWdCQyxPQUFoQixDQUF3QmxDLElBQXhCLElBQWdDcUIsRUFBRVcsTUFBRixDQUFTRSxPQUFULENBQWlCbEMsSUFENUQ7QUFBQSxvQkFFSXVCLFFBQVFGLEVBQUVDLE1BQUYsQ0FBU0MsS0FGckI7QUFHQSxvQkFBSVMsVUFBVSxTQUFWLElBQXVCaEMsUUFBUSxDQUFuQyxFQUFzQztBQUNsQyx3QkFBSXVCLE1BQU1ZLE1BQU4sSUFBZ0IsRUFBcEIsRUFBd0I7QUFDcEIsNEJBQUlDLE9BQU9DLGVBQUtDLG1CQUFMLENBQXlCZixLQUF6QixDQUFYO0FBQ0EsNEJBQUksUUFBT2EsSUFBUCx5Q0FBT0EsSUFBUCxNQUFlLFFBQW5CLEVBQTZCO0FBQ3pCRywyQ0FBS0MsS0FBTCxDQUFXSixLQUFLSyxPQUFoQixFQUF5QixZQUFNLENBQUUsQ0FBakMsRUFBbUMsTUFBbkM7QUFDSCx5QkFGRCxNQUVPLElBQUksT0FBT0wsSUFBUCxJQUFlLFFBQW5CLEVBQTZCO0FBQ2hDLGlDQUFLOUIsSUFBTCxDQUFVRixXQUFWLEdBQXdCZ0MsSUFBeEI7QUFDSDtBQUNELDZCQUFLOUIsSUFBTCxDQUFVRyxNQUFWLEdBQW1CNEIsZUFBS0ssY0FBTCxDQUFvQm5CLEtBQXBCLENBQW5CO0FBQ0g7QUFDSjtBQUNELHFCQUFLakIsSUFBTCxDQUFVMEIsTUFBVixJQUFvQlQsS0FBcEI7QUFDSCxhQTFDSztBQTJDQW9CLGdCQTNDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlDQTRDRSxLQUFLQyxPQUFMLEVBNUNGO0FBQUE7QUFBQTtBQUFBOztBQTZDRUMsNENBQVFDLEdBQVIsQ0FBWSxLQUFLeEMsSUFBakI7O0FBN0NGLDBDQThDTSxLQUFLQSxJQUFMLENBQVVDLFFBQVYsSUFBc0IsQ0E5QzVCO0FBQUE7QUFBQTtBQUFBOztBQStDVU8seUNBL0NWLEdBK0NrQnVCLGVBQUtVLFdBQUwsQ0FBaUIsS0FBS3pDLElBQUwsQ0FBVUUsT0FBM0IsQ0EvQ2xCOztBQUFBLHdDQWdEV00sTUFBTWtDLE1BaERqQjtBQUFBO0FBQUE7QUFBQTs7QUFpRFVULG1EQUFLQyxLQUFMLENBQVcxQixNQUFNMkIsT0FBakIsRUFBMEIsWUFBTSxDQUFFLENBQWxDLEVBQW9DLE1BQXBDO0FBakRWLHFFQWtEaUIsS0FsRGpCOztBQUFBO0FBQUE7QUFBQSwyQ0FxRGtCaEQsaUJBQU93RCxXQUFQLENBQW1CLEtBQUszQyxJQUF4QixDQXJEbEI7O0FBQUE7QUFxRE00Qyx1Q0FyRE47O0FBc0RFLHdDQUFJQSxJQUFJQyxPQUFKLElBQWUsR0FBbkIsRUFBd0I7QUFDcEJaLHVEQUFLQyxLQUFMLENBQVcsTUFBWCxFQUFtQixZQUFNO0FBQ3JCYiwyREFBS3lCLFlBQUwsQ0FBa0I7QUFDZEMsdURBQU8sQ0FETyxDQUNMO0FBREssNkNBQWxCO0FBR0gseUNBSkQsRUFJRyxNQUpIO0FBS0g7O0FBNURIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBK0RBQyxvQkEvREE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFnRUVDLHdDQWhFRixHQWdFUyxJQWhFVDs7QUFpRUZDLHVDQUFHQyxTQUFILENBQWE7QUFDVEMsOEVBQWdCSCxLQUFLakQsSUFBTCxDQUFVUCxJQUExQiwrQ0FEUztBQUVUNEQ7QUFBQSxnSEFBUyxrQkFBZVQsR0FBZjtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUVBQ0RBLElBQUlVLE9BREg7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQSx1RUFFZW5FLGlCQUFPNkQsUUFBUCxDQUFnQkMsS0FBS3BELEVBQXJCLENBRmY7O0FBQUE7QUFFRytDLHFFQUZIOztBQUdELG9FQUFJQSxNQUFJQyxPQUFKLElBQWUsR0FBbkIsRUFBd0I7QUFDcEJaLG1GQUFLQyxLQUFMLENBQVcsTUFBWCxFQUFtQixZQUFNO0FBQ3JCYix1RkFBS3lCLFlBQUwsQ0FBa0I7QUFDZEMsbUZBQU8sQ0FETyxDQUNMO0FBREsseUVBQWxCO0FBR0gscUVBSkQsRUFJRyxNQUpIO0FBS0g7QUFUQTtBQUFBOztBQUFBO0FBVUUsb0VBQUlILElBQUlXLE1BQVIsRUFBZ0IsQ0FBRTs7QUFWcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkNBQVQ7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFGUyxxQ0FBYjs7QUFqRUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQSxTOzs7Ozs7a0dBakVHQyxHOzs7OztBQUNULHFDQUFLM0QsRUFBTCxHQUFVMkQsSUFBSTNELEVBQWQ7QUFDQSxxQ0FBS0UsUUFBTCxHQUFnQmdDLGVBQUswQixXQUFMLENBQWlCLElBQUlDLElBQUosRUFBakIsRUFBNkIsWUFBN0IsQ0FBaEI7O3VDQUNNLEtBQUtDLE1BQUwsRTs7O0FBQ04sb0NBQUksS0FBSzlELEVBQUwsSUFBVyxDQUFDLENBQWhCLEVBQW1CO0FBQ2YseUNBQUtHLElBQUwsQ0FBVUYsV0FBVixHQUF3QixLQUFLQyxRQUE3QjtBQUNIO0FBQ0QscUNBQUtXLE1BQUwsR0FBYyxLQUFkOzs7Ozs7Ozs7Ozs7Ozs7Ozs7aUNBRUs7QUFDTCxnQkFBSSxLQUFLQSxNQUFULEVBQWlCO0FBQ2IsdUJBQU8sS0FBUDtBQUNIO0FBQ0QsaUJBQUtpRCxNQUFMO0FBQ0g7Ozs7Ozs7Ozs7Ozt1Q0FFUyxLQUFLQyxVQUFMLEU7OztzQ0FDRixLQUFLL0QsRUFBTCxJQUFXLEk7Ozs7Ozt1Q0FDTCxLQUFLZ0UsUUFBTCxDQUFjLEtBQUtoRSxFQUFuQixDOzs7QUFFVjtBQUNBLG9DQUFJLEtBQUtOLElBQUwsQ0FBVXNDLE1BQWQsRUFBc0I7QUFDbEIsd0NBQUksS0FBSzdCLElBQUwsQ0FBVU8sVUFBZCxFQUEwQjtBQUN0Qiw2Q0FBS1gsTUFBTCxHQUFjLEtBQUtMLElBQUwsQ0FBVXVFLFNBQVYsQ0FBb0IsYUFBSztBQUNuQyxtREFBTy9DLEVBQUVsQixFQUFGLElBQVEsT0FBS0csSUFBTCxDQUFVTyxVQUF6QjtBQUNILHlDQUZhLENBQWQ7QUFHSCxxQ0FKRCxNQUlPO0FBQ0gsNkNBQUtQLElBQUwsQ0FBVU8sVUFBVixHQUF1QixLQUFLaEIsSUFBTCxDQUFVLEtBQUtLLE1BQWYsRUFBdUJDLEVBQTlDO0FBQ0g7QUFDSjtBQUNELHFDQUFLa0UsTUFBTDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3VDQUtVNUUsaUJBQU95RSxVQUFQLEU7Ozs7QUFETkksdUMsU0FBQUEsTzs7QUFFSixxQ0FBS3pFLElBQUwsR0FBWXlFLE9BQVo7QUFDQSxxQ0FBS0QsTUFBTDs7Ozs7Ozs7Ozs7Ozs7Ozs7OztrR0FFV2xFLEU7Ozs7Ozs7dUNBQ0tWLGlCQUFPMEUsUUFBUCxDQUFnQmhFLEVBQWhCLEM7OztBQUFaK0MsbUM7O0FBQ0oscUNBQUs1QyxJQUFMLEdBQVk7QUFDUlAsMENBQU1tRCxJQUFJbkQsSUFERjtBQUVSUSw4Q0FBVTJDLElBQUkzQyxRQUZOO0FBR1JDLDZDQUFTMEMsSUFBSTFDLE9BSEw7QUFJUkMsNENBQVF5QyxJQUFJekMsTUFKSjtBQUtSTCxpREFBYThDLElBQUlxQixRQUxUO0FBTVI3RCw0Q0FBUXdDLElBQUl4QyxNQU5KO0FBT1JDLDRDQUFRdUMsSUFBSXZDLE1BUEo7QUFRUkMsNENBQVFzQyxJQUFJdEMsTUFSSjtBQVNSQyxnREFBWXFDLElBQUlyQyxVQVRSO0FBVVJWLHdDQUFJK0MsSUFBSS9DO0FBVkEsaUNBQVo7Ozs7Ozs7Ozs7Ozs7Ozs7OztrQ0FhTTtBQUNOLGdCQUFJcUUsT0FBTyxJQUFYO0FBRE07QUFBQTtBQUFBOztBQUFBO0FBRU4scUNBQWMsS0FBSzFELEtBQW5CLDhIQUEwQjtBQUFBLHdCQUFqQjJELENBQWlCOztBQUN0Qix3QkFBSXBDLGVBQUtxQyxPQUFMLENBQWEsS0FBS3BFLElBQUwsQ0FBVW1FLEVBQUUxRSxJQUFaLENBQWIsQ0FBSixFQUFxQztBQUNqQ3dDLHVDQUFLQyxLQUFMLENBQVdpQyxFQUFFMUQsR0FBYixFQUFrQixZQUFNLENBQUUsQ0FBMUIsRUFBNEIsTUFBNUI7QUFDQXlELCtCQUFPLEtBQVA7QUFDQTtBQUNIO0FBQ0o7QUFSSztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQVNOLG1CQUFPQSxJQUFQO0FBQ0g7Ozs7RUEvSCtCN0MsZUFBS2dELEk7O2tCQUFwQm5GLE0iLCJmaWxlIjoiYWRkQ2hpbGQuanMiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuICAgIGltcG9ydCB3ZXB5IGZyb20gXCJ3ZXB5XCJcclxuICAgIGltcG9ydCBMYW5nIGZyb20gXCJAL3V0aWxzL0xhbmdcIlxyXG4gICAgaW1wb3J0IFRpcHMgZnJvbSBcIkAvdXRpbHMvVGlwc1wiXHJcbiAgICBpbXBvcnQgY29uZmlnIGZyb20gXCJAL2FwaS9jb25maWdcIlxyXG4gICAgZXhwb3J0IGRlZmF1bHQgY2xhc3MgRGlhbG9nIGV4dGVuZHMgd2VweS5wYWdlIHtcclxuICAgICAgICBjb25maWcgPSB7XHJcbiAgICAgICAgICAgIG5hdmlnYXRpb25CYXJUaXRsZVRleHQ6IFwi5YS/56ul5L+h5oGv57yW6L6RXCJcclxuICAgICAgICB9O1xyXG4gICAgICAgIGRhdGEgPSB7XHJcbiAgICAgICAgICAgIG1vZGFsTmFtZTogJycsXHJcbiAgICAgICAgICAgIGd1ZXM6IFtdLFxyXG4gICAgICAgICAgICBwaWNrZXI6IFt7XHJcbiAgICAgICAgICAgICAgICBuYW1lOiAn5YaF5Zyw6Lqr5Lu96K+B5Y+3JyxcclxuICAgICAgICAgICAgICAgIHR5cGU6IDFcclxuICAgICAgICAgICAgfSwge1xyXG4gICAgICAgICAgICAgICAgbmFtZTogJ+aKpOeFp+WPtycsXHJcbiAgICAgICAgICAgICAgICB0eXBlOiAyXHJcbiAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgIG5hbWU6ICflhpvlrpjor4Hlj7cnLFxyXG4gICAgICAgICAgICAgICAgdHlwZTogM1xyXG4gICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICBuYW1lOiAn5riv5r6z6YCa6KGM6K+B5Y+3JyxcclxuICAgICAgICAgICAgICAgIHR5cGU6IDRcclxuICAgICAgICAgICAgfSwge1xyXG4gICAgICAgICAgICAgICAgbmFtZTogJ+WPsOiDnuivgeWPtycsXHJcbiAgICAgICAgICAgICAgICB0eXBlOiA1XHJcbiAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgIG5hbWU6ICflhbbku5bor4Hlj7cnLFxyXG4gICAgICAgICAgICAgICAgdHlwZTogNlxyXG4gICAgICAgICAgICB9LCBdLFxyXG4gICAgICAgICAgICBjYXJkSW54OiAwLFxyXG4gICAgICAgICAgICBtYW5Jbng6IDAsXHJcbiAgICAgICAgICAgIGlkOiAnJyxcclxuICAgICAgICAgICAgYmlydGhkYXlTdHI6IFwiMjAxNS0wOS0wMVwiLFxyXG4gICAgICAgICAgICBlbmRfZGF0ZTogJycsXHJcbiAgICAgICAgICAgIGZvcm06IHtcclxuICAgICAgICAgICAgICAgIG5hbWU6ICcnLFxyXG4gICAgICAgICAgICAgICAgY2FyZFR5cGU6IDEsXHJcbiAgICAgICAgICAgICAgICBjYXJkTnVtOiAnJyxcclxuICAgICAgICAgICAgICAgIGdlbmRlcjogMSxcclxuICAgICAgICAgICAgICAgIGJpcnRoZGF5U3RyOiAnJyxcclxuICAgICAgICAgICAgICAgIGhlaWdodDogJycsXHJcbiAgICAgICAgICAgICAgICB3ZWlnaHQ6ICcnLFxyXG4gICAgICAgICAgICAgICAgc2hhcGVzOiAxLFxyXG4gICAgICAgICAgICAgICAgZ3VhcmRpYW5JZDogJydcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgcnVsZXM6IFt7XHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZTogJ25hbWUnLFxyXG4gICAgICAgICAgICAgICAgICAgIG1zZzogJ+ivt+Whq+WGmeWEv+erpeWnk+WQjSdcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZTogJ2NhcmROdW0nLFxyXG4gICAgICAgICAgICAgICAgICAgIG1zZzogJ+ivt+Whq+WGmeWEv+erpeivgeS7tuWPt+eggSdcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZTogJ2hlaWdodCcsXHJcbiAgICAgICAgICAgICAgICAgICAgbXNnOiAn6K+35aGr5YaZ5YS/56ul6Lqr6auYJ1xyXG4gICAgICAgICAgICAgICAgfSwge1xyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU6ICd3ZWlnaHQnLFxyXG4gICAgICAgICAgICAgICAgICAgIG1zZzogJ+ivt+Whq+WGmeWEv+erpeS9k+mHjSdcclxuICAgICAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgICAgICBuYW1lOiAnZ3VhcmRpYW5JZCcsXHJcbiAgICAgICAgICAgICAgICAgICAgbXNnOiAn6K+36YCJ5oup5LiA5L2N55uR5oqk5Lq6J1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICBpc2xvYWQ6IHRydWVcclxuICAgICAgICB9O1xyXG4gICAgICAgIGFzeW5jIG9uTG9hZChvcHQpIHtcclxuICAgICAgICAgICAgdGhpcy5pZCA9IG9wdC5pZFxyXG4gICAgICAgICAgICB0aGlzLmVuZF9kYXRlID0gTGFuZy5kYXRlRm9ybWF0ZShuZXcgRGF0ZSgpLCAneXl5eS1NTS1kZCcpXHJcbiAgICAgICAgICAgIGF3YWl0IHRoaXMudXBkYXRhKClcclxuICAgICAgICAgICAgaWYgKHRoaXMuaWQgPT0gLTEpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuZm9ybS5iaXJ0aGRheVN0ciA9IHRoaXMuZW5kX2RhdGVcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0aGlzLmlzbG9hZCA9IGZhbHNlXHJcbiAgICAgICAgfVxyXG4gICAgICAgIG9uU2hvdygpIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuaXNsb2FkKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0aGlzLnVwZGF0YSgpXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGFzeW5jIHVwZGF0YSgpIHtcclxuICAgICAgICAgICAgYXdhaXQgdGhpcy5nZXRHdWFMaXN0KClcclxuICAgICAgICAgICAgaWYgKHRoaXMuaWQgIT0gJy0xJykge1xyXG4gICAgICAgICAgICAgICAgYXdhaXQgdGhpcy5nZXRDaGlsZCh0aGlzLmlkKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8vIOmHjeaWsOmAieS4re+8jOebkeaKpOS6uumhuVxyXG4gICAgICAgICAgICBpZiAodGhpcy5ndWVzLmxlbmd0aCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuZm9ybS5ndWFyZGlhbklkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5tYW5JbnggPSB0aGlzLmd1ZXMuZmluZEluZGV4KGUgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZS5pZCA9PSB0aGlzLmZvcm0uZ3VhcmRpYW5JZFxyXG4gICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZm9ybS5ndWFyZGlhbklkID0gdGhpcy5ndWVzW3RoaXMubWFuSW54XS5pZFxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgICB9XHJcbiAgICAgICAgYXN5bmMgZ2V0R3VhTGlzdCgpIHtcclxuICAgICAgICAgICAgbGV0IHtcclxuICAgICAgICAgICAgICAgIGd1YUxpc3RcclxuICAgICAgICAgICAgfSA9IGF3YWl0IGNvbmZpZy5nZXRHdWFMaXN0KClcclxuICAgICAgICAgICAgdGhpcy5ndWVzID0gZ3VhTGlzdFxyXG4gICAgICAgICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGFzeW5jIGdldENoaWxkKGlkKSB7XHJcbiAgICAgICAgICAgIGxldCByZXMgPSBhd2FpdCBjb25maWcuZ2V0Q2hpbGQoaWQpXHJcbiAgICAgICAgICAgIHRoaXMuZm9ybSA9IHtcclxuICAgICAgICAgICAgICAgIG5hbWU6IHJlcy5uYW1lLFxyXG4gICAgICAgICAgICAgICAgY2FyZFR5cGU6IHJlcy5jYXJkVHlwZSxcclxuICAgICAgICAgICAgICAgIGNhcmROdW06IHJlcy5jYXJkTnVtLFxyXG4gICAgICAgICAgICAgICAgZ2VuZGVyOiByZXMuZ2VuZGVyLFxyXG4gICAgICAgICAgICAgICAgYmlydGhkYXlTdHI6IHJlcy5iaXJ0aGRheSxcclxuICAgICAgICAgICAgICAgIGhlaWdodDogcmVzLmhlaWdodCxcclxuICAgICAgICAgICAgICAgIHdlaWdodDogcmVzLndlaWdodCxcclxuICAgICAgICAgICAgICAgIHNoYXBlczogcmVzLnNoYXBlcyxcclxuICAgICAgICAgICAgICAgIGd1YXJkaWFuSWQ6IHJlcy5ndWFyZGlhbklkLFxyXG4gICAgICAgICAgICAgICAgaWQ6IHJlcy5pZFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJ1bGVzRm4oKSB7XHJcbiAgICAgICAgICAgIGxldCBmbGFnID0gdHJ1ZVxyXG4gICAgICAgICAgICBmb3IgKGxldCBpIG9mIHRoaXMucnVsZXMpIHtcclxuICAgICAgICAgICAgICAgIGlmIChMYW5nLmlzRW1wdHkodGhpcy5mb3JtW2kubmFtZV0pKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgVGlwcy50b2FzdChpLm1zZywgKCkgPT4ge30sICdub25lJylcclxuICAgICAgICAgICAgICAgICAgICBmbGFnID0gZmFsc2VcclxuICAgICAgICAgICAgICAgICAgICBicmVha1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiBmbGFnXHJcbiAgICAgICAgfVxyXG4gICAgICAgIG1ldGhvZHMgPSB7XHJcbiAgICAgICAgICAgIGdlbmRlcihnZW5kZXIpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuZm9ybS5nZW5kZXIgPSBnZW5kZXJcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgdGlwcygpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kYWxOYW1lID0gJ3RpcHMnXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGhpZGVNb2RhbCgpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kYWxOYW1lID0gJydcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgUGlja2VyQ2hhbmdlKGUpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuY2FyZElueCA9IGUuZGV0YWlsLnZhbHVlXHJcbiAgICAgICAgICAgICAgICB0aGlzLmZvcm0uY2FyZFR5cGUgPSB0aGlzLnBpY2tlclt0aGlzLmNhcmRJbnhdLnR5cGVcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgY2hlY2tNYW4oaW54KSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1hbklueCA9IGlueFxyXG4gICAgICAgICAgICAgICAgdGhpcy5mb3JtLmd1YXJkaWFuSWQgPSB0aGlzLmd1ZXNbdGhpcy5tYW5JbnhdLmlkXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHRvRWRpdChpZCkge1xyXG4gICAgICAgICAgICAgICAgd2VweS5uYXZpZ2F0ZVRvKHtcclxuICAgICAgICAgICAgICAgICAgICB1cmw6ICcuL2FkZE1hbj9pZD0nICsgaWRcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBEYXRlQ2hhbmdlKGUpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuYmlydGhkYXlTdHIgPSBlLmRldGFpbC52YWx1ZVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBpbnB1dChlKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgdGFyZ2V0ID0gZS5jdXJyZW50VGFyZ2V0LmRhdGFzZXQudGFyZ2V0IHx8IGUudGFyZ2V0LmRhdGFzZXQudGFyZ2V0LFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGUgPSBlLmN1cnJlbnRUYXJnZXQuZGF0YXNldC50eXBlIHx8IGUudGFyZ2V0LmRhdGFzZXQudHlwZSxcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZSA9IGUuZGV0YWlsLnZhbHVlO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRhcmdldCA9PSAnY2FyZE51bScgJiYgdHlwZSA9PSAxKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHZhbHVlLmxlbmd0aCA9PSAxOCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgX3JlcyA9IExhbmcuZ2V0QmlydGhkYXlCeUlkQ2FyZCh2YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBfcmVzID09ICdvYmplY3QnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBUaXBzLnRvYXN0KF9yZXMubWVzc2FnZSwgKCkgPT4ge30sICdub25lJylcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmICh0eXBlb2YgX3JlcyA9PSAnc3RyaW5nJykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5mb3JtLmJpcnRoZGF5U3RyID0gX3Jlc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZm9ybS5nZW5kZXIgPSBMYW5nLmdldFNleEJ5SWRDYXJkKHZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHRoaXMuZm9ybVt0YXJnZXRdID0gdmFsdWVcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgYXN5bmMgcGx1cygpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLnJ1bGVzRm4oKSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKHRoaXMuZm9ybSlcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5mb3JtLmNhcmRUeXBlID09IDEpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHJ1bGVzID0gTGFuZy5jaGVja0lkQ2FyZCh0aGlzLmZvcm0uY2FyZE51bSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFydWxlcy5zdGF0dXMpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRpcHMudG9hc3QocnVsZXMubWVzc2FnZSwgKCkgPT4ge30sICdub25lJylcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGxldCByZXMgPSBhd2FpdCBjb25maWcudXBkYXRlQ2hpbGQodGhpcy5mb3JtKVxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChyZXMuZXJyY29kZSA9PSAyMDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgVGlwcy50b2FzdCgn5L+d5a2Y5oiQ5YqfJywgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgd2VweS5uYXZpZ2F0ZUJhY2soe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlbHRhOiAxIC8v6L+U5Zue55qE6aG16Z2i5pWw77yM5aaC5p6cIGRlbHRhIOWkp+S6jueOsOaciemhtemdouaVsO+8jOWImei/lOWbnuWIsOmmlumhtSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LCAnbm9uZScpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBhc3luYyBkZWxDaGlsZCgpIHtcclxuICAgICAgICAgICAgICAgIGxldCBzZWxmID0gdGhpc1xyXG4gICAgICAgICAgICAgICAgd3guc2hvd01vZGFsKHtcclxuICAgICAgICAgICAgICAgICAgICBjb250ZW50OiBg56Gu5a6a5Yig6ZmkJHtzZWxmLmZvcm0ubmFtZX3nmoTlhL/nq6Xkv6Hmga/lkJfvvJ9gLFxyXG4gICAgICAgICAgICAgICAgICAgIHN1Y2Nlc3M6IGFzeW5jIGZ1bmN0aW9uKHJlcykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzLmNvbmZpcm0pIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCByZXMgPSBhd2FpdCBjb25maWcuZGVsQ2hpbGQoc2VsZi5pZClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXMuZXJyY29kZSA9PSAyMDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUaXBzLnRvYXN0KCfliKDpmaTmiJDlip8nLCAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdlcHkubmF2aWdhdGVCYWNrKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlbHRhOiAxIC8v6L+U5Zue55qE6aG16Z2i5pWw77yM5aaC5p6cIGRlbHRhIOWkp+S6jueOsOaciemhtemdouaVsO+8jOWImei/lOWbnuWIsOmmlumhtSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSwgJ25vbmUnKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKHJlcy5jYW5jZWwpIHt9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH07XHJcbiAgICB9XHJcbiJdfQ==