"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _card = require('./../../components/meet/card.js');

var _card2 = _interopRequireDefault(_card);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Meet = function (_wepy$page) {
  _inherits(Meet, _wepy$page);

  function Meet() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, Meet);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Meet.__proto__ || Object.getPrototypeOf(Meet)).call.apply(_ref, [this].concat(args))), _this), _this.data = {
      theme: _wepy2.default.$instance.globalData.themeColor,
      mobile: "",
      childs: [],
      remarks: [],
      pageIndex: 1,
      toload: false,
      isload: true,
      loadmoring: false
    }, _this.config = {
      navigationBarTitleText: "成长记录",
      enablePullDownRefresh: true
    }, _this.$repeat = { "remarks": { "com": "cCard", "props": "remark.sync" } }, _this.$props = { "cCard": { "xmlns:v-bind": { "value": "", "for": "remarks", "item": "item", "index": "index", "key": "index" }, "v-bind:remark.sync": { "value": "item", "type": "item", "for": "remarks", "item": "item", "index": "index", "key": "index" } } }, _this.$events = {}, _this.components = {
      cCard: _card2.default
    }, _this.methods = {
      toanswer: function toanswer() {
        _wepy2.default.navigateTo({
          url: "/actPages/pages/index"
        });
      },
      onGotUserInfo: function () {
        var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(e) {
          return regeneratorRuntime.wrap(function _callee$(_context) {
            while (1) {
              switch (_context.prev = _context.next) {
                case 0:
                  if (!(e.detail.errMsg == "getUserInfo:ok")) {
                    _context.next = 4;
                    break;
                  }

                  _context.next = 3;
                  return _auth2.default.getUserinfo(e.detail);

                case 3:
                  _wepy2.default.navigateTo({
                    url: "./childs"
                  });

                case 4:
                case "end":
                  return _context.stop();
              }
            }
          }, _callee, this);
        }));

        function onGotUserInfo(_x) {
          return _ref2.apply(this, arguments);
        }

        return onGotUserInfo;
      }(),
      bindgetphonenumber: function () {
        var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(e) {
          var mobile;
          return regeneratorRuntime.wrap(function _callee2$(_context2) {
            while (1) {
              switch (_context2.prev = _context2.next) {
                case 0:
                  if (!(e.detail.errMsg == "getPhoneNumber:ok")) {
                    _context2.next = 6;
                    break;
                  }

                  _context2.next = 3;
                  return _auth2.default.getPhone(e.detail);

                case 3:
                  mobile = _context2.sent;

                  if (mobile) {
                    _wepy2.default.setStorageSync("mobile", mobile);
                    this.mobile = mobile;
                  }
                  this.$apply();

                case 6:
                case "end":
                  return _context2.stop();
              }
            }
          }, _callee2, this);
        }));

        function bindgetphonenumber(_x2) {
          return _ref3.apply(this, arguments);
        }

        return bindgetphonenumber;
      }()
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(Meet, [{
    key: "onPullDownRefresh",
    value: function () {
      var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
        return regeneratorRuntime.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                _context3.next = 2;
                return this.loadData(1);

              case 2:
                this.pageIndex = 1;
                this.$apply();
                wx.stopPullDownRefresh();

              case 5:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this);
      }));

      function onPullDownRefresh() {
        return _ref4.apply(this, arguments);
      }

      return onPullDownRefresh;
    }()
  }, {
    key: "onLoad",
    value: function () {
      var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
        var _ref6, childList;

        return regeneratorRuntime.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                if (!_wepy2.default.getStorageSync("mobile")) {
                  _context4.next = 6;
                  break;
                }

                _context4.next = 3;
                return _config2.default.getChildList();

              case 3:
                _ref6 = _context4.sent;
                childList = _ref6.childList;

                this.childs = childList;

              case 6:
                this.loadData();
                // let {
                //   Comments
                // } = await config.aspirations()
                // this.remarks = Comments
                // this.$apply()

              case 7:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, this);
      }));

      function onLoad() {
        return _ref5.apply(this, arguments);
      }

      return onLoad;
    }()
  }, {
    key: "loadData",
    value: function () {
      var _ref7 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5(pageIndex) {
        var params, res, remarks;
        return regeneratorRuntime.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                params = {
                  pageIndex: pageIndex || this.pageIndex,
                  pageSize: 10
                };
                _context5.next = 3;
                return _config2.default.aspirations(params);

              case 3:
                res = _context5.sent;
                remarks = res.Comments;

                if (remarks.length) {
                  _context5.next = 14;
                  break;
                }

                if (pageIndex == 1) {
                  this.remarks = remarks;
                }
                this.pageIndex = pageIndex;
                this.toload = true;
                this.loadmoring = true;
                this.$apply();
                return _context5.abrupt("return", false);

              case 14:
                if (pageIndex > 1) this.pageIndex = pageIndex;
                if (pageIndex == 1) {
                  this.remarks = remarks;
                } else {
                  this.remarks = this.remarks.concat(remarks);
                }
                this.loadmoring = false;

              case 17:
                this.$apply();

              case 18:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5, this);
      }));

      function loadData(_x3) {
        return _ref7.apply(this, arguments);
      }

      return loadData;
    }()
  }, {
    key: "onReachBottom",
    value: function () {
      var _ref8 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
        return regeneratorRuntime.wrap(function _callee6$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                if (!this.loadmoring) {
                  _context6.next = 2;
                  break;
                }

                return _context6.abrupt("return", false);

              case 2:
                this.loadmoring = true;
                this.toload = false;
                _context6.next = 6;
                return this.loadData(this.pageIndex + 1);

              case 6:
                this.$apply();

              case 7:
              case "end":
                return _context6.stop();
            }
          }
        }, _callee6, this);
      }));

      function onReachBottom() {
        return _ref8.apply(this, arguments);
      }

      return onReachBottom;
    }()
  }, {
    key: "onShow",
    value: function onShow() {
      this.mobile = _wepy2.default.getStorageSync("mobile");
    }
  }]);

  return Meet;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Meet , 'pages/meet/meet'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1lZXQuanMiXSwibmFtZXMiOlsiTWVldCIsImRhdGEiLCJ0aGVtZSIsIndlcHkiLCIkaW5zdGFuY2UiLCJnbG9iYWxEYXRhIiwidGhlbWVDb2xvciIsIm1vYmlsZSIsImNoaWxkcyIsInJlbWFya3MiLCJwYWdlSW5kZXgiLCJ0b2xvYWQiLCJpc2xvYWQiLCJsb2FkbW9yaW5nIiwiY29uZmlnIiwibmF2aWdhdGlvbkJhclRpdGxlVGV4dCIsImVuYWJsZVB1bGxEb3duUmVmcmVzaCIsIiRyZXBlYXQiLCIkcHJvcHMiLCIkZXZlbnRzIiwiY29tcG9uZW50cyIsImNDYXJkIiwibWV0aG9kcyIsInRvYW5zd2VyIiwibmF2aWdhdGVUbyIsInVybCIsIm9uR290VXNlckluZm8iLCJlIiwiZGV0YWlsIiwiZXJyTXNnIiwiYXV0aCIsImdldFVzZXJpbmZvIiwiYmluZGdldHBob25lbnVtYmVyIiwiZ2V0UGhvbmUiLCJzZXRTdG9yYWdlU3luYyIsIiRhcHBseSIsImxvYWREYXRhIiwid3giLCJzdG9wUHVsbERvd25SZWZyZXNoIiwiZ2V0U3RvcmFnZVN5bmMiLCJnZXRDaGlsZExpc3QiLCJjaGlsZExpc3QiLCJwYXJhbXMiLCJwYWdlU2l6ZSIsImFzcGlyYXRpb25zIiwicmVzIiwiQ29tbWVudHMiLCJsZW5ndGgiLCJjb25jYXQiLCJwYWdlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFDRTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7Ozs7Ozs7Ozs7Ozs7SUFDcUJBLEk7Ozs7Ozs7Ozs7Ozs7O2tMQUNuQkMsSSxHQUFPO0FBQ0xDLGFBQU9DLGVBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQkMsVUFENUI7QUFFTEMsY0FBUSxFQUZIO0FBR0xDLGNBQVEsRUFISDtBQUlMQyxlQUFTLEVBSko7QUFLTEMsaUJBQVcsQ0FMTjtBQU1MQyxjQUFRLEtBTkg7QUFPTEMsY0FBUSxJQVBIO0FBUUxDLGtCQUFZO0FBUlAsSyxRQVVQQyxNLEdBQVM7QUFDUEMsOEJBQXdCLE1BRGpCO0FBRVBDLDZCQUF1QjtBQUZoQixLLFFBSVZDLE8sR0FBVSxFQUFDLFdBQVUsRUFBQyxPQUFNLE9BQVAsRUFBZSxTQUFRLGFBQXZCLEVBQVgsRSxRQUNiQyxNLEdBQVMsRUFBQyxTQUFRLEVBQUMsZ0JBQWUsRUFBQyxTQUFRLEVBQVQsRUFBWSxPQUFNLFNBQWxCLEVBQTRCLFFBQU8sTUFBbkMsRUFBMEMsU0FBUSxPQUFsRCxFQUEwRCxPQUFNLE9BQWhFLEVBQWhCLEVBQXlGLHNCQUFxQixFQUFDLFNBQVEsTUFBVCxFQUFnQixRQUFPLE1BQXZCLEVBQThCLE9BQU0sU0FBcEMsRUFBOEMsUUFBTyxNQUFyRCxFQUE0RCxTQUFRLE9BQXBFLEVBQTRFLE9BQU0sT0FBbEYsRUFBOUcsRUFBVCxFLFFBQ1RDLE8sR0FBVSxFLFFBQ1RDLFUsR0FBYTtBQUNSQztBQURRLEssUUE4RFZDLE8sR0FBVTtBQUNSQyxjQURRLHNCQUNHO0FBQ1RwQix1QkFBS3FCLFVBQUwsQ0FBZ0I7QUFDZEMsZUFBSztBQURTLFNBQWhCO0FBR0QsT0FMTztBQU1GQyxtQkFORTtBQUFBLDZGQU1ZQyxDQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFPRkEsRUFBRUMsTUFBRixDQUFTQyxNQUFULElBQW1CLGdCQVBqQjtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBLHlCQVFFQyxlQUFLQyxXQUFMLENBQWlCSixFQUFFQyxNQUFuQixDQVJGOztBQUFBO0FBU0p6QixpQ0FBS3FCLFVBQUwsQ0FBZ0I7QUFDZEMseUJBQUs7QUFEUyxtQkFBaEI7O0FBVEk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFjRk8sd0JBZEU7QUFBQSw4RkFjaUJMLENBZGpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQWVGQSxFQUFFQyxNQUFGLENBQVNDLE1BQVQsSUFBbUIsbUJBZmpCO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUEseUJBZ0JlQyxlQUFLRyxRQUFMLENBQWNOLEVBQUVDLE1BQWhCLENBaEJmOztBQUFBO0FBZ0JBckIsd0JBaEJBOztBQWlCSixzQkFBSUEsTUFBSixFQUFZO0FBQ1ZKLG1DQUFLK0IsY0FBTCxDQUFvQixRQUFwQixFQUE4QjNCLE1BQTlCO0FBQ0EseUJBQUtBLE1BQUwsR0FBY0EsTUFBZDtBQUNEO0FBQ0QsdUJBQUs0QixNQUFMOztBQXJCSTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBLEs7Ozs7Ozs7Ozs7Ozt1QkExREYsS0FBS0MsUUFBTCxDQUFjLENBQWQsQzs7O0FBQ04scUJBQUsxQixTQUFMLEdBQWlCLENBQWpCO0FBQ0EscUJBQUt5QixNQUFMO0FBQ0FFLG1CQUFHQyxtQkFBSDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7cUJBR0luQyxlQUFLb0MsY0FBTCxDQUFvQixRQUFwQixDOzs7Ozs7dUJBR1F6QixpQkFBTzBCLFlBQVAsRTs7OztBQURSQyx5QixTQUFBQSxTOztBQUVGLHFCQUFLakMsTUFBTCxHQUFjaUMsU0FBZDs7O0FBRUYscUJBQUtMLFFBQUw7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OzRGQUVhMUIsUzs7Ozs7O0FBQ1RnQyxzQixHQUFTO0FBQ1hoQyw2QkFBV0EsYUFBYSxLQUFLQSxTQURsQjtBQUVYaUMsNEJBQVU7QUFGQyxpQjs7dUJBSUc3QixpQkFBTzhCLFdBQVAsQ0FBbUJGLE1BQW5CLEM7OztBQUFaRyxtQjtBQUNBcEMsdUIsR0FBVW9DLElBQUlDLFE7O29CQUNickMsUUFBUXNDLE07Ozs7O0FBQ1gsb0JBQUlyQyxhQUFhLENBQWpCLEVBQW9CO0FBQ2xCLHVCQUFLRCxPQUFMLEdBQWVBLE9BQWY7QUFDRDtBQUNELHFCQUFLQyxTQUFMLEdBQWlCQSxTQUFqQjtBQUNBLHFCQUFLQyxNQUFMLEdBQWMsSUFBZDtBQUNBLHFCQUFLRSxVQUFMLEdBQWtCLElBQWxCO0FBQ0EscUJBQUtzQixNQUFMO2tEQUNPLEs7OztBQUVQLG9CQUFJekIsWUFBWSxDQUFoQixFQUFtQixLQUFLQSxTQUFMLEdBQWlCQSxTQUFqQjtBQUNuQixvQkFBSUEsYUFBYSxDQUFqQixFQUFvQjtBQUNsQix1QkFBS0QsT0FBTCxHQUFlQSxPQUFmO0FBQ0QsaUJBRkQsTUFFTztBQUNMLHVCQUFLQSxPQUFMLEdBQWUsS0FBS0EsT0FBTCxDQUFhdUMsTUFBYixDQUFvQnZDLE9BQXBCLENBQWY7QUFDRDtBQUNELHFCQUFLSSxVQUFMLEdBQWtCLEtBQWxCOzs7QUFFRixxQkFBS3NCLE1BQUw7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztxQkFHSSxLQUFLdEIsVTs7Ozs7a0RBQ0EsSzs7O0FBRVQscUJBQUtBLFVBQUwsR0FBa0IsSUFBbEI7QUFDQSxxQkFBS0YsTUFBTCxHQUFjLEtBQWQ7O3VCQUNNLEtBQUt5QixRQUFMLENBQWMsS0FBSzFCLFNBQUwsR0FBaUIsQ0FBL0IsQzs7O0FBQ04scUJBQUt5QixNQUFMOzs7Ozs7Ozs7Ozs7Ozs7Ozs7NkJBRU87QUFDUCxXQUFLNUIsTUFBTCxHQUFjSixlQUFLb0MsY0FBTCxDQUFvQixRQUFwQixDQUFkO0FBQ0Q7Ozs7RUEvRStCcEMsZUFBSzhDLEk7O2tCQUFsQmpELEkiLCJmaWxlIjoibWVldC5qcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4gIGltcG9ydCB3ZXB5IGZyb20gXCJ3ZXB5XCI7XHJcbiAgaW1wb3J0IGNDYXJkIGZyb20gXCJAL2NvbXBvbmVudHMvbWVldC9jYXJkXCI7XHJcbiAgaW1wb3J0IGF1dGggZnJvbSBcIkAvYXBpL2F1dGhcIjtcclxuICBpbXBvcnQgY29uZmlnIGZyb20gXCJAL2FwaS9jb25maWdcIjtcclxuICBleHBvcnQgZGVmYXVsdCBjbGFzcyBNZWV0IGV4dGVuZHMgd2VweS5wYWdlIHtcclxuICAgIGRhdGEgPSB7XHJcbiAgICAgIHRoZW1lOiB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnRoZW1lQ29sb3IsXHJcbiAgICAgIG1vYmlsZTogXCJcIixcclxuICAgICAgY2hpbGRzOiBbXSxcclxuICAgICAgcmVtYXJrczogW10sXHJcbiAgICAgIHBhZ2VJbmRleDogMSxcclxuICAgICAgdG9sb2FkOiBmYWxzZSxcclxuICAgICAgaXNsb2FkOiB0cnVlLFxyXG4gICAgICBsb2FkbW9yaW5nOiBmYWxzZVxyXG4gICAgfTtcclxuICAgIGNvbmZpZyA9IHtcclxuICAgICAgbmF2aWdhdGlvbkJhclRpdGxlVGV4dDogXCLmiJDplb/orrDlvZVcIixcclxuICAgICAgZW5hYmxlUHVsbERvd25SZWZyZXNoOiB0cnVlXHJcbiAgICB9O1xyXG4gICAkcmVwZWF0ID0ge1wicmVtYXJrc1wiOntcImNvbVwiOlwiY0NhcmRcIixcInByb3BzXCI6XCJyZW1hcmsuc3luY1wifX07XHJcbiRwcm9wcyA9IHtcImNDYXJkXCI6e1wieG1sbnM6di1iaW5kXCI6e1widmFsdWVcIjpcIlwiLFwiZm9yXCI6XCJyZW1hcmtzXCIsXCJpdGVtXCI6XCJpdGVtXCIsXCJpbmRleFwiOlwiaW5kZXhcIixcImtleVwiOlwiaW5kZXhcIn0sXCJ2LWJpbmQ6cmVtYXJrLnN5bmNcIjp7XCJ2YWx1ZVwiOlwiaXRlbVwiLFwidHlwZVwiOlwiaXRlbVwiLFwiZm9yXCI6XCJyZW1hcmtzXCIsXCJpdGVtXCI6XCJpdGVtXCIsXCJpbmRleFwiOlwiaW5kZXhcIixcImtleVwiOlwiaW5kZXhcIn19fTtcclxuJGV2ZW50cyA9IHt9O1xyXG4gY29tcG9uZW50cyA9IHtcclxuICAgICAgY0NhcmRcclxuICAgIH07XHJcbiAgICBhc3luYyBvblB1bGxEb3duUmVmcmVzaCgpIHtcclxuICAgICAgYXdhaXQgdGhpcy5sb2FkRGF0YSgxKTtcclxuICAgICAgdGhpcy5wYWdlSW5kZXggPSAxO1xyXG4gICAgICB0aGlzLiRhcHBseSgpO1xyXG4gICAgICB3eC5zdG9wUHVsbERvd25SZWZyZXNoKCk7XHJcbiAgICB9XHJcbiAgICBhc3luYyBvbkxvYWQoKSB7XHJcbiAgICAgIGlmICh3ZXB5LmdldFN0b3JhZ2VTeW5jKFwibW9iaWxlXCIpKSB7XHJcbiAgICAgICAgbGV0IHtcclxuICAgICAgICAgIGNoaWxkTGlzdFxyXG4gICAgICAgIH0gPSBhd2FpdCBjb25maWcuZ2V0Q2hpbGRMaXN0KCk7XHJcbiAgICAgICAgdGhpcy5jaGlsZHMgPSBjaGlsZExpc3Q7XHJcbiAgICAgIH1cclxuICAgICAgdGhpcy5sb2FkRGF0YSgpO1xyXG4gICAgICAvLyBsZXQge1xyXG4gICAgICAvLyAgIENvbW1lbnRzXHJcbiAgICAgIC8vIH0gPSBhd2FpdCBjb25maWcuYXNwaXJhdGlvbnMoKVxyXG4gICAgICAvLyB0aGlzLnJlbWFya3MgPSBDb21tZW50c1xyXG4gICAgICAvLyB0aGlzLiRhcHBseSgpXHJcbiAgICB9XHJcbiAgICBhc3luYyBsb2FkRGF0YShwYWdlSW5kZXgpIHtcclxuICAgICAgbGV0IHBhcmFtcyA9IHtcclxuICAgICAgICBwYWdlSW5kZXg6IHBhZ2VJbmRleCB8fCB0aGlzLnBhZ2VJbmRleCxcclxuICAgICAgICBwYWdlU2l6ZTogMTBcclxuICAgICAgfTtcclxuICAgICAgbGV0IHJlcyA9IGF3YWl0IGNvbmZpZy5hc3BpcmF0aW9ucyhwYXJhbXMpO1xyXG4gICAgICBsZXQgcmVtYXJrcyA9IHJlcy5Db21tZW50cztcclxuICAgICAgaWYgKCFyZW1hcmtzLmxlbmd0aCkge1xyXG4gICAgICAgIGlmIChwYWdlSW5kZXggPT0gMSkge1xyXG4gICAgICAgICAgdGhpcy5yZW1hcmtzID0gcmVtYXJrcztcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5wYWdlSW5kZXggPSBwYWdlSW5kZXg7XHJcbiAgICAgICAgdGhpcy50b2xvYWQgPSB0cnVlO1xyXG4gICAgICAgIHRoaXMubG9hZG1vcmluZyA9IHRydWU7XHJcbiAgICAgICAgdGhpcy4kYXBwbHkoKTtcclxuICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgaWYgKHBhZ2VJbmRleCA+IDEpIHRoaXMucGFnZUluZGV4ID0gcGFnZUluZGV4O1xyXG4gICAgICAgIGlmIChwYWdlSW5kZXggPT0gMSkge1xyXG4gICAgICAgICAgdGhpcy5yZW1hcmtzID0gcmVtYXJrcztcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgdGhpcy5yZW1hcmtzID0gdGhpcy5yZW1hcmtzLmNvbmNhdChyZW1hcmtzKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5sb2FkbW9yaW5nID0gZmFsc2U7XHJcbiAgICAgIH1cclxuICAgICAgdGhpcy4kYXBwbHkoKTtcclxuICAgIH1cclxuICAgIGFzeW5jIG9uUmVhY2hCb3R0b20oKSB7XHJcbiAgICAgIGlmICh0aGlzLmxvYWRtb3JpbmcpIHtcclxuICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgIH1cclxuICAgICAgdGhpcy5sb2FkbW9yaW5nID0gdHJ1ZTtcclxuICAgICAgdGhpcy50b2xvYWQgPSBmYWxzZTtcclxuICAgICAgYXdhaXQgdGhpcy5sb2FkRGF0YSh0aGlzLnBhZ2VJbmRleCArIDEpO1xyXG4gICAgICB0aGlzLiRhcHBseSgpO1xyXG4gICAgfVxyXG4gICAgb25TaG93KCkge1xyXG4gICAgICB0aGlzLm1vYmlsZSA9IHdlcHkuZ2V0U3RvcmFnZVN5bmMoXCJtb2JpbGVcIik7XHJcbiAgICB9XHJcbiAgICBtZXRob2RzID0ge1xyXG4gICAgICB0b2Fuc3dlcigpIHtcclxuICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgdXJsOiBcIi9hY3RQYWdlcy9wYWdlcy9pbmRleFwiXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0sXHJcbiAgICAgIGFzeW5jIG9uR290VXNlckluZm8oZSkge1xyXG4gICAgICAgIGlmIChlLmRldGFpbC5lcnJNc2cgPT0gXCJnZXRVc2VySW5mbzpva1wiKSB7XHJcbiAgICAgICAgICBhd2FpdCBhdXRoLmdldFVzZXJpbmZvKGUuZGV0YWlsKTtcclxuICAgICAgICAgIHdlcHkubmF2aWdhdGVUbyh7XHJcbiAgICAgICAgICAgIHVybDogXCIuL2NoaWxkc1wiXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgIH0sXHJcbiAgICAgIGFzeW5jIGJpbmRnZXRwaG9uZW51bWJlcihlKSB7XHJcbiAgICAgICAgaWYgKGUuZGV0YWlsLmVyck1zZyA9PSBcImdldFBob25lTnVtYmVyOm9rXCIpIHtcclxuICAgICAgICAgIGxldCBtb2JpbGUgPSBhd2FpdCBhdXRoLmdldFBob25lKGUuZGV0YWlsKTtcclxuICAgICAgICAgIGlmIChtb2JpbGUpIHtcclxuICAgICAgICAgICAgd2VweS5zZXRTdG9yYWdlU3luYyhcIm1vYmlsZVwiLCBtb2JpbGUpO1xyXG4gICAgICAgICAgICB0aGlzLm1vYmlsZSA9IG1vYmlsZTtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIHRoaXMuJGFwcGx5KCk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gIH1cclxuIl19