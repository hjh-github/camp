"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _card = require('./../../components/meet/card.js');

var _card2 = _interopRequireDefault(_card);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Meet = function (_wepy$page) {
  _inherits(Meet, _wepy$page);

  function Meet() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, Meet);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Meet.__proto__ || Object.getPrototypeOf(Meet)).call.apply(_ref, [this].concat(args))), _this), _this.data = {
      theme: _wepy2.default.$instance.globalData.themeColor,
      mobile: '',
      childs: [],
      remarks: [],
      pageIndex: 1,
      toload: false,
      isload: true,
      loadmoring: false
    }, _this.config = {
      navigationBarTitleText: "成长记录",
      enablePullDownRefresh: true
    }, _this.$repeat = { "remarks": { "com": "cCard", "props": "remark.sync" } }, _this.$props = { "cCard": { "xmlns:v-bind": { "value": "", "for": "remarks", "item": "item", "index": "index", "key": "index" }, "v-bind:remark.sync": { "value": "item", "type": "item", "for": "remarks", "item": "item", "index": "index", "key": "index" } } }, _this.$events = {}, _this.components = {
      cCard: _card2.default
    }, _this.methods = {
      onGotUserInfo: function () {
        var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(e) {
          return regeneratorRuntime.wrap(function _callee$(_context) {
            while (1) {
              switch (_context.prev = _context.next) {
                case 0:
                  if (!(e.detail.errMsg == "getUserInfo:ok")) {
                    _context.next = 4;
                    break;
                  }

                  _context.next = 3;
                  return _auth2.default.getUserinfo(e.detail);

                case 3:
                  _wepy2.default.navigateTo({
                    url: './childs'
                  });

                case 4:
                case "end":
                  return _context.stop();
              }
            }
          }, _callee, this);
        }));

        function onGotUserInfo(_x) {
          return _ref2.apply(this, arguments);
        }

        return onGotUserInfo;
      }(),
      bindgetphonenumber: function () {
        var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(e) {
          var mobile;
          return regeneratorRuntime.wrap(function _callee2$(_context2) {
            while (1) {
              switch (_context2.prev = _context2.next) {
                case 0:
                  if (!(e.detail.errMsg == "getPhoneNumber:ok")) {
                    _context2.next = 6;
                    break;
                  }

                  _context2.next = 3;
                  return _auth2.default.getPhone(e.detail);

                case 3:
                  mobile = _context2.sent;

                  if (mobile) {
                    _wepy2.default.setStorageSync('mobile', mobile);
                    this.mobile = mobile;
                  }
                  this.$apply();

                case 6:
                case "end":
                  return _context2.stop();
              }
            }
          }, _callee2, this);
        }));

        function bindgetphonenumber(_x2) {
          return _ref3.apply(this, arguments);
        }

        return bindgetphonenumber;
      }()
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(Meet, [{
    key: "onPullDownRefresh",
    value: function () {
      var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
        return regeneratorRuntime.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                _context3.next = 2;
                return this.loadData(1);

              case 2:
                this.pageIndex = 1;
                this.$apply();
                wx.stopPullDownRefresh();

              case 5:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this);
      }));

      function onPullDownRefresh() {
        return _ref4.apply(this, arguments);
      }

      return onPullDownRefresh;
    }()
  }, {
    key: "onLoad",
    value: function () {
      var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
        var _ref6, childList;

        return regeneratorRuntime.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                if (!_wepy2.default.getStorageSync('mobile')) {
                  _context4.next = 6;
                  break;
                }

                _context4.next = 3;
                return _config2.default.getChildList();

              case 3:
                _ref6 = _context4.sent;
                childList = _ref6.childList;

                this.childs = childList;

              case 6:
                this.loadData();
                // let {
                //   Comments
                // } = await config.aspirations()
                // this.remarks = Comments
                // this.$apply()

              case 7:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, this);
      }));

      function onLoad() {
        return _ref5.apply(this, arguments);
      }

      return onLoad;
    }()
  }, {
    key: "loadData",
    value: function () {
      var _ref7 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5(pageIndex) {
        var params, res, remarks;
        return regeneratorRuntime.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                params = {
                  pageIndex: pageIndex || this.pageIndex,
                  pageSize: 10
                };
                _context5.next = 3;
                return _config2.default.aspirations(params);

              case 3:
                res = _context5.sent;
                remarks = res.Comments;

                if (remarks.length) {
                  _context5.next = 14;
                  break;
                }

                if (pageIndex == 1) {
                  this.remarks = remarks;
                }
                this.pageIndex = pageIndex;
                this.toload = true;
                this.loadmoring = true;
                this.$apply();
                return _context5.abrupt("return", false);

              case 14:
                if (pageIndex > 1) this.pageIndex = pageIndex;
                if (pageIndex == 1) {
                  this.remarks = remarks;
                } else {
                  this.remarks = this.remarks.concat(remarks);
                }
                this.loadmoring = false;

              case 17:
                this.$apply();

              case 18:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5, this);
      }));

      function loadData(_x3) {
        return _ref7.apply(this, arguments);
      }

      return loadData;
    }()
  }, {
    key: "onReachBottom",
    value: function () {
      var _ref8 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
        return regeneratorRuntime.wrap(function _callee6$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                if (!this.loadmoring) {
                  _context6.next = 2;
                  break;
                }

                return _context6.abrupt("return", false);

              case 2:
                this.loadmoring = true;
                this.toload = false;
                _context6.next = 6;
                return this.loadData(this.pageIndex + 1);

              case 6:
                this.$apply();

              case 7:
              case "end":
                return _context6.stop();
            }
          }
        }, _callee6, this);
      }));

      function onReachBottom() {
        return _ref8.apply(this, arguments);
      }

      return onReachBottom;
    }()
  }, {
    key: "onShow",
    value: function onShow() {
      this.mobile = _wepy2.default.getStorageSync('mobile');
    }
  }]);

  return Meet;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Meet , 'pages/meet/meet'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1lZXQuanMiXSwibmFtZXMiOlsiTWVldCIsImRhdGEiLCJ0aGVtZSIsIndlcHkiLCIkaW5zdGFuY2UiLCJnbG9iYWxEYXRhIiwidGhlbWVDb2xvciIsIm1vYmlsZSIsImNoaWxkcyIsInJlbWFya3MiLCJwYWdlSW5kZXgiLCJ0b2xvYWQiLCJpc2xvYWQiLCJsb2FkbW9yaW5nIiwiY29uZmlnIiwibmF2aWdhdGlvbkJhclRpdGxlVGV4dCIsImVuYWJsZVB1bGxEb3duUmVmcmVzaCIsIiRyZXBlYXQiLCIkcHJvcHMiLCIkZXZlbnRzIiwiY29tcG9uZW50cyIsImNDYXJkIiwibWV0aG9kcyIsIm9uR290VXNlckluZm8iLCJlIiwiZGV0YWlsIiwiZXJyTXNnIiwiYXV0aCIsImdldFVzZXJpbmZvIiwibmF2aWdhdGVUbyIsInVybCIsImJpbmRnZXRwaG9uZW51bWJlciIsImdldFBob25lIiwic2V0U3RvcmFnZVN5bmMiLCIkYXBwbHkiLCJsb2FkRGF0YSIsInd4Iiwic3RvcFB1bGxEb3duUmVmcmVzaCIsImdldFN0b3JhZ2VTeW5jIiwiZ2V0Q2hpbGRMaXN0IiwiY2hpbGRMaXN0IiwicGFyYW1zIiwicGFnZVNpemUiLCJhc3BpcmF0aW9ucyIsInJlcyIsIkNvbW1lbnRzIiwibGVuZ3RoIiwiY29uY2F0IiwicGFnZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQ0U7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7Ozs7Ozs7Ozs7O0lBQ3FCQSxJOzs7Ozs7Ozs7Ozs7OztrTEFDbkJDLEksR0FBTztBQUNMQyxhQUFPQyxlQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJDLFVBRDVCO0FBRUxDLGNBQVEsRUFGSDtBQUdMQyxjQUFRLEVBSEg7QUFJTEMsZUFBUyxFQUpKO0FBS0xDLGlCQUFXLENBTE47QUFNTEMsY0FBUSxLQU5IO0FBT0xDLGNBQVEsSUFQSDtBQVFMQyxrQkFBWTtBQVJQLEssUUFVUEMsTSxHQUFTO0FBQ1BDLDhCQUF3QixNQURqQjtBQUVQQyw2QkFBdUI7QUFGaEIsSyxRQUlWQyxPLEdBQVUsRUFBQyxXQUFVLEVBQUMsT0FBTSxPQUFQLEVBQWUsU0FBUSxhQUF2QixFQUFYLEUsUUFDYkMsTSxHQUFTLEVBQUMsU0FBUSxFQUFDLGdCQUFlLEVBQUMsU0FBUSxFQUFULEVBQVksT0FBTSxTQUFsQixFQUE0QixRQUFPLE1BQW5DLEVBQTBDLFNBQVEsT0FBbEQsRUFBMEQsT0FBTSxPQUFoRSxFQUFoQixFQUF5RixzQkFBcUIsRUFBQyxTQUFRLE1BQVQsRUFBZ0IsUUFBTyxNQUF2QixFQUE4QixPQUFNLFNBQXBDLEVBQThDLFFBQU8sTUFBckQsRUFBNEQsU0FBUSxPQUFwRSxFQUE0RSxPQUFNLE9BQWxGLEVBQTlHLEVBQVQsRSxRQUNUQyxPLEdBQVUsRSxRQUNUQyxVLEdBQWE7QUFDUkM7QUFEUSxLLFFBOERWQyxPLEdBQVU7QUFDRkMsbUJBREU7QUFBQSw2RkFDWUMsQ0FEWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBRUZBLEVBQUVDLE1BQUYsQ0FBU0MsTUFBVCxJQUFtQixnQkFGakI7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQSx5QkFHRUMsZUFBS0MsV0FBTCxDQUFpQkosRUFBRUMsTUFBbkIsQ0FIRjs7QUFBQTtBQUlKdEIsaUNBQUswQixVQUFMLENBQWdCO0FBQ2RDLHlCQUFLO0FBRFMsbUJBQWhCOztBQUpJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBU0ZDLHdCQVRFO0FBQUEsOEZBU2lCUCxDQVRqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFVRkEsRUFBRUMsTUFBRixDQUFTQyxNQUFULElBQW1CLG1CQVZqQjtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBLHlCQVdlQyxlQUFLSyxRQUFMLENBQWNSLEVBQUVDLE1BQWhCLENBWGY7O0FBQUE7QUFXQWxCLHdCQVhBOztBQVlKLHNCQUFJQSxNQUFKLEVBQVk7QUFDVkosbUNBQUs4QixjQUFMLENBQW9CLFFBQXBCLEVBQThCMUIsTUFBOUI7QUFDQSx5QkFBS0EsTUFBTCxHQUFjQSxNQUFkO0FBQ0Q7QUFDRCx1QkFBSzJCLE1BQUw7O0FBaEJJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUEsSzs7Ozs7Ozs7Ozs7O3VCQTFERixLQUFLQyxRQUFMLENBQWMsQ0FBZCxDOzs7QUFDTixxQkFBS3pCLFNBQUwsR0FBaUIsQ0FBakI7QUFDQSxxQkFBS3dCLE1BQUw7QUFDQUUsbUJBQUdDLG1CQUFIOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztxQkFHSWxDLGVBQUttQyxjQUFMLENBQW9CLFFBQXBCLEM7Ozs7Ozt1QkFHUXhCLGlCQUFPeUIsWUFBUCxFOzs7O0FBRFJDLHlCLFNBQUFBLFM7O0FBRUYscUJBQUtoQyxNQUFMLEdBQWNnQyxTQUFkOzs7QUFFRixxQkFBS0wsUUFBTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7NEZBRWF6QixTOzs7Ozs7QUFDVCtCLHNCLEdBQVM7QUFDWC9CLDZCQUFXQSxhQUFhLEtBQUtBLFNBRGxCO0FBRVhnQyw0QkFBVTtBQUZDLGlCOzt1QkFJRzVCLGlCQUFPNkIsV0FBUCxDQUFtQkYsTUFBbkIsQzs7O0FBQVpHLG1CO0FBQ0FuQyx1QixHQUFVbUMsSUFBSUMsUTs7b0JBQ2JwQyxRQUFRcUMsTTs7Ozs7QUFDWCxvQkFBSXBDLGFBQWEsQ0FBakIsRUFBb0I7QUFDbEIsdUJBQUtELE9BQUwsR0FBZUEsT0FBZjtBQUNEO0FBQ0QscUJBQUtDLFNBQUwsR0FBaUJBLFNBQWpCO0FBQ0EscUJBQUtDLE1BQUwsR0FBYyxJQUFkO0FBQ0EscUJBQUtFLFVBQUwsR0FBa0IsSUFBbEI7QUFDQSxxQkFBS3FCLE1BQUw7a0RBQ08sSzs7O0FBRVAsb0JBQUl4QixZQUFZLENBQWhCLEVBQW1CLEtBQUtBLFNBQUwsR0FBaUJBLFNBQWpCO0FBQ25CLG9CQUFJQSxhQUFhLENBQWpCLEVBQW9CO0FBQ2xCLHVCQUFLRCxPQUFMLEdBQWVBLE9BQWY7QUFDRCxpQkFGRCxNQUVPO0FBQ0wsdUJBQUtBLE9BQUwsR0FBZSxLQUFLQSxPQUFMLENBQWFzQyxNQUFiLENBQW9CdEMsT0FBcEIsQ0FBZjtBQUNEO0FBQ0QscUJBQUtJLFVBQUwsR0FBa0IsS0FBbEI7OztBQUVGLHFCQUFLcUIsTUFBTDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3FCQUdJLEtBQUtyQixVOzs7OztrREFDQSxLOzs7QUFFVCxxQkFBS0EsVUFBTCxHQUFrQixJQUFsQjtBQUNBLHFCQUFLRixNQUFMLEdBQWMsS0FBZDs7dUJBQ00sS0FBS3dCLFFBQUwsQ0FBYyxLQUFLekIsU0FBTCxHQUFpQixDQUEvQixDOzs7QUFDTixxQkFBS3dCLE1BQUw7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs2QkFFTztBQUNQLFdBQUszQixNQUFMLEdBQWNKLGVBQUttQyxjQUFMLENBQW9CLFFBQXBCLENBQWQ7QUFDRDs7OztFQS9FK0JuQyxlQUFLNkMsSTs7a0JBQWxCaEQsSSIsImZpbGUiOiJtZWV0LmpzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbiAgaW1wb3J0IHdlcHkgZnJvbSBcIndlcHlcIjtcclxuICBpbXBvcnQgY0NhcmQgZnJvbSBcIkAvY29tcG9uZW50cy9tZWV0L2NhcmRcIlxyXG4gIGltcG9ydCBhdXRoIGZyb20gXCJAL2FwaS9hdXRoXCJcclxuICBpbXBvcnQgY29uZmlnIGZyb20gXCJAL2FwaS9jb25maWdcIlxyXG4gIGV4cG9ydCBkZWZhdWx0IGNsYXNzIE1lZXQgZXh0ZW5kcyB3ZXB5LnBhZ2Uge1xyXG4gICAgZGF0YSA9IHtcclxuICAgICAgdGhlbWU6IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEudGhlbWVDb2xvcixcclxuICAgICAgbW9iaWxlOiAnJyxcclxuICAgICAgY2hpbGRzOiBbXSxcclxuICAgICAgcmVtYXJrczogW10sXHJcbiAgICAgIHBhZ2VJbmRleDogMSxcclxuICAgICAgdG9sb2FkOiBmYWxzZSxcclxuICAgICAgaXNsb2FkOiB0cnVlLFxyXG4gICAgICBsb2FkbW9yaW5nOiBmYWxzZSxcclxuICAgIH07XHJcbiAgICBjb25maWcgPSB7XHJcbiAgICAgIG5hdmlnYXRpb25CYXJUaXRsZVRleHQ6IFwi5oiQ6ZW/6K6w5b2VXCIsXHJcbiAgICAgIGVuYWJsZVB1bGxEb3duUmVmcmVzaDogdHJ1ZVxyXG4gICAgfTtcclxuICAgJHJlcGVhdCA9IHtcInJlbWFya3NcIjp7XCJjb21cIjpcImNDYXJkXCIsXCJwcm9wc1wiOlwicmVtYXJrLnN5bmNcIn19O1xyXG4kcHJvcHMgPSB7XCJjQ2FyZFwiOntcInhtbG5zOnYtYmluZFwiOntcInZhbHVlXCI6XCJcIixcImZvclwiOlwicmVtYXJrc1wiLFwiaXRlbVwiOlwiaXRlbVwiLFwiaW5kZXhcIjpcImluZGV4XCIsXCJrZXlcIjpcImluZGV4XCJ9LFwidi1iaW5kOnJlbWFyay5zeW5jXCI6e1widmFsdWVcIjpcIml0ZW1cIixcInR5cGVcIjpcIml0ZW1cIixcImZvclwiOlwicmVtYXJrc1wiLFwiaXRlbVwiOlwiaXRlbVwiLFwiaW5kZXhcIjpcImluZGV4XCIsXCJrZXlcIjpcImluZGV4XCJ9fX07XHJcbiRldmVudHMgPSB7fTtcclxuIGNvbXBvbmVudHMgPSB7XHJcbiAgICAgIGNDYXJkXHJcbiAgICB9XHJcbiAgICBhc3luYyBvblB1bGxEb3duUmVmcmVzaCgpIHtcclxuICAgICAgYXdhaXQgdGhpcy5sb2FkRGF0YSgxKVxyXG4gICAgICB0aGlzLnBhZ2VJbmRleCA9IDFcclxuICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgICB3eC5zdG9wUHVsbERvd25SZWZyZXNoKClcclxuICAgIH1cclxuICAgIGFzeW5jIG9uTG9hZCgpIHtcclxuICAgICAgaWYgKHdlcHkuZ2V0U3RvcmFnZVN5bmMoJ21vYmlsZScpKSB7XHJcbiAgICAgICAgbGV0IHtcclxuICAgICAgICAgIGNoaWxkTGlzdFxyXG4gICAgICAgIH0gPSBhd2FpdCBjb25maWcuZ2V0Q2hpbGRMaXN0KClcclxuICAgICAgICB0aGlzLmNoaWxkcyA9IGNoaWxkTGlzdFxyXG4gICAgICB9XHJcbiAgICAgIHRoaXMubG9hZERhdGEoKVxyXG4gICAgICAvLyBsZXQge1xyXG4gICAgICAvLyAgIENvbW1lbnRzXHJcbiAgICAgIC8vIH0gPSBhd2FpdCBjb25maWcuYXNwaXJhdGlvbnMoKVxyXG4gICAgICAvLyB0aGlzLnJlbWFya3MgPSBDb21tZW50c1xyXG4gICAgICAvLyB0aGlzLiRhcHBseSgpXHJcbiAgICB9XHJcbiAgICBhc3luYyBsb2FkRGF0YShwYWdlSW5kZXgpIHtcclxuICAgICAgbGV0IHBhcmFtcyA9IHtcclxuICAgICAgICBwYWdlSW5kZXg6IHBhZ2VJbmRleCB8fCB0aGlzLnBhZ2VJbmRleCxcclxuICAgICAgICBwYWdlU2l6ZTogMTBcclxuICAgICAgfVxyXG4gICAgICBsZXQgcmVzID0gYXdhaXQgY29uZmlnLmFzcGlyYXRpb25zKHBhcmFtcylcclxuICAgICAgbGV0IHJlbWFya3MgPSByZXMuQ29tbWVudHNcclxuICAgICAgaWYgKCFyZW1hcmtzLmxlbmd0aCkge1xyXG4gICAgICAgIGlmIChwYWdlSW5kZXggPT0gMSkge1xyXG4gICAgICAgICAgdGhpcy5yZW1hcmtzID0gcmVtYXJrc1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLnBhZ2VJbmRleCA9IHBhZ2VJbmRleFxyXG4gICAgICAgIHRoaXMudG9sb2FkID0gdHJ1ZVxyXG4gICAgICAgIHRoaXMubG9hZG1vcmluZyA9IHRydWVcclxuICAgICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgaWYgKHBhZ2VJbmRleCA+IDEpIHRoaXMucGFnZUluZGV4ID0gcGFnZUluZGV4XHJcbiAgICAgICAgaWYgKHBhZ2VJbmRleCA9PSAxKSB7XHJcbiAgICAgICAgICB0aGlzLnJlbWFya3MgPSByZW1hcmtzXHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHRoaXMucmVtYXJrcyA9IHRoaXMucmVtYXJrcy5jb25jYXQocmVtYXJrcylcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5sb2FkbW9yaW5nID0gZmFsc2VcclxuICAgICAgfVxyXG4gICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICB9XHJcbiAgICBhc3luYyBvblJlYWNoQm90dG9tKCkge1xyXG4gICAgICBpZiAodGhpcy5sb2FkbW9yaW5nKSB7XHJcbiAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgIH1cclxuICAgICAgdGhpcy5sb2FkbW9yaW5nID0gdHJ1ZVxyXG4gICAgICB0aGlzLnRvbG9hZCA9IGZhbHNlXHJcbiAgICAgIGF3YWl0IHRoaXMubG9hZERhdGEodGhpcy5wYWdlSW5kZXggKyAxKVxyXG4gICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICB9XHJcbiAgICBvblNob3coKSB7XHJcbiAgICAgIHRoaXMubW9iaWxlID0gd2VweS5nZXRTdG9yYWdlU3luYygnbW9iaWxlJyk7XHJcbiAgICB9XHJcbiAgICBtZXRob2RzID0ge1xyXG4gICAgICBhc3luYyBvbkdvdFVzZXJJbmZvKGUpIHtcclxuICAgICAgICBpZiAoZS5kZXRhaWwuZXJyTXNnID09IFwiZ2V0VXNlckluZm86b2tcIikge1xyXG4gICAgICAgICAgYXdhaXQgYXV0aC5nZXRVc2VyaW5mbyhlLmRldGFpbClcclxuICAgICAgICAgIHdlcHkubmF2aWdhdGVUbyh7XHJcbiAgICAgICAgICAgIHVybDogJy4vY2hpbGRzJ1xyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG4gICAgICBhc3luYyBiaW5kZ2V0cGhvbmVudW1iZXIoZSkge1xyXG4gICAgICAgIGlmIChlLmRldGFpbC5lcnJNc2cgPT0gXCJnZXRQaG9uZU51bWJlcjpva1wiKSB7XHJcbiAgICAgICAgICBsZXQgbW9iaWxlID0gYXdhaXQgYXV0aC5nZXRQaG9uZShlLmRldGFpbClcclxuICAgICAgICAgIGlmIChtb2JpbGUpIHtcclxuICAgICAgICAgICAgd2VweS5zZXRTdG9yYWdlU3luYygnbW9iaWxlJywgbW9iaWxlKTtcclxuICAgICAgICAgICAgdGhpcy5tb2JpbGUgPSBtb2JpbGVcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgfVxyXG4iXX0=