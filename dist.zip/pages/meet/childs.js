"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
    _inherits(Dialog, _wepy$page);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.data = {
            close: "/static/images/close.png",
            ListTouchStart: 0,
            ListTouchDirection: null,
            modalName: null,
            childs: [],
            isget: false,
            childsed: {},
            len: 1
        }, _this.config = {
            navigationBarTitleText: "身份信息管理"
        }, _this.methods = {
            toEdit: function toEdit(id) {
                _wepy2.default.navigateTo({
                    url: './addChild?id=' + id
                });
            },
            getChilds: function getChilds(e) {
                console.log(e);
                if (!this.isget || !e.guardianId) {
                    return false;
                }
                if (this.childsed[e.id]) {
                    delete this.childsed[e.id];
                } else {
                    this.childsed[e.id] = e;
                }
                this.getArr();
            },
            sureChilds: function sureChilds() {
                _wepy2.default.navigateBack({
                    delta: 1 //返回的页面数，如果 delta 大于现有页面数，则返回到首页,
                });
            }
            // ListTouchStart(e) {
            //     this.ListTouchStart = e.touches[0].pageX
            // },
            // // ListTouch计算方向
            // ListTouchMove(e) {
            //     this.ListTouchDirection = e.touches[0].pageX - this.data.ListTouchStart > 0 ? 'right' : 'left'
            // },
            // // ListTouch计算滚动
            // ListTouchEnd(e) {
            //     if (this.ListTouchDirection == 'left') {
            //         this.modalName = e.currentTarget.dataset.target
            //     } else {
            //         this.modalName = null
            //     }
            //     this.ListTouchDirection = null
            // }

        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(Dialog, [{
        key: "onLoad",
        value: function onLoad(opt) {
            this.isget = opt.type == 1;
            this.len = opt.len;
        }
    }, {
        key: "onShow",
        value: function () {
            var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
                var _ref3, childList;

                return regeneratorRuntime.wrap(function _callee$(_context) {
                    while (1) {
                        switch (_context.prev = _context.next) {
                            case 0:
                                _context.next = 2;
                                return _config2.default.getChildList();

                            case 2:
                                _ref3 = _context.sent;
                                childList = _ref3.childList;

                                this.childs = childList;
                                this.$apply();
                                // this.ListTouchDirection = 'right'
                                // if (this.list.length > 0) {
                                //     setTimeout(() => {
                                //         this.modalName = 'move-box-0'
                                //         this.$apply()
                                //         setTimeout(() => {
                                //             this.modalName = null
                                //             this.$apply()
                                //         }, 1000)
                                //     }, 300)
                                // }

                            case 6:
                            case "end":
                                return _context.stop();
                        }
                    }
                }, _callee, this);
            }));

            function onShow() {
                return _ref2.apply(this, arguments);
            }

            return onShow;
        }()
    }, {
        key: "getArr",
        value: function getArr() {
            var arr = [];
            console.log(this.childsed);
            for (var i in this.childsed) {
                var o = this.childsed[i];
                arr.push(o);
            }
            _wepy2.default.$instance.globalData.childs = arr;
            if (arr.length == this.len) {
                _wepy2.default.navigateBack({
                    delta: 1 //返回的页面数，如果 delta 大于现有页面数，则返回到首页,
                });
            }
        }
    }]);

    return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/meet/childs'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNoaWxkcy5qcyJdLCJuYW1lcyI6WyJEaWFsb2ciLCJkYXRhIiwiY2xvc2UiLCJMaXN0VG91Y2hTdGFydCIsIkxpc3RUb3VjaERpcmVjdGlvbiIsIm1vZGFsTmFtZSIsImNoaWxkcyIsImlzZ2V0IiwiY2hpbGRzZWQiLCJsZW4iLCJjb25maWciLCJuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0IiwibWV0aG9kcyIsInRvRWRpdCIsImlkIiwid2VweSIsIm5hdmlnYXRlVG8iLCJ1cmwiLCJnZXRDaGlsZHMiLCJlIiwiY29uc29sZSIsImxvZyIsImd1YXJkaWFuSWQiLCJnZXRBcnIiLCJzdXJlQ2hpbGRzIiwibmF2aWdhdGVCYWNrIiwiZGVsdGEiLCJvcHQiLCJ0eXBlIiwiZ2V0Q2hpbGRMaXN0IiwiY2hpbGRMaXN0IiwiJGFwcGx5IiwiYXJyIiwiaSIsIm8iLCJwdXNoIiwiJGluc3RhbmNlIiwiZ2xvYmFsRGF0YSIsImxlbmd0aCIsInBhZ2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUNJOzs7O0FBQ0E7Ozs7Ozs7Ozs7Ozs7O0lBQ3FCQSxNOzs7Ozs7Ozs7Ozs7OzswTEFDakJDLEksR0FBTztBQUNIQyxtQkFBTywwQkFESjtBQUVIQyw0QkFBZ0IsQ0FGYjtBQUdIQyxnQ0FBb0IsSUFIakI7QUFJSEMsdUJBQVcsSUFKUjtBQUtIQyxvQkFBUSxFQUxMO0FBTUhDLG1CQUFPLEtBTko7QUFPSEMsc0JBQVUsRUFQUDtBQVFIQyxpQkFBSztBQVJGLFMsUUFVUEMsTSxHQUFTO0FBQ0xDLG9DQUF3QjtBQURuQixTLFFBdUNUQyxPLEdBQVU7QUFDTkMsa0JBRE0sa0JBQ0NDLEVBREQsRUFDSztBQUNQQywrQkFBS0MsVUFBTCxDQUFnQjtBQUNaQyx5QkFBSyxtQkFBbUJIO0FBRFosaUJBQWhCO0FBR0gsYUFMSztBQU1OSSxxQkFOTSxxQkFNSUMsQ0FOSixFQU1PO0FBQ1RDLHdCQUFRQyxHQUFSLENBQVlGLENBQVo7QUFDQSxvQkFBSSxDQUFDLEtBQUtaLEtBQU4sSUFBZSxDQUFDWSxFQUFFRyxVQUF0QixFQUFrQztBQUM5QiwyQkFBTyxLQUFQO0FBQ0g7QUFDRCxvQkFBSSxLQUFLZCxRQUFMLENBQWNXLEVBQUVMLEVBQWhCLENBQUosRUFBeUI7QUFDckIsMkJBQU8sS0FBS04sUUFBTCxDQUFjVyxFQUFFTCxFQUFoQixDQUFQO0FBQ0gsaUJBRkQsTUFFTztBQUNILHlCQUFLTixRQUFMLENBQWNXLEVBQUVMLEVBQWhCLElBQXNCSyxDQUF0QjtBQUNIO0FBQ0QscUJBQUtJLE1BQUw7QUFDSCxhQWpCSztBQWtCTkMsc0JBbEJNLHdCQWtCTztBQUNUVCwrQkFBS1UsWUFBTCxDQUFrQjtBQUNkQywyQkFBTyxDQURPLENBQ0w7QUFESyxpQkFBbEI7QUFHSDtBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQXRDTSxTOzs7OzsrQkFwQ0hDLEcsRUFBSztBQUNSLGlCQUFLcEIsS0FBTCxHQUFhb0IsSUFBSUMsSUFBSixJQUFZLENBQXpCO0FBQ0EsaUJBQUtuQixHQUFMLEdBQVdrQixJQUFJbEIsR0FBZjtBQUNIOzs7Ozs7Ozs7Ozs7dUNBSWFDLGlCQUFPbUIsWUFBUCxFOzs7O0FBRE5DLHlDLFNBQUFBLFM7O0FBRUoscUNBQUt4QixNQUFMLEdBQWN3QixTQUFkO0FBQ0EscUNBQUtDLE1BQUw7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7aUNBRUs7QUFDTCxnQkFBSUMsTUFBTSxFQUFWO0FBQ0FaLG9CQUFRQyxHQUFSLENBQVksS0FBS2IsUUFBakI7QUFDQSxpQkFBSyxJQUFJeUIsQ0FBVCxJQUFjLEtBQUt6QixRQUFuQixFQUE2QjtBQUN6QixvQkFBSTBCLElBQUksS0FBSzFCLFFBQUwsQ0FBY3lCLENBQWQsQ0FBUjtBQUNBRCxvQkFBSUcsSUFBSixDQUFTRCxDQUFUO0FBQ0g7QUFDRG5CLDJCQUFLcUIsU0FBTCxDQUFlQyxVQUFmLENBQTBCL0IsTUFBMUIsR0FBbUMwQixHQUFuQztBQUNBLGdCQUFJQSxJQUFJTSxNQUFKLElBQWMsS0FBSzdCLEdBQXZCLEVBQTRCO0FBQ3hCTSwrQkFBS1UsWUFBTCxDQUFrQjtBQUNkQywyQkFBTyxDQURPLENBQ0w7QUFESyxpQkFBbEI7QUFHSDtBQUNKOzs7O0VBakQrQlgsZUFBS3dCLEk7O2tCQUFwQnZDLE0iLCJmaWxlIjoiY2hpbGRzLmpzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbiAgICBpbXBvcnQgd2VweSBmcm9tIFwid2VweVwiO1xyXG4gICAgaW1wb3J0IGNvbmZpZyBmcm9tIFwiQC9hcGkvY29uZmlnXCJcclxuICAgIGV4cG9ydCBkZWZhdWx0IGNsYXNzIERpYWxvZyBleHRlbmRzIHdlcHkucGFnZSB7XHJcbiAgICAgICAgZGF0YSA9IHtcclxuICAgICAgICAgICAgY2xvc2U6IFwiL3N0YXRpYy9pbWFnZXMvY2xvc2UucG5nXCIsXHJcbiAgICAgICAgICAgIExpc3RUb3VjaFN0YXJ0OiAwLFxyXG4gICAgICAgICAgICBMaXN0VG91Y2hEaXJlY3Rpb246IG51bGwsXHJcbiAgICAgICAgICAgIG1vZGFsTmFtZTogbnVsbCxcclxuICAgICAgICAgICAgY2hpbGRzOiBbXSxcclxuICAgICAgICAgICAgaXNnZXQ6IGZhbHNlLFxyXG4gICAgICAgICAgICBjaGlsZHNlZDoge30sXHJcbiAgICAgICAgICAgIGxlbjogMVxyXG4gICAgICAgIH07XHJcbiAgICAgICAgY29uZmlnID0ge1xyXG4gICAgICAgICAgICBuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0OiBcIui6q+S7veS/oeaBr+euoeeQhlwiXHJcbiAgICAgICAgfTtcclxuICAgICAgICBvbkxvYWQob3B0KSB7XHJcbiAgICAgICAgICAgIHRoaXMuaXNnZXQgPSBvcHQudHlwZSA9PSAxXHJcbiAgICAgICAgICAgIHRoaXMubGVuID0gb3B0LmxlblxyXG4gICAgICAgIH1cclxuICAgICAgICBhc3luYyBvblNob3coKSB7XHJcbiAgICAgICAgICAgIGxldCB7XHJcbiAgICAgICAgICAgICAgICBjaGlsZExpc3RcclxuICAgICAgICAgICAgfSA9IGF3YWl0IGNvbmZpZy5nZXRDaGlsZExpc3QoKVxyXG4gICAgICAgICAgICB0aGlzLmNoaWxkcyA9IGNoaWxkTGlzdFxyXG4gICAgICAgICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICAgICAgICAgIC8vIHRoaXMuTGlzdFRvdWNoRGlyZWN0aW9uID0gJ3JpZ2h0J1xyXG4gICAgICAgICAgICAvLyBpZiAodGhpcy5saXN0Lmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgLy8gICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgICAgICAvLyAgICAgICAgIHRoaXMubW9kYWxOYW1lID0gJ21vdmUtYm94LTAnXHJcbiAgICAgICAgICAgIC8vICAgICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgICAgICAgICAvLyAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgICAgICAvLyAgICAgICAgICAgICB0aGlzLm1vZGFsTmFtZSA9IG51bGxcclxuICAgICAgICAgICAgLy8gICAgICAgICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgICAgICAgICAvLyAgICAgICAgIH0sIDEwMDApXHJcbiAgICAgICAgICAgIC8vICAgICB9LCAzMDApXHJcbiAgICAgICAgICAgIC8vIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgZ2V0QXJyKCkge1xyXG4gICAgICAgICAgICBsZXQgYXJyID0gW11cclxuICAgICAgICAgICAgY29uc29sZS5sb2codGhpcy5jaGlsZHNlZClcclxuICAgICAgICAgICAgZm9yIChsZXQgaSBpbiB0aGlzLmNoaWxkc2VkKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgbyA9IHRoaXMuY2hpbGRzZWRbaV07XHJcbiAgICAgICAgICAgICAgICBhcnIucHVzaChvKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuY2hpbGRzID0gYXJyXHJcbiAgICAgICAgICAgIGlmIChhcnIubGVuZ3RoID09IHRoaXMubGVuKSB7XHJcbiAgICAgICAgICAgICAgICB3ZXB5Lm5hdmlnYXRlQmFjayh7XHJcbiAgICAgICAgICAgICAgICAgICAgZGVsdGE6IDEgLy/ov5Tlm57nmoTpobXpnaLmlbDvvIzlpoLmnpwgZGVsdGEg5aSn5LqO546w5pyJ6aG16Z2i5pWw77yM5YiZ6L+U5Zue5Yiw6aaW6aG1LFxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgbWV0aG9kcyA9IHtcclxuICAgICAgICAgICAgdG9FZGl0KGlkKSB7XHJcbiAgICAgICAgICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICAgICAgICAgIHVybDogJy4vYWRkQ2hpbGQ/aWQ9JyArIGlkXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgZ2V0Q2hpbGRzKGUpIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpXHJcbiAgICAgICAgICAgICAgICBpZiAoIXRoaXMuaXNnZXQgfHwgIWUuZ3VhcmRpYW5JZCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuY2hpbGRzZWRbZS5pZF0pIHtcclxuICAgICAgICAgICAgICAgICAgICBkZWxldGUgdGhpcy5jaGlsZHNlZFtlLmlkXVxyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmNoaWxkc2VkW2UuaWRdID0gZVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgdGhpcy5nZXRBcnIoKVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBzdXJlQ2hpbGRzKCkge1xyXG4gICAgICAgICAgICAgICAgd2VweS5uYXZpZ2F0ZUJhY2soe1xyXG4gICAgICAgICAgICAgICAgICAgIGRlbHRhOiAxIC8v6L+U5Zue55qE6aG16Z2i5pWw77yM5aaC5p6cIGRlbHRhIOWkp+S6jueOsOaciemhtemdouaVsO+8jOWImei/lOWbnuWIsOmmlumhtSxcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8vIExpc3RUb3VjaFN0YXJ0KGUpIHtcclxuICAgICAgICAgICAgLy8gICAgIHRoaXMuTGlzdFRvdWNoU3RhcnQgPSBlLnRvdWNoZXNbMF0ucGFnZVhcclxuICAgICAgICAgICAgLy8gfSxcclxuICAgICAgICAgICAgLy8gLy8gTGlzdFRvdWNo6K6h566X5pa55ZCRXHJcbiAgICAgICAgICAgIC8vIExpc3RUb3VjaE1vdmUoZSkge1xyXG4gICAgICAgICAgICAvLyAgICAgdGhpcy5MaXN0VG91Y2hEaXJlY3Rpb24gPSBlLnRvdWNoZXNbMF0ucGFnZVggLSB0aGlzLmRhdGEuTGlzdFRvdWNoU3RhcnQgPiAwID8gJ3JpZ2h0JyA6ICdsZWZ0J1xyXG4gICAgICAgICAgICAvLyB9LFxyXG4gICAgICAgICAgICAvLyAvLyBMaXN0VG91Y2jorqHnrpfmu5rliqhcclxuICAgICAgICAgICAgLy8gTGlzdFRvdWNoRW5kKGUpIHtcclxuICAgICAgICAgICAgLy8gICAgIGlmICh0aGlzLkxpc3RUb3VjaERpcmVjdGlvbiA9PSAnbGVmdCcpIHtcclxuICAgICAgICAgICAgLy8gICAgICAgICB0aGlzLm1vZGFsTmFtZSA9IGUuY3VycmVudFRhcmdldC5kYXRhc2V0LnRhcmdldFxyXG4gICAgICAgICAgICAvLyAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgLy8gICAgICAgICB0aGlzLm1vZGFsTmFtZSA9IG51bGxcclxuICAgICAgICAgICAgLy8gICAgIH1cclxuICAgICAgICAgICAgLy8gICAgIHRoaXMuTGlzdFRvdWNoRGlyZWN0aW9uID0gbnVsbFxyXG4gICAgICAgICAgICAvLyB9XHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuIl19