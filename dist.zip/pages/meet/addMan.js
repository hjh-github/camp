"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _Lang = require('./../../utils/Lang.js');

var _Lang2 = _interopRequireDefault(_Lang);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
    _inherits(Dialog, _wepy$page);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
            navigationBarTitleText: "监护人信息编辑"
        }, _this.data = {
            picker: [{
                name: '内地身份证号',
                type: 1
            }, {
                name: '护照号',
                type: 2
            }, {
                name: '军官证号',
                type: 3
            }, {
                name: '港澳通行证号',
                type: 4
            }, {
                name: '台胞证号',
                type: 5
            }, {
                name: '其他证号',
                type: 6
            }],
            cardInx: 0,
            manInx: 0,
            id: '',
            end_date: '',
            form: {
                name: '',
                cardType: 1,
                cardNum: '',
                gender: 1,
                birthdayStr: ''
            }
        }, _this.methods = {
            PickerChange: function PickerChange(e) {
                this.cardInx = e.detail.value;
                this.form.cardType = this.picker[this.cardInx].type;
            },
            DateChange: function DateChange(e) {
                this.form.birthdayStr = e.detail.value;
            },
            gender: function gender(_gender) {
                this.form.gender = _gender;
            },
            input: function input(e) {
                var target = e.currentTarget.dataset.target || e.target.dataset.target,
                    type = e.currentTarget.dataset.type || e.target.dataset.type,
                    value = e.detail.value;
                // 当输入身份证号时，自动读取到生日日期
                if (target == 'cardNum' && type == 1) {
                    if (value.length == 18) {
                        var _res = _Lang2.default.getBirthdayByIdCard(value);
                        if ((typeof _res === "undefined" ? "undefined" : _typeof(_res)) == 'object') {
                            _Tips2.default.toast(_res.message, function () {}, 'none');
                        } else if (typeof _res == 'string') {
                            this.form.birthdayStr = _res;
                        }
                        this.form.gender = _Lang2.default.getSexByIdCard(value);
                    }
                }
                this.form[target] = value;
            },
            plus: function () {
                var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
                    var rules, res;
                    return regeneratorRuntime.wrap(function _callee$(_context) {
                        while (1) {
                            switch (_context.prev = _context.next) {
                                case 0:
                                    if (!(this.form.cardType == 1)) {
                                        _context.next = 5;
                                        break;
                                    }

                                    rules = _Lang2.default.checkIdCard(this.form.cardNum);

                                    if (rules.status) {
                                        _context.next = 5;
                                        break;
                                    }

                                    _Tips2.default.toast(rules.message, function () {}, 'none');
                                    return _context.abrupt("return", false);

                                case 5:
                                    if (!_Lang2.default.isEmpty(this.form.name)) {
                                        _context.next = 8;
                                        break;
                                    }

                                    _Tips2.default.toast('请填写监护人姓名', function () {}, 'none');
                                    return _context.abrupt("return", false);

                                case 8:
                                    _context.next = 10;
                                    return _config2.default.updateGua(this.form);

                                case 10:
                                    res = _context.sent;

                                    if (res.errcode == 200) {
                                        _Tips2.default.toast('保存成功', function () {
                                            _wepy2.default.navigateBack({
                                                delta: 1 //返回的页面数，如果 delta 大于现有页面数，则返回到首页,
                                            });
                                        }, 'none');
                                    }

                                case 12:
                                case "end":
                                    return _context.stop();
                            }
                        }
                    }, _callee, this);
                }));

                function plus() {
                    return _ref2.apply(this, arguments);
                }

                return plus;
            }(),
            delGua: function () {
                var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
                    var self;
                    return regeneratorRuntime.wrap(function _callee3$(_context3) {
                        while (1) {
                            switch (_context3.prev = _context3.next) {
                                case 0:
                                    self = this;

                                    wx.showModal({
                                        content: "\u786E\u5B9A\u5220\u9664\u76D1\u62A4\u4EBA" + self.form.name + "\u5417\uFF1F",
                                        success: function () {
                                            var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(res) {
                                                var _res2;

                                                return regeneratorRuntime.wrap(function _callee2$(_context2) {
                                                    while (1) {
                                                        switch (_context2.prev = _context2.next) {
                                                            case 0:
                                                                if (!res.confirm) {
                                                                    _context2.next = 7;
                                                                    break;
                                                                }

                                                                _context2.next = 3;
                                                                return _config2.default.delGua(self.id);

                                                            case 3:
                                                                _res2 = _context2.sent;

                                                                if (_res2.errcode == 200) {
                                                                    _Tips2.default.toast('删除成功', function () {
                                                                        _wepy2.default.navigateBack({
                                                                            delta: 1 //返回的页面数，如果 delta 大于现有页面数，则返回到首页,
                                                                        });
                                                                    }, 'none');
                                                                }
                                                                _context2.next = 8;
                                                                break;

                                                            case 7:
                                                                if (res.cancel) {}

                                                            case 8:
                                                            case "end":
                                                                return _context2.stop();
                                                        }
                                                    }
                                                }, _callee2, this);
                                            }));

                                            function success(_x) {
                                                return _ref4.apply(this, arguments);
                                            }

                                            return success;
                                        }()
                                    });

                                case 2:
                                case "end":
                                    return _context3.stop();
                            }
                        }
                    }, _callee3, this);
                }));

                function delGua() {
                    return _ref3.apply(this, arguments);
                }

                return delGua;
            }()
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(Dialog, [{
        key: "onLoad",
        value: function onLoad(opt) {
            this.id = opt.id;
            this.end_date = _Lang2.default.dateFormate(new Date(), 'yyyy-MM-dd');
            if (this.id == -1) {
                this.form.birthdayStr = this.end_date;
            } else {
                this.getGua(this.id);
            }
        }
    }, {
        key: "getGua",
        value: function () {
            var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4(id) {
                var res;
                return regeneratorRuntime.wrap(function _callee4$(_context4) {
                    while (1) {
                        switch (_context4.prev = _context4.next) {
                            case 0:
                                _context4.next = 2;
                                return _config2.default.getGua(id);

                            case 2:
                                res = _context4.sent;

                                this.form = {
                                    name: res.name,
                                    cardType: res.cardType,
                                    cardNum: res.cardNum,
                                    gender: res.gender,
                                    birthdayStr: res.birthday,
                                    id: res.id
                                };
                                this.$apply();

                            case 5:
                            case "end":
                                return _context4.stop();
                        }
                    }
                }, _callee4, this);
            }));

            function getGua(_x2) {
                return _ref5.apply(this, arguments);
            }

            return getGua;
        }()
    }]);

    return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/meet/addMan'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFkZE1hbi5qcyJdLCJuYW1lcyI6WyJEaWFsb2ciLCJjb25maWciLCJuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0IiwiZGF0YSIsInBpY2tlciIsIm5hbWUiLCJ0eXBlIiwiY2FyZElueCIsIm1hbklueCIsImlkIiwiZW5kX2RhdGUiLCJmb3JtIiwiY2FyZFR5cGUiLCJjYXJkTnVtIiwiZ2VuZGVyIiwiYmlydGhkYXlTdHIiLCJtZXRob2RzIiwiUGlja2VyQ2hhbmdlIiwiZSIsImRldGFpbCIsInZhbHVlIiwiRGF0ZUNoYW5nZSIsImlucHV0IiwidGFyZ2V0IiwiY3VycmVudFRhcmdldCIsImRhdGFzZXQiLCJsZW5ndGgiLCJfcmVzIiwiTGFuZyIsImdldEJpcnRoZGF5QnlJZENhcmQiLCJUaXBzIiwidG9hc3QiLCJtZXNzYWdlIiwiZ2V0U2V4QnlJZENhcmQiLCJwbHVzIiwicnVsZXMiLCJjaGVja0lkQ2FyZCIsInN0YXR1cyIsImlzRW1wdHkiLCJ1cGRhdGVHdWEiLCJyZXMiLCJlcnJjb2RlIiwid2VweSIsIm5hdmlnYXRlQmFjayIsImRlbHRhIiwiZGVsR3VhIiwic2VsZiIsInd4Iiwic2hvd01vZGFsIiwiY29udGVudCIsInN1Y2Nlc3MiLCJjb25maXJtIiwiY2FuY2VsIiwib3B0IiwiZGF0ZUZvcm1hdGUiLCJEYXRlIiwiZ2V0R3VhIiwiYmlydGhkYXkiLCIkYXBwbHkiLCJwYWdlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUNJOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7Ozs7Ozs7Ozs7OztJQUNxQkEsTTs7Ozs7Ozs7Ozs7Ozs7MExBQ2pCQyxNLEdBQVM7QUFDTEMsb0NBQXdCO0FBRG5CLFMsUUFHVEMsSSxHQUFPO0FBQ0hDLG9CQUFRLENBQUM7QUFDTEMsc0JBQU0sUUFERDtBQUVMQyxzQkFBTTtBQUZELGFBQUQsRUFHTDtBQUNDRCxzQkFBTSxLQURQO0FBRUNDLHNCQUFNO0FBRlAsYUFISyxFQU1MO0FBQ0NELHNCQUFNLE1BRFA7QUFFQ0Msc0JBQU07QUFGUCxhQU5LLEVBU0w7QUFDQ0Qsc0JBQU0sUUFEUDtBQUVDQyxzQkFBTTtBQUZQLGFBVEssRUFZTDtBQUNDRCxzQkFBTSxNQURQO0FBRUNDLHNCQUFNO0FBRlAsYUFaSyxFQWVMO0FBQ0NELHNCQUFNLE1BRFA7QUFFQ0Msc0JBQU07QUFGUCxhQWZLLENBREw7QUFvQkhDLHFCQUFTLENBcEJOO0FBcUJIQyxvQkFBUSxDQXJCTDtBQXNCSEMsZ0JBQUksRUF0QkQ7QUF1QkhDLHNCQUFVLEVBdkJQO0FBd0JIQyxrQkFBTTtBQUNGTixzQkFBTSxFQURKO0FBRUZPLDBCQUFVLENBRlI7QUFHRkMseUJBQVMsRUFIUDtBQUlGQyx3QkFBUSxDQUpOO0FBS0ZDLDZCQUFhO0FBTFg7QUF4QkgsUyxRQXFEUEMsTyxHQUFVO0FBQ05DLHdCQURNLHdCQUNPQyxDQURQLEVBQ1U7QUFDWixxQkFBS1gsT0FBTCxHQUFlVyxFQUFFQyxNQUFGLENBQVNDLEtBQXhCO0FBQ0EscUJBQUtULElBQUwsQ0FBVUMsUUFBVixHQUFxQixLQUFLUixNQUFMLENBQVksS0FBS0csT0FBakIsRUFBMEJELElBQS9DO0FBQ0gsYUFKSztBQUtOZSxzQkFMTSxzQkFLS0gsQ0FMTCxFQUtRO0FBQ1YscUJBQUtQLElBQUwsQ0FBVUksV0FBVixHQUF3QkcsRUFBRUMsTUFBRixDQUFTQyxLQUFqQztBQUNILGFBUEs7QUFRTk4sa0JBUk0sa0JBUUNBLE9BUkQsRUFRUztBQUNYLHFCQUFLSCxJQUFMLENBQVVHLE1BQVYsR0FBbUJBLE9BQW5CO0FBQ0gsYUFWSztBQVdOUSxpQkFYTSxpQkFXQUosQ0FYQSxFQVdHO0FBQ0wsb0JBQUlLLFNBQVNMLEVBQUVNLGFBQUYsQ0FBZ0JDLE9BQWhCLENBQXdCRixNQUF4QixJQUFrQ0wsRUFBRUssTUFBRixDQUFTRSxPQUFULENBQWlCRixNQUFoRTtBQUFBLG9CQUNJakIsT0FBT1ksRUFBRU0sYUFBRixDQUFnQkMsT0FBaEIsQ0FBd0JuQixJQUF4QixJQUFnQ1ksRUFBRUssTUFBRixDQUFTRSxPQUFULENBQWlCbkIsSUFENUQ7QUFBQSxvQkFFSWMsUUFBUUYsRUFBRUMsTUFBRixDQUFTQyxLQUZyQjtBQUdBO0FBQ0Esb0JBQUlHLFVBQVUsU0FBVixJQUF1QmpCLFFBQVEsQ0FBbkMsRUFBc0M7QUFDbEMsd0JBQUljLE1BQU1NLE1BQU4sSUFBZ0IsRUFBcEIsRUFBd0I7QUFDcEIsNEJBQUlDLE9BQU9DLGVBQUtDLG1CQUFMLENBQXlCVCxLQUF6QixDQUFYO0FBQ0EsNEJBQUksUUFBT08sSUFBUCx5Q0FBT0EsSUFBUCxNQUFlLFFBQW5CLEVBQTZCO0FBQ3pCRywyQ0FBS0MsS0FBTCxDQUFXSixLQUFLSyxPQUFoQixFQUF5QixZQUFNLENBQUUsQ0FBakMsRUFBbUMsTUFBbkM7QUFDSCx5QkFGRCxNQUVPLElBQUksT0FBT0wsSUFBUCxJQUFlLFFBQW5CLEVBQTZCO0FBQ2hDLGlDQUFLaEIsSUFBTCxDQUFVSSxXQUFWLEdBQXdCWSxJQUF4QjtBQUNIO0FBQ0QsNkJBQUtoQixJQUFMLENBQVVHLE1BQVYsR0FBbUJjLGVBQUtLLGNBQUwsQ0FBb0JiLEtBQXBCLENBQW5CO0FBQ0g7QUFDSjtBQUNELHFCQUFLVCxJQUFMLENBQVVZLE1BQVYsSUFBb0JILEtBQXBCO0FBQ0gsYUE1Qks7QUE2QkFjLGdCQTdCQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBDQThCRSxLQUFLdkIsSUFBTCxDQUFVQyxRQUFWLElBQXNCLENBOUJ4QjtBQUFBO0FBQUE7QUFBQTs7QUErQk11Qix5Q0EvQk4sR0ErQmNQLGVBQUtRLFdBQUwsQ0FBaUIsS0FBS3pCLElBQUwsQ0FBVUUsT0FBM0IsQ0EvQmQ7O0FBQUEsd0NBZ0NPc0IsTUFBTUUsTUFoQ2I7QUFBQTtBQUFBO0FBQUE7O0FBaUNNUCxtREFBS0MsS0FBTCxDQUFXSSxNQUFNSCxPQUFqQixFQUEwQixZQUFNLENBQUUsQ0FBbEMsRUFBb0MsTUFBcEM7QUFqQ04scUVBa0NhLEtBbENiOztBQUFBO0FBQUEseUNBcUNFSixlQUFLVSxPQUFMLENBQWEsS0FBSzNCLElBQUwsQ0FBVU4sSUFBdkIsQ0FyQ0Y7QUFBQTtBQUFBO0FBQUE7O0FBc0NFeUIsbURBQUtDLEtBQUwsQ0FBVyxVQUFYLEVBQXVCLFlBQU0sQ0FBRSxDQUEvQixFQUFpQyxNQUFqQztBQXRDRixxRUF1Q1MsS0F2Q1Q7O0FBQUE7QUFBQTtBQUFBLDJDQXlDYzlCLGlCQUFPc0MsU0FBUCxDQUFpQixLQUFLNUIsSUFBdEIsQ0F6Q2Q7O0FBQUE7QUF5Q0U2Qix1Q0F6Q0Y7O0FBMENGLHdDQUFJQSxJQUFJQyxPQUFKLElBQWUsR0FBbkIsRUFBd0I7QUFDcEJYLHVEQUFLQyxLQUFMLENBQVcsTUFBWCxFQUFtQixZQUFNO0FBQ3JCVywyREFBS0MsWUFBTCxDQUFrQjtBQUNkQyx1REFBTyxDQURPLENBQ0w7QUFESyw2Q0FBbEI7QUFHSCx5Q0FKRCxFQUlHLE1BSkg7QUFLSDs7QUFoREM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFrREFDLGtCQWxEQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQW1ERUMsd0NBbkRGLEdBbURTLElBbkRUOztBQW9ERkMsdUNBQUdDLFNBQUgsQ0FBYTtBQUNUQyxnR0FBbUJILEtBQUtuQyxJQUFMLENBQVVOLElBQTdCLGlCQURTO0FBRVQ2QztBQUFBLGdIQUFTLGtCQUFlVixHQUFmO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxRUFDREEsSUFBSVcsT0FESDtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBLHVFQUVlbEQsaUJBQU80QyxNQUFQLENBQWNDLEtBQUtyQyxFQUFuQixDQUZmOztBQUFBO0FBRUcrQixxRUFGSDs7QUFHRCxvRUFBSUEsTUFBSUMsT0FBSixJQUFlLEdBQW5CLEVBQXdCO0FBQ3BCWCxtRkFBS0MsS0FBTCxDQUFXLE1BQVgsRUFBbUIsWUFBTTtBQUNyQlcsdUZBQUtDLFlBQUwsQ0FBa0I7QUFDZEMsbUZBQU8sQ0FETyxDQUNMO0FBREsseUVBQWxCO0FBR0gscUVBSkQsRUFJRyxNQUpIO0FBS0g7QUFUQTtBQUFBOztBQUFBO0FBVUUsb0VBQUlKLElBQUlZLE1BQVIsRUFBZ0IsQ0FBRTs7QUFWcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkNBQVQ7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFGUyxxQ0FBYjs7QUFwREU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQSxTOzs7OzsrQkFyQkhDLEcsRUFBSztBQUNSLGlCQUFLNUMsRUFBTCxHQUFVNEMsSUFBSTVDLEVBQWQ7QUFDQSxpQkFBS0MsUUFBTCxHQUFnQmtCLGVBQUswQixXQUFMLENBQWlCLElBQUlDLElBQUosRUFBakIsRUFBNkIsWUFBN0IsQ0FBaEI7QUFDQSxnQkFBSSxLQUFLOUMsRUFBTCxJQUFXLENBQUMsQ0FBaEIsRUFBbUI7QUFDZixxQkFBS0UsSUFBTCxDQUFVSSxXQUFWLEdBQXdCLEtBQUtMLFFBQTdCO0FBQ0gsYUFGRCxNQUVPO0FBQ0gscUJBQUs4QyxNQUFMLENBQVksS0FBSy9DLEVBQWpCO0FBQ0g7QUFDSjs7OztrR0FDWUEsRTs7Ozs7Ozt1Q0FDT1IsaUJBQU91RCxNQUFQLENBQWMvQyxFQUFkLEM7OztBQUFaK0IsbUM7O0FBQ0oscUNBQUs3QixJQUFMLEdBQVk7QUFDUk4sMENBQU1tQyxJQUFJbkMsSUFERjtBQUVSTyw4Q0FBVTRCLElBQUk1QixRQUZOO0FBR1JDLDZDQUFTMkIsSUFBSTNCLE9BSEw7QUFJUkMsNENBQVEwQixJQUFJMUIsTUFKSjtBQUtSQyxpREFBYXlCLElBQUlpQixRQUxUO0FBTVJoRCx3Q0FBSStCLElBQUkvQjtBQU5BLGlDQUFaO0FBUUEscUNBQUtpRCxNQUFMOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBdkQ0QmhCLGVBQUtpQixJOztrQkFBcEIzRCxNIiwiZmlsZSI6ImFkZE1hbi5qcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4gICAgaW1wb3J0IHdlcHkgZnJvbSBcIndlcHlcIlxyXG4gICAgaW1wb3J0IExhbmcgZnJvbSBcIkAvdXRpbHMvTGFuZ1wiXHJcbiAgICBpbXBvcnQgVGlwcyBmcm9tIFwiQC91dGlscy9UaXBzXCJcclxuICAgIGltcG9ydCBjb25maWcgZnJvbSBcIkAvYXBpL2NvbmZpZ1wiXHJcbiAgICBleHBvcnQgZGVmYXVsdCBjbGFzcyBEaWFsb2cgZXh0ZW5kcyB3ZXB5LnBhZ2Uge1xyXG4gICAgICAgIGNvbmZpZyA9IHtcclxuICAgICAgICAgICAgbmF2aWdhdGlvbkJhclRpdGxlVGV4dDogXCLnm5HmiqTkurrkv6Hmga/nvJbovpFcIlxyXG4gICAgICAgIH07XHJcbiAgICAgICAgZGF0YSA9IHtcclxuICAgICAgICAgICAgcGlja2VyOiBbe1xyXG4gICAgICAgICAgICAgICAgbmFtZTogJ+WGheWcsOi6q+S7veivgeWPtycsXHJcbiAgICAgICAgICAgICAgICB0eXBlOiAxXHJcbiAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgIG5hbWU6ICfmiqTnhaflj7cnLFxyXG4gICAgICAgICAgICAgICAgdHlwZTogMlxyXG4gICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICBuYW1lOiAn5Yab5a6Y6K+B5Y+3JyxcclxuICAgICAgICAgICAgICAgIHR5cGU6IDNcclxuICAgICAgICAgICAgfSwge1xyXG4gICAgICAgICAgICAgICAgbmFtZTogJ+a4r+a+s+mAmuihjOivgeWPtycsXHJcbiAgICAgICAgICAgICAgICB0eXBlOiA0XHJcbiAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgIG5hbWU6ICflj7Dog57or4Hlj7cnLFxyXG4gICAgICAgICAgICAgICAgdHlwZTogNVxyXG4gICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICBuYW1lOiAn5YW25LuW6K+B5Y+3JyxcclxuICAgICAgICAgICAgICAgIHR5cGU6IDZcclxuICAgICAgICAgICAgfSwgXSxcclxuICAgICAgICAgICAgY2FyZElueDogMCxcclxuICAgICAgICAgICAgbWFuSW54OiAwLFxyXG4gICAgICAgICAgICBpZDogJycsXHJcbiAgICAgICAgICAgIGVuZF9kYXRlOiAnJyxcclxuICAgICAgICAgICAgZm9ybToge1xyXG4gICAgICAgICAgICAgICAgbmFtZTogJycsXHJcbiAgICAgICAgICAgICAgICBjYXJkVHlwZTogMSxcclxuICAgICAgICAgICAgICAgIGNhcmROdW06ICcnLFxyXG4gICAgICAgICAgICAgICAgZ2VuZGVyOiAxLFxyXG4gICAgICAgICAgICAgICAgYmlydGhkYXlTdHI6ICcnXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9O1xyXG4gICAgICAgIG9uTG9hZChvcHQpIHtcclxuICAgICAgICAgICAgdGhpcy5pZCA9IG9wdC5pZFxyXG4gICAgICAgICAgICB0aGlzLmVuZF9kYXRlID0gTGFuZy5kYXRlRm9ybWF0ZShuZXcgRGF0ZSgpLCAneXl5eS1NTS1kZCcpXHJcbiAgICAgICAgICAgIGlmICh0aGlzLmlkID09IC0xKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmZvcm0uYmlydGhkYXlTdHIgPSB0aGlzLmVuZF9kYXRlXHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmdldEd1YSh0aGlzLmlkKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGFzeW5jIGdldEd1YShpZCkge1xyXG4gICAgICAgICAgICBsZXQgcmVzID0gYXdhaXQgY29uZmlnLmdldEd1YShpZClcclxuICAgICAgICAgICAgdGhpcy5mb3JtID0ge1xyXG4gICAgICAgICAgICAgICAgbmFtZTogcmVzLm5hbWUsXHJcbiAgICAgICAgICAgICAgICBjYXJkVHlwZTogcmVzLmNhcmRUeXBlLFxyXG4gICAgICAgICAgICAgICAgY2FyZE51bTogcmVzLmNhcmROdW0sXHJcbiAgICAgICAgICAgICAgICBnZW5kZXI6IHJlcy5nZW5kZXIsXHJcbiAgICAgICAgICAgICAgICBiaXJ0aGRheVN0cjogcmVzLmJpcnRoZGF5LFxyXG4gICAgICAgICAgICAgICAgaWQ6IHJlcy5pZFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgICB9XHJcbiAgICAgICAgbWV0aG9kcyA9IHtcclxuICAgICAgICAgICAgUGlja2VyQ2hhbmdlKGUpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuY2FyZElueCA9IGUuZGV0YWlsLnZhbHVlXHJcbiAgICAgICAgICAgICAgICB0aGlzLmZvcm0uY2FyZFR5cGUgPSB0aGlzLnBpY2tlclt0aGlzLmNhcmRJbnhdLnR5cGVcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgRGF0ZUNoYW5nZShlKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmZvcm0uYmlydGhkYXlTdHIgPSBlLmRldGFpbC52YWx1ZVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBnZW5kZXIoZ2VuZGVyKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmZvcm0uZ2VuZGVyID0gZ2VuZGVyXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGlucHV0KGUpIHtcclxuICAgICAgICAgICAgICAgIGxldCB0YXJnZXQgPSBlLmN1cnJlbnRUYXJnZXQuZGF0YXNldC50YXJnZXQgfHwgZS50YXJnZXQuZGF0YXNldC50YXJnZXQsXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZSA9IGUuY3VycmVudFRhcmdldC5kYXRhc2V0LnR5cGUgfHwgZS50YXJnZXQuZGF0YXNldC50eXBlLFxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlID0gZS5kZXRhaWwudmFsdWU7XHJcbiAgICAgICAgICAgICAgICAvLyDlvZPovpPlhaXouqvku73or4Hlj7fml7bvvIzoh6rliqjor7vlj5bliLDnlJ/ml6Xml6XmnJ9cclxuICAgICAgICAgICAgICAgIGlmICh0YXJnZXQgPT0gJ2NhcmROdW0nICYmIHR5cGUgPT0gMSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh2YWx1ZS5sZW5ndGggPT0gMTgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IF9yZXMgPSBMYW5nLmdldEJpcnRoZGF5QnlJZENhcmQodmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgX3JlcyA9PSAnb2JqZWN0Jykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVGlwcy50b2FzdChfcmVzLm1lc3NhZ2UsICgpID0+IHt9LCAnbm9uZScpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAodHlwZW9mIF9yZXMgPT0gJ3N0cmluZycpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZm9ybS5iaXJ0aGRheVN0ciA9IF9yZXNcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmZvcm0uZ2VuZGVyID0gTGFuZy5nZXRTZXhCeUlkQ2FyZCh2YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB0aGlzLmZvcm1bdGFyZ2V0XSA9IHZhbHVlXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGFzeW5jIHBsdXMoKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5mb3JtLmNhcmRUeXBlID09IDEpIHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgcnVsZXMgPSBMYW5nLmNoZWNrSWRDYXJkKHRoaXMuZm9ybS5jYXJkTnVtKVxyXG4gICAgICAgICAgICAgICAgICAgIGlmICghcnVsZXMuc3RhdHVzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFRpcHMudG9hc3QocnVsZXMubWVzc2FnZSwgKCkgPT4ge30sICdub25lJylcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgaWYgKExhbmcuaXNFbXB0eSh0aGlzLmZvcm0ubmFtZSkpIHtcclxuICAgICAgICAgICAgICAgICAgICBUaXBzLnRvYXN0KCfor7floavlhpnnm5HmiqTkurrlp5PlkI0nLCAoKSA9PiB7fSwgJ25vbmUnKVxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGNvbmZpZy51cGRhdGVHdWEodGhpcy5mb3JtKVxyXG4gICAgICAgICAgICAgICAgaWYgKHJlcy5lcnJjb2RlID09IDIwMCkge1xyXG4gICAgICAgICAgICAgICAgICAgIFRpcHMudG9hc3QoJ+S/neWtmOaIkOWKnycsICgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgd2VweS5uYXZpZ2F0ZUJhY2soe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVsdGE6IDEgLy/ov5Tlm57nmoTpobXpnaLmlbDvvIzlpoLmnpwgZGVsdGEg5aSn5LqO546w5pyJ6aG16Z2i5pWw77yM5YiZ6L+U5Zue5Yiw6aaW6aG1LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICB9LCAnbm9uZScpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGFzeW5jIGRlbEd1YSgpIHtcclxuICAgICAgICAgICAgICAgIGxldCBzZWxmID0gdGhpc1xyXG4gICAgICAgICAgICAgICAgd3guc2hvd01vZGFsKHtcclxuICAgICAgICAgICAgICAgICAgICBjb250ZW50OiBg56Gu5a6a5Yig6Zmk55uR5oqk5Lq6JHtzZWxmLmZvcm0ubmFtZX3lkJfvvJ9gLFxyXG4gICAgICAgICAgICAgICAgICAgIHN1Y2Nlc3M6IGFzeW5jIGZ1bmN0aW9uKHJlcykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzLmNvbmZpcm0pIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCByZXMgPSBhd2FpdCBjb25maWcuZGVsR3VhKHNlbGYuaWQpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzLmVycmNvZGUgPT0gMjAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVGlwcy50b2FzdCgn5Yig6Zmk5oiQ5YqfJywgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB3ZXB5Lm5hdmlnYXRlQmFjayh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZWx0YTogMSAvL+i/lOWbnueahOmhtemdouaVsO+8jOWmguaenCBkZWx0YSDlpKfkuo7njrDmnInpobXpnaLmlbDvvIzliJnov5Tlm57liLDpppbpobUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sICdub25lJylcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChyZXMuY2FuY2VsKSB7fVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9O1xyXG4gICAgfVxyXG4iXX0=