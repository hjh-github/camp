"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});


var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

var _remake = require('./../../components/detaile/remake.js');

var _remake2 = _interopRequireDefault(_remake);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
  _inherits(Dialog, _wepy$page);

  function Dialog() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, Dialog);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
      navigationBarTitleText: "全部评论"
    }, _this.data = {
      statistics: [],
      CourseComments: [],
      opt: {},
      pageIndex: 1
    }, _this.components = {
      cRemake: _remake2.default
    }, _this.methods = {
      turnTag: function () {
        var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(e) {
          return regeneratorRuntime.wrap(function _callee$(_context) {
            while (1) {
              switch (_context.prev = _context.next) {
                case 0:
                  this.opt.tag = e.currentTarget.dataset.id || e.target.dataset.id;
                  _context.next = 3;
                  return this.load();

                case 3:
                  this.CourseComments = _context.sent;

                case 4:
                case "end":
                  return _context.stop();
              }
            }
          }, _callee, this);
        }));

        function turnTag(_x) {
          return _ref2.apply(this, arguments);
        }

        return turnTag;
      }()
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(Dialog, [{
    key: "onLoad",
    value: function () {
      var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(opt) {
        return regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                this.opt = opt;
                _context2.next = 3;
                return this.load();

              case 3:
                this.CourseComments = _context2.sent;

                console.log(this.CourseComments);
                this.$apply();

              case 6:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));

      function onLoad(_x2) {
        return _ref3.apply(this, arguments);
      }

      return onLoad;
    }()
  }, {
    key: "load",
    value: function () {
      var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
        var res;
        return regeneratorRuntime.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                _context3.next = 2;
                return _config2.default.comments(_extends({}, this.opt, {
                  pageIndex: this.pageIndex
                }));

              case 2:
                res = _context3.sent;
                return _context3.abrupt("return", res);

              case 4:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this);
      }));

      function load() {
        return _ref4.apply(this, arguments);
      }

      return load;
    }()
  }, {
    key: "onReachBottom",
    value: function () {
      var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
        var newlist;
        return regeneratorRuntime.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                this.pageIndex++;
                _context4.next = 3;
                return this.load();

              case 3:
                newlist = _context4.sent;

                if (newlist.length) {
                  this.CourseComments = this.CourseComments.concat(newlist);
                } else {
                  _Tips2.default.toast('人家也是有底线的啦 ~', function () {}, 'none');
                  this.pageIndex--;
                }
                this.$apply();

              case 6:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, this);
      }));

      function onReachBottom() {
        return _ref5.apply(this, arguments);
      }

      return onReachBottom;
    }()
  }]);

  return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/meet/remarks'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJlbWFya3MuanMiXSwibmFtZXMiOlsiRGlhbG9nIiwiY29uZmlnIiwibmF2aWdhdGlvbkJhclRpdGxlVGV4dCIsImRhdGEiLCJzdGF0aXN0aWNzIiwiQ291cnNlQ29tbWVudHMiLCJvcHQiLCJwYWdlSW5kZXgiLCJjb21wb25lbnRzIiwiY1JlbWFrZSIsIm1ldGhvZHMiLCJ0dXJuVGFnIiwiZSIsInRhZyIsImN1cnJlbnRUYXJnZXQiLCJkYXRhc2V0IiwiaWQiLCJ0YXJnZXQiLCJsb2FkIiwiY29uc29sZSIsImxvZyIsIiRhcHBseSIsImNvbW1lbnRzIiwicmVzIiwibmV3bGlzdCIsImxlbmd0aCIsImNvbmNhdCIsIlRpcHMiLCJ0b2FzdCIsIndlcHkiLCJwYWdlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUNFOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7Ozs7Ozs7Ozs7OztJQUNxQkEsTTs7Ozs7Ozs7Ozs7Ozs7c0xBQ25CQyxNLEdBQVM7QUFDUEMsOEJBQXdCO0FBRGpCLEssUUFHVEMsSSxHQUFPO0FBQ0xDLGtCQUFZLEVBRFA7QUFFTEMsc0JBQWdCLEVBRlg7QUFHTEMsV0FBSyxFQUhBO0FBSUxDLGlCQUFXO0FBSk4sSyxRQW1CUEMsVSxHQUFhO0FBQ1hDO0FBRFcsSyxRQWNiQyxPLEdBQVU7QUFDRkMsYUFERTtBQUFBLDZGQUNNQyxDQUROO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFTix1QkFBS04sR0FBTCxDQUFTTyxHQUFULEdBQWVELEVBQUVFLGFBQUYsQ0FBZ0JDLE9BQWhCLENBQXdCQyxFQUF4QixJQUE4QkosRUFBRUssTUFBRixDQUFTRixPQUFULENBQWlCQyxFQUE5RDtBQUZNO0FBQUEseUJBR3NCLEtBQUtFLElBQUwsRUFIdEI7O0FBQUE7QUFHTix1QkFBS2IsY0FIQzs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBLEs7Ozs7Ozs0RkEzQkdDLEc7Ozs7O0FBQ1gscUJBQUtBLEdBQUwsR0FBV0EsR0FBWDs7dUJBQzRCLEtBQUtZLElBQUwsRTs7O0FBQTVCLHFCQUFLYixjOztBQUNMYyx3QkFBUUMsR0FBUixDQUFZLEtBQUtmLGNBQWpCO0FBQ0EscUJBQUtnQixNQUFMOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozt1QkFHZ0JwQixpQkFBT3FCLFFBQVAsY0FDWCxLQUFLaEIsR0FETTtBQUVkQyw2QkFBVyxLQUFLQTtBQUZGLG1COzs7QUFBWmdCLG1CO2tEQUlHQSxHOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBTVAscUJBQUtoQixTQUFMOzt1QkFDc0IsS0FBS1csSUFBTCxFOzs7QUFBaEJNLHVCOztBQUNOLG9CQUFJQSxRQUFRQyxNQUFaLEVBQW9CO0FBQ2xCLHVCQUFLcEIsY0FBTCxHQUFzQixLQUFLQSxjQUFMLENBQW9CcUIsTUFBcEIsQ0FBMkJGLE9BQTNCLENBQXRCO0FBQ0QsaUJBRkQsTUFFTztBQUNMRyxpQ0FBS0MsS0FBTCxDQUFXLGFBQVgsRUFBMEIsWUFBTSxDQUFFLENBQWxDLEVBQW9DLE1BQXBDO0FBQ0EsdUJBQUtyQixTQUFMO0FBQ0Q7QUFDRCxxQkFBS2MsTUFBTDs7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQW5DZ0NRLGVBQUtDLEk7O2tCQUFwQjlCLE0iLCJmaWxlIjoicmVtYXJrcy5qcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4gIGltcG9ydCB3ZXB5IGZyb20gXCJ3ZXB5XCI7XHJcbiAgaW1wb3J0IGNvbmZpZyBmcm9tIFwiQC9hcGkvY29uZmlnXCI7XHJcbiAgaW1wb3J0IFRpcHMgZnJvbSBcIkAvdXRpbHMvVGlwc1wiXHJcbiAgaW1wb3J0IGNSZW1ha2UgZnJvbSBcIkAvY29tcG9uZW50cy9kZXRhaWxlL3JlbWFrZVwiO1xyXG4gIGV4cG9ydCBkZWZhdWx0IGNsYXNzIERpYWxvZyBleHRlbmRzIHdlcHkucGFnZSB7XHJcbiAgICBjb25maWcgPSB7XHJcbiAgICAgIG5hdmlnYXRpb25CYXJUaXRsZVRleHQ6IFwi5YWo6YOo6K+E6K66XCJcclxuICAgIH07XHJcbiAgICBkYXRhID0ge1xyXG4gICAgICBzdGF0aXN0aWNzOiBbXSxcclxuICAgICAgQ291cnNlQ29tbWVudHM6IFtdLFxyXG4gICAgICBvcHQ6IHt9LFxyXG4gICAgICBwYWdlSW5kZXg6IDFcclxuICAgIH07XHJcbiAgICBhc3luYyBvbkxvYWQob3B0KSB7XHJcbiAgICAgIHRoaXMub3B0ID0gb3B0XHJcbiAgICAgIHRoaXMuQ291cnNlQ29tbWVudHMgPSBhd2FpdCB0aGlzLmxvYWQoKVxyXG4gICAgICBjb25zb2xlLmxvZyh0aGlzLkNvdXJzZUNvbW1lbnRzKVxyXG4gICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICB9XHJcbiAgICBhc3luYyBsb2FkKCkge1xyXG4gICAgICBsZXQgcmVzID0gYXdhaXQgY29uZmlnLmNvbW1lbnRzKHtcclxuICAgICAgICAuLi50aGlzLm9wdCxcclxuICAgICAgICBwYWdlSW5kZXg6IHRoaXMucGFnZUluZGV4XHJcbiAgICAgIH0pXHJcbiAgICAgIHJldHVybiByZXNcclxuICAgIH1cclxuICAgIGNvbXBvbmVudHMgPSB7XHJcbiAgICAgIGNSZW1ha2VcclxuICAgIH07XHJcbiAgICBhc3luYyBvblJlYWNoQm90dG9tKCkge1xyXG4gICAgICB0aGlzLnBhZ2VJbmRleCsrXHJcbiAgICAgICAgbGV0IG5ld2xpc3QgPSBhd2FpdCB0aGlzLmxvYWQoKVxyXG4gICAgICBpZiAobmV3bGlzdC5sZW5ndGgpIHtcclxuICAgICAgICB0aGlzLkNvdXJzZUNvbW1lbnRzID0gdGhpcy5Db3Vyc2VDb21tZW50cy5jb25jYXQobmV3bGlzdClcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBUaXBzLnRvYXN0KCfkurrlrrbkuZ/mmK/mnInlupXnur/nmoTllaYgficsICgpID0+IHt9LCAnbm9uZScpXHJcbiAgICAgICAgdGhpcy5wYWdlSW5kZXgtLVxyXG4gICAgICB9XHJcbiAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgIH1cclxuICAgIG1ldGhvZHMgPSB7XHJcbiAgICAgIGFzeW5jIHR1cm5UYWcoZSkge1xyXG4gICAgICAgIHRoaXMub3B0LnRhZyA9IGUuY3VycmVudFRhcmdldC5kYXRhc2V0LmlkIHx8IGUudGFyZ2V0LmRhdGFzZXQuaWRcclxuICAgICAgICB0aGlzLkNvdXJzZUNvbW1lbnRzID0gYXdhaXQgdGhpcy5sb2FkKClcclxuICAgICAgfVxyXG4gICAgfTtcclxuICB9XHJcbiJdfQ==