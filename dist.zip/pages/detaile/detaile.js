"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _swiper = require('./../../components/common/swiper.js');

var _swiper2 = _interopRequireDefault(_swiper);

var _title = require('./../../components/detaile/title.js');

var _title2 = _interopRequireDefault(_title);

var _info = require('./../../components/detaile/info.js');

var _info2 = _interopRequireDefault(_info);

var _remake = require('./../../components/detaile/remake.js');

var _remake2 = _interopRequireDefault(_remake);

var _contact = require('./../../components/common/contact.js');

var _contact2 = _interopRequireDefault(_contact);

var _utils = require('./../../store/utils.js');

var _utils2 = _interopRequireDefault(_utils);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

var _WxUtils = require('./../../utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
  _inherits(Dialog, _wepy$page);

  function Dialog() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, Dialog);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.data = {
      TabCur: 0,
      close: "/static/images/close.png",
      swipers: {
        type: 1,
        list: [{
          id: 0,
          type: "image",
          url: "",
          link: "/pages/meet/meet",
          linkType: "switchTab"
        }]
      },
      mainHeight: 0,
      courseInfo: {},
      nodes: ["name", "attrs", "attrs"],
      num: 1,
      showSku: false,
      buyTypt: 'normal',
      courseInx: -1,
      companions: [],
      statistics: {},
      CourseComment: {},
      ActPintuan: {},
      sign_states: {
        0: '火热招生中',
        1: '少量名额',
        2: '已满员'
      },
      toPintuan: false,
      modalName: '',
      customerService: {},
      member: {},
      paymentType: 1
    }, _this.$repeat = {}, _this.$props = { "cSwiper": { "xmlns:v-bind": "", "v-bind:model.sync": "swipers" }, "ctitle": { "v-bind:model.sync": "courseInfo" }, "cInfo": { "v-bind:model.sync": "courseInfo", "v-bind:companions.sync": "companions" }, "cRemake": { "v-bind:model.sync": "courseInfo", "v-bind:statistics.sync": "statistics", "v-bind:CourseComment.sync": "CourseComment" } }, _this.$events = {}, _this.components = {
      cSwiper: _swiper2.default,
      ctitle: _title2.default,
      cInfo: _info2.default,
      cRemake: _remake2.default,
      contact: _contact2.default
    }, _this.config = {
      navigationBarTitleText: "活动详情"
    }, _this.methods = {
      paymentType: function paymentType(type) {
        this.paymentType = type;
      },
      call: function call(phoneNumber) {
        wx.makePhoneCall({
          phoneNumber: phoneNumber //仅为示例，并非真实的电话号码
        });
      },
      cont: function cont() {
        this.modalName = 'bottomModal';
      },
      tocut: function () {
        var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(type) {
          return regeneratorRuntime.wrap(function _callee$(_context) {
            while (1) {
              switch (_context.prev = _context.next) {
                case 0:
                  if (_wepy2.default.getStorageSync('mobile') == '' || !_wepy2.default.getStorageSync('mobile') || _wepy2.default.getStorageSync('isFans') != 1) {
                    _wepy2.default.navigateTo({
                      url: "/pages/home/auth"
                    });
                  } else {
                    this.sku(type);
                    this.$apply();
                  }

                case 1:
                case "end":
                  return _context.stop();
              }
            }
          }, _callee, this);
        }));

        function tocut(_x) {
          return _ref2.apply(this, arguments);
        }

        return tocut;
      }(),
      createImg: function () {
        var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(e) {
          return regeneratorRuntime.wrap(function _callee2$(_context2) {
            while (1) {
              switch (_context2.prev = _context2.next) {
                case 0:
                  if (!(e.detail.errMsg == "getUserInfo:ok")) {
                    _context2.next = 5;
                    break;
                  }

                  _context2.next = 3;
                  return _auth2.default.getUserinfo(e.detail);

                case 3:
                  _utils2.default.save('shareInfo', {
                    course: this.courseInfo,
                    path: 'pages/detaile/detaile',
                    id: this.courseInfo.id,
                    type: 1
                  });
                  _wepy2.default.navigateTo({
                    url: '/pages/home/share'
                  });

                case 5:
                case "end":
                  return _context2.stop();
              }
            }
          }, _callee2, this);
        }));

        function createImg(_x2) {
          return _ref3.apply(this, arguments);
        }

        return createImg;
      }(),
      toshare: function toshare() {
        this.modalName = 'share';
      },
      toPintuanfy: function toPintuanfy() {
        if (_wepy2.default.getStorageSync('mobile') == '' || !_wepy2.default.getStorageSync('mobile') || _wepy2.default.getStorageSync('isFans') != 1) {
          _wepy2.default.navigateTo({
            url: "/pages/home/auth"
          });
        } else {
          this.toPintuan = true;
        }
      },
      bargain: function () {
        var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
          var _ref5, errcode, errmsg, data;

          return regeneratorRuntime.wrap(function _callee3$(_context3) {
            while (1) {
              switch (_context3.prev = _context3.next) {
                case 0:
                  if (!(this.courseInx == -1)) {
                    _context3.next = 3;
                    break;
                  }

                  _Tips2.default.toast("请选择一个营期", function (res) {}, 'none');
                  return _context3.abrupt("return", false);

                case 3:
                  _context3.next = 5;
                  return _config2.default.regBargain({
                    bargainId: this.courseInfo.bargainId,
                    courseId: this.courseInfo.id,
                    periodId: this.courseInfo.periodList[this.courseInx].id
                  });

                case 5:
                  _ref5 = _context3.sent;
                  errcode = _ref5.errcode;
                  errmsg = _ref5.errmsg;
                  data = _ref5.data;

                  if (errcode == 200) {
                    _wepy2.default.redirectTo({
                      url: '/pages/activity/bargain?id=' + data.regId
                    });
                  } else {
                    // 发起砍价异常
                    _Tips2.default.toast(errmsg, function (res) {
                      _wepy2.default.redirectTo({
                        url: '/pages/activity/bargain?id=' + data.actBargainReg.id
                      });
                    }, 'none');
                  }

                case 10:
                case "end":
                  return _context3.stop();
              }
            }
          }, _callee3, this);
        }));

        function bargain() {
          return _ref4.apply(this, arguments);
        }

        return bargain;
      }(),
      ret: function ret() {
        return false;
      },
      tabSelect: function tabSelect(e) {
        console.log(e);
        this.TabCur = e.currentTarget.dataset.id || e.detail.current;
      },
      hideModal: function hideModal() {
        this.toPintuan = false;
        this.showSku = false;
        this.modalName = '';
      },
      sku: function sku(type) {
        this.sku(type);
      },
      plus: function plus() {
        if (this.buyTypt == 'bargain' || this.buyTypt == 'crowdfund') {
          return false;
        }
        wx.vibrateShort();
        this.num = this.num + 1;
      },
      minus: function minus() {
        if (this.num > 1) {
          wx.vibrateShort();
          this.num = this.num - 1;
        }
      },
      course: function course(inx) {
        this.courseInx = inx;
      },
      buy: function () {
        var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
          var aid = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;
          var ot = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1;
          return regeneratorRuntime.wrap(function _callee4$(_context4) {
            while (1) {
              switch (_context4.prev = _context4.next) {
                case 0:
                  if (!(this.courseInx == -1)) {
                    _context4.next = 3;
                    break;
                  }

                  _Tips2.default.toast("请选择一个营期", function (res) {}, 'none');
                  return _context4.abrupt("return", false);

                case 3:
                  if (!(ot == 4)) {
                    _context4.next = 6;
                    break;
                  }

                  // 砍价
                  _wepy2.default.navigateTo({
                    url: "/crowdfund/pages/sureOrder?type=" + ot + "&pid=" + this.courseInfo.periodList[this.courseInx].id + "&cid=" + this.courseInfo.id + "&num=" + this.num + "&aid=" + aid + "&actpid=" + this.courseInfo.pintuanId + "&pt=" + this.paymentType
                  });
                  return _context4.abrupt("return", false);

                case 6:
                  // if(ot == 2){
                  //     // 砍价
                  //     aid = this.courseInfo.bargainId
                  // }
                  // if(ot == 3){
                  //     // 拼团
                  //     aid = this.courseInfo.pintuanId
                  // }
                  _wepy2.default.navigateTo({
                    url: "./sureOrder?type=" + ot + "&pid=" + this.courseInfo.periodList[this.courseInx].id + "&cid=" + this.courseInfo.id + "&num=" + this.num + "&aid=" + aid + "&actpid=" + this.courseInfo.pintuanId + "&pt=" + this.paymentType
                  });

                case 7:
                case "end":
                  return _context4.stop();
              }
            }
          }, _callee4, this);
        }));

        function buy() {
          return _ref6.apply(this, arguments);
        }

        return buy;
      }()
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(Dialog, [{
    key: "onShareAppMessage",

    // 转发暂时先不开启
    value: function onShareAppMessage(res) {
      if (res.from === 'button') {
        // 来自页面内转发按钮
        console.log(res.target);
      }
      return {
        title: this.courseInfo.courseTittle,
        path: '/pages/detaile/detaile?id=' + this.courseInfo.id + '&agentId=' + this.member.agentId
      };
    }
  }, {
    key: "onLoad",
    value: function () {
      var _ref7 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5(opt) {
        var _this2 = this;

        var view, _ref8, course, companions, statistics, CourseComment, actPintuan, customerService;

        return regeneratorRuntime.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                console.log(opt);
                // 获取主内容高度，用于悬浮详情导航
                view = wx.createSelectorQuery().select("#info-box");

                view.fields({
                  size: true
                }, function (data) {
                  console.log(data.height);
                  _this2.mainHeight = data.height;
                }).exec();
                _context5.next = 5;
                return _auth2.default.login();

              case 5:
                this.member = _wepy2.default.getStorageSync('member');
                _context5.next = 8;
                return _config2.default.getCourseInfo(opt.id || _wepy2.default.$instance.globalData.query.id);

              case 8:
                _ref8 = _context5.sent;
                course = _ref8.course;
                companions = _ref8.companions;
                statistics = _ref8.statistics;
                CourseComment = _ref8.CourseComment;
                actPintuan = _ref8.actPintuan;
                customerService = _ref8.customerService;

                this.swipers.list = course.pics;
                course.courseChar = course.courseChar.split("|");
                this.courseInfo = course;
                this.customerService = customerService;
                _wepy2.default.$instance.globalData.courseInfo = course;
                this.companions = companions;
                this.statistics = statistics;
                this.CourseComment = CourseComment;
                this.ActPintuan = actPintuan;
                this.$apply();

              case 25:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5, this);
      }));

      function onLoad(_x5) {
        return _ref7.apply(this, arguments);
      }

      return onLoad;
    }()
  }, {
    key: "sku",
    value: function sku() {
      var type = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'normal';

      this.showSku = true;
      this.toPintuan = false;
      this.buyTypt = type;
    }
  }]);

  return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/detaile/detaile'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldGFpbGUuanMiXSwibmFtZXMiOlsiRGlhbG9nIiwiZGF0YSIsIlRhYkN1ciIsImNsb3NlIiwic3dpcGVycyIsInR5cGUiLCJsaXN0IiwiaWQiLCJ1cmwiLCJsaW5rIiwibGlua1R5cGUiLCJtYWluSGVpZ2h0IiwiY291cnNlSW5mbyIsIm5vZGVzIiwibnVtIiwic2hvd1NrdSIsImJ1eVR5cHQiLCJjb3Vyc2VJbngiLCJjb21wYW5pb25zIiwic3RhdGlzdGljcyIsIkNvdXJzZUNvbW1lbnQiLCJBY3RQaW50dWFuIiwic2lnbl9zdGF0ZXMiLCJ0b1BpbnR1YW4iLCJtb2RhbE5hbWUiLCJjdXN0b21lclNlcnZpY2UiLCJtZW1iZXIiLCJwYXltZW50VHlwZSIsIiRyZXBlYXQiLCIkcHJvcHMiLCIkZXZlbnRzIiwiY29tcG9uZW50cyIsImNTd2lwZXIiLCJjdGl0bGUiLCJjSW5mbyIsImNSZW1ha2UiLCJjb250YWN0IiwiY29uZmlnIiwibmF2aWdhdGlvbkJhclRpdGxlVGV4dCIsIm1ldGhvZHMiLCJjYWxsIiwicGhvbmVOdW1iZXIiLCJ3eCIsIm1ha2VQaG9uZUNhbGwiLCJjb250IiwidG9jdXQiLCJ3ZXB5IiwiZ2V0U3RvcmFnZVN5bmMiLCJuYXZpZ2F0ZVRvIiwic2t1IiwiJGFwcGx5IiwiY3JlYXRlSW1nIiwiZSIsImRldGFpbCIsImVyck1zZyIsImF1dGgiLCJnZXRVc2VyaW5mbyIsInN0b3JlIiwic2F2ZSIsImNvdXJzZSIsInBhdGgiLCJ0b3NoYXJlIiwidG9QaW50dWFuZnkiLCJiYXJnYWluIiwiVGlwcyIsInRvYXN0IiwicmVnQmFyZ2FpbiIsImJhcmdhaW5JZCIsImNvdXJzZUlkIiwicGVyaW9kSWQiLCJwZXJpb2RMaXN0IiwiZXJyY29kZSIsImVycm1zZyIsInJlZGlyZWN0VG8iLCJyZWdJZCIsImFjdEJhcmdhaW5SZWciLCJyZXQiLCJ0YWJTZWxlY3QiLCJjb25zb2xlIiwibG9nIiwiY3VycmVudFRhcmdldCIsImRhdGFzZXQiLCJjdXJyZW50IiwiaGlkZU1vZGFsIiwicGx1cyIsInZpYnJhdGVTaG9ydCIsIm1pbnVzIiwiaW54IiwiYnV5IiwiYWlkIiwib3QiLCJwaW50dWFuSWQiLCJyZXMiLCJmcm9tIiwidGFyZ2V0IiwidGl0bGUiLCJjb3Vyc2VUaXR0bGUiLCJhZ2VudElkIiwib3B0IiwidmlldyIsImNyZWF0ZVNlbGVjdG9yUXVlcnkiLCJzZWxlY3QiLCJmaWVsZHMiLCJzaXplIiwiaGVpZ2h0IiwiZXhlYyIsImxvZ2luIiwiZ2V0Q291cnNlSW5mbyIsIiRpbnN0YW5jZSIsImdsb2JhbERhdGEiLCJxdWVyeSIsImFjdFBpbnR1YW4iLCJwaWNzIiwiY291cnNlQ2hhciIsInNwbGl0IiwicGFnZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQ0U7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7Ozs7Ozs7Ozs7Ozs7SUFDcUJBLE07Ozs7Ozs7Ozs7Ozs7O3NMQUNuQkMsSSxHQUFPO0FBQ0xDLGNBQVEsQ0FESDtBQUVMQyxhQUFPLDBCQUZGO0FBR0xDLGVBQVM7QUFDUEMsY0FBTSxDQURDO0FBRVBDLGNBQU0sQ0FBQztBQUNMQyxjQUFJLENBREM7QUFFTEYsZ0JBQU0sT0FGRDtBQUdMRyxlQUFLLEVBSEE7QUFJTEMsZ0JBQU0sa0JBSkQ7QUFLTEMsb0JBQVU7QUFMTCxTQUFEO0FBRkMsT0FISjtBQWFMQyxrQkFBWSxDQWJQO0FBY0xDLGtCQUFZLEVBZFA7QUFlTEMsYUFBTyxDQUFDLE1BQUQsRUFBUyxPQUFULEVBQWtCLE9BQWxCLENBZkY7QUFnQkxDLFdBQUssQ0FoQkE7QUFpQkxDLGVBQVMsS0FqQko7QUFrQkxDLGVBQVMsUUFsQko7QUFtQkxDLGlCQUFXLENBQUMsQ0FuQlA7QUFvQkxDLGtCQUFZLEVBcEJQO0FBcUJMQyxrQkFBWSxFQXJCUDtBQXNCTEMscUJBQWUsRUF0QlY7QUF1QkxDLGtCQUFZLEVBdkJQO0FBd0JMQyxtQkFBYTtBQUNYLFdBQUcsT0FEUTtBQUVYLFdBQUcsTUFGUTtBQUdYLFdBQUc7QUFIUSxPQXhCUjtBQTZCTEMsaUJBQVcsS0E3Qk47QUE4QkxDLGlCQUFXLEVBOUJOO0FBK0JMQyx1QkFBaUIsRUEvQlo7QUFnQ0xDLGNBQVEsRUFoQ0g7QUFpQ0xDLG1CQUFhO0FBakNSLEssUUFtQ1JDLE8sR0FBVSxFLFFBQ2JDLE0sR0FBUyxFQUFDLFdBQVUsRUFBQyxnQkFBZSxFQUFoQixFQUFtQixxQkFBb0IsU0FBdkMsRUFBWCxFQUE2RCxVQUFTLEVBQUMscUJBQW9CLFlBQXJCLEVBQXRFLEVBQXlHLFNBQVEsRUFBQyxxQkFBb0IsWUFBckIsRUFBa0MsMEJBQXlCLFlBQTNELEVBQWpILEVBQTBMLFdBQVUsRUFBQyxxQkFBb0IsWUFBckIsRUFBa0MsMEJBQXlCLFlBQTNELEVBQXdFLDZCQUE0QixlQUFwRyxFQUFwTSxFLFFBQ1RDLE8sR0FBVSxFLFFBQ1RDLFUsR0FBYTtBQUNSQywrQkFEUTtBQUVSQyw2QkFGUTtBQUdSQywyQkFIUTtBQUlSQywrQkFKUTtBQUtSQztBQUxRLEssUUFPVkMsTSxHQUFTO0FBQ1BDLDhCQUF3QjtBQURqQixLLFFBc0RUQyxPLEdBQVU7QUFDUlosaUJBRFEsdUJBQ0l0QixJQURKLEVBQ1U7QUFDaEIsYUFBS3NCLFdBQUwsR0FBbUJ0QixJQUFuQjtBQUNELE9BSE87QUFJUm1DLFVBSlEsZ0JBSUhDLFdBSkcsRUFJVTtBQUNoQkMsV0FBR0MsYUFBSCxDQUFpQjtBQUNmRixrQ0FEZSxDQUNIO0FBREcsU0FBakI7QUFHRCxPQVJPO0FBU1JHLFVBVFEsa0JBU0Q7QUFDTCxhQUFLcEIsU0FBTCxHQUFpQixhQUFqQjtBQUNELE9BWE87QUFZRnFCLFdBWkU7QUFBQSw2RkFZSXhDLElBWko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQWFOLHNCQUFJeUMsZUFBS0MsY0FBTCxDQUFvQixRQUFwQixLQUFpQyxFQUFqQyxJQUF1QyxDQUFDRCxlQUFLQyxjQUFMLENBQW9CLFFBQXBCLENBQXhDLElBQXlFRCxlQUFLQyxjQUFMLENBQzNFLFFBRDJFLEtBQzlELENBRGYsRUFDa0I7QUFDaEJELG1DQUFLRSxVQUFMLENBQWdCO0FBQ2R4QztBQURjLHFCQUFoQjtBQUdELG1CQUxELE1BS087QUFDTCx5QkFBS3lDLEdBQUwsQ0FBUzVDLElBQVQ7QUFDQSx5QkFBSzZDLE1BQUw7QUFDRDs7QUFyQks7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUF1QkZDLGVBdkJFO0FBQUEsOEZBdUJRQyxDQXZCUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBd0JGQSxFQUFFQyxNQUFGLENBQVNDLE1BQVQsSUFBbUIsZ0JBeEJqQjtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBLHlCQXlCRUMsZUFBS0MsV0FBTCxDQUFpQkosRUFBRUMsTUFBbkIsQ0F6QkY7O0FBQUE7QUEwQkpJLGtDQUFNQyxJQUFOLENBQVcsV0FBWCxFQUF3QjtBQUN0QkMsNEJBQVEsS0FBSy9DLFVBRFM7QUFFdEJnRCwwQkFBTSx1QkFGZ0I7QUFHdEJyRCx3QkFBSSxLQUFLSyxVQUFMLENBQWdCTCxFQUhFO0FBSXRCRiwwQkFBTTtBQUpnQixtQkFBeEI7QUFNQXlDLGlDQUFLRSxVQUFMLENBQWdCO0FBQ2R4Qyx5QkFBSztBQURTLG1CQUFoQjs7QUFoQ0k7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFxQ1JxRCxhQXJDUSxxQkFxQ0U7QUFDUixhQUFLckMsU0FBTCxHQUFpQixPQUFqQjtBQUNELE9BdkNPO0FBd0NSc0MsaUJBeENRLHlCQXdDTTtBQUNaLFlBQUloQixlQUFLQyxjQUFMLENBQW9CLFFBQXBCLEtBQWlDLEVBQWpDLElBQXVDLENBQUNELGVBQUtDLGNBQUwsQ0FBb0IsUUFBcEIsQ0FBeEMsSUFBeUVELGVBQUtDLGNBQUwsQ0FDM0UsUUFEMkUsS0FDOUQsQ0FEZixFQUNrQjtBQUNoQkQseUJBQUtFLFVBQUwsQ0FBZ0I7QUFDZHhDO0FBRGMsV0FBaEI7QUFHRCxTQUxELE1BS087QUFDTCxlQUFLZSxTQUFMLEdBQWlCLElBQWpCO0FBQ0Q7QUFDRixPQWpETztBQWtERndDLGFBbERFO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQW1ERixLQUFLOUMsU0FBTCxJQUFrQixDQUFDLENBbkRqQjtBQUFBO0FBQUE7QUFBQTs7QUFvREorQyxpQ0FBS0MsS0FBTCxDQUFXLFNBQVgsRUFBc0IsZUFBTyxDQUFFLENBQS9CLEVBQWlDLE1BQWpDO0FBcERJLG9EQXFERyxLQXJESDs7QUFBQTtBQUFBO0FBQUEseUJBMkRJNUIsaUJBQU82QixVQUFQLENBQWtCO0FBQzFCQywrQkFBVyxLQUFLdkQsVUFBTCxDQUFnQnVELFNBREQ7QUFFMUJDLDhCQUFVLEtBQUt4RCxVQUFMLENBQWdCTCxFQUZBO0FBRzFCOEQsOEJBQVUsS0FBS3pELFVBQUwsQ0FBZ0IwRCxVQUFoQixDQUEyQixLQUFLckQsU0FBaEMsRUFBMkNWO0FBSDNCLG1CQUFsQixDQTNESjs7QUFBQTtBQUFBO0FBd0RKZ0UseUJBeERJLFNBd0RKQSxPQXhESTtBQXlESkMsd0JBekRJLFNBeURKQSxNQXpESTtBQTBESnZFLHNCQTFESSxTQTBESkEsSUExREk7O0FBZ0VOLHNCQUFJc0UsV0FBVyxHQUFmLEVBQW9CO0FBQ2xCekIsbUNBQUsyQixVQUFMLENBQWdCO0FBQ2RqRSwyQkFBSyxnQ0FBZ0NQLEtBQUt5RTtBQUQ1QixxQkFBaEI7QUFHRCxtQkFKRCxNQUlPO0FBQ0w7QUFDQVYsbUNBQUtDLEtBQUwsQ0FBV08sTUFBWCxFQUFtQixlQUFPO0FBQ3hCMUIscUNBQUsyQixVQUFMLENBQWdCO0FBQ2RqRSw2QkFBSyxnQ0FBZ0NQLEtBQUswRSxhQUFMLENBQW1CcEU7QUFEMUMsdUJBQWhCO0FBR0QscUJBSkQsRUFJRyxNQUpIO0FBS0Q7O0FBM0VLO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBNkVScUUsU0E3RVEsaUJBNkVGO0FBQ0osZUFBTyxLQUFQO0FBQ0QsT0EvRU87QUFnRlJDLGVBaEZRLHFCQWdGRXpCLENBaEZGLEVBZ0ZLO0FBQ1gwQixnQkFBUUMsR0FBUixDQUFZM0IsQ0FBWjtBQUNBLGFBQUtsRCxNQUFMLEdBQWNrRCxFQUFFNEIsYUFBRixDQUFnQkMsT0FBaEIsQ0FBd0IxRSxFQUF4QixJQUE4QjZDLEVBQUVDLE1BQUYsQ0FBUzZCLE9BQXJEO0FBQ0QsT0FuRk87QUFvRlJDLGVBcEZRLHVCQW9GSTtBQUNWLGFBQUs1RCxTQUFMLEdBQWlCLEtBQWpCO0FBQ0EsYUFBS1IsT0FBTCxHQUFlLEtBQWY7QUFDQSxhQUFLUyxTQUFMLEdBQWlCLEVBQWpCO0FBQ0QsT0F4Rk87QUF5RlJ5QixTQXpGUSxlQXlGSjVDLElBekZJLEVBeUZFO0FBQ1IsYUFBSzRDLEdBQUwsQ0FBUzVDLElBQVQ7QUFDRCxPQTNGTztBQTRGUitFLFVBNUZRLGtCQTRGRDtBQUNMLFlBQUksS0FBS3BFLE9BQUwsSUFBZ0IsU0FBaEIsSUFBNkIsS0FBS0EsT0FBTCxJQUFnQixXQUFqRCxFQUE4RDtBQUM1RCxpQkFBTyxLQUFQO0FBQ0Q7QUFDRDBCLFdBQUcyQyxZQUFIO0FBQ0EsYUFBS3ZFLEdBQUwsR0FBVyxLQUFLQSxHQUFMLEdBQVcsQ0FBdEI7QUFDRCxPQWxHTztBQW1HUndFLFdBbkdRLG1CQW1HQTtBQUNOLFlBQUksS0FBS3hFLEdBQUwsR0FBVyxDQUFmLEVBQWtCO0FBQ2hCNEIsYUFBRzJDLFlBQUg7QUFDQSxlQUFLdkUsR0FBTCxHQUFXLEtBQUtBLEdBQUwsR0FBVyxDQUF0QjtBQUNEO0FBQ0YsT0F4R087QUF5R1I2QyxZQXpHUSxrQkF5R0Q0QixHQXpHQyxFQXlHSTtBQUNWLGFBQUt0RSxTQUFMLEdBQWlCc0UsR0FBakI7QUFDRCxPQTNHTztBQTRHRkMsU0E1R0U7QUFBQTtBQUFBLGNBNEdFQyxHQTVHRix1RUE0R1EsQ0E1R1I7QUFBQSxjQTRHV0MsRUE1R1gsdUVBNEdnQixDQTVHaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQTZHRixLQUFLekUsU0FBTCxJQUFrQixDQUFDLENBN0dqQjtBQUFBO0FBQUE7QUFBQTs7QUE4R0orQyxpQ0FBS0MsS0FBTCxDQUFXLFNBQVgsRUFBc0IsZUFBTyxDQUFFLENBQS9CLEVBQWlDLE1BQWpDO0FBOUdJLG9EQStHRyxLQS9HSDs7QUFBQTtBQUFBLHdCQWlIRnlCLE1BQU0sQ0FqSEo7QUFBQTtBQUFBO0FBQUE7O0FBa0hKO0FBQ0E1QyxpQ0FBS0UsVUFBTCxDQUFnQjtBQUNkeEMsOERBQXdDa0YsRUFBeEMsYUFBa0QsS0FBSzlFLFVBQUwsQ0FBZ0IwRCxVQUFoQixDQUEyQixLQUFLckQsU0FBaEMsRUFBMkNWLEVBQTdGLGFBQXVHLEtBQUtLLFVBQUwsQ0FBZ0JMLEVBQXZILGFBQWlJLEtBQUtPLEdBQXRJLGFBQWlKMkUsR0FBakosZ0JBQStKLEtBQUs3RSxVQUFMLENBQWdCK0UsU0FBL0ssWUFBK0wsS0FBS2hFO0FBRHRMLG1CQUFoQjtBQW5ISSxvREFzSEcsS0F0SEg7O0FBQUE7QUF3SE47QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBbUIsaUNBQUtFLFVBQUwsQ0FBZ0I7QUFDZHhDLCtDQUF5QmtGLEVBQXpCLGFBQW1DLEtBQUs5RSxVQUFMLENBQWdCMEQsVUFBaEIsQ0FBMkIsS0FBS3JELFNBQWhDLEVBQTJDVixFQUE5RSxhQUF3RixLQUFLSyxVQUFMLENBQWdCTCxFQUF4RyxhQUFrSCxLQUFLTyxHQUF2SCxhQUFrSTJFLEdBQWxJLGdCQUFnSixLQUFLN0UsVUFBTCxDQUFnQitFLFNBQWhLLFlBQWdMLEtBQUtoRTtBQUR2SyxtQkFBaEI7O0FBaElNO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUEsSzs7Ozs7O0FBbkRWO3NDQUNrQmlFLEcsRUFBSztBQUNyQixVQUFJQSxJQUFJQyxJQUFKLEtBQWEsUUFBakIsRUFBMkI7QUFDekI7QUFDQWYsZ0JBQVFDLEdBQVIsQ0FBWWEsSUFBSUUsTUFBaEI7QUFDRDtBQUNELGFBQU87QUFDTEMsZUFBTyxLQUFLbkYsVUFBTCxDQUFnQm9GLFlBRGxCO0FBRUxwQyxjQUFNLCtCQUErQixLQUFLaEQsVUFBTCxDQUFnQkwsRUFBL0MsR0FBb0QsV0FBcEQsR0FBa0UsS0FBS21CLE1BQUwsQ0FBWXVFO0FBRi9FLE9BQVA7QUFJRDs7Ozs0RkFDWUMsRzs7Ozs7Ozs7O0FBQ1hwQix3QkFBUUMsR0FBUixDQUFZbUIsR0FBWjtBQUNBO0FBQ0lDLG9CLEdBQU96RCxHQUFHMEQsbUJBQUgsR0FBeUJDLE1BQXpCLENBQWdDLFdBQWhDLEM7O0FBQ1hGLHFCQUNHRyxNQURILENBQ1U7QUFDSkMsd0JBQU07QUFERixpQkFEVixFQUlJLGdCQUFRO0FBQ056QiwwQkFBUUMsR0FBUixDQUFZOUUsS0FBS3VHLE1BQWpCO0FBQ0EseUJBQUs3RixVQUFMLEdBQWtCVixLQUFLdUcsTUFBdkI7QUFDRCxpQkFQTCxFQVNHQyxJQVRIOzt1QkFVTWxELGVBQUttRCxLQUFMLEU7OztBQUNOLHFCQUFLaEYsTUFBTCxHQUFjb0IsZUFBS0MsY0FBTCxDQUFvQixRQUFwQixDQUFkOzt1QkFRVVYsaUJBQU9zRSxhQUFQLENBQXFCVCxJQUFJM0YsRUFBSixJQUFVdUMsZUFBSzhELFNBQUwsQ0FBZUMsVUFBZixDQUEwQkMsS0FBMUIsQ0FBZ0N2RyxFQUEvRCxDOzs7O0FBTlJvRCxzQixTQUFBQSxNO0FBQ0F6QywwQixTQUFBQSxVO0FBQ0FDLDBCLFNBQUFBLFU7QUFDQUMsNkIsU0FBQUEsYTtBQUNBMkYsMEIsU0FBQUEsVTtBQUNBdEYsK0IsU0FBQUEsZTs7QUFFRixxQkFBS3JCLE9BQUwsQ0FBYUUsSUFBYixHQUFvQnFELE9BQU9xRCxJQUEzQjtBQUNBckQsdUJBQU9zRCxVQUFQLEdBQW9CdEQsT0FBT3NELFVBQVAsQ0FBa0JDLEtBQWxCLENBQXdCLEdBQXhCLENBQXBCO0FBQ0EscUJBQUt0RyxVQUFMLEdBQWtCK0MsTUFBbEI7QUFDQSxxQkFBS2xDLGVBQUwsR0FBdUJBLGVBQXZCO0FBQ0FxQiwrQkFBSzhELFNBQUwsQ0FBZUMsVUFBZixDQUEwQmpHLFVBQTFCLEdBQXVDK0MsTUFBdkM7QUFDQSxxQkFBS3pDLFVBQUwsR0FBa0JBLFVBQWxCO0FBQ0EscUJBQUtDLFVBQUwsR0FBa0JBLFVBQWxCO0FBQ0EscUJBQUtDLGFBQUwsR0FBcUJBLGFBQXJCO0FBQ0EscUJBQUtDLFVBQUwsR0FBa0IwRixVQUFsQjtBQUNBLHFCQUFLN0QsTUFBTDs7Ozs7Ozs7Ozs7Ozs7Ozs7OzBCQUVtQjtBQUFBLFVBQWpCN0MsSUFBaUIsdUVBQVYsUUFBVTs7QUFDbkIsV0FBS1UsT0FBTCxHQUFlLElBQWY7QUFDQSxXQUFLUSxTQUFMLEdBQWlCLEtBQWpCO0FBQ0EsV0FBS1AsT0FBTCxHQUFlWCxJQUFmO0FBQ0Q7Ozs7RUFuR2lDeUMsZUFBS3FFLEk7O2tCQUFwQm5ILE0iLCJmaWxlIjoiZGV0YWlsZS5qcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4gIGltcG9ydCB3ZXB5IGZyb20gXCJ3ZXB5XCI7XHJcbiAgaW1wb3J0IGNTd2lwZXIgZnJvbSBcIkAvY29tcG9uZW50cy9jb21tb24vc3dpcGVyXCI7XHJcbiAgaW1wb3J0IGN0aXRsZSBmcm9tIFwiQC9jb21wb25lbnRzL2RldGFpbGUvdGl0bGVcIjtcclxuICBpbXBvcnQgY0luZm8gZnJvbSBcIkAvY29tcG9uZW50cy9kZXRhaWxlL2luZm9cIjtcclxuICBpbXBvcnQgY1JlbWFrZSBmcm9tIFwiQC9jb21wb25lbnRzL2RldGFpbGUvcmVtYWtlXCI7XHJcbiAgaW1wb3J0IGNvbnRhY3QgZnJvbSBcIkAvY29tcG9uZW50cy9jb21tb24vY29udGFjdFwiXHJcbiAgaW1wb3J0IHN0b3JlIGZyb20gXCJAL3N0b3JlL3V0aWxzXCJcclxuICBpbXBvcnQgY29uZmlnIGZyb20gXCJAL2FwaS9jb25maWdcIjtcclxuICBpbXBvcnQgYXV0aCBmcm9tIFwiQC9hcGkvYXV0aFwiO1xyXG4gIGltcG9ydCBXeFV0aWxzIGZyb20gXCJAL3V0aWxzL1d4VXRpbHNcIjtcclxuICBpbXBvcnQgVGlwcyBmcm9tIFwiQC91dGlscy9UaXBzXCI7XHJcbiAgZXhwb3J0IGRlZmF1bHQgY2xhc3MgRGlhbG9nIGV4dGVuZHMgd2VweS5wYWdlIHtcclxuICAgIGRhdGEgPSB7XHJcbiAgICAgIFRhYkN1cjogMCxcclxuICAgICAgY2xvc2U6IFwiL3N0YXRpYy9pbWFnZXMvY2xvc2UucG5nXCIsXHJcbiAgICAgIHN3aXBlcnM6IHtcclxuICAgICAgICB0eXBlOiAxLFxyXG4gICAgICAgIGxpc3Q6IFt7XHJcbiAgICAgICAgICBpZDogMCxcclxuICAgICAgICAgIHR5cGU6IFwiaW1hZ2VcIixcclxuICAgICAgICAgIHVybDogXCJcIixcclxuICAgICAgICAgIGxpbms6IFwiL3BhZ2VzL21lZXQvbWVldFwiLFxyXG4gICAgICAgICAgbGlua1R5cGU6IFwic3dpdGNoVGFiXCJcclxuICAgICAgICB9XVxyXG4gICAgICB9LFxyXG4gICAgICBtYWluSGVpZ2h0OiAwLFxyXG4gICAgICBjb3Vyc2VJbmZvOiB7fSxcclxuICAgICAgbm9kZXM6IFtcIm5hbWVcIiwgXCJhdHRyc1wiLCBcImF0dHJzXCJdLFxyXG4gICAgICBudW06IDEsXHJcbiAgICAgIHNob3dTa3U6IGZhbHNlLFxyXG4gICAgICBidXlUeXB0OiAnbm9ybWFsJyxcclxuICAgICAgY291cnNlSW54OiAtMSxcclxuICAgICAgY29tcGFuaW9uczogW10sXHJcbiAgICAgIHN0YXRpc3RpY3M6IHt9LFxyXG4gICAgICBDb3Vyc2VDb21tZW50OiB7fSxcclxuICAgICAgQWN0UGludHVhbjoge30sXHJcbiAgICAgIHNpZ25fc3RhdGVzOiB7XHJcbiAgICAgICAgMDogJ+eBq+eDreaLm+eUn+S4rScsXHJcbiAgICAgICAgMTogJ+WwkemHj+WQjeminScsXHJcbiAgICAgICAgMjogJ+W3sua7oeWRmCdcclxuICAgICAgfSxcclxuICAgICAgdG9QaW50dWFuOiBmYWxzZSxcclxuICAgICAgbW9kYWxOYW1lOiAnJyxcclxuICAgICAgY3VzdG9tZXJTZXJ2aWNlOiB7fSxcclxuICAgICAgbWVtYmVyOiB7fSxcclxuICAgICAgcGF5bWVudFR5cGU6IDFcclxuICAgIH07XHJcbiAgICRyZXBlYXQgPSB7fTtcclxuJHByb3BzID0ge1wiY1N3aXBlclwiOntcInhtbG5zOnYtYmluZFwiOlwiXCIsXCJ2LWJpbmQ6bW9kZWwuc3luY1wiOlwic3dpcGVyc1wifSxcImN0aXRsZVwiOntcInYtYmluZDptb2RlbC5zeW5jXCI6XCJjb3Vyc2VJbmZvXCJ9LFwiY0luZm9cIjp7XCJ2LWJpbmQ6bW9kZWwuc3luY1wiOlwiY291cnNlSW5mb1wiLFwidi1iaW5kOmNvbXBhbmlvbnMuc3luY1wiOlwiY29tcGFuaW9uc1wifSxcImNSZW1ha2VcIjp7XCJ2LWJpbmQ6bW9kZWwuc3luY1wiOlwiY291cnNlSW5mb1wiLFwidi1iaW5kOnN0YXRpc3RpY3Muc3luY1wiOlwic3RhdGlzdGljc1wiLFwidi1iaW5kOkNvdXJzZUNvbW1lbnQuc3luY1wiOlwiQ291cnNlQ29tbWVudFwifX07XHJcbiRldmVudHMgPSB7fTtcclxuIGNvbXBvbmVudHMgPSB7XHJcbiAgICAgIGNTd2lwZXIsXHJcbiAgICAgIGN0aXRsZSxcclxuICAgICAgY0luZm8sXHJcbiAgICAgIGNSZW1ha2UsXHJcbiAgICAgIGNvbnRhY3RcclxuICAgIH07XHJcbiAgICBjb25maWcgPSB7XHJcbiAgICAgIG5hdmlnYXRpb25CYXJUaXRsZVRleHQ6IFwi5rS75Yqo6K+m5oOFXCJcclxuICAgIH07XHJcbiAgICAvLyDovazlj5HmmoLml7blhYjkuI3lvIDlkK9cclxuICAgIG9uU2hhcmVBcHBNZXNzYWdlKHJlcykge1xyXG4gICAgICBpZiAocmVzLmZyb20gPT09ICdidXR0b24nKSB7XHJcbiAgICAgICAgLy8g5p2l6Ieq6aG16Z2i5YaF6L2s5Y+R5oyJ6ZKuXHJcbiAgICAgICAgY29uc29sZS5sb2cocmVzLnRhcmdldClcclxuICAgICAgfVxyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIHRpdGxlOiB0aGlzLmNvdXJzZUluZm8uY291cnNlVGl0dGxlLFxyXG4gICAgICAgIHBhdGg6ICcvcGFnZXMvZGV0YWlsZS9kZXRhaWxlP2lkPScgKyB0aGlzLmNvdXJzZUluZm8uaWQgKyAnJmFnZW50SWQ9JyArIHRoaXMubWVtYmVyLmFnZW50SWRcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgYXN5bmMgb25Mb2FkKG9wdCkge1xyXG4gICAgICBjb25zb2xlLmxvZyhvcHQpXHJcbiAgICAgIC8vIOiOt+WPluS4u+WGheWuuemrmOW6pu+8jOeUqOS6juaCrOa1ruivpuaDheWvvOiIqlxyXG4gICAgICBsZXQgdmlldyA9IHd4LmNyZWF0ZVNlbGVjdG9yUXVlcnkoKS5zZWxlY3QoXCIjaW5mby1ib3hcIik7XHJcbiAgICAgIHZpZXdcclxuICAgICAgICAuZmllbGRzKHtcclxuICAgICAgICAgICAgc2l6ZTogdHJ1ZVxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIGRhdGEgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhkYXRhLmhlaWdodCk7XHJcbiAgICAgICAgICAgIHRoaXMubWFpbkhlaWdodCA9IGRhdGEuaGVpZ2h0O1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIClcclxuICAgICAgICAuZXhlYygpO1xyXG4gICAgICBhd2FpdCBhdXRoLmxvZ2luKClcclxuICAgICAgdGhpcy5tZW1iZXIgPSB3ZXB5LmdldFN0b3JhZ2VTeW5jKCdtZW1iZXInKTtcclxuICAgICAgbGV0IHtcclxuICAgICAgICBjb3Vyc2UsXHJcbiAgICAgICAgY29tcGFuaW9ucyxcclxuICAgICAgICBzdGF0aXN0aWNzLFxyXG4gICAgICAgIENvdXJzZUNvbW1lbnQsXHJcbiAgICAgICAgYWN0UGludHVhbixcclxuICAgICAgICBjdXN0b21lclNlcnZpY2VcclxuICAgICAgfSA9IGF3YWl0IGNvbmZpZy5nZXRDb3Vyc2VJbmZvKG9wdC5pZCB8fCB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnF1ZXJ5LmlkKVxyXG4gICAgICB0aGlzLnN3aXBlcnMubGlzdCA9IGNvdXJzZS5waWNzXHJcbiAgICAgIGNvdXJzZS5jb3Vyc2VDaGFyID0gY291cnNlLmNvdXJzZUNoYXIuc3BsaXQoXCJ8XCIpXHJcbiAgICAgIHRoaXMuY291cnNlSW5mbyA9IGNvdXJzZVxyXG4gICAgICB0aGlzLmN1c3RvbWVyU2VydmljZSA9IGN1c3RvbWVyU2VydmljZVxyXG4gICAgICB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLmNvdXJzZUluZm8gPSBjb3Vyc2VcclxuICAgICAgdGhpcy5jb21wYW5pb25zID0gY29tcGFuaW9uc1xyXG4gICAgICB0aGlzLnN0YXRpc3RpY3MgPSBzdGF0aXN0aWNzXHJcbiAgICAgIHRoaXMuQ291cnNlQ29tbWVudCA9IENvdXJzZUNvbW1lbnRcclxuICAgICAgdGhpcy5BY3RQaW50dWFuID0gYWN0UGludHVhblxyXG4gICAgICB0aGlzLiRhcHBseSgpO1xyXG4gICAgfVxyXG4gICAgc2t1KHR5cGUgPSAnbm9ybWFsJykge1xyXG4gICAgICB0aGlzLnNob3dTa3UgPSB0cnVlXHJcbiAgICAgIHRoaXMudG9QaW50dWFuID0gZmFsc2VcclxuICAgICAgdGhpcy5idXlUeXB0ID0gdHlwZVxyXG4gICAgfVxyXG4gICAgbWV0aG9kcyA9IHtcclxuICAgICAgcGF5bWVudFR5cGUodHlwZSkge1xyXG4gICAgICAgIHRoaXMucGF5bWVudFR5cGUgPSB0eXBlXHJcbiAgICAgIH0sXHJcbiAgICAgIGNhbGwocGhvbmVOdW1iZXIpIHtcclxuICAgICAgICB3eC5tYWtlUGhvbmVDYWxsKHtcclxuICAgICAgICAgIHBob25lTnVtYmVyIC8v5LuF5Li656S65L6L77yM5bm26Z2e55yf5a6e55qE55S16K+d5Y+356CBXHJcbiAgICAgICAgfSlcclxuICAgICAgfSxcclxuICAgICAgY29udCgpIHtcclxuICAgICAgICB0aGlzLm1vZGFsTmFtZSA9ICdib3R0b21Nb2RhbCdcclxuICAgICAgfSxcclxuICAgICAgYXN5bmMgdG9jdXQodHlwZSkge1xyXG4gICAgICAgIGlmICh3ZXB5LmdldFN0b3JhZ2VTeW5jKCdtb2JpbGUnKSA9PSAnJyB8fCAhd2VweS5nZXRTdG9yYWdlU3luYygnbW9iaWxlJykgfHwgd2VweS5nZXRTdG9yYWdlU3luYyhcclxuICAgICAgICAgICdpc0ZhbnMnKSAhPSAxKSB7XHJcbiAgICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICB1cmw6IGAvcGFnZXMvaG9tZS9hdXRoYFxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHRoaXMuc2t1KHR5cGUpXHJcbiAgICAgICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG4gICAgICBhc3luYyBjcmVhdGVJbWcoZSkge1xyXG4gICAgICAgIGlmIChlLmRldGFpbC5lcnJNc2cgPT0gXCJnZXRVc2VySW5mbzpva1wiKSB7XHJcbiAgICAgICAgICBhd2FpdCBhdXRoLmdldFVzZXJpbmZvKGUuZGV0YWlsKVxyXG4gICAgICAgICAgc3RvcmUuc2F2ZSgnc2hhcmVJbmZvJywge1xyXG4gICAgICAgICAgICBjb3Vyc2U6IHRoaXMuY291cnNlSW5mbyxcclxuICAgICAgICAgICAgcGF0aDogJ3BhZ2VzL2RldGFpbGUvZGV0YWlsZScsXHJcbiAgICAgICAgICAgIGlkOiB0aGlzLmNvdXJzZUluZm8uaWQsXHJcbiAgICAgICAgICAgIHR5cGU6IDFcclxuICAgICAgICAgIH0pXHJcbiAgICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICB1cmw6ICcvcGFnZXMvaG9tZS9zaGFyZSdcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgfSxcclxuICAgICAgdG9zaGFyZSgpIHtcclxuICAgICAgICB0aGlzLm1vZGFsTmFtZSA9ICdzaGFyZSdcclxuICAgICAgfSxcclxuICAgICAgdG9QaW50dWFuZnkoKSB7XHJcbiAgICAgICAgaWYgKHdlcHkuZ2V0U3RvcmFnZVN5bmMoJ21vYmlsZScpID09ICcnIHx8ICF3ZXB5LmdldFN0b3JhZ2VTeW5jKCdtb2JpbGUnKSB8fCB3ZXB5LmdldFN0b3JhZ2VTeW5jKFxyXG4gICAgICAgICAgJ2lzRmFucycpICE9IDEpIHtcclxuICAgICAgICAgIHdlcHkubmF2aWdhdGVUbyh7XHJcbiAgICAgICAgICAgIHVybDogYC9wYWdlcy9ob21lL2F1dGhgXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgdGhpcy50b1BpbnR1YW4gPSB0cnVlXHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG4gICAgICBhc3luYyBiYXJnYWluKCkge1xyXG4gICAgICAgIGlmICh0aGlzLmNvdXJzZUlueCA9PSAtMSkge1xyXG4gICAgICAgICAgVGlwcy50b2FzdChcIuivt+mAieaLqeS4gOS4quiQpeacn1wiLCByZXMgPT4ge30sICdub25lJylcclxuICAgICAgICAgIHJldHVybiBmYWxzZVxyXG4gICAgICAgIH1cclxuICAgICAgICBsZXQge1xyXG4gICAgICAgICAgZXJyY29kZSxcclxuICAgICAgICAgIGVycm1zZyxcclxuICAgICAgICAgIGRhdGFcclxuICAgICAgICB9ID0gYXdhaXQgY29uZmlnLnJlZ0JhcmdhaW4oe1xyXG4gICAgICAgICAgYmFyZ2FpbklkOiB0aGlzLmNvdXJzZUluZm8uYmFyZ2FpbklkLFxyXG4gICAgICAgICAgY291cnNlSWQ6IHRoaXMuY291cnNlSW5mby5pZCxcclxuICAgICAgICAgIHBlcmlvZElkOiB0aGlzLmNvdXJzZUluZm8ucGVyaW9kTGlzdFt0aGlzLmNvdXJzZUlueF0uaWQsXHJcbiAgICAgICAgfSlcclxuICAgICAgICBpZiAoZXJyY29kZSA9PSAyMDApIHtcclxuICAgICAgICAgIHdlcHkucmVkaXJlY3RUbyh7XHJcbiAgICAgICAgICAgIHVybDogJy9wYWdlcy9hY3Rpdml0eS9iYXJnYWluP2lkPScgKyBkYXRhLnJlZ0lkXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgLy8g5Y+R6LW356CN5Lu35byC5bi4XHJcbiAgICAgICAgICBUaXBzLnRvYXN0KGVycm1zZywgcmVzID0+IHtcclxuICAgICAgICAgICAgd2VweS5yZWRpcmVjdFRvKHtcclxuICAgICAgICAgICAgICB1cmw6ICcvcGFnZXMvYWN0aXZpdHkvYmFyZ2Fpbj9pZD0nICsgZGF0YS5hY3RCYXJnYWluUmVnLmlkXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgfSwgJ25vbmUnKVxyXG4gICAgICAgIH1cclxuICAgICAgfSxcclxuICAgICAgcmV0KCkge1xyXG4gICAgICAgIHJldHVybiBmYWxzZVxyXG4gICAgICB9LFxyXG4gICAgICB0YWJTZWxlY3QoZSkge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGUpO1xyXG4gICAgICAgIHRoaXMuVGFiQ3VyID0gZS5jdXJyZW50VGFyZ2V0LmRhdGFzZXQuaWQgfHwgZS5kZXRhaWwuY3VycmVudDtcclxuICAgICAgfSxcclxuICAgICAgaGlkZU1vZGFsKCkge1xyXG4gICAgICAgIHRoaXMudG9QaW50dWFuID0gZmFsc2VcclxuICAgICAgICB0aGlzLnNob3dTa3UgPSBmYWxzZVxyXG4gICAgICAgIHRoaXMubW9kYWxOYW1lID0gJydcclxuICAgICAgfSxcclxuICAgICAgc2t1KHR5cGUpIHtcclxuICAgICAgICB0aGlzLnNrdSh0eXBlKVxyXG4gICAgICB9LFxyXG4gICAgICBwbHVzKCkge1xyXG4gICAgICAgIGlmICh0aGlzLmJ1eVR5cHQgPT0gJ2JhcmdhaW4nIHx8IHRoaXMuYnV5VHlwdCA9PSAnY3Jvd2RmdW5kJykge1xyXG4gICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHd4LnZpYnJhdGVTaG9ydCgpXHJcbiAgICAgICAgdGhpcy5udW0gPSB0aGlzLm51bSArIDFcclxuICAgICAgfSxcclxuICAgICAgbWludXMoKSB7XHJcbiAgICAgICAgaWYgKHRoaXMubnVtID4gMSkge1xyXG4gICAgICAgICAgd3gudmlicmF0ZVNob3J0KClcclxuICAgICAgICAgIHRoaXMubnVtID0gdGhpcy5udW0gLSAxXHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG4gICAgICBjb3Vyc2UoaW54KSB7XHJcbiAgICAgICAgdGhpcy5jb3Vyc2VJbnggPSBpbnhcclxuICAgICAgfSxcclxuICAgICAgYXN5bmMgYnV5KGFpZCA9IDAsIG90ID0gMSwgKSB7XHJcbiAgICAgICAgaWYgKHRoaXMuY291cnNlSW54ID09IC0xKSB7XHJcbiAgICAgICAgICBUaXBzLnRvYXN0KFwi6K+36YCJ5oup5LiA5Liq6JCl5pyfXCIsIHJlcyA9PiB7fSwgJ25vbmUnKVxyXG4gICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChvdCA9PSA0KSB7XHJcbiAgICAgICAgICAvLyDnoI3ku7dcclxuICAgICAgICAgIHdlcHkubmF2aWdhdGVUbyh7XHJcbiAgICAgICAgICAgIHVybDogYC9jcm93ZGZ1bmQvcGFnZXMvc3VyZU9yZGVyP3R5cGU9JHtvdH0mcGlkPSR7dGhpcy5jb3Vyc2VJbmZvLnBlcmlvZExpc3RbdGhpcy5jb3Vyc2VJbnhdLmlkfSZjaWQ9JHt0aGlzLmNvdXJzZUluZm8uaWR9Jm51bT0ke3RoaXMubnVtfSZhaWQ9JHthaWR9JmFjdHBpZD0ke3RoaXMuY291cnNlSW5mby5waW50dWFuSWR9JnB0PSR7dGhpcy5wYXltZW50VHlwZX1gXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICAgIHJldHVybiBmYWxzZVxyXG4gICAgICAgIH1cclxuICAgICAgICAvLyBpZihvdCA9PSAyKXtcclxuICAgICAgICAvLyAgICAgLy8g56CN5Lu3XHJcbiAgICAgICAgLy8gICAgIGFpZCA9IHRoaXMuY291cnNlSW5mby5iYXJnYWluSWRcclxuICAgICAgICAvLyB9XHJcbiAgICAgICAgLy8gaWYob3QgPT0gMyl7XHJcbiAgICAgICAgLy8gICAgIC8vIOaLvOWbolxyXG4gICAgICAgIC8vICAgICBhaWQgPSB0aGlzLmNvdXJzZUluZm8ucGludHVhbklkXHJcbiAgICAgICAgLy8gfVxyXG4gICAgICAgIHdlcHkubmF2aWdhdGVUbyh7XHJcbiAgICAgICAgICB1cmw6IGAuL3N1cmVPcmRlcj90eXBlPSR7b3R9JnBpZD0ke3RoaXMuY291cnNlSW5mby5wZXJpb2RMaXN0W3RoaXMuY291cnNlSW54XS5pZH0mY2lkPSR7dGhpcy5jb3Vyc2VJbmZvLmlkfSZudW09JHt0aGlzLm51bX0mYWlkPSR7YWlkfSZhY3RwaWQ9JHt0aGlzLmNvdXJzZUluZm8ucGludHVhbklkfSZwdD0ke3RoaXMucGF5bWVudFR5cGV9YFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gIH1cclxuIl19