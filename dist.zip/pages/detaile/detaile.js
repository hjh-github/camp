"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _swiper = require('./../../components/common/swiper.js');

var _swiper2 = _interopRequireDefault(_swiper);

var _title = require('./../../components/detaile/title.js');

var _title2 = _interopRequireDefault(_title);

var _info = require('./../../components/detaile/info.js');

var _info2 = _interopRequireDefault(_info);

var _remake = require('./../../components/detaile/remake.js');

var _remake2 = _interopRequireDefault(_remake);

var _contact = require('./../../components/common/contact.js');

var _contact2 = _interopRequireDefault(_contact);

var _utils = require('./../../store/utils.js');

var _utils2 = _interopRequireDefault(_utils);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

var _WxUtils = require('./../../utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
    _inherits(Dialog, _wepy$page);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.data = {
            TabCur: 0,
            close: "/static/images/close.png",
            swipers: {
                type: 1,
                list: [{
                    id: 0,
                    type: "image",
                    url: "",
                    link: "/pages/meet/meet",
                    linkType: "switchTab"
                }]
            },
            mainHeight: 0,
            courseInfo: {},
            nodes: ["name", "attrs", "attrs"],
            num: 1,
            showSku: false,
            buyTypt: 'normal',
            courseInx: -1,
            companions: [],
            statistics: {},
            CourseComment: {},
            ActPintuan: {},
            sign_states: {
                0: '火热招生中',
                1: '少量名额',
                2: '已满员'
            },
            toPintuan: false,
            modalName: '',
            customerService: {},
            member: {},
            paymentType: 1
        }, _this.$repeat = {}, _this.$props = { "cSwiper": { "xmlns:v-bind": "", "v-bind:model.sync": "swipers" }, "ctitle": { "v-bind:model.sync": "courseInfo" }, "cInfo": { "v-bind:model.sync": "courseInfo", "v-bind:companions.sync": "companions" }, "cRemake": { "v-bind:model.sync": "courseInfo", "v-bind:statistics.sync": "statistics", "v-bind:CourseComment.sync": "CourseComment" } }, _this.$events = {}, _this.components = {
            cSwiper: _swiper2.default,
            ctitle: _title2.default,
            cInfo: _info2.default,
            cRemake: _remake2.default,
            contact: _contact2.default
        }, _this.config = {
            navigationBarTitleText: "活动详情"
        }, _this.methods = {
            paymentType: function paymentType(type) {
                this.paymentType = type;
            },
            call: function call(phoneNumber) {
                wx.makePhoneCall({
                    phoneNumber: phoneNumber //仅为示例，并非真实的电话号码
                });
            },
            cont: function cont() {
                this.modalName = 'bottomModal';
            },
            tocut: function () {
                var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(e) {
                    return regeneratorRuntime.wrap(function _callee$(_context) {
                        while (1) {
                            switch (_context.prev = _context.next) {
                                case 0:
                                    if (_wepy2.default.getStorageSync('mobile') == '' || !_wepy2.default.getStorageSync('mobile') || _wepy2.default.getStorageSync('isFans') != 1) {
                                        _wepy2.default.navigateTo({
                                            url: "/pages/home/auth"
                                        });
                                    } else {
                                        this.sku('bargain');
                                        this.$apply();
                                    }

                                case 1:
                                case "end":
                                    return _context.stop();
                            }
                        }
                    }, _callee, this);
                }));

                function tocut(_x) {
                    return _ref2.apply(this, arguments);
                }

                return tocut;
            }(),
            createImg: function () {
                var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(e) {
                    return regeneratorRuntime.wrap(function _callee2$(_context2) {
                        while (1) {
                            switch (_context2.prev = _context2.next) {
                                case 0:
                                    if (!(e.detail.errMsg == "getUserInfo:ok")) {
                                        _context2.next = 5;
                                        break;
                                    }

                                    _context2.next = 3;
                                    return _auth2.default.getUserinfo(e.detail);

                                case 3:
                                    _utils2.default.save('shareInfo', {
                                        course: this.courseInfo,
                                        path: 'pages/detaile/detaile',
                                        id: this.courseInfo.id
                                    });
                                    _wepy2.default.navigateTo({
                                        url: '/pages/home/share'
                                    });

                                case 5:
                                case "end":
                                    return _context2.stop();
                            }
                        }
                    }, _callee2, this);
                }));

                function createImg(_x2) {
                    return _ref3.apply(this, arguments);
                }

                return createImg;
            }(),
            toshare: function toshare() {
                this.modalName = 'share';
            },
            toPintuanfy: function toPintuanfy() {
                if (_wepy2.default.getStorageSync('mobile') == '' || !_wepy2.default.getStorageSync('mobile') || _wepy2.default.getStorageSync('isFans') != 1) {
                    _wepy2.default.navigateTo({
                        url: "/pages/home/auth"
                    });
                } else {
                    this.toPintuan = true;
                }
            },
            bargain: function () {
                var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
                    var _ref5, errcode, errmsg, data;

                    return regeneratorRuntime.wrap(function _callee3$(_context3) {
                        while (1) {
                            switch (_context3.prev = _context3.next) {
                                case 0:
                                    if (!(this.courseInx == -1)) {
                                        _context3.next = 3;
                                        break;
                                    }

                                    _Tips2.default.toast("请选择一个营期", function (res) {}, 'none');
                                    return _context3.abrupt("return", false);

                                case 3:
                                    _context3.next = 5;
                                    return _config2.default.regBargain({
                                        bargainId: this.courseInfo.bargainId,
                                        courseId: this.courseInfo.id,
                                        periodId: this.courseInfo.periodList[this.courseInx].id
                                    });

                                case 5:
                                    _ref5 = _context3.sent;
                                    errcode = _ref5.errcode;
                                    errmsg = _ref5.errmsg;
                                    data = _ref5.data;

                                    if (errcode == 200) {
                                        _wepy2.default.redirectTo({
                                            url: '/pages/activity/bargain?id=' + data.regId
                                        });
                                    } else {
                                        // 发起砍价异常
                                        _Tips2.default.toast(errmsg, function (res) {
                                            _wepy2.default.redirectTo({
                                                url: '/pages/activity/bargain?id=' + data.actBargainReg.id
                                            });
                                        }, 'none');
                                    }

                                case 10:
                                case "end":
                                    return _context3.stop();
                            }
                        }
                    }, _callee3, this);
                }));

                function bargain() {
                    return _ref4.apply(this, arguments);
                }

                return bargain;
            }(),
            ret: function ret() {
                return false;
            },
            tabSelect: function tabSelect(e) {
                console.log(e);
                this.TabCur = e.currentTarget.dataset.id || e.detail.current;
            },
            hideModal: function hideModal() {
                this.toPintuan = false;
                this.showSku = false;
                this.modalName = '';
            },
            sku: function sku(type) {
                this.sku(type);
            },
            plus: function plus() {
                if (this.buyTypt == 'bargain') {
                    return false;
                }
                wx.vibrateShort();
                this.num = this.num + 1;
            },
            minus: function minus() {
                if (this.num > 1) {
                    wx.vibrateShort();
                    this.num = this.num - 1;
                }
            },
            course: function course(inx) {
                this.courseInx = inx;
            },
            buy: function () {
                var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
                    var aid = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;
                    var ot = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1;
                    return regeneratorRuntime.wrap(function _callee4$(_context4) {
                        while (1) {
                            switch (_context4.prev = _context4.next) {
                                case 0:
                                    if (!(this.courseInx == -1)) {
                                        _context4.next = 3;
                                        break;
                                    }

                                    _Tips2.default.toast("请选择一个营期", function (res) {}, 'none');
                                    return _context4.abrupt("return", false);

                                case 3:
                                    // if(ot == 2){
                                    //     // 砍价
                                    //     aid = this.courseInfo.bargainId
                                    // }
                                    // if(ot == 3){
                                    //     // 拼团
                                    //     aid = this.courseInfo.pintuanId
                                    // }
                                    _wepy2.default.navigateTo({
                                        url: "./sureOrder?type=" + ot + "&pid=" + this.courseInfo.periodList[this.courseInx].id + "&cid=" + this.courseInfo.id + "&num=" + this.num + "&aid=" + aid + "&actpid=" + this.courseInfo.pintuanId + "&pt=" + this.paymentType
                                    });

                                case 4:
                                case "end":
                                    return _context4.stop();
                            }
                        }
                    }, _callee4, this);
                }));

                function buy() {
                    return _ref6.apply(this, arguments);
                }

                return buy;
            }()
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(Dialog, [{
        key: "onShareAppMessage",

        // 转发暂时先不开启
        value: function onShareAppMessage(res) {
            if (res.from === 'button') {
                // 来自页面内转发按钮
                console.log(res.target);
            }
            return {
                title: this.courseInfo.courseTittle,
                path: '/pages/detaile/detaile?id=' + this.courseInfo.id + '&agentId=' + this.member.agentId
            };
        }
    }, {
        key: "onLoad",
        value: function () {
            var _ref7 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5(opt) {
                var _this2 = this;

                var view, _ref8, course, companions, statistics, CourseComment, actPintuan, customerService;

                return regeneratorRuntime.wrap(function _callee5$(_context5) {
                    while (1) {
                        switch (_context5.prev = _context5.next) {
                            case 0:
                                console.log(opt);
                                // 获取主内容高度，用于悬浮详情导航
                                view = wx.createSelectorQuery().select("#info-box");

                                view.fields({
                                    size: true
                                }, function (data) {
                                    console.log(data.height);
                                    _this2.mainHeight = data.height;
                                }).exec();
                                _context5.next = 5;
                                return _auth2.default.login();

                            case 5:
                                this.member = _wepy2.default.getStorageSync('member');
                                _context5.next = 8;
                                return _config2.default.getCourseInfo(opt.id || opt.scene);

                            case 8:
                                _ref8 = _context5.sent;
                                course = _ref8.course;
                                companions = _ref8.companions;
                                statistics = _ref8.statistics;
                                CourseComment = _ref8.CourseComment;
                                actPintuan = _ref8.actPintuan;
                                customerService = _ref8.customerService;

                                this.swipers.list = course.pics;
                                course.courseChar = course.courseChar.split("|");
                                this.courseInfo = course;
                                this.customerService = customerService;
                                _wepy2.default.$instance.globalData.courseInfo = course;
                                this.companions = companions;
                                this.statistics = statistics;
                                this.CourseComment = CourseComment;
                                this.ActPintuan = actPintuan;
                                console.log(this.ActPintuan);
                                this.$apply();

                            case 26:
                            case "end":
                                return _context5.stop();
                        }
                    }
                }, _callee5, this);
            }));

            function onLoad(_x5) {
                return _ref7.apply(this, arguments);
            }

            return onLoad;
        }()
    }, {
        key: "sku",
        value: function sku() {
            var type = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'normal';

            this.showSku = true;
            this.toPintuan = false;
            this.buyTypt = type;
        }
    }]);

    return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/detaile/detaile'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldGFpbGUuanMiXSwibmFtZXMiOlsiRGlhbG9nIiwiZGF0YSIsIlRhYkN1ciIsImNsb3NlIiwic3dpcGVycyIsInR5cGUiLCJsaXN0IiwiaWQiLCJ1cmwiLCJsaW5rIiwibGlua1R5cGUiLCJtYWluSGVpZ2h0IiwiY291cnNlSW5mbyIsIm5vZGVzIiwibnVtIiwic2hvd1NrdSIsImJ1eVR5cHQiLCJjb3Vyc2VJbngiLCJjb21wYW5pb25zIiwic3RhdGlzdGljcyIsIkNvdXJzZUNvbW1lbnQiLCJBY3RQaW50dWFuIiwic2lnbl9zdGF0ZXMiLCJ0b1BpbnR1YW4iLCJtb2RhbE5hbWUiLCJjdXN0b21lclNlcnZpY2UiLCJtZW1iZXIiLCJwYXltZW50VHlwZSIsIiRyZXBlYXQiLCIkcHJvcHMiLCIkZXZlbnRzIiwiY29tcG9uZW50cyIsImNTd2lwZXIiLCJjdGl0bGUiLCJjSW5mbyIsImNSZW1ha2UiLCJjb250YWN0IiwiY29uZmlnIiwibmF2aWdhdGlvbkJhclRpdGxlVGV4dCIsIm1ldGhvZHMiLCJjYWxsIiwicGhvbmVOdW1iZXIiLCJ3eCIsIm1ha2VQaG9uZUNhbGwiLCJjb250IiwidG9jdXQiLCJlIiwid2VweSIsImdldFN0b3JhZ2VTeW5jIiwibmF2aWdhdGVUbyIsInNrdSIsIiRhcHBseSIsImNyZWF0ZUltZyIsImRldGFpbCIsImVyck1zZyIsImF1dGgiLCJnZXRVc2VyaW5mbyIsInN0b3JlIiwic2F2ZSIsImNvdXJzZSIsInBhdGgiLCJ0b3NoYXJlIiwidG9QaW50dWFuZnkiLCJiYXJnYWluIiwiVGlwcyIsInRvYXN0IiwicmVnQmFyZ2FpbiIsImJhcmdhaW5JZCIsImNvdXJzZUlkIiwicGVyaW9kSWQiLCJwZXJpb2RMaXN0IiwiZXJyY29kZSIsImVycm1zZyIsInJlZGlyZWN0VG8iLCJyZWdJZCIsImFjdEJhcmdhaW5SZWciLCJyZXQiLCJ0YWJTZWxlY3QiLCJjb25zb2xlIiwibG9nIiwiY3VycmVudFRhcmdldCIsImRhdGFzZXQiLCJjdXJyZW50IiwiaGlkZU1vZGFsIiwicGx1cyIsInZpYnJhdGVTaG9ydCIsIm1pbnVzIiwiaW54IiwiYnV5IiwiYWlkIiwib3QiLCJwaW50dWFuSWQiLCJyZXMiLCJmcm9tIiwidGFyZ2V0IiwidGl0bGUiLCJjb3Vyc2VUaXR0bGUiLCJhZ2VudElkIiwib3B0IiwidmlldyIsImNyZWF0ZVNlbGVjdG9yUXVlcnkiLCJzZWxlY3QiLCJmaWVsZHMiLCJzaXplIiwiaGVpZ2h0IiwiZXhlYyIsImxvZ2luIiwiZ2V0Q291cnNlSW5mbyIsInNjZW5lIiwiYWN0UGludHVhbiIsInBpY3MiLCJjb3Vyc2VDaGFyIiwic3BsaXQiLCIkaW5zdGFuY2UiLCJnbG9iYWxEYXRhIiwicGFnZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQ0k7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7Ozs7Ozs7Ozs7Ozs7SUFDcUJBLE07Ozs7Ozs7Ozs7Ozs7OzBMQUNqQkMsSSxHQUFPO0FBQ0hDLG9CQUFRLENBREw7QUFFSEMsbUJBQU8sMEJBRko7QUFHSEMscUJBQVM7QUFDTEMsc0JBQU0sQ0FERDtBQUVMQyxzQkFBTSxDQUFDO0FBQ0hDLHdCQUFJLENBREQ7QUFFSEYsMEJBQU0sT0FGSDtBQUdIRyx5QkFBSyxFQUhGO0FBSUhDLDBCQUFNLGtCQUpIO0FBS0hDLDhCQUFVO0FBTFAsaUJBQUQ7QUFGRCxhQUhOO0FBYUhDLHdCQUFZLENBYlQ7QUFjSEMsd0JBQVksRUFkVDtBQWVIQyxtQkFBTyxDQUFDLE1BQUQsRUFBUyxPQUFULEVBQWtCLE9BQWxCLENBZko7QUFnQkhDLGlCQUFLLENBaEJGO0FBaUJIQyxxQkFBUyxLQWpCTjtBQWtCSEMscUJBQVMsUUFsQk47QUFtQkhDLHVCQUFXLENBQUMsQ0FuQlQ7QUFvQkhDLHdCQUFZLEVBcEJUO0FBcUJIQyx3QkFBWSxFQXJCVDtBQXNCSEMsMkJBQWUsRUF0Qlo7QUF1QkhDLHdCQUFZLEVBdkJUO0FBd0JIQyx5QkFBYTtBQUNULG1CQUFHLE9BRE07QUFFVCxtQkFBRyxNQUZNO0FBR1QsbUJBQUc7QUFITSxhQXhCVjtBQTZCSEMsdUJBQVcsS0E3QlI7QUE4QkhDLHVCQUFXLEVBOUJSO0FBK0JIQyw2QkFBaUIsRUEvQmQ7QUFnQ0hDLG9CQUFRLEVBaENMO0FBaUNIQyx5QkFBYTtBQWpDVixTLFFBbUNSQyxPLEdBQVUsRSxRQUNqQkMsTSxHQUFTLEVBQUMsV0FBVSxFQUFDLGdCQUFlLEVBQWhCLEVBQW1CLHFCQUFvQixTQUF2QyxFQUFYLEVBQTZELFVBQVMsRUFBQyxxQkFBb0IsWUFBckIsRUFBdEUsRUFBeUcsU0FBUSxFQUFDLHFCQUFvQixZQUFyQixFQUFrQywwQkFBeUIsWUFBM0QsRUFBakgsRUFBMEwsV0FBVSxFQUFDLHFCQUFvQixZQUFyQixFQUFrQywwQkFBeUIsWUFBM0QsRUFBd0UsNkJBQTRCLGVBQXBHLEVBQXBNLEUsUUFDVEMsTyxHQUFVLEUsUUFDVEMsVSxHQUFhO0FBQ0ZDLHFDQURFO0FBRUZDLG1DQUZFO0FBR0ZDLGlDQUhFO0FBSUZDLHFDQUpFO0FBS0ZDO0FBTEUsUyxRQU9OQyxNLEdBQVM7QUFDTEMsb0NBQXdCO0FBRG5CLFMsUUF1RFRDLE8sR0FBVTtBQUNOWix1QkFETSx1QkFDTXRCLElBRE4sRUFDWTtBQUNkLHFCQUFLc0IsV0FBTCxHQUFtQnRCLElBQW5CO0FBQ0gsYUFISztBQUlObUMsZ0JBSk0sZ0JBSURDLFdBSkMsRUFJWTtBQUNkQyxtQkFBR0MsYUFBSCxDQUFpQjtBQUNiRiw0Q0FEYSxDQUNEO0FBREMsaUJBQWpCO0FBR0gsYUFSSztBQVNORyxnQkFUTSxrQkFTQztBQUNILHFCQUFLcEIsU0FBTCxHQUFpQixhQUFqQjtBQUNILGFBWEs7QUFZQXFCLGlCQVpBO0FBQUEscUdBWU1DLENBWk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQWFGLHdDQUFJQyxlQUFLQyxjQUFMLENBQW9CLFFBQXBCLEtBQWlDLEVBQWpDLElBQXVDLENBQUNELGVBQUtDLGNBQUwsQ0FBb0IsUUFBcEIsQ0FBeEMsSUFBeUVELGVBQUtDLGNBQUwsQ0FBb0IsUUFBcEIsS0FBaUMsQ0FBOUcsRUFBaUg7QUFDN0dELHVEQUFLRSxVQUFMLENBQWdCO0FBQ1p6QztBQURZLHlDQUFoQjtBQUdILHFDQUpELE1BSU87QUFDSCw2Q0FBSzBDLEdBQUwsQ0FBUyxTQUFUO0FBQ0EsNkNBQUtDLE1BQUw7QUFDSDs7QUFwQkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFzQkFDLHFCQXRCQTtBQUFBLHNHQXNCVU4sQ0F0QlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBDQXVCRUEsRUFBRU8sTUFBRixDQUFTQyxNQUFULElBQW1CLGdCQXZCckI7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQSwyQ0F3QlFDLGVBQUtDLFdBQUwsQ0FBaUJWLEVBQUVPLE1BQW5CLENBeEJSOztBQUFBO0FBeUJFSSxvREFBTUMsSUFBTixDQUFXLFdBQVgsRUFBd0I7QUFDcEJDLGdEQUFRLEtBQUsvQyxVQURPO0FBRXBCZ0QsOENBQU0sdUJBRmM7QUFHcEJyRCw0Q0FBSSxLQUFLSyxVQUFMLENBQWdCTDtBQUhBLHFDQUF4QjtBQUtBd0MsbURBQUtFLFVBQUwsQ0FBZ0I7QUFDWnpDLDZDQUFLO0FBRE8scUNBQWhCOztBQTlCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQW1DTnFELG1CQW5DTSxxQkFtQ0k7QUFDTixxQkFBS3JDLFNBQUwsR0FBaUIsT0FBakI7QUFDSCxhQXJDSztBQXNDTnNDLHVCQXRDTSx5QkFzQ1E7QUFDVixvQkFBSWYsZUFBS0MsY0FBTCxDQUFvQixRQUFwQixLQUFpQyxFQUFqQyxJQUF1QyxDQUFDRCxlQUFLQyxjQUFMLENBQW9CLFFBQXBCLENBQXhDLElBQXlFRCxlQUFLQyxjQUFMLENBQW9CLFFBQXBCLEtBQWlDLENBQTlHLEVBQWlIO0FBQzdHRCxtQ0FBS0UsVUFBTCxDQUFnQjtBQUNaekM7QUFEWSxxQkFBaEI7QUFHSCxpQkFKRCxNQUlPO0FBQ0gseUJBQUtlLFNBQUwsR0FBaUIsSUFBakI7QUFDSDtBQUNKLGFBOUNLO0FBK0NBd0MsbUJBL0NBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBDQWdERSxLQUFLOUMsU0FBTCxJQUFrQixDQUFDLENBaERyQjtBQUFBO0FBQUE7QUFBQTs7QUFpREUrQyxtREFBS0MsS0FBTCxDQUFXLFNBQVgsRUFBc0IsZUFBTyxDQUFFLENBQS9CLEVBQWlDLE1BQWpDO0FBakRGLHNFQWtEUyxLQWxEVDs7QUFBQTtBQUFBO0FBQUEsMkNBd0RRNUIsaUJBQU82QixVQUFQLENBQWtCO0FBQ3hCQyxtREFBVyxLQUFLdkQsVUFBTCxDQUFnQnVELFNBREg7QUFFeEJDLGtEQUFVLEtBQUt4RCxVQUFMLENBQWdCTCxFQUZGO0FBR3hCOEQsa0RBQVUsS0FBS3pELFVBQUwsQ0FBZ0IwRCxVQUFoQixDQUEyQixLQUFLckQsU0FBaEMsRUFBMkNWO0FBSDdCLHFDQUFsQixDQXhEUjs7QUFBQTtBQUFBO0FBcURFZ0UsMkNBckRGLFNBcURFQSxPQXJERjtBQXNERUMsMENBdERGLFNBc0RFQSxNQXRERjtBQXVERXZFLHdDQXZERixTQXVERUEsSUF2REY7O0FBNkRGLHdDQUFJc0UsV0FBVyxHQUFmLEVBQW9CO0FBQ2hCeEIsdURBQUswQixVQUFMLENBQWdCO0FBQ1pqRSxpREFBSyxnQ0FBZ0NQLEtBQUt5RTtBQUQ5Qix5Q0FBaEI7QUFHSCxxQ0FKRCxNQUlPO0FBQ0g7QUFDQVYsdURBQUtDLEtBQUwsQ0FBV08sTUFBWCxFQUFtQixlQUFPO0FBQ3RCekIsMkRBQUswQixVQUFMLENBQWdCO0FBQ1pqRSxxREFBSyxnQ0FBZ0NQLEtBQUswRSxhQUFMLENBQW1CcEU7QUFENUMsNkNBQWhCO0FBR0gseUNBSkQsRUFJRyxNQUpIO0FBS0g7O0FBeEVDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBMEVOcUUsZUExRU0saUJBMEVBO0FBQ0YsdUJBQU8sS0FBUDtBQUNILGFBNUVLO0FBNkVOQyxxQkE3RU0scUJBNkVJL0IsQ0E3RUosRUE2RU87QUFDVGdDLHdCQUFRQyxHQUFSLENBQVlqQyxDQUFaO0FBQ0EscUJBQUs1QyxNQUFMLEdBQWM0QyxFQUFFa0MsYUFBRixDQUFnQkMsT0FBaEIsQ0FBd0IxRSxFQUF4QixJQUE4QnVDLEVBQUVPLE1BQUYsQ0FBUzZCLE9BQXJEO0FBQ0gsYUFoRks7QUFpRk5DLHFCQWpGTSx1QkFpRk07QUFDUixxQkFBSzVELFNBQUwsR0FBaUIsS0FBakI7QUFDQSxxQkFBS1IsT0FBTCxHQUFlLEtBQWY7QUFDQSxxQkFBS1MsU0FBTCxHQUFpQixFQUFqQjtBQUNILGFBckZLO0FBc0ZOMEIsZUF0Rk0sZUFzRkY3QyxJQXRGRSxFQXNGSTtBQUNOLHFCQUFLNkMsR0FBTCxDQUFTN0MsSUFBVDtBQUNILGFBeEZLO0FBeUZOK0UsZ0JBekZNLGtCQXlGQztBQUNILG9CQUFJLEtBQUtwRSxPQUFMLElBQWdCLFNBQXBCLEVBQStCO0FBQzNCLDJCQUFPLEtBQVA7QUFDSDtBQUNEMEIsbUJBQUcyQyxZQUFIO0FBQ0EscUJBQUt2RSxHQUFMLEdBQVcsS0FBS0EsR0FBTCxHQUFXLENBQXRCO0FBQ0gsYUEvRks7QUFnR053RSxpQkFoR00sbUJBZ0dFO0FBQ0osb0JBQUksS0FBS3hFLEdBQUwsR0FBVyxDQUFmLEVBQWtCO0FBQ2Q0Qix1QkFBRzJDLFlBQUg7QUFDQSx5QkFBS3ZFLEdBQUwsR0FBVyxLQUFLQSxHQUFMLEdBQVcsQ0FBdEI7QUFDSDtBQUNKLGFBckdLO0FBc0dONkMsa0JBdEdNLGtCQXNHQzRCLEdBdEdELEVBc0dNO0FBQ1IscUJBQUt0RSxTQUFMLEdBQWlCc0UsR0FBakI7QUFDSCxhQXhHSztBQXlHQUMsZUF6R0E7QUFBQTtBQUFBLHdCQXlHSUMsR0F6R0osdUVBeUdVLENBekdWO0FBQUEsd0JBeUdhQyxFQXpHYix1RUF5R2tCLENBekdsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMENBMEdFLEtBQUt6RSxTQUFMLElBQWtCLENBQUMsQ0ExR3JCO0FBQUE7QUFBQTtBQUFBOztBQTJHRStDLG1EQUFLQyxLQUFMLENBQVcsU0FBWCxFQUFzQixlQUFPLENBQUUsQ0FBL0IsRUFBaUMsTUFBakM7QUEzR0Ysc0VBNEdTLEtBNUdUOztBQUFBO0FBOEdGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQWxCLG1EQUFLRSxVQUFMLENBQWdCO0FBQ1p6QyxtRUFBeUJrRixFQUF6QixhQUFtQyxLQUFLOUUsVUFBTCxDQUFnQjBELFVBQWhCLENBQTJCLEtBQUtyRCxTQUFoQyxFQUEyQ1YsRUFBOUUsYUFBd0YsS0FBS0ssVUFBTCxDQUFnQkwsRUFBeEcsYUFBa0gsS0FBS08sR0FBdkgsYUFBa0kyRSxHQUFsSSxnQkFBZ0osS0FBSzdFLFVBQUwsQ0FBZ0IrRSxTQUFoSyxZQUFnTCxLQUFLaEU7QUFEeksscUNBQWhCOztBQXRIRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBLFM7Ozs7OztBQXBEVjswQ0FDa0JpRSxHLEVBQUs7QUFDbkIsZ0JBQUlBLElBQUlDLElBQUosS0FBYSxRQUFqQixFQUEyQjtBQUN2QjtBQUNBZix3QkFBUUMsR0FBUixDQUFZYSxJQUFJRSxNQUFoQjtBQUNIO0FBQ0QsbUJBQU87QUFDSEMsdUJBQU8sS0FBS25GLFVBQUwsQ0FBZ0JvRixZQURwQjtBQUVIcEMsc0JBQU0sK0JBQStCLEtBQUtoRCxVQUFMLENBQWdCTCxFQUEvQyxHQUFvRCxXQUFwRCxHQUFrRSxLQUFLbUIsTUFBTCxDQUFZdUU7QUFGakYsYUFBUDtBQUlIOzs7O2tHQUNZQyxHOzs7Ozs7Ozs7QUFDVHBCLHdDQUFRQyxHQUFSLENBQVltQixHQUFaO0FBQ0E7QUFDSUMsb0MsR0FBT3pELEdBQUcwRCxtQkFBSCxHQUF5QkMsTUFBekIsQ0FBZ0MsV0FBaEMsQzs7QUFDWEYscUNBQ0tHLE1BREwsQ0FDWTtBQUNBQywwQ0FBTTtBQUROLGlDQURaLEVBSVEsZ0JBQVE7QUFDSnpCLDRDQUFRQyxHQUFSLENBQVk5RSxLQUFLdUcsTUFBakI7QUFDQSwyQ0FBSzdGLFVBQUwsR0FBa0JWLEtBQUt1RyxNQUF2QjtBQUNILGlDQVBULEVBU0tDLElBVEw7O3VDQVVNbEQsZUFBS21ELEtBQUwsRTs7O0FBQ04scUNBQUtoRixNQUFMLEdBQWNxQixlQUFLQyxjQUFMLENBQW9CLFFBQXBCLENBQWQ7O3VDQVFVWCxpQkFBT3NFLGFBQVAsQ0FBcUJULElBQUkzRixFQUFKLElBQVUyRixJQUFJVSxLQUFuQyxDOzs7O0FBTk5qRCxzQyxTQUFBQSxNO0FBQ0F6QywwQyxTQUFBQSxVO0FBQ0FDLDBDLFNBQUFBLFU7QUFDQUMsNkMsU0FBQUEsYTtBQUNBeUYsMEMsU0FBQUEsVTtBQUNBcEYsK0MsU0FBQUEsZTs7QUFFSixxQ0FBS3JCLE9BQUwsQ0FBYUUsSUFBYixHQUFvQnFELE9BQU9tRCxJQUEzQjtBQUNBbkQsdUNBQU9vRCxVQUFQLEdBQW9CcEQsT0FBT29ELFVBQVAsQ0FBa0JDLEtBQWxCLENBQXdCLEdBQXhCLENBQXBCO0FBQ0EscUNBQUtwRyxVQUFMLEdBQWtCK0MsTUFBbEI7QUFDQSxxQ0FBS2xDLGVBQUwsR0FBdUJBLGVBQXZCO0FBQ0FzQiwrQ0FBS2tFLFNBQUwsQ0FBZUMsVUFBZixDQUEwQnRHLFVBQTFCLEdBQXVDK0MsTUFBdkM7QUFDQSxxQ0FBS3pDLFVBQUwsR0FBa0JBLFVBQWxCO0FBQ0EscUNBQUtDLFVBQUwsR0FBa0JBLFVBQWxCO0FBQ0EscUNBQUtDLGFBQUwsR0FBcUJBLGFBQXJCO0FBQ0EscUNBQUtDLFVBQUwsR0FBa0J3RixVQUFsQjtBQUNBL0Isd0NBQVFDLEdBQVIsQ0FBWSxLQUFLMUQsVUFBakI7QUFDQSxxQ0FBSzhCLE1BQUw7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs4QkFFaUI7QUFBQSxnQkFBakI5QyxJQUFpQix1RUFBVixRQUFVOztBQUNqQixpQkFBS1UsT0FBTCxHQUFlLElBQWY7QUFDQSxpQkFBS1EsU0FBTCxHQUFpQixLQUFqQjtBQUNBLGlCQUFLUCxPQUFMLEdBQWVYLElBQWY7QUFDSDs7OztFQXBHK0IwQyxlQUFLb0UsSTs7a0JBQXBCbkgsTSIsImZpbGUiOiJkZXRhaWxlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbiAgICBpbXBvcnQgd2VweSBmcm9tIFwid2VweVwiO1xyXG4gICAgaW1wb3J0IGNTd2lwZXIgZnJvbSBcIkAvY29tcG9uZW50cy9jb21tb24vc3dpcGVyXCI7XHJcbiAgICBpbXBvcnQgY3RpdGxlIGZyb20gXCJAL2NvbXBvbmVudHMvZGV0YWlsZS90aXRsZVwiO1xyXG4gICAgaW1wb3J0IGNJbmZvIGZyb20gXCJAL2NvbXBvbmVudHMvZGV0YWlsZS9pbmZvXCI7XHJcbiAgICBpbXBvcnQgY1JlbWFrZSBmcm9tIFwiQC9jb21wb25lbnRzL2RldGFpbGUvcmVtYWtlXCI7XHJcbiAgICBpbXBvcnQgY29udGFjdCBmcm9tIFwiQC9jb21wb25lbnRzL2NvbW1vbi9jb250YWN0XCJcclxuICAgIGltcG9ydCBzdG9yZSBmcm9tIFwiQC9zdG9yZS91dGlsc1wiXHJcbiAgICBpbXBvcnQgY29uZmlnIGZyb20gXCJAL2FwaS9jb25maWdcIjtcclxuICAgIGltcG9ydCBhdXRoIGZyb20gXCJAL2FwaS9hdXRoXCI7XHJcbiAgICBpbXBvcnQgV3hVdGlscyBmcm9tIFwiQC91dGlscy9XeFV0aWxzXCI7XHJcbiAgICBpbXBvcnQgVGlwcyBmcm9tIFwiQC91dGlscy9UaXBzXCI7XHJcbiAgICBleHBvcnQgZGVmYXVsdCBjbGFzcyBEaWFsb2cgZXh0ZW5kcyB3ZXB5LnBhZ2Uge1xyXG4gICAgICAgIGRhdGEgPSB7XHJcbiAgICAgICAgICAgIFRhYkN1cjogMCxcclxuICAgICAgICAgICAgY2xvc2U6IFwiL3N0YXRpYy9pbWFnZXMvY2xvc2UucG5nXCIsXHJcbiAgICAgICAgICAgIHN3aXBlcnM6IHtcclxuICAgICAgICAgICAgICAgIHR5cGU6IDEsXHJcbiAgICAgICAgICAgICAgICBsaXN0OiBbe1xyXG4gICAgICAgICAgICAgICAgICAgIGlkOiAwLFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU6IFwiaW1hZ2VcIixcclxuICAgICAgICAgICAgICAgICAgICB1cmw6IFwiXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgbGluazogXCIvcGFnZXMvbWVldC9tZWV0XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgbGlua1R5cGU6IFwic3dpdGNoVGFiXCJcclxuICAgICAgICAgICAgICAgIH1dXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIG1haW5IZWlnaHQ6IDAsXHJcbiAgICAgICAgICAgIGNvdXJzZUluZm86IHt9LFxyXG4gICAgICAgICAgICBub2RlczogW1wibmFtZVwiLCBcImF0dHJzXCIsIFwiYXR0cnNcIl0sXHJcbiAgICAgICAgICAgIG51bTogMSxcclxuICAgICAgICAgICAgc2hvd1NrdTogZmFsc2UsXHJcbiAgICAgICAgICAgIGJ1eVR5cHQ6ICdub3JtYWwnLFxyXG4gICAgICAgICAgICBjb3Vyc2VJbng6IC0xLFxyXG4gICAgICAgICAgICBjb21wYW5pb25zOiBbXSxcclxuICAgICAgICAgICAgc3RhdGlzdGljczoge30sXHJcbiAgICAgICAgICAgIENvdXJzZUNvbW1lbnQ6IHt9LFxyXG4gICAgICAgICAgICBBY3RQaW50dWFuOiB7fSxcclxuICAgICAgICAgICAgc2lnbl9zdGF0ZXM6IHtcclxuICAgICAgICAgICAgICAgIDA6ICfngavng63mi5vnlJ/kuK0nLFxyXG4gICAgICAgICAgICAgICAgMTogJ+WwkemHj+WQjeminScsXHJcbiAgICAgICAgICAgICAgICAyOiAn5bey5ruh5ZGYJ1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB0b1BpbnR1YW46IGZhbHNlLFxyXG4gICAgICAgICAgICBtb2RhbE5hbWU6ICcnLFxyXG4gICAgICAgICAgICBjdXN0b21lclNlcnZpY2U6IHt9LFxyXG4gICAgICAgICAgICBtZW1iZXI6IHt9LFxyXG4gICAgICAgICAgICBwYXltZW50VHlwZTogMVxyXG4gICAgICAgIH07XHJcbiAgICAgICAkcmVwZWF0ID0ge307XHJcbiRwcm9wcyA9IHtcImNTd2lwZXJcIjp7XCJ4bWxuczp2LWJpbmRcIjpcIlwiLFwidi1iaW5kOm1vZGVsLnN5bmNcIjpcInN3aXBlcnNcIn0sXCJjdGl0bGVcIjp7XCJ2LWJpbmQ6bW9kZWwuc3luY1wiOlwiY291cnNlSW5mb1wifSxcImNJbmZvXCI6e1widi1iaW5kOm1vZGVsLnN5bmNcIjpcImNvdXJzZUluZm9cIixcInYtYmluZDpjb21wYW5pb25zLnN5bmNcIjpcImNvbXBhbmlvbnNcIn0sXCJjUmVtYWtlXCI6e1widi1iaW5kOm1vZGVsLnN5bmNcIjpcImNvdXJzZUluZm9cIixcInYtYmluZDpzdGF0aXN0aWNzLnN5bmNcIjpcInN0YXRpc3RpY3NcIixcInYtYmluZDpDb3Vyc2VDb21tZW50LnN5bmNcIjpcIkNvdXJzZUNvbW1lbnRcIn19O1xyXG4kZXZlbnRzID0ge307XHJcbiBjb21wb25lbnRzID0ge1xyXG4gICAgICAgICAgICBjU3dpcGVyLFxyXG4gICAgICAgICAgICBjdGl0bGUsXHJcbiAgICAgICAgICAgIGNJbmZvLFxyXG4gICAgICAgICAgICBjUmVtYWtlLFxyXG4gICAgICAgICAgICBjb250YWN0XHJcbiAgICAgICAgfTtcclxuICAgICAgICBjb25maWcgPSB7XHJcbiAgICAgICAgICAgIG5hdmlnYXRpb25CYXJUaXRsZVRleHQ6IFwi5rS75Yqo6K+m5oOFXCJcclxuICAgICAgICB9O1xyXG4gICAgICAgIC8vIOi9rOWPkeaaguaXtuWFiOS4jeW8gOWQr1xyXG4gICAgICAgIG9uU2hhcmVBcHBNZXNzYWdlKHJlcykge1xyXG4gICAgICAgICAgICBpZiAocmVzLmZyb20gPT09ICdidXR0b24nKSB7XHJcbiAgICAgICAgICAgICAgICAvLyDmnaXoh6rpobXpnaLlhoXovazlj5HmjInpkq5cclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKHJlcy50YXJnZXQpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgIHRpdGxlOiB0aGlzLmNvdXJzZUluZm8uY291cnNlVGl0dGxlLFxyXG4gICAgICAgICAgICAgICAgcGF0aDogJy9wYWdlcy9kZXRhaWxlL2RldGFpbGU/aWQ9JyArIHRoaXMuY291cnNlSW5mby5pZCArICcmYWdlbnRJZD0nICsgdGhpcy5tZW1iZXIuYWdlbnRJZFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGFzeW5jIG9uTG9hZChvcHQpIHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2cob3B0KVxyXG4gICAgICAgICAgICAvLyDojrflj5bkuLvlhoXlrrnpq5jluqbvvIznlKjkuo7mgqzmta7or6bmg4Xlr7zoiKpcclxuICAgICAgICAgICAgbGV0IHZpZXcgPSB3eC5jcmVhdGVTZWxlY3RvclF1ZXJ5KCkuc2VsZWN0KFwiI2luZm8tYm94XCIpO1xyXG4gICAgICAgICAgICB2aWV3XHJcbiAgICAgICAgICAgICAgICAuZmllbGRzKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZTogdHJ1ZVxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgZGF0YSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGRhdGEuaGVpZ2h0KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5tYWluSGVpZ2h0ID0gZGF0YS5oZWlnaHQ7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgLmV4ZWMoKTtcclxuICAgICAgICAgICAgYXdhaXQgYXV0aC5sb2dpbigpXHJcbiAgICAgICAgICAgIHRoaXMubWVtYmVyID0gd2VweS5nZXRTdG9yYWdlU3luYygnbWVtYmVyJyk7XHJcbiAgICAgICAgICAgIGxldCB7XHJcbiAgICAgICAgICAgICAgICBjb3Vyc2UsXHJcbiAgICAgICAgICAgICAgICBjb21wYW5pb25zLFxyXG4gICAgICAgICAgICAgICAgc3RhdGlzdGljcyxcclxuICAgICAgICAgICAgICAgIENvdXJzZUNvbW1lbnQsXHJcbiAgICAgICAgICAgICAgICBhY3RQaW50dWFuLFxyXG4gICAgICAgICAgICAgICAgY3VzdG9tZXJTZXJ2aWNlXHJcbiAgICAgICAgICAgIH0gPSBhd2FpdCBjb25maWcuZ2V0Q291cnNlSW5mbyhvcHQuaWQgfHwgb3B0LnNjZW5lKVxyXG4gICAgICAgICAgICB0aGlzLnN3aXBlcnMubGlzdCA9IGNvdXJzZS5waWNzXHJcbiAgICAgICAgICAgIGNvdXJzZS5jb3Vyc2VDaGFyID0gY291cnNlLmNvdXJzZUNoYXIuc3BsaXQoXCJ8XCIpXHJcbiAgICAgICAgICAgIHRoaXMuY291cnNlSW5mbyA9IGNvdXJzZVxyXG4gICAgICAgICAgICB0aGlzLmN1c3RvbWVyU2VydmljZSA9IGN1c3RvbWVyU2VydmljZVxyXG4gICAgICAgICAgICB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLmNvdXJzZUluZm8gPSBjb3Vyc2VcclxuICAgICAgICAgICAgdGhpcy5jb21wYW5pb25zID0gY29tcGFuaW9uc1xyXG4gICAgICAgICAgICB0aGlzLnN0YXRpc3RpY3MgPSBzdGF0aXN0aWNzXHJcbiAgICAgICAgICAgIHRoaXMuQ291cnNlQ29tbWVudCA9IENvdXJzZUNvbW1lbnRcclxuICAgICAgICAgICAgdGhpcy5BY3RQaW50dWFuID0gYWN0UGludHVhblxyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyh0aGlzLkFjdFBpbnR1YW4pXHJcbiAgICAgICAgICAgIHRoaXMuJGFwcGx5KCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHNrdSh0eXBlID0gJ25vcm1hbCcpIHtcclxuICAgICAgICAgICAgdGhpcy5zaG93U2t1ID0gdHJ1ZVxyXG4gICAgICAgICAgICB0aGlzLnRvUGludHVhbiA9IGZhbHNlXHJcbiAgICAgICAgICAgIHRoaXMuYnV5VHlwdCA9IHR5cGVcclxuICAgICAgICB9XHJcbiAgICAgICAgbWV0aG9kcyA9IHtcclxuICAgICAgICAgICAgcGF5bWVudFR5cGUodHlwZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5wYXltZW50VHlwZSA9IHR5cGVcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgY2FsbChwaG9uZU51bWJlcikge1xyXG4gICAgICAgICAgICAgICAgd3gubWFrZVBob25lQ2FsbCh7XHJcbiAgICAgICAgICAgICAgICAgICAgcGhvbmVOdW1iZXIgLy/ku4XkuLrnpLrkvovvvIzlubbpnZ7nnJ/lrp7nmoTnlLXor53lj7fnoIFcclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGNvbnQoKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGFsTmFtZSA9ICdib3R0b21Nb2RhbCdcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgYXN5bmMgdG9jdXQoZSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHdlcHkuZ2V0U3RvcmFnZVN5bmMoJ21vYmlsZScpID09ICcnIHx8ICF3ZXB5LmdldFN0b3JhZ2VTeW5jKCdtb2JpbGUnKSB8fCB3ZXB5LmdldFN0b3JhZ2VTeW5jKCdpc0ZhbnMnKSAhPSAxKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgd2VweS5uYXZpZ2F0ZVRvKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdXJsOiBgL3BhZ2VzL2hvbWUvYXV0aGBcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5za3UoJ2JhcmdhaW4nKVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgYXN5bmMgY3JlYXRlSW1nKGUpIHtcclxuICAgICAgICAgICAgICAgIGlmIChlLmRldGFpbC5lcnJNc2cgPT0gXCJnZXRVc2VySW5mbzpva1wiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYXdhaXQgYXV0aC5nZXRVc2VyaW5mbyhlLmRldGFpbClcclxuICAgICAgICAgICAgICAgICAgICBzdG9yZS5zYXZlKCdzaGFyZUluZm8nLCB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvdXJzZTogdGhpcy5jb3Vyc2VJbmZvLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYXRoOiAncGFnZXMvZGV0YWlsZS9kZXRhaWxlJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IHRoaXMuY291cnNlSW5mby5pZFxyXG4gICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgd2VweS5uYXZpZ2F0ZVRvKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdXJsOiAnL3BhZ2VzL2hvbWUvc2hhcmUnXHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHRvc2hhcmUoKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGFsTmFtZSA9ICdzaGFyZSdcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgdG9QaW50dWFuZnkoKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAod2VweS5nZXRTdG9yYWdlU3luYygnbW9iaWxlJykgPT0gJycgfHwgIXdlcHkuZ2V0U3RvcmFnZVN5bmMoJ21vYmlsZScpIHx8IHdlcHkuZ2V0U3RvcmFnZVN5bmMoJ2lzRmFucycpICE9IDEpIHtcclxuICAgICAgICAgICAgICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB1cmw6IGAvcGFnZXMvaG9tZS9hdXRoYFxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnRvUGludHVhbiA9IHRydWVcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgYXN5bmMgYmFyZ2FpbigpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmNvdXJzZUlueCA9PSAtMSkge1xyXG4gICAgICAgICAgICAgICAgICAgIFRpcHMudG9hc3QoXCLor7fpgInmi6nkuIDkuKrokKXmnJ9cIiwgcmVzID0+IHt9LCAnbm9uZScpXHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBsZXQge1xyXG4gICAgICAgICAgICAgICAgICAgIGVycmNvZGUsXHJcbiAgICAgICAgICAgICAgICAgICAgZXJybXNnLFxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGFcclxuICAgICAgICAgICAgICAgIH0gPSBhd2FpdCBjb25maWcucmVnQmFyZ2Fpbih7XHJcbiAgICAgICAgICAgICAgICAgICAgYmFyZ2FpbklkOiB0aGlzLmNvdXJzZUluZm8uYmFyZ2FpbklkLFxyXG4gICAgICAgICAgICAgICAgICAgIGNvdXJzZUlkOiB0aGlzLmNvdXJzZUluZm8uaWQsXHJcbiAgICAgICAgICAgICAgICAgICAgcGVyaW9kSWQ6IHRoaXMuY291cnNlSW5mby5wZXJpb2RMaXN0W3RoaXMuY291cnNlSW54XS5pZCxcclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICBpZiAoZXJyY29kZSA9PSAyMDApIHtcclxuICAgICAgICAgICAgICAgICAgICB3ZXB5LnJlZGlyZWN0VG8oe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB1cmw6ICcvcGFnZXMvYWN0aXZpdHkvYmFyZ2Fpbj9pZD0nICsgZGF0YS5yZWdJZFxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAvLyDlj5HotbfnoI3ku7flvILluLhcclxuICAgICAgICAgICAgICAgICAgICBUaXBzLnRvYXN0KGVycm1zZywgcmVzID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgd2VweS5yZWRpcmVjdFRvKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVybDogJy9wYWdlcy9hY3Rpdml0eS9iYXJnYWluP2lkPScgKyBkYXRhLmFjdEJhcmdhaW5SZWcuaWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfSwgJ25vbmUnKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICByZXQoKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgdGFiU2VsZWN0KGUpIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5UYWJDdXIgPSBlLmN1cnJlbnRUYXJnZXQuZGF0YXNldC5pZCB8fCBlLmRldGFpbC5jdXJyZW50O1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBoaWRlTW9kYWwoKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnRvUGludHVhbiA9IGZhbHNlXHJcbiAgICAgICAgICAgICAgICB0aGlzLnNob3dTa3UgPSBmYWxzZVxyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RhbE5hbWUgPSAnJ1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBza3UodHlwZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5za3UodHlwZSlcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgcGx1cygpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmJ1eVR5cHQgPT0gJ2JhcmdhaW4nKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB3eC52aWJyYXRlU2hvcnQoKVxyXG4gICAgICAgICAgICAgICAgdGhpcy5udW0gPSB0aGlzLm51bSArIDFcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgbWludXMoKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5udW0gPiAxKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgd3gudmlicmF0ZVNob3J0KClcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm51bSA9IHRoaXMubnVtIC0gMVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBjb3Vyc2UoaW54KSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNvdXJzZUlueCA9IGlueFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBhc3luYyBidXkoYWlkID0gMCwgb3QgPSAxLCApIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmNvdXJzZUlueCA9PSAtMSkge1xyXG4gICAgICAgICAgICAgICAgICAgIFRpcHMudG9hc3QoXCLor7fpgInmi6nkuIDkuKrokKXmnJ9cIiwgcmVzID0+IHt9LCAnbm9uZScpXHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvLyBpZihvdCA9PSAyKXtcclxuICAgICAgICAgICAgICAgIC8vICAgICAvLyDnoI3ku7dcclxuICAgICAgICAgICAgICAgIC8vICAgICBhaWQgPSB0aGlzLmNvdXJzZUluZm8uYmFyZ2FpbklkXHJcbiAgICAgICAgICAgICAgICAvLyB9XHJcbiAgICAgICAgICAgICAgICAvLyBpZihvdCA9PSAzKXtcclxuICAgICAgICAgICAgICAgIC8vICAgICAvLyDmi7zlm6JcclxuICAgICAgICAgICAgICAgIC8vICAgICBhaWQgPSB0aGlzLmNvdXJzZUluZm8ucGludHVhbklkXHJcbiAgICAgICAgICAgICAgICAvLyB9XHJcbiAgICAgICAgICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICAgICAgICAgIHVybDogYC4vc3VyZU9yZGVyP3R5cGU9JHtvdH0mcGlkPSR7dGhpcy5jb3Vyc2VJbmZvLnBlcmlvZExpc3RbdGhpcy5jb3Vyc2VJbnhdLmlkfSZjaWQ9JHt0aGlzLmNvdXJzZUluZm8uaWR9Jm51bT0ke3RoaXMubnVtfSZhaWQ9JHthaWR9JmFjdHBpZD0ke3RoaXMuY291cnNlSW5mby5waW50dWFuSWR9JnB0PSR7dGhpcy5wYXltZW50VHlwZX1gXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH07XHJcbiAgICB9XHJcbiJdfQ==