"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _swiper = require('./../../components/common/swiper.js');

var _swiper2 = _interopRequireDefault(_swiper);

var _title = require('./../../components/detaile/title.js');

var _title2 = _interopRequireDefault(_title);

var _info = require('./../../components/detaile/info.js');

var _info2 = _interopRequireDefault(_info);

var _remake = require('./../../components/detaile/remake.js');

var _remake2 = _interopRequireDefault(_remake);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _WxUtils = require('./../../utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
    _inherits(Dialog, _wepy$page);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.data = {
            TabCur: 0,
            close: "/static/images/close.png",
            swipers: {
                type: 1,
                list: [{
                    id: 0,
                    type: "image",
                    url: "",
                    link: "/pages/meet/meet",
                    linkType: "switchTab"
                }]
            },
            mainHeight: 0,
            courseInfo: {},
            nodes: ["name", "attrs", "attrs"],
            num: 1,
            showSku: false,
            buyTypt: 'normal',
            courseInx: -1,
            companions: [],
            statistics: {},
            CourseComment: {},
            sign_states: {
                0: '火热招生中',
                1: '少量名额',
                2: '已满员'
            },
            toPintuan: false
        }, _this.$repeat = {}, _this.$props = { "cSwiper": { "xmlns:v-bind": "", "v-bind:model.sync": "swipers" }, "ctitle": { "v-bind:model.sync": "courseInfo" }, "cInfo": { "v-bind:model.sync": "courseInfo", "v-bind:companions.sync": "companions" }, "cRemake": { "v-bind:model.sync": "courseInfo", "v-bind:statistics.sync": "statistics", "v-bind:CourseComment.sync": "CourseComment" } }, _this.$events = {}, _this.components = {
            cSwiper: _swiper2.default,
            ctitle: _title2.default,
            cInfo: _info2.default,
            cRemake: _remake2.default
        }, _this.config = {
            navigationBarTitleText: "活动详情"
        }, _this.methods = {
            toPintuanfy: function toPintuanfy() {
                this.toPintuan = true;
            },
            bargain: function () {
                var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
                    var _ref3, errcode, errmsg, data;

                    return regeneratorRuntime.wrap(function _callee$(_context) {
                        while (1) {
                            switch (_context.prev = _context.next) {
                                case 0:
                                    if (!(this.courseInx == -1)) {
                                        _context.next = 3;
                                        break;
                                    }

                                    _Tips2.default.toast("请选择一个营期", function (res) {}, 'none');
                                    return _context.abrupt("return", false);

                                case 3:
                                    _context.next = 5;
                                    return _config2.default.regBargain({
                                        bargainId: this.courseInfo.bargainId,
                                        courseId: this.courseInfo.id,
                                        periodId: this.courseInfo.periodList[this.courseInx].id
                                    });

                                case 5:
                                    _ref3 = _context.sent;
                                    errcode = _ref3.errcode;
                                    errmsg = _ref3.errmsg;
                                    data = _ref3.data;

                                    if (errcode == 200) {
                                        _wepy2.default.redirectTo({
                                            url: '/pages/activity/bargain?regId=' + data.regId
                                        });
                                    } else {
                                        // 发起砍价异常
                                        _Tips2.default.toast(errmsg, function (res) {
                                            _wepy2.default.redirectTo({
                                                url: '/pages/activity/bargain?regId=' + data.actBargainReg.id
                                            });
                                        }, 'none');
                                    }

                                case 10:
                                case "end":
                                    return _context.stop();
                            }
                        }
                    }, _callee, this);
                }));

                function bargain() {
                    return _ref2.apply(this, arguments);
                }

                return bargain;
            }(),
            ret: function ret() {
                return false;
            },
            tabSelect: function tabSelect(e) {
                console.log(e);
                this.TabCur = e.currentTarget.dataset.id || e.detail.current;
            },
            hideModal: function hideModal() {
                this.toPintuan = false;
                this.showSku = false;
            },
            sku: function sku() {
                var type = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'normal';

                this.showSku = true;
                this.toPintuan = false;
                this.buyTypt = type;
            },
            plus: function plus() {
                wx.vibrateShort();
                this.num = this.num + 1;
            },
            minus: function minus() {
                if (this.num > 1) {
                    wx.vibrateShort();
                    this.num = this.num - 1;
                }
            },
            course: function course(inx) {
                this.courseInx = inx;
            },
            buy: function () {
                var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
                    var aid = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;
                    var ot = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1;
                    return regeneratorRuntime.wrap(function _callee2$(_context2) {
                        while (1) {
                            switch (_context2.prev = _context2.next) {
                                case 0:
                                    if (!(this.courseInx == -1)) {
                                        _context2.next = 3;
                                        break;
                                    }

                                    _Tips2.default.toast("请选择一个营期", function (res) {}, 'none');
                                    return _context2.abrupt("return", false);

                                case 3:
                                    _wepy2.default.navigateTo({
                                        url: "./sureOrder?type=" + ot + "&pid=" + this.courseInfo.periodList[this.courseInx].id + "&cid=" + this.courseInfo.id + "&num=" + this.num + "&aid=" + aid + "&actpid=" + this.courseInfo.pintuanId
                                    });

                                case 4:
                                case "end":
                                    return _context2.stop();
                            }
                        }
                    }, _callee2, this);
                }));

                function buy() {
                    return _ref4.apply(this, arguments);
                }

                return buy;
            }()
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(Dialog, [{
        key: "onShareAppMessage",

        // 转发暂时先不开启
        value: function onShareAppMessage(res) {
            if (res.from === 'button') {
                // 来自页面内转发按钮
                console.log(res.target);
            }
            return {
                title: this.courseInfo.courseTittle,
                path: '/pages/detaile/detaile?id=' + this.courseInfo.id
            };
        }
    }, {
        key: "onLoad",
        value: function () {
            var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(opt) {
                var _this2 = this;

                var view, _ref6, course, companions, statistics, CourseComment;

                return regeneratorRuntime.wrap(function _callee3$(_context3) {
                    while (1) {
                        switch (_context3.prev = _context3.next) {
                            case 0:
                                // 获取主内容高度，用于悬浮详情导航
                                view = wx.createSelectorQuery().select("#info-box");

                                view.fields({
                                    size: true
                                }, function (data) {
                                    console.log(data.height);
                                    _this2.mainHeight = data.height;
                                }).exec();
                                _context3.next = 4;
                                return _config2.default.getCourseInfo(opt.id);

                            case 4:
                                _ref6 = _context3.sent;
                                course = _ref6.course;
                                companions = _ref6.companions;
                                statistics = _ref6.statistics;
                                CourseComment = _ref6.CourseComment;

                                this.swipers.list[0].url = course.image;
                                course.courseChar = course.courseChar.split("|");
                                this.courseInfo = course;
                                _wepy2.default.$instance.globalData.courseInfo = course;
                                this.companions = companions;
                                this.statistics = statistics;
                                this.CourseComment = CourseComment;
                                console.log(this.courseInfo);
                                this.$apply();

                            case 18:
                            case "end":
                                return _context3.stop();
                        }
                    }
                }, _callee3, this);
            }));

            function onLoad(_x4) {
                return _ref5.apply(this, arguments);
            }

            return onLoad;
        }()
    }]);

    return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/detaile/detaile'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldGFpbGUuanMiXSwibmFtZXMiOlsiRGlhbG9nIiwiZGF0YSIsIlRhYkN1ciIsImNsb3NlIiwic3dpcGVycyIsInR5cGUiLCJsaXN0IiwiaWQiLCJ1cmwiLCJsaW5rIiwibGlua1R5cGUiLCJtYWluSGVpZ2h0IiwiY291cnNlSW5mbyIsIm5vZGVzIiwibnVtIiwic2hvd1NrdSIsImJ1eVR5cHQiLCJjb3Vyc2VJbngiLCJjb21wYW5pb25zIiwic3RhdGlzdGljcyIsIkNvdXJzZUNvbW1lbnQiLCJzaWduX3N0YXRlcyIsInRvUGludHVhbiIsIiRyZXBlYXQiLCIkcHJvcHMiLCIkZXZlbnRzIiwiY29tcG9uZW50cyIsImNTd2lwZXIiLCJjdGl0bGUiLCJjSW5mbyIsImNSZW1ha2UiLCJjb25maWciLCJuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0IiwibWV0aG9kcyIsInRvUGludHVhbmZ5IiwiYmFyZ2FpbiIsIlRpcHMiLCJ0b2FzdCIsInJlZ0JhcmdhaW4iLCJiYXJnYWluSWQiLCJjb3Vyc2VJZCIsInBlcmlvZElkIiwicGVyaW9kTGlzdCIsImVycmNvZGUiLCJlcnJtc2ciLCJ3ZXB5IiwicmVkaXJlY3RUbyIsInJlZ0lkIiwiYWN0QmFyZ2FpblJlZyIsInJldCIsInRhYlNlbGVjdCIsImUiLCJjb25zb2xlIiwibG9nIiwiY3VycmVudFRhcmdldCIsImRhdGFzZXQiLCJkZXRhaWwiLCJjdXJyZW50IiwiaGlkZU1vZGFsIiwic2t1IiwicGx1cyIsInd4IiwidmlicmF0ZVNob3J0IiwibWludXMiLCJjb3Vyc2UiLCJpbngiLCJidXkiLCJhaWQiLCJvdCIsIm5hdmlnYXRlVG8iLCJwaW50dWFuSWQiLCJyZXMiLCJmcm9tIiwidGFyZ2V0IiwidGl0bGUiLCJjb3Vyc2VUaXR0bGUiLCJwYXRoIiwib3B0IiwidmlldyIsImNyZWF0ZVNlbGVjdG9yUXVlcnkiLCJzZWxlY3QiLCJmaWVsZHMiLCJzaXplIiwiaGVpZ2h0IiwiZXhlYyIsImdldENvdXJzZUluZm8iLCJpbWFnZSIsImNvdXJzZUNoYXIiLCJzcGxpdCIsIiRpbnN0YW5jZSIsImdsb2JhbERhdGEiLCIkYXBwbHkiLCJwYWdlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFDSTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7Ozs7Ozs7Ozs7OztJQUNxQkEsTTs7Ozs7Ozs7Ozs7Ozs7MExBQ2pCQyxJLEdBQU87QUFDSEMsb0JBQVEsQ0FETDtBQUVIQyxtQkFBTywwQkFGSjtBQUdIQyxxQkFBUztBQUNMQyxzQkFBTSxDQUREO0FBRUxDLHNCQUFNLENBQUM7QUFDSEMsd0JBQUksQ0FERDtBQUVIRiwwQkFBTSxPQUZIO0FBR0hHLHlCQUFLLEVBSEY7QUFJSEMsMEJBQU0sa0JBSkg7QUFLSEMsOEJBQVU7QUFMUCxpQkFBRDtBQUZELGFBSE47QUFhSEMsd0JBQVksQ0FiVDtBQWNIQyx3QkFBWSxFQWRUO0FBZUhDLG1CQUFPLENBQUMsTUFBRCxFQUFTLE9BQVQsRUFBa0IsT0FBbEIsQ0FmSjtBQWdCSEMsaUJBQUssQ0FoQkY7QUFpQkhDLHFCQUFTLEtBakJOO0FBa0JIQyxxQkFBUyxRQWxCTjtBQW1CSEMsdUJBQVcsQ0FBQyxDQW5CVDtBQW9CSEMsd0JBQVksRUFwQlQ7QUFxQkhDLHdCQUFZLEVBckJUO0FBc0JIQywyQkFBZSxFQXRCWjtBQXVCSEMseUJBQWE7QUFDVCxtQkFBRyxPQURNO0FBRVQsbUJBQUcsTUFGTTtBQUdULG1CQUFHO0FBSE0sYUF2QlY7QUE0QkhDLHVCQUFXO0FBNUJSLFMsUUE4QlJDLE8sR0FBVSxFLFFBQ2pCQyxNLEdBQVMsRUFBQyxXQUFVLEVBQUMsZ0JBQWUsRUFBaEIsRUFBbUIscUJBQW9CLFNBQXZDLEVBQVgsRUFBNkQsVUFBUyxFQUFDLHFCQUFvQixZQUFyQixFQUF0RSxFQUF5RyxTQUFRLEVBQUMscUJBQW9CLFlBQXJCLEVBQWtDLDBCQUF5QixZQUEzRCxFQUFqSCxFQUEwTCxXQUFVLEVBQUMscUJBQW9CLFlBQXJCLEVBQWtDLDBCQUF5QixZQUEzRCxFQUF3RSw2QkFBNEIsZUFBcEcsRUFBcE0sRSxRQUNUQyxPLEdBQVUsRSxRQUNUQyxVLEdBQWE7QUFDRkMscUNBREU7QUFFRkMsbUNBRkU7QUFHRkMsaUNBSEU7QUFJRkM7QUFKRSxTLFFBTU5DLE0sR0FBUztBQUNMQyxvQ0FBd0I7QUFEbkIsUyxRQTJDVEMsTyxHQUFVO0FBQ05DLHVCQURNLHlCQUNRO0FBQ1YscUJBQUtaLFNBQUwsR0FBaUIsSUFBakI7QUFDSCxhQUhLO0FBSUFhLG1CQUpBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBDQUtFLEtBQUtsQixTQUFMLElBQWtCLENBQUMsQ0FMckI7QUFBQTtBQUFBO0FBQUE7O0FBTUVtQixtREFBS0MsS0FBTCxDQUFXLFNBQVgsRUFBc0IsZUFBTyxDQUFFLENBQS9CLEVBQWlDLE1BQWpDO0FBTkYscUVBT1MsS0FQVDs7QUFBQTtBQUFBO0FBQUEsMkNBYVFOLGlCQUFPTyxVQUFQLENBQWtCO0FBQ3hCQyxtREFBVyxLQUFLM0IsVUFBTCxDQUFnQjJCLFNBREg7QUFFeEJDLGtEQUFVLEtBQUs1QixVQUFMLENBQWdCTCxFQUZGO0FBR3hCa0Msa0RBQVUsS0FBSzdCLFVBQUwsQ0FBZ0I4QixVQUFoQixDQUEyQixLQUFLekIsU0FBaEMsRUFBMkNWO0FBSDdCLHFDQUFsQixDQWJSOztBQUFBO0FBQUE7QUFVRW9DLDJDQVZGLFNBVUVBLE9BVkY7QUFXRUMsMENBWEYsU0FXRUEsTUFYRjtBQVlFM0Msd0NBWkYsU0FZRUEsSUFaRjs7QUFrQkYsd0NBQUkwQyxXQUFXLEdBQWYsRUFBb0I7QUFDaEJFLHVEQUFLQyxVQUFMLENBQWdCO0FBQ1p0QyxpREFBSyxtQ0FBbUNQLEtBQUs4QztBQURqQyx5Q0FBaEI7QUFHSCxxQ0FKRCxNQUlPO0FBQ0g7QUFDQVgsdURBQUtDLEtBQUwsQ0FBV08sTUFBWCxFQUFtQixlQUFPO0FBQ3RCQywyREFBS0MsVUFBTCxDQUFnQjtBQUNadEMscURBQUssbUNBQW1DUCxLQUFLK0MsYUFBTCxDQUFtQnpDO0FBRC9DLDZDQUFoQjtBQUdILHlDQUpELEVBSUcsTUFKSDtBQUtIOztBQTdCQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQStCTjBDLGVBL0JNLGlCQStCQTtBQUNGLHVCQUFPLEtBQVA7QUFDSCxhQWpDSztBQWtDTkMscUJBbENNLHFCQWtDSUMsQ0FsQ0osRUFrQ087QUFDVEMsd0JBQVFDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNBLHFCQUFLakQsTUFBTCxHQUFjaUQsRUFBRUcsYUFBRixDQUFnQkMsT0FBaEIsQ0FBd0JoRCxFQUF4QixJQUE4QjRDLEVBQUVLLE1BQUYsQ0FBU0MsT0FBckQ7QUFDSCxhQXJDSztBQXNDTkMscUJBdENNLHVCQXNDTTtBQUNSLHFCQUFLcEMsU0FBTCxHQUFpQixLQUFqQjtBQUNBLHFCQUFLUCxPQUFMLEdBQWUsS0FBZjtBQUNILGFBekNLO0FBMENONEMsZUExQ00saUJBMENlO0FBQUEsb0JBQWpCdEQsSUFBaUIsdUVBQVYsUUFBVTs7QUFDakIscUJBQUtVLE9BQUwsR0FBZSxJQUFmO0FBQ0EscUJBQUtPLFNBQUwsR0FBaUIsS0FBakI7QUFDQSxxQkFBS04sT0FBTCxHQUFlWCxJQUFmO0FBQ0gsYUE5Q0s7QUErQ051RCxnQkEvQ00sa0JBK0NDO0FBQ0hDLG1CQUFHQyxZQUFIO0FBQ0EscUJBQUtoRCxHQUFMLEdBQVcsS0FBS0EsR0FBTCxHQUFXLENBQXRCO0FBQ0gsYUFsREs7QUFtRE5pRCxpQkFuRE0sbUJBbURFO0FBQ0osb0JBQUksS0FBS2pELEdBQUwsR0FBVyxDQUFmLEVBQWtCO0FBQ2QrQyx1QkFBR0MsWUFBSDtBQUNBLHlCQUFLaEQsR0FBTCxHQUFXLEtBQUtBLEdBQUwsR0FBVyxDQUF0QjtBQUNIO0FBQ0osYUF4REs7QUF5RE5rRCxrQkF6RE0sa0JBeURDQyxHQXpERCxFQXlETTtBQUNSLHFCQUFLaEQsU0FBTCxHQUFpQmdELEdBQWpCO0FBQ0gsYUEzREs7QUE0REFDLGVBNURBO0FBQUE7QUFBQSx3QkE0RElDLEdBNURKLHVFQTREVSxDQTVEVjtBQUFBLHdCQTREYUMsRUE1RGIsdUVBNERrQixDQTVEbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBDQTZERSxLQUFLbkQsU0FBTCxJQUFrQixDQUFDLENBN0RyQjtBQUFBO0FBQUE7QUFBQTs7QUE4REVtQixtREFBS0MsS0FBTCxDQUFXLFNBQVgsRUFBc0IsZUFBTyxDQUFFLENBQS9CLEVBQWlDLE1BQWpDO0FBOURGLHNFQStEUyxLQS9EVDs7QUFBQTtBQWlFRlEsbURBQUt3QixVQUFMLENBQWdCO0FBQ1o3RCxtRUFBeUI0RCxFQUF6QixhQUFtQyxLQUFLeEQsVUFBTCxDQUFnQjhCLFVBQWhCLENBQTJCLEtBQUt6QixTQUFoQyxFQUEyQ1YsRUFBOUUsYUFBd0YsS0FBS0ssVUFBTCxDQUFnQkwsRUFBeEcsYUFBa0gsS0FBS08sR0FBdkgsYUFBa0lxRCxHQUFsSSxnQkFBZ0osS0FBS3ZELFVBQUwsQ0FBZ0IwRDtBQURwSixxQ0FBaEI7O0FBakVFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUEsUzs7Ozs7O0FBeENWOzBDQUNrQkMsRyxFQUFLO0FBQ25CLGdCQUFJQSxJQUFJQyxJQUFKLEtBQWEsUUFBakIsRUFBMkI7QUFDdkI7QUFDQXBCLHdCQUFRQyxHQUFSLENBQVlrQixJQUFJRSxNQUFoQjtBQUNIO0FBQ0QsbUJBQU87QUFDSEMsdUJBQU8sS0FBSzlELFVBQUwsQ0FBZ0IrRCxZQURwQjtBQUVIQyxzQkFBTSwrQkFBK0IsS0FBS2hFLFVBQUwsQ0FBZ0JMO0FBRmxELGFBQVA7QUFJSDs7OztrR0FDWXNFLEc7Ozs7Ozs7OztBQUNUO0FBQ0lDLG9DLEdBQU9qQixHQUFHa0IsbUJBQUgsR0FBeUJDLE1BQXpCLENBQWdDLFdBQWhDLEM7O0FBQ1hGLHFDQUNLRyxNQURMLENBQ1k7QUFDQUMsMENBQU07QUFETixpQ0FEWixFQUlRLGdCQUFRO0FBQ0o5Qiw0Q0FBUUMsR0FBUixDQUFZcEQsS0FBS2tGLE1BQWpCO0FBQ0EsMkNBQUt4RSxVQUFMLEdBQWtCVixLQUFLa0YsTUFBdkI7QUFDSCxpQ0FQVCxFQVNLQyxJQVRMOzt1Q0FlVXJELGlCQUFPc0QsYUFBUCxDQUFxQlIsSUFBSXRFLEVBQXpCLEM7Ozs7QUFKTnlELHNDLFNBQUFBLE07QUFDQTlDLDBDLFNBQUFBLFU7QUFDQUMsMEMsU0FBQUEsVTtBQUNBQyw2QyxTQUFBQSxhOztBQUVKLHFDQUFLaEIsT0FBTCxDQUFhRSxJQUFiLENBQWtCLENBQWxCLEVBQXFCRSxHQUFyQixHQUEyQndELE9BQU9zQixLQUFsQztBQUNBdEIsdUNBQU91QixVQUFQLEdBQW9CdkIsT0FBT3VCLFVBQVAsQ0FBa0JDLEtBQWxCLENBQXdCLEdBQXhCLENBQXBCO0FBQ0EscUNBQUs1RSxVQUFMLEdBQWtCb0QsTUFBbEI7QUFDQW5CLCtDQUFLNEMsU0FBTCxDQUFlQyxVQUFmLENBQTBCOUUsVUFBMUIsR0FBdUNvRCxNQUF2QztBQUNBLHFDQUFLOUMsVUFBTCxHQUFrQkEsVUFBbEI7QUFDQSxxQ0FBS0MsVUFBTCxHQUFrQkEsVUFBbEI7QUFDQSxxQ0FBS0MsYUFBTCxHQUFxQkEsYUFBckI7QUFDQWdDLHdDQUFRQyxHQUFSLENBQVksS0FBS3pDLFVBQWpCO0FBQ0EscUNBQUsrRSxNQUFMOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBakY0QjlDLGVBQUsrQyxJOztrQkFBcEI1RixNIiwiZmlsZSI6ImRldGFpbGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuICAgIGltcG9ydCB3ZXB5IGZyb20gXCJ3ZXB5XCI7XHJcbiAgICBpbXBvcnQgY1N3aXBlciBmcm9tIFwiQC9jb21wb25lbnRzL2NvbW1vbi9zd2lwZXJcIjtcclxuICAgIGltcG9ydCBjdGl0bGUgZnJvbSBcIkAvY29tcG9uZW50cy9kZXRhaWxlL3RpdGxlXCI7XHJcbiAgICBpbXBvcnQgY0luZm8gZnJvbSBcIkAvY29tcG9uZW50cy9kZXRhaWxlL2luZm9cIjtcclxuICAgIGltcG9ydCBjUmVtYWtlIGZyb20gXCJAL2NvbXBvbmVudHMvZGV0YWlsZS9yZW1ha2VcIjtcclxuICAgIGltcG9ydCBjb25maWcgZnJvbSBcIkAvYXBpL2NvbmZpZ1wiO1xyXG4gICAgaW1wb3J0IFd4VXRpbHMgZnJvbSBcIkAvdXRpbHMvV3hVdGlsc1wiO1xyXG4gICAgaW1wb3J0IFRpcHMgZnJvbSBcIkAvdXRpbHMvVGlwc1wiO1xyXG4gICAgZXhwb3J0IGRlZmF1bHQgY2xhc3MgRGlhbG9nIGV4dGVuZHMgd2VweS5wYWdlIHtcclxuICAgICAgICBkYXRhID0ge1xyXG4gICAgICAgICAgICBUYWJDdXI6IDAsXHJcbiAgICAgICAgICAgIGNsb3NlOiBcIi9zdGF0aWMvaW1hZ2VzL2Nsb3NlLnBuZ1wiLFxyXG4gICAgICAgICAgICBzd2lwZXJzOiB7XHJcbiAgICAgICAgICAgICAgICB0eXBlOiAxLFxyXG4gICAgICAgICAgICAgICAgbGlzdDogW3tcclxuICAgICAgICAgICAgICAgICAgICBpZDogMCxcclxuICAgICAgICAgICAgICAgICAgICB0eXBlOiBcImltYWdlXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgdXJsOiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgICAgIGxpbms6IFwiL3BhZ2VzL21lZXQvbWVldFwiLFxyXG4gICAgICAgICAgICAgICAgICAgIGxpbmtUeXBlOiBcInN3aXRjaFRhYlwiXHJcbiAgICAgICAgICAgICAgICB9XVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBtYWluSGVpZ2h0OiAwLFxyXG4gICAgICAgICAgICBjb3Vyc2VJbmZvOiB7fSxcclxuICAgICAgICAgICAgbm9kZXM6IFtcIm5hbWVcIiwgXCJhdHRyc1wiLCBcImF0dHJzXCJdLFxyXG4gICAgICAgICAgICBudW06IDEsXHJcbiAgICAgICAgICAgIHNob3dTa3U6IGZhbHNlLFxyXG4gICAgICAgICAgICBidXlUeXB0OiAnbm9ybWFsJyxcclxuICAgICAgICAgICAgY291cnNlSW54OiAtMSxcclxuICAgICAgICAgICAgY29tcGFuaW9uczogW10sXHJcbiAgICAgICAgICAgIHN0YXRpc3RpY3M6IHt9LFxyXG4gICAgICAgICAgICBDb3Vyc2VDb21tZW50OiB7fSxcclxuICAgICAgICAgICAgc2lnbl9zdGF0ZXM6IHtcclxuICAgICAgICAgICAgICAgIDA6ICfngavng63mi5vnlJ/kuK0nLFxyXG4gICAgICAgICAgICAgICAgMTogJ+WwkemHj+WQjeminScsXHJcbiAgICAgICAgICAgICAgICAyOiAn5bey5ruh5ZGYJ1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB0b1BpbnR1YW46IGZhbHNlXHJcbiAgICAgICAgfTtcclxuICAgICAgICRyZXBlYXQgPSB7fTtcclxuJHByb3BzID0ge1wiY1N3aXBlclwiOntcInhtbG5zOnYtYmluZFwiOlwiXCIsXCJ2LWJpbmQ6bW9kZWwuc3luY1wiOlwic3dpcGVyc1wifSxcImN0aXRsZVwiOntcInYtYmluZDptb2RlbC5zeW5jXCI6XCJjb3Vyc2VJbmZvXCJ9LFwiY0luZm9cIjp7XCJ2LWJpbmQ6bW9kZWwuc3luY1wiOlwiY291cnNlSW5mb1wiLFwidi1iaW5kOmNvbXBhbmlvbnMuc3luY1wiOlwiY29tcGFuaW9uc1wifSxcImNSZW1ha2VcIjp7XCJ2LWJpbmQ6bW9kZWwuc3luY1wiOlwiY291cnNlSW5mb1wiLFwidi1iaW5kOnN0YXRpc3RpY3Muc3luY1wiOlwic3RhdGlzdGljc1wiLFwidi1iaW5kOkNvdXJzZUNvbW1lbnQuc3luY1wiOlwiQ291cnNlQ29tbWVudFwifX07XHJcbiRldmVudHMgPSB7fTtcclxuIGNvbXBvbmVudHMgPSB7XHJcbiAgICAgICAgICAgIGNTd2lwZXIsXHJcbiAgICAgICAgICAgIGN0aXRsZSxcclxuICAgICAgICAgICAgY0luZm8sXHJcbiAgICAgICAgICAgIGNSZW1ha2VcclxuICAgICAgICB9O1xyXG4gICAgICAgIGNvbmZpZyA9IHtcclxuICAgICAgICAgICAgbmF2aWdhdGlvbkJhclRpdGxlVGV4dDogXCLmtLvliqjor6bmg4VcIlxyXG4gICAgICAgIH07XHJcbiAgICAgICAgLy8g6L2s5Y+R5pqC5pe25YWI5LiN5byA5ZCvXHJcbiAgICAgICAgb25TaGFyZUFwcE1lc3NhZ2UocmVzKSB7XHJcbiAgICAgICAgICAgIGlmIChyZXMuZnJvbSA9PT0gJ2J1dHRvbicpIHtcclxuICAgICAgICAgICAgICAgIC8vIOadpeiHqumhtemdouWGhei9rOWPkeaMiemSrlxyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2cocmVzLnRhcmdldClcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgdGl0bGU6IHRoaXMuY291cnNlSW5mby5jb3Vyc2VUaXR0bGUsXHJcbiAgICAgICAgICAgICAgICBwYXRoOiAnL3BhZ2VzL2RldGFpbGUvZGV0YWlsZT9pZD0nICsgdGhpcy5jb3Vyc2VJbmZvLmlkXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgYXN5bmMgb25Mb2FkKG9wdCkge1xyXG4gICAgICAgICAgICAvLyDojrflj5bkuLvlhoXlrrnpq5jluqbvvIznlKjkuo7mgqzmta7or6bmg4Xlr7zoiKpcclxuICAgICAgICAgICAgbGV0IHZpZXcgPSB3eC5jcmVhdGVTZWxlY3RvclF1ZXJ5KCkuc2VsZWN0KFwiI2luZm8tYm94XCIpO1xyXG4gICAgICAgICAgICB2aWV3XHJcbiAgICAgICAgICAgICAgICAuZmllbGRzKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZTogdHJ1ZVxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgZGF0YSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGRhdGEuaGVpZ2h0KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5tYWluSGVpZ2h0ID0gZGF0YS5oZWlnaHQ7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgLmV4ZWMoKTtcclxuICAgICAgICAgICAgbGV0IHtcclxuICAgICAgICAgICAgICAgIGNvdXJzZSxcclxuICAgICAgICAgICAgICAgIGNvbXBhbmlvbnMsXHJcbiAgICAgICAgICAgICAgICBzdGF0aXN0aWNzLFxyXG4gICAgICAgICAgICAgICAgQ291cnNlQ29tbWVudFxyXG4gICAgICAgICAgICB9ID0gYXdhaXQgY29uZmlnLmdldENvdXJzZUluZm8ob3B0LmlkKVxyXG4gICAgICAgICAgICB0aGlzLnN3aXBlcnMubGlzdFswXS51cmwgPSBjb3Vyc2UuaW1hZ2VcclxuICAgICAgICAgICAgY291cnNlLmNvdXJzZUNoYXIgPSBjb3Vyc2UuY291cnNlQ2hhci5zcGxpdChcInxcIilcclxuICAgICAgICAgICAgdGhpcy5jb3Vyc2VJbmZvID0gY291cnNlXHJcbiAgICAgICAgICAgIHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuY291cnNlSW5mbyA9IGNvdXJzZVxyXG4gICAgICAgICAgICB0aGlzLmNvbXBhbmlvbnMgPSBjb21wYW5pb25zXHJcbiAgICAgICAgICAgIHRoaXMuc3RhdGlzdGljcyA9IHN0YXRpc3RpY3NcclxuICAgICAgICAgICAgdGhpcy5Db3Vyc2VDb21tZW50ID0gQ291cnNlQ29tbWVudFxyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyh0aGlzLmNvdXJzZUluZm8pXHJcbiAgICAgICAgICAgIHRoaXMuJGFwcGx5KCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIG1ldGhvZHMgPSB7XHJcbiAgICAgICAgICAgIHRvUGludHVhbmZ5KCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy50b1BpbnR1YW4gPSB0cnVlXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGFzeW5jIGJhcmdhaW4oKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5jb3Vyc2VJbnggPT0gLTEpIHtcclxuICAgICAgICAgICAgICAgICAgICBUaXBzLnRvYXN0KFwi6K+36YCJ5oup5LiA5Liq6JCl5pyfXCIsIHJlcyA9PiB7fSwgJ25vbmUnKVxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgbGV0IHtcclxuICAgICAgICAgICAgICAgICAgICBlcnJjb2RlLFxyXG4gICAgICAgICAgICAgICAgICAgIGVycm1zZyxcclxuICAgICAgICAgICAgICAgICAgICBkYXRhXHJcbiAgICAgICAgICAgICAgICB9ID0gYXdhaXQgY29uZmlnLnJlZ0JhcmdhaW4oe1xyXG4gICAgICAgICAgICAgICAgICAgIGJhcmdhaW5JZDogdGhpcy5jb3Vyc2VJbmZvLmJhcmdhaW5JZCxcclxuICAgICAgICAgICAgICAgICAgICBjb3Vyc2VJZDogdGhpcy5jb3Vyc2VJbmZvLmlkLFxyXG4gICAgICAgICAgICAgICAgICAgIHBlcmlvZElkOiB0aGlzLmNvdXJzZUluZm8ucGVyaW9kTGlzdFt0aGlzLmNvdXJzZUlueF0uaWQsXHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgaWYgKGVycmNvZGUgPT0gMjAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgd2VweS5yZWRpcmVjdFRvKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdXJsOiAnL3BhZ2VzL2FjdGl2aXR5L2JhcmdhaW4/cmVnSWQ9JyArIGRhdGEucmVnSWRcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8g5Y+R6LW356CN5Lu35byC5bi4XHJcbiAgICAgICAgICAgICAgICAgICAgVGlwcy50b2FzdChlcnJtc2csIHJlcyA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHdlcHkucmVkaXJlY3RUbyh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cmw6ICcvcGFnZXMvYWN0aXZpdHkvYmFyZ2Fpbj9yZWdJZD0nICsgZGF0YS5hY3RCYXJnYWluUmVnLmlkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIH0sICdub25lJylcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgcmV0KCkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHRhYlNlbGVjdChlKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuVGFiQ3VyID0gZS5jdXJyZW50VGFyZ2V0LmRhdGFzZXQuaWQgfHwgZS5kZXRhaWwuY3VycmVudDtcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgaGlkZU1vZGFsKCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy50b1BpbnR1YW4gPSBmYWxzZVxyXG4gICAgICAgICAgICAgICAgdGhpcy5zaG93U2t1ID0gZmFsc2VcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgc2t1KHR5cGUgPSAnbm9ybWFsJykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zaG93U2t1ID0gdHJ1ZVxyXG4gICAgICAgICAgICAgICAgdGhpcy50b1BpbnR1YW4gPSBmYWxzZVxyXG4gICAgICAgICAgICAgICAgdGhpcy5idXlUeXB0ID0gdHlwZVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBwbHVzKCkge1xyXG4gICAgICAgICAgICAgICAgd3gudmlicmF0ZVNob3J0KClcclxuICAgICAgICAgICAgICAgIHRoaXMubnVtID0gdGhpcy5udW0gKyAxXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIG1pbnVzKCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMubnVtID4gMSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHd4LnZpYnJhdGVTaG9ydCgpXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5udW0gPSB0aGlzLm51bSAtIDFcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgY291cnNlKGlueCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jb3Vyc2VJbnggPSBpbnhcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgYXN5bmMgYnV5KGFpZCA9IDAsIG90ID0gMSwpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmNvdXJzZUlueCA9PSAtMSkge1xyXG4gICAgICAgICAgICAgICAgICAgIFRpcHMudG9hc3QoXCLor7fpgInmi6nkuIDkuKrokKXmnJ9cIiwgcmVzID0+IHt9LCAnbm9uZScpXHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICAgICAgICAgIHVybDogYC4vc3VyZU9yZGVyP3R5cGU9JHtvdH0mcGlkPSR7dGhpcy5jb3Vyc2VJbmZvLnBlcmlvZExpc3RbdGhpcy5jb3Vyc2VJbnhdLmlkfSZjaWQ9JHt0aGlzLmNvdXJzZUluZm8uaWR9Jm51bT0ke3RoaXMubnVtfSZhaWQ9JHthaWR9JmFjdHBpZD0ke3RoaXMuY291cnNlSW5mby5waW50dWFuSWR9YFxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9O1xyXG4gICAgfVxyXG4iXX0=