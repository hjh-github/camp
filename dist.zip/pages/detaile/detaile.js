"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _swiper = require('./../../components/common/swiper.js');

var _swiper2 = _interopRequireDefault(_swiper);

var _title = require('./../../components/detaile/title.js');

var _title2 = _interopRequireDefault(_title);

var _info = require('./../../components/detaile/info.js');

var _info2 = _interopRequireDefault(_info);

var _remake = require('./../../components/detaile/remake.js');

var _remake2 = _interopRequireDefault(_remake);

var _contact = require('./../../components/common/contact.js');

var _contact2 = _interopRequireDefault(_contact);

var _utils = require('./../../store/utils.js');

var _utils2 = _interopRequireDefault(_utils);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

var _WxUtils = require('./../../utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
    _inherits(Dialog, _wepy$page);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.data = {
            TabCur: 0,
            close: "/static/images/close.png",
            swipers: {
                type: 1,
                list: [{
                    id: 0,
                    type: "image",
                    url: "",
                    link: "/pages/meet/meet",
                    linkType: "switchTab"
                }]
            },
            mainHeight: 0,
            courseInfo: {},
            nodes: ["name", "attrs", "attrs"],
            num: 1,
            showSku: false,
            buyTypt: 'normal',
            courseInx: -1,
            companions: [],
            statistics: {},
            CourseComment: {},
            ActPintuan: {},
            sign_states: {
                0: '火热招生中',
                1: '少量名额',
                2: '已满员'
            },
            toPintuan: false,
            modalName: '',
            customerService: {},
            member: {},
            paymentType: 1
        }, _this.$repeat = {}, _this.$props = { "cSwiper": { "xmlns:v-bind": "", "v-bind:model.sync": "swipers" }, "ctitle": { "v-bind:model.sync": "courseInfo" }, "cInfo": { "v-bind:model.sync": "courseInfo", "v-bind:companions.sync": "companions" }, "cRemake": { "v-bind:model.sync": "courseInfo", "v-bind:statistics.sync": "statistics", "v-bind:CourseComment.sync": "CourseComment" } }, _this.$events = {}, _this.components = {
            cSwiper: _swiper2.default,
            ctitle: _title2.default,
            cInfo: _info2.default,
            cRemake: _remake2.default,
            contact: _contact2.default
        }, _this.config = {
            navigationBarTitleText: "活动详情"
        }, _this.methods = {
            paymentType: function paymentType(type) {
                this.paymentType = type;
            },
            call: function call(phoneNumber) {
                wx.makePhoneCall({
                    phoneNumber: phoneNumber //仅为示例，并非真实的电话号码
                });
            },
            cont: function cont() {
                this.modalName = 'bottomModal';
            },
            tocut: function () {
                var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(e) {
                    return regeneratorRuntime.wrap(function _callee$(_context) {
                        while (1) {
                            switch (_context.prev = _context.next) {
                                case 0:
                                    if (!(e.detail.errMsg == "getUserInfo:ok")) {
                                        _context.next = 5;
                                        break;
                                    }

                                    _context.next = 3;
                                    return _auth2.default.getUserinfo(e.detail);

                                case 3:
                                    this.sku('bargain');
                                    this.$apply();

                                case 5:
                                case "end":
                                    return _context.stop();
                            }
                        }
                    }, _callee, this);
                }));

                function tocut(_x) {
                    return _ref2.apply(this, arguments);
                }

                return tocut;
            }(),
            createImg: function () {
                var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(e) {
                    return regeneratorRuntime.wrap(function _callee2$(_context2) {
                        while (1) {
                            switch (_context2.prev = _context2.next) {
                                case 0:
                                    if (!(e.detail.errMsg == "getUserInfo:ok")) {
                                        _context2.next = 5;
                                        break;
                                    }

                                    _context2.next = 3;
                                    return _auth2.default.getUserinfo(e.detail);

                                case 3:
                                    _utils2.default.save('shareInfo', {
                                        course: this.courseInfo,
                                        path: 'pages/detaile/detaile',
                                        id: this.courseInfo.id
                                    });
                                    _wepy2.default.navigateTo({
                                        url: '/pages/home/share'
                                    });

                                case 5:
                                case "end":
                                    return _context2.stop();
                            }
                        }
                    }, _callee2, this);
                }));

                function createImg(_x2) {
                    return _ref3.apply(this, arguments);
                }

                return createImg;
            }(),
            toshare: function toshare() {
                this.modalName = 'share';
            },
            toPintuanfy: function toPintuanfy() {
                this.toPintuan = true;
            },
            bargain: function () {
                var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
                    var _ref5, errcode, errmsg, data;

                    return regeneratorRuntime.wrap(function _callee3$(_context3) {
                        while (1) {
                            switch (_context3.prev = _context3.next) {
                                case 0:
                                    if (!(this.courseInx == -1)) {
                                        _context3.next = 3;
                                        break;
                                    }

                                    _Tips2.default.toast("请选择一个营期", function (res) {}, 'none');
                                    return _context3.abrupt("return", false);

                                case 3:
                                    _context3.next = 5;
                                    return _config2.default.regBargain({
                                        bargainId: this.courseInfo.bargainId,
                                        courseId: this.courseInfo.id,
                                        periodId: this.courseInfo.periodList[this.courseInx].id
                                    });

                                case 5:
                                    _ref5 = _context3.sent;
                                    errcode = _ref5.errcode;
                                    errmsg = _ref5.errmsg;
                                    data = _ref5.data;

                                    if (errcode == 200) {
                                        _wepy2.default.redirectTo({
                                            url: '/pages/activity/bargain?id=' + data.regId
                                        });
                                    } else {
                                        // 发起砍价异常
                                        _Tips2.default.toast(errmsg, function (res) {
                                            _wepy2.default.redirectTo({
                                                url: '/pages/activity/bargain?id=' + data.actBargainReg.id
                                            });
                                        }, 'none');
                                    }

                                case 10:
                                case "end":
                                    return _context3.stop();
                            }
                        }
                    }, _callee3, this);
                }));

                function bargain() {
                    return _ref4.apply(this, arguments);
                }

                return bargain;
            }(),
            ret: function ret() {
                return false;
            },
            tabSelect: function tabSelect(e) {
                console.log(e);
                this.TabCur = e.currentTarget.dataset.id || e.detail.current;
            },
            hideModal: function hideModal() {
                this.toPintuan = false;
                this.showSku = false;
                this.modalName = '';
            },
            sku: function sku(type) {
                this.sku(type);
            },
            plus: function plus() {
                if (this.buyTypt == 'bargain') {
                    return false;
                }
                wx.vibrateShort();
                this.num = this.num + 1;
            },
            minus: function minus() {
                if (this.num > 1) {
                    wx.vibrateShort();
                    this.num = this.num - 1;
                }
            },
            course: function course(inx) {
                this.courseInx = inx;
            },
            buy: function () {
                var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
                    var aid = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;
                    var ot = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1;
                    return regeneratorRuntime.wrap(function _callee4$(_context4) {
                        while (1) {
                            switch (_context4.prev = _context4.next) {
                                case 0:
                                    if (!(this.courseInx == -1)) {
                                        _context4.next = 3;
                                        break;
                                    }

                                    _Tips2.default.toast("请选择一个营期", function (res) {}, 'none');
                                    return _context4.abrupt("return", false);

                                case 3:
                                    // if(ot == 2){
                                    //     // 砍价
                                    //     aid = this.courseInfo.bargainId
                                    // }
                                    // if(ot == 3){
                                    //     // 拼团
                                    //     aid = this.courseInfo.pintuanId
                                    // }
                                    _wepy2.default.navigateTo({
                                        url: "./sureOrder?type=" + ot + "&pid=" + this.courseInfo.periodList[this.courseInx].id + "&cid=" + this.courseInfo.id + "&num=" + this.num + "&aid=" + aid + "&actpid=" + this.courseInfo.pintuanId + "&pt=" + this.paymentType
                                    });

                                case 4:
                                case "end":
                                    return _context4.stop();
                            }
                        }
                    }, _callee4, this);
                }));

                function buy() {
                    return _ref6.apply(this, arguments);
                }

                return buy;
            }()
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(Dialog, [{
        key: "onShareAppMessage",

        // 转发暂时先不开启
        value: function onShareAppMessage(res) {
            if (res.from === 'button') {
                // 来自页面内转发按钮
                console.log(res.target);
            }
            return {
                title: this.courseInfo.courseTittle,
                path: '/pages/detaile/detaile?id=' + this.courseInfo.id + '&agentId=' + this.member.agentId
            };
        }
    }, {
        key: "onLoad",
        value: function () {
            var _ref7 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5(opt) {
                var _this2 = this;

                var view, _ref8, course, companions, statistics, CourseComment, actPintuan, customerService;

                return regeneratorRuntime.wrap(function _callee5$(_context5) {
                    while (1) {
                        switch (_context5.prev = _context5.next) {
                            case 0:
                                console.log(opt);
                                // 获取主内容高度，用于悬浮详情导航
                                view = wx.createSelectorQuery().select("#info-box");

                                view.fields({
                                    size: true
                                }, function (data) {
                                    console.log(data.height);
                                    _this2.mainHeight = data.height;
                                }).exec();
                                _context5.next = 5;
                                return _auth2.default.login();

                            case 5:
                                this.member = _wepy2.default.getStorageSync('member');
                                _context5.next = 8;
                                return _config2.default.getCourseInfo(opt.id || opt.scene);

                            case 8:
                                _ref8 = _context5.sent;
                                course = _ref8.course;
                                companions = _ref8.companions;
                                statistics = _ref8.statistics;
                                CourseComment = _ref8.CourseComment;
                                actPintuan = _ref8.actPintuan;
                                customerService = _ref8.customerService;

                                this.swipers.list = course.pics;
                                course.courseChar = course.courseChar.split("|");
                                this.courseInfo = course;
                                this.customerService = customerService;
                                _wepy2.default.$instance.globalData.courseInfo = course;
                                this.companions = companions;
                                this.statistics = statistics;
                                this.CourseComment = CourseComment;
                                this.ActPintuan = actPintuan;
                                console.log(this.ActPintuan);
                                this.$apply();

                            case 26:
                            case "end":
                                return _context5.stop();
                        }
                    }
                }, _callee5, this);
            }));

            function onLoad(_x5) {
                return _ref7.apply(this, arguments);
            }

            return onLoad;
        }()
    }, {
        key: "sku",
        value: function sku() {
            var type = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'normal';

            this.showSku = true;
            this.toPintuan = false;
            this.buyTypt = type;
        }
    }]);

    return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/detaile/detaile'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldGFpbGUuanMiXSwibmFtZXMiOlsiRGlhbG9nIiwiZGF0YSIsIlRhYkN1ciIsImNsb3NlIiwic3dpcGVycyIsInR5cGUiLCJsaXN0IiwiaWQiLCJ1cmwiLCJsaW5rIiwibGlua1R5cGUiLCJtYWluSGVpZ2h0IiwiY291cnNlSW5mbyIsIm5vZGVzIiwibnVtIiwic2hvd1NrdSIsImJ1eVR5cHQiLCJjb3Vyc2VJbngiLCJjb21wYW5pb25zIiwic3RhdGlzdGljcyIsIkNvdXJzZUNvbW1lbnQiLCJBY3RQaW50dWFuIiwic2lnbl9zdGF0ZXMiLCJ0b1BpbnR1YW4iLCJtb2RhbE5hbWUiLCJjdXN0b21lclNlcnZpY2UiLCJtZW1iZXIiLCJwYXltZW50VHlwZSIsIiRyZXBlYXQiLCIkcHJvcHMiLCIkZXZlbnRzIiwiY29tcG9uZW50cyIsImNTd2lwZXIiLCJjdGl0bGUiLCJjSW5mbyIsImNSZW1ha2UiLCJjb250YWN0IiwiY29uZmlnIiwibmF2aWdhdGlvbkJhclRpdGxlVGV4dCIsIm1ldGhvZHMiLCJjYWxsIiwicGhvbmVOdW1iZXIiLCJ3eCIsIm1ha2VQaG9uZUNhbGwiLCJjb250IiwidG9jdXQiLCJlIiwiZGV0YWlsIiwiZXJyTXNnIiwiYXV0aCIsImdldFVzZXJpbmZvIiwic2t1IiwiJGFwcGx5IiwiY3JlYXRlSW1nIiwic3RvcmUiLCJzYXZlIiwiY291cnNlIiwicGF0aCIsIndlcHkiLCJuYXZpZ2F0ZVRvIiwidG9zaGFyZSIsInRvUGludHVhbmZ5IiwiYmFyZ2FpbiIsIlRpcHMiLCJ0b2FzdCIsInJlZ0JhcmdhaW4iLCJiYXJnYWluSWQiLCJjb3Vyc2VJZCIsInBlcmlvZElkIiwicGVyaW9kTGlzdCIsImVycmNvZGUiLCJlcnJtc2ciLCJyZWRpcmVjdFRvIiwicmVnSWQiLCJhY3RCYXJnYWluUmVnIiwicmV0IiwidGFiU2VsZWN0IiwiY29uc29sZSIsImxvZyIsImN1cnJlbnRUYXJnZXQiLCJkYXRhc2V0IiwiY3VycmVudCIsImhpZGVNb2RhbCIsInBsdXMiLCJ2aWJyYXRlU2hvcnQiLCJtaW51cyIsImlueCIsImJ1eSIsImFpZCIsIm90IiwicGludHVhbklkIiwicmVzIiwiZnJvbSIsInRhcmdldCIsInRpdGxlIiwiY291cnNlVGl0dGxlIiwiYWdlbnRJZCIsIm9wdCIsInZpZXciLCJjcmVhdGVTZWxlY3RvclF1ZXJ5Iiwic2VsZWN0IiwiZmllbGRzIiwic2l6ZSIsImhlaWdodCIsImV4ZWMiLCJsb2dpbiIsImdldFN0b3JhZ2VTeW5jIiwiZ2V0Q291cnNlSW5mbyIsInNjZW5lIiwiYWN0UGludHVhbiIsInBpY3MiLCJjb3Vyc2VDaGFyIiwic3BsaXQiLCIkaW5zdGFuY2UiLCJnbG9iYWxEYXRhIiwicGFnZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQ0k7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7Ozs7Ozs7Ozs7Ozs7SUFDcUJBLE07Ozs7Ozs7Ozs7Ozs7OzBMQUNqQkMsSSxHQUFPO0FBQ0hDLG9CQUFRLENBREw7QUFFSEMsbUJBQU8sMEJBRko7QUFHSEMscUJBQVM7QUFDTEMsc0JBQU0sQ0FERDtBQUVMQyxzQkFBTSxDQUFDO0FBQ0hDLHdCQUFJLENBREQ7QUFFSEYsMEJBQU0sT0FGSDtBQUdIRyx5QkFBSyxFQUhGO0FBSUhDLDBCQUFNLGtCQUpIO0FBS0hDLDhCQUFVO0FBTFAsaUJBQUQ7QUFGRCxhQUhOO0FBYUhDLHdCQUFZLENBYlQ7QUFjSEMsd0JBQVksRUFkVDtBQWVIQyxtQkFBTyxDQUFDLE1BQUQsRUFBUyxPQUFULEVBQWtCLE9BQWxCLENBZko7QUFnQkhDLGlCQUFLLENBaEJGO0FBaUJIQyxxQkFBUyxLQWpCTjtBQWtCSEMscUJBQVMsUUFsQk47QUFtQkhDLHVCQUFXLENBQUMsQ0FuQlQ7QUFvQkhDLHdCQUFZLEVBcEJUO0FBcUJIQyx3QkFBWSxFQXJCVDtBQXNCSEMsMkJBQWUsRUF0Qlo7QUF1QkhDLHdCQUFZLEVBdkJUO0FBd0JIQyx5QkFBYTtBQUNULG1CQUFHLE9BRE07QUFFVCxtQkFBRyxNQUZNO0FBR1QsbUJBQUc7QUFITSxhQXhCVjtBQTZCSEMsdUJBQVcsS0E3QlI7QUE4QkhDLHVCQUFXLEVBOUJSO0FBK0JIQyw2QkFBaUIsRUEvQmQ7QUFnQ0hDLG9CQUFRLEVBaENMO0FBaUNIQyx5QkFBYTtBQWpDVixTLFFBbUNSQyxPLEdBQVUsRSxRQUNqQkMsTSxHQUFTLEVBQUMsV0FBVSxFQUFDLGdCQUFlLEVBQWhCLEVBQW1CLHFCQUFvQixTQUF2QyxFQUFYLEVBQTZELFVBQVMsRUFBQyxxQkFBb0IsWUFBckIsRUFBdEUsRUFBeUcsU0FBUSxFQUFDLHFCQUFvQixZQUFyQixFQUFrQywwQkFBeUIsWUFBM0QsRUFBakgsRUFBMEwsV0FBVSxFQUFDLHFCQUFvQixZQUFyQixFQUFrQywwQkFBeUIsWUFBM0QsRUFBd0UsNkJBQTRCLGVBQXBHLEVBQXBNLEUsUUFDVEMsTyxHQUFVLEUsUUFDVEMsVSxHQUFhO0FBQ0ZDLHFDQURFO0FBRUZDLG1DQUZFO0FBR0ZDLGlDQUhFO0FBSUZDLHFDQUpFO0FBS0ZDO0FBTEUsUyxRQU9OQyxNLEdBQVM7QUFDTEMsb0NBQXdCO0FBRG5CLFMsUUF1RFRDLE8sR0FBVTtBQUNOWix1QkFETSx1QkFDTXRCLElBRE4sRUFDWTtBQUNkLHFCQUFLc0IsV0FBTCxHQUFtQnRCLElBQW5CO0FBQ0gsYUFISztBQUlObUMsZ0JBSk0sZ0JBSURDLFdBSkMsRUFJWTtBQUNkQyxtQkFBR0MsYUFBSCxDQUFpQjtBQUNiRiw0Q0FEYSxDQUNEO0FBREMsaUJBQWpCO0FBR0gsYUFSSztBQVNORyxnQkFUTSxrQkFTQztBQUNILHFCQUFLcEIsU0FBTCxHQUFpQixhQUFqQjtBQUNILGFBWEs7QUFZQXFCLGlCQVpBO0FBQUEscUdBWU1DLENBWk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBDQWFFQSxFQUFFQyxNQUFGLENBQVNDLE1BQVQsSUFBbUIsZ0JBYnJCO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUEsMkNBY1FDLGVBQUtDLFdBQUwsQ0FBaUJKLEVBQUVDLE1BQW5CLENBZFI7O0FBQUE7QUFlRSx5Q0FBS0ksR0FBTCxDQUFTLFNBQVQ7QUFDQSx5Q0FBS0MsTUFBTDs7QUFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFtQkFDLHFCQW5CQTtBQUFBLHNHQW1CVVAsQ0FuQlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBDQW9CRUEsRUFBRUMsTUFBRixDQUFTQyxNQUFULElBQW1CLGdCQXBCckI7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQSwyQ0FxQlFDLGVBQUtDLFdBQUwsQ0FBaUJKLEVBQUVDLE1BQW5CLENBckJSOztBQUFBO0FBc0JFTyxvREFBTUMsSUFBTixDQUFXLFdBQVgsRUFBd0I7QUFDcEJDLGdEQUFRLEtBQUs1QyxVQURPO0FBRXBCNkMsOENBQU0sdUJBRmM7QUFHcEJsRCw0Q0FBSSxLQUFLSyxVQUFMLENBQWdCTDtBQUhBLHFDQUF4QjtBQUtBbUQsbURBQUtDLFVBQUwsQ0FBZ0I7QUFDWm5ELDZDQUFLO0FBRE8scUNBQWhCOztBQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQWdDTm9ELG1CQWhDTSxxQkFnQ0k7QUFDTixxQkFBS3BDLFNBQUwsR0FBaUIsT0FBakI7QUFDSCxhQWxDSztBQW1DTnFDLHVCQW5DTSx5QkFtQ1E7QUFDVixxQkFBS3RDLFNBQUwsR0FBaUIsSUFBakI7QUFDSCxhQXJDSztBQXNDQXVDLG1CQXRDQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQ0F1Q0UsS0FBSzdDLFNBQUwsSUFBa0IsQ0FBQyxDQXZDckI7QUFBQTtBQUFBO0FBQUE7O0FBd0NFOEMsbURBQUtDLEtBQUwsQ0FBVyxTQUFYLEVBQXNCLGVBQU8sQ0FBRSxDQUEvQixFQUFpQyxNQUFqQztBQXhDRixzRUF5Q1MsS0F6Q1Q7O0FBQUE7QUFBQTtBQUFBLDJDQStDUTNCLGlCQUFPNEIsVUFBUCxDQUFrQjtBQUN4QkMsbURBQVcsS0FBS3RELFVBQUwsQ0FBZ0JzRCxTQURIO0FBRXhCQyxrREFBVSxLQUFLdkQsVUFBTCxDQUFnQkwsRUFGRjtBQUd4QjZELGtEQUFVLEtBQUt4RCxVQUFMLENBQWdCeUQsVUFBaEIsQ0FBMkIsS0FBS3BELFNBQWhDLEVBQTJDVjtBQUg3QixxQ0FBbEIsQ0EvQ1I7O0FBQUE7QUFBQTtBQTRDRStELDJDQTVDRixTQTRDRUEsT0E1Q0Y7QUE2Q0VDLDBDQTdDRixTQTZDRUEsTUE3Q0Y7QUE4Q0V0RSx3Q0E5Q0YsU0E4Q0VBLElBOUNGOztBQW9ERix3Q0FBSXFFLFdBQVcsR0FBZixFQUFvQjtBQUNoQlosdURBQUtjLFVBQUwsQ0FBZ0I7QUFDWmhFLGlEQUFLLGdDQUFnQ1AsS0FBS3dFO0FBRDlCLHlDQUFoQjtBQUdILHFDQUpELE1BSU87QUFDSDtBQUNBVix1REFBS0MsS0FBTCxDQUFXTyxNQUFYLEVBQW1CLGVBQU87QUFDdEJiLDJEQUFLYyxVQUFMLENBQWdCO0FBQ1poRSxxREFBSyxnQ0FBZ0NQLEtBQUt5RSxhQUFMLENBQW1CbkU7QUFENUMsNkNBQWhCO0FBR0gseUNBSkQsRUFJRyxNQUpIO0FBS0g7O0FBL0RDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBaUVOb0UsZUFqRU0saUJBaUVBO0FBQ0YsdUJBQU8sS0FBUDtBQUNILGFBbkVLO0FBb0VOQyxxQkFwRU0scUJBb0VJOUIsQ0FwRUosRUFvRU87QUFDVCtCLHdCQUFRQyxHQUFSLENBQVloQyxDQUFaO0FBQ0EscUJBQUs1QyxNQUFMLEdBQWM0QyxFQUFFaUMsYUFBRixDQUFnQkMsT0FBaEIsQ0FBd0J6RSxFQUF4QixJQUE4QnVDLEVBQUVDLE1BQUYsQ0FBU2tDLE9BQXJEO0FBQ0gsYUF2RUs7QUF3RU5DLHFCQXhFTSx1QkF3RU07QUFDUixxQkFBSzNELFNBQUwsR0FBaUIsS0FBakI7QUFDQSxxQkFBS1IsT0FBTCxHQUFlLEtBQWY7QUFDQSxxQkFBS1MsU0FBTCxHQUFpQixFQUFqQjtBQUNILGFBNUVLO0FBNkVOMkIsZUE3RU0sZUE2RUY5QyxJQTdFRSxFQTZFSTtBQUNOLHFCQUFLOEMsR0FBTCxDQUFTOUMsSUFBVDtBQUNILGFBL0VLO0FBZ0ZOOEUsZ0JBaEZNLGtCQWdGQztBQUNILG9CQUFJLEtBQUtuRSxPQUFMLElBQWdCLFNBQXBCLEVBQStCO0FBQzNCLDJCQUFPLEtBQVA7QUFDSDtBQUNEMEIsbUJBQUcwQyxZQUFIO0FBQ0EscUJBQUt0RSxHQUFMLEdBQVcsS0FBS0EsR0FBTCxHQUFXLENBQXRCO0FBQ0gsYUF0Rks7QUF1Rk51RSxpQkF2Rk0sbUJBdUZFO0FBQ0osb0JBQUksS0FBS3ZFLEdBQUwsR0FBVyxDQUFmLEVBQWtCO0FBQ2Q0Qix1QkFBRzBDLFlBQUg7QUFDQSx5QkFBS3RFLEdBQUwsR0FBVyxLQUFLQSxHQUFMLEdBQVcsQ0FBdEI7QUFDSDtBQUNKLGFBNUZLO0FBNkZOMEMsa0JBN0ZNLGtCQTZGQzhCLEdBN0ZELEVBNkZNO0FBQ1IscUJBQUtyRSxTQUFMLEdBQWlCcUUsR0FBakI7QUFDSCxhQS9GSztBQWdHQUMsZUFoR0E7QUFBQTtBQUFBLHdCQWdHSUMsR0FoR0osdUVBZ0dVLENBaEdWO0FBQUEsd0JBZ0dhQyxFQWhHYix1RUFnR2tCLENBaEdsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMENBaUdFLEtBQUt4RSxTQUFMLElBQWtCLENBQUMsQ0FqR3JCO0FBQUE7QUFBQTtBQUFBOztBQWtHRThDLG1EQUFLQyxLQUFMLENBQVcsU0FBWCxFQUFzQixlQUFPLENBQUUsQ0FBL0IsRUFBaUMsTUFBakM7QUFsR0Ysc0VBbUdTLEtBbkdUOztBQUFBO0FBcUdGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQU4sbURBQUtDLFVBQUwsQ0FBZ0I7QUFDWm5ELG1FQUF5QmlGLEVBQXpCLGFBQW1DLEtBQUs3RSxVQUFMLENBQWdCeUQsVUFBaEIsQ0FBMkIsS0FBS3BELFNBQWhDLEVBQTJDVixFQUE5RSxhQUF3RixLQUFLSyxVQUFMLENBQWdCTCxFQUF4RyxhQUFrSCxLQUFLTyxHQUF2SCxhQUFrSTBFLEdBQWxJLGdCQUFnSixLQUFLNUUsVUFBTCxDQUFnQjhFLFNBQWhLLFlBQWdMLEtBQUsvRDtBQUR6SyxxQ0FBaEI7O0FBN0dFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUEsUzs7Ozs7O0FBcERWOzBDQUNrQmdFLEcsRUFBSztBQUNuQixnQkFBSUEsSUFBSUMsSUFBSixLQUFhLFFBQWpCLEVBQTJCO0FBQ3ZCO0FBQ0FmLHdCQUFRQyxHQUFSLENBQVlhLElBQUlFLE1BQWhCO0FBQ0g7QUFDRCxtQkFBTztBQUNIQyx1QkFBTyxLQUFLbEYsVUFBTCxDQUFnQm1GLFlBRHBCO0FBRUh0QyxzQkFBTSwrQkFBK0IsS0FBSzdDLFVBQUwsQ0FBZ0JMLEVBQS9DLEdBQW9ELFdBQXBELEdBQWtFLEtBQUttQixNQUFMLENBQVlzRTtBQUZqRixhQUFQO0FBSUg7Ozs7a0dBQ1lDLEc7Ozs7Ozs7OztBQUNUcEIsd0NBQVFDLEdBQVIsQ0FBWW1CLEdBQVo7QUFDQTtBQUNJQyxvQyxHQUFPeEQsR0FBR3lELG1CQUFILEdBQXlCQyxNQUF6QixDQUFnQyxXQUFoQyxDOztBQUNYRixxQ0FDS0csTUFETCxDQUNZO0FBQ0FDLDBDQUFNO0FBRE4saUNBRFosRUFJUSxnQkFBUTtBQUNKekIsNENBQVFDLEdBQVIsQ0FBWTdFLEtBQUtzRyxNQUFqQjtBQUNBLDJDQUFLNUYsVUFBTCxHQUFrQlYsS0FBS3NHLE1BQXZCO0FBQ0gsaUNBUFQsRUFTS0MsSUFUTDs7dUNBVU12RCxlQUFLd0QsS0FBTCxFOzs7QUFDTixxQ0FBSy9FLE1BQUwsR0FBY2dDLGVBQUtnRCxjQUFMLENBQW9CLFFBQXBCLENBQWQ7O3VDQVFVckUsaUJBQU9zRSxhQUFQLENBQXFCVixJQUFJMUYsRUFBSixJQUFVMEYsSUFBSVcsS0FBbkMsQzs7OztBQU5OcEQsc0MsU0FBQUEsTTtBQUNBdEMsMEMsU0FBQUEsVTtBQUNBQywwQyxTQUFBQSxVO0FBQ0FDLDZDLFNBQUFBLGE7QUFDQXlGLDBDLFNBQUFBLFU7QUFDQXBGLCtDLFNBQUFBLGU7O0FBRUoscUNBQUtyQixPQUFMLENBQWFFLElBQWIsR0FBb0JrRCxPQUFPc0QsSUFBM0I7QUFDQXRELHVDQUFPdUQsVUFBUCxHQUFvQnZELE9BQU91RCxVQUFQLENBQWtCQyxLQUFsQixDQUF3QixHQUF4QixDQUFwQjtBQUNBLHFDQUFLcEcsVUFBTCxHQUFrQjRDLE1BQWxCO0FBQ0EscUNBQUsvQixlQUFMLEdBQXVCQSxlQUF2QjtBQUNBaUMsK0NBQUt1RCxTQUFMLENBQWVDLFVBQWYsQ0FBMEJ0RyxVQUExQixHQUF1QzRDLE1BQXZDO0FBQ0EscUNBQUt0QyxVQUFMLEdBQWtCQSxVQUFsQjtBQUNBLHFDQUFLQyxVQUFMLEdBQWtCQSxVQUFsQjtBQUNBLHFDQUFLQyxhQUFMLEdBQXFCQSxhQUFyQjtBQUNBLHFDQUFLQyxVQUFMLEdBQWtCd0YsVUFBbEI7QUFDQWhDLHdDQUFRQyxHQUFSLENBQVksS0FBS3pELFVBQWpCO0FBQ0EscUNBQUsrQixNQUFMOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OEJBRWlCO0FBQUEsZ0JBQWpCL0MsSUFBaUIsdUVBQVYsUUFBVTs7QUFDakIsaUJBQUtVLE9BQUwsR0FBZSxJQUFmO0FBQ0EsaUJBQUtRLFNBQUwsR0FBaUIsS0FBakI7QUFDQSxpQkFBS1AsT0FBTCxHQUFlWCxJQUFmO0FBQ0g7Ozs7RUFwRytCcUQsZUFBS3lELEk7O2tCQUFwQm5ILE0iLCJmaWxlIjoiZGV0YWlsZS5qcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4gICAgaW1wb3J0IHdlcHkgZnJvbSBcIndlcHlcIjtcclxuICAgIGltcG9ydCBjU3dpcGVyIGZyb20gXCJAL2NvbXBvbmVudHMvY29tbW9uL3N3aXBlclwiO1xyXG4gICAgaW1wb3J0IGN0aXRsZSBmcm9tIFwiQC9jb21wb25lbnRzL2RldGFpbGUvdGl0bGVcIjtcclxuICAgIGltcG9ydCBjSW5mbyBmcm9tIFwiQC9jb21wb25lbnRzL2RldGFpbGUvaW5mb1wiO1xyXG4gICAgaW1wb3J0IGNSZW1ha2UgZnJvbSBcIkAvY29tcG9uZW50cy9kZXRhaWxlL3JlbWFrZVwiO1xyXG4gICAgaW1wb3J0IGNvbnRhY3QgZnJvbSBcIkAvY29tcG9uZW50cy9jb21tb24vY29udGFjdFwiXHJcbiAgICBpbXBvcnQgc3RvcmUgZnJvbSBcIkAvc3RvcmUvdXRpbHNcIlxyXG4gICAgaW1wb3J0IGNvbmZpZyBmcm9tIFwiQC9hcGkvY29uZmlnXCI7XHJcbiAgICBpbXBvcnQgYXV0aCBmcm9tIFwiQC9hcGkvYXV0aFwiO1xyXG4gICAgaW1wb3J0IFd4VXRpbHMgZnJvbSBcIkAvdXRpbHMvV3hVdGlsc1wiO1xyXG4gICAgaW1wb3J0IFRpcHMgZnJvbSBcIkAvdXRpbHMvVGlwc1wiO1xyXG4gICAgZXhwb3J0IGRlZmF1bHQgY2xhc3MgRGlhbG9nIGV4dGVuZHMgd2VweS5wYWdlIHtcclxuICAgICAgICBkYXRhID0ge1xyXG4gICAgICAgICAgICBUYWJDdXI6IDAsXHJcbiAgICAgICAgICAgIGNsb3NlOiBcIi9zdGF0aWMvaW1hZ2VzL2Nsb3NlLnBuZ1wiLFxyXG4gICAgICAgICAgICBzd2lwZXJzOiB7XHJcbiAgICAgICAgICAgICAgICB0eXBlOiAxLFxyXG4gICAgICAgICAgICAgICAgbGlzdDogW3tcclxuICAgICAgICAgICAgICAgICAgICBpZDogMCxcclxuICAgICAgICAgICAgICAgICAgICB0eXBlOiBcImltYWdlXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgdXJsOiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgICAgIGxpbms6IFwiL3BhZ2VzL21lZXQvbWVldFwiLFxyXG4gICAgICAgICAgICAgICAgICAgIGxpbmtUeXBlOiBcInN3aXRjaFRhYlwiXHJcbiAgICAgICAgICAgICAgICB9XVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBtYWluSGVpZ2h0OiAwLFxyXG4gICAgICAgICAgICBjb3Vyc2VJbmZvOiB7fSxcclxuICAgICAgICAgICAgbm9kZXM6IFtcIm5hbWVcIiwgXCJhdHRyc1wiLCBcImF0dHJzXCJdLFxyXG4gICAgICAgICAgICBudW06IDEsXHJcbiAgICAgICAgICAgIHNob3dTa3U6IGZhbHNlLFxyXG4gICAgICAgICAgICBidXlUeXB0OiAnbm9ybWFsJyxcclxuICAgICAgICAgICAgY291cnNlSW54OiAtMSxcclxuICAgICAgICAgICAgY29tcGFuaW9uczogW10sXHJcbiAgICAgICAgICAgIHN0YXRpc3RpY3M6IHt9LFxyXG4gICAgICAgICAgICBDb3Vyc2VDb21tZW50OiB7fSxcclxuICAgICAgICAgICAgQWN0UGludHVhbjoge30sXHJcbiAgICAgICAgICAgIHNpZ25fc3RhdGVzOiB7XHJcbiAgICAgICAgICAgICAgICAwOiAn54Gr54Ot5oub55Sf5LitJyxcclxuICAgICAgICAgICAgICAgIDE6ICflsJHph4/lkI3pop0nLFxyXG4gICAgICAgICAgICAgICAgMjogJ+W3sua7oeWRmCdcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgdG9QaW50dWFuOiBmYWxzZSxcclxuICAgICAgICAgICAgbW9kYWxOYW1lOiAnJyxcclxuICAgICAgICAgICAgY3VzdG9tZXJTZXJ2aWNlOiB7fSxcclxuICAgICAgICAgICAgbWVtYmVyOiB7fSxcclxuICAgICAgICAgICAgcGF5bWVudFR5cGU6IDFcclxuICAgICAgICB9O1xyXG4gICAgICAgJHJlcGVhdCA9IHt9O1xyXG4kcHJvcHMgPSB7XCJjU3dpcGVyXCI6e1wieG1sbnM6di1iaW5kXCI6XCJcIixcInYtYmluZDptb2RlbC5zeW5jXCI6XCJzd2lwZXJzXCJ9LFwiY3RpdGxlXCI6e1widi1iaW5kOm1vZGVsLnN5bmNcIjpcImNvdXJzZUluZm9cIn0sXCJjSW5mb1wiOntcInYtYmluZDptb2RlbC5zeW5jXCI6XCJjb3Vyc2VJbmZvXCIsXCJ2LWJpbmQ6Y29tcGFuaW9ucy5zeW5jXCI6XCJjb21wYW5pb25zXCJ9LFwiY1JlbWFrZVwiOntcInYtYmluZDptb2RlbC5zeW5jXCI6XCJjb3Vyc2VJbmZvXCIsXCJ2LWJpbmQ6c3RhdGlzdGljcy5zeW5jXCI6XCJzdGF0aXN0aWNzXCIsXCJ2LWJpbmQ6Q291cnNlQ29tbWVudC5zeW5jXCI6XCJDb3Vyc2VDb21tZW50XCJ9fTtcclxuJGV2ZW50cyA9IHt9O1xyXG4gY29tcG9uZW50cyA9IHtcclxuICAgICAgICAgICAgY1N3aXBlcixcclxuICAgICAgICAgICAgY3RpdGxlLFxyXG4gICAgICAgICAgICBjSW5mbyxcclxuICAgICAgICAgICAgY1JlbWFrZSxcclxuICAgICAgICAgICAgY29udGFjdFxyXG4gICAgICAgIH07XHJcbiAgICAgICAgY29uZmlnID0ge1xyXG4gICAgICAgICAgICBuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0OiBcIua0u+WKqOivpuaDhVwiXHJcbiAgICAgICAgfTtcclxuICAgICAgICAvLyDovazlj5HmmoLml7blhYjkuI3lvIDlkK9cclxuICAgICAgICBvblNoYXJlQXBwTWVzc2FnZShyZXMpIHtcclxuICAgICAgICAgICAgaWYgKHJlcy5mcm9tID09PSAnYnV0dG9uJykge1xyXG4gICAgICAgICAgICAgICAgLy8g5p2l6Ieq6aG16Z2i5YaF6L2s5Y+R5oyJ6ZKuXHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhyZXMudGFyZ2V0KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICB0aXRsZTogdGhpcy5jb3Vyc2VJbmZvLmNvdXJzZVRpdHRsZSxcclxuICAgICAgICAgICAgICAgIHBhdGg6ICcvcGFnZXMvZGV0YWlsZS9kZXRhaWxlP2lkPScgKyB0aGlzLmNvdXJzZUluZm8uaWQgKyAnJmFnZW50SWQ9JyArIHRoaXMubWVtYmVyLmFnZW50SWRcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBhc3luYyBvbkxvYWQob3B0KSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKG9wdClcclxuICAgICAgICAgICAgLy8g6I635Y+W5Li75YaF5a656auY5bqm77yM55So5LqO5oKs5rWu6K+m5oOF5a+86IiqXHJcbiAgICAgICAgICAgIGxldCB2aWV3ID0gd3guY3JlYXRlU2VsZWN0b3JRdWVyeSgpLnNlbGVjdChcIiNpbmZvLWJveFwiKTtcclxuICAgICAgICAgICAgdmlld1xyXG4gICAgICAgICAgICAgICAgLmZpZWxkcyh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNpemU6IHRydWVcclxuICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGEgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhkYXRhLmhlaWdodCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubWFpbkhlaWdodCA9IGRhdGEuaGVpZ2h0O1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgIC5leGVjKCk7XHJcbiAgICAgICAgICAgIGF3YWl0IGF1dGgubG9naW4oKVxyXG4gICAgICAgICAgICB0aGlzLm1lbWJlciA9IHdlcHkuZ2V0U3RvcmFnZVN5bmMoJ21lbWJlcicpO1xyXG4gICAgICAgICAgICBsZXQge1xyXG4gICAgICAgICAgICAgICAgY291cnNlLFxyXG4gICAgICAgICAgICAgICAgY29tcGFuaW9ucyxcclxuICAgICAgICAgICAgICAgIHN0YXRpc3RpY3MsXHJcbiAgICAgICAgICAgICAgICBDb3Vyc2VDb21tZW50LFxyXG4gICAgICAgICAgICAgICAgYWN0UGludHVhbixcclxuICAgICAgICAgICAgICAgIGN1c3RvbWVyU2VydmljZVxyXG4gICAgICAgICAgICB9ID0gYXdhaXQgY29uZmlnLmdldENvdXJzZUluZm8ob3B0LmlkIHx8IG9wdC5zY2VuZSlcclxuICAgICAgICAgICAgdGhpcy5zd2lwZXJzLmxpc3QgPSBjb3Vyc2UucGljc1xyXG4gICAgICAgICAgICBjb3Vyc2UuY291cnNlQ2hhciA9IGNvdXJzZS5jb3Vyc2VDaGFyLnNwbGl0KFwifFwiKVxyXG4gICAgICAgICAgICB0aGlzLmNvdXJzZUluZm8gPSBjb3Vyc2VcclxuICAgICAgICAgICAgdGhpcy5jdXN0b21lclNlcnZpY2UgPSBjdXN0b21lclNlcnZpY2VcclxuICAgICAgICAgICAgd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5jb3Vyc2VJbmZvID0gY291cnNlXHJcbiAgICAgICAgICAgIHRoaXMuY29tcGFuaW9ucyA9IGNvbXBhbmlvbnNcclxuICAgICAgICAgICAgdGhpcy5zdGF0aXN0aWNzID0gc3RhdGlzdGljc1xyXG4gICAgICAgICAgICB0aGlzLkNvdXJzZUNvbW1lbnQgPSBDb3Vyc2VDb21tZW50XHJcbiAgICAgICAgICAgIHRoaXMuQWN0UGludHVhbiA9IGFjdFBpbnR1YW5cclxuICAgICAgICAgICAgY29uc29sZS5sb2codGhpcy5BY3RQaW50dWFuKVxyXG4gICAgICAgICAgICB0aGlzLiRhcHBseSgpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBza3UodHlwZSA9ICdub3JtYWwnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuc2hvd1NrdSA9IHRydWVcclxuICAgICAgICAgICAgdGhpcy50b1BpbnR1YW4gPSBmYWxzZVxyXG4gICAgICAgICAgICB0aGlzLmJ1eVR5cHQgPSB0eXBlXHJcbiAgICAgICAgfVxyXG4gICAgICAgIG1ldGhvZHMgPSB7XHJcbiAgICAgICAgICAgIHBheW1lbnRUeXBlKHR5cGUpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMucGF5bWVudFR5cGUgPSB0eXBlXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGNhbGwocGhvbmVOdW1iZXIpIHtcclxuICAgICAgICAgICAgICAgIHd4Lm1ha2VQaG9uZUNhbGwoe1xyXG4gICAgICAgICAgICAgICAgICAgIHBob25lTnVtYmVyIC8v5LuF5Li656S65L6L77yM5bm26Z2e55yf5a6e55qE55S16K+d5Y+356CBXHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBjb250KCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RhbE5hbWUgPSAnYm90dG9tTW9kYWwnXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGFzeW5jIHRvY3V0KGUpIHtcclxuICAgICAgICAgICAgICAgIGlmIChlLmRldGFpbC5lcnJNc2cgPT0gXCJnZXRVc2VySW5mbzpva1wiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYXdhaXQgYXV0aC5nZXRVc2VyaW5mbyhlLmRldGFpbClcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnNrdSgnYmFyZ2FpbicpXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBhc3luYyBjcmVhdGVJbWcoZSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKGUuZGV0YWlsLmVyck1zZyA9PSBcImdldFVzZXJJbmZvOm9rXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICBhd2FpdCBhdXRoLmdldFVzZXJpbmZvKGUuZGV0YWlsKVxyXG4gICAgICAgICAgICAgICAgICAgIHN0b3JlLnNhdmUoJ3NoYXJlSW5mbycsIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY291cnNlOiB0aGlzLmNvdXJzZUluZm8sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhdGg6ICdwYWdlcy9kZXRhaWxlL2RldGFpbGUnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZDogdGhpcy5jb3Vyc2VJbmZvLmlkXHJcbiAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB1cmw6ICcvcGFnZXMvaG9tZS9zaGFyZSdcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgdG9zaGFyZSgpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kYWxOYW1lID0gJ3NoYXJlJ1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB0b1BpbnR1YW5meSgpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMudG9QaW50dWFuID0gdHJ1ZVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBhc3luYyBiYXJnYWluKCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuY291cnNlSW54ID09IC0xKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgVGlwcy50b2FzdChcIuivt+mAieaLqeS4gOS4quiQpeacn1wiLCByZXMgPT4ge30sICdub25lJylcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGxldCB7XHJcbiAgICAgICAgICAgICAgICAgICAgZXJyY29kZSxcclxuICAgICAgICAgICAgICAgICAgICBlcnJtc2csXHJcbiAgICAgICAgICAgICAgICAgICAgZGF0YVxyXG4gICAgICAgICAgICAgICAgfSA9IGF3YWl0IGNvbmZpZy5yZWdCYXJnYWluKHtcclxuICAgICAgICAgICAgICAgICAgICBiYXJnYWluSWQ6IHRoaXMuY291cnNlSW5mby5iYXJnYWluSWQsXHJcbiAgICAgICAgICAgICAgICAgICAgY291cnNlSWQ6IHRoaXMuY291cnNlSW5mby5pZCxcclxuICAgICAgICAgICAgICAgICAgICBwZXJpb2RJZDogdGhpcy5jb3Vyc2VJbmZvLnBlcmlvZExpc3RbdGhpcy5jb3Vyc2VJbnhdLmlkLFxyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgIGlmIChlcnJjb2RlID09IDIwMCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHdlcHkucmVkaXJlY3RUbyh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHVybDogJy9wYWdlcy9hY3Rpdml0eS9iYXJnYWluP2lkPScgKyBkYXRhLnJlZ0lkXHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIOWPkei1t+egjeS7t+W8guW4uFxyXG4gICAgICAgICAgICAgICAgICAgIFRpcHMudG9hc3QoZXJybXNnLCByZXMgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB3ZXB5LnJlZGlyZWN0VG8oe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdXJsOiAnL3BhZ2VzL2FjdGl2aXR5L2JhcmdhaW4/aWQ9JyArIGRhdGEuYWN0QmFyZ2FpblJlZy5pZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICB9LCAnbm9uZScpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHJldCgpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB0YWJTZWxlY3QoZSkge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLlRhYkN1ciA9IGUuY3VycmVudFRhcmdldC5kYXRhc2V0LmlkIHx8IGUuZGV0YWlsLmN1cnJlbnQ7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGhpZGVNb2RhbCgpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMudG9QaW50dWFuID0gZmFsc2VcclxuICAgICAgICAgICAgICAgIHRoaXMuc2hvd1NrdSA9IGZhbHNlXHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGFsTmFtZSA9ICcnXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHNrdSh0eXBlKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNrdSh0eXBlKVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBwbHVzKCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuYnV5VHlwdCA9PSAnYmFyZ2FpbicpIHtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHd4LnZpYnJhdGVTaG9ydCgpXHJcbiAgICAgICAgICAgICAgICB0aGlzLm51bSA9IHRoaXMubnVtICsgMVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBtaW51cygpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLm51bSA+IDEpIHtcclxuICAgICAgICAgICAgICAgICAgICB3eC52aWJyYXRlU2hvcnQoKVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubnVtID0gdGhpcy5udW0gLSAxXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGNvdXJzZShpbngpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuY291cnNlSW54ID0gaW54XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGFzeW5jIGJ1eShhaWQgPSAwLCBvdCA9IDEsICkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuY291cnNlSW54ID09IC0xKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgVGlwcy50b2FzdChcIuivt+mAieaLqeS4gOS4quiQpeacn1wiLCByZXMgPT4ge30sICdub25lJylcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC8vIGlmKG90ID09IDIpe1xyXG4gICAgICAgICAgICAgICAgLy8gICAgIC8vIOegjeS7t1xyXG4gICAgICAgICAgICAgICAgLy8gICAgIGFpZCA9IHRoaXMuY291cnNlSW5mby5iYXJnYWluSWRcclxuICAgICAgICAgICAgICAgIC8vIH1cclxuICAgICAgICAgICAgICAgIC8vIGlmKG90ID09IDMpe1xyXG4gICAgICAgICAgICAgICAgLy8gICAgIC8vIOaLvOWbolxyXG4gICAgICAgICAgICAgICAgLy8gICAgIGFpZCA9IHRoaXMuY291cnNlSW5mby5waW50dWFuSWRcclxuICAgICAgICAgICAgICAgIC8vIH1cclxuICAgICAgICAgICAgICAgIHdlcHkubmF2aWdhdGVUbyh7XHJcbiAgICAgICAgICAgICAgICAgICAgdXJsOiBgLi9zdXJlT3JkZXI/dHlwZT0ke290fSZwaWQ9JHt0aGlzLmNvdXJzZUluZm8ucGVyaW9kTGlzdFt0aGlzLmNvdXJzZUlueF0uaWR9JmNpZD0ke3RoaXMuY291cnNlSW5mby5pZH0mbnVtPSR7dGhpcy5udW19JmFpZD0ke2FpZH0mYWN0cGlkPSR7dGhpcy5jb3Vyc2VJbmZvLnBpbnR1YW5JZH0mcHQ9JHt0aGlzLnBheW1lbnRUeXBlfWBcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuIl19