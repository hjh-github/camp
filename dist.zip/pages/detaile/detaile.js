"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _swiper = require('./../../components/common/swiper.js');

var _swiper2 = _interopRequireDefault(_swiper);

var _title = require('./../../components/detaile/title.js');

var _title2 = _interopRequireDefault(_title);

var _info = require('./../../components/detaile/info.js');

var _info2 = _interopRequireDefault(_info);

var _remake = require('./../../components/detaile/remake.js');

var _remake2 = _interopRequireDefault(_remake);

var _contact = require('./../../components/common/contact.js');

var _contact2 = _interopRequireDefault(_contact);

var _utils = require('./../../store/utils.js');

var _utils2 = _interopRequireDefault(_utils);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

var _WxUtils = require('./../../utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
    _inherits(Dialog, _wepy$page);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.data = {
            TabCur: 0,
            close: "/static/images/close.png",
            swipers: {
                type: 1,
                list: [{
                    id: 0,
                    type: "image",
                    url: "",
                    link: "/pages/meet/meet",
                    linkType: "switchTab"
                }]
            },
            mainHeight: 0,
            courseInfo: {},
            nodes: ["name", "attrs", "attrs"],
            num: 1,
            showSku: false,
            buyTypt: 'normal',
            courseInx: -1,
            companions: [],
            statistics: {},
            CourseComment: {},
            ActPintuan: {},
            sign_states: {
                0: '火热招生中',
                1: '少量名额',
                2: '已满员'
            },
            toPintuan: false,
            modalName: ''
        }, _this.$repeat = {}, _this.$props = { "cSwiper": { "xmlns:v-bind": "", "v-bind:model.sync": "swipers" }, "ctitle": { "v-bind:model.sync": "courseInfo" }, "cInfo": { "v-bind:model.sync": "courseInfo", "v-bind:companions.sync": "companions" }, "cRemake": { "v-bind:model.sync": "courseInfo", "v-bind:statistics.sync": "statistics", "v-bind:CourseComment.sync": "CourseComment" } }, _this.$events = {}, _this.components = {
            cSwiper: _swiper2.default,
            ctitle: _title2.default,
            cInfo: _info2.default,
            cRemake: _remake2.default,
            contact: _contact2.default
        }, _this.config = {
            navigationBarTitleText: "活动详情"
        }, _this.methods = {
            createImg: function () {
                var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(e) {
                    return regeneratorRuntime.wrap(function _callee$(_context) {
                        while (1) {
                            switch (_context.prev = _context.next) {
                                case 0:
                                    if (!(e.detail.errMsg == "getUserInfo:ok")) {
                                        _context.next = 5;
                                        break;
                                    }

                                    _context.next = 3;
                                    return _auth2.default.getUserinfo(e.detail);

                                case 3:
                                    _utils2.default.save('shareInfo', {
                                        course: this.courseInfo,
                                        path: 'pages/detaile/detaile',
                                        id: this.courseInfo.id
                                    });
                                    _wepy2.default.navigateTo({
                                        url: '/pages/home/share'
                                    });

                                case 5:
                                case "end":
                                    return _context.stop();
                            }
                        }
                    }, _callee, this);
                }));

                function createImg(_x) {
                    return _ref2.apply(this, arguments);
                }

                return createImg;
            }(),
            toshare: function toshare() {
                this.modalName = 'share';
            },
            toPintuanfy: function toPintuanfy() {
                this.toPintuan = true;
            },
            bargain: function () {
                var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
                    var _ref4, errcode, errmsg, data;

                    return regeneratorRuntime.wrap(function _callee2$(_context2) {
                        while (1) {
                            switch (_context2.prev = _context2.next) {
                                case 0:
                                    if (!(this.courseInx == -1)) {
                                        _context2.next = 3;
                                        break;
                                    }

                                    _Tips2.default.toast("请选择一个营期", function (res) {}, 'none');
                                    return _context2.abrupt("return", false);

                                case 3:
                                    _context2.next = 5;
                                    return _config2.default.regBargain({
                                        bargainId: this.courseInfo.bargainId,
                                        courseId: this.courseInfo.id,
                                        periodId: this.courseInfo.periodList[this.courseInx].id
                                    });

                                case 5:
                                    _ref4 = _context2.sent;
                                    errcode = _ref4.errcode;
                                    errmsg = _ref4.errmsg;
                                    data = _ref4.data;

                                    if (errcode == 200) {
                                        _wepy2.default.redirectTo({
                                            url: '/pages/activity/bargain?id=' + data.regId
                                        });
                                    } else {
                                        // 发起砍价异常
                                        _Tips2.default.toast(errmsg, function (res) {
                                            _wepy2.default.redirectTo({
                                                url: '/pages/activity/bargain?id=' + data.actBargainReg.id
                                            });
                                        }, 'none');
                                    }

                                case 10:
                                case "end":
                                    return _context2.stop();
                            }
                        }
                    }, _callee2, this);
                }));

                function bargain() {
                    return _ref3.apply(this, arguments);
                }

                return bargain;
            }(),
            ret: function ret() {
                return false;
            },
            tabSelect: function tabSelect(e) {
                console.log(e);
                this.TabCur = e.currentTarget.dataset.id || e.detail.current;
            },
            hideModal: function hideModal() {
                this.toPintuan = false;
                this.showSku = false;
                this.modalName = '';
            },
            sku: function sku() {
                var type = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'normal';

                this.showSku = true;
                this.toPintuan = false;
                this.buyTypt = type;
            },
            plus: function plus() {
                if (this.buyTypt == 'bargain') {
                    return false;
                }
                wx.vibrateShort();
                this.num = this.num + 1;
            },
            minus: function minus() {
                if (this.num > 1) {
                    wx.vibrateShort();
                    this.num = this.num - 1;
                }
            },
            course: function course(inx) {
                this.courseInx = inx;
            },
            buy: function () {
                var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
                    var aid = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;
                    var ot = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1;
                    return regeneratorRuntime.wrap(function _callee3$(_context3) {
                        while (1) {
                            switch (_context3.prev = _context3.next) {
                                case 0:
                                    if (!(this.courseInx == -1)) {
                                        _context3.next = 3;
                                        break;
                                    }

                                    _Tips2.default.toast("请选择一个营期", function (res) {}, 'none');
                                    return _context3.abrupt("return", false);

                                case 3:
                                    // if(ot == 2){
                                    //     // 砍价
                                    //     aid = this.courseInfo.bargainId
                                    // }
                                    // if(ot == 3){
                                    //     // 拼团
                                    //     aid = this.courseInfo.pintuanId
                                    // }
                                    _wepy2.default.navigateTo({
                                        url: "./sureOrder?type=" + ot + "&pid=" + this.courseInfo.periodList[this.courseInx].id + "&cid=" + this.courseInfo.id + "&num=" + this.num + "&aid=" + aid + "&actpid=" + this.courseInfo.pintuanId
                                    });

                                case 4:
                                case "end":
                                    return _context3.stop();
                            }
                        }
                    }, _callee3, this);
                }));

                function buy() {
                    return _ref5.apply(this, arguments);
                }

                return buy;
            }()
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(Dialog, [{
        key: "onShareAppMessage",

        // 转发暂时先不开启
        value: function onShareAppMessage(res) {
            if (res.from === 'button') {
                // 来自页面内转发按钮
                console.log(res.target);
            }
            return {
                title: this.courseInfo.courseTittle,
                path: '/pages/detaile/detaile?id=' + this.courseInfo.id
            };
        }
    }, {
        key: "onLoad",
        value: function () {
            var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4(opt) {
                var _this2 = this;

                var view, _ref7, course, companions, statistics, CourseComment, actPintuan;

                return regeneratorRuntime.wrap(function _callee4$(_context4) {
                    while (1) {
                        switch (_context4.prev = _context4.next) {
                            case 0:
                                console.log(opt);
                                // 获取主内容高度，用于悬浮详情导航
                                view = wx.createSelectorQuery().select("#info-box");

                                view.fields({
                                    size: true
                                }, function (data) {
                                    console.log(data.height);
                                    _this2.mainHeight = data.height;
                                }).exec();
                                _context4.next = 5;
                                return _auth2.default.login();

                            case 5:
                                _context4.next = 7;
                                return _config2.default.getCourseInfo(opt.id || opt.scene);

                            case 7:
                                _ref7 = _context4.sent;
                                course = _ref7.course;
                                companions = _ref7.companions;
                                statistics = _ref7.statistics;
                                CourseComment = _ref7.CourseComment;
                                actPintuan = _ref7.actPintuan;

                                this.swipers.list = course.pics;
                                course.courseChar = course.courseChar.split("|");
                                this.courseInfo = course;
                                _wepy2.default.$instance.globalData.courseInfo = course;
                                this.companions = companions;
                                this.statistics = statistics;
                                this.CourseComment = CourseComment;
                                this.ActPintuan = actPintuan;
                                console.log(this.ActPintuan);
                                this.$apply();

                            case 23:
                            case "end":
                                return _context4.stop();
                        }
                    }
                }, _callee4, this);
            }));

            function onLoad(_x5) {
                return _ref6.apply(this, arguments);
            }

            return onLoad;
        }()
    }]);

    return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/detaile/detaile'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldGFpbGUuanMiXSwibmFtZXMiOlsiRGlhbG9nIiwiZGF0YSIsIlRhYkN1ciIsImNsb3NlIiwic3dpcGVycyIsInR5cGUiLCJsaXN0IiwiaWQiLCJ1cmwiLCJsaW5rIiwibGlua1R5cGUiLCJtYWluSGVpZ2h0IiwiY291cnNlSW5mbyIsIm5vZGVzIiwibnVtIiwic2hvd1NrdSIsImJ1eVR5cHQiLCJjb3Vyc2VJbngiLCJjb21wYW5pb25zIiwic3RhdGlzdGljcyIsIkNvdXJzZUNvbW1lbnQiLCJBY3RQaW50dWFuIiwic2lnbl9zdGF0ZXMiLCJ0b1BpbnR1YW4iLCJtb2RhbE5hbWUiLCIkcmVwZWF0IiwiJHByb3BzIiwiJGV2ZW50cyIsImNvbXBvbmVudHMiLCJjU3dpcGVyIiwiY3RpdGxlIiwiY0luZm8iLCJjUmVtYWtlIiwiY29udGFjdCIsImNvbmZpZyIsIm5hdmlnYXRpb25CYXJUaXRsZVRleHQiLCJtZXRob2RzIiwiY3JlYXRlSW1nIiwiZSIsImRldGFpbCIsImVyck1zZyIsImF1dGgiLCJnZXRVc2VyaW5mbyIsInN0b3JlIiwic2F2ZSIsImNvdXJzZSIsInBhdGgiLCJ3ZXB5IiwibmF2aWdhdGVUbyIsInRvc2hhcmUiLCJ0b1BpbnR1YW5meSIsImJhcmdhaW4iLCJUaXBzIiwidG9hc3QiLCJyZWdCYXJnYWluIiwiYmFyZ2FpbklkIiwiY291cnNlSWQiLCJwZXJpb2RJZCIsInBlcmlvZExpc3QiLCJlcnJjb2RlIiwiZXJybXNnIiwicmVkaXJlY3RUbyIsInJlZ0lkIiwiYWN0QmFyZ2FpblJlZyIsInJldCIsInRhYlNlbGVjdCIsImNvbnNvbGUiLCJsb2ciLCJjdXJyZW50VGFyZ2V0IiwiZGF0YXNldCIsImN1cnJlbnQiLCJoaWRlTW9kYWwiLCJza3UiLCJwbHVzIiwid3giLCJ2aWJyYXRlU2hvcnQiLCJtaW51cyIsImlueCIsImJ1eSIsImFpZCIsIm90IiwicGludHVhbklkIiwicmVzIiwiZnJvbSIsInRhcmdldCIsInRpdGxlIiwiY291cnNlVGl0dGxlIiwib3B0IiwidmlldyIsImNyZWF0ZVNlbGVjdG9yUXVlcnkiLCJzZWxlY3QiLCJmaWVsZHMiLCJzaXplIiwiaGVpZ2h0IiwiZXhlYyIsImxvZ2luIiwiZ2V0Q291cnNlSW5mbyIsInNjZW5lIiwiYWN0UGludHVhbiIsInBpY3MiLCJjb3Vyc2VDaGFyIiwic3BsaXQiLCIkaW5zdGFuY2UiLCJnbG9iYWxEYXRhIiwiJGFwcGx5IiwicGFnZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQ0k7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7Ozs7Ozs7Ozs7Ozs7SUFDcUJBLE07Ozs7Ozs7Ozs7Ozs7OzBMQUNqQkMsSSxHQUFPO0FBQ0hDLG9CQUFRLENBREw7QUFFSEMsbUJBQU8sMEJBRko7QUFHSEMscUJBQVM7QUFDTEMsc0JBQU0sQ0FERDtBQUVMQyxzQkFBTSxDQUFDO0FBQ0hDLHdCQUFJLENBREQ7QUFFSEYsMEJBQU0sT0FGSDtBQUdIRyx5QkFBSyxFQUhGO0FBSUhDLDBCQUFNLGtCQUpIO0FBS0hDLDhCQUFVO0FBTFAsaUJBQUQ7QUFGRCxhQUhOO0FBYUhDLHdCQUFZLENBYlQ7QUFjSEMsd0JBQVksRUFkVDtBQWVIQyxtQkFBTyxDQUFDLE1BQUQsRUFBUyxPQUFULEVBQWtCLE9BQWxCLENBZko7QUFnQkhDLGlCQUFLLENBaEJGO0FBaUJIQyxxQkFBUyxLQWpCTjtBQWtCSEMscUJBQVMsUUFsQk47QUFtQkhDLHVCQUFXLENBQUMsQ0FuQlQ7QUFvQkhDLHdCQUFZLEVBcEJUO0FBcUJIQyx3QkFBWSxFQXJCVDtBQXNCSEMsMkJBQWUsRUF0Qlo7QUF1QkhDLHdCQUFZLEVBdkJUO0FBd0JIQyx5QkFBYTtBQUNULG1CQUFHLE9BRE07QUFFVCxtQkFBRyxNQUZNO0FBR1QsbUJBQUc7QUFITSxhQXhCVjtBQTZCSEMsdUJBQVcsS0E3QlI7QUE4QkhDLHVCQUFXO0FBOUJSLFMsUUFnQ1JDLE8sR0FBVSxFLFFBQ2pCQyxNLEdBQVMsRUFBQyxXQUFVLEVBQUMsZ0JBQWUsRUFBaEIsRUFBbUIscUJBQW9CLFNBQXZDLEVBQVgsRUFBNkQsVUFBUyxFQUFDLHFCQUFvQixZQUFyQixFQUF0RSxFQUF5RyxTQUFRLEVBQUMscUJBQW9CLFlBQXJCLEVBQWtDLDBCQUF5QixZQUEzRCxFQUFqSCxFQUEwTCxXQUFVLEVBQUMscUJBQW9CLFlBQXJCLEVBQWtDLDBCQUF5QixZQUEzRCxFQUF3RSw2QkFBNEIsZUFBcEcsRUFBcE0sRSxRQUNUQyxPLEdBQVUsRSxRQUNUQyxVLEdBQWE7QUFDRkMscUNBREU7QUFFRkMsbUNBRkU7QUFHRkMsaUNBSEU7QUFJRkMscUNBSkU7QUFLRkM7QUFMRSxTLFFBT05DLE0sR0FBUztBQUNMQyxvQ0FBd0I7QUFEbkIsUyxRQStDVEMsTyxHQUFVO0FBQ0FDLHFCQURBO0FBQUEscUdBQ1VDLENBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBDQUVFQSxFQUFFQyxNQUFGLENBQVNDLE1BQVQsSUFBbUIsZ0JBRnJCO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUEsMkNBR1FDLGVBQUtDLFdBQUwsQ0FBaUJKLEVBQUVDLE1BQW5CLENBSFI7O0FBQUE7QUFJRUksb0RBQU1DLElBQU4sQ0FBVyxXQUFYLEVBQXdCO0FBQ3BCQyxnREFBUSxLQUFLakMsVUFETztBQUVwQmtDLDhDQUFNLHVCQUZjO0FBR3BCdkMsNENBQUksS0FBS0ssVUFBTCxDQUFnQkw7QUFIQSxxQ0FBeEI7QUFLQXdDLG1EQUFLQyxVQUFMLENBQWdCO0FBQ1p4Qyw2Q0FBSztBQURPLHFDQUFoQjs7QUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQWNOeUMsbUJBZE0scUJBY0k7QUFDTixxQkFBS3pCLFNBQUwsR0FBaUIsT0FBakI7QUFDSCxhQWhCSztBQWlCTjBCLHVCQWpCTSx5QkFpQlE7QUFDVixxQkFBSzNCLFNBQUwsR0FBaUIsSUFBakI7QUFDSCxhQW5CSztBQW9CQTRCLG1CQXBCQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQ0FxQkUsS0FBS2xDLFNBQUwsSUFBa0IsQ0FBQyxDQXJCckI7QUFBQTtBQUFBO0FBQUE7O0FBc0JFbUMsbURBQUtDLEtBQUwsQ0FBVyxTQUFYLEVBQXNCLGVBQU8sQ0FBRSxDQUEvQixFQUFpQyxNQUFqQztBQXRCRixzRUF1QlMsS0F2QlQ7O0FBQUE7QUFBQTtBQUFBLDJDQTZCUW5CLGlCQUFPb0IsVUFBUCxDQUFrQjtBQUN4QkMsbURBQVcsS0FBSzNDLFVBQUwsQ0FBZ0IyQyxTQURIO0FBRXhCQyxrREFBVSxLQUFLNUMsVUFBTCxDQUFnQkwsRUFGRjtBQUd4QmtELGtEQUFVLEtBQUs3QyxVQUFMLENBQWdCOEMsVUFBaEIsQ0FBMkIsS0FBS3pDLFNBQWhDLEVBQTJDVjtBQUg3QixxQ0FBbEIsQ0E3QlI7O0FBQUE7QUFBQTtBQTBCRW9ELDJDQTFCRixTQTBCRUEsT0ExQkY7QUEyQkVDLDBDQTNCRixTQTJCRUEsTUEzQkY7QUE0QkUzRCx3Q0E1QkYsU0E0QkVBLElBNUJGOztBQWtDRix3Q0FBSTBELFdBQVcsR0FBZixFQUFvQjtBQUNoQlosdURBQUtjLFVBQUwsQ0FBZ0I7QUFDWnJELGlEQUFLLGdDQUFnQ1AsS0FBSzZEO0FBRDlCLHlDQUFoQjtBQUdILHFDQUpELE1BSU87QUFDSDtBQUNBVix1REFBS0MsS0FBTCxDQUFXTyxNQUFYLEVBQW1CLGVBQU87QUFDdEJiLDJEQUFLYyxVQUFMLENBQWdCO0FBQ1pyRCxxREFBSyxnQ0FBZ0NQLEtBQUs4RCxhQUFMLENBQW1CeEQ7QUFENUMsNkNBQWhCO0FBR0gseUNBSkQsRUFJRyxNQUpIO0FBS0g7O0FBN0NDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBK0NOeUQsZUEvQ00saUJBK0NBO0FBQ0YsdUJBQU8sS0FBUDtBQUNILGFBakRLO0FBa0ROQyxxQkFsRE0scUJBa0RJM0IsQ0FsREosRUFrRE87QUFDVDRCLHdCQUFRQyxHQUFSLENBQVk3QixDQUFaO0FBQ0EscUJBQUtwQyxNQUFMLEdBQWNvQyxFQUFFOEIsYUFBRixDQUFnQkMsT0FBaEIsQ0FBd0I5RCxFQUF4QixJQUE4QitCLEVBQUVDLE1BQUYsQ0FBUytCLE9BQXJEO0FBQ0gsYUFyREs7QUFzRE5DLHFCQXRETSx1QkFzRE07QUFDUixxQkFBS2hELFNBQUwsR0FBaUIsS0FBakI7QUFDQSxxQkFBS1IsT0FBTCxHQUFlLEtBQWY7QUFDQSxxQkFBS1MsU0FBTCxHQUFpQixFQUFqQjtBQUNILGFBMURLO0FBMkROZ0QsZUEzRE0saUJBMkRlO0FBQUEsb0JBQWpCbkUsSUFBaUIsdUVBQVYsUUFBVTs7QUFDakIscUJBQUtVLE9BQUwsR0FBZSxJQUFmO0FBQ0EscUJBQUtRLFNBQUwsR0FBaUIsS0FBakI7QUFDQSxxQkFBS1AsT0FBTCxHQUFlWCxJQUFmO0FBQ0gsYUEvREs7QUFnRU5vRSxnQkFoRU0sa0JBZ0VDO0FBQ0gsb0JBQUksS0FBS3pELE9BQUwsSUFBZ0IsU0FBcEIsRUFBK0I7QUFDM0IsMkJBQU8sS0FBUDtBQUNIO0FBQ0QwRCxtQkFBR0MsWUFBSDtBQUNBLHFCQUFLN0QsR0FBTCxHQUFXLEtBQUtBLEdBQUwsR0FBVyxDQUF0QjtBQUNILGFBdEVLO0FBdUVOOEQsaUJBdkVNLG1CQXVFRTtBQUNKLG9CQUFJLEtBQUs5RCxHQUFMLEdBQVcsQ0FBZixFQUFrQjtBQUNkNEQsdUJBQUdDLFlBQUg7QUFDQSx5QkFBSzdELEdBQUwsR0FBVyxLQUFLQSxHQUFMLEdBQVcsQ0FBdEI7QUFDSDtBQUNKLGFBNUVLO0FBNkVOK0Isa0JBN0VNLGtCQTZFQ2dDLEdBN0VELEVBNkVNO0FBQ1IscUJBQUs1RCxTQUFMLEdBQWlCNEQsR0FBakI7QUFDSCxhQS9FSztBQWdGQUMsZUFoRkE7QUFBQTtBQUFBLHdCQWdGSUMsR0FoRkosdUVBZ0ZVLENBaEZWO0FBQUEsd0JBZ0ZhQyxFQWhGYix1RUFnRmtCLENBaEZsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMENBaUZFLEtBQUsvRCxTQUFMLElBQWtCLENBQUMsQ0FqRnJCO0FBQUE7QUFBQTtBQUFBOztBQWtGRW1DLG1EQUFLQyxLQUFMLENBQVcsU0FBWCxFQUFzQixlQUFPLENBQUUsQ0FBL0IsRUFBaUMsTUFBakM7QUFsRkYsc0VBbUZTLEtBbkZUOztBQUFBO0FBcUZGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQU4sbURBQUtDLFVBQUwsQ0FBZ0I7QUFDWnhDLG1FQUF5QndFLEVBQXpCLGFBQW1DLEtBQUtwRSxVQUFMLENBQWdCOEMsVUFBaEIsQ0FBMkIsS0FBS3pDLFNBQWhDLEVBQTJDVixFQUE5RSxhQUF3RixLQUFLSyxVQUFMLENBQWdCTCxFQUF4RyxhQUFrSCxLQUFLTyxHQUF2SCxhQUFrSWlFLEdBQWxJLGdCQUFnSixLQUFLbkUsVUFBTCxDQUFnQnFFO0FBRHBKLHFDQUFoQjs7QUE3RkU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQSxTOzs7Ozs7QUE1Q1Y7MENBQ2tCQyxHLEVBQUs7QUFDbkIsZ0JBQUlBLElBQUlDLElBQUosS0FBYSxRQUFqQixFQUEyQjtBQUN2QjtBQUNBakIsd0JBQVFDLEdBQVIsQ0FBWWUsSUFBSUUsTUFBaEI7QUFDSDtBQUNELG1CQUFPO0FBQ0hDLHVCQUFPLEtBQUt6RSxVQUFMLENBQWdCMEUsWUFEcEI7QUFFSHhDLHNCQUFNLCtCQUErQixLQUFLbEMsVUFBTCxDQUFnQkw7QUFGbEQsYUFBUDtBQUlIOzs7O2tHQUNZZ0YsRzs7Ozs7Ozs7O0FBQ1RyQix3Q0FBUUMsR0FBUixDQUFZb0IsR0FBWjtBQUNBO0FBQ0lDLG9DLEdBQU9kLEdBQUdlLG1CQUFILEdBQXlCQyxNQUF6QixDQUFnQyxXQUFoQyxDOztBQUNYRixxQ0FDS0csTUFETCxDQUNZO0FBQ0FDLDBDQUFNO0FBRE4saUNBRFosRUFJUSxnQkFBUTtBQUNKMUIsNENBQVFDLEdBQVIsQ0FBWWxFLEtBQUs0RixNQUFqQjtBQUNBLDJDQUFLbEYsVUFBTCxHQUFrQlYsS0FBSzRGLE1BQXZCO0FBQ0gsaUNBUFQsRUFTS0MsSUFUTDs7dUNBVU1yRCxlQUFLc0QsS0FBTCxFOzs7O3VDQU9JN0QsaUJBQU84RCxhQUFQLENBQXFCVCxJQUFJaEYsRUFBSixJQUFVZ0YsSUFBSVUsS0FBbkMsQzs7OztBQUxOcEQsc0MsU0FBQUEsTTtBQUNBM0IsMEMsU0FBQUEsVTtBQUNBQywwQyxTQUFBQSxVO0FBQ0FDLDZDLFNBQUFBLGE7QUFDQThFLDBDLFNBQUFBLFU7O0FBRUoscUNBQUs5RixPQUFMLENBQWFFLElBQWIsR0FBb0J1QyxPQUFPc0QsSUFBM0I7QUFDQXRELHVDQUFPdUQsVUFBUCxHQUFvQnZELE9BQU91RCxVQUFQLENBQWtCQyxLQUFsQixDQUF3QixHQUF4QixDQUFwQjtBQUNBLHFDQUFLekYsVUFBTCxHQUFrQmlDLE1BQWxCO0FBQ0FFLCtDQUFLdUQsU0FBTCxDQUFlQyxVQUFmLENBQTBCM0YsVUFBMUIsR0FBdUNpQyxNQUF2QztBQUNBLHFDQUFLM0IsVUFBTCxHQUFrQkEsVUFBbEI7QUFDQSxxQ0FBS0MsVUFBTCxHQUFrQkEsVUFBbEI7QUFDQSxxQ0FBS0MsYUFBTCxHQUFxQkEsYUFBckI7QUFDQSxxQ0FBS0MsVUFBTCxHQUFrQjZFLFVBQWxCO0FBQ0FoQyx3Q0FBUUMsR0FBUixDQUFZLEtBQUs5QyxVQUFqQjtBQUNBLHFDQUFLbUYsTUFBTDs7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQXhGNEJ6RCxlQUFLMEQsSTs7a0JBQXBCekcsTSIsImZpbGUiOiJkZXRhaWxlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbiAgICBpbXBvcnQgd2VweSBmcm9tIFwid2VweVwiO1xyXG4gICAgaW1wb3J0IGNTd2lwZXIgZnJvbSBcIkAvY29tcG9uZW50cy9jb21tb24vc3dpcGVyXCI7XHJcbiAgICBpbXBvcnQgY3RpdGxlIGZyb20gXCJAL2NvbXBvbmVudHMvZGV0YWlsZS90aXRsZVwiO1xyXG4gICAgaW1wb3J0IGNJbmZvIGZyb20gXCJAL2NvbXBvbmVudHMvZGV0YWlsZS9pbmZvXCI7XHJcbiAgICBpbXBvcnQgY1JlbWFrZSBmcm9tIFwiQC9jb21wb25lbnRzL2RldGFpbGUvcmVtYWtlXCI7XHJcbiAgICBpbXBvcnQgY29udGFjdCBmcm9tIFwiQC9jb21wb25lbnRzL2NvbW1vbi9jb250YWN0XCJcclxuICAgIGltcG9ydCBzdG9yZSBmcm9tIFwiQC9zdG9yZS91dGlsc1wiXHJcbiAgICBpbXBvcnQgY29uZmlnIGZyb20gXCJAL2FwaS9jb25maWdcIjtcclxuICAgIGltcG9ydCBhdXRoIGZyb20gXCJAL2FwaS9hdXRoXCI7XHJcbiAgICBpbXBvcnQgV3hVdGlscyBmcm9tIFwiQC91dGlscy9XeFV0aWxzXCI7XHJcbiAgICBpbXBvcnQgVGlwcyBmcm9tIFwiQC91dGlscy9UaXBzXCI7XHJcbiAgICBleHBvcnQgZGVmYXVsdCBjbGFzcyBEaWFsb2cgZXh0ZW5kcyB3ZXB5LnBhZ2Uge1xyXG4gICAgICAgIGRhdGEgPSB7XHJcbiAgICAgICAgICAgIFRhYkN1cjogMCxcclxuICAgICAgICAgICAgY2xvc2U6IFwiL3N0YXRpYy9pbWFnZXMvY2xvc2UucG5nXCIsXHJcbiAgICAgICAgICAgIHN3aXBlcnM6IHtcclxuICAgICAgICAgICAgICAgIHR5cGU6IDEsXHJcbiAgICAgICAgICAgICAgICBsaXN0OiBbe1xyXG4gICAgICAgICAgICAgICAgICAgIGlkOiAwLFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU6IFwiaW1hZ2VcIixcclxuICAgICAgICAgICAgICAgICAgICB1cmw6IFwiXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgbGluazogXCIvcGFnZXMvbWVldC9tZWV0XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgbGlua1R5cGU6IFwic3dpdGNoVGFiXCJcclxuICAgICAgICAgICAgICAgIH1dXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIG1haW5IZWlnaHQ6IDAsXHJcbiAgICAgICAgICAgIGNvdXJzZUluZm86IHt9LFxyXG4gICAgICAgICAgICBub2RlczogW1wibmFtZVwiLCBcImF0dHJzXCIsIFwiYXR0cnNcIl0sXHJcbiAgICAgICAgICAgIG51bTogMSxcclxuICAgICAgICAgICAgc2hvd1NrdTogZmFsc2UsXHJcbiAgICAgICAgICAgIGJ1eVR5cHQ6ICdub3JtYWwnLFxyXG4gICAgICAgICAgICBjb3Vyc2VJbng6IC0xLFxyXG4gICAgICAgICAgICBjb21wYW5pb25zOiBbXSxcclxuICAgICAgICAgICAgc3RhdGlzdGljczoge30sXHJcbiAgICAgICAgICAgIENvdXJzZUNvbW1lbnQ6IHt9LFxyXG4gICAgICAgICAgICBBY3RQaW50dWFuOiB7fSxcclxuICAgICAgICAgICAgc2lnbl9zdGF0ZXM6IHtcclxuICAgICAgICAgICAgICAgIDA6ICfngavng63mi5vnlJ/kuK0nLFxyXG4gICAgICAgICAgICAgICAgMTogJ+WwkemHj+WQjeminScsXHJcbiAgICAgICAgICAgICAgICAyOiAn5bey5ruh5ZGYJ1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB0b1BpbnR1YW46IGZhbHNlLFxyXG4gICAgICAgICAgICBtb2RhbE5hbWU6ICcnXHJcbiAgICAgICAgfTtcclxuICAgICAgICRyZXBlYXQgPSB7fTtcclxuJHByb3BzID0ge1wiY1N3aXBlclwiOntcInhtbG5zOnYtYmluZFwiOlwiXCIsXCJ2LWJpbmQ6bW9kZWwuc3luY1wiOlwic3dpcGVyc1wifSxcImN0aXRsZVwiOntcInYtYmluZDptb2RlbC5zeW5jXCI6XCJjb3Vyc2VJbmZvXCJ9LFwiY0luZm9cIjp7XCJ2LWJpbmQ6bW9kZWwuc3luY1wiOlwiY291cnNlSW5mb1wiLFwidi1iaW5kOmNvbXBhbmlvbnMuc3luY1wiOlwiY29tcGFuaW9uc1wifSxcImNSZW1ha2VcIjp7XCJ2LWJpbmQ6bW9kZWwuc3luY1wiOlwiY291cnNlSW5mb1wiLFwidi1iaW5kOnN0YXRpc3RpY3Muc3luY1wiOlwic3RhdGlzdGljc1wiLFwidi1iaW5kOkNvdXJzZUNvbW1lbnQuc3luY1wiOlwiQ291cnNlQ29tbWVudFwifX07XHJcbiRldmVudHMgPSB7fTtcclxuIGNvbXBvbmVudHMgPSB7XHJcbiAgICAgICAgICAgIGNTd2lwZXIsXHJcbiAgICAgICAgICAgIGN0aXRsZSxcclxuICAgICAgICAgICAgY0luZm8sXHJcbiAgICAgICAgICAgIGNSZW1ha2UsXHJcbiAgICAgICAgICAgIGNvbnRhY3RcclxuICAgICAgICB9O1xyXG4gICAgICAgIGNvbmZpZyA9IHtcclxuICAgICAgICAgICAgbmF2aWdhdGlvbkJhclRpdGxlVGV4dDogXCLmtLvliqjor6bmg4VcIlxyXG4gICAgICAgIH07XHJcbiAgICAgICAgLy8g6L2s5Y+R5pqC5pe25YWI5LiN5byA5ZCvXHJcbiAgICAgICAgb25TaGFyZUFwcE1lc3NhZ2UocmVzKSB7XHJcbiAgICAgICAgICAgIGlmIChyZXMuZnJvbSA9PT0gJ2J1dHRvbicpIHtcclxuICAgICAgICAgICAgICAgIC8vIOadpeiHqumhtemdouWGhei9rOWPkeaMiemSrlxyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2cocmVzLnRhcmdldClcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgdGl0bGU6IHRoaXMuY291cnNlSW5mby5jb3Vyc2VUaXR0bGUsXHJcbiAgICAgICAgICAgICAgICBwYXRoOiAnL3BhZ2VzL2RldGFpbGUvZGV0YWlsZT9pZD0nICsgdGhpcy5jb3Vyc2VJbmZvLmlkXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgYXN5bmMgb25Mb2FkKG9wdCkge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhvcHQpXHJcbiAgICAgICAgICAgIC8vIOiOt+WPluS4u+WGheWuuemrmOW6pu+8jOeUqOS6juaCrOa1ruivpuaDheWvvOiIqlxyXG4gICAgICAgICAgICBsZXQgdmlldyA9IHd4LmNyZWF0ZVNlbGVjdG9yUXVlcnkoKS5zZWxlY3QoXCIjaW5mby1ib3hcIik7XHJcbiAgICAgICAgICAgIHZpZXdcclxuICAgICAgICAgICAgICAgIC5maWVsZHMoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzaXplOiB0cnVlXHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICBkYXRhID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZGF0YS5oZWlnaHQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm1haW5IZWlnaHQgPSBkYXRhLmhlaWdodDtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAuZXhlYygpO1xyXG4gICAgICAgICAgICBhd2FpdCBhdXRoLmxvZ2luKClcclxuICAgICAgICAgICAgbGV0IHtcclxuICAgICAgICAgICAgICAgIGNvdXJzZSxcclxuICAgICAgICAgICAgICAgIGNvbXBhbmlvbnMsXHJcbiAgICAgICAgICAgICAgICBzdGF0aXN0aWNzLFxyXG4gICAgICAgICAgICAgICAgQ291cnNlQ29tbWVudCxcclxuICAgICAgICAgICAgICAgIGFjdFBpbnR1YW5cclxuICAgICAgICAgICAgfSA9IGF3YWl0IGNvbmZpZy5nZXRDb3Vyc2VJbmZvKG9wdC5pZCB8fCBvcHQuc2NlbmUpXHJcbiAgICAgICAgICAgIHRoaXMuc3dpcGVycy5saXN0ID0gY291cnNlLnBpY3NcclxuICAgICAgICAgICAgY291cnNlLmNvdXJzZUNoYXIgPSBjb3Vyc2UuY291cnNlQ2hhci5zcGxpdChcInxcIilcclxuICAgICAgICAgICAgdGhpcy5jb3Vyc2VJbmZvID0gY291cnNlXHJcbiAgICAgICAgICAgIHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuY291cnNlSW5mbyA9IGNvdXJzZVxyXG4gICAgICAgICAgICB0aGlzLmNvbXBhbmlvbnMgPSBjb21wYW5pb25zXHJcbiAgICAgICAgICAgIHRoaXMuc3RhdGlzdGljcyA9IHN0YXRpc3RpY3NcclxuICAgICAgICAgICAgdGhpcy5Db3Vyc2VDb21tZW50ID0gQ291cnNlQ29tbWVudFxyXG4gICAgICAgICAgICB0aGlzLkFjdFBpbnR1YW4gPSBhY3RQaW50dWFuXHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKHRoaXMuQWN0UGludHVhbilcclxuICAgICAgICAgICAgdGhpcy4kYXBwbHkoKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgbWV0aG9kcyA9IHtcclxuICAgICAgICAgICAgYXN5bmMgY3JlYXRlSW1nKGUpIHtcclxuICAgICAgICAgICAgICAgIGlmIChlLmRldGFpbC5lcnJNc2cgPT0gXCJnZXRVc2VySW5mbzpva1wiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYXdhaXQgYXV0aC5nZXRVc2VyaW5mbyhlLmRldGFpbClcclxuICAgICAgICAgICAgICAgICAgICBzdG9yZS5zYXZlKCdzaGFyZUluZm8nLCB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvdXJzZTogdGhpcy5jb3Vyc2VJbmZvLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYXRoOiAncGFnZXMvZGV0YWlsZS9kZXRhaWxlJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IHRoaXMuY291cnNlSW5mby5pZFxyXG4gICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgd2VweS5uYXZpZ2F0ZVRvKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdXJsOiAnL3BhZ2VzL2hvbWUvc2hhcmUnXHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHRvc2hhcmUoKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGFsTmFtZSA9ICdzaGFyZSdcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgdG9QaW50dWFuZnkoKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnRvUGludHVhbiA9IHRydWVcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgYXN5bmMgYmFyZ2FpbigpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmNvdXJzZUlueCA9PSAtMSkge1xyXG4gICAgICAgICAgICAgICAgICAgIFRpcHMudG9hc3QoXCLor7fpgInmi6nkuIDkuKrokKXmnJ9cIiwgcmVzID0+IHt9LCAnbm9uZScpXHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBsZXQge1xyXG4gICAgICAgICAgICAgICAgICAgIGVycmNvZGUsXHJcbiAgICAgICAgICAgICAgICAgICAgZXJybXNnLFxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGFcclxuICAgICAgICAgICAgICAgIH0gPSBhd2FpdCBjb25maWcucmVnQmFyZ2Fpbih7XHJcbiAgICAgICAgICAgICAgICAgICAgYmFyZ2FpbklkOiB0aGlzLmNvdXJzZUluZm8uYmFyZ2FpbklkLFxyXG4gICAgICAgICAgICAgICAgICAgIGNvdXJzZUlkOiB0aGlzLmNvdXJzZUluZm8uaWQsXHJcbiAgICAgICAgICAgICAgICAgICAgcGVyaW9kSWQ6IHRoaXMuY291cnNlSW5mby5wZXJpb2RMaXN0W3RoaXMuY291cnNlSW54XS5pZCxcclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICBpZiAoZXJyY29kZSA9PSAyMDApIHtcclxuICAgICAgICAgICAgICAgICAgICB3ZXB5LnJlZGlyZWN0VG8oe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB1cmw6ICcvcGFnZXMvYWN0aXZpdHkvYmFyZ2Fpbj9pZD0nICsgZGF0YS5yZWdJZFxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAvLyDlj5HotbfnoI3ku7flvILluLhcclxuICAgICAgICAgICAgICAgICAgICBUaXBzLnRvYXN0KGVycm1zZywgcmVzID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgd2VweS5yZWRpcmVjdFRvKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVybDogJy9wYWdlcy9hY3Rpdml0eS9iYXJnYWluP2lkPScgKyBkYXRhLmFjdEJhcmdhaW5SZWcuaWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfSwgJ25vbmUnKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICByZXQoKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgdGFiU2VsZWN0KGUpIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5UYWJDdXIgPSBlLmN1cnJlbnRUYXJnZXQuZGF0YXNldC5pZCB8fCBlLmRldGFpbC5jdXJyZW50O1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBoaWRlTW9kYWwoKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnRvUGludHVhbiA9IGZhbHNlXHJcbiAgICAgICAgICAgICAgICB0aGlzLnNob3dTa3UgPSBmYWxzZVxyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RhbE5hbWUgPSAnJ1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBza3UodHlwZSA9ICdub3JtYWwnKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNob3dTa3UgPSB0cnVlXHJcbiAgICAgICAgICAgICAgICB0aGlzLnRvUGludHVhbiA9IGZhbHNlXHJcbiAgICAgICAgICAgICAgICB0aGlzLmJ1eVR5cHQgPSB0eXBlXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHBsdXMoKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5idXlUeXB0ID09ICdiYXJnYWluJykge1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgd3gudmlicmF0ZVNob3J0KClcclxuICAgICAgICAgICAgICAgIHRoaXMubnVtID0gdGhpcy5udW0gKyAxXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIG1pbnVzKCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMubnVtID4gMSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHd4LnZpYnJhdGVTaG9ydCgpXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5udW0gPSB0aGlzLm51bSAtIDFcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgY291cnNlKGlueCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jb3Vyc2VJbnggPSBpbnhcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgYXN5bmMgYnV5KGFpZCA9IDAsIG90ID0gMSwgKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5jb3Vyc2VJbnggPT0gLTEpIHtcclxuICAgICAgICAgICAgICAgICAgICBUaXBzLnRvYXN0KFwi6K+36YCJ5oup5LiA5Liq6JCl5pyfXCIsIHJlcyA9PiB7fSwgJ25vbmUnKVxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLy8gaWYob3QgPT0gMil7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgLy8g56CN5Lu3XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgYWlkID0gdGhpcy5jb3Vyc2VJbmZvLmJhcmdhaW5JZFxyXG4gICAgICAgICAgICAgICAgLy8gfVxyXG4gICAgICAgICAgICAgICAgLy8gaWYob3QgPT0gMyl7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgLy8g5ou85ZuiXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgYWlkID0gdGhpcy5jb3Vyc2VJbmZvLnBpbnR1YW5JZFxyXG4gICAgICAgICAgICAgICAgLy8gfVxyXG4gICAgICAgICAgICAgICAgd2VweS5uYXZpZ2F0ZVRvKHtcclxuICAgICAgICAgICAgICAgICAgICB1cmw6IGAuL3N1cmVPcmRlcj90eXBlPSR7b3R9JnBpZD0ke3RoaXMuY291cnNlSW5mby5wZXJpb2RMaXN0W3RoaXMuY291cnNlSW54XS5pZH0mY2lkPSR7dGhpcy5jb3Vyc2VJbmZvLmlkfSZudW09JHt0aGlzLm51bX0mYWlkPSR7YWlkfSZhY3RwaWQ9JHt0aGlzLmNvdXJzZUluZm8ucGludHVhbklkfWBcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuIl19