"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _swiper = require('./../../components/common/swiper.js');

var _swiper2 = _interopRequireDefault(_swiper);

var _title = require('./../../components/detaile/title.js');

var _title2 = _interopRequireDefault(_title);

var _info = require('./../../components/detaile/info.js');

var _info2 = _interopRequireDefault(_info);

var _remake = require('./../../components/detaile/remake.js');

var _remake2 = _interopRequireDefault(_remake);

var _contact = require('./../../components/common/contact.js');

var _contact2 = _interopRequireDefault(_contact);

var _utils = require('./../../store/utils.js');

var _utils2 = _interopRequireDefault(_utils);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

var _WxUtils = require('./../../utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
    _inherits(Dialog, _wepy$page);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.data = {
            TabCur: 0,
            close: "/static/images/close.png",
            swipers: {
                type: 1,
                list: [{
                    id: 0,
                    type: "image",
                    url: "",
                    link: "/pages/meet/meet",
                    linkType: "switchTab"
                }]
            },
            mainHeight: 0,
            courseInfo: {},
            nodes: ["name", "attrs", "attrs"],
            num: 1,
            showSku: false,
            buyTypt: 'normal',
            courseInx: -1,
            companions: [],
            statistics: {},
            CourseComment: {},
            ActPintuan: {},
            sign_states: {
                0: '火热招生中',
                1: '少量名额',
                2: '已满员'
            },
            toPintuan: false,
            modalName: '',
            customerService: {},
            member: {}
        }, _this.$repeat = {}, _this.$props = { "cSwiper": { "xmlns:v-bind": "", "v-bind:model.sync": "swipers" }, "ctitle": { "v-bind:model.sync": "courseInfo" }, "cInfo": { "v-bind:model.sync": "courseInfo", "v-bind:companions.sync": "companions" }, "cRemake": { "v-bind:model.sync": "courseInfo", "v-bind:statistics.sync": "statistics", "v-bind:CourseComment.sync": "CourseComment" } }, _this.$events = {}, _this.components = {
            cSwiper: _swiper2.default,
            ctitle: _title2.default,
            cInfo: _info2.default,
            cRemake: _remake2.default,
            contact: _contact2.default
        }, _this.config = {
            navigationBarTitleText: "活动详情"
        }, _this.methods = {
            call: function call(phoneNumber) {
                wx.makePhoneCall({
                    phoneNumber: phoneNumber //仅为示例，并非真实的电话号码
                });
            },
            cont: function cont() {
                this.modalName = 'bottomModal';
            },
            tocut: function () {
                var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(e) {
                    return regeneratorRuntime.wrap(function _callee$(_context) {
                        while (1) {
                            switch (_context.prev = _context.next) {
                                case 0:
                                    if (!(e.detail.errMsg == "getUserInfo:ok")) {
                                        _context.next = 5;
                                        break;
                                    }

                                    _context.next = 3;
                                    return _auth2.default.getUserinfo(e.detail);

                                case 3:
                                    this.sku('bargain');
                                    this.$apply();

                                case 5:
                                case "end":
                                    return _context.stop();
                            }
                        }
                    }, _callee, this);
                }));

                function tocut(_x) {
                    return _ref2.apply(this, arguments);
                }

                return tocut;
            }(),
            createImg: function () {
                var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(e) {
                    return regeneratorRuntime.wrap(function _callee2$(_context2) {
                        while (1) {
                            switch (_context2.prev = _context2.next) {
                                case 0:
                                    if (!(e.detail.errMsg == "getUserInfo:ok")) {
                                        _context2.next = 5;
                                        break;
                                    }

                                    _context2.next = 3;
                                    return _auth2.default.getUserinfo(e.detail);

                                case 3:
                                    _utils2.default.save('shareInfo', {
                                        course: this.courseInfo,
                                        path: 'pages/detaile/detaile',
                                        id: this.courseInfo.id
                                    });
                                    _wepy2.default.navigateTo({
                                        url: '/pages/home/share'
                                    });

                                case 5:
                                case "end":
                                    return _context2.stop();
                            }
                        }
                    }, _callee2, this);
                }));

                function createImg(_x2) {
                    return _ref3.apply(this, arguments);
                }

                return createImg;
            }(),
            toshare: function toshare() {
                this.modalName = 'share';
            },
            toPintuanfy: function toPintuanfy() {
                this.toPintuan = true;
            },
            bargain: function () {
                var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
                    var _ref5, errcode, errmsg, data;

                    return regeneratorRuntime.wrap(function _callee3$(_context3) {
                        while (1) {
                            switch (_context3.prev = _context3.next) {
                                case 0:
                                    if (!(this.courseInx == -1)) {
                                        _context3.next = 3;
                                        break;
                                    }

                                    _Tips2.default.toast("请选择一个营期", function (res) {}, 'none');
                                    return _context3.abrupt("return", false);

                                case 3:
                                    _context3.next = 5;
                                    return _config2.default.regBargain({
                                        bargainId: this.courseInfo.bargainId,
                                        courseId: this.courseInfo.id,
                                        periodId: this.courseInfo.periodList[this.courseInx].id
                                    });

                                case 5:
                                    _ref5 = _context3.sent;
                                    errcode = _ref5.errcode;
                                    errmsg = _ref5.errmsg;
                                    data = _ref5.data;

                                    if (errcode == 200) {
                                        _wepy2.default.redirectTo({
                                            url: '/pages/activity/bargain?id=' + data.regId
                                        });
                                    } else {
                                        // 发起砍价异常
                                        _Tips2.default.toast(errmsg, function (res) {
                                            _wepy2.default.redirectTo({
                                                url: '/pages/activity/bargain?id=' + data.actBargainReg.id
                                            });
                                        }, 'none');
                                    }

                                case 10:
                                case "end":
                                    return _context3.stop();
                            }
                        }
                    }, _callee3, this);
                }));

                function bargain() {
                    return _ref4.apply(this, arguments);
                }

                return bargain;
            }(),
            ret: function ret() {
                return false;
            },
            tabSelect: function tabSelect(e) {
                console.log(e);
                this.TabCur = e.currentTarget.dataset.id || e.detail.current;
            },
            hideModal: function hideModal() {
                this.toPintuan = false;
                this.showSku = false;
                this.modalName = '';
            },
            sku: function sku(type) {
                this.sku(type);
            },
            plus: function plus() {
                if (this.buyTypt == 'bargain') {
                    return false;
                }
                wx.vibrateShort();
                this.num = this.num + 1;
            },
            minus: function minus() {
                if (this.num > 1) {
                    wx.vibrateShort();
                    this.num = this.num - 1;
                }
            },
            course: function course(inx) {
                this.courseInx = inx;
            },
            buy: function () {
                var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
                    var aid = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;
                    var ot = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1;
                    return regeneratorRuntime.wrap(function _callee4$(_context4) {
                        while (1) {
                            switch (_context4.prev = _context4.next) {
                                case 0:
                                    if (!(this.courseInx == -1)) {
                                        _context4.next = 3;
                                        break;
                                    }

                                    _Tips2.default.toast("请选择一个营期", function (res) {}, 'none');
                                    return _context4.abrupt("return", false);

                                case 3:
                                    // if(ot == 2){
                                    //     // 砍价
                                    //     aid = this.courseInfo.bargainId
                                    // }
                                    // if(ot == 3){
                                    //     // 拼团
                                    //     aid = this.courseInfo.pintuanId
                                    // }
                                    _wepy2.default.navigateTo({
                                        url: "./sureOrder?type=" + ot + "&pid=" + this.courseInfo.periodList[this.courseInx].id + "&cid=" + this.courseInfo.id + "&num=" + this.num + "&aid=" + aid + "&actpid=" + this.courseInfo.pintuanId
                                    });

                                case 4:
                                case "end":
                                    return _context4.stop();
                            }
                        }
                    }, _callee4, this);
                }));

                function buy() {
                    return _ref6.apply(this, arguments);
                }

                return buy;
            }()
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(Dialog, [{
        key: "onShareAppMessage",

        // 转发暂时先不开启
        value: function onShareAppMessage(res) {
            if (res.from === 'button') {
                // 来自页面内转发按钮
                console.log(res.target);
            }
            return {
                title: this.courseInfo.courseTittle,
                path: '/pages/detaile/detaile?id=' + this.courseInfo.id + '&agentId=' + this.member.agentId
            };
        }
    }, {
        key: "onLoad",
        value: function () {
            var _ref7 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5(opt) {
                var _this2 = this;

                var view, _ref8, course, companions, statistics, CourseComment, actPintuan, customerService;

                return regeneratorRuntime.wrap(function _callee5$(_context5) {
                    while (1) {
                        switch (_context5.prev = _context5.next) {
                            case 0:
                                console.log(opt);
                                // 获取主内容高度，用于悬浮详情导航
                                view = wx.createSelectorQuery().select("#info-box");

                                view.fields({
                                    size: true
                                }, function (data) {
                                    console.log(data.height);
                                    _this2.mainHeight = data.height;
                                }).exec();
                                _context5.next = 5;
                                return _auth2.default.login();

                            case 5:
                                this.member = _wepy2.default.getStorageSync('member');
                                _context5.next = 8;
                                return _config2.default.getCourseInfo(opt.id || opt.scene);

                            case 8:
                                _ref8 = _context5.sent;
                                course = _ref8.course;
                                companions = _ref8.companions;
                                statistics = _ref8.statistics;
                                CourseComment = _ref8.CourseComment;
                                actPintuan = _ref8.actPintuan;
                                customerService = _ref8.customerService;

                                this.swipers.list = course.pics;
                                course.courseChar = course.courseChar.split("|");
                                this.courseInfo = course;
                                this.customerService = customerService;
                                _wepy2.default.$instance.globalData.courseInfo = course;
                                this.companions = companions;
                                this.statistics = statistics;
                                this.CourseComment = CourseComment;
                                this.ActPintuan = actPintuan;
                                console.log(this.ActPintuan);
                                this.$apply();

                            case 26:
                            case "end":
                                return _context5.stop();
                        }
                    }
                }, _callee5, this);
            }));

            function onLoad(_x5) {
                return _ref7.apply(this, arguments);
            }

            return onLoad;
        }()
    }, {
        key: "sku",
        value: function sku() {
            var type = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'normal';

            this.showSku = true;
            this.toPintuan = false;
            this.buyTypt = type;
        }
    }]);

    return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/detaile/detaile'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldGFpbGUuanMiXSwibmFtZXMiOlsiRGlhbG9nIiwiZGF0YSIsIlRhYkN1ciIsImNsb3NlIiwic3dpcGVycyIsInR5cGUiLCJsaXN0IiwiaWQiLCJ1cmwiLCJsaW5rIiwibGlua1R5cGUiLCJtYWluSGVpZ2h0IiwiY291cnNlSW5mbyIsIm5vZGVzIiwibnVtIiwic2hvd1NrdSIsImJ1eVR5cHQiLCJjb3Vyc2VJbngiLCJjb21wYW5pb25zIiwic3RhdGlzdGljcyIsIkNvdXJzZUNvbW1lbnQiLCJBY3RQaW50dWFuIiwic2lnbl9zdGF0ZXMiLCJ0b1BpbnR1YW4iLCJtb2RhbE5hbWUiLCJjdXN0b21lclNlcnZpY2UiLCJtZW1iZXIiLCIkcmVwZWF0IiwiJHByb3BzIiwiJGV2ZW50cyIsImNvbXBvbmVudHMiLCJjU3dpcGVyIiwiY3RpdGxlIiwiY0luZm8iLCJjUmVtYWtlIiwiY29udGFjdCIsImNvbmZpZyIsIm5hdmlnYXRpb25CYXJUaXRsZVRleHQiLCJtZXRob2RzIiwiY2FsbCIsInBob25lTnVtYmVyIiwid3giLCJtYWtlUGhvbmVDYWxsIiwiY29udCIsInRvY3V0IiwiZSIsImRldGFpbCIsImVyck1zZyIsImF1dGgiLCJnZXRVc2VyaW5mbyIsInNrdSIsIiRhcHBseSIsImNyZWF0ZUltZyIsInN0b3JlIiwic2F2ZSIsImNvdXJzZSIsInBhdGgiLCJ3ZXB5IiwibmF2aWdhdGVUbyIsInRvc2hhcmUiLCJ0b1BpbnR1YW5meSIsImJhcmdhaW4iLCJUaXBzIiwidG9hc3QiLCJyZWdCYXJnYWluIiwiYmFyZ2FpbklkIiwiY291cnNlSWQiLCJwZXJpb2RJZCIsInBlcmlvZExpc3QiLCJlcnJjb2RlIiwiZXJybXNnIiwicmVkaXJlY3RUbyIsInJlZ0lkIiwiYWN0QmFyZ2FpblJlZyIsInJldCIsInRhYlNlbGVjdCIsImNvbnNvbGUiLCJsb2ciLCJjdXJyZW50VGFyZ2V0IiwiZGF0YXNldCIsImN1cnJlbnQiLCJoaWRlTW9kYWwiLCJwbHVzIiwidmlicmF0ZVNob3J0IiwibWludXMiLCJpbngiLCJidXkiLCJhaWQiLCJvdCIsInBpbnR1YW5JZCIsInJlcyIsImZyb20iLCJ0YXJnZXQiLCJ0aXRsZSIsImNvdXJzZVRpdHRsZSIsImFnZW50SWQiLCJvcHQiLCJ2aWV3IiwiY3JlYXRlU2VsZWN0b3JRdWVyeSIsInNlbGVjdCIsImZpZWxkcyIsInNpemUiLCJoZWlnaHQiLCJleGVjIiwibG9naW4iLCJnZXRTdG9yYWdlU3luYyIsImdldENvdXJzZUluZm8iLCJzY2VuZSIsImFjdFBpbnR1YW4iLCJwaWNzIiwiY291cnNlQ2hhciIsInNwbGl0IiwiJGluc3RhbmNlIiwiZ2xvYmFsRGF0YSIsInBhZ2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUNJOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7Ozs7Ozs7Ozs7O0lBQ3FCQSxNOzs7Ozs7Ozs7Ozs7OzswTEFDakJDLEksR0FBTztBQUNIQyxvQkFBUSxDQURMO0FBRUhDLG1CQUFPLDBCQUZKO0FBR0hDLHFCQUFTO0FBQ0xDLHNCQUFNLENBREQ7QUFFTEMsc0JBQU0sQ0FBQztBQUNIQyx3QkFBSSxDQUREO0FBRUhGLDBCQUFNLE9BRkg7QUFHSEcseUJBQUssRUFIRjtBQUlIQywwQkFBTSxrQkFKSDtBQUtIQyw4QkFBVTtBQUxQLGlCQUFEO0FBRkQsYUFITjtBQWFIQyx3QkFBWSxDQWJUO0FBY0hDLHdCQUFZLEVBZFQ7QUFlSEMsbUJBQU8sQ0FBQyxNQUFELEVBQVMsT0FBVCxFQUFrQixPQUFsQixDQWZKO0FBZ0JIQyxpQkFBSyxDQWhCRjtBQWlCSEMscUJBQVMsS0FqQk47QUFrQkhDLHFCQUFTLFFBbEJOO0FBbUJIQyx1QkFBVyxDQUFDLENBbkJUO0FBb0JIQyx3QkFBWSxFQXBCVDtBQXFCSEMsd0JBQVksRUFyQlQ7QUFzQkhDLDJCQUFlLEVBdEJaO0FBdUJIQyx3QkFBWSxFQXZCVDtBQXdCSEMseUJBQWE7QUFDVCxtQkFBRyxPQURNO0FBRVQsbUJBQUcsTUFGTTtBQUdULG1CQUFHO0FBSE0sYUF4QlY7QUE2QkhDLHVCQUFXLEtBN0JSO0FBOEJIQyx1QkFBVyxFQTlCUjtBQStCSEMsNkJBQWlCLEVBL0JkO0FBZ0NIQyxvQkFBTztBQWhDSixTLFFBa0NSQyxPLEdBQVUsRSxRQUNqQkMsTSxHQUFTLEVBQUMsV0FBVSxFQUFDLGdCQUFlLEVBQWhCLEVBQW1CLHFCQUFvQixTQUF2QyxFQUFYLEVBQTZELFVBQVMsRUFBQyxxQkFBb0IsWUFBckIsRUFBdEUsRUFBeUcsU0FBUSxFQUFDLHFCQUFvQixZQUFyQixFQUFrQywwQkFBeUIsWUFBM0QsRUFBakgsRUFBMEwsV0FBVSxFQUFDLHFCQUFvQixZQUFyQixFQUFrQywwQkFBeUIsWUFBM0QsRUFBd0UsNkJBQTRCLGVBQXBHLEVBQXBNLEUsUUFDVEMsTyxHQUFVLEUsUUFDVEMsVSxHQUFhO0FBQ0ZDLHFDQURFO0FBRUZDLG1DQUZFO0FBR0ZDLGlDQUhFO0FBSUZDLHFDQUpFO0FBS0ZDO0FBTEUsUyxRQU9OQyxNLEdBQVM7QUFDTEMsb0NBQXdCO0FBRG5CLFMsUUF1RFRDLE8sR0FBVTtBQUNOQyxnQkFETSxnQkFDREMsV0FEQyxFQUNZO0FBQ2RDLG1CQUFHQyxhQUFILENBQWlCO0FBQ2JGLDRDQURhLENBQ0Q7QUFEQyxpQkFBakI7QUFHSCxhQUxLO0FBTU5HLGdCQU5NLGtCQU1DO0FBQ0gscUJBQUtuQixTQUFMLEdBQWlCLGFBQWpCO0FBQ0gsYUFSSztBQVNBb0IsaUJBVEE7QUFBQSxxR0FTTUMsQ0FUTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMENBVUVBLEVBQUVDLE1BQUYsQ0FBU0MsTUFBVCxJQUFtQixnQkFWckI7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQSwyQ0FXUUMsZUFBS0MsV0FBTCxDQUFpQkosRUFBRUMsTUFBbkIsQ0FYUjs7QUFBQTtBQVlFLHlDQUFLSSxHQUFMLENBQVMsU0FBVDtBQUNBLHlDQUFLQyxNQUFMOztBQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBZ0JBQyxxQkFoQkE7QUFBQSxzR0FnQlVQLENBaEJWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQ0FpQkVBLEVBQUVDLE1BQUYsQ0FBU0MsTUFBVCxJQUFtQixnQkFqQnJCO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUEsMkNBa0JRQyxlQUFLQyxXQUFMLENBQWlCSixFQUFFQyxNQUFuQixDQWxCUjs7QUFBQTtBQW1CRU8sb0RBQU1DLElBQU4sQ0FBVyxXQUFYLEVBQXdCO0FBQ3BCQyxnREFBUSxLQUFLM0MsVUFETztBQUVwQjRDLDhDQUFNLHVCQUZjO0FBR3BCakQsNENBQUksS0FBS0ssVUFBTCxDQUFnQkw7QUFIQSxxQ0FBeEI7QUFLQWtELG1EQUFLQyxVQUFMLENBQWdCO0FBQ1psRCw2Q0FBSztBQURPLHFDQUFoQjs7QUF4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUE2Qk5tRCxtQkE3Qk0scUJBNkJJO0FBQ04scUJBQUtuQyxTQUFMLEdBQWlCLE9BQWpCO0FBQ0gsYUEvQks7QUFnQ05vQyx1QkFoQ00seUJBZ0NRO0FBQ1YscUJBQUtyQyxTQUFMLEdBQWlCLElBQWpCO0FBQ0gsYUFsQ0s7QUFtQ0FzQyxtQkFuQ0E7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMENBb0NFLEtBQUs1QyxTQUFMLElBQWtCLENBQUMsQ0FwQ3JCO0FBQUE7QUFBQTtBQUFBOztBQXFDRTZDLG1EQUFLQyxLQUFMLENBQVcsU0FBWCxFQUFzQixlQUFPLENBQUUsQ0FBL0IsRUFBaUMsTUFBakM7QUFyQ0Ysc0VBc0NTLEtBdENUOztBQUFBO0FBQUE7QUFBQSwyQ0E0Q1EzQixpQkFBTzRCLFVBQVAsQ0FBa0I7QUFDeEJDLG1EQUFXLEtBQUtyRCxVQUFMLENBQWdCcUQsU0FESDtBQUV4QkMsa0RBQVUsS0FBS3RELFVBQUwsQ0FBZ0JMLEVBRkY7QUFHeEI0RCxrREFBVSxLQUFLdkQsVUFBTCxDQUFnQndELFVBQWhCLENBQTJCLEtBQUtuRCxTQUFoQyxFQUEyQ1Y7QUFIN0IscUNBQWxCLENBNUNSOztBQUFBO0FBQUE7QUF5Q0U4RCwyQ0F6Q0YsU0F5Q0VBLE9BekNGO0FBMENFQywwQ0ExQ0YsU0EwQ0VBLE1BMUNGO0FBMkNFckUsd0NBM0NGLFNBMkNFQSxJQTNDRjs7QUFpREYsd0NBQUlvRSxXQUFXLEdBQWYsRUFBb0I7QUFDaEJaLHVEQUFLYyxVQUFMLENBQWdCO0FBQ1ovRCxpREFBSyxnQ0FBZ0NQLEtBQUt1RTtBQUQ5Qix5Q0FBaEI7QUFHSCxxQ0FKRCxNQUlPO0FBQ0g7QUFDQVYsdURBQUtDLEtBQUwsQ0FBV08sTUFBWCxFQUFtQixlQUFPO0FBQ3RCYiwyREFBS2MsVUFBTCxDQUFnQjtBQUNaL0QscURBQUssZ0NBQWdDUCxLQUFLd0UsYUFBTCxDQUFtQmxFO0FBRDVDLDZDQUFoQjtBQUdILHlDQUpELEVBSUcsTUFKSDtBQUtIOztBQTVEQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQThETm1FLGVBOURNLGlCQThEQTtBQUNGLHVCQUFPLEtBQVA7QUFDSCxhQWhFSztBQWlFTkMscUJBakVNLHFCQWlFSTlCLENBakVKLEVBaUVPO0FBQ1QrQix3QkFBUUMsR0FBUixDQUFZaEMsQ0FBWjtBQUNBLHFCQUFLM0MsTUFBTCxHQUFjMkMsRUFBRWlDLGFBQUYsQ0FBZ0JDLE9BQWhCLENBQXdCeEUsRUFBeEIsSUFBOEJzQyxFQUFFQyxNQUFGLENBQVNrQyxPQUFyRDtBQUNILGFBcEVLO0FBcUVOQyxxQkFyRU0sdUJBcUVNO0FBQ1IscUJBQUsxRCxTQUFMLEdBQWlCLEtBQWpCO0FBQ0EscUJBQUtSLE9BQUwsR0FBZSxLQUFmO0FBQ0EscUJBQUtTLFNBQUwsR0FBaUIsRUFBakI7QUFDSCxhQXpFSztBQTBFTjBCLGVBMUVNLGVBMEVGN0MsSUExRUUsRUEwRUk7QUFDTixxQkFBSzZDLEdBQUwsQ0FBUzdDLElBQVQ7QUFDSCxhQTVFSztBQTZFTjZFLGdCQTdFTSxrQkE2RUM7QUFDSCxvQkFBSSxLQUFLbEUsT0FBTCxJQUFnQixTQUFwQixFQUErQjtBQUMzQiwyQkFBTyxLQUFQO0FBQ0g7QUFDRHlCLG1CQUFHMEMsWUFBSDtBQUNBLHFCQUFLckUsR0FBTCxHQUFXLEtBQUtBLEdBQUwsR0FBVyxDQUF0QjtBQUNILGFBbkZLO0FBb0ZOc0UsaUJBcEZNLG1CQW9GRTtBQUNKLG9CQUFJLEtBQUt0RSxHQUFMLEdBQVcsQ0FBZixFQUFrQjtBQUNkMkIsdUJBQUcwQyxZQUFIO0FBQ0EseUJBQUtyRSxHQUFMLEdBQVcsS0FBS0EsR0FBTCxHQUFXLENBQXRCO0FBQ0g7QUFDSixhQXpGSztBQTBGTnlDLGtCQTFGTSxrQkEwRkM4QixHQTFGRCxFQTBGTTtBQUNSLHFCQUFLcEUsU0FBTCxHQUFpQm9FLEdBQWpCO0FBQ0gsYUE1Rks7QUE2RkFDLGVBN0ZBO0FBQUE7QUFBQSx3QkE2RklDLEdBN0ZKLHVFQTZGVSxDQTdGVjtBQUFBLHdCQTZGYUMsRUE3RmIsdUVBNkZrQixDQTdGbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBDQThGRSxLQUFLdkUsU0FBTCxJQUFrQixDQUFDLENBOUZyQjtBQUFBO0FBQUE7QUFBQTs7QUErRkU2QyxtREFBS0MsS0FBTCxDQUFXLFNBQVgsRUFBc0IsZUFBTyxDQUFFLENBQS9CLEVBQWlDLE1BQWpDO0FBL0ZGLHNFQWdHUyxLQWhHVDs7QUFBQTtBQWtHRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0FOLG1EQUFLQyxVQUFMLENBQWdCO0FBQ1psRCxtRUFBeUJnRixFQUF6QixhQUFtQyxLQUFLNUUsVUFBTCxDQUFnQndELFVBQWhCLENBQTJCLEtBQUtuRCxTQUFoQyxFQUEyQ1YsRUFBOUUsYUFBd0YsS0FBS0ssVUFBTCxDQUFnQkwsRUFBeEcsYUFBa0gsS0FBS08sR0FBdkgsYUFBa0l5RSxHQUFsSSxnQkFBZ0osS0FBSzNFLFVBQUwsQ0FBZ0I2RTtBQURwSixxQ0FBaEI7O0FBMUdFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUEsUzs7Ozs7O0FBcERWOzBDQUNrQkMsRyxFQUFLO0FBQ25CLGdCQUFJQSxJQUFJQyxJQUFKLEtBQWEsUUFBakIsRUFBMkI7QUFDdkI7QUFDQWYsd0JBQVFDLEdBQVIsQ0FBWWEsSUFBSUUsTUFBaEI7QUFDSDtBQUNELG1CQUFPO0FBQ0hDLHVCQUFPLEtBQUtqRixVQUFMLENBQWdCa0YsWUFEcEI7QUFFSHRDLHNCQUFNLCtCQUErQixLQUFLNUMsVUFBTCxDQUFnQkwsRUFBL0MsR0FBb0QsV0FBcEQsR0FBa0UsS0FBS21CLE1BQUwsQ0FBWXFFO0FBRmpGLGFBQVA7QUFJSDs7OztrR0FDWUMsRzs7Ozs7Ozs7O0FBQ1RwQix3Q0FBUUMsR0FBUixDQUFZbUIsR0FBWjtBQUNBO0FBQ0lDLG9DLEdBQU94RCxHQUFHeUQsbUJBQUgsR0FBeUJDLE1BQXpCLENBQWdDLFdBQWhDLEM7O0FBQ1hGLHFDQUNLRyxNQURMLENBQ1k7QUFDQUMsMENBQU07QUFETixpQ0FEWixFQUlRLGdCQUFRO0FBQ0p6Qiw0Q0FBUUMsR0FBUixDQUFZNUUsS0FBS3FHLE1BQWpCO0FBQ0EsMkNBQUszRixVQUFMLEdBQWtCVixLQUFLcUcsTUFBdkI7QUFDSCxpQ0FQVCxFQVNLQyxJQVRMOzt1Q0FVTXZELGVBQUt3RCxLQUFMLEU7OztBQUNOLHFDQUFLOUUsTUFBTCxHQUFjK0IsZUFBS2dELGNBQUwsQ0FBb0IsUUFBcEIsQ0FBZDs7dUNBUVVyRSxpQkFBT3NFLGFBQVAsQ0FBcUJWLElBQUl6RixFQUFKLElBQVV5RixJQUFJVyxLQUFuQyxDOzs7O0FBTk5wRCxzQyxTQUFBQSxNO0FBQ0FyQywwQyxTQUFBQSxVO0FBQ0FDLDBDLFNBQUFBLFU7QUFDQUMsNkMsU0FBQUEsYTtBQUNBd0YsMEMsU0FBQUEsVTtBQUNBbkYsK0MsU0FBQUEsZTs7QUFFSixxQ0FBS3JCLE9BQUwsQ0FBYUUsSUFBYixHQUFvQmlELE9BQU9zRCxJQUEzQjtBQUNBdEQsdUNBQU91RCxVQUFQLEdBQW9CdkQsT0FBT3VELFVBQVAsQ0FBa0JDLEtBQWxCLENBQXdCLEdBQXhCLENBQXBCO0FBQ0EscUNBQUtuRyxVQUFMLEdBQWtCMkMsTUFBbEI7QUFDQSxxQ0FBSzlCLGVBQUwsR0FBdUJBLGVBQXZCO0FBQ0FnQywrQ0FBS3VELFNBQUwsQ0FBZUMsVUFBZixDQUEwQnJHLFVBQTFCLEdBQXVDMkMsTUFBdkM7QUFDQSxxQ0FBS3JDLFVBQUwsR0FBa0JBLFVBQWxCO0FBQ0EscUNBQUtDLFVBQUwsR0FBa0JBLFVBQWxCO0FBQ0EscUNBQUtDLGFBQUwsR0FBcUJBLGFBQXJCO0FBQ0EscUNBQUtDLFVBQUwsR0FBa0J1RixVQUFsQjtBQUNBaEMsd0NBQVFDLEdBQVIsQ0FBWSxLQUFLeEQsVUFBakI7QUFDQSxxQ0FBSzhCLE1BQUw7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs4QkFFaUI7QUFBQSxnQkFBakI5QyxJQUFpQix1RUFBVixRQUFVOztBQUNqQixpQkFBS1UsT0FBTCxHQUFlLElBQWY7QUFDQSxpQkFBS1EsU0FBTCxHQUFpQixLQUFqQjtBQUNBLGlCQUFLUCxPQUFMLEdBQWVYLElBQWY7QUFDSDs7OztFQW5HK0JvRCxlQUFLeUQsSTs7a0JBQXBCbEgsTSIsImZpbGUiOiJkZXRhaWxlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbiAgICBpbXBvcnQgd2VweSBmcm9tIFwid2VweVwiO1xyXG4gICAgaW1wb3J0IGNTd2lwZXIgZnJvbSBcIkAvY29tcG9uZW50cy9jb21tb24vc3dpcGVyXCI7XHJcbiAgICBpbXBvcnQgY3RpdGxlIGZyb20gXCJAL2NvbXBvbmVudHMvZGV0YWlsZS90aXRsZVwiO1xyXG4gICAgaW1wb3J0IGNJbmZvIGZyb20gXCJAL2NvbXBvbmVudHMvZGV0YWlsZS9pbmZvXCI7XHJcbiAgICBpbXBvcnQgY1JlbWFrZSBmcm9tIFwiQC9jb21wb25lbnRzL2RldGFpbGUvcmVtYWtlXCI7XHJcbiAgICBpbXBvcnQgY29udGFjdCBmcm9tIFwiQC9jb21wb25lbnRzL2NvbW1vbi9jb250YWN0XCJcclxuICAgIGltcG9ydCBzdG9yZSBmcm9tIFwiQC9zdG9yZS91dGlsc1wiXHJcbiAgICBpbXBvcnQgY29uZmlnIGZyb20gXCJAL2FwaS9jb25maWdcIjtcclxuICAgIGltcG9ydCBhdXRoIGZyb20gXCJAL2FwaS9hdXRoXCI7XHJcbiAgICBpbXBvcnQgV3hVdGlscyBmcm9tIFwiQC91dGlscy9XeFV0aWxzXCI7XHJcbiAgICBpbXBvcnQgVGlwcyBmcm9tIFwiQC91dGlscy9UaXBzXCI7XHJcbiAgICBleHBvcnQgZGVmYXVsdCBjbGFzcyBEaWFsb2cgZXh0ZW5kcyB3ZXB5LnBhZ2Uge1xyXG4gICAgICAgIGRhdGEgPSB7XHJcbiAgICAgICAgICAgIFRhYkN1cjogMCxcclxuICAgICAgICAgICAgY2xvc2U6IFwiL3N0YXRpYy9pbWFnZXMvY2xvc2UucG5nXCIsXHJcbiAgICAgICAgICAgIHN3aXBlcnM6IHtcclxuICAgICAgICAgICAgICAgIHR5cGU6IDEsXHJcbiAgICAgICAgICAgICAgICBsaXN0OiBbe1xyXG4gICAgICAgICAgICAgICAgICAgIGlkOiAwLFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU6IFwiaW1hZ2VcIixcclxuICAgICAgICAgICAgICAgICAgICB1cmw6IFwiXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgbGluazogXCIvcGFnZXMvbWVldC9tZWV0XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgbGlua1R5cGU6IFwic3dpdGNoVGFiXCJcclxuICAgICAgICAgICAgICAgIH1dXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIG1haW5IZWlnaHQ6IDAsXHJcbiAgICAgICAgICAgIGNvdXJzZUluZm86IHt9LFxyXG4gICAgICAgICAgICBub2RlczogW1wibmFtZVwiLCBcImF0dHJzXCIsIFwiYXR0cnNcIl0sXHJcbiAgICAgICAgICAgIG51bTogMSxcclxuICAgICAgICAgICAgc2hvd1NrdTogZmFsc2UsXHJcbiAgICAgICAgICAgIGJ1eVR5cHQ6ICdub3JtYWwnLFxyXG4gICAgICAgICAgICBjb3Vyc2VJbng6IC0xLFxyXG4gICAgICAgICAgICBjb21wYW5pb25zOiBbXSxcclxuICAgICAgICAgICAgc3RhdGlzdGljczoge30sXHJcbiAgICAgICAgICAgIENvdXJzZUNvbW1lbnQ6IHt9LFxyXG4gICAgICAgICAgICBBY3RQaW50dWFuOiB7fSxcclxuICAgICAgICAgICAgc2lnbl9zdGF0ZXM6IHtcclxuICAgICAgICAgICAgICAgIDA6ICfngavng63mi5vnlJ/kuK0nLFxyXG4gICAgICAgICAgICAgICAgMTogJ+WwkemHj+WQjeminScsXHJcbiAgICAgICAgICAgICAgICAyOiAn5bey5ruh5ZGYJ1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB0b1BpbnR1YW46IGZhbHNlLFxyXG4gICAgICAgICAgICBtb2RhbE5hbWU6ICcnLFxyXG4gICAgICAgICAgICBjdXN0b21lclNlcnZpY2U6IHt9LFxyXG4gICAgICAgICAgICBtZW1iZXI6e31cclxuICAgICAgICB9O1xyXG4gICAgICAgJHJlcGVhdCA9IHt9O1xyXG4kcHJvcHMgPSB7XCJjU3dpcGVyXCI6e1wieG1sbnM6di1iaW5kXCI6XCJcIixcInYtYmluZDptb2RlbC5zeW5jXCI6XCJzd2lwZXJzXCJ9LFwiY3RpdGxlXCI6e1widi1iaW5kOm1vZGVsLnN5bmNcIjpcImNvdXJzZUluZm9cIn0sXCJjSW5mb1wiOntcInYtYmluZDptb2RlbC5zeW5jXCI6XCJjb3Vyc2VJbmZvXCIsXCJ2LWJpbmQ6Y29tcGFuaW9ucy5zeW5jXCI6XCJjb21wYW5pb25zXCJ9LFwiY1JlbWFrZVwiOntcInYtYmluZDptb2RlbC5zeW5jXCI6XCJjb3Vyc2VJbmZvXCIsXCJ2LWJpbmQ6c3RhdGlzdGljcy5zeW5jXCI6XCJzdGF0aXN0aWNzXCIsXCJ2LWJpbmQ6Q291cnNlQ29tbWVudC5zeW5jXCI6XCJDb3Vyc2VDb21tZW50XCJ9fTtcclxuJGV2ZW50cyA9IHt9O1xyXG4gY29tcG9uZW50cyA9IHtcclxuICAgICAgICAgICAgY1N3aXBlcixcclxuICAgICAgICAgICAgY3RpdGxlLFxyXG4gICAgICAgICAgICBjSW5mbyxcclxuICAgICAgICAgICAgY1JlbWFrZSxcclxuICAgICAgICAgICAgY29udGFjdFxyXG4gICAgICAgIH07XHJcbiAgICAgICAgY29uZmlnID0ge1xyXG4gICAgICAgICAgICBuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0OiBcIua0u+WKqOivpuaDhVwiXHJcbiAgICAgICAgfTtcclxuICAgICAgICAvLyDovazlj5HmmoLml7blhYjkuI3lvIDlkK9cclxuICAgICAgICBvblNoYXJlQXBwTWVzc2FnZShyZXMpIHtcclxuICAgICAgICAgICAgaWYgKHJlcy5mcm9tID09PSAnYnV0dG9uJykge1xyXG4gICAgICAgICAgICAgICAgLy8g5p2l6Ieq6aG16Z2i5YaF6L2s5Y+R5oyJ6ZKuXHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhyZXMudGFyZ2V0KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICB0aXRsZTogdGhpcy5jb3Vyc2VJbmZvLmNvdXJzZVRpdHRsZSxcclxuICAgICAgICAgICAgICAgIHBhdGg6ICcvcGFnZXMvZGV0YWlsZS9kZXRhaWxlP2lkPScgKyB0aGlzLmNvdXJzZUluZm8uaWQgKyAnJmFnZW50SWQ9JyArIHRoaXMubWVtYmVyLmFnZW50SWQgXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgYXN5bmMgb25Mb2FkKG9wdCkge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhvcHQpXHJcbiAgICAgICAgICAgIC8vIOiOt+WPluS4u+WGheWuuemrmOW6pu+8jOeUqOS6juaCrOa1ruivpuaDheWvvOiIqlxyXG4gICAgICAgICAgICBsZXQgdmlldyA9IHd4LmNyZWF0ZVNlbGVjdG9yUXVlcnkoKS5zZWxlY3QoXCIjaW5mby1ib3hcIik7XHJcbiAgICAgICAgICAgIHZpZXdcclxuICAgICAgICAgICAgICAgIC5maWVsZHMoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzaXplOiB0cnVlXHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICBkYXRhID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZGF0YS5oZWlnaHQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm1haW5IZWlnaHQgPSBkYXRhLmhlaWdodDtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAuZXhlYygpO1xyXG4gICAgICAgICAgICBhd2FpdCBhdXRoLmxvZ2luKClcclxuICAgICAgICAgICAgdGhpcy5tZW1iZXIgPSB3ZXB5LmdldFN0b3JhZ2VTeW5jKCdtZW1iZXInKTtcclxuICAgICAgICAgICAgbGV0IHtcclxuICAgICAgICAgICAgICAgIGNvdXJzZSxcclxuICAgICAgICAgICAgICAgIGNvbXBhbmlvbnMsXHJcbiAgICAgICAgICAgICAgICBzdGF0aXN0aWNzLFxyXG4gICAgICAgICAgICAgICAgQ291cnNlQ29tbWVudCxcclxuICAgICAgICAgICAgICAgIGFjdFBpbnR1YW4sXHJcbiAgICAgICAgICAgICAgICBjdXN0b21lclNlcnZpY2VcclxuICAgICAgICAgICAgfSA9IGF3YWl0IGNvbmZpZy5nZXRDb3Vyc2VJbmZvKG9wdC5pZCB8fCBvcHQuc2NlbmUpXHJcbiAgICAgICAgICAgIHRoaXMuc3dpcGVycy5saXN0ID0gY291cnNlLnBpY3NcclxuICAgICAgICAgICAgY291cnNlLmNvdXJzZUNoYXIgPSBjb3Vyc2UuY291cnNlQ2hhci5zcGxpdChcInxcIilcclxuICAgICAgICAgICAgdGhpcy5jb3Vyc2VJbmZvID0gY291cnNlXHJcbiAgICAgICAgICAgIHRoaXMuY3VzdG9tZXJTZXJ2aWNlID0gY3VzdG9tZXJTZXJ2aWNlXHJcbiAgICAgICAgICAgIHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuY291cnNlSW5mbyA9IGNvdXJzZVxyXG4gICAgICAgICAgICB0aGlzLmNvbXBhbmlvbnMgPSBjb21wYW5pb25zXHJcbiAgICAgICAgICAgIHRoaXMuc3RhdGlzdGljcyA9IHN0YXRpc3RpY3NcclxuICAgICAgICAgICAgdGhpcy5Db3Vyc2VDb21tZW50ID0gQ291cnNlQ29tbWVudFxyXG4gICAgICAgICAgICB0aGlzLkFjdFBpbnR1YW4gPSBhY3RQaW50dWFuXHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKHRoaXMuQWN0UGludHVhbilcclxuICAgICAgICAgICAgdGhpcy4kYXBwbHkoKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgc2t1KHR5cGUgPSAnbm9ybWFsJykge1xyXG4gICAgICAgICAgICB0aGlzLnNob3dTa3UgPSB0cnVlXHJcbiAgICAgICAgICAgIHRoaXMudG9QaW50dWFuID0gZmFsc2VcclxuICAgICAgICAgICAgdGhpcy5idXlUeXB0ID0gdHlwZVxyXG4gICAgICAgIH1cclxuICAgICAgICBtZXRob2RzID0ge1xyXG4gICAgICAgICAgICBjYWxsKHBob25lTnVtYmVyKSB7XHJcbiAgICAgICAgICAgICAgICB3eC5tYWtlUGhvbmVDYWxsKHtcclxuICAgICAgICAgICAgICAgICAgICBwaG9uZU51bWJlciAvL+S7heS4uuekuuS+i++8jOW5tumdnuecn+WunueahOeUteivneWPt+eggVxyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgY29udCgpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kYWxOYW1lID0gJ2JvdHRvbU1vZGFsJ1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBhc3luYyB0b2N1dChlKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoZS5kZXRhaWwuZXJyTXNnID09IFwiZ2V0VXNlckluZm86b2tcIikge1xyXG4gICAgICAgICAgICAgICAgICAgIGF3YWl0IGF1dGguZ2V0VXNlcmluZm8oZS5kZXRhaWwpXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5za3UoJ2JhcmdhaW4nKVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgYXN5bmMgY3JlYXRlSW1nKGUpIHtcclxuICAgICAgICAgICAgICAgIGlmIChlLmRldGFpbC5lcnJNc2cgPT0gXCJnZXRVc2VySW5mbzpva1wiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYXdhaXQgYXV0aC5nZXRVc2VyaW5mbyhlLmRldGFpbClcclxuICAgICAgICAgICAgICAgICAgICBzdG9yZS5zYXZlKCdzaGFyZUluZm8nLCB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvdXJzZTogdGhpcy5jb3Vyc2VJbmZvLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYXRoOiAncGFnZXMvZGV0YWlsZS9kZXRhaWxlJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IHRoaXMuY291cnNlSW5mby5pZFxyXG4gICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgd2VweS5uYXZpZ2F0ZVRvKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdXJsOiAnL3BhZ2VzL2hvbWUvc2hhcmUnXHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHRvc2hhcmUoKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGFsTmFtZSA9ICdzaGFyZSdcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgdG9QaW50dWFuZnkoKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnRvUGludHVhbiA9IHRydWVcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgYXN5bmMgYmFyZ2FpbigpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmNvdXJzZUlueCA9PSAtMSkge1xyXG4gICAgICAgICAgICAgICAgICAgIFRpcHMudG9hc3QoXCLor7fpgInmi6nkuIDkuKrokKXmnJ9cIiwgcmVzID0+IHt9LCAnbm9uZScpXHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBsZXQge1xyXG4gICAgICAgICAgICAgICAgICAgIGVycmNvZGUsXHJcbiAgICAgICAgICAgICAgICAgICAgZXJybXNnLFxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGFcclxuICAgICAgICAgICAgICAgIH0gPSBhd2FpdCBjb25maWcucmVnQmFyZ2Fpbih7XHJcbiAgICAgICAgICAgICAgICAgICAgYmFyZ2FpbklkOiB0aGlzLmNvdXJzZUluZm8uYmFyZ2FpbklkLFxyXG4gICAgICAgICAgICAgICAgICAgIGNvdXJzZUlkOiB0aGlzLmNvdXJzZUluZm8uaWQsXHJcbiAgICAgICAgICAgICAgICAgICAgcGVyaW9kSWQ6IHRoaXMuY291cnNlSW5mby5wZXJpb2RMaXN0W3RoaXMuY291cnNlSW54XS5pZCxcclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICBpZiAoZXJyY29kZSA9PSAyMDApIHtcclxuICAgICAgICAgICAgICAgICAgICB3ZXB5LnJlZGlyZWN0VG8oe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB1cmw6ICcvcGFnZXMvYWN0aXZpdHkvYmFyZ2Fpbj9pZD0nICsgZGF0YS5yZWdJZFxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAvLyDlj5HotbfnoI3ku7flvILluLhcclxuICAgICAgICAgICAgICAgICAgICBUaXBzLnRvYXN0KGVycm1zZywgcmVzID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgd2VweS5yZWRpcmVjdFRvKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVybDogJy9wYWdlcy9hY3Rpdml0eS9iYXJnYWluP2lkPScgKyBkYXRhLmFjdEJhcmdhaW5SZWcuaWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfSwgJ25vbmUnKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICByZXQoKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgdGFiU2VsZWN0KGUpIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5UYWJDdXIgPSBlLmN1cnJlbnRUYXJnZXQuZGF0YXNldC5pZCB8fCBlLmRldGFpbC5jdXJyZW50O1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBoaWRlTW9kYWwoKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnRvUGludHVhbiA9IGZhbHNlXHJcbiAgICAgICAgICAgICAgICB0aGlzLnNob3dTa3UgPSBmYWxzZVxyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RhbE5hbWUgPSAnJ1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBza3UodHlwZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5za3UodHlwZSlcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgcGx1cygpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmJ1eVR5cHQgPT0gJ2JhcmdhaW4nKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB3eC52aWJyYXRlU2hvcnQoKVxyXG4gICAgICAgICAgICAgICAgdGhpcy5udW0gPSB0aGlzLm51bSArIDFcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgbWludXMoKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5udW0gPiAxKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgd3gudmlicmF0ZVNob3J0KClcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm51bSA9IHRoaXMubnVtIC0gMVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBjb3Vyc2UoaW54KSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNvdXJzZUlueCA9IGlueFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBhc3luYyBidXkoYWlkID0gMCwgb3QgPSAxLCApIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmNvdXJzZUlueCA9PSAtMSkge1xyXG4gICAgICAgICAgICAgICAgICAgIFRpcHMudG9hc3QoXCLor7fpgInmi6nkuIDkuKrokKXmnJ9cIiwgcmVzID0+IHt9LCAnbm9uZScpXHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvLyBpZihvdCA9PSAyKXtcclxuICAgICAgICAgICAgICAgIC8vICAgICAvLyDnoI3ku7dcclxuICAgICAgICAgICAgICAgIC8vICAgICBhaWQgPSB0aGlzLmNvdXJzZUluZm8uYmFyZ2FpbklkXHJcbiAgICAgICAgICAgICAgICAvLyB9XHJcbiAgICAgICAgICAgICAgICAvLyBpZihvdCA9PSAzKXtcclxuICAgICAgICAgICAgICAgIC8vICAgICAvLyDmi7zlm6JcclxuICAgICAgICAgICAgICAgIC8vICAgICBhaWQgPSB0aGlzLmNvdXJzZUluZm8ucGludHVhbklkXHJcbiAgICAgICAgICAgICAgICAvLyB9XHJcbiAgICAgICAgICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICAgICAgICAgIHVybDogYC4vc3VyZU9yZGVyP3R5cGU9JHtvdH0mcGlkPSR7dGhpcy5jb3Vyc2VJbmZvLnBlcmlvZExpc3RbdGhpcy5jb3Vyc2VJbnhdLmlkfSZjaWQ9JHt0aGlzLmNvdXJzZUluZm8uaWR9Jm51bT0ke3RoaXMubnVtfSZhaWQ9JHthaWR9JmFjdHBpZD0ke3RoaXMuY291cnNlSW5mby5waW50dWFuSWR9YFxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9O1xyXG4gICAgfVxyXG4iXX0=