"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _swiper = require('./../../components/common/swiper.js');

var _swiper2 = _interopRequireDefault(_swiper);

var _title = require('./../../components/detaile/title.js');

var _title2 = _interopRequireDefault(_title);

var _info = require('./../../components/detaile/info.js');

var _info2 = _interopRequireDefault(_info);

var _remake = require('./../../components/detaile/remake.js');

var _remake2 = _interopRequireDefault(_remake);

var _utils = require('./../../store/utils.js');

var _utils2 = _interopRequireDefault(_utils);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

var _WxUtils = require('./../../utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
    _inherits(Dialog, _wepy$page);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.data = {
            TabCur: 0,
            close: "/static/images/close.png",
            swipers: {
                type: 1,
                list: [{
                    id: 0,
                    type: "image",
                    url: "",
                    link: "/pages/meet/meet",
                    linkType: "switchTab"
                }]
            },
            mainHeight: 0,
            courseInfo: {},
            nodes: ["name", "attrs", "attrs"],
            num: 1,
            showSku: false,
            buyTypt: 'normal',
            courseInx: -1,
            companions: [],
            statistics: {},
            CourseComment: {},
            ActPintuan: {},
            sign_states: {
                0: '火热招生中',
                1: '少量名额',
                2: '已满员'
            },
            toPintuan: false,
            modalName: ''
        }, _this.$repeat = {}, _this.$props = { "cSwiper": { "xmlns:v-bind": "", "v-bind:model.sync": "swipers" }, "ctitle": { "v-bind:model.sync": "courseInfo" }, "cInfo": { "v-bind:model.sync": "courseInfo", "v-bind:companions.sync": "companions" }, "cRemake": { "v-bind:model.sync": "courseInfo", "v-bind:statistics.sync": "statistics", "v-bind:CourseComment.sync": "CourseComment" } }, _this.$events = {}, _this.components = {
            cSwiper: _swiper2.default,
            ctitle: _title2.default,
            cInfo: _info2.default,
            cRemake: _remake2.default
        }, _this.config = {
            navigationBarTitleText: "活动详情"
        }, _this.methods = {
            createImg: function () {
                var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(e) {
                    return regeneratorRuntime.wrap(function _callee$(_context) {
                        while (1) {
                            switch (_context.prev = _context.next) {
                                case 0:
                                    if (!(e.detail.errMsg == "getUserInfo:ok")) {
                                        _context.next = 5;
                                        break;
                                    }

                                    _context.next = 3;
                                    return _auth2.default.getUserinfo(e.detail);

                                case 3:
                                    _utils2.default.save('shareInfo', {
                                        course: this.courseInfo,
                                        path: 'pages/detaile/detaile',
                                        id: this.courseInfo.id
                                    });
                                    _wepy2.default.navigateTo({
                                        url: '/pages/home/share'
                                    });

                                case 5:
                                case "end":
                                    return _context.stop();
                            }
                        }
                    }, _callee, this);
                }));

                function createImg(_x) {
                    return _ref2.apply(this, arguments);
                }

                return createImg;
            }(),
            toshare: function toshare() {
                this.modalName = 'share';
            },
            toPintuanfy: function toPintuanfy() {
                this.toPintuan = true;
            },
            bargain: function () {
                var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
                    var _ref4, errcode, errmsg, data;

                    return regeneratorRuntime.wrap(function _callee2$(_context2) {
                        while (1) {
                            switch (_context2.prev = _context2.next) {
                                case 0:
                                    if (!(this.courseInx == -1)) {
                                        _context2.next = 3;
                                        break;
                                    }

                                    _Tips2.default.toast("请选择一个营期", function (res) {}, 'none');
                                    return _context2.abrupt("return", false);

                                case 3:
                                    _context2.next = 5;
                                    return _config2.default.regBargain({
                                        bargainId: this.courseInfo.bargainId,
                                        courseId: this.courseInfo.id,
                                        periodId: this.courseInfo.periodList[this.courseInx].id
                                    });

                                case 5:
                                    _ref4 = _context2.sent;
                                    errcode = _ref4.errcode;
                                    errmsg = _ref4.errmsg;
                                    data = _ref4.data;

                                    if (errcode == 200) {
                                        _wepy2.default.redirectTo({
                                            url: '/pages/activity/bargain?id=' + data.regId
                                        });
                                    } else {
                                        // 发起砍价异常
                                        _Tips2.default.toast(errmsg, function (res) {
                                            _wepy2.default.redirectTo({
                                                url: '/pages/activity/bargain?id=' + data.actBargainReg.id
                                            });
                                        }, 'none');
                                    }

                                case 10:
                                case "end":
                                    return _context2.stop();
                            }
                        }
                    }, _callee2, this);
                }));

                function bargain() {
                    return _ref3.apply(this, arguments);
                }

                return bargain;
            }(),
            ret: function ret() {
                return false;
            },
            tabSelect: function tabSelect(e) {
                console.log(e);
                this.TabCur = e.currentTarget.dataset.id || e.detail.current;
            },
            hideModal: function hideModal() {
                this.toPintuan = false;
                this.showSku = false;
                this.modalName = '';
            },
            sku: function sku() {
                var type = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'normal';

                this.showSku = true;
                this.toPintuan = false;
                this.buyTypt = type;
            },
            plus: function plus() {
                if (this.buyTypt == 'bargain') {
                    return false;
                }
                wx.vibrateShort();
                this.num = this.num + 1;
            },
            minus: function minus() {
                if (this.num > 1) {
                    wx.vibrateShort();
                    this.num = this.num - 1;
                }
            },
            course: function course(inx) {
                this.courseInx = inx;
            },
            buy: function () {
                var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
                    var aid = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;
                    var ot = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1;
                    return regeneratorRuntime.wrap(function _callee3$(_context3) {
                        while (1) {
                            switch (_context3.prev = _context3.next) {
                                case 0:
                                    if (!(this.courseInx == -1)) {
                                        _context3.next = 3;
                                        break;
                                    }

                                    _Tips2.default.toast("请选择一个营期", function (res) {}, 'none');
                                    return _context3.abrupt("return", false);

                                case 3:
                                    _wepy2.default.navigateTo({
                                        url: "./sureOrder?type=" + ot + "&pid=" + this.courseInfo.periodList[this.courseInx].id + "&cid=" + this.courseInfo.id + "&num=" + this.num + "&aid=" + aid + "&actpid=" + this.courseInfo.pintuanId
                                    });

                                case 4:
                                case "end":
                                    return _context3.stop();
                            }
                        }
                    }, _callee3, this);
                }));

                function buy() {
                    return _ref5.apply(this, arguments);
                }

                return buy;
            }()
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(Dialog, [{
        key: "onShareAppMessage",

        // 转发暂时先不开启
        value: function onShareAppMessage(res) {
            if (res.from === 'button') {
                // 来自页面内转发按钮
                console.log(res.target);
            }
            return {
                title: this.courseInfo.courseTittle,
                path: '/pages/detaile/detaile?id=' + this.courseInfo.id
            };
        }
    }, {
        key: "onLoad",
        value: function () {
            var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4(opt) {
                var _this2 = this;

                var view, _ref7, course, companions, statistics, CourseComment, actPintuan;

                return regeneratorRuntime.wrap(function _callee4$(_context4) {
                    while (1) {
                        switch (_context4.prev = _context4.next) {
                            case 0:
                                console.log(opt);
                                // 获取主内容高度，用于悬浮详情导航
                                view = wx.createSelectorQuery().select("#info-box");

                                view.fields({
                                    size: true
                                }, function (data) {
                                    console.log(data.height);
                                    _this2.mainHeight = data.height;
                                }).exec();
                                _context4.next = 5;
                                return _auth2.default.login();

                            case 5:
                                _context4.next = 7;
                                return _config2.default.getCourseInfo(opt.id || opt.scene);

                            case 7:
                                _ref7 = _context4.sent;
                                course = _ref7.course;
                                companions = _ref7.companions;
                                statistics = _ref7.statistics;
                                CourseComment = _ref7.CourseComment;
                                actPintuan = _ref7.actPintuan;

                                this.swipers.list[0].url = course.image;
                                course.courseChar = course.courseChar.split("|");
                                this.courseInfo = course;
                                _wepy2.default.$instance.globalData.courseInfo = course;
                                this.companions = companions;
                                this.statistics = statistics;
                                this.CourseComment = CourseComment;
                                this.ActPintuan = actPintuan;
                                console.log(this.ActPintuan);
                                this.$apply();

                            case 23:
                            case "end":
                                return _context4.stop();
                        }
                    }
                }, _callee4, this);
            }));

            function onLoad(_x5) {
                return _ref6.apply(this, arguments);
            }

            return onLoad;
        }()
    }]);

    return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/detaile/detaile'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldGFpbGUuanMiXSwibmFtZXMiOlsiRGlhbG9nIiwiZGF0YSIsIlRhYkN1ciIsImNsb3NlIiwic3dpcGVycyIsInR5cGUiLCJsaXN0IiwiaWQiLCJ1cmwiLCJsaW5rIiwibGlua1R5cGUiLCJtYWluSGVpZ2h0IiwiY291cnNlSW5mbyIsIm5vZGVzIiwibnVtIiwic2hvd1NrdSIsImJ1eVR5cHQiLCJjb3Vyc2VJbngiLCJjb21wYW5pb25zIiwic3RhdGlzdGljcyIsIkNvdXJzZUNvbW1lbnQiLCJBY3RQaW50dWFuIiwic2lnbl9zdGF0ZXMiLCJ0b1BpbnR1YW4iLCJtb2RhbE5hbWUiLCIkcmVwZWF0IiwiJHByb3BzIiwiJGV2ZW50cyIsImNvbXBvbmVudHMiLCJjU3dpcGVyIiwiY3RpdGxlIiwiY0luZm8iLCJjUmVtYWtlIiwiY29uZmlnIiwibmF2aWdhdGlvbkJhclRpdGxlVGV4dCIsIm1ldGhvZHMiLCJjcmVhdGVJbWciLCJlIiwiZGV0YWlsIiwiZXJyTXNnIiwiYXV0aCIsImdldFVzZXJpbmZvIiwic3RvcmUiLCJzYXZlIiwiY291cnNlIiwicGF0aCIsIndlcHkiLCJuYXZpZ2F0ZVRvIiwidG9zaGFyZSIsInRvUGludHVhbmZ5IiwiYmFyZ2FpbiIsIlRpcHMiLCJ0b2FzdCIsInJlZ0JhcmdhaW4iLCJiYXJnYWluSWQiLCJjb3Vyc2VJZCIsInBlcmlvZElkIiwicGVyaW9kTGlzdCIsImVycmNvZGUiLCJlcnJtc2ciLCJyZWRpcmVjdFRvIiwicmVnSWQiLCJhY3RCYXJnYWluUmVnIiwicmV0IiwidGFiU2VsZWN0IiwiY29uc29sZSIsImxvZyIsImN1cnJlbnRUYXJnZXQiLCJkYXRhc2V0IiwiY3VycmVudCIsImhpZGVNb2RhbCIsInNrdSIsInBsdXMiLCJ3eCIsInZpYnJhdGVTaG9ydCIsIm1pbnVzIiwiaW54IiwiYnV5IiwiYWlkIiwib3QiLCJwaW50dWFuSWQiLCJyZXMiLCJmcm9tIiwidGFyZ2V0IiwidGl0bGUiLCJjb3Vyc2VUaXR0bGUiLCJvcHQiLCJ2aWV3IiwiY3JlYXRlU2VsZWN0b3JRdWVyeSIsInNlbGVjdCIsImZpZWxkcyIsInNpemUiLCJoZWlnaHQiLCJleGVjIiwibG9naW4iLCJnZXRDb3Vyc2VJbmZvIiwic2NlbmUiLCJhY3RQaW50dWFuIiwiaW1hZ2UiLCJjb3Vyc2VDaGFyIiwic3BsaXQiLCIkaW5zdGFuY2UiLCJnbG9iYWxEYXRhIiwiJGFwcGx5IiwicGFnZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQ0k7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7Ozs7Ozs7Ozs7O0lBQ3FCQSxNOzs7Ozs7Ozs7Ozs7OzswTEFDakJDLEksR0FBTztBQUNIQyxvQkFBUSxDQURMO0FBRUhDLG1CQUFPLDBCQUZKO0FBR0hDLHFCQUFTO0FBQ0xDLHNCQUFNLENBREQ7QUFFTEMsc0JBQU0sQ0FBQztBQUNIQyx3QkFBSSxDQUREO0FBRUhGLDBCQUFNLE9BRkg7QUFHSEcseUJBQUssRUFIRjtBQUlIQywwQkFBTSxrQkFKSDtBQUtIQyw4QkFBVTtBQUxQLGlCQUFEO0FBRkQsYUFITjtBQWFIQyx3QkFBWSxDQWJUO0FBY0hDLHdCQUFZLEVBZFQ7QUFlSEMsbUJBQU8sQ0FBQyxNQUFELEVBQVMsT0FBVCxFQUFrQixPQUFsQixDQWZKO0FBZ0JIQyxpQkFBSyxDQWhCRjtBQWlCSEMscUJBQVMsS0FqQk47QUFrQkhDLHFCQUFTLFFBbEJOO0FBbUJIQyx1QkFBVyxDQUFDLENBbkJUO0FBb0JIQyx3QkFBWSxFQXBCVDtBQXFCSEMsd0JBQVksRUFyQlQ7QUFzQkhDLDJCQUFlLEVBdEJaO0FBdUJIQyx3QkFBWSxFQXZCVDtBQXdCSEMseUJBQWE7QUFDVCxtQkFBRyxPQURNO0FBRVQsbUJBQUcsTUFGTTtBQUdULG1CQUFHO0FBSE0sYUF4QlY7QUE2QkhDLHVCQUFXLEtBN0JSO0FBOEJIQyx1QkFBVztBQTlCUixTLFFBZ0NSQyxPLEdBQVUsRSxRQUNqQkMsTSxHQUFTLEVBQUMsV0FBVSxFQUFDLGdCQUFlLEVBQWhCLEVBQW1CLHFCQUFvQixTQUF2QyxFQUFYLEVBQTZELFVBQVMsRUFBQyxxQkFBb0IsWUFBckIsRUFBdEUsRUFBeUcsU0FBUSxFQUFDLHFCQUFvQixZQUFyQixFQUFrQywwQkFBeUIsWUFBM0QsRUFBakgsRUFBMEwsV0FBVSxFQUFDLHFCQUFvQixZQUFyQixFQUFrQywwQkFBeUIsWUFBM0QsRUFBd0UsNkJBQTRCLGVBQXBHLEVBQXBNLEUsUUFDVEMsTyxHQUFVLEUsUUFDVEMsVSxHQUFhO0FBQ0ZDLHFDQURFO0FBRUZDLG1DQUZFO0FBR0ZDLGlDQUhFO0FBSUZDO0FBSkUsUyxRQU1OQyxNLEdBQVM7QUFDTEMsb0NBQXdCO0FBRG5CLFMsUUErQ1RDLE8sR0FBVTtBQUNBQyxxQkFEQTtBQUFBLHFHQUNVQyxDQURWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQ0FFRUEsRUFBRUMsTUFBRixDQUFTQyxNQUFULElBQW1CLGdCQUZyQjtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBLDJDQUdRQyxlQUFLQyxXQUFMLENBQWlCSixFQUFFQyxNQUFuQixDQUhSOztBQUFBO0FBSUVJLG9EQUFNQyxJQUFOLENBQVcsV0FBWCxFQUF3QjtBQUNwQkMsZ0RBQVEsS0FBS2hDLFVBRE87QUFFcEJpQyw4Q0FBTSx1QkFGYztBQUdwQnRDLDRDQUFJLEtBQUtLLFVBQUwsQ0FBZ0JMO0FBSEEscUNBQXhCO0FBS0F1QyxtREFBS0MsVUFBTCxDQUFnQjtBQUNadkMsNkNBQUs7QUFETyxxQ0FBaEI7O0FBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFjTndDLG1CQWRNLHFCQWNJO0FBQ04scUJBQUt4QixTQUFMLEdBQWlCLE9BQWpCO0FBQ0gsYUFoQks7QUFpQk55Qix1QkFqQk0seUJBaUJRO0FBQ1YscUJBQUsxQixTQUFMLEdBQWlCLElBQWpCO0FBQ0gsYUFuQks7QUFvQkEyQixtQkFwQkE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMENBcUJFLEtBQUtqQyxTQUFMLElBQWtCLENBQUMsQ0FyQnJCO0FBQUE7QUFBQTtBQUFBOztBQXNCRWtDLG1EQUFLQyxLQUFMLENBQVcsU0FBWCxFQUFzQixlQUFPLENBQUUsQ0FBL0IsRUFBaUMsTUFBakM7QUF0QkYsc0VBdUJTLEtBdkJUOztBQUFBO0FBQUE7QUFBQSwyQ0E2QlFuQixpQkFBT29CLFVBQVAsQ0FBa0I7QUFDeEJDLG1EQUFXLEtBQUsxQyxVQUFMLENBQWdCMEMsU0FESDtBQUV4QkMsa0RBQVUsS0FBSzNDLFVBQUwsQ0FBZ0JMLEVBRkY7QUFHeEJpRCxrREFBVSxLQUFLNUMsVUFBTCxDQUFnQjZDLFVBQWhCLENBQTJCLEtBQUt4QyxTQUFoQyxFQUEyQ1Y7QUFIN0IscUNBQWxCLENBN0JSOztBQUFBO0FBQUE7QUEwQkVtRCwyQ0ExQkYsU0EwQkVBLE9BMUJGO0FBMkJFQywwQ0EzQkYsU0EyQkVBLE1BM0JGO0FBNEJFMUQsd0NBNUJGLFNBNEJFQSxJQTVCRjs7QUFrQ0Ysd0NBQUl5RCxXQUFXLEdBQWYsRUFBb0I7QUFDaEJaLHVEQUFLYyxVQUFMLENBQWdCO0FBQ1pwRCxpREFBSyxnQ0FBZ0NQLEtBQUs0RDtBQUQ5Qix5Q0FBaEI7QUFHSCxxQ0FKRCxNQUlPO0FBQ0g7QUFDQVYsdURBQUtDLEtBQUwsQ0FBV08sTUFBWCxFQUFtQixlQUFPO0FBQ3RCYiwyREFBS2MsVUFBTCxDQUFnQjtBQUNacEQscURBQUssZ0NBQWdDUCxLQUFLNkQsYUFBTCxDQUFtQnZEO0FBRDVDLDZDQUFoQjtBQUdILHlDQUpELEVBSUcsTUFKSDtBQUtIOztBQTdDQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQStDTndELGVBL0NNLGlCQStDQTtBQUNGLHVCQUFPLEtBQVA7QUFDSCxhQWpESztBQWtETkMscUJBbERNLHFCQWtESTNCLENBbERKLEVBa0RPO0FBQ1Q0Qix3QkFBUUMsR0FBUixDQUFZN0IsQ0FBWjtBQUNBLHFCQUFLbkMsTUFBTCxHQUFjbUMsRUFBRThCLGFBQUYsQ0FBZ0JDLE9BQWhCLENBQXdCN0QsRUFBeEIsSUFBOEI4QixFQUFFQyxNQUFGLENBQVMrQixPQUFyRDtBQUNILGFBckRLO0FBc0ROQyxxQkF0RE0sdUJBc0RNO0FBQ1IscUJBQUsvQyxTQUFMLEdBQWlCLEtBQWpCO0FBQ0EscUJBQUtSLE9BQUwsR0FBZSxLQUFmO0FBQ0EscUJBQUtTLFNBQUwsR0FBaUIsRUFBakI7QUFDSCxhQTFESztBQTJETitDLGVBM0RNLGlCQTJEZTtBQUFBLG9CQUFqQmxFLElBQWlCLHVFQUFWLFFBQVU7O0FBQ2pCLHFCQUFLVSxPQUFMLEdBQWUsSUFBZjtBQUNBLHFCQUFLUSxTQUFMLEdBQWlCLEtBQWpCO0FBQ0EscUJBQUtQLE9BQUwsR0FBZVgsSUFBZjtBQUNILGFBL0RLO0FBZ0VObUUsZ0JBaEVNLGtCQWdFQztBQUNILG9CQUFJLEtBQUt4RCxPQUFMLElBQWdCLFNBQXBCLEVBQStCO0FBQzNCLDJCQUFPLEtBQVA7QUFDSDtBQUNEeUQsbUJBQUdDLFlBQUg7QUFDQSxxQkFBSzVELEdBQUwsR0FBVyxLQUFLQSxHQUFMLEdBQVcsQ0FBdEI7QUFDSCxhQXRFSztBQXVFTjZELGlCQXZFTSxtQkF1RUU7QUFDSixvQkFBSSxLQUFLN0QsR0FBTCxHQUFXLENBQWYsRUFBa0I7QUFDZDJELHVCQUFHQyxZQUFIO0FBQ0EseUJBQUs1RCxHQUFMLEdBQVcsS0FBS0EsR0FBTCxHQUFXLENBQXRCO0FBQ0g7QUFDSixhQTVFSztBQTZFTjhCLGtCQTdFTSxrQkE2RUNnQyxHQTdFRCxFQTZFTTtBQUNSLHFCQUFLM0QsU0FBTCxHQUFpQjJELEdBQWpCO0FBQ0gsYUEvRUs7QUFnRkFDLGVBaEZBO0FBQUE7QUFBQSx3QkFnRklDLEdBaEZKLHVFQWdGVSxDQWhGVjtBQUFBLHdCQWdGYUMsRUFoRmIsdUVBZ0ZrQixDQWhGbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBDQWlGRSxLQUFLOUQsU0FBTCxJQUFrQixDQUFDLENBakZyQjtBQUFBO0FBQUE7QUFBQTs7QUFrRkVrQyxtREFBS0MsS0FBTCxDQUFXLFNBQVgsRUFBc0IsZUFBTyxDQUFFLENBQS9CLEVBQWlDLE1BQWpDO0FBbEZGLHNFQW1GUyxLQW5GVDs7QUFBQTtBQXFGRk4sbURBQUtDLFVBQUwsQ0FBZ0I7QUFDWnZDLG1FQUF5QnVFLEVBQXpCLGFBQW1DLEtBQUtuRSxVQUFMLENBQWdCNkMsVUFBaEIsQ0FBMkIsS0FBS3hDLFNBQWhDLEVBQTJDVixFQUE5RSxhQUF3RixLQUFLSyxVQUFMLENBQWdCTCxFQUF4RyxhQUFrSCxLQUFLTyxHQUF2SCxhQUFrSWdFLEdBQWxJLGdCQUFnSixLQUFLbEUsVUFBTCxDQUFnQm9FO0FBRHBKLHFDQUFoQjs7QUFyRkU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQSxTOzs7Ozs7QUE1Q1Y7MENBQ2tCQyxHLEVBQUs7QUFDbkIsZ0JBQUlBLElBQUlDLElBQUosS0FBYSxRQUFqQixFQUEyQjtBQUN2QjtBQUNBakIsd0JBQVFDLEdBQVIsQ0FBWWUsSUFBSUUsTUFBaEI7QUFDSDtBQUNELG1CQUFPO0FBQ0hDLHVCQUFPLEtBQUt4RSxVQUFMLENBQWdCeUUsWUFEcEI7QUFFSHhDLHNCQUFNLCtCQUErQixLQUFLakMsVUFBTCxDQUFnQkw7QUFGbEQsYUFBUDtBQUlIOzs7O2tHQUNZK0UsRzs7Ozs7Ozs7O0FBQ1RyQix3Q0FBUUMsR0FBUixDQUFZb0IsR0FBWjtBQUNBO0FBQ0lDLG9DLEdBQU9kLEdBQUdlLG1CQUFILEdBQXlCQyxNQUF6QixDQUFnQyxXQUFoQyxDOztBQUNYRixxQ0FDS0csTUFETCxDQUNZO0FBQ0FDLDBDQUFNO0FBRE4saUNBRFosRUFJUSxnQkFBUTtBQUNKMUIsNENBQVFDLEdBQVIsQ0FBWWpFLEtBQUsyRixNQUFqQjtBQUNBLDJDQUFLakYsVUFBTCxHQUFrQlYsS0FBSzJGLE1BQXZCO0FBQ0gsaUNBUFQsRUFTS0MsSUFUTDs7dUNBVU1yRCxlQUFLc0QsS0FBTCxFOzs7O3VDQU9JN0QsaUJBQU84RCxhQUFQLENBQXFCVCxJQUFJL0UsRUFBSixJQUFVK0UsSUFBSVUsS0FBbkMsQzs7OztBQUxOcEQsc0MsU0FBQUEsTTtBQUNBMUIsMEMsU0FBQUEsVTtBQUNBQywwQyxTQUFBQSxVO0FBQ0FDLDZDLFNBQUFBLGE7QUFDQTZFLDBDLFNBQUFBLFU7O0FBRUoscUNBQUs3RixPQUFMLENBQWFFLElBQWIsQ0FBa0IsQ0FBbEIsRUFBcUJFLEdBQXJCLEdBQTJCb0MsT0FBT3NELEtBQWxDO0FBQ0F0RCx1Q0FBT3VELFVBQVAsR0FBb0J2RCxPQUFPdUQsVUFBUCxDQUFrQkMsS0FBbEIsQ0FBd0IsR0FBeEIsQ0FBcEI7QUFDQSxxQ0FBS3hGLFVBQUwsR0FBa0JnQyxNQUFsQjtBQUNBRSwrQ0FBS3VELFNBQUwsQ0FBZUMsVUFBZixDQUEwQjFGLFVBQTFCLEdBQXVDZ0MsTUFBdkM7QUFDQSxxQ0FBSzFCLFVBQUwsR0FBa0JBLFVBQWxCO0FBQ0EscUNBQUtDLFVBQUwsR0FBa0JBLFVBQWxCO0FBQ0EscUNBQUtDLGFBQUwsR0FBcUJBLGFBQXJCO0FBQ0EscUNBQUtDLFVBQUwsR0FBa0I0RSxVQUFsQjtBQUNBaEMsd0NBQVFDLEdBQVIsQ0FBWSxLQUFLN0MsVUFBakI7QUFDQSxxQ0FBS2tGLE1BQUw7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUF2RjRCekQsZUFBSzBELEk7O2tCQUFwQnhHLE0iLCJmaWxlIjoiZGV0YWlsZS5qcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4gICAgaW1wb3J0IHdlcHkgZnJvbSBcIndlcHlcIjtcclxuICAgIGltcG9ydCBjU3dpcGVyIGZyb20gXCJAL2NvbXBvbmVudHMvY29tbW9uL3N3aXBlclwiO1xyXG4gICAgaW1wb3J0IGN0aXRsZSBmcm9tIFwiQC9jb21wb25lbnRzL2RldGFpbGUvdGl0bGVcIjtcclxuICAgIGltcG9ydCBjSW5mbyBmcm9tIFwiQC9jb21wb25lbnRzL2RldGFpbGUvaW5mb1wiO1xyXG4gICAgaW1wb3J0IGNSZW1ha2UgZnJvbSBcIkAvY29tcG9uZW50cy9kZXRhaWxlL3JlbWFrZVwiO1xyXG4gICAgaW1wb3J0IHN0b3JlIGZyb20gXCJAL3N0b3JlL3V0aWxzXCJcclxuICAgIGltcG9ydCBjb25maWcgZnJvbSBcIkAvYXBpL2NvbmZpZ1wiO1xyXG4gICAgaW1wb3J0IGF1dGggZnJvbSBcIkAvYXBpL2F1dGhcIjtcclxuICAgIGltcG9ydCBXeFV0aWxzIGZyb20gXCJAL3V0aWxzL1d4VXRpbHNcIjtcclxuICAgIGltcG9ydCBUaXBzIGZyb20gXCJAL3V0aWxzL1RpcHNcIjtcclxuICAgIGV4cG9ydCBkZWZhdWx0IGNsYXNzIERpYWxvZyBleHRlbmRzIHdlcHkucGFnZSB7XHJcbiAgICAgICAgZGF0YSA9IHtcclxuICAgICAgICAgICAgVGFiQ3VyOiAwLFxyXG4gICAgICAgICAgICBjbG9zZTogXCIvc3RhdGljL2ltYWdlcy9jbG9zZS5wbmdcIixcclxuICAgICAgICAgICAgc3dpcGVyczoge1xyXG4gICAgICAgICAgICAgICAgdHlwZTogMSxcclxuICAgICAgICAgICAgICAgIGxpc3Q6IFt7XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ6IDAsXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogXCJpbWFnZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgIHVybDogXCJcIixcclxuICAgICAgICAgICAgICAgICAgICBsaW5rOiBcIi9wYWdlcy9tZWV0L21lZXRcIixcclxuICAgICAgICAgICAgICAgICAgICBsaW5rVHlwZTogXCJzd2l0Y2hUYWJcIlxyXG4gICAgICAgICAgICAgICAgfV1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgbWFpbkhlaWdodDogMCxcclxuICAgICAgICAgICAgY291cnNlSW5mbzoge30sXHJcbiAgICAgICAgICAgIG5vZGVzOiBbXCJuYW1lXCIsIFwiYXR0cnNcIiwgXCJhdHRyc1wiXSxcclxuICAgICAgICAgICAgbnVtOiAxLFxyXG4gICAgICAgICAgICBzaG93U2t1OiBmYWxzZSxcclxuICAgICAgICAgICAgYnV5VHlwdDogJ25vcm1hbCcsXHJcbiAgICAgICAgICAgIGNvdXJzZUlueDogLTEsXHJcbiAgICAgICAgICAgIGNvbXBhbmlvbnM6IFtdLFxyXG4gICAgICAgICAgICBzdGF0aXN0aWNzOiB7fSxcclxuICAgICAgICAgICAgQ291cnNlQ29tbWVudDoge30sXHJcbiAgICAgICAgICAgIEFjdFBpbnR1YW46IHt9LFxyXG4gICAgICAgICAgICBzaWduX3N0YXRlczoge1xyXG4gICAgICAgICAgICAgICAgMDogJ+eBq+eDreaLm+eUn+S4rScsXHJcbiAgICAgICAgICAgICAgICAxOiAn5bCR6YeP5ZCN6aKdJyxcclxuICAgICAgICAgICAgICAgIDI6ICflt7Lmu6HlkZgnXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHRvUGludHVhbjogZmFsc2UsXHJcbiAgICAgICAgICAgIG1vZGFsTmFtZTogJydcclxuICAgICAgICB9O1xyXG4gICAgICAgJHJlcGVhdCA9IHt9O1xyXG4kcHJvcHMgPSB7XCJjU3dpcGVyXCI6e1wieG1sbnM6di1iaW5kXCI6XCJcIixcInYtYmluZDptb2RlbC5zeW5jXCI6XCJzd2lwZXJzXCJ9LFwiY3RpdGxlXCI6e1widi1iaW5kOm1vZGVsLnN5bmNcIjpcImNvdXJzZUluZm9cIn0sXCJjSW5mb1wiOntcInYtYmluZDptb2RlbC5zeW5jXCI6XCJjb3Vyc2VJbmZvXCIsXCJ2LWJpbmQ6Y29tcGFuaW9ucy5zeW5jXCI6XCJjb21wYW5pb25zXCJ9LFwiY1JlbWFrZVwiOntcInYtYmluZDptb2RlbC5zeW5jXCI6XCJjb3Vyc2VJbmZvXCIsXCJ2LWJpbmQ6c3RhdGlzdGljcy5zeW5jXCI6XCJzdGF0aXN0aWNzXCIsXCJ2LWJpbmQ6Q291cnNlQ29tbWVudC5zeW5jXCI6XCJDb3Vyc2VDb21tZW50XCJ9fTtcclxuJGV2ZW50cyA9IHt9O1xyXG4gY29tcG9uZW50cyA9IHtcclxuICAgICAgICAgICAgY1N3aXBlcixcclxuICAgICAgICAgICAgY3RpdGxlLFxyXG4gICAgICAgICAgICBjSW5mbyxcclxuICAgICAgICAgICAgY1JlbWFrZVxyXG4gICAgICAgIH07XHJcbiAgICAgICAgY29uZmlnID0ge1xyXG4gICAgICAgICAgICBuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0OiBcIua0u+WKqOivpuaDhVwiXHJcbiAgICAgICAgfTtcclxuICAgICAgICAvLyDovazlj5HmmoLml7blhYjkuI3lvIDlkK9cclxuICAgICAgICBvblNoYXJlQXBwTWVzc2FnZShyZXMpIHtcclxuICAgICAgICAgICAgaWYgKHJlcy5mcm9tID09PSAnYnV0dG9uJykge1xyXG4gICAgICAgICAgICAgICAgLy8g5p2l6Ieq6aG16Z2i5YaF6L2s5Y+R5oyJ6ZKuXHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhyZXMudGFyZ2V0KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICB0aXRsZTogdGhpcy5jb3Vyc2VJbmZvLmNvdXJzZVRpdHRsZSxcclxuICAgICAgICAgICAgICAgIHBhdGg6ICcvcGFnZXMvZGV0YWlsZS9kZXRhaWxlP2lkPScgKyB0aGlzLmNvdXJzZUluZm8uaWRcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBhc3luYyBvbkxvYWQob3B0KSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKG9wdClcclxuICAgICAgICAgICAgLy8g6I635Y+W5Li75YaF5a656auY5bqm77yM55So5LqO5oKs5rWu6K+m5oOF5a+86IiqXHJcbiAgICAgICAgICAgIGxldCB2aWV3ID0gd3guY3JlYXRlU2VsZWN0b3JRdWVyeSgpLnNlbGVjdChcIiNpbmZvLWJveFwiKTtcclxuICAgICAgICAgICAgdmlld1xyXG4gICAgICAgICAgICAgICAgLmZpZWxkcyh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNpemU6IHRydWVcclxuICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGEgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhkYXRhLmhlaWdodCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubWFpbkhlaWdodCA9IGRhdGEuaGVpZ2h0O1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgIC5leGVjKCk7XHJcbiAgICAgICAgICAgIGF3YWl0IGF1dGgubG9naW4oKVxyXG4gICAgICAgICAgICBsZXQge1xyXG4gICAgICAgICAgICAgICAgY291cnNlLFxyXG4gICAgICAgICAgICAgICAgY29tcGFuaW9ucyxcclxuICAgICAgICAgICAgICAgIHN0YXRpc3RpY3MsXHJcbiAgICAgICAgICAgICAgICBDb3Vyc2VDb21tZW50LFxyXG4gICAgICAgICAgICAgICAgYWN0UGludHVhblxyXG4gICAgICAgICAgICB9ID0gYXdhaXQgY29uZmlnLmdldENvdXJzZUluZm8ob3B0LmlkIHx8IG9wdC5zY2VuZSlcclxuICAgICAgICAgICAgdGhpcy5zd2lwZXJzLmxpc3RbMF0udXJsID0gY291cnNlLmltYWdlXHJcbiAgICAgICAgICAgIGNvdXJzZS5jb3Vyc2VDaGFyID0gY291cnNlLmNvdXJzZUNoYXIuc3BsaXQoXCJ8XCIpXHJcbiAgICAgICAgICAgIHRoaXMuY291cnNlSW5mbyA9IGNvdXJzZVxyXG4gICAgICAgICAgICB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLmNvdXJzZUluZm8gPSBjb3Vyc2VcclxuICAgICAgICAgICAgdGhpcy5jb21wYW5pb25zID0gY29tcGFuaW9uc1xyXG4gICAgICAgICAgICB0aGlzLnN0YXRpc3RpY3MgPSBzdGF0aXN0aWNzXHJcbiAgICAgICAgICAgIHRoaXMuQ291cnNlQ29tbWVudCA9IENvdXJzZUNvbW1lbnRcclxuICAgICAgICAgICAgdGhpcy5BY3RQaW50dWFuID0gYWN0UGludHVhblxyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyh0aGlzLkFjdFBpbnR1YW4pXHJcbiAgICAgICAgICAgIHRoaXMuJGFwcGx5KCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIG1ldGhvZHMgPSB7XHJcbiAgICAgICAgICAgIGFzeW5jIGNyZWF0ZUltZyhlKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoZS5kZXRhaWwuZXJyTXNnID09IFwiZ2V0VXNlckluZm86b2tcIikge1xyXG4gICAgICAgICAgICAgICAgICAgIGF3YWl0IGF1dGguZ2V0VXNlcmluZm8oZS5kZXRhaWwpXHJcbiAgICAgICAgICAgICAgICAgICAgc3RvcmUuc2F2ZSgnc2hhcmVJbmZvJywge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb3Vyc2U6IHRoaXMuY291cnNlSW5mbyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGF0aDogJ3BhZ2VzL2RldGFpbGUvZGV0YWlsZScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkOiB0aGlzLmNvdXJzZUluZm8uaWRcclxuICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgIHdlcHkubmF2aWdhdGVUbyh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHVybDogJy9wYWdlcy9ob21lL3NoYXJlJ1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB0b3NoYXJlKCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb2RhbE5hbWUgPSAnc2hhcmUnXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHRvUGludHVhbmZ5KCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy50b1BpbnR1YW4gPSB0cnVlXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGFzeW5jIGJhcmdhaW4oKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5jb3Vyc2VJbnggPT0gLTEpIHtcclxuICAgICAgICAgICAgICAgICAgICBUaXBzLnRvYXN0KFwi6K+36YCJ5oup5LiA5Liq6JCl5pyfXCIsIHJlcyA9PiB7fSwgJ25vbmUnKVxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgbGV0IHtcclxuICAgICAgICAgICAgICAgICAgICBlcnJjb2RlLFxyXG4gICAgICAgICAgICAgICAgICAgIGVycm1zZyxcclxuICAgICAgICAgICAgICAgICAgICBkYXRhXHJcbiAgICAgICAgICAgICAgICB9ID0gYXdhaXQgY29uZmlnLnJlZ0JhcmdhaW4oe1xyXG4gICAgICAgICAgICAgICAgICAgIGJhcmdhaW5JZDogdGhpcy5jb3Vyc2VJbmZvLmJhcmdhaW5JZCxcclxuICAgICAgICAgICAgICAgICAgICBjb3Vyc2VJZDogdGhpcy5jb3Vyc2VJbmZvLmlkLFxyXG4gICAgICAgICAgICAgICAgICAgIHBlcmlvZElkOiB0aGlzLmNvdXJzZUluZm8ucGVyaW9kTGlzdFt0aGlzLmNvdXJzZUlueF0uaWQsXHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgaWYgKGVycmNvZGUgPT0gMjAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgd2VweS5yZWRpcmVjdFRvKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdXJsOiAnL3BhZ2VzL2FjdGl2aXR5L2JhcmdhaW4/aWQ9JyArIGRhdGEucmVnSWRcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8g5Y+R6LW356CN5Lu35byC5bi4XHJcbiAgICAgICAgICAgICAgICAgICAgVGlwcy50b2FzdChlcnJtc2csIHJlcyA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHdlcHkucmVkaXJlY3RUbyh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cmw6ICcvcGFnZXMvYWN0aXZpdHkvYmFyZ2Fpbj9pZD0nICsgZGF0YS5hY3RCYXJnYWluUmVnLmlkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIH0sICdub25lJylcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgcmV0KCkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHRhYlNlbGVjdChlKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuVGFiQ3VyID0gZS5jdXJyZW50VGFyZ2V0LmRhdGFzZXQuaWQgfHwgZS5kZXRhaWwuY3VycmVudDtcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgaGlkZU1vZGFsKCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy50b1BpbnR1YW4gPSBmYWxzZVxyXG4gICAgICAgICAgICAgICAgdGhpcy5zaG93U2t1ID0gZmFsc2VcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kYWxOYW1lID0gJydcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgc2t1KHR5cGUgPSAnbm9ybWFsJykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zaG93U2t1ID0gdHJ1ZVxyXG4gICAgICAgICAgICAgICAgdGhpcy50b1BpbnR1YW4gPSBmYWxzZVxyXG4gICAgICAgICAgICAgICAgdGhpcy5idXlUeXB0ID0gdHlwZVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBwbHVzKCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuYnV5VHlwdCA9PSAnYmFyZ2FpbicpIHtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHd4LnZpYnJhdGVTaG9ydCgpXHJcbiAgICAgICAgICAgICAgICB0aGlzLm51bSA9IHRoaXMubnVtICsgMVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBtaW51cygpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLm51bSA+IDEpIHtcclxuICAgICAgICAgICAgICAgICAgICB3eC52aWJyYXRlU2hvcnQoKVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubnVtID0gdGhpcy5udW0gLSAxXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGNvdXJzZShpbngpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuY291cnNlSW54ID0gaW54XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGFzeW5jIGJ1eShhaWQgPSAwLCBvdCA9IDEsICkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuY291cnNlSW54ID09IC0xKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgVGlwcy50b2FzdChcIuivt+mAieaLqeS4gOS4quiQpeacn1wiLCByZXMgPT4ge30sICdub25lJylcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHdlcHkubmF2aWdhdGVUbyh7XHJcbiAgICAgICAgICAgICAgICAgICAgdXJsOiBgLi9zdXJlT3JkZXI/dHlwZT0ke290fSZwaWQ9JHt0aGlzLmNvdXJzZUluZm8ucGVyaW9kTGlzdFt0aGlzLmNvdXJzZUlueF0uaWR9JmNpZD0ke3RoaXMuY291cnNlSW5mby5pZH0mbnVtPSR7dGhpcy5udW19JmFpZD0ke2FpZH0mYWN0cGlkPSR7dGhpcy5jb3Vyc2VJbmZvLnBpbnR1YW5JZH1gXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH07XHJcbiAgICB9XHJcbiJdfQ==