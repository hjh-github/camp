"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

var _WxUtils = require('./../../utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
  _inherits(Dialog, _wepy$page);

  function Dialog() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, Dialog);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
      navigationBarTitleText: "确认订单"
    }, _this.data = {
      orderInfo: {},
      payParams: {},
      childs: [],
      mobile: '',
      canpay: true
    }, _this.computed = {
      orderPrice: function orderPrice() {
        if (JSON.stringify(this.payParams) == '{}' || JSON.stringify(this.orderInfo) == '{}') {
          return '0.00';
        }

        return this.payParams.paymentType == 1 ? (this.payParams.price * this.payParams.courseNum).toFixed(2) : (this.orderInfo.earnesMoney * this.payParams.courseNum).toFixed(2);
      }
    }, _this.methods = {
      bindgetphonenumber: function () {
        var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(e) {
          var mobile;
          return regeneratorRuntime.wrap(function _callee$(_context) {
            while (1) {
              switch (_context.prev = _context.next) {
                case 0:
                  if (!(e.detail.errMsg == "getPhoneNumber:ok")) {
                    _context.next = 6;
                    break;
                  }

                  _context.next = 3;
                  return _auth2.default.getPhone(e.detail);

                case 3:
                  mobile = _context.sent;

                  if (mobile) {
                    _wepy2.default.setStorageSync('mobile', mobile);
                    this.mobile = mobile;
                  }
                  this.$apply();

                case 6:
                case "end":
                  return _context.stop();
              }
            }
          }, _callee, this);
        }));

        function bindgetphonenumber(_x) {
          return _ref2.apply(this, arguments);
        }

        return bindgetphonenumber;
      }(),
      textareaBInput: function textareaBInput(e) {
        this.payParams.remark = e.detail.value;
      },
      paymentType: function paymentType(type) {
        this.payParams.paymentType = type;
      },
      plus: function plus() {
        wx.vibrateShort();
        this.payParams.courseNum = this.payParams.courseNum + 1;
        this.childs = [];
      },
      minus: function minus() {
        if (this.payParams.courseNum > 1) {
          wx.vibrateShort();
          this.payParams.courseNum = this.payParams.courseNum - 1;
          this.childs = [];
        }
      },
      getChilds: function () {
        var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(e) {
          return regeneratorRuntime.wrap(function _callee2$(_context2) {
            while (1) {
              switch (_context2.prev = _context2.next) {
                case 0:
                  if (this.mobile) {
                    _context2.next = 2;
                    break;
                  }

                  return _context2.abrupt("return", false);

                case 2:
                  if (!(e.detail.errMsg == "getUserInfo:ok")) {
                    _context2.next = 6;
                    break;
                  }

                  _context2.next = 5;
                  return _auth2.default.getUserinfo(e.detail);

                case 5:
                  _wepy2.default.navigateTo({
                    url: '/pages/meet/childs?type=1&len=' + this.payParams.courseNum
                  });

                case 6:
                case "end":
                  return _context2.stop();
              }
            }
          }, _callee2, this);
        }));

        function getChilds(_x2) {
          return _ref3.apply(this, arguments);
        }

        return getChilds;
      }(),
      pay: function () {
        var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
          var _this2 = this;

          var ids;
          return regeneratorRuntime.wrap(function _callee4$(_context4) {
            while (1) {
              switch (_context4.prev = _context4.next) {
                case 0:
                  if (!(!this.childs.length || this.childs.length != this.payParams.courseNum)) {
                    _context4.next = 3;
                    break;
                  }

                  _Tips2.default.toast(!this.childs.length ? "请先选择出行人" : "购买数量与出行人数量不匹配", function (res) {}, 'none');
                  return _context4.abrupt("return", false);

                case 3:
                  ids = this.childs.map(function (e) {
                    return e.id;
                  });

                  this.payParams.childIds = ids.join(',');
                  this.canpay = false;
                  _config2.default.ordercommit(this.payParams).then(function () {
                    var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(res) {
                      var _code;

                      return regeneratorRuntime.wrap(function _callee3$(_context3) {
                        while (1) {
                          switch (_context3.prev = _context3.next) {
                            case 0:
                              if (!(res.errcode == 200)) {
                                _context3.next = 5;
                                break;
                              }

                              _context3.next = 3;
                              return _config2.default.wxpaytopay({
                                orderPaySn: res.data.paySn,
                                describe: '描述',
                                money: parseInt(res.data.payAmount * 100)
                              });

                            case 3:
                              _code = _context3.sent;

                              _WxUtils2.default.wxPay(_code.data).then(function (r) {
                                var url = "";
                                if (res.data.orderType == 1) url = "/pages/my/order?id=" + res.data.orderId;
                                if (res.data.orderType == 2) url = '/pages/activity/bargain?id=' + res.data.actId;
                                if (res.data.orderType == 3) url = '/pages/activity/pintuan?id=' + res.data.actId;
                                _Tips2.default.toast("支付成功", function (re) {
                                  wx.reLaunch({
                                    url: url
                                  });
                                });
                              }).catch(function (err) {
                                wx.reLaunch({
                                  url: "/pages/my/order?id=" + res.data.orderId
                                });
                              });

                            case 5:
                            case "end":
                              return _context3.stop();
                          }
                        }
                      }, _callee3, _this2);
                    }));

                    return function (_x3) {
                      return _ref5.apply(this, arguments);
                    };
                  }()).catch(function (err) {
                    _this2.canpay = true;
                    _this2.$apply();
                  });

                case 7:
                case "end":
                  return _context4.stop();
              }
            }
          }, _callee4, this);
        }));

        function pay() {
          return _ref4.apply(this, arguments);
        }

        return pay;
      }()
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(Dialog, [{
    key: "onLoad",
    value: function () {
      var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5(opt) {
        return regeneratorRuntime.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                console.log(opt);
                this.mobile = _wepy2.default.getStorageSync('mobile');

                // this.payParams = wepy.$instance.globalData.orderInfo
                // this.orderInfo = wepy.$instance.globalData.courseInfo
                _context5.next = 4;
                return this.getorderInfo(opt);

              case 4:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5, this);
      }));

      function onLoad(_x4) {
        return _ref6.apply(this, arguments);
      }

      return onLoad;
    }()
  }, {
    key: "onShow",
    value: function onShow() {
      this.childs = _wepy2.default.$instance.globalData.childs;
    }
  }, {
    key: "onUnload",
    value: function onUnload() {
      this.childs = _wepy2.default.$instance.globalData.childs = [];
    }
    // 根据课程详情参数，生成支付订单信息

  }, {
    key: "getorderInfo",
    value: function () {
      var _ref7 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee6(opt) {
        var params, _ref8, errcode, data, _data;

        return regeneratorRuntime.wrap(function _callee6$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                /*
                  params ={
                    orderType: ${opt.type}, // 订单类型
                    courseId: ${opt.cid}, // 课程id
                    periodId: ${opt.pid}, // 营期id
                    num: ${opt.num}, // 数量
                    actId: ${opt.aId}, // 活动id
                  }
                */
                params = {
                  orderType: opt.type,
                  courseId: opt.cid,
                  periodId: opt.pid,
                  num: opt.num,
                  actId: opt.aid
                };
                _context6.next = 3;
                return _config2.default.orderInfo(params);

              case 3:
                _ref8 = _context6.sent;
                errcode = _ref8.errcode;
                data = _ref8.data;

                if (errcode == 200) {
                  this.orderInfo = data.course;
                  _data = data;

                  this.payParams = {
                    childIds: '',
                    courseId: _data.courseId,
                    courseNum: _data.num,
                    periodId: _data.periodId,
                    remark: '',
                    orderType: _data.orderType,
                    periodName: _data.period,
                    actId: _data.actId,
                    price: _data.totalPrice,
                    actPintuanId: opt.actpid,
                    paymentType: opt.pt || 1
                  };
                }
                this.$apply();

              case 8:
              case "end":
                return _context6.stop();
            }
          }
        }, _callee6, this);
      }));

      function getorderInfo(_x5) {
        return _ref7.apply(this, arguments);
      }

      return getorderInfo;
    }()
  }]);

  return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/detaile/sureOrder'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN1cmVPcmRlci5qcyJdLCJuYW1lcyI6WyJEaWFsb2ciLCJjb25maWciLCJuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0IiwiZGF0YSIsIm9yZGVySW5mbyIsInBheVBhcmFtcyIsImNoaWxkcyIsIm1vYmlsZSIsImNhbnBheSIsImNvbXB1dGVkIiwib3JkZXJQcmljZSIsIkpTT04iLCJzdHJpbmdpZnkiLCJwYXltZW50VHlwZSIsInByaWNlIiwiY291cnNlTnVtIiwidG9GaXhlZCIsImVhcm5lc01vbmV5IiwibWV0aG9kcyIsImJpbmRnZXRwaG9uZW51bWJlciIsImUiLCJkZXRhaWwiLCJlcnJNc2ciLCJhdXRoIiwiZ2V0UGhvbmUiLCJ3ZXB5Iiwic2V0U3RvcmFnZVN5bmMiLCIkYXBwbHkiLCJ0ZXh0YXJlYUJJbnB1dCIsInJlbWFyayIsInZhbHVlIiwidHlwZSIsInBsdXMiLCJ3eCIsInZpYnJhdGVTaG9ydCIsIm1pbnVzIiwiZ2V0Q2hpbGRzIiwiZ2V0VXNlcmluZm8iLCJuYXZpZ2F0ZVRvIiwidXJsIiwicGF5IiwibGVuZ3RoIiwiVGlwcyIsInRvYXN0IiwiaWRzIiwibWFwIiwiaWQiLCJjaGlsZElkcyIsImpvaW4iLCJvcmRlcmNvbW1pdCIsInRoZW4iLCJyZXMiLCJlcnJjb2RlIiwid3hwYXl0b3BheSIsIm9yZGVyUGF5U24iLCJwYXlTbiIsImRlc2NyaWJlIiwibW9uZXkiLCJwYXJzZUludCIsInBheUFtb3VudCIsIl9jb2RlIiwiV3hVdGlscyIsInd4UGF5Iiwib3JkZXJUeXBlIiwib3JkZXJJZCIsImFjdElkIiwicmVMYXVuY2giLCJjYXRjaCIsIm9wdCIsImNvbnNvbGUiLCJsb2ciLCJnZXRTdG9yYWdlU3luYyIsImdldG9yZGVySW5mbyIsIiRpbnN0YW5jZSIsImdsb2JhbERhdGEiLCJwYXJhbXMiLCJjb3Vyc2VJZCIsImNpZCIsInBlcmlvZElkIiwicGlkIiwibnVtIiwiYWlkIiwiY291cnNlIiwiX2RhdGEiLCJwZXJpb2ROYW1lIiwicGVyaW9kIiwidG90YWxQcmljZSIsImFjdFBpbnR1YW5JZCIsImFjdHBpZCIsInB0IiwicGFnZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQ0U7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7Ozs7Ozs7Ozs7Ozs7SUFDcUJBLE07Ozs7Ozs7Ozs7Ozs7O3NMQUNuQkMsTSxHQUFTO0FBQ1BDLDhCQUF3QjtBQURqQixLLFFBR1RDLEksR0FBTztBQUNMQyxpQkFBVyxFQUROO0FBRUxDLGlCQUFXLEVBRk47QUFHTEMsY0FBUSxFQUhIO0FBSUxDLGNBQVEsRUFKSDtBQUtMQyxjQUFRO0FBTEgsSyxRQThEUEMsUSxHQUFXO0FBQ1RDLGdCQURTLHdCQUNJO0FBQ1gsWUFBSUMsS0FBS0MsU0FBTCxDQUFlLEtBQUtQLFNBQXBCLEtBQWtDLElBQWxDLElBQTBDTSxLQUFLQyxTQUFMLENBQWUsS0FBS1IsU0FBcEIsS0FBa0MsSUFBaEYsRUFBc0Y7QUFDcEYsaUJBQU8sTUFBUDtBQUNEOztBQUVELGVBQU8sS0FBS0MsU0FBTCxDQUFlUSxXQUFmLElBQThCLENBQTlCLEdBQWtDLENBQUMsS0FBS1IsU0FBTCxDQUFlUyxLQUFmLEdBQXVCLEtBQUtULFNBQUwsQ0FBZVUsU0FBdkMsRUFBa0RDLE9BQWxELENBQTBELENBQTFELENBQWxDLEdBQWlHLENBQUMsS0FBS1osU0FBTCxDQUFlYSxXQUFmLEdBQTZCLEtBQUtaLFNBQUwsQ0FBZVUsU0FBN0MsRUFBd0RDLE9BQXhELENBQWdFLENBQWhFLENBQXhHO0FBQ0Q7QUFQUSxLLFFBU1hFLE8sR0FBVTtBQUNGQyx3QkFERTtBQUFBLDZGQUNpQkMsQ0FEakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBRUZBLEVBQUVDLE1BQUYsQ0FBU0MsTUFBVCxJQUFtQixtQkFGakI7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQSx5QkFHZUMsZUFBS0MsUUFBTCxDQUFjSixFQUFFQyxNQUFoQixDQUhmOztBQUFBO0FBR0FkLHdCQUhBOztBQUlKLHNCQUFJQSxNQUFKLEVBQVk7QUFDVmtCLG1DQUFLQyxjQUFMLENBQW9CLFFBQXBCLEVBQThCbkIsTUFBOUI7QUFDQSx5QkFBS0EsTUFBTCxHQUFjQSxNQUFkO0FBQ0Q7QUFDRCx1QkFBS29CLE1BQUw7O0FBUkk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFXUkMsb0JBWFEsMEJBV09SLENBWFAsRUFXVTtBQUNoQixhQUFLZixTQUFMLENBQWV3QixNQUFmLEdBQXdCVCxFQUFFQyxNQUFGLENBQVNTLEtBQWpDO0FBQ0QsT0FiTztBQWNSakIsaUJBZFEsdUJBY0lrQixJQWRKLEVBY1U7QUFDaEIsYUFBSzFCLFNBQUwsQ0FBZVEsV0FBZixHQUE2QmtCLElBQTdCO0FBQ0QsT0FoQk87QUFpQlJDLFVBakJRLGtCQWlCRDtBQUNMQyxXQUFHQyxZQUFIO0FBQ0EsYUFBSzdCLFNBQUwsQ0FBZVUsU0FBZixHQUEyQixLQUFLVixTQUFMLENBQWVVLFNBQWYsR0FBMkIsQ0FBdEQ7QUFDQSxhQUFLVCxNQUFMLEdBQWMsRUFBZDtBQUNELE9BckJPO0FBc0JSNkIsV0F0QlEsbUJBc0JBO0FBQ04sWUFBSSxLQUFLOUIsU0FBTCxDQUFlVSxTQUFmLEdBQTJCLENBQS9CLEVBQWtDO0FBQ2hDa0IsYUFBR0MsWUFBSDtBQUNBLGVBQUs3QixTQUFMLENBQWVVLFNBQWYsR0FBMkIsS0FBS1YsU0FBTCxDQUFlVSxTQUFmLEdBQTJCLENBQXREO0FBQ0EsZUFBS1QsTUFBTCxHQUFjLEVBQWQ7QUFDRDtBQUNGLE9BNUJPO0FBNkJGOEIsZUE3QkU7QUFBQSw4RkE2QlFoQixDQTdCUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBOEJELEtBQUtiLE1BOUJKO0FBQUE7QUFBQTtBQUFBOztBQUFBLG9EQStCRyxLQS9CSDs7QUFBQTtBQUFBLHdCQWlDRmEsRUFBRUMsTUFBRixDQUFTQyxNQUFULElBQW1CLGdCQWpDakI7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQSx5QkFrQ0VDLGVBQUtjLFdBQUwsQ0FBaUJqQixFQUFFQyxNQUFuQixDQWxDRjs7QUFBQTtBQW1DSkksaUNBQUthLFVBQUwsQ0FBZ0I7QUFDZEMseUJBQUssbUNBQW1DLEtBQUtsQyxTQUFMLENBQWVVO0FBRHpDLG1CQUFoQjs7QUFuQ0k7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUF3Q0Z5QixTQXhDRTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQXlDRixDQUFDLEtBQUtsQyxNQUFMLENBQVltQyxNQUFiLElBQXVCLEtBQUtuQyxNQUFMLENBQVltQyxNQUFaLElBQXNCLEtBQUtwQyxTQUFMLENBQWVVLFNBekMxRDtBQUFBO0FBQUE7QUFBQTs7QUEwQ0oyQixpQ0FBS0MsS0FBTCxDQUFXLENBQUMsS0FBS3JDLE1BQUwsQ0FBWW1DLE1BQWIsR0FBc0IsU0FBdEIsR0FBa0MsZUFBN0MsRUFBOEQsZUFBTyxDQUFFLENBQXZFLEVBQXlFLE1BQXpFO0FBMUNJLG9EQTJDRyxLQTNDSDs7QUFBQTtBQTZDRkcscUJBN0NFLEdBNkNJLEtBQUt0QyxNQUFMLENBQVl1QyxHQUFaLENBQWdCLGFBQUs7QUFDN0IsMkJBQU96QixFQUFFMEIsRUFBVDtBQUNELG1CQUZTLENBN0NKOztBQWdETix1QkFBS3pDLFNBQUwsQ0FBZTBDLFFBQWYsR0FBMEJILElBQUlJLElBQUosQ0FBUyxHQUFULENBQTFCO0FBQ0EsdUJBQUt4QyxNQUFMLEdBQWMsS0FBZDtBQUNBUCxtQ0FBT2dELFdBQVAsQ0FBbUIsS0FBSzVDLFNBQXhCLEVBQW1DNkMsSUFBbkM7QUFBQSx3RkFBeUMsa0JBQU1DLEdBQU47QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9DQUNuQ0EsSUFBSUMsT0FBSixJQUFlLEdBRG9CO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUEscUNBRW5CbkQsaUJBQU9vRCxVQUFQLENBQWtCO0FBQ2xDQyw0Q0FBWUgsSUFBSWhELElBQUosQ0FBU29ELEtBRGE7QUFFbENDLDBDQUFVLElBRndCO0FBR2xDQyx1Q0FBT0MsU0FBU1AsSUFBSWhELElBQUosQ0FBU3dELFNBQVQsR0FBcUIsR0FBOUI7QUFIMkIsK0JBQWxCLENBRm1COztBQUFBO0FBRWpDQyxtQ0FGaUM7O0FBT3JDQyxnREFBUUMsS0FBUixDQUFjRixNQUFNekQsSUFBcEIsRUFBMEIrQyxJQUExQixDQUErQixhQUFLO0FBQ2xDLG9DQUFJWCxRQUFKO0FBQ0Esb0NBQUlZLElBQUloRCxJQUFKLENBQVM0RCxTQUFULElBQXNCLENBQTFCLEVBQTZCeEIsTUFBTSx3QkFBd0JZLElBQUloRCxJQUFKLENBQVM2RCxPQUF2QztBQUM3QixvQ0FBSWIsSUFBSWhELElBQUosQ0FBUzRELFNBQVQsSUFBc0IsQ0FBMUIsRUFBNkJ4QixNQUFNLGdDQUFnQ1ksSUFBSWhELElBQUosQ0FBUzhELEtBQS9DO0FBQzdCLG9DQUFJZCxJQUFJaEQsSUFBSixDQUFTNEQsU0FBVCxJQUFzQixDQUExQixFQUE2QnhCLE1BQU0sZ0NBQWdDWSxJQUFJaEQsSUFBSixDQUFTOEQsS0FBL0M7QUFDN0J2QiwrQ0FBS0MsS0FBTCxDQUFXLE1BQVgsRUFBbUIsY0FBTTtBQUN2QlYscUNBQUdpQyxRQUFILENBQVk7QUFDVjNCO0FBRFUsbUNBQVo7QUFHRCxpQ0FKRDtBQUtELCtCQVZELEVBVUc0QixLQVZILENBVVMsZUFBTztBQUNkbEMsbUNBQUdpQyxRQUFILENBQVk7QUFDVjNCLHVDQUFLLHdCQUF3QlksSUFBSWhELElBQUosQ0FBUzZEO0FBRDVCLGlDQUFaO0FBR0QsK0JBZEQ7O0FBUHFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF6Qzs7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkF1QkdHLEtBdkJILENBdUJTLGVBQUs7QUFDWiwyQkFBSzNELE1BQUwsR0FBYyxJQUFkO0FBQ0EsMkJBQUttQixNQUFMO0FBQ0QsbUJBMUJEOztBQWxETTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBLEs7Ozs7Ozs0RkFoRUd5QyxHOzs7OztBQUNYQyx3QkFBUUMsR0FBUixDQUFZRixHQUFaO0FBQ0EscUJBQUs3RCxNQUFMLEdBQWNrQixlQUFLOEMsY0FBTCxDQUFvQixRQUFwQixDQUFkOztBQUVBO0FBQ0E7O3VCQUNNLEtBQUtDLFlBQUwsQ0FBa0JKLEdBQWxCLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs2QkFFQztBQUNQLFdBQUs5RCxNQUFMLEdBQWNtQixlQUFLZ0QsU0FBTCxDQUFlQyxVQUFmLENBQTBCcEUsTUFBeEM7QUFDRDs7OytCQUNVO0FBQ1QsV0FBS0EsTUFBTCxHQUFjbUIsZUFBS2dELFNBQUwsQ0FBZUMsVUFBZixDQUEwQnBFLE1BQTFCLEdBQW1DLEVBQWpEO0FBQ0Q7QUFDRDs7Ozs7NEZBQ21COEQsRzs7Ozs7OztBQUNqQjs7Ozs7Ozs7O0FBU0lPLHNCLEdBQVM7QUFDWFosNkJBQVdLLElBQUlyQyxJQURKO0FBRVg2Qyw0QkFBVVIsSUFBSVMsR0FGSDtBQUdYQyw0QkFBVVYsSUFBSVcsR0FISDtBQUlYQyx1QkFBS1osSUFBSVksR0FKRTtBQUtYZix5QkFBT0csSUFBSWE7QUFMQSxpQjs7dUJBVUhoRixpQkFBT0csU0FBUCxDQUFpQnVFLE1BQWpCLEM7Ozs7QUFGUnZCLHVCLFNBQUFBLE87QUFDQWpELG9CLFNBQUFBLEk7O0FBRUYsb0JBQUlpRCxXQUFXLEdBQWYsRUFBb0I7QUFDbEIsdUJBQUtoRCxTQUFMLEdBQWlCRCxLQUFLK0UsTUFBdEI7QUFDSUMsdUJBRmMsR0FFTmhGLElBRk07O0FBR2xCLHVCQUFLRSxTQUFMLEdBQWlCO0FBQ2YwQyw4QkFBVSxFQURLO0FBRWY2Qiw4QkFBVU8sTUFBTVAsUUFGRDtBQUdmN0QsK0JBQVdvRSxNQUFNSCxHQUhGO0FBSWZGLDhCQUFVSyxNQUFNTCxRQUpEO0FBS2ZqRCw0QkFBUSxFQUxPO0FBTWZrQywrQkFBV29CLE1BQU1wQixTQU5GO0FBT2ZxQixnQ0FBWUQsTUFBTUUsTUFQSDtBQVFmcEIsMkJBQU9rQixNQUFNbEIsS0FSRTtBQVNmbkQsMkJBQU9xRSxNQUFNRyxVQVRFO0FBVWZDLGtDQUFjbkIsSUFBSW9CLE1BVkg7QUFXZjNFLGlDQUFjdUQsSUFBSXFCLEVBQUosSUFBVTtBQVhULG1CQUFqQjtBQWFEO0FBQ0QscUJBQUs5RCxNQUFMOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBaEVnQ0YsZUFBS2lFLEk7O2tCQUFwQjFGLE0iLCJmaWxlIjoic3VyZU9yZGVyLmpzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbiAgaW1wb3J0IHdlcHkgZnJvbSBcIndlcHlcIjtcclxuICBpbXBvcnQgY29uZmlnIGZyb20gXCJAL2FwaS9jb25maWdcIlxyXG4gIGltcG9ydCBUaXBzIGZyb20gXCJAL3V0aWxzL1RpcHNcIlxyXG4gIGltcG9ydCBXeFV0aWxzIGZyb20gXCJAL3V0aWxzL1d4VXRpbHNcIlxyXG4gIGltcG9ydCBhdXRoIGZyb20gXCJAL2FwaS9hdXRoXCJcclxuICBleHBvcnQgZGVmYXVsdCBjbGFzcyBEaWFsb2cgZXh0ZW5kcyB3ZXB5LnBhZ2Uge1xyXG4gICAgY29uZmlnID0ge1xyXG4gICAgICBuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0OiBcIuehruiupOiuouWNlVwiXHJcbiAgICB9O1xyXG4gICAgZGF0YSA9IHtcclxuICAgICAgb3JkZXJJbmZvOiB7fSxcclxuICAgICAgcGF5UGFyYW1zOiB7fSxcclxuICAgICAgY2hpbGRzOiBbXSxcclxuICAgICAgbW9iaWxlOiAnJyxcclxuICAgICAgY2FucGF5OiB0cnVlXHJcbiAgICB9O1xyXG4gICAgYXN5bmMgb25Mb2FkKG9wdCkge1xyXG4gICAgICBjb25zb2xlLmxvZyhvcHQpXHJcbiAgICAgIHRoaXMubW9iaWxlID0gd2VweS5nZXRTdG9yYWdlU3luYygnbW9iaWxlJyk7XHJcbiAgICAgIFxyXG4gICAgICAvLyB0aGlzLnBheVBhcmFtcyA9IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEub3JkZXJJbmZvXHJcbiAgICAgIC8vIHRoaXMub3JkZXJJbmZvID0gd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5jb3Vyc2VJbmZvXHJcbiAgICAgIGF3YWl0IHRoaXMuZ2V0b3JkZXJJbmZvKG9wdClcclxuICAgIH1cclxuICAgIG9uU2hvdygpIHtcclxuICAgICAgdGhpcy5jaGlsZHMgPSB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLmNoaWxkc1xyXG4gICAgfVxyXG4gICAgb25VbmxvYWQoKSB7XHJcbiAgICAgIHRoaXMuY2hpbGRzID0gd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5jaGlsZHMgPSBbXVxyXG4gICAgfVxyXG4gICAgLy8g5qC55o2u6K++56iL6K+m5oOF5Y+C5pWw77yM55Sf5oiQ5pSv5LuY6K6i5Y2V5L+h5oGvXHJcbiAgICBhc3luYyBnZXRvcmRlckluZm8ob3B0KSB7XHJcbiAgICAgIC8qXHJcbiAgICAgICAgcGFyYW1zID17XHJcbiAgICAgICAgICBvcmRlclR5cGU6ICR7b3B0LnR5cGV9LCAvLyDorqLljZXnsbvlnotcclxuICAgICAgICAgIGNvdXJzZUlkOiAke29wdC5jaWR9LCAvLyDor77nqItpZFxyXG4gICAgICAgICAgcGVyaW9kSWQ6ICR7b3B0LnBpZH0sIC8vIOiQpeacn2lkXHJcbiAgICAgICAgICBudW06ICR7b3B0Lm51bX0sIC8vIOaVsOmHj1xyXG4gICAgICAgICAgYWN0SWQ6ICR7b3B0LmFJZH0sIC8vIOa0u+WKqGlkXHJcbiAgICAgICAgfVxyXG4gICAgICAqL1xyXG4gICAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICAgIG9yZGVyVHlwZTogb3B0LnR5cGUsXHJcbiAgICAgICAgY291cnNlSWQ6IG9wdC5jaWQsXHJcbiAgICAgICAgcGVyaW9kSWQ6IG9wdC5waWQsXHJcbiAgICAgICAgbnVtOiBvcHQubnVtLFxyXG4gICAgICAgIGFjdElkOiBvcHQuYWlkXHJcbiAgICAgIH1cclxuICAgICAgbGV0IHtcclxuICAgICAgICBlcnJjb2RlLFxyXG4gICAgICAgIGRhdGFcclxuICAgICAgfSA9IGF3YWl0IGNvbmZpZy5vcmRlckluZm8ocGFyYW1zKVxyXG4gICAgICBpZiAoZXJyY29kZSA9PSAyMDApIHtcclxuICAgICAgICB0aGlzLm9yZGVySW5mbyA9IGRhdGEuY291cnNlXHJcbiAgICAgICAgbGV0IF9kYXRhID0gZGF0YVxyXG4gICAgICAgIHRoaXMucGF5UGFyYW1zID0ge1xyXG4gICAgICAgICAgY2hpbGRJZHM6ICcnLFxyXG4gICAgICAgICAgY291cnNlSWQ6IF9kYXRhLmNvdXJzZUlkLFxyXG4gICAgICAgICAgY291cnNlTnVtOiBfZGF0YS5udW0sXHJcbiAgICAgICAgICBwZXJpb2RJZDogX2RhdGEucGVyaW9kSWQsXHJcbiAgICAgICAgICByZW1hcms6ICcnLFxyXG4gICAgICAgICAgb3JkZXJUeXBlOiBfZGF0YS5vcmRlclR5cGUsXHJcbiAgICAgICAgICBwZXJpb2ROYW1lOiBfZGF0YS5wZXJpb2QsXHJcbiAgICAgICAgICBhY3RJZDogX2RhdGEuYWN0SWQsXHJcbiAgICAgICAgICBwcmljZTogX2RhdGEudG90YWxQcmljZSxcclxuICAgICAgICAgIGFjdFBpbnR1YW5JZDogb3B0LmFjdHBpZCxcclxuICAgICAgICAgIHBheW1lbnRUeXBlIDogb3B0LnB0IHx8IDFcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgfVxyXG4gICAgY29tcHV0ZWQgPSB7XHJcbiAgICAgIG9yZGVyUHJpY2UoKSB7XHJcbiAgICAgICAgaWYgKEpTT04uc3RyaW5naWZ5KHRoaXMucGF5UGFyYW1zKSA9PSAne30nIHx8IEpTT04uc3RyaW5naWZ5KHRoaXMub3JkZXJJbmZvKSA9PSAne30nKSB7XHJcbiAgICAgICAgICByZXR1cm4gJzAuMDAnXHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgICAgIHJldHVybiB0aGlzLnBheVBhcmFtcy5wYXltZW50VHlwZSA9PSAxID8gKHRoaXMucGF5UGFyYW1zLnByaWNlICogdGhpcy5wYXlQYXJhbXMuY291cnNlTnVtKS50b0ZpeGVkKDIpIDogKHRoaXMub3JkZXJJbmZvLmVhcm5lc01vbmV5ICogdGhpcy5wYXlQYXJhbXMuY291cnNlTnVtKS50b0ZpeGVkKDIpXHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIG1ldGhvZHMgPSB7XHJcbiAgICAgIGFzeW5jIGJpbmRnZXRwaG9uZW51bWJlcihlKSB7XHJcbiAgICAgICAgaWYgKGUuZGV0YWlsLmVyck1zZyA9PSBcImdldFBob25lTnVtYmVyOm9rXCIpIHtcclxuICAgICAgICAgIGxldCBtb2JpbGUgPSBhd2FpdCBhdXRoLmdldFBob25lKGUuZGV0YWlsKVxyXG4gICAgICAgICAgaWYgKG1vYmlsZSkge1xyXG4gICAgICAgICAgICB3ZXB5LnNldFN0b3JhZ2VTeW5jKCdtb2JpbGUnLCBtb2JpbGUpO1xyXG4gICAgICAgICAgICB0aGlzLm1vYmlsZSA9IG1vYmlsZVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgICAgIH1cclxuICAgICAgfSxcclxuICAgICAgdGV4dGFyZWFCSW5wdXQoZSkge1xyXG4gICAgICAgIHRoaXMucGF5UGFyYW1zLnJlbWFyayA9IGUuZGV0YWlsLnZhbHVlXHJcbiAgICAgIH0sXHJcbiAgICAgIHBheW1lbnRUeXBlKHR5cGUpIHtcclxuICAgICAgICB0aGlzLnBheVBhcmFtcy5wYXltZW50VHlwZSA9IHR5cGVcclxuICAgICAgfSxcclxuICAgICAgcGx1cygpIHtcclxuICAgICAgICB3eC52aWJyYXRlU2hvcnQoKVxyXG4gICAgICAgIHRoaXMucGF5UGFyYW1zLmNvdXJzZU51bSA9IHRoaXMucGF5UGFyYW1zLmNvdXJzZU51bSArIDFcclxuICAgICAgICB0aGlzLmNoaWxkcyA9IFtdXHJcbiAgICAgIH0sXHJcbiAgICAgIG1pbnVzKCkge1xyXG4gICAgICAgIGlmICh0aGlzLnBheVBhcmFtcy5jb3Vyc2VOdW0gPiAxKSB7XHJcbiAgICAgICAgICB3eC52aWJyYXRlU2hvcnQoKVxyXG4gICAgICAgICAgdGhpcy5wYXlQYXJhbXMuY291cnNlTnVtID0gdGhpcy5wYXlQYXJhbXMuY291cnNlTnVtIC0gMVxyXG4gICAgICAgICAgdGhpcy5jaGlsZHMgPSBbXVxyXG4gICAgICAgIH1cclxuICAgICAgfSxcclxuICAgICAgYXN5bmMgZ2V0Q2hpbGRzKGUpIHtcclxuICAgICAgICBpZiAoIXRoaXMubW9iaWxlKSB7XHJcbiAgICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKGUuZGV0YWlsLmVyck1zZyA9PSBcImdldFVzZXJJbmZvOm9rXCIpIHtcclxuICAgICAgICAgIGF3YWl0IGF1dGguZ2V0VXNlcmluZm8oZS5kZXRhaWwpXHJcbiAgICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICB1cmw6ICcvcGFnZXMvbWVldC9jaGlsZHM/dHlwZT0xJmxlbj0nICsgdGhpcy5wYXlQYXJhbXMuY291cnNlTnVtXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgIH0sXHJcbiAgICAgIGFzeW5jIHBheSgpIHtcclxuICAgICAgICBpZiAoIXRoaXMuY2hpbGRzLmxlbmd0aCB8fCB0aGlzLmNoaWxkcy5sZW5ndGggIT0gdGhpcy5wYXlQYXJhbXMuY291cnNlTnVtKSB7XHJcbiAgICAgICAgICBUaXBzLnRvYXN0KCF0aGlzLmNoaWxkcy5sZW5ndGggPyBcIuivt+WFiOmAieaLqeWHuuihjOS6ulwiIDogXCLotK3kubDmlbDph4/kuI7lh7rooYzkurrmlbDph4/kuI3ljLnphY1cIiwgcmVzID0+IHt9LCAnbm9uZScpO1xyXG4gICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGxldCBpZHMgPSB0aGlzLmNoaWxkcy5tYXAoZSA9PiB7XHJcbiAgICAgICAgICByZXR1cm4gZS5pZFxyXG4gICAgICAgIH0pXHJcbiAgICAgICAgdGhpcy5wYXlQYXJhbXMuY2hpbGRJZHMgPSBpZHMuam9pbignLCcpXHJcbiAgICAgICAgdGhpcy5jYW5wYXkgPSBmYWxzZVxyXG4gICAgICAgIGNvbmZpZy5vcmRlcmNvbW1pdCh0aGlzLnBheVBhcmFtcykudGhlbiggYXN5bmMgcmVzID0+IHtcclxuICAgICAgICAgIGlmIChyZXMuZXJyY29kZSA9PSAyMDApIHtcclxuICAgICAgICAgICAgbGV0IF9jb2RlID0gYXdhaXQgY29uZmlnLnd4cGF5dG9wYXkoe1xyXG4gICAgICAgICAgICAgIG9yZGVyUGF5U246IHJlcy5kYXRhLnBheVNuLFxyXG4gICAgICAgICAgICAgIGRlc2NyaWJlOiAn5o+P6L+wJyxcclxuICAgICAgICAgICAgICBtb25leTogcGFyc2VJbnQocmVzLmRhdGEucGF5QW1vdW50ICogMTAwKVxyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICBXeFV0aWxzLnd4UGF5KF9jb2RlLmRhdGEpLnRoZW4ociA9PiB7XHJcbiAgICAgICAgICAgICAgbGV0IHVybCA9IGBgXHJcbiAgICAgICAgICAgICAgaWYgKHJlcy5kYXRhLm9yZGVyVHlwZSA9PSAxKSB1cmwgPSBgL3BhZ2VzL215L29yZGVyP2lkPWAgKyByZXMuZGF0YS5vcmRlcklkXHJcbiAgICAgICAgICAgICAgaWYgKHJlcy5kYXRhLm9yZGVyVHlwZSA9PSAyKSB1cmwgPSAnL3BhZ2VzL2FjdGl2aXR5L2JhcmdhaW4/aWQ9JyArIHJlcy5kYXRhLmFjdElkXHJcbiAgICAgICAgICAgICAgaWYgKHJlcy5kYXRhLm9yZGVyVHlwZSA9PSAzKSB1cmwgPSAnL3BhZ2VzL2FjdGl2aXR5L3BpbnR1YW4/aWQ9JyArIHJlcy5kYXRhLmFjdElkXHJcbiAgICAgICAgICAgICAgVGlwcy50b2FzdChcIuaUr+S7mOaIkOWKn1wiLCByZSA9PiB7XHJcbiAgICAgICAgICAgICAgICB3eC5yZUxhdW5jaCh7XHJcbiAgICAgICAgICAgICAgICAgIHVybFxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH0pLmNhdGNoKGVyciA9PiB7XHJcbiAgICAgICAgICAgICAgd3gucmVMYXVuY2goe1xyXG4gICAgICAgICAgICAgICAgdXJsOiBgL3BhZ2VzL215L29yZGVyP2lkPWAgKyByZXMuZGF0YS5vcmRlcklkXHJcbiAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSkuY2F0Y2goZXJyPT57XHJcbiAgICAgICAgICB0aGlzLmNhbnBheSA9IHRydWVcclxuICAgICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgICB9KVxyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gIH1cclxuIl19