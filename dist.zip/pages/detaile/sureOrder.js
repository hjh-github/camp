"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

var _WxUtils = require('./../../utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
  _inherits(Dialog, _wepy$page);

  function Dialog() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, Dialog);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
      navigationBarTitleText: "确认订单"
    }, _this.data = {
      modalName: '',
      orderInfo: {},
      payParams: {},
      childs: [],
      mobile: '',
      canpay: true,
      paymentType: 1,
      coupons: [],
      couponUser: {
        id: ''
      },
      opt: {},
      bg_img: {
        cou_bg_1: 'https://images.kuan1.cn/kuan1/upload/image/20201227/20201227141029_82067.png',
        cou_bg_0: 'https://images.kuan1.cn/kuan1/upload/image/20201227/20201227141101_21176.png'
      }
    }, _this.methods = {
      touse: function touse(coupon) {
        this.couponUser = coupon;
        this.modalName = '';
        this.getorderInfo();
      },
      hideModal: function hideModal() {
        this.modalName = '';
      },
      openCoupons: function openCoupons() {
        this.modalName = 'coupons';
      },
      bindgetphonenumber: function () {
        var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(e) {
          var mobile;
          return regeneratorRuntime.wrap(function _callee$(_context) {
            while (1) {
              switch (_context.prev = _context.next) {
                case 0:
                  if (!(e.detail.errMsg == "getPhoneNumber:ok")) {
                    _context.next = 6;
                    break;
                  }

                  _context.next = 3;
                  return _auth2.default.getPhone(e.detail);

                case 3:
                  mobile = _context.sent;

                  if (mobile) {
                    _wepy2.default.setStorageSync('mobile', mobile);
                    this.mobile = mobile;
                  }
                  this.$apply();

                case 6:
                case "end":
                  return _context.stop();
              }
            }
          }, _callee, this);
        }));

        function bindgetphonenumber(_x) {
          return _ref2.apply(this, arguments);
        }

        return bindgetphonenumber;
      }(),
      textareaBInput: function textareaBInput(e) {
        this.payParams.remark = e.detail.value;
      },
      paymentType: function paymentType(type) {
        this.paymentType = type;
        this.getorderInfo();
      },
      plus: function plus() {
        wx.vibrateShort();
        // this.payParams.courseNum = this.payParams.courseNum + 1
        this.opt.num = parseInt(this.opt.num) + 1;
        this.childs = [];
        this.getorderInfo();
      },
      minus: function minus() {
        if (this.opt.num > 1) {
          wx.vibrateShort();
          this.opt.num = parseInt(this.opt.num) - 1;
          this.childs = [];
          this.getorderInfo();
        }
      },
      getChilds: function () {
        var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(e) {
          return regeneratorRuntime.wrap(function _callee2$(_context2) {
            while (1) {
              switch (_context2.prev = _context2.next) {
                case 0:
                  if (this.mobile) {
                    _context2.next = 2;
                    break;
                  }

                  return _context2.abrupt("return", false);

                case 2:
                  if (!(e.detail.errMsg == "getUserInfo:ok")) {
                    _context2.next = 6;
                    break;
                  }

                  _context2.next = 5;
                  return _auth2.default.getUserinfo(e.detail);

                case 5:
                  _wepy2.default.navigateTo({
                    url: '/pages/meet/childs?type=1&len=' + this.payParams.courseNum
                  });

                case 6:
                case "end":
                  return _context2.stop();
              }
            }
          }, _callee2, this);
        }));

        function getChilds(_x2) {
          return _ref3.apply(this, arguments);
        }

        return getChilds;
      }(),
      pay: function () {
        var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
          var _this2 = this;

          var ids;
          return regeneratorRuntime.wrap(function _callee4$(_context4) {
            while (1) {
              switch (_context4.prev = _context4.next) {
                case 0:
                  if (!(!this.childs.length || this.childs.length != this.payParams.courseNum)) {
                    _context4.next = 3;
                    break;
                  }

                  _Tips2.default.toast(!this.childs.length ? "请先选择出行人" : "购买数量与出行人数量不匹配", function (res) {}, 'none');
                  return _context4.abrupt("return", false);

                case 3:
                  ids = this.childs.map(function (e) {
                    return e.id;
                  });

                  this.payParams.childIds = ids.join(',');
                  this.canpay = false;
                  _config2.default.ordercommit(this.payParams).then(function () {
                    var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(res) {
                      var _code;

                      return regeneratorRuntime.wrap(function _callee3$(_context3) {
                        while (1) {
                          switch (_context3.prev = _context3.next) {
                            case 0:
                              if (!(res.errcode == 200)) {
                                _context3.next = 5;
                                break;
                              }

                              _context3.next = 3;
                              return _config2.default.wxpaytopay({
                                orderPaySn: res.data.paySn,
                                describe: '描述',
                                money: parseInt(res.data.payAmount * 100)
                              });

                            case 3:
                              _code = _context3.sent;

                              _WxUtils2.default.wxPay(_code.data).then(function (r) {
                                var url = "";
                                if (res.data.orderType == 1) url = "/pages/my/order?id=" + res.data.orderId;
                                if (res.data.orderType == 2) url = '/pages/activity/bargain?id=' + res.data.actId;
                                if (res.data.orderType == 3) url = '/pages/activity/pintuan?id=' + res.data.actId;
                                _Tips2.default.toast("支付成功", function (re) {
                                  wx.reLaunch({
                                    url: url
                                  });
                                });
                              }).catch(function (err) {
                                wx.reLaunch({
                                  url: "/pages/my/order?id=" + res.data.orderId
                                });
                              });

                            case 5:
                            case "end":
                              return _context3.stop();
                          }
                        }
                      }, _callee3, _this2);
                    }));

                    return function (_x3) {
                      return _ref5.apply(this, arguments);
                    };
                  }()).catch(function (err) {
                    _this2.canpay = true;
                    _this2.$apply();
                  });

                case 7:
                case "end":
                  return _context4.stop();
              }
            }
          }, _callee4, this);
        }));

        function pay() {
          return _ref4.apply(this, arguments);
        }

        return pay;
      }()
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(Dialog, [{
    key: "onLoad",
    value: function () {
      var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5(opt) {
        return regeneratorRuntime.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                this.opt = opt;
                this.paymentType = this.opt.pt;
                this.mobile = _wepy2.default.getStorageSync('mobile');
                // this.payParams = wepy.$instance.globalData.orderInfo
                // this.orderInfo = wepy.$instance.globalData.courseInfo
                _context5.next = 5;
                return this.getorderInfo();

              case 5:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5, this);
      }));

      function onLoad(_x4) {
        return _ref6.apply(this, arguments);
      }

      return onLoad;
    }()
  }, {
    key: "onShow",
    value: function onShow() {
      this.childs = _wepy2.default.$instance.globalData.childs;
    }
  }, {
    key: "onUnload",
    value: function onUnload() {
      this.childs = _wepy2.default.$instance.globalData.childs = [];
    }
    // 根据课程详情参数，生成支付订单信息

  }, {
    key: "getorderInfo",
    value: function () {
      var _ref7 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
        var params, _ref8, errcode, data, _data;

        return regeneratorRuntime.wrap(function _callee6$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                /*
                  params ={
                    orderType: ${opt.type}, // 订单类型
                    courseId: ${opt.cid}, // 课程id
                    periodId: ${opt.pid}, // 营期id
                    num: ${opt.num}, // 数量
                    actId: ${opt.aId}, // 活动id
                  }
                */
                params = {
                  orderType: this.opt.type,
                  courseId: this.opt.cid,
                  periodId: this.opt.pid,
                  num: this.opt.num,
                  actId: this.opt.aid,
                  couponUserId: this.couponUser.id,
                  paymentType: this.paymentType
                };
                _context6.next = 3;
                return _config2.default.orderInfo(params);

              case 3:
                _ref8 = _context6.sent;
                errcode = _ref8.errcode;
                data = _ref8.data;

                if (errcode == 200) {
                  this.orderInfo = data.course;
                  _data = data;
                  // 有可用券 并选中

                  if (data.couponUser) {
                    this.couponUser = data.couponUser;
                  } else {
                    this.couponUser = {
                      id: ''
                    };
                  }
                  // 有可用券
                  if (data.couponUserList) {
                    this.coupons = data.couponUserList;
                  } else {
                    this.coupons = [];
                  }

                  this.payParams = {
                    childIds: '',
                    courseId: _data.courseId,
                    courseNum: _data.num,
                    periodId: _data.periodId,
                    remark: '',
                    orderType: _data.orderType,
                    periodName: _data.period,
                    actId: _data.actId,
                    price: _data.totalPrice,
                    actPintuanId: this.opt.actpid,
                    paymentType: this.paymentType,
                    couponUserId: this.couponUser.id
                  };
                }
                this.$apply();

              case 8:
              case "end":
                return _context6.stop();
            }
          }
        }, _callee6, this);
      }));

      function getorderInfo() {
        return _ref7.apply(this, arguments);
      }

      return getorderInfo;
    }()
    // computed = {
    //   orderPrice() {
    //     if (JSON.stringify(this.payParams) == '{}' || JSON.stringify(this.orderInfo) == '{}') {
    //       return '0.00'
    //     }
    //     return this.payParams.paymentType == 1 ? (this.payParams.price * this.payParams.courseNum).toFixed(2) : (this.orderInfo.earnesMoney * this.payParams.courseNum).toFixed(2)
    //   }
    // }

  }]);

  return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/detaile/sureOrder'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN1cmVPcmRlci5qcyJdLCJuYW1lcyI6WyJEaWFsb2ciLCJjb25maWciLCJuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0IiwiZGF0YSIsIm1vZGFsTmFtZSIsIm9yZGVySW5mbyIsInBheVBhcmFtcyIsImNoaWxkcyIsIm1vYmlsZSIsImNhbnBheSIsInBheW1lbnRUeXBlIiwiY291cG9ucyIsImNvdXBvblVzZXIiLCJpZCIsIm9wdCIsImJnX2ltZyIsImNvdV9iZ18xIiwiY291X2JnXzAiLCJtZXRob2RzIiwidG91c2UiLCJjb3Vwb24iLCJnZXRvcmRlckluZm8iLCJoaWRlTW9kYWwiLCJvcGVuQ291cG9ucyIsImJpbmRnZXRwaG9uZW51bWJlciIsImUiLCJkZXRhaWwiLCJlcnJNc2ciLCJhdXRoIiwiZ2V0UGhvbmUiLCJ3ZXB5Iiwic2V0U3RvcmFnZVN5bmMiLCIkYXBwbHkiLCJ0ZXh0YXJlYUJJbnB1dCIsInJlbWFyayIsInZhbHVlIiwidHlwZSIsInBsdXMiLCJ3eCIsInZpYnJhdGVTaG9ydCIsIm51bSIsInBhcnNlSW50IiwibWludXMiLCJnZXRDaGlsZHMiLCJnZXRVc2VyaW5mbyIsIm5hdmlnYXRlVG8iLCJ1cmwiLCJjb3Vyc2VOdW0iLCJwYXkiLCJsZW5ndGgiLCJUaXBzIiwidG9hc3QiLCJpZHMiLCJtYXAiLCJjaGlsZElkcyIsImpvaW4iLCJvcmRlcmNvbW1pdCIsInRoZW4iLCJyZXMiLCJlcnJjb2RlIiwid3hwYXl0b3BheSIsIm9yZGVyUGF5U24iLCJwYXlTbiIsImRlc2NyaWJlIiwibW9uZXkiLCJwYXlBbW91bnQiLCJfY29kZSIsIld4VXRpbHMiLCJ3eFBheSIsIm9yZGVyVHlwZSIsIm9yZGVySWQiLCJhY3RJZCIsInJlTGF1bmNoIiwiY2F0Y2giLCJwdCIsImdldFN0b3JhZ2VTeW5jIiwiJGluc3RhbmNlIiwiZ2xvYmFsRGF0YSIsInBhcmFtcyIsImNvdXJzZUlkIiwiY2lkIiwicGVyaW9kSWQiLCJwaWQiLCJhaWQiLCJjb3Vwb25Vc2VySWQiLCJjb3Vyc2UiLCJfZGF0YSIsImNvdXBvblVzZXJMaXN0IiwicGVyaW9kTmFtZSIsInBlcmlvZCIsInByaWNlIiwidG90YWxQcmljZSIsImFjdFBpbnR1YW5JZCIsImFjdHBpZCIsInBhZ2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUNFOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7Ozs7Ozs7Ozs7O0lBQ3FCQSxNOzs7Ozs7Ozs7Ozs7OztzTEFDbkJDLE0sR0FBUztBQUNQQyw4QkFBd0I7QUFEakIsSyxRQUdUQyxJLEdBQU87QUFDTEMsaUJBQVcsRUFETjtBQUVMQyxpQkFBVyxFQUZOO0FBR0xDLGlCQUFXLEVBSE47QUFJTEMsY0FBUSxFQUpIO0FBS0xDLGNBQVEsRUFMSDtBQU1MQyxjQUFRLElBTkg7QUFPTEMsbUJBQWEsQ0FQUjtBQVFMQyxlQUFTLEVBUko7QUFTTEMsa0JBQVk7QUFDVkMsWUFBSTtBQURNLE9BVFA7QUFZTEMsV0FBSyxFQVpBO0FBYUxDLGNBQVE7QUFDTkMsa0JBQVUsOEVBREo7QUFFTkMsa0JBQVU7QUFGSjtBQWJILEssUUFtR1BDLE8sR0FBVTtBQUNSQyxXQURRLGlCQUNGQyxNQURFLEVBQ007QUFDWixhQUFLUixVQUFMLEdBQWtCUSxNQUFsQjtBQUNBLGFBQUtoQixTQUFMLEdBQWlCLEVBQWpCO0FBQ0EsYUFBS2lCLFlBQUw7QUFDRCxPQUxPO0FBTVJDLGVBTlEsdUJBTUk7QUFDVixhQUFLbEIsU0FBTCxHQUFpQixFQUFqQjtBQUNELE9BUk87QUFTUm1CLGlCQVRRLHlCQVNNO0FBQ1osYUFBS25CLFNBQUwsR0FBaUIsU0FBakI7QUFDRCxPQVhPO0FBWUZvQix3QkFaRTtBQUFBLDZGQVlpQkMsQ0FaakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBYUZBLEVBQUVDLE1BQUYsQ0FBU0MsTUFBVCxJQUFtQixtQkFiakI7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQSx5QkFjZUMsZUFBS0MsUUFBTCxDQUFjSixFQUFFQyxNQUFoQixDQWRmOztBQUFBO0FBY0FsQix3QkFkQTs7QUFlSixzQkFBSUEsTUFBSixFQUFZO0FBQ1ZzQixtQ0FBS0MsY0FBTCxDQUFvQixRQUFwQixFQUE4QnZCLE1BQTlCO0FBQ0EseUJBQUtBLE1BQUwsR0FBY0EsTUFBZDtBQUNEO0FBQ0QsdUJBQUt3QixNQUFMOztBQW5CSTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQXNCUkMsb0JBdEJRLDBCQXNCT1IsQ0F0QlAsRUFzQlU7QUFDaEIsYUFBS25CLFNBQUwsQ0FBZTRCLE1BQWYsR0FBd0JULEVBQUVDLE1BQUYsQ0FBU1MsS0FBakM7QUFDRCxPQXhCTztBQXlCUnpCLGlCQXpCUSx1QkF5QkkwQixJQXpCSixFQXlCVTtBQUNoQixhQUFLMUIsV0FBTCxHQUFtQjBCLElBQW5CO0FBQ0EsYUFBS2YsWUFBTDtBQUNELE9BNUJPO0FBNkJSZ0IsVUE3QlEsa0JBNkJEO0FBQ0xDLFdBQUdDLFlBQUg7QUFDQTtBQUNBLGFBQUt6QixHQUFMLENBQVMwQixHQUFULEdBQWVDLFNBQVMsS0FBSzNCLEdBQUwsQ0FBUzBCLEdBQWxCLElBQXlCLENBQXhDO0FBQ0EsYUFBS2pDLE1BQUwsR0FBYyxFQUFkO0FBQ0EsYUFBS2MsWUFBTDtBQUNELE9BbkNPO0FBb0NScUIsV0FwQ1EsbUJBb0NBO0FBQ04sWUFBSSxLQUFLNUIsR0FBTCxDQUFTMEIsR0FBVCxHQUFlLENBQW5CLEVBQXNCO0FBQ3BCRixhQUFHQyxZQUFIO0FBQ0EsZUFBS3pCLEdBQUwsQ0FBUzBCLEdBQVQsR0FBZUMsU0FBUyxLQUFLM0IsR0FBTCxDQUFTMEIsR0FBbEIsSUFBeUIsQ0FBeEM7QUFDQSxlQUFLakMsTUFBTCxHQUFjLEVBQWQ7QUFDQSxlQUFLYyxZQUFMO0FBQ0Q7QUFDRixPQTNDTztBQTRDRnNCLGVBNUNFO0FBQUEsOEZBNENRbEIsQ0E1Q1I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQTZDRCxLQUFLakIsTUE3Q0o7QUFBQTtBQUFBO0FBQUE7O0FBQUEsb0RBOENHLEtBOUNIOztBQUFBO0FBQUEsd0JBZ0RGaUIsRUFBRUMsTUFBRixDQUFTQyxNQUFULElBQW1CLGdCQWhEakI7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQSx5QkFpREVDLGVBQUtnQixXQUFMLENBQWlCbkIsRUFBRUMsTUFBbkIsQ0FqREY7O0FBQUE7QUFrREpJLGlDQUFLZSxVQUFMLENBQWdCO0FBQ2RDLHlCQUFLLG1DQUFtQyxLQUFLeEMsU0FBTCxDQUFleUM7QUFEekMsbUJBQWhCOztBQWxESTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQXVERkMsU0F2REU7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkF3REYsQ0FBQyxLQUFLekMsTUFBTCxDQUFZMEMsTUFBYixJQUF1QixLQUFLMUMsTUFBTCxDQUFZMEMsTUFBWixJQUFzQixLQUFLM0MsU0FBTCxDQUFleUMsU0F4RDFEO0FBQUE7QUFBQTtBQUFBOztBQXlESkcsaUNBQUtDLEtBQUwsQ0FBVyxDQUFDLEtBQUs1QyxNQUFMLENBQVkwQyxNQUFiLEdBQXNCLFNBQXRCLEdBQWtDLGVBQTdDLEVBQThELGVBQU8sQ0FBRSxDQUF2RSxFQUF5RSxNQUF6RTtBQXpESSxvREEwREcsS0ExREg7O0FBQUE7QUE0REZHLHFCQTVERSxHQTRESSxLQUFLN0MsTUFBTCxDQUFZOEMsR0FBWixDQUFnQixhQUFLO0FBQzdCLDJCQUFPNUIsRUFBRVosRUFBVDtBQUNELG1CQUZTLENBNURKOztBQStETix1QkFBS1AsU0FBTCxDQUFlZ0QsUUFBZixHQUEwQkYsSUFBSUcsSUFBSixDQUFTLEdBQVQsQ0FBMUI7QUFDQSx1QkFBSzlDLE1BQUwsR0FBYyxLQUFkO0FBQ0FSLG1DQUFPdUQsV0FBUCxDQUFtQixLQUFLbEQsU0FBeEIsRUFBbUNtRCxJQUFuQztBQUFBLHdGQUF3QyxrQkFBTUMsR0FBTjtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0NBQ2xDQSxJQUFJQyxPQUFKLElBQWUsR0FEbUI7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQSxxQ0FFbEIxRCxpQkFBTzJELFVBQVAsQ0FBa0I7QUFDbENDLDRDQUFZSCxJQUFJdkQsSUFBSixDQUFTMkQsS0FEYTtBQUVsQ0MsMENBQVUsSUFGd0I7QUFHbENDLHVDQUFPdkIsU0FBU2lCLElBQUl2RCxJQUFKLENBQVM4RCxTQUFULEdBQXFCLEdBQTlCO0FBSDJCLCtCQUFsQixDQUZrQjs7QUFBQTtBQUVoQ0MsbUNBRmdDOztBQU9wQ0MsZ0RBQVFDLEtBQVIsQ0FBY0YsTUFBTS9ELElBQXBCLEVBQTBCc0QsSUFBMUIsQ0FBK0IsYUFBSztBQUNsQyxvQ0FBSVgsUUFBSjtBQUNBLG9DQUFJWSxJQUFJdkQsSUFBSixDQUFTa0UsU0FBVCxJQUFzQixDQUExQixFQUE2QnZCLE1BQU0sd0JBQXdCWSxJQUFJdkQsSUFBSixDQUFTbUUsT0FBdkM7QUFDN0Isb0NBQUlaLElBQUl2RCxJQUFKLENBQVNrRSxTQUFULElBQXNCLENBQTFCLEVBQTZCdkIsTUFBTSxnQ0FBZ0NZLElBQUl2RCxJQUFKLENBQVNvRSxLQUEvQztBQUM3QixvQ0FBSWIsSUFBSXZELElBQUosQ0FBU2tFLFNBQVQsSUFBc0IsQ0FBMUIsRUFBNkJ2QixNQUFNLGdDQUFnQ1ksSUFBSXZELElBQUosQ0FBU29FLEtBQS9DO0FBQzdCckIsK0NBQUtDLEtBQUwsQ0FBVyxNQUFYLEVBQW1CLGNBQU07QUFDdkJiLHFDQUFHa0MsUUFBSCxDQUFZO0FBQ1YxQjtBQURVLG1DQUFaO0FBR0QsaUNBSkQ7QUFLRCwrQkFWRCxFQVVHMkIsS0FWSCxDQVVTLGVBQU87QUFDZG5DLG1DQUFHa0MsUUFBSCxDQUFZO0FBQ1YxQix1Q0FBSyx3QkFBd0JZLElBQUl2RCxJQUFKLENBQVNtRTtBQUQ1QixpQ0FBWjtBQUdELCtCQWREOztBQVBvQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeEM7O0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBdUJHRyxLQXZCSCxDQXVCUyxlQUFPO0FBQ2QsMkJBQUtoRSxNQUFMLEdBQWMsSUFBZDtBQUNBLDJCQUFLdUIsTUFBTDtBQUNELG1CQTFCRDs7QUFqRU07QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQSxLOzs7Ozs7NEZBakZHbEIsRzs7Ozs7QUFDWCxxQkFBS0EsR0FBTCxHQUFXQSxHQUFYO0FBQ0EscUJBQUtKLFdBQUwsR0FBbUIsS0FBS0ksR0FBTCxDQUFTNEQsRUFBNUI7QUFDQSxxQkFBS2xFLE1BQUwsR0FBY3NCLGVBQUs2QyxjQUFMLENBQW9CLFFBQXBCLENBQWQ7QUFDQTtBQUNBOzt1QkFDTSxLQUFLdEQsWUFBTCxFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7NkJBRUM7QUFDUCxXQUFLZCxNQUFMLEdBQWN1QixlQUFLOEMsU0FBTCxDQUFlQyxVQUFmLENBQTBCdEUsTUFBeEM7QUFDRDs7OytCQUNVO0FBQ1QsV0FBS0EsTUFBTCxHQUFjdUIsZUFBSzhDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQnRFLE1BQTFCLEdBQW1DLEVBQWpEO0FBQ0Q7QUFDRDs7Ozs7Ozs7Ozs7O0FBRUU7Ozs7Ozs7OztBQVNJdUUsc0IsR0FBUztBQUNYVCw2QkFBVyxLQUFLdkQsR0FBTCxDQUFTc0IsSUFEVDtBQUVYMkMsNEJBQVUsS0FBS2pFLEdBQUwsQ0FBU2tFLEdBRlI7QUFHWEMsNEJBQVUsS0FBS25FLEdBQUwsQ0FBU29FLEdBSFI7QUFJWDFDLHVCQUFLLEtBQUsxQixHQUFMLENBQVMwQixHQUpIO0FBS1grQix5QkFBTyxLQUFLekQsR0FBTCxDQUFTcUUsR0FMTDtBQU1YQyxnQ0FBYyxLQUFLeEUsVUFBTCxDQUFnQkMsRUFObkI7QUFPWEgsK0JBQWEsS0FBS0E7QUFQUCxpQjs7dUJBWUhULGlCQUFPSSxTQUFQLENBQWlCeUUsTUFBakIsQzs7OztBQUZSbkIsdUIsU0FBQUEsTztBQUNBeEQsb0IsU0FBQUEsSTs7QUFFRixvQkFBSXdELFdBQVcsR0FBZixFQUFvQjtBQUNsQix1QkFBS3RELFNBQUwsR0FBaUJGLEtBQUtrRixNQUF0QjtBQUNJQyx1QkFGYyxHQUVObkYsSUFGTTtBQUdsQjs7QUFDQSxzQkFBSUEsS0FBS1MsVUFBVCxFQUFxQjtBQUNuQix5QkFBS0EsVUFBTCxHQUFrQlQsS0FBS1MsVUFBdkI7QUFDRCxtQkFGRCxNQUVPO0FBQ0wseUJBQUtBLFVBQUwsR0FBa0I7QUFDaEJDLDBCQUFJO0FBRFkscUJBQWxCO0FBR0Q7QUFDRDtBQUNBLHNCQUFJVixLQUFLb0YsY0FBVCxFQUF5QjtBQUN2Qix5QkFBSzVFLE9BQUwsR0FBZVIsS0FBS29GLGNBQXBCO0FBQ0QsbUJBRkQsTUFFSztBQUNILHlCQUFLNUUsT0FBTCxHQUFlLEVBQWY7QUFDRDs7QUFFRCx1QkFBS0wsU0FBTCxHQUFpQjtBQUNmZ0QsOEJBQVUsRUFESztBQUVmeUIsOEJBQVVPLE1BQU1QLFFBRkQ7QUFHZmhDLCtCQUFXdUMsTUFBTTlDLEdBSEY7QUFJZnlDLDhCQUFVSyxNQUFNTCxRQUpEO0FBS2YvQyw0QkFBUSxFQUxPO0FBTWZtQywrQkFBV2lCLE1BQU1qQixTQU5GO0FBT2ZtQixnQ0FBWUYsTUFBTUcsTUFQSDtBQVFmbEIsMkJBQU9lLE1BQU1mLEtBUkU7QUFTZm1CLDJCQUFPSixNQUFNSyxVQVRFO0FBVWZDLGtDQUFjLEtBQUs5RSxHQUFMLENBQVMrRSxNQVZSO0FBV2ZuRixpQ0FBYSxLQUFLQSxXQVhIO0FBWWYwRSxrQ0FBYSxLQUFLeEUsVUFBTCxDQUFnQkM7QUFaZCxtQkFBakI7QUFjRDtBQUNELHFCQUFLbUIsTUFBTDs7Ozs7Ozs7Ozs7Ozs7OztBQUVGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7O0VBdEdrQ0YsZUFBS2dFLEk7O2tCQUFwQjlGLE0iLCJmaWxlIjoic3VyZU9yZGVyLmpzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbiAgaW1wb3J0IHdlcHkgZnJvbSBcIndlcHlcIjtcclxuICBpbXBvcnQgY29uZmlnIGZyb20gXCJAL2FwaS9jb25maWdcIlxyXG4gIGltcG9ydCBUaXBzIGZyb20gXCJAL3V0aWxzL1RpcHNcIlxyXG4gIGltcG9ydCBXeFV0aWxzIGZyb20gXCJAL3V0aWxzL1d4VXRpbHNcIlxyXG4gIGltcG9ydCBhdXRoIGZyb20gXCJAL2FwaS9hdXRoXCJcclxuICBleHBvcnQgZGVmYXVsdCBjbGFzcyBEaWFsb2cgZXh0ZW5kcyB3ZXB5LnBhZ2Uge1xyXG4gICAgY29uZmlnID0ge1xyXG4gICAgICBuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0OiBcIuehruiupOiuouWNlVwiXHJcbiAgICB9O1xyXG4gICAgZGF0YSA9IHtcclxuICAgICAgbW9kYWxOYW1lOiAnJyxcclxuICAgICAgb3JkZXJJbmZvOiB7fSxcclxuICAgICAgcGF5UGFyYW1zOiB7fSxcclxuICAgICAgY2hpbGRzOiBbXSxcclxuICAgICAgbW9iaWxlOiAnJyxcclxuICAgICAgY2FucGF5OiB0cnVlLFxyXG4gICAgICBwYXltZW50VHlwZTogMSxcclxuICAgICAgY291cG9uczogW10sXHJcbiAgICAgIGNvdXBvblVzZXI6IHtcclxuICAgICAgICBpZDogJydcclxuICAgICAgfSxcclxuICAgICAgb3B0OiB7fSxcclxuICAgICAgYmdfaW1nOiB7XHJcbiAgICAgICAgY291X2JnXzE6ICdodHRwczovL2ltYWdlcy5rdWFuMS5jbi9rdWFuMS91cGxvYWQvaW1hZ2UvMjAyMDEyMjcvMjAyMDEyMjcxNDEwMjlfODIwNjcucG5nJyxcclxuICAgICAgICBjb3VfYmdfMDogJ2h0dHBzOi8vaW1hZ2VzLmt1YW4xLmNuL2t1YW4xL3VwbG9hZC9pbWFnZS8yMDIwMTIyNy8yMDIwMTIyNzE0MTEwMV8yMTE3Ni5wbmcnLFxyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgYXN5bmMgb25Mb2FkKG9wdCkge1xyXG4gICAgICB0aGlzLm9wdCA9IG9wdFxyXG4gICAgICB0aGlzLnBheW1lbnRUeXBlID0gdGhpcy5vcHQucHRcclxuICAgICAgdGhpcy5tb2JpbGUgPSB3ZXB5LmdldFN0b3JhZ2VTeW5jKCdtb2JpbGUnKTtcclxuICAgICAgLy8gdGhpcy5wYXlQYXJhbXMgPSB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLm9yZGVySW5mb1xyXG4gICAgICAvLyB0aGlzLm9yZGVySW5mbyA9IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuY291cnNlSW5mb1xyXG4gICAgICBhd2FpdCB0aGlzLmdldG9yZGVySW5mbygpXHJcbiAgICB9XHJcbiAgICBvblNob3coKSB7XHJcbiAgICAgIHRoaXMuY2hpbGRzID0gd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5jaGlsZHNcclxuICAgIH1cclxuICAgIG9uVW5sb2FkKCkge1xyXG4gICAgICB0aGlzLmNoaWxkcyA9IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuY2hpbGRzID0gW11cclxuICAgIH1cclxuICAgIC8vIOagueaNruivvueoi+ivpuaDheWPguaVsO+8jOeUn+aIkOaUr+S7mOiuouWNleS/oeaBr1xyXG4gICAgYXN5bmMgZ2V0b3JkZXJJbmZvKCkge1xyXG4gICAgICAvKlxyXG4gICAgICAgIHBhcmFtcyA9e1xyXG4gICAgICAgICAgb3JkZXJUeXBlOiAke29wdC50eXBlfSwgLy8g6K6i5Y2V57G75Z6LXHJcbiAgICAgICAgICBjb3Vyc2VJZDogJHtvcHQuY2lkfSwgLy8g6K++56iLaWRcclxuICAgICAgICAgIHBlcmlvZElkOiAke29wdC5waWR9LCAvLyDokKXmnJ9pZFxyXG4gICAgICAgICAgbnVtOiAke29wdC5udW19LCAvLyDmlbDph49cclxuICAgICAgICAgIGFjdElkOiAke29wdC5hSWR9LCAvLyDmtLvliqhpZFxyXG4gICAgICAgIH1cclxuICAgICAgKi9cclxuICAgICAgbGV0IHBhcmFtcyA9IHtcclxuICAgICAgICBvcmRlclR5cGU6IHRoaXMub3B0LnR5cGUsXHJcbiAgICAgICAgY291cnNlSWQ6IHRoaXMub3B0LmNpZCxcclxuICAgICAgICBwZXJpb2RJZDogdGhpcy5vcHQucGlkLFxyXG4gICAgICAgIG51bTogdGhpcy5vcHQubnVtLFxyXG4gICAgICAgIGFjdElkOiB0aGlzLm9wdC5haWQsXHJcbiAgICAgICAgY291cG9uVXNlcklkOiB0aGlzLmNvdXBvblVzZXIuaWQsXHJcbiAgICAgICAgcGF5bWVudFR5cGU6IHRoaXMucGF5bWVudFR5cGVcclxuICAgICAgfVxyXG4gICAgICBsZXQge1xyXG4gICAgICAgIGVycmNvZGUsXHJcbiAgICAgICAgZGF0YVxyXG4gICAgICB9ID0gYXdhaXQgY29uZmlnLm9yZGVySW5mbyhwYXJhbXMpXHJcbiAgICAgIGlmIChlcnJjb2RlID09IDIwMCkge1xyXG4gICAgICAgIHRoaXMub3JkZXJJbmZvID0gZGF0YS5jb3Vyc2VcclxuICAgICAgICBsZXQgX2RhdGEgPSBkYXRhXHJcbiAgICAgICAgLy8g5pyJ5Y+v55So5Yi4IOW5tumAieS4rVxyXG4gICAgICAgIGlmIChkYXRhLmNvdXBvblVzZXIpIHtcclxuICAgICAgICAgIHRoaXMuY291cG9uVXNlciA9IGRhdGEuY291cG9uVXNlclxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICB0aGlzLmNvdXBvblVzZXIgPSB7XHJcbiAgICAgICAgICAgIGlkOiAnJ1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICAvLyDmnInlj6/nlKjliLhcclxuICAgICAgICBpZiAoZGF0YS5jb3Vwb25Vc2VyTGlzdCkge1xyXG4gICAgICAgICAgdGhpcy5jb3Vwb25zID0gZGF0YS5jb3Vwb25Vc2VyTGlzdFxyXG4gICAgICAgIH1lbHNle1xyXG4gICAgICAgICAgdGhpcy5jb3Vwb25zID0gW11cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMucGF5UGFyYW1zID0ge1xyXG4gICAgICAgICAgY2hpbGRJZHM6ICcnLFxyXG4gICAgICAgICAgY291cnNlSWQ6IF9kYXRhLmNvdXJzZUlkLFxyXG4gICAgICAgICAgY291cnNlTnVtOiBfZGF0YS5udW0sXHJcbiAgICAgICAgICBwZXJpb2RJZDogX2RhdGEucGVyaW9kSWQsXHJcbiAgICAgICAgICByZW1hcms6ICcnLFxyXG4gICAgICAgICAgb3JkZXJUeXBlOiBfZGF0YS5vcmRlclR5cGUsXHJcbiAgICAgICAgICBwZXJpb2ROYW1lOiBfZGF0YS5wZXJpb2QsXHJcbiAgICAgICAgICBhY3RJZDogX2RhdGEuYWN0SWQsXHJcbiAgICAgICAgICBwcmljZTogX2RhdGEudG90YWxQcmljZSxcclxuICAgICAgICAgIGFjdFBpbnR1YW5JZDogdGhpcy5vcHQuYWN0cGlkLFxyXG4gICAgICAgICAgcGF5bWVudFR5cGU6IHRoaXMucGF5bWVudFR5cGUsXHJcbiAgICAgICAgICBjb3Vwb25Vc2VySWQ6dGhpcy5jb3Vwb25Vc2VyLmlkXHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgIH1cclxuICAgIC8vIGNvbXB1dGVkID0ge1xyXG4gICAgLy8gICBvcmRlclByaWNlKCkge1xyXG4gICAgLy8gICAgIGlmIChKU09OLnN0cmluZ2lmeSh0aGlzLnBheVBhcmFtcykgPT0gJ3t9JyB8fCBKU09OLnN0cmluZ2lmeSh0aGlzLm9yZGVySW5mbykgPT0gJ3t9Jykge1xyXG4gICAgLy8gICAgICAgcmV0dXJuICcwLjAwJ1xyXG4gICAgLy8gICAgIH1cclxuICAgIC8vICAgICByZXR1cm4gdGhpcy5wYXlQYXJhbXMucGF5bWVudFR5cGUgPT0gMSA/ICh0aGlzLnBheVBhcmFtcy5wcmljZSAqIHRoaXMucGF5UGFyYW1zLmNvdXJzZU51bSkudG9GaXhlZCgyKSA6ICh0aGlzLm9yZGVySW5mby5lYXJuZXNNb25leSAqIHRoaXMucGF5UGFyYW1zLmNvdXJzZU51bSkudG9GaXhlZCgyKVxyXG4gICAgLy8gICB9XHJcbiAgICAvLyB9XHJcbiAgICBtZXRob2RzID0ge1xyXG4gICAgICB0b3VzZShjb3Vwb24pIHtcclxuICAgICAgICB0aGlzLmNvdXBvblVzZXIgPSBjb3Vwb25cclxuICAgICAgICB0aGlzLm1vZGFsTmFtZSA9ICcnXHJcbiAgICAgICAgdGhpcy5nZXRvcmRlckluZm8oKVxyXG4gICAgICB9LFxyXG4gICAgICBoaWRlTW9kYWwoKSB7XHJcbiAgICAgICAgdGhpcy5tb2RhbE5hbWUgPSAnJ1xyXG4gICAgICB9LFxyXG4gICAgICBvcGVuQ291cG9ucygpIHtcclxuICAgICAgICB0aGlzLm1vZGFsTmFtZSA9ICdjb3Vwb25zJ1xyXG4gICAgICB9LFxyXG4gICAgICBhc3luYyBiaW5kZ2V0cGhvbmVudW1iZXIoZSkge1xyXG4gICAgICAgIGlmIChlLmRldGFpbC5lcnJNc2cgPT0gXCJnZXRQaG9uZU51bWJlcjpva1wiKSB7XHJcbiAgICAgICAgICBsZXQgbW9iaWxlID0gYXdhaXQgYXV0aC5nZXRQaG9uZShlLmRldGFpbClcclxuICAgICAgICAgIGlmIChtb2JpbGUpIHtcclxuICAgICAgICAgICAgd2VweS5zZXRTdG9yYWdlU3luYygnbW9iaWxlJywgbW9iaWxlKTtcclxuICAgICAgICAgICAgdGhpcy5tb2JpbGUgPSBtb2JpbGVcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgICB9XHJcbiAgICAgIH0sXHJcbiAgICAgIHRleHRhcmVhQklucHV0KGUpIHtcclxuICAgICAgICB0aGlzLnBheVBhcmFtcy5yZW1hcmsgPSBlLmRldGFpbC52YWx1ZVxyXG4gICAgICB9LFxyXG4gICAgICBwYXltZW50VHlwZSh0eXBlKSB7XHJcbiAgICAgICAgdGhpcy5wYXltZW50VHlwZSA9IHR5cGVcclxuICAgICAgICB0aGlzLmdldG9yZGVySW5mbygpXHJcbiAgICAgIH0sXHJcbiAgICAgIHBsdXMoKSB7XHJcbiAgICAgICAgd3gudmlicmF0ZVNob3J0KClcclxuICAgICAgICAvLyB0aGlzLnBheVBhcmFtcy5jb3Vyc2VOdW0gPSB0aGlzLnBheVBhcmFtcy5jb3Vyc2VOdW0gKyAxXHJcbiAgICAgICAgdGhpcy5vcHQubnVtID0gcGFyc2VJbnQodGhpcy5vcHQubnVtKSArIDFcclxuICAgICAgICB0aGlzLmNoaWxkcyA9IFtdXHJcbiAgICAgICAgdGhpcy5nZXRvcmRlckluZm8oKVxyXG4gICAgICB9LFxyXG4gICAgICBtaW51cygpIHtcclxuICAgICAgICBpZiAodGhpcy5vcHQubnVtID4gMSkge1xyXG4gICAgICAgICAgd3gudmlicmF0ZVNob3J0KClcclxuICAgICAgICAgIHRoaXMub3B0Lm51bSA9IHBhcnNlSW50KHRoaXMub3B0Lm51bSkgLSAxXHJcbiAgICAgICAgICB0aGlzLmNoaWxkcyA9IFtdXHJcbiAgICAgICAgICB0aGlzLmdldG9yZGVySW5mbygpXHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG4gICAgICBhc3luYyBnZXRDaGlsZHMoZSkge1xyXG4gICAgICAgIGlmICghdGhpcy5tb2JpbGUpIHtcclxuICAgICAgICAgIHJldHVybiBmYWxzZVxyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoZS5kZXRhaWwuZXJyTXNnID09IFwiZ2V0VXNlckluZm86b2tcIikge1xyXG4gICAgICAgICAgYXdhaXQgYXV0aC5nZXRVc2VyaW5mbyhlLmRldGFpbClcclxuICAgICAgICAgIHdlcHkubmF2aWdhdGVUbyh7XHJcbiAgICAgICAgICAgIHVybDogJy9wYWdlcy9tZWV0L2NoaWxkcz90eXBlPTEmbGVuPScgKyB0aGlzLnBheVBhcmFtcy5jb3Vyc2VOdW1cclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgfSxcclxuICAgICAgYXN5bmMgcGF5KCkge1xyXG4gICAgICAgIGlmICghdGhpcy5jaGlsZHMubGVuZ3RoIHx8IHRoaXMuY2hpbGRzLmxlbmd0aCAhPSB0aGlzLnBheVBhcmFtcy5jb3Vyc2VOdW0pIHtcclxuICAgICAgICAgIFRpcHMudG9hc3QoIXRoaXMuY2hpbGRzLmxlbmd0aCA/IFwi6K+35YWI6YCJ5oup5Ye66KGM5Lq6XCIgOiBcIui0reS5sOaVsOmHj+S4juWHuuihjOS6uuaVsOmHj+S4jeWMuemFjVwiLCByZXMgPT4ge30sICdub25lJyk7XHJcbiAgICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgICB9XHJcbiAgICAgICAgbGV0IGlkcyA9IHRoaXMuY2hpbGRzLm1hcChlID0+IHtcclxuICAgICAgICAgIHJldHVybiBlLmlkXHJcbiAgICAgICAgfSlcclxuICAgICAgICB0aGlzLnBheVBhcmFtcy5jaGlsZElkcyA9IGlkcy5qb2luKCcsJylcclxuICAgICAgICB0aGlzLmNhbnBheSA9IGZhbHNlXHJcbiAgICAgICAgY29uZmlnLm9yZGVyY29tbWl0KHRoaXMucGF5UGFyYW1zKS50aGVuKGFzeW5jIHJlcyA9PiB7XHJcbiAgICAgICAgICBpZiAocmVzLmVycmNvZGUgPT0gMjAwKSB7XHJcbiAgICAgICAgICAgIGxldCBfY29kZSA9IGF3YWl0IGNvbmZpZy53eHBheXRvcGF5KHtcclxuICAgICAgICAgICAgICBvcmRlclBheVNuOiByZXMuZGF0YS5wYXlTbixcclxuICAgICAgICAgICAgICBkZXNjcmliZTogJ+aPj+i/sCcsXHJcbiAgICAgICAgICAgICAgbW9uZXk6IHBhcnNlSW50KHJlcy5kYXRhLnBheUFtb3VudCAqIDEwMClcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgV3hVdGlscy53eFBheShfY29kZS5kYXRhKS50aGVuKHIgPT4ge1xyXG4gICAgICAgICAgICAgIGxldCB1cmwgPSBgYFxyXG4gICAgICAgICAgICAgIGlmIChyZXMuZGF0YS5vcmRlclR5cGUgPT0gMSkgdXJsID0gYC9wYWdlcy9teS9vcmRlcj9pZD1gICsgcmVzLmRhdGEub3JkZXJJZFxyXG4gICAgICAgICAgICAgIGlmIChyZXMuZGF0YS5vcmRlclR5cGUgPT0gMikgdXJsID0gJy9wYWdlcy9hY3Rpdml0eS9iYXJnYWluP2lkPScgKyByZXMuZGF0YS5hY3RJZFxyXG4gICAgICAgICAgICAgIGlmIChyZXMuZGF0YS5vcmRlclR5cGUgPT0gMykgdXJsID0gJy9wYWdlcy9hY3Rpdml0eS9waW50dWFuP2lkPScgKyByZXMuZGF0YS5hY3RJZFxyXG4gICAgICAgICAgICAgIFRpcHMudG9hc3QoXCLmlK/ku5jmiJDlip9cIiwgcmUgPT4ge1xyXG4gICAgICAgICAgICAgICAgd3gucmVMYXVuY2goe1xyXG4gICAgICAgICAgICAgICAgICB1cmxcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9KS5jYXRjaChlcnIgPT4ge1xyXG4gICAgICAgICAgICAgIHd4LnJlTGF1bmNoKHtcclxuICAgICAgICAgICAgICAgIHVybDogYC9wYWdlcy9teS9vcmRlcj9pZD1gICsgcmVzLmRhdGEub3JkZXJJZFxyXG4gICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pLmNhdGNoKGVyciA9PiB7XHJcbiAgICAgICAgICB0aGlzLmNhbnBheSA9IHRydWVcclxuICAgICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgICB9KVxyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gIH1cclxuIl19