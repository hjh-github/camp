"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

var _WxUtils = require('./../../utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
  _inherits(Dialog, _wepy$page);

  function Dialog() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, Dialog);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
      navigationBarTitleText: "确认订单"
    }, _this.data = {
      orderInfo: {},
      payParams: {},
      childs: [],
      mobile: ''
    }, _this.computed = {
      orderPrice: function orderPrice() {
        if (JSON.stringify(this.payParams) == '{}' || JSON.stringify(this.orderInfo) == '{}') {
          return '0.00';
        }
        return this.payParams.paymentType == 1 ? (this.payParams.price * this.payParams.courseNum).toFixed(2) : (this.orderInfo.earnesMoney * this.payParams.courseNum).toFixed(2);
      }
    }, _this.methods = {
      bindgetphonenumber: function () {
        var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(e) {
          var mobile;
          return regeneratorRuntime.wrap(function _callee$(_context) {
            while (1) {
              switch (_context.prev = _context.next) {
                case 0:
                  if (!(e.detail.errMsg == "getPhoneNumber:ok")) {
                    _context.next = 6;
                    break;
                  }

                  _context.next = 3;
                  return _auth2.default.getPhone(e.detail);

                case 3:
                  mobile = _context.sent;

                  if (mobile) {
                    _wepy2.default.setStorageSync('mobile', mobile);
                    this.mobile = mobile;
                  }
                  this.$apply();

                case 6:
                case "end":
                  return _context.stop();
              }
            }
          }, _callee, this);
        }));

        function bindgetphonenumber(_x) {
          return _ref2.apply(this, arguments);
        }

        return bindgetphonenumber;
      }(),
      textareaBInput: function textareaBInput(e) {
        this.payParams.remark = e.detail.value;
      },
      paymentType: function paymentType(type) {
        this.payParams.paymentType = type;
      },
      plus: function plus() {
        wx.vibrateShort();
        this.payParams.courseNum = this.payParams.courseNum + 1;
        this.childs = [];
      },
      minus: function minus() {
        if (this.payParams.courseNum > 1) {
          wx.vibrateShort();
          this.payParams.courseNum = this.payParams.courseNum - 1;
          this.childs = [];
        }
      },
      getChilds: function () {
        var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(e) {
          return regeneratorRuntime.wrap(function _callee2$(_context2) {
            while (1) {
              switch (_context2.prev = _context2.next) {
                case 0:
                  if (this.mobile) {
                    _context2.next = 2;
                    break;
                  }

                  return _context2.abrupt("return", false);

                case 2:
                  if (!(e.detail.errMsg == "getUserInfo:ok")) {
                    _context2.next = 6;
                    break;
                  }

                  _context2.next = 5;
                  return _auth2.default.getUserinfo(e.detail);

                case 5:
                  _wepy2.default.navigateTo({
                    url: '/pages/meet/childs?type=1&len=' + this.payParams.courseNum
                  });

                case 6:
                case "end":
                  return _context2.stop();
              }
            }
          }, _callee2, this);
        }));

        function getChilds(_x2) {
          return _ref3.apply(this, arguments);
        }

        return getChilds;
      }(),
      pay: function () {
        var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
          var ids, res, _code;

          return regeneratorRuntime.wrap(function _callee3$(_context3) {
            while (1) {
              switch (_context3.prev = _context3.next) {
                case 0:
                  if (!(!this.childs.length || this.childs.length != this.payParams.courseNum)) {
                    _context3.next = 3;
                    break;
                  }

                  _Tips2.default.toast(!this.childs.length ? "请先选择出行人" : "购买数量与出行人数量不匹配", function (res) {}, 'none');
                  return _context3.abrupt("return", false);

                case 3:
                  ids = this.childs.map(function (e) {
                    return e.id;
                  });

                  this.payParams.childIds = ids.join(',');
                  _context3.next = 7;
                  return _config2.default.ordercommit(this.payParams);

                case 7:
                  res = _context3.sent;

                  if (!(res.errcode == 200)) {
                    _context3.next = 13;
                    break;
                  }

                  _context3.next = 11;
                  return _config2.default.wxpaytopay({
                    orderPaySn: res.data.paySn,
                    describe: '描述',
                    money: parseInt(res.data.payAmount * 100)
                  });

                case 11:
                  _code = _context3.sent;

                  _WxUtils2.default.wxPay(_code.data).then(function (r) {
                    _Tips2.default.toast("支付成功", function (r) {
                      _WxUtils2.default.backOrRedirect("/pages/my/order?id=" + res.data.orderId);
                    });
                  }).catch(function (err) {
                    _WxUtils2.default.backOrRedirect("/pages/my/order?id=" + res.data.orderId);
                  });

                case 13:
                case "end":
                  return _context3.stop();
              }
            }
          }, _callee3, this);
        }));

        function pay() {
          return _ref4.apply(this, arguments);
        }

        return pay;
      }()
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(Dialog, [{
    key: "onLoad",
    value: function () {
      var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4(opt) {
        return regeneratorRuntime.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                console.log(opt);
                this.mobile = _wepy2.default.getStorageSync('mobile');
                // this.payParams = wepy.$instance.globalData.orderInfo
                // this.orderInfo = wepy.$instance.globalData.courseInfo
                _context4.next = 4;
                return this.getorderInfo(opt);

              case 4:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, this);
      }));

      function onLoad(_x3) {
        return _ref5.apply(this, arguments);
      }

      return onLoad;
    }()
  }, {
    key: "onShow",
    value: function onShow() {
      this.childs = _wepy2.default.$instance.globalData.childs;
    }
  }, {
    key: "onUnload",
    value: function onUnload() {
      this.childs = _wepy2.default.$instance.globalData.childs = [];
    }
    // 根据课程详情参数，生成支付订单信息

  }, {
    key: "getorderInfo",
    value: function () {
      var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5(opt) {
        var params, _ref7, errcode, data, _data;

        return regeneratorRuntime.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                /*
                  params ={
                    orderType: ${opt.type}, // 订单类型
                    courseId: ${opt.cid}, // 课程id
                    periodId: ${opt.pid}, // 营期id
                    num: ${opt.num}, // 数量
                    actId: ${opt.aId}, // 活动id
                  }
                */
                params = {
                  orderType: opt.type,
                  courseId: opt.cid,
                  periodId: opt.pid,
                  num: opt.num,
                  actId: opt.aid
                };
                _context5.next = 3;
                return _config2.default.orderInfo(params);

              case 3:
                _ref7 = _context5.sent;
                errcode = _ref7.errcode;
                data = _ref7.data;

                if (errcode == 200) {
                  this.orderInfo = data.course;
                  _data = data;

                  this.payParams = {
                    childIds: '',
                    courseId: _data.courseId,
                    courseNum: _data.num,
                    periodId: _data.periodId,
                    remark: '',
                    paymentType: 1,
                    orderType: _data.orderType,
                    periodName: _data.period,
                    actId: _data.actId,
                    price: _data.totalPrice,
                    actPintuanId: opt.actpid
                  };
                }
                this.$apply();

              case 8:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5, this);
      }));

      function getorderInfo(_x4) {
        return _ref6.apply(this, arguments);
      }

      return getorderInfo;
    }()
  }]);

  return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/detaile/sureOrder'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN1cmVPcmRlci5qcyJdLCJuYW1lcyI6WyJEaWFsb2ciLCJjb25maWciLCJuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0IiwiZGF0YSIsIm9yZGVySW5mbyIsInBheVBhcmFtcyIsImNoaWxkcyIsIm1vYmlsZSIsImNvbXB1dGVkIiwib3JkZXJQcmljZSIsIkpTT04iLCJzdHJpbmdpZnkiLCJwYXltZW50VHlwZSIsInByaWNlIiwiY291cnNlTnVtIiwidG9GaXhlZCIsImVhcm5lc01vbmV5IiwibWV0aG9kcyIsImJpbmRnZXRwaG9uZW51bWJlciIsImUiLCJkZXRhaWwiLCJlcnJNc2ciLCJhdXRoIiwiZ2V0UGhvbmUiLCJ3ZXB5Iiwic2V0U3RvcmFnZVN5bmMiLCIkYXBwbHkiLCJ0ZXh0YXJlYUJJbnB1dCIsInJlbWFyayIsInZhbHVlIiwidHlwZSIsInBsdXMiLCJ3eCIsInZpYnJhdGVTaG9ydCIsIm1pbnVzIiwiZ2V0Q2hpbGRzIiwiZ2V0VXNlcmluZm8iLCJuYXZpZ2F0ZVRvIiwidXJsIiwicGF5IiwibGVuZ3RoIiwiVGlwcyIsInRvYXN0IiwiaWRzIiwibWFwIiwiaWQiLCJjaGlsZElkcyIsImpvaW4iLCJvcmRlcmNvbW1pdCIsInJlcyIsImVycmNvZGUiLCJ3eHBheXRvcGF5Iiwib3JkZXJQYXlTbiIsInBheVNuIiwiZGVzY3JpYmUiLCJtb25leSIsInBhcnNlSW50IiwicGF5QW1vdW50IiwiX2NvZGUiLCJXeFV0aWxzIiwid3hQYXkiLCJ0aGVuIiwiYmFja09yUmVkaXJlY3QiLCJvcmRlcklkIiwiY2F0Y2giLCJvcHQiLCJjb25zb2xlIiwibG9nIiwiZ2V0U3RvcmFnZVN5bmMiLCJnZXRvcmRlckluZm8iLCIkaW5zdGFuY2UiLCJnbG9iYWxEYXRhIiwicGFyYW1zIiwib3JkZXJUeXBlIiwiY291cnNlSWQiLCJjaWQiLCJwZXJpb2RJZCIsInBpZCIsIm51bSIsImFjdElkIiwiYWlkIiwiY291cnNlIiwiX2RhdGEiLCJwZXJpb2ROYW1lIiwicGVyaW9kIiwidG90YWxQcmljZSIsImFjdFBpbnR1YW5JZCIsImFjdHBpZCIsInBhZ2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUNFOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7Ozs7Ozs7Ozs7O0lBQ3FCQSxNOzs7Ozs7Ozs7Ozs7OztzTEFDbkJDLE0sR0FBUztBQUNQQyw4QkFBd0I7QUFEakIsSyxRQUdUQyxJLEdBQU87QUFDTEMsaUJBQVcsRUFETjtBQUVMQyxpQkFBVyxFQUZOO0FBR0xDLGNBQVEsRUFISDtBQUlMQyxjQUFRO0FBSkgsSyxRQTREUEMsUSxHQUFXO0FBQ1RDLGdCQURTLHdCQUNJO0FBQ1gsWUFBSUMsS0FBS0MsU0FBTCxDQUFlLEtBQUtOLFNBQXBCLEtBQWtDLElBQWxDLElBQTBDSyxLQUFLQyxTQUFMLENBQWUsS0FBS1AsU0FBcEIsS0FBa0MsSUFBaEYsRUFBc0Y7QUFDcEYsaUJBQU8sTUFBUDtBQUNEO0FBQ0QsZUFBTyxLQUFLQyxTQUFMLENBQWVPLFdBQWYsSUFBOEIsQ0FBOUIsR0FBa0MsQ0FBQyxLQUFLUCxTQUFMLENBQWVRLEtBQWYsR0FBdUIsS0FBS1IsU0FBTCxDQUFlUyxTQUF2QyxFQUFrREMsT0FBbEQsQ0FBMEQsQ0FBMUQsQ0FBbEMsR0FBaUcsQ0FBQyxLQUFLWCxTQUFMLENBQWVZLFdBQWYsR0FBNkIsS0FBS1gsU0FBTCxDQUFlUyxTQUE3QyxFQUF3REMsT0FBeEQsQ0FBZ0UsQ0FBaEUsQ0FBeEc7QUFDRDtBQU5RLEssUUFRWEUsTyxHQUFVO0FBQ0ZDLHdCQURFO0FBQUEsNkZBQ2lCQyxDQURqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFFRkEsRUFBRUMsTUFBRixDQUFTQyxNQUFULElBQW1CLG1CQUZqQjtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBLHlCQUdlQyxlQUFLQyxRQUFMLENBQWNKLEVBQUVDLE1BQWhCLENBSGY7O0FBQUE7QUFHQWIsd0JBSEE7O0FBSUosc0JBQUlBLE1BQUosRUFBWTtBQUNWaUIsbUNBQUtDLGNBQUwsQ0FBb0IsUUFBcEIsRUFBOEJsQixNQUE5QjtBQUNBLHlCQUFLQSxNQUFMLEdBQWNBLE1BQWQ7QUFDRDtBQUNELHVCQUFLbUIsTUFBTDs7QUFSSTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQVdSQyxvQkFYUSwwQkFXT1IsQ0FYUCxFQVdVO0FBQ2hCLGFBQUtkLFNBQUwsQ0FBZXVCLE1BQWYsR0FBd0JULEVBQUVDLE1BQUYsQ0FBU1MsS0FBakM7QUFDRCxPQWJPO0FBY1JqQixpQkFkUSx1QkFjSWtCLElBZEosRUFjVTtBQUNoQixhQUFLekIsU0FBTCxDQUFlTyxXQUFmLEdBQTZCa0IsSUFBN0I7QUFDRCxPQWhCTztBQWlCUkMsVUFqQlEsa0JBaUJEO0FBQ0xDLFdBQUdDLFlBQUg7QUFDQSxhQUFLNUIsU0FBTCxDQUFlUyxTQUFmLEdBQTJCLEtBQUtULFNBQUwsQ0FBZVMsU0FBZixHQUEyQixDQUF0RDtBQUNBLGFBQUtSLE1BQUwsR0FBYyxFQUFkO0FBQ0QsT0FyQk87QUFzQlI0QixXQXRCUSxtQkFzQkE7QUFDTixZQUFJLEtBQUs3QixTQUFMLENBQWVTLFNBQWYsR0FBMkIsQ0FBL0IsRUFBa0M7QUFDaENrQixhQUFHQyxZQUFIO0FBQ0EsZUFBSzVCLFNBQUwsQ0FBZVMsU0FBZixHQUEyQixLQUFLVCxTQUFMLENBQWVTLFNBQWYsR0FBMkIsQ0FBdEQ7QUFDQSxlQUFLUixNQUFMLEdBQWMsRUFBZDtBQUNEO0FBQ0YsT0E1Qk87QUE2Qkg2QixlQTdCRztBQUFBLDhGQTZCT2hCLENBN0JQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkE4QkQsS0FBS1osTUE5Qko7QUFBQTtBQUFBO0FBQUE7O0FBQUEsb0RBK0JHLEtBL0JIOztBQUFBO0FBQUEsd0JBaUNGWSxFQUFFQyxNQUFGLENBQVNDLE1BQVQsSUFBbUIsZ0JBakNqQjtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBLHlCQWtDRUMsZUFBS2MsV0FBTCxDQUFpQmpCLEVBQUVDLE1BQW5CLENBbENGOztBQUFBO0FBbUNKSSxpQ0FBS2EsVUFBTCxDQUFnQjtBQUNkQyx5QkFBSyxtQ0FBbUMsS0FBS2pDLFNBQUwsQ0FBZVM7QUFEekMsbUJBQWhCOztBQW5DSTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQXdDRnlCLFNBeENFO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQXlDRixDQUFDLEtBQUtqQyxNQUFMLENBQVlrQyxNQUFiLElBQXVCLEtBQUtsQyxNQUFMLENBQVlrQyxNQUFaLElBQXNCLEtBQUtuQyxTQUFMLENBQWVTLFNBekMxRDtBQUFBO0FBQUE7QUFBQTs7QUEwQ0oyQixpQ0FBS0MsS0FBTCxDQUFXLENBQUMsS0FBS3BDLE1BQUwsQ0FBWWtDLE1BQWIsR0FBc0IsU0FBdEIsR0FBa0MsZUFBN0MsRUFBOEQsZUFBTyxDQUFFLENBQXZFLEVBQXlFLE1BQXpFO0FBMUNJLG9EQTJDRyxLQTNDSDs7QUFBQTtBQTZDRkcscUJBN0NFLEdBNkNJLEtBQUtyQyxNQUFMLENBQVlzQyxHQUFaLENBQWdCLGFBQUs7QUFDN0IsMkJBQU96QixFQUFFMEIsRUFBVDtBQUNELG1CQUZTLENBN0NKOztBQWdETix1QkFBS3hDLFNBQUwsQ0FBZXlDLFFBQWYsR0FBMEJILElBQUlJLElBQUosQ0FBUyxHQUFULENBQTFCO0FBaERNO0FBQUEseUJBaURVOUMsaUJBQU8rQyxXQUFQLENBQW1CLEtBQUszQyxTQUF4QixDQWpEVjs7QUFBQTtBQWlERjRDLHFCQWpERTs7QUFBQSx3QkFrREZBLElBQUlDLE9BQUosSUFBZSxHQWxEYjtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBLHlCQW1EY2pELGlCQUFPa0QsVUFBUCxDQUFrQjtBQUNsQ0MsZ0NBQVlILElBQUk5QyxJQUFKLENBQVNrRCxLQURhO0FBRWxDQyw4QkFBVSxJQUZ3QjtBQUdsQ0MsMkJBQU9DLFNBQVNQLElBQUk5QyxJQUFKLENBQVNzRCxTQUFULEdBQXFCLEdBQTlCO0FBSDJCLG1CQUFsQixDQW5EZDs7QUFBQTtBQW1EQUMsdUJBbkRBOztBQXdESkMsb0NBQVFDLEtBQVIsQ0FBY0YsTUFBTXZELElBQXBCLEVBQTBCMEQsSUFBMUIsQ0FBK0IsYUFBSztBQUNsQ3BCLG1DQUFLQyxLQUFMLENBQVcsTUFBWCxFQUFtQixhQUFLO0FBQ3RCaUIsd0NBQVFHLGNBQVIsQ0FDRSx3QkFBd0JiLElBQUk5QyxJQUFKLENBQVM0RCxPQURuQztBQUdELHFCQUpEO0FBS0QsbUJBTkQsRUFNR0MsS0FOSCxDQU1TLGVBQU87QUFDZEwsc0NBQVFHLGNBQVIsQ0FDRSx3QkFBd0JiLElBQUk5QyxJQUFKLENBQVM0RCxPQURuQztBQUdELG1CQVZEOztBQXhESTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBLEs7Ozs7Ozs0RkE5REdFLEc7Ozs7O0FBQ1hDLHdCQUFRQyxHQUFSLENBQVlGLEdBQVo7QUFDQSxxQkFBSzFELE1BQUwsR0FBY2lCLGVBQUs0QyxjQUFMLENBQW9CLFFBQXBCLENBQWQ7QUFDQTtBQUNBOzt1QkFDTSxLQUFLQyxZQUFMLENBQWtCSixHQUFsQixDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7NkJBRUM7QUFDUCxXQUFLM0QsTUFBTCxHQUFja0IsZUFBSzhDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQmpFLE1BQXhDO0FBQ0Q7OzsrQkFDVTtBQUNULFdBQUtBLE1BQUwsR0FBY2tCLGVBQUs4QyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJqRSxNQUExQixHQUFtQyxFQUFqRDtBQUNEO0FBQ0Q7Ozs7OzRGQUNtQjJELEc7Ozs7Ozs7QUFDakI7Ozs7Ozs7OztBQVNJTyxzQixHQUFTO0FBQ1hDLDZCQUFXUixJQUFJbkMsSUFESjtBQUVYNEMsNEJBQVVULElBQUlVLEdBRkg7QUFHWEMsNEJBQVVYLElBQUlZLEdBSEg7QUFJWEMsdUJBQUtiLElBQUlhLEdBSkU7QUFLWEMseUJBQU9kLElBQUllO0FBTEEsaUI7O3VCQVVIL0UsaUJBQU9HLFNBQVAsQ0FBaUJvRSxNQUFqQixDOzs7O0FBRlJ0Qix1QixTQUFBQSxPO0FBQ0EvQyxvQixTQUFBQSxJOztBQUVGLG9CQUFJK0MsV0FBVyxHQUFmLEVBQW9CO0FBQ2xCLHVCQUFLOUMsU0FBTCxHQUFpQkQsS0FBSzhFLE1BQXRCO0FBQ0lDLHVCQUZjLEdBRU4vRSxJQUZNOztBQUdsQix1QkFBS0UsU0FBTCxHQUFpQjtBQUNmeUMsOEJBQVUsRUFESztBQUVmNEIsOEJBQVVRLE1BQU1SLFFBRkQ7QUFHZjVELCtCQUFXb0UsTUFBTUosR0FIRjtBQUlmRiw4QkFBVU0sTUFBTU4sUUFKRDtBQUtmaEQsNEJBQVEsRUFMTztBQU1maEIsaUNBQWEsQ0FORTtBQU9mNkQsK0JBQVdTLE1BQU1ULFNBUEY7QUFRZlUsZ0NBQVlELE1BQU1FLE1BUkg7QUFTZkwsMkJBQU9HLE1BQU1ILEtBVEU7QUFVZmxFLDJCQUFPcUUsTUFBTUcsVUFWRTtBQVdmQyxrQ0FBY3JCLElBQUlzQjtBQVhILG1CQUFqQjtBQWFEO0FBQ0QscUJBQUs3RCxNQUFMOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBOURnQ0YsZUFBS2dFLEk7O2tCQUFwQnhGLE0iLCJmaWxlIjoic3VyZU9yZGVyLmpzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbiAgaW1wb3J0IHdlcHkgZnJvbSBcIndlcHlcIjtcclxuICBpbXBvcnQgY29uZmlnIGZyb20gXCJAL2FwaS9jb25maWdcIlxyXG4gIGltcG9ydCBUaXBzIGZyb20gXCJAL3V0aWxzL1RpcHNcIlxyXG4gIGltcG9ydCBXeFV0aWxzIGZyb20gXCJAL3V0aWxzL1d4VXRpbHNcIlxyXG4gIGltcG9ydCBhdXRoIGZyb20gXCJAL2FwaS9hdXRoXCJcclxuICBleHBvcnQgZGVmYXVsdCBjbGFzcyBEaWFsb2cgZXh0ZW5kcyB3ZXB5LnBhZ2Uge1xyXG4gICAgY29uZmlnID0ge1xyXG4gICAgICBuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0OiBcIuehruiupOiuouWNlVwiXHJcbiAgICB9O1xyXG4gICAgZGF0YSA9IHtcclxuICAgICAgb3JkZXJJbmZvOiB7fSxcclxuICAgICAgcGF5UGFyYW1zOiB7fSxcclxuICAgICAgY2hpbGRzOiBbXSxcclxuICAgICAgbW9iaWxlOiAnJ1xyXG4gICAgfTtcclxuICAgIGFzeW5jIG9uTG9hZChvcHQpIHtcclxuICAgICAgY29uc29sZS5sb2cob3B0KVxyXG4gICAgICB0aGlzLm1vYmlsZSA9IHdlcHkuZ2V0U3RvcmFnZVN5bmMoJ21vYmlsZScpO1xyXG4gICAgICAvLyB0aGlzLnBheVBhcmFtcyA9IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEub3JkZXJJbmZvXHJcbiAgICAgIC8vIHRoaXMub3JkZXJJbmZvID0gd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5jb3Vyc2VJbmZvXHJcbiAgICAgIGF3YWl0IHRoaXMuZ2V0b3JkZXJJbmZvKG9wdClcclxuICAgIH1cclxuICAgIG9uU2hvdygpIHtcclxuICAgICAgdGhpcy5jaGlsZHMgPSB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLmNoaWxkc1xyXG4gICAgfVxyXG4gICAgb25VbmxvYWQoKSB7XHJcbiAgICAgIHRoaXMuY2hpbGRzID0gd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5jaGlsZHMgPSBbXVxyXG4gICAgfVxyXG4gICAgLy8g5qC55o2u6K++56iL6K+m5oOF5Y+C5pWw77yM55Sf5oiQ5pSv5LuY6K6i5Y2V5L+h5oGvXHJcbiAgICBhc3luYyBnZXRvcmRlckluZm8ob3B0KSB7XHJcbiAgICAgIC8qXHJcbiAgICAgICAgcGFyYW1zID17XHJcbiAgICAgICAgICBvcmRlclR5cGU6ICR7b3B0LnR5cGV9LCAvLyDorqLljZXnsbvlnotcclxuICAgICAgICAgIGNvdXJzZUlkOiAke29wdC5jaWR9LCAvLyDor77nqItpZFxyXG4gICAgICAgICAgcGVyaW9kSWQ6ICR7b3B0LnBpZH0sIC8vIOiQpeacn2lkXHJcbiAgICAgICAgICBudW06ICR7b3B0Lm51bX0sIC8vIOaVsOmHj1xyXG4gICAgICAgICAgYWN0SWQ6ICR7b3B0LmFJZH0sIC8vIOa0u+WKqGlkXHJcbiAgICAgICAgfVxyXG4gICAgICAqL1xyXG4gICAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICAgIG9yZGVyVHlwZTogb3B0LnR5cGUsXHJcbiAgICAgICAgY291cnNlSWQ6IG9wdC5jaWQsXHJcbiAgICAgICAgcGVyaW9kSWQ6IG9wdC5waWQsXHJcbiAgICAgICAgbnVtOiBvcHQubnVtLFxyXG4gICAgICAgIGFjdElkOiBvcHQuYWlkXHJcbiAgICAgIH1cclxuICAgICAgbGV0IHtcclxuICAgICAgICBlcnJjb2RlLFxyXG4gICAgICAgIGRhdGFcclxuICAgICAgfSA9IGF3YWl0IGNvbmZpZy5vcmRlckluZm8ocGFyYW1zKVxyXG4gICAgICBpZiAoZXJyY29kZSA9PSAyMDApIHtcclxuICAgICAgICB0aGlzLm9yZGVySW5mbyA9IGRhdGEuY291cnNlXHJcbiAgICAgICAgbGV0IF9kYXRhID0gZGF0YVxyXG4gICAgICAgIHRoaXMucGF5UGFyYW1zID0ge1xyXG4gICAgICAgICAgY2hpbGRJZHM6ICcnLFxyXG4gICAgICAgICAgY291cnNlSWQ6IF9kYXRhLmNvdXJzZUlkLFxyXG4gICAgICAgICAgY291cnNlTnVtOiBfZGF0YS5udW0sXHJcbiAgICAgICAgICBwZXJpb2RJZDogX2RhdGEucGVyaW9kSWQsXHJcbiAgICAgICAgICByZW1hcms6ICcnLFxyXG4gICAgICAgICAgcGF5bWVudFR5cGU6IDEsXHJcbiAgICAgICAgICBvcmRlclR5cGU6IF9kYXRhLm9yZGVyVHlwZSxcclxuICAgICAgICAgIHBlcmlvZE5hbWU6IF9kYXRhLnBlcmlvZCxcclxuICAgICAgICAgIGFjdElkOiBfZGF0YS5hY3RJZCxcclxuICAgICAgICAgIHByaWNlOiBfZGF0YS50b3RhbFByaWNlLFxyXG4gICAgICAgICAgYWN0UGludHVhbklkOiBvcHQuYWN0cGlkLFxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICB9XHJcbiAgICBjb21wdXRlZCA9IHtcclxuICAgICAgb3JkZXJQcmljZSgpIHtcclxuICAgICAgICBpZiAoSlNPTi5zdHJpbmdpZnkodGhpcy5wYXlQYXJhbXMpID09ICd7fScgfHwgSlNPTi5zdHJpbmdpZnkodGhpcy5vcmRlckluZm8pID09ICd7fScpIHtcclxuICAgICAgICAgIHJldHVybiAnMC4wMCdcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHRoaXMucGF5UGFyYW1zLnBheW1lbnRUeXBlID09IDEgPyAodGhpcy5wYXlQYXJhbXMucHJpY2UgKiB0aGlzLnBheVBhcmFtcy5jb3Vyc2VOdW0pLnRvRml4ZWQoMikgOiAodGhpcy5vcmRlckluZm8uZWFybmVzTW9uZXkgKiB0aGlzLnBheVBhcmFtcy5jb3Vyc2VOdW0pLnRvRml4ZWQoMilcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgbWV0aG9kcyA9IHtcclxuICAgICAgYXN5bmMgYmluZGdldHBob25lbnVtYmVyKGUpIHtcclxuICAgICAgICBpZiAoZS5kZXRhaWwuZXJyTXNnID09IFwiZ2V0UGhvbmVOdW1iZXI6b2tcIikge1xyXG4gICAgICAgICAgbGV0IG1vYmlsZSA9IGF3YWl0IGF1dGguZ2V0UGhvbmUoZS5kZXRhaWwpXHJcbiAgICAgICAgICBpZiAobW9iaWxlKSB7XHJcbiAgICAgICAgICAgIHdlcHkuc2V0U3RvcmFnZVN5bmMoJ21vYmlsZScsIG1vYmlsZSk7XHJcbiAgICAgICAgICAgIHRoaXMubW9iaWxlID0gbW9iaWxlXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG4gICAgICB0ZXh0YXJlYUJJbnB1dChlKSB7XHJcbiAgICAgICAgdGhpcy5wYXlQYXJhbXMucmVtYXJrID0gZS5kZXRhaWwudmFsdWVcclxuICAgICAgfSxcclxuICAgICAgcGF5bWVudFR5cGUodHlwZSkge1xyXG4gICAgICAgIHRoaXMucGF5UGFyYW1zLnBheW1lbnRUeXBlID0gdHlwZVxyXG4gICAgICB9LFxyXG4gICAgICBwbHVzKCkge1xyXG4gICAgICAgIHd4LnZpYnJhdGVTaG9ydCgpXHJcbiAgICAgICAgdGhpcy5wYXlQYXJhbXMuY291cnNlTnVtID0gdGhpcy5wYXlQYXJhbXMuY291cnNlTnVtICsgMVxyXG4gICAgICAgIHRoaXMuY2hpbGRzID0gW11cclxuICAgICAgfSxcclxuICAgICAgbWludXMoKSB7XHJcbiAgICAgICAgaWYgKHRoaXMucGF5UGFyYW1zLmNvdXJzZU51bSA+IDEpIHtcclxuICAgICAgICAgIHd4LnZpYnJhdGVTaG9ydCgpXHJcbiAgICAgICAgICB0aGlzLnBheVBhcmFtcy5jb3Vyc2VOdW0gPSB0aGlzLnBheVBhcmFtcy5jb3Vyc2VOdW0gLSAxXHJcbiAgICAgICAgICB0aGlzLmNoaWxkcyA9IFtdXHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG4gICAgIGFzeW5jIGdldENoaWxkcyhlKSB7XHJcbiAgICAgICAgaWYgKCF0aGlzLm1vYmlsZSkge1xyXG4gICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChlLmRldGFpbC5lcnJNc2cgPT0gXCJnZXRVc2VySW5mbzpva1wiKSB7XHJcbiAgICAgICAgICBhd2FpdCBhdXRoLmdldFVzZXJpbmZvKGUuZGV0YWlsKVxyXG4gICAgICAgICAgd2VweS5uYXZpZ2F0ZVRvKHtcclxuICAgICAgICAgICAgdXJsOiAnL3BhZ2VzL21lZXQvY2hpbGRzP3R5cGU9MSZsZW49JyArIHRoaXMucGF5UGFyYW1zLmNvdXJzZU51bVxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG4gICAgICBhc3luYyBwYXkoKSB7XHJcbiAgICAgICAgaWYgKCF0aGlzLmNoaWxkcy5sZW5ndGggfHwgdGhpcy5jaGlsZHMubGVuZ3RoICE9IHRoaXMucGF5UGFyYW1zLmNvdXJzZU51bSkge1xyXG4gICAgICAgICAgVGlwcy50b2FzdCghdGhpcy5jaGlsZHMubGVuZ3RoID8gXCLor7flhYjpgInmi6nlh7rooYzkurpcIiA6IFwi6LSt5Lmw5pWw6YeP5LiO5Ye66KGM5Lq65pWw6YeP5LiN5Yy56YWNXCIsIHJlcyA9PiB7fSwgJ25vbmUnKTtcclxuICAgICAgICAgIHJldHVybiBmYWxzZVxyXG4gICAgICAgIH1cclxuICAgICAgICBsZXQgaWRzID0gdGhpcy5jaGlsZHMubWFwKGUgPT4ge1xyXG4gICAgICAgICAgcmV0dXJuIGUuaWRcclxuICAgICAgICB9KVxyXG4gICAgICAgIHRoaXMucGF5UGFyYW1zLmNoaWxkSWRzID0gaWRzLmpvaW4oJywnKVxyXG4gICAgICAgIGxldCByZXMgPSBhd2FpdCBjb25maWcub3JkZXJjb21taXQodGhpcy5wYXlQYXJhbXMpXHJcbiAgICAgICAgaWYgKHJlcy5lcnJjb2RlID09IDIwMCkge1xyXG4gICAgICAgICAgbGV0IF9jb2RlID0gYXdhaXQgY29uZmlnLnd4cGF5dG9wYXkoe1xyXG4gICAgICAgICAgICBvcmRlclBheVNuOiByZXMuZGF0YS5wYXlTbixcclxuICAgICAgICAgICAgZGVzY3JpYmU6ICfmj4/ov7AnLFxyXG4gICAgICAgICAgICBtb25leTogcGFyc2VJbnQocmVzLmRhdGEucGF5QW1vdW50ICogMTAwKVxyXG4gICAgICAgICAgfSlcclxuICAgICAgICAgIFd4VXRpbHMud3hQYXkoX2NvZGUuZGF0YSkudGhlbihyID0+IHtcclxuICAgICAgICAgICAgVGlwcy50b2FzdChcIuaUr+S7mOaIkOWKn1wiLCByID0+IHtcclxuICAgICAgICAgICAgICBXeFV0aWxzLmJhY2tPclJlZGlyZWN0KFxyXG4gICAgICAgICAgICAgICAgYC9wYWdlcy9teS9vcmRlcj9pZD1gICsgcmVzLmRhdGEub3JkZXJJZFxyXG4gICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgfSkuY2F0Y2goZXJyID0+IHtcclxuICAgICAgICAgICAgV3hVdGlscy5iYWNrT3JSZWRpcmVjdChcclxuICAgICAgICAgICAgICBgL3BhZ2VzL215L29yZGVyP2lkPWAgKyByZXMuZGF0YS5vcmRlcklkXHJcbiAgICAgICAgICAgICk7XHJcbiAgICAgICAgICB9KVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfTtcclxuICB9XHJcbiJdfQ==