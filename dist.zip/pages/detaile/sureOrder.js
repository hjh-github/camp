"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

var _WxUtils = require('./../../utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
  _inherits(Dialog, _wepy$page);

  function Dialog() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, Dialog);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
      navigationBarTitleText: "确认订单"
    }, _this.data = {
      orderInfo: {},
      payParams: {},
      childs: [],
      mobile: ''
    }, _this.computed = {
      orderPrice: function orderPrice() {
        if (JSON.stringify(this.payParams) == '{}' || JSON.stringify(this.orderInfo) == '{}') {
          return '0.00';
        }
        return this.payParams.paymentType == 1 ? (this.payParams.price * this.payParams.courseNum).toFixed(2) : (this.orderInfo.earnesMoney * this.payParams.courseNum).toFixed(2);
      }
    }, _this.methods = {
      bindgetphonenumber: function () {
        var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(e) {
          var mobile;
          return regeneratorRuntime.wrap(function _callee$(_context) {
            while (1) {
              switch (_context.prev = _context.next) {
                case 0:
                  if (!(e.detail.errMsg == "getPhoneNumber:ok")) {
                    _context.next = 6;
                    break;
                  }

                  _context.next = 3;
                  return _auth2.default.getPhone(e.detail);

                case 3:
                  mobile = _context.sent;

                  if (mobile) {
                    _wepy2.default.setStorageSync('mobile', mobile);
                    this.mobile = mobile;
                  }
                  this.$apply();

                case 6:
                case "end":
                  return _context.stop();
              }
            }
          }, _callee, this);
        }));

        function bindgetphonenumber(_x) {
          return _ref2.apply(this, arguments);
        }

        return bindgetphonenumber;
      }(),
      textareaBInput: function textareaBInput(e) {
        this.payParams.remark = e.detail.value;
      },
      paymentType: function paymentType(type) {
        this.payParams.paymentType = type;
      },
      plus: function plus() {
        wx.vibrateShort();
        this.payParams.courseNum = this.payParams.courseNum + 1;
        this.childs = [];
      },
      minus: function minus() {
        if (this.payParams.courseNum > 1) {
          wx.vibrateShort();
          this.payParams.courseNum = this.payParams.courseNum - 1;
          this.childs = [];
        }
      },
      getChilds: function getChilds() {
        if (!this.mobile) {
          return false;
        }
        _wepy2.default.navigateTo({
          url: '/pages/meet/childs?type=1&len=' + this.payParams.courseNum
        });
      },
      pay: function () {
        var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
          var ids, res, _code;

          return regeneratorRuntime.wrap(function _callee2$(_context2) {
            while (1) {
              switch (_context2.prev = _context2.next) {
                case 0:
                  if (!(!this.childs.length || this.childs.length != this.payParams.courseNum)) {
                    _context2.next = 3;
                    break;
                  }

                  _Tips2.default.toast(!this.childs.length ? "请先选择出行人" : "购买数量与出行人数量不匹配", function (res) {}, 'none');
                  return _context2.abrupt("return", false);

                case 3:
                  ids = this.childs.map(function (e) {
                    return e.id;
                  });

                  this.payParams.childIds = ids.join(',');
                  _context2.next = 7;
                  return _config2.default.ordercommit(this.payParams);

                case 7:
                  res = _context2.sent;

                  if (!(res.errcode == 200)) {
                    _context2.next = 14;
                    break;
                  }

                  _context2.next = 11;
                  return _config2.default.wxpaytopay({
                    orderPaySn: res.data.paySn,
                    describe: '描述',
                    money: parseInt(this.orderPrice * 100)
                  });

                case 11:
                  _code = _context2.sent;

                  console.log(res);
                  _WxUtils2.default.wxPay(_code.data).then(function (r) {
                    _Tips2.default.toast("支付成功", function (r) {
                      _WxUtils2.default.backOrRedirect("/pages/my/order?id=" + res.data.orderId);
                    });
                  }).catch(function (err) {
                    _WxUtils2.default.backOrRedirect("/pages/my/order?id=" + res.data.orderId);
                  });

                case 14:
                case "end":
                  return _context2.stop();
              }
            }
          }, _callee2, this);
        }));

        function pay() {
          return _ref3.apply(this, arguments);
        }

        return pay;
      }()
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(Dialog, [{
    key: "onLoad",
    value: function () {
      var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(opt) {
        return regeneratorRuntime.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                console.log(opt);
                this.mobile = _wepy2.default.getStorageSync('mobile');
                // this.payParams = wepy.$instance.globalData.orderInfo
                // this.orderInfo = wepy.$instance.globalData.courseInfo
                _context3.next = 4;
                return this.getorderInfo(opt);

              case 4:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this);
      }));

      function onLoad(_x2) {
        return _ref4.apply(this, arguments);
      }

      return onLoad;
    }()
  }, {
    key: "onShow",
    value: function onShow() {
      this.childs = _wepy2.default.$instance.globalData.childs;
    }
  }, {
    key: "onUnload",
    value: function onUnload() {
      this.childs = _wepy2.default.$instance.globalData.childs = [];
    }
    // 根据课程详情参数，生成支付订单信息

  }, {
    key: "getorderInfo",
    value: function () {
      var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4(opt) {
        var params, _ref6, errcode, data, _data;

        return regeneratorRuntime.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                /*
                  params ={
                    orderType: ${opt.type}, // 订单类型
                    courseId: ${opt.cid}, // 课程id
                    periodId: ${opt.pid}, // 营期id
                    num: ${opt.num}, // 数量
                    actId: ${opt.aId}, // 活动id
                  }
                */
                params = {
                  orderType: opt.type,
                  courseId: opt.cid,
                  periodId: opt.pid,
                  num: opt.num,
                  actId: opt.aid
                };
                _context4.next = 3;
                return _config2.default.orderInfo(params);

              case 3:
                _ref6 = _context4.sent;
                errcode = _ref6.errcode;
                data = _ref6.data;

                if (errcode == 200) {
                  this.orderInfo = data.course;
                  _data = data;

                  this.payParams = {
                    childIds: '',
                    courseId: _data.courseId,
                    courseNum: _data.num,
                    periodId: _data.periodId,
                    remark: '',
                    paymentType: 1,
                    orderType: _data.orderType,
                    periodName: _data.period,
                    actId: _data.actId,
                    price: _data.totalPrice,
                    actPintuanId: opt.actpid
                  };
                }
                this.$apply();

              case 8:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, this);
      }));

      function getorderInfo(_x3) {
        return _ref5.apply(this, arguments);
      }

      return getorderInfo;
    }()
  }]);

  return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/detaile/sureOrder'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN1cmVPcmRlci5qcyJdLCJuYW1lcyI6WyJEaWFsb2ciLCJjb25maWciLCJuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0IiwiZGF0YSIsIm9yZGVySW5mbyIsInBheVBhcmFtcyIsImNoaWxkcyIsIm1vYmlsZSIsImNvbXB1dGVkIiwib3JkZXJQcmljZSIsIkpTT04iLCJzdHJpbmdpZnkiLCJwYXltZW50VHlwZSIsInByaWNlIiwiY291cnNlTnVtIiwidG9GaXhlZCIsImVhcm5lc01vbmV5IiwibWV0aG9kcyIsImJpbmRnZXRwaG9uZW51bWJlciIsImUiLCJkZXRhaWwiLCJlcnJNc2ciLCJhdXRoIiwiZ2V0UGhvbmUiLCJ3ZXB5Iiwic2V0U3RvcmFnZVN5bmMiLCIkYXBwbHkiLCJ0ZXh0YXJlYUJJbnB1dCIsInJlbWFyayIsInZhbHVlIiwidHlwZSIsInBsdXMiLCJ3eCIsInZpYnJhdGVTaG9ydCIsIm1pbnVzIiwiZ2V0Q2hpbGRzIiwibmF2aWdhdGVUbyIsInVybCIsInBheSIsImxlbmd0aCIsIlRpcHMiLCJ0b2FzdCIsImlkcyIsIm1hcCIsImlkIiwiY2hpbGRJZHMiLCJqb2luIiwib3JkZXJjb21taXQiLCJyZXMiLCJlcnJjb2RlIiwid3hwYXl0b3BheSIsIm9yZGVyUGF5U24iLCJwYXlTbiIsImRlc2NyaWJlIiwibW9uZXkiLCJwYXJzZUludCIsIl9jb2RlIiwiY29uc29sZSIsImxvZyIsIld4VXRpbHMiLCJ3eFBheSIsInRoZW4iLCJiYWNrT3JSZWRpcmVjdCIsIm9yZGVySWQiLCJjYXRjaCIsIm9wdCIsImdldFN0b3JhZ2VTeW5jIiwiZ2V0b3JkZXJJbmZvIiwiJGluc3RhbmNlIiwiZ2xvYmFsRGF0YSIsInBhcmFtcyIsIm9yZGVyVHlwZSIsImNvdXJzZUlkIiwiY2lkIiwicGVyaW9kSWQiLCJwaWQiLCJudW0iLCJhY3RJZCIsImFpZCIsImNvdXJzZSIsIl9kYXRhIiwicGVyaW9kTmFtZSIsInBlcmlvZCIsInRvdGFsUHJpY2UiLCJhY3RQaW50dWFuSWQiLCJhY3RwaWQiLCJwYWdlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFDRTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7Ozs7Ozs7Ozs7OztJQUNxQkEsTTs7Ozs7Ozs7Ozs7Ozs7c0xBQ25CQyxNLEdBQVM7QUFDUEMsOEJBQXdCO0FBRGpCLEssUUFHVEMsSSxHQUFPO0FBQ0xDLGlCQUFXLEVBRE47QUFFTEMsaUJBQVcsRUFGTjtBQUdMQyxjQUFRLEVBSEg7QUFJTEMsY0FBUTtBQUpILEssUUE0RFBDLFEsR0FBVztBQUNUQyxnQkFEUyx3QkFDSTtBQUNYLFlBQUlDLEtBQUtDLFNBQUwsQ0FBZSxLQUFLTixTQUFwQixLQUFrQyxJQUFsQyxJQUEwQ0ssS0FBS0MsU0FBTCxDQUFlLEtBQUtQLFNBQXBCLEtBQWtDLElBQWhGLEVBQXNGO0FBQ3BGLGlCQUFPLE1BQVA7QUFDRDtBQUNELGVBQU8sS0FBS0MsU0FBTCxDQUFlTyxXQUFmLElBQThCLENBQTlCLEdBQWtDLENBQUMsS0FBS1AsU0FBTCxDQUFlUSxLQUFmLEdBQXVCLEtBQUtSLFNBQUwsQ0FBZVMsU0FBdkMsRUFBa0RDLE9BQWxELENBQTBELENBQTFELENBQWxDLEdBQWlHLENBQUMsS0FBS1gsU0FBTCxDQUFlWSxXQUFmLEdBQTZCLEtBQUtYLFNBQUwsQ0FBZVMsU0FBN0MsRUFBd0RDLE9BQXhELENBQWdFLENBQWhFLENBQXhHO0FBQ0Q7QUFOUSxLLFFBUVhFLE8sR0FBVTtBQUNGQyx3QkFERTtBQUFBLDZGQUNpQkMsQ0FEakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBRUZBLEVBQUVDLE1BQUYsQ0FBU0MsTUFBVCxJQUFtQixtQkFGakI7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQSx5QkFHZUMsZUFBS0MsUUFBTCxDQUFjSixFQUFFQyxNQUFoQixDQUhmOztBQUFBO0FBR0FiLHdCQUhBOztBQUlKLHNCQUFJQSxNQUFKLEVBQVk7QUFDVmlCLG1DQUFLQyxjQUFMLENBQW9CLFFBQXBCLEVBQThCbEIsTUFBOUI7QUFDQSx5QkFBS0EsTUFBTCxHQUFjQSxNQUFkO0FBQ0Q7QUFDRCx1QkFBS21CLE1BQUw7O0FBUkk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFXUkMsb0JBWFEsMEJBV09SLENBWFAsRUFXVTtBQUNoQixhQUFLZCxTQUFMLENBQWV1QixNQUFmLEdBQXdCVCxFQUFFQyxNQUFGLENBQVNTLEtBQWpDO0FBQ0QsT0FiTztBQWNSakIsaUJBZFEsdUJBY0lrQixJQWRKLEVBY1U7QUFDaEIsYUFBS3pCLFNBQUwsQ0FBZU8sV0FBZixHQUE2QmtCLElBQTdCO0FBQ0QsT0FoQk87QUFpQlJDLFVBakJRLGtCQWlCRDtBQUNMQyxXQUFHQyxZQUFIO0FBQ0EsYUFBSzVCLFNBQUwsQ0FBZVMsU0FBZixHQUEyQixLQUFLVCxTQUFMLENBQWVTLFNBQWYsR0FBMkIsQ0FBdEQ7QUFDQSxhQUFLUixNQUFMLEdBQWMsRUFBZDtBQUNELE9BckJPO0FBc0JSNEIsV0F0QlEsbUJBc0JBO0FBQ04sWUFBSSxLQUFLN0IsU0FBTCxDQUFlUyxTQUFmLEdBQTJCLENBQS9CLEVBQWtDO0FBQ2hDa0IsYUFBR0MsWUFBSDtBQUNBLGVBQUs1QixTQUFMLENBQWVTLFNBQWYsR0FBMkIsS0FBS1QsU0FBTCxDQUFlUyxTQUFmLEdBQTJCLENBQXREO0FBQ0EsZUFBS1IsTUFBTCxHQUFjLEVBQWQ7QUFDRDtBQUNGLE9BNUJPO0FBNkJSNkIsZUE3QlEsdUJBNkJJO0FBQ1YsWUFBSSxDQUFDLEtBQUs1QixNQUFWLEVBQWtCO0FBQ2hCLGlCQUFPLEtBQVA7QUFDRDtBQUNEaUIsdUJBQUtZLFVBQUwsQ0FBZ0I7QUFDZEMsZUFBSyxtQ0FBbUMsS0FBS2hDLFNBQUwsQ0FBZVM7QUFEekMsU0FBaEI7QUFHRCxPQXBDTztBQXFDRndCLFNBckNFO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQXNDRixDQUFDLEtBQUtoQyxNQUFMLENBQVlpQyxNQUFiLElBQXVCLEtBQUtqQyxNQUFMLENBQVlpQyxNQUFaLElBQXNCLEtBQUtsQyxTQUFMLENBQWVTLFNBdEMxRDtBQUFBO0FBQUE7QUFBQTs7QUF1Q0owQixpQ0FBS0MsS0FBTCxDQUFXLENBQUMsS0FBS25DLE1BQUwsQ0FBWWlDLE1BQWIsR0FBc0IsU0FBdEIsR0FBa0MsZUFBN0MsRUFBOEQsZUFBTyxDQUFFLENBQXZFLEVBQXlFLE1BQXpFO0FBdkNJLG9EQXdDRyxLQXhDSDs7QUFBQTtBQTBDRkcscUJBMUNFLEdBMENJLEtBQUtwQyxNQUFMLENBQVlxQyxHQUFaLENBQWdCLGFBQUs7QUFDN0IsMkJBQU94QixFQUFFeUIsRUFBVDtBQUNELG1CQUZTLENBMUNKOztBQTZDTix1QkFBS3ZDLFNBQUwsQ0FBZXdDLFFBQWYsR0FBMEJILElBQUlJLElBQUosQ0FBUyxHQUFULENBQTFCO0FBN0NNO0FBQUEseUJBOENVN0MsaUJBQU84QyxXQUFQLENBQW1CLEtBQUsxQyxTQUF4QixDQTlDVjs7QUFBQTtBQThDRjJDLHFCQTlDRTs7QUFBQSx3QkErQ0ZBLElBQUlDLE9BQUosSUFBZSxHQS9DYjtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBLHlCQWdEY2hELGlCQUFPaUQsVUFBUCxDQUFrQjtBQUNsQ0MsZ0NBQVlILElBQUk3QyxJQUFKLENBQVNpRCxLQURhO0FBRWxDQyw4QkFBVSxJQUZ3QjtBQUdsQ0MsMkJBQU9DLFNBQVMsS0FBSzlDLFVBQUwsR0FBa0IsR0FBM0I7QUFIMkIsbUJBQWxCLENBaERkOztBQUFBO0FBZ0RBK0MsdUJBaERBOztBQXFESkMsMEJBQVFDLEdBQVIsQ0FBWVYsR0FBWjtBQUNBVyxvQ0FBUUMsS0FBUixDQUFjSixNQUFNckQsSUFBcEIsRUFBMEIwRCxJQUExQixDQUErQixhQUFLO0FBQ2xDckIsbUNBQUtDLEtBQUwsQ0FBVyxNQUFYLEVBQW1CLGFBQUs7QUFDdEJrQix3Q0FBUUcsY0FBUixDQUNFLHdCQUF3QmQsSUFBSTdDLElBQUosQ0FBUzRELE9BRG5DO0FBR0QscUJBSkQ7QUFLRCxtQkFORCxFQU1HQyxLQU5ILENBTVMsZUFBTztBQUNkTCxzQ0FBUUcsY0FBUixDQUNFLHdCQUF3QmQsSUFBSTdDLElBQUosQ0FBUzRELE9BRG5DO0FBR0QsbUJBVkQ7O0FBdERJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUEsSzs7Ozs7OzRGQTlER0UsRzs7Ozs7QUFDWFIsd0JBQVFDLEdBQVIsQ0FBWU8sR0FBWjtBQUNBLHFCQUFLMUQsTUFBTCxHQUFjaUIsZUFBSzBDLGNBQUwsQ0FBb0IsUUFBcEIsQ0FBZDtBQUNBO0FBQ0E7O3VCQUNNLEtBQUtDLFlBQUwsQ0FBa0JGLEdBQWxCLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs2QkFFQztBQUNQLFdBQUszRCxNQUFMLEdBQWNrQixlQUFLNEMsU0FBTCxDQUFlQyxVQUFmLENBQTBCL0QsTUFBeEM7QUFDRDs7OytCQUNVO0FBQ1QsV0FBS0EsTUFBTCxHQUFja0IsZUFBSzRDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQi9ELE1BQTFCLEdBQW1DLEVBQWpEO0FBQ0Q7QUFDRDs7Ozs7NEZBQ21CMkQsRzs7Ozs7OztBQUNqQjs7Ozs7Ozs7O0FBU0lLLHNCLEdBQVM7QUFDWEMsNkJBQVdOLElBQUluQyxJQURKO0FBRVgwQyw0QkFBVVAsSUFBSVEsR0FGSDtBQUdYQyw0QkFBVVQsSUFBSVUsR0FISDtBQUlYQyx1QkFBS1gsSUFBSVcsR0FKRTtBQUtYQyx5QkFBT1osSUFBSWE7QUFMQSxpQjs7dUJBVUg3RSxpQkFBT0csU0FBUCxDQUFpQmtFLE1BQWpCLEM7Ozs7QUFGUnJCLHVCLFNBQUFBLE87QUFDQTlDLG9CLFNBQUFBLEk7O0FBRUYsb0JBQUk4QyxXQUFXLEdBQWYsRUFBb0I7QUFDbEIsdUJBQUs3QyxTQUFMLEdBQWlCRCxLQUFLNEUsTUFBdEI7QUFDSUMsdUJBRmMsR0FFTjdFLElBRk07O0FBR2xCLHVCQUFLRSxTQUFMLEdBQWlCO0FBQ2Z3Qyw4QkFBVSxFQURLO0FBRWYyQiw4QkFBVVEsTUFBTVIsUUFGRDtBQUdmMUQsK0JBQVdrRSxNQUFNSixHQUhGO0FBSWZGLDhCQUFVTSxNQUFNTixRQUpEO0FBS2Y5Qyw0QkFBUSxFQUxPO0FBTWZoQixpQ0FBYSxDQU5FO0FBT2YyRCwrQkFBV1MsTUFBTVQsU0FQRjtBQVFmVSxnQ0FBWUQsTUFBTUUsTUFSSDtBQVNmTCwyQkFBT0csTUFBTUgsS0FURTtBQVVmaEUsMkJBQU9tRSxNQUFNRyxVQVZFO0FBV2ZDLGtDQUFjbkIsSUFBSW9CO0FBWEgsbUJBQWpCO0FBYUQ7QUFDRCxxQkFBSzNELE1BQUw7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUE5RGdDRixlQUFLOEQsSTs7a0JBQXBCdEYsTSIsImZpbGUiOiJzdXJlT3JkZXIuanMiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuICBpbXBvcnQgd2VweSBmcm9tIFwid2VweVwiO1xyXG4gIGltcG9ydCBjb25maWcgZnJvbSBcIkAvYXBpL2NvbmZpZ1wiXHJcbiAgaW1wb3J0IFRpcHMgZnJvbSBcIkAvdXRpbHMvVGlwc1wiXHJcbiAgaW1wb3J0IFd4VXRpbHMgZnJvbSBcIkAvdXRpbHMvV3hVdGlsc1wiXHJcbiAgaW1wb3J0IGF1dGggZnJvbSBcIkAvYXBpL2F1dGhcIlxyXG4gIGV4cG9ydCBkZWZhdWx0IGNsYXNzIERpYWxvZyBleHRlbmRzIHdlcHkucGFnZSB7XHJcbiAgICBjb25maWcgPSB7XHJcbiAgICAgIG5hdmlnYXRpb25CYXJUaXRsZVRleHQ6IFwi56Gu6K6k6K6i5Y2VXCJcclxuICAgIH07XHJcbiAgICBkYXRhID0ge1xyXG4gICAgICBvcmRlckluZm86IHt9LFxyXG4gICAgICBwYXlQYXJhbXM6IHt9LFxyXG4gICAgICBjaGlsZHM6IFtdLFxyXG4gICAgICBtb2JpbGU6ICcnXHJcbiAgICB9O1xyXG4gICAgYXN5bmMgb25Mb2FkKG9wdCkge1xyXG4gICAgICBjb25zb2xlLmxvZyhvcHQpXHJcbiAgICAgIHRoaXMubW9iaWxlID0gd2VweS5nZXRTdG9yYWdlU3luYygnbW9iaWxlJyk7XHJcbiAgICAgIC8vIHRoaXMucGF5UGFyYW1zID0gd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5vcmRlckluZm9cclxuICAgICAgLy8gdGhpcy5vcmRlckluZm8gPSB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLmNvdXJzZUluZm9cclxuICAgICAgYXdhaXQgdGhpcy5nZXRvcmRlckluZm8ob3B0KVxyXG4gICAgfVxyXG4gICAgb25TaG93KCkge1xyXG4gICAgICB0aGlzLmNoaWxkcyA9IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuY2hpbGRzXHJcbiAgICB9XHJcbiAgICBvblVubG9hZCgpIHtcclxuICAgICAgdGhpcy5jaGlsZHMgPSB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLmNoaWxkcyA9IFtdXHJcbiAgICB9XHJcbiAgICAvLyDmoLnmja7or77nqIvor6bmg4Xlj4LmlbDvvIznlJ/miJDmlK/ku5jorqLljZXkv6Hmga9cclxuICAgIGFzeW5jIGdldG9yZGVySW5mbyhvcHQpIHtcclxuICAgICAgLypcclxuICAgICAgICBwYXJhbXMgPXtcclxuICAgICAgICAgIG9yZGVyVHlwZTogJHtvcHQudHlwZX0sIC8vIOiuouWNleexu+Wei1xyXG4gICAgICAgICAgY291cnNlSWQ6ICR7b3B0LmNpZH0sIC8vIOivvueoi2lkXHJcbiAgICAgICAgICBwZXJpb2RJZDogJHtvcHQucGlkfSwgLy8g6JCl5pyfaWRcclxuICAgICAgICAgIG51bTogJHtvcHQubnVtfSwgLy8g5pWw6YePXHJcbiAgICAgICAgICBhY3RJZDogJHtvcHQuYUlkfSwgLy8g5rS75YqoaWRcclxuICAgICAgICB9XHJcbiAgICAgICovXHJcbiAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgb3JkZXJUeXBlOiBvcHQudHlwZSxcclxuICAgICAgICBjb3Vyc2VJZDogb3B0LmNpZCxcclxuICAgICAgICBwZXJpb2RJZDogb3B0LnBpZCxcclxuICAgICAgICBudW06IG9wdC5udW0sXHJcbiAgICAgICAgYWN0SWQ6IG9wdC5haWRcclxuICAgICAgfVxyXG4gICAgICBsZXQge1xyXG4gICAgICAgIGVycmNvZGUsXHJcbiAgICAgICAgZGF0YVxyXG4gICAgICB9ID0gYXdhaXQgY29uZmlnLm9yZGVySW5mbyhwYXJhbXMpXHJcbiAgICAgIGlmIChlcnJjb2RlID09IDIwMCkge1xyXG4gICAgICAgIHRoaXMub3JkZXJJbmZvID0gZGF0YS5jb3Vyc2VcclxuICAgICAgICBsZXQgX2RhdGEgPSBkYXRhXHJcbiAgICAgICAgdGhpcy5wYXlQYXJhbXMgPSB7XHJcbiAgICAgICAgICBjaGlsZElkczogJycsXHJcbiAgICAgICAgICBjb3Vyc2VJZDogX2RhdGEuY291cnNlSWQsXHJcbiAgICAgICAgICBjb3Vyc2VOdW06IF9kYXRhLm51bSxcclxuICAgICAgICAgIHBlcmlvZElkOiBfZGF0YS5wZXJpb2RJZCxcclxuICAgICAgICAgIHJlbWFyazogJycsXHJcbiAgICAgICAgICBwYXltZW50VHlwZTogMSxcclxuICAgICAgICAgIG9yZGVyVHlwZTogX2RhdGEub3JkZXJUeXBlLFxyXG4gICAgICAgICAgcGVyaW9kTmFtZTogX2RhdGEucGVyaW9kLFxyXG4gICAgICAgICAgYWN0SWQ6IF9kYXRhLmFjdElkLFxyXG4gICAgICAgICAgcHJpY2U6IF9kYXRhLnRvdGFsUHJpY2UsXHJcbiAgICAgICAgICBhY3RQaW50dWFuSWQ6IG9wdC5hY3RwaWQsIFxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICB9XHJcbiAgICBjb21wdXRlZCA9IHtcclxuICAgICAgb3JkZXJQcmljZSgpIHtcclxuICAgICAgICBpZiAoSlNPTi5zdHJpbmdpZnkodGhpcy5wYXlQYXJhbXMpID09ICd7fScgfHwgSlNPTi5zdHJpbmdpZnkodGhpcy5vcmRlckluZm8pID09ICd7fScpIHtcclxuICAgICAgICAgIHJldHVybiAnMC4wMCdcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHRoaXMucGF5UGFyYW1zLnBheW1lbnRUeXBlID09IDEgPyAodGhpcy5wYXlQYXJhbXMucHJpY2UgKiB0aGlzLnBheVBhcmFtcy5jb3Vyc2VOdW0pLnRvRml4ZWQoMikgOiAodGhpcy5vcmRlckluZm8uZWFybmVzTW9uZXkgKiB0aGlzLnBheVBhcmFtcy5jb3Vyc2VOdW0pLnRvRml4ZWQoMilcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgbWV0aG9kcyA9IHtcclxuICAgICAgYXN5bmMgYmluZGdldHBob25lbnVtYmVyKGUpIHtcclxuICAgICAgICBpZiAoZS5kZXRhaWwuZXJyTXNnID09IFwiZ2V0UGhvbmVOdW1iZXI6b2tcIikge1xyXG4gICAgICAgICAgbGV0IG1vYmlsZSA9IGF3YWl0IGF1dGguZ2V0UGhvbmUoZS5kZXRhaWwpXHJcbiAgICAgICAgICBpZiAobW9iaWxlKSB7XHJcbiAgICAgICAgICAgIHdlcHkuc2V0U3RvcmFnZVN5bmMoJ21vYmlsZScsIG1vYmlsZSk7XHJcbiAgICAgICAgICAgIHRoaXMubW9iaWxlID0gbW9iaWxlXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG4gICAgICB0ZXh0YXJlYUJJbnB1dChlKSB7XHJcbiAgICAgICAgdGhpcy5wYXlQYXJhbXMucmVtYXJrID0gZS5kZXRhaWwudmFsdWVcclxuICAgICAgfSxcclxuICAgICAgcGF5bWVudFR5cGUodHlwZSkge1xyXG4gICAgICAgIHRoaXMucGF5UGFyYW1zLnBheW1lbnRUeXBlID0gdHlwZVxyXG4gICAgICB9LFxyXG4gICAgICBwbHVzKCkge1xyXG4gICAgICAgIHd4LnZpYnJhdGVTaG9ydCgpXHJcbiAgICAgICAgdGhpcy5wYXlQYXJhbXMuY291cnNlTnVtID0gdGhpcy5wYXlQYXJhbXMuY291cnNlTnVtICsgMVxyXG4gICAgICAgIHRoaXMuY2hpbGRzID0gW11cclxuICAgICAgfSxcclxuICAgICAgbWludXMoKSB7XHJcbiAgICAgICAgaWYgKHRoaXMucGF5UGFyYW1zLmNvdXJzZU51bSA+IDEpIHtcclxuICAgICAgICAgIHd4LnZpYnJhdGVTaG9ydCgpXHJcbiAgICAgICAgICB0aGlzLnBheVBhcmFtcy5jb3Vyc2VOdW0gPSB0aGlzLnBheVBhcmFtcy5jb3Vyc2VOdW0gLSAxXHJcbiAgICAgICAgICB0aGlzLmNoaWxkcyA9IFtdXHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG4gICAgICBnZXRDaGlsZHMoKSB7XHJcbiAgICAgICAgaWYgKCF0aGlzLm1vYmlsZSkge1xyXG4gICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHdlcHkubmF2aWdhdGVUbyh7XHJcbiAgICAgICAgICB1cmw6ICcvcGFnZXMvbWVldC9jaGlsZHM/dHlwZT0xJmxlbj0nICsgdGhpcy5wYXlQYXJhbXMuY291cnNlTnVtXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0sXHJcbiAgICAgIGFzeW5jIHBheSgpIHtcclxuICAgICAgICBpZiAoIXRoaXMuY2hpbGRzLmxlbmd0aCB8fCB0aGlzLmNoaWxkcy5sZW5ndGggIT0gdGhpcy5wYXlQYXJhbXMuY291cnNlTnVtKSB7XHJcbiAgICAgICAgICBUaXBzLnRvYXN0KCF0aGlzLmNoaWxkcy5sZW5ndGggPyBcIuivt+WFiOmAieaLqeWHuuihjOS6ulwiIDogXCLotK3kubDmlbDph4/kuI7lh7rooYzkurrmlbDph4/kuI3ljLnphY1cIiwgcmVzID0+IHt9LCAnbm9uZScpO1xyXG4gICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGxldCBpZHMgPSB0aGlzLmNoaWxkcy5tYXAoZSA9PiB7XHJcbiAgICAgICAgICByZXR1cm4gZS5pZFxyXG4gICAgICAgIH0pXHJcbiAgICAgICAgdGhpcy5wYXlQYXJhbXMuY2hpbGRJZHMgPSBpZHMuam9pbignLCcpXHJcbiAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGNvbmZpZy5vcmRlcmNvbW1pdCh0aGlzLnBheVBhcmFtcylcclxuICAgICAgICBpZiAocmVzLmVycmNvZGUgPT0gMjAwKSB7XHJcbiAgICAgICAgICBsZXQgX2NvZGUgPSBhd2FpdCBjb25maWcud3hwYXl0b3BheSh7XHJcbiAgICAgICAgICAgIG9yZGVyUGF5U246IHJlcy5kYXRhLnBheVNuLFxyXG4gICAgICAgICAgICBkZXNjcmliZTogJ+aPj+i/sCcsXHJcbiAgICAgICAgICAgIG1vbmV5OiBwYXJzZUludCh0aGlzLm9yZGVyUHJpY2UgKiAxMDApIFxyXG4gICAgICAgICAgfSlcclxuICAgICAgICAgIGNvbnNvbGUubG9nKHJlcylcclxuICAgICAgICAgIFd4VXRpbHMud3hQYXkoX2NvZGUuZGF0YSkudGhlbihyID0+IHtcclxuICAgICAgICAgICAgVGlwcy50b2FzdChcIuaUr+S7mOaIkOWKn1wiLCByID0+IHtcclxuICAgICAgICAgICAgICBXeFV0aWxzLmJhY2tPclJlZGlyZWN0KFxyXG4gICAgICAgICAgICAgICAgYC9wYWdlcy9teS9vcmRlcj9pZD1gICsgcmVzLmRhdGEub3JkZXJJZFxyXG4gICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgfSkuY2F0Y2goZXJyID0+IHtcclxuICAgICAgICAgICAgV3hVdGlscy5iYWNrT3JSZWRpcmVjdChcclxuICAgICAgICAgICAgICBgL3BhZ2VzL215L29yZGVyP2lkPWAgKyByZXMuZGF0YS5vcmRlcklkXHJcbiAgICAgICAgICAgICk7XHJcbiAgICAgICAgICB9KVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfTtcclxuICB9XHJcbiJdfQ==