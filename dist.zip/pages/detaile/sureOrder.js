"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

var _WxUtils = require('./../../utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
  _inherits(Dialog, _wepy$page);

  function Dialog() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, Dialog);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
      navigationBarTitleText: "确认订单"
    }, _this.data = {
      orderInfo: {},
      payParams: {},
      childs: [],
      mobile: '',
      canpay: true
    }, _this.computed = {
      orderPrice: function orderPrice() {
        if (JSON.stringify(this.payParams) == '{}' || JSON.stringify(this.orderInfo) == '{}') {
          return '0.00';
        }
        return this.payParams.paymentType == 1 ? (this.orderInfo.price * this.payParams.courseNum).toFixed(2) : (this.orderInfo.earnesMoney * this.payParams.courseNum).toFixed(2);
      }
    }, _this.methods = {
      bindgetphonenumber: function () {
        var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(e) {
          var mobile;
          return regeneratorRuntime.wrap(function _callee$(_context) {
            while (1) {
              switch (_context.prev = _context.next) {
                case 0:
                  if (!(e.detail.errMsg == "getPhoneNumber:ok")) {
                    _context.next = 6;
                    break;
                  }

                  _context.next = 3;
                  return _auth2.default.getPhone(e.detail);

                case 3:
                  mobile = _context.sent;

                  if (mobile) {
                    _wepy2.default.setStorageSync('mobile', mobile);
                    this.mobile = mobile;
                  }
                  this.$apply();

                case 6:
                case "end":
                  return _context.stop();
              }
            }
          }, _callee, this);
        }));

        function bindgetphonenumber(_x) {
          return _ref2.apply(this, arguments);
        }

        return bindgetphonenumber;
      }(),
      textareaBInput: function textareaBInput(e) {
        this.payParams.remark = e.detail.value;
      },
      paymentType: function paymentType(type) {
        this.payParams.paymentType = type;
      },
      plus: function plus() {
        wx.vibrateShort();
        this.payParams.courseNum = this.payParams.courseNum + 1;
        this.childs = [];
      },
      minus: function minus() {
        if (this.payParams.courseNum > 1) {
          wx.vibrateShort();
          this.payParams.courseNum = this.payParams.courseNum - 1;
          this.childs = [];
        }
      },
      getChilds: function () {
        var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(e) {
          return regeneratorRuntime.wrap(function _callee2$(_context2) {
            while (1) {
              switch (_context2.prev = _context2.next) {
                case 0:
                  if (this.mobile) {
                    _context2.next = 2;
                    break;
                  }

                  return _context2.abrupt("return", false);

                case 2:
                  if (!(e.detail.errMsg == "getUserInfo:ok")) {
                    _context2.next = 6;
                    break;
                  }

                  _context2.next = 5;
                  return _auth2.default.getUserinfo(e.detail);

                case 5:
                  _wepy2.default.navigateTo({
                    url: '/pages/meet/childs?type=1&len=' + this.payParams.courseNum
                  });

                case 6:
                case "end":
                  return _context2.stop();
              }
            }
          }, _callee2, this);
        }));

        function getChilds(_x2) {
          return _ref3.apply(this, arguments);
        }

        return getChilds;
      }(),
      pay: function () {
        var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
          var _this2 = this;

          var ids;
          return regeneratorRuntime.wrap(function _callee4$(_context4) {
            while (1) {
              switch (_context4.prev = _context4.next) {
                case 0:
                  if (!(!this.childs.length || this.childs.length != this.payParams.courseNum)) {
                    _context4.next = 3;
                    break;
                  }

                  _Tips2.default.toast(!this.childs.length ? "请先选择出行人" : "购买数量与出行人数量不匹配", function (res) {}, 'none');
                  return _context4.abrupt("return", false);

                case 3:
                  ids = this.childs.map(function (e) {
                    return e.id;
                  });

                  this.payParams.childIds = ids.join(',');
                  this.canpay = false;
                  _config2.default.ordercommit(this.payParams).then(function () {
                    var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(res) {
                      var _code;

                      return regeneratorRuntime.wrap(function _callee3$(_context3) {
                        while (1) {
                          switch (_context3.prev = _context3.next) {
                            case 0:
                              if (!(res.errcode == 200)) {
                                _context3.next = 5;
                                break;
                              }

                              _context3.next = 3;
                              return _config2.default.wxpaytopay({
                                orderPaySn: res.data.paySn,
                                describe: '描述',
                                money: parseInt(res.data.payAmount * 100)
                              });

                            case 3:
                              _code = _context3.sent;

                              _WxUtils2.default.wxPay(_code.data).then(function (r) {
                                var url = "";
                                if (res.data.orderType == 1) url = "/pages/my/order?id=" + res.data.orderId;
                                if (res.data.orderType == 2) url = '/pages/activity/bargain?id=' + res.data.actId;
                                if (res.data.orderType == 3) url = '/pages/activity/pintuan?id=' + res.data.actId;
                                _Tips2.default.toast("支付成功", function (re) {
                                  wx.reLaunch({
                                    url: url
                                  });
                                });
                              }).catch(function (err) {
                                wx.reLaunch({
                                  url: "/pages/my/order?id=" + res.data.orderId
                                });
                              });

                            case 5:
                            case "end":
                              return _context3.stop();
                          }
                        }
                      }, _callee3, _this2);
                    }));

                    return function (_x3) {
                      return _ref5.apply(this, arguments);
                    };
                  }()).catch(function (err) {
                    _this2.canpay = true;
                    _this2.$apply();
                  });

                case 7:
                case "end":
                  return _context4.stop();
              }
            }
          }, _callee4, this);
        }));

        function pay() {
          return _ref4.apply(this, arguments);
        }

        return pay;
      }()
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(Dialog, [{
    key: "onLoad",
    value: function () {
      var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5(opt) {
        return regeneratorRuntime.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                console.log(opt);
                this.mobile = _wepy2.default.getStorageSync('mobile');

                // this.payParams = wepy.$instance.globalData.orderInfo
                // this.orderInfo = wepy.$instance.globalData.courseInfo
                _context5.next = 4;
                return this.getorderInfo(opt);

              case 4:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5, this);
      }));

      function onLoad(_x4) {
        return _ref6.apply(this, arguments);
      }

      return onLoad;
    }()
  }, {
    key: "onShow",
    value: function onShow() {
      this.childs = _wepy2.default.$instance.globalData.childs;
    }
  }, {
    key: "onUnload",
    value: function onUnload() {
      this.childs = _wepy2.default.$instance.globalData.childs = [];
    }
    // 根据课程详情参数，生成支付订单信息

  }, {
    key: "getorderInfo",
    value: function () {
      var _ref7 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee6(opt) {
        var params, _ref8, errcode, data, _data;

        return regeneratorRuntime.wrap(function _callee6$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                /*
                  params ={
                    orderType: ${opt.type}, // 订单类型
                    courseId: ${opt.cid}, // 课程id
                    periodId: ${opt.pid}, // 营期id
                    num: ${opt.num}, // 数量
                    actId: ${opt.aId}, // 活动id
                  }
                */
                params = {
                  orderType: opt.type,
                  courseId: opt.cid,
                  periodId: opt.pid,
                  num: opt.num,
                  actId: opt.aid
                };
                _context6.next = 3;
                return _config2.default.orderInfo(params);

              case 3:
                _ref8 = _context6.sent;
                errcode = _ref8.errcode;
                data = _ref8.data;

                if (errcode == 200) {
                  this.orderInfo = data.course;
                  _data = data;

                  this.payParams = _defineProperty({
                    childIds: '',
                    courseId: _data.courseId,
                    courseNum: _data.num,
                    periodId: _data.periodId,
                    remark: '',
                    paymentType: 1,
                    orderType: _data.orderType,
                    periodName: _data.period,
                    actId: _data.actId,
                    price: _data.totalPrice,
                    actPintuanId: opt.actpid
                  }, "paymentType", opt.pt);
                }
                this.$apply();

              case 8:
              case "end":
                return _context6.stop();
            }
          }
        }, _callee6, this);
      }));

      function getorderInfo(_x5) {
        return _ref7.apply(this, arguments);
      }

      return getorderInfo;
    }()
  }]);

  return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'pages/detaile/sureOrder'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN1cmVPcmRlci5qcyJdLCJuYW1lcyI6WyJEaWFsb2ciLCJjb25maWciLCJuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0IiwiZGF0YSIsIm9yZGVySW5mbyIsInBheVBhcmFtcyIsImNoaWxkcyIsIm1vYmlsZSIsImNhbnBheSIsImNvbXB1dGVkIiwib3JkZXJQcmljZSIsIkpTT04iLCJzdHJpbmdpZnkiLCJwYXltZW50VHlwZSIsInByaWNlIiwiY291cnNlTnVtIiwidG9GaXhlZCIsImVhcm5lc01vbmV5IiwibWV0aG9kcyIsImJpbmRnZXRwaG9uZW51bWJlciIsImUiLCJkZXRhaWwiLCJlcnJNc2ciLCJhdXRoIiwiZ2V0UGhvbmUiLCJ3ZXB5Iiwic2V0U3RvcmFnZVN5bmMiLCIkYXBwbHkiLCJ0ZXh0YXJlYUJJbnB1dCIsInJlbWFyayIsInZhbHVlIiwidHlwZSIsInBsdXMiLCJ3eCIsInZpYnJhdGVTaG9ydCIsIm1pbnVzIiwiZ2V0Q2hpbGRzIiwiZ2V0VXNlcmluZm8iLCJuYXZpZ2F0ZVRvIiwidXJsIiwicGF5IiwibGVuZ3RoIiwiVGlwcyIsInRvYXN0IiwiaWRzIiwibWFwIiwiaWQiLCJjaGlsZElkcyIsImpvaW4iLCJvcmRlcmNvbW1pdCIsInRoZW4iLCJyZXMiLCJlcnJjb2RlIiwid3hwYXl0b3BheSIsIm9yZGVyUGF5U24iLCJwYXlTbiIsImRlc2NyaWJlIiwibW9uZXkiLCJwYXJzZUludCIsInBheUFtb3VudCIsIl9jb2RlIiwiV3hVdGlscyIsInd4UGF5Iiwib3JkZXJUeXBlIiwib3JkZXJJZCIsImFjdElkIiwicmVMYXVuY2giLCJjYXRjaCIsIm9wdCIsImNvbnNvbGUiLCJsb2ciLCJnZXRTdG9yYWdlU3luYyIsImdldG9yZGVySW5mbyIsIiRpbnN0YW5jZSIsImdsb2JhbERhdGEiLCJwYXJhbXMiLCJjb3Vyc2VJZCIsImNpZCIsInBlcmlvZElkIiwicGlkIiwibnVtIiwiYWlkIiwiY291cnNlIiwiX2RhdGEiLCJwZXJpb2ROYW1lIiwicGVyaW9kIiwidG90YWxQcmljZSIsImFjdFBpbnR1YW5JZCIsImFjdHBpZCIsInB0IiwicGFnZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQ0U7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7Ozs7Ozs7Ozs7Ozs7OztJQUNxQkEsTTs7Ozs7Ozs7Ozs7Ozs7c0xBQ25CQyxNLEdBQVM7QUFDUEMsOEJBQXdCO0FBRGpCLEssUUFHVEMsSSxHQUFPO0FBQ0xDLGlCQUFXLEVBRE47QUFFTEMsaUJBQVcsRUFGTjtBQUdMQyxjQUFRLEVBSEg7QUFJTEMsY0FBUSxFQUpIO0FBS0xDLGNBQVE7QUFMSCxLLFFBK0RQQyxRLEdBQVc7QUFDVEMsZ0JBRFMsd0JBQ0k7QUFDWCxZQUFJQyxLQUFLQyxTQUFMLENBQWUsS0FBS1AsU0FBcEIsS0FBa0MsSUFBbEMsSUFBMENNLEtBQUtDLFNBQUwsQ0FBZSxLQUFLUixTQUFwQixLQUFrQyxJQUFoRixFQUFzRjtBQUNwRixpQkFBTyxNQUFQO0FBQ0Q7QUFDRCxlQUFPLEtBQUtDLFNBQUwsQ0FBZVEsV0FBZixJQUE4QixDQUE5QixHQUFrQyxDQUFDLEtBQUtULFNBQUwsQ0FBZVUsS0FBZixHQUF1QixLQUFLVCxTQUFMLENBQWVVLFNBQXZDLEVBQWtEQyxPQUFsRCxDQUEwRCxDQUExRCxDQUFsQyxHQUFpRyxDQUFDLEtBQUtaLFNBQUwsQ0FBZWEsV0FBZixHQUE2QixLQUFLWixTQUFMLENBQWVVLFNBQTdDLEVBQXdEQyxPQUF4RCxDQUFnRSxDQUFoRSxDQUF4RztBQUNEO0FBTlEsSyxRQVFYRSxPLEdBQVU7QUFDRkMsd0JBREU7QUFBQSw2RkFDaUJDLENBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQUVGQSxFQUFFQyxNQUFGLENBQVNDLE1BQVQsSUFBbUIsbUJBRmpCO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUEseUJBR2VDLGVBQUtDLFFBQUwsQ0FBY0osRUFBRUMsTUFBaEIsQ0FIZjs7QUFBQTtBQUdBZCx3QkFIQTs7QUFJSixzQkFBSUEsTUFBSixFQUFZO0FBQ1ZrQixtQ0FBS0MsY0FBTCxDQUFvQixRQUFwQixFQUE4Qm5CLE1BQTlCO0FBQ0EseUJBQUtBLE1BQUwsR0FBY0EsTUFBZDtBQUNEO0FBQ0QsdUJBQUtvQixNQUFMOztBQVJJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBV1JDLG9CQVhRLDBCQVdPUixDQVhQLEVBV1U7QUFDaEIsYUFBS2YsU0FBTCxDQUFld0IsTUFBZixHQUF3QlQsRUFBRUMsTUFBRixDQUFTUyxLQUFqQztBQUNELE9BYk87QUFjUmpCLGlCQWRRLHVCQWNJa0IsSUFkSixFQWNVO0FBQ2hCLGFBQUsxQixTQUFMLENBQWVRLFdBQWYsR0FBNkJrQixJQUE3QjtBQUNELE9BaEJPO0FBaUJSQyxVQWpCUSxrQkFpQkQ7QUFDTEMsV0FBR0MsWUFBSDtBQUNBLGFBQUs3QixTQUFMLENBQWVVLFNBQWYsR0FBMkIsS0FBS1YsU0FBTCxDQUFlVSxTQUFmLEdBQTJCLENBQXREO0FBQ0EsYUFBS1QsTUFBTCxHQUFjLEVBQWQ7QUFDRCxPQXJCTztBQXNCUjZCLFdBdEJRLG1CQXNCQTtBQUNOLFlBQUksS0FBSzlCLFNBQUwsQ0FBZVUsU0FBZixHQUEyQixDQUEvQixFQUFrQztBQUNoQ2tCLGFBQUdDLFlBQUg7QUFDQSxlQUFLN0IsU0FBTCxDQUFlVSxTQUFmLEdBQTJCLEtBQUtWLFNBQUwsQ0FBZVUsU0FBZixHQUEyQixDQUF0RDtBQUNBLGVBQUtULE1BQUwsR0FBYyxFQUFkO0FBQ0Q7QUFDRixPQTVCTztBQTZCRjhCLGVBN0JFO0FBQUEsOEZBNkJRaEIsQ0E3QlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQThCRCxLQUFLYixNQTlCSjtBQUFBO0FBQUE7QUFBQTs7QUFBQSxvREErQkcsS0EvQkg7O0FBQUE7QUFBQSx3QkFpQ0ZhLEVBQUVDLE1BQUYsQ0FBU0MsTUFBVCxJQUFtQixnQkFqQ2pCO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUEseUJBa0NFQyxlQUFLYyxXQUFMLENBQWlCakIsRUFBRUMsTUFBbkIsQ0FsQ0Y7O0FBQUE7QUFtQ0pJLGlDQUFLYSxVQUFMLENBQWdCO0FBQ2RDLHlCQUFLLG1DQUFtQyxLQUFLbEMsU0FBTCxDQUFlVTtBQUR6QyxtQkFBaEI7O0FBbkNJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBd0NGeUIsU0F4Q0U7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkF5Q0YsQ0FBQyxLQUFLbEMsTUFBTCxDQUFZbUMsTUFBYixJQUF1QixLQUFLbkMsTUFBTCxDQUFZbUMsTUFBWixJQUFzQixLQUFLcEMsU0FBTCxDQUFlVSxTQXpDMUQ7QUFBQTtBQUFBO0FBQUE7O0FBMENKMkIsaUNBQUtDLEtBQUwsQ0FBVyxDQUFDLEtBQUtyQyxNQUFMLENBQVltQyxNQUFiLEdBQXNCLFNBQXRCLEdBQWtDLGVBQTdDLEVBQThELGVBQU8sQ0FBRSxDQUF2RSxFQUF5RSxNQUF6RTtBQTFDSSxvREEyQ0csS0EzQ0g7O0FBQUE7QUE2Q0ZHLHFCQTdDRSxHQTZDSSxLQUFLdEMsTUFBTCxDQUFZdUMsR0FBWixDQUFnQixhQUFLO0FBQzdCLDJCQUFPekIsRUFBRTBCLEVBQVQ7QUFDRCxtQkFGUyxDQTdDSjs7QUFnRE4sdUJBQUt6QyxTQUFMLENBQWUwQyxRQUFmLEdBQTBCSCxJQUFJSSxJQUFKLENBQVMsR0FBVCxDQUExQjtBQUNBLHVCQUFLeEMsTUFBTCxHQUFjLEtBQWQ7QUFDQVAsbUNBQU9nRCxXQUFQLENBQW1CLEtBQUs1QyxTQUF4QixFQUFtQzZDLElBQW5DO0FBQUEsd0ZBQXlDLGtCQUFNQyxHQUFOO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQ0FDbkNBLElBQUlDLE9BQUosSUFBZSxHQURvQjtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBLHFDQUVuQm5ELGlCQUFPb0QsVUFBUCxDQUFrQjtBQUNsQ0MsNENBQVlILElBQUloRCxJQUFKLENBQVNvRCxLQURhO0FBRWxDQywwQ0FBVSxJQUZ3QjtBQUdsQ0MsdUNBQU9DLFNBQVNQLElBQUloRCxJQUFKLENBQVN3RCxTQUFULEdBQXFCLEdBQTlCO0FBSDJCLCtCQUFsQixDQUZtQjs7QUFBQTtBQUVqQ0MsbUNBRmlDOztBQU9yQ0MsZ0RBQVFDLEtBQVIsQ0FBY0YsTUFBTXpELElBQXBCLEVBQTBCK0MsSUFBMUIsQ0FBK0IsYUFBSztBQUNsQyxvQ0FBSVgsUUFBSjtBQUNBLG9DQUFJWSxJQUFJaEQsSUFBSixDQUFTNEQsU0FBVCxJQUFzQixDQUExQixFQUE2QnhCLE1BQU0sd0JBQXdCWSxJQUFJaEQsSUFBSixDQUFTNkQsT0FBdkM7QUFDN0Isb0NBQUliLElBQUloRCxJQUFKLENBQVM0RCxTQUFULElBQXNCLENBQTFCLEVBQTZCeEIsTUFBTSxnQ0FBZ0NZLElBQUloRCxJQUFKLENBQVM4RCxLQUEvQztBQUM3QixvQ0FBSWQsSUFBSWhELElBQUosQ0FBUzRELFNBQVQsSUFBc0IsQ0FBMUIsRUFBNkJ4QixNQUFNLGdDQUFnQ1ksSUFBSWhELElBQUosQ0FBUzhELEtBQS9DO0FBQzdCdkIsK0NBQUtDLEtBQUwsQ0FBVyxNQUFYLEVBQW1CLGNBQU07QUFDdkJWLHFDQUFHaUMsUUFBSCxDQUFZO0FBQ1YzQjtBQURVLG1DQUFaO0FBR0QsaUNBSkQ7QUFLRCwrQkFWRCxFQVVHNEIsS0FWSCxDQVVTLGVBQU87QUFDZGxDLG1DQUFHaUMsUUFBSCxDQUFZO0FBQ1YzQix1Q0FBSyx3QkFBd0JZLElBQUloRCxJQUFKLENBQVM2RDtBQUQ1QixpQ0FBWjtBQUdELCtCQWREOztBQVBxQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBekM7O0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBdUJHRyxLQXZCSCxDQXVCUyxlQUFLO0FBQ1osMkJBQUszRCxNQUFMLEdBQWMsSUFBZDtBQUNBLDJCQUFLbUIsTUFBTDtBQUNELG1CQTFCRDs7QUFsRE07QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQSxLOzs7Ozs7NEZBaEVHeUMsRzs7Ozs7QUFDWEMsd0JBQVFDLEdBQVIsQ0FBWUYsR0FBWjtBQUNBLHFCQUFLN0QsTUFBTCxHQUFja0IsZUFBSzhDLGNBQUwsQ0FBb0IsUUFBcEIsQ0FBZDs7QUFFQTtBQUNBOzt1QkFDTSxLQUFLQyxZQUFMLENBQWtCSixHQUFsQixDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7NkJBRUM7QUFDUCxXQUFLOUQsTUFBTCxHQUFjbUIsZUFBS2dELFNBQUwsQ0FBZUMsVUFBZixDQUEwQnBFLE1BQXhDO0FBQ0Q7OzsrQkFDVTtBQUNULFdBQUtBLE1BQUwsR0FBY21CLGVBQUtnRCxTQUFMLENBQWVDLFVBQWYsQ0FBMEJwRSxNQUExQixHQUFtQyxFQUFqRDtBQUNEO0FBQ0Q7Ozs7OzRGQUNtQjhELEc7Ozs7Ozs7QUFDakI7Ozs7Ozs7OztBQVNJTyxzQixHQUFTO0FBQ1haLDZCQUFXSyxJQUFJckMsSUFESjtBQUVYNkMsNEJBQVVSLElBQUlTLEdBRkg7QUFHWEMsNEJBQVVWLElBQUlXLEdBSEg7QUFJWEMsdUJBQUtaLElBQUlZLEdBSkU7QUFLWGYseUJBQU9HLElBQUlhO0FBTEEsaUI7O3VCQVVIaEYsaUJBQU9HLFNBQVAsQ0FBaUJ1RSxNQUFqQixDOzs7O0FBRlJ2Qix1QixTQUFBQSxPO0FBQ0FqRCxvQixTQUFBQSxJOztBQUVGLG9CQUFJaUQsV0FBVyxHQUFmLEVBQW9CO0FBQ2xCLHVCQUFLaEQsU0FBTCxHQUFpQkQsS0FBSytFLE1BQXRCO0FBQ0lDLHVCQUZjLEdBRU5oRixJQUZNOztBQUdsQix1QkFBS0UsU0FBTDtBQUNFMEMsOEJBQVUsRUFEWjtBQUVFNkIsOEJBQVVPLE1BQU1QLFFBRmxCO0FBR0U3RCwrQkFBV29FLE1BQU1ILEdBSG5CO0FBSUVGLDhCQUFVSyxNQUFNTCxRQUpsQjtBQUtFakQsNEJBQVEsRUFMVjtBQU1FaEIsaUNBQWEsQ0FOZjtBQU9Fa0QsK0JBQVdvQixNQUFNcEIsU0FQbkI7QUFRRXFCLGdDQUFZRCxNQUFNRSxNQVJwQjtBQVNFcEIsMkJBQU9rQixNQUFNbEIsS0FUZjtBQVVFbkQsMkJBQU9xRSxNQUFNRyxVQVZmO0FBV0VDLGtDQUFjbkIsSUFBSW9CO0FBWHBCLG9DQVlnQnBCLElBQUlxQixFQVpwQjtBQWNEO0FBQ0QscUJBQUs5RCxNQUFMOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBakVnQ0YsZUFBS2lFLEk7O2tCQUFwQjFGLE0iLCJmaWxlIjoic3VyZU9yZGVyLmpzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbiAgaW1wb3J0IHdlcHkgZnJvbSBcIndlcHlcIjtcclxuICBpbXBvcnQgY29uZmlnIGZyb20gXCJAL2FwaS9jb25maWdcIlxyXG4gIGltcG9ydCBUaXBzIGZyb20gXCJAL3V0aWxzL1RpcHNcIlxyXG4gIGltcG9ydCBXeFV0aWxzIGZyb20gXCJAL3V0aWxzL1d4VXRpbHNcIlxyXG4gIGltcG9ydCBhdXRoIGZyb20gXCJAL2FwaS9hdXRoXCJcclxuICBleHBvcnQgZGVmYXVsdCBjbGFzcyBEaWFsb2cgZXh0ZW5kcyB3ZXB5LnBhZ2Uge1xyXG4gICAgY29uZmlnID0ge1xyXG4gICAgICBuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0OiBcIuehruiupOiuouWNlVwiXHJcbiAgICB9O1xyXG4gICAgZGF0YSA9IHtcclxuICAgICAgb3JkZXJJbmZvOiB7fSxcclxuICAgICAgcGF5UGFyYW1zOiB7fSxcclxuICAgICAgY2hpbGRzOiBbXSxcclxuICAgICAgbW9iaWxlOiAnJyxcclxuICAgICAgY2FucGF5OiB0cnVlXHJcbiAgICB9O1xyXG4gICAgYXN5bmMgb25Mb2FkKG9wdCkge1xyXG4gICAgICBjb25zb2xlLmxvZyhvcHQpXHJcbiAgICAgIHRoaXMubW9iaWxlID0gd2VweS5nZXRTdG9yYWdlU3luYygnbW9iaWxlJyk7XHJcbiAgICAgIFxyXG4gICAgICAvLyB0aGlzLnBheVBhcmFtcyA9IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEub3JkZXJJbmZvXHJcbiAgICAgIC8vIHRoaXMub3JkZXJJbmZvID0gd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5jb3Vyc2VJbmZvXHJcbiAgICAgIGF3YWl0IHRoaXMuZ2V0b3JkZXJJbmZvKG9wdClcclxuICAgIH1cclxuICAgIG9uU2hvdygpIHtcclxuICAgICAgdGhpcy5jaGlsZHMgPSB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLmNoaWxkc1xyXG4gICAgfVxyXG4gICAgb25VbmxvYWQoKSB7XHJcbiAgICAgIHRoaXMuY2hpbGRzID0gd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5jaGlsZHMgPSBbXVxyXG4gICAgfVxyXG4gICAgLy8g5qC55o2u6K++56iL6K+m5oOF5Y+C5pWw77yM55Sf5oiQ5pSv5LuY6K6i5Y2V5L+h5oGvXHJcbiAgICBhc3luYyBnZXRvcmRlckluZm8ob3B0KSB7XHJcbiAgICAgIC8qXHJcbiAgICAgICAgcGFyYW1zID17XHJcbiAgICAgICAgICBvcmRlclR5cGU6ICR7b3B0LnR5cGV9LCAvLyDorqLljZXnsbvlnotcclxuICAgICAgICAgIGNvdXJzZUlkOiAke29wdC5jaWR9LCAvLyDor77nqItpZFxyXG4gICAgICAgICAgcGVyaW9kSWQ6ICR7b3B0LnBpZH0sIC8vIOiQpeacn2lkXHJcbiAgICAgICAgICBudW06ICR7b3B0Lm51bX0sIC8vIOaVsOmHj1xyXG4gICAgICAgICAgYWN0SWQ6ICR7b3B0LmFJZH0sIC8vIOa0u+WKqGlkXHJcbiAgICAgICAgfVxyXG4gICAgICAqL1xyXG4gICAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICAgIG9yZGVyVHlwZTogb3B0LnR5cGUsXHJcbiAgICAgICAgY291cnNlSWQ6IG9wdC5jaWQsXHJcbiAgICAgICAgcGVyaW9kSWQ6IG9wdC5waWQsXHJcbiAgICAgICAgbnVtOiBvcHQubnVtLFxyXG4gICAgICAgIGFjdElkOiBvcHQuYWlkXHJcbiAgICAgIH1cclxuICAgICAgbGV0IHtcclxuICAgICAgICBlcnJjb2RlLFxyXG4gICAgICAgIGRhdGFcclxuICAgICAgfSA9IGF3YWl0IGNvbmZpZy5vcmRlckluZm8ocGFyYW1zKVxyXG4gICAgICBpZiAoZXJyY29kZSA9PSAyMDApIHtcclxuICAgICAgICB0aGlzLm9yZGVySW5mbyA9IGRhdGEuY291cnNlXHJcbiAgICAgICAgbGV0IF9kYXRhID0gZGF0YVxyXG4gICAgICAgIHRoaXMucGF5UGFyYW1zID0ge1xyXG4gICAgICAgICAgY2hpbGRJZHM6ICcnLFxyXG4gICAgICAgICAgY291cnNlSWQ6IF9kYXRhLmNvdXJzZUlkLFxyXG4gICAgICAgICAgY291cnNlTnVtOiBfZGF0YS5udW0sXHJcbiAgICAgICAgICBwZXJpb2RJZDogX2RhdGEucGVyaW9kSWQsXHJcbiAgICAgICAgICByZW1hcms6ICcnLFxyXG4gICAgICAgICAgcGF5bWVudFR5cGU6IDEsXHJcbiAgICAgICAgICBvcmRlclR5cGU6IF9kYXRhLm9yZGVyVHlwZSxcclxuICAgICAgICAgIHBlcmlvZE5hbWU6IF9kYXRhLnBlcmlvZCxcclxuICAgICAgICAgIGFjdElkOiBfZGF0YS5hY3RJZCxcclxuICAgICAgICAgIHByaWNlOiBfZGF0YS50b3RhbFByaWNlLFxyXG4gICAgICAgICAgYWN0UGludHVhbklkOiBvcHQuYWN0cGlkLFxyXG4gICAgICAgICAgcGF5bWVudFR5cGUgOiBvcHQucHRcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgfVxyXG4gICAgY29tcHV0ZWQgPSB7XHJcbiAgICAgIG9yZGVyUHJpY2UoKSB7XHJcbiAgICAgICAgaWYgKEpTT04uc3RyaW5naWZ5KHRoaXMucGF5UGFyYW1zKSA9PSAne30nIHx8IEpTT04uc3RyaW5naWZ5KHRoaXMub3JkZXJJbmZvKSA9PSAne30nKSB7XHJcbiAgICAgICAgICByZXR1cm4gJzAuMDAnXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB0aGlzLnBheVBhcmFtcy5wYXltZW50VHlwZSA9PSAxID8gKHRoaXMub3JkZXJJbmZvLnByaWNlICogdGhpcy5wYXlQYXJhbXMuY291cnNlTnVtKS50b0ZpeGVkKDIpIDogKHRoaXMub3JkZXJJbmZvLmVhcm5lc01vbmV5ICogdGhpcy5wYXlQYXJhbXMuY291cnNlTnVtKS50b0ZpeGVkKDIpXHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIG1ldGhvZHMgPSB7XHJcbiAgICAgIGFzeW5jIGJpbmRnZXRwaG9uZW51bWJlcihlKSB7XHJcbiAgICAgICAgaWYgKGUuZGV0YWlsLmVyck1zZyA9PSBcImdldFBob25lTnVtYmVyOm9rXCIpIHtcclxuICAgICAgICAgIGxldCBtb2JpbGUgPSBhd2FpdCBhdXRoLmdldFBob25lKGUuZGV0YWlsKVxyXG4gICAgICAgICAgaWYgKG1vYmlsZSkge1xyXG4gICAgICAgICAgICB3ZXB5LnNldFN0b3JhZ2VTeW5jKCdtb2JpbGUnLCBtb2JpbGUpO1xyXG4gICAgICAgICAgICB0aGlzLm1vYmlsZSA9IG1vYmlsZVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgICAgIH1cclxuICAgICAgfSxcclxuICAgICAgdGV4dGFyZWFCSW5wdXQoZSkge1xyXG4gICAgICAgIHRoaXMucGF5UGFyYW1zLnJlbWFyayA9IGUuZGV0YWlsLnZhbHVlXHJcbiAgICAgIH0sXHJcbiAgICAgIHBheW1lbnRUeXBlKHR5cGUpIHtcclxuICAgICAgICB0aGlzLnBheVBhcmFtcy5wYXltZW50VHlwZSA9IHR5cGVcclxuICAgICAgfSxcclxuICAgICAgcGx1cygpIHtcclxuICAgICAgICB3eC52aWJyYXRlU2hvcnQoKVxyXG4gICAgICAgIHRoaXMucGF5UGFyYW1zLmNvdXJzZU51bSA9IHRoaXMucGF5UGFyYW1zLmNvdXJzZU51bSArIDFcclxuICAgICAgICB0aGlzLmNoaWxkcyA9IFtdXHJcbiAgICAgIH0sXHJcbiAgICAgIG1pbnVzKCkge1xyXG4gICAgICAgIGlmICh0aGlzLnBheVBhcmFtcy5jb3Vyc2VOdW0gPiAxKSB7XHJcbiAgICAgICAgICB3eC52aWJyYXRlU2hvcnQoKVxyXG4gICAgICAgICAgdGhpcy5wYXlQYXJhbXMuY291cnNlTnVtID0gdGhpcy5wYXlQYXJhbXMuY291cnNlTnVtIC0gMVxyXG4gICAgICAgICAgdGhpcy5jaGlsZHMgPSBbXVxyXG4gICAgICAgIH1cclxuICAgICAgfSxcclxuICAgICAgYXN5bmMgZ2V0Q2hpbGRzKGUpIHtcclxuICAgICAgICBpZiAoIXRoaXMubW9iaWxlKSB7XHJcbiAgICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKGUuZGV0YWlsLmVyck1zZyA9PSBcImdldFVzZXJJbmZvOm9rXCIpIHtcclxuICAgICAgICAgIGF3YWl0IGF1dGguZ2V0VXNlcmluZm8oZS5kZXRhaWwpXHJcbiAgICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICB1cmw6ICcvcGFnZXMvbWVldC9jaGlsZHM/dHlwZT0xJmxlbj0nICsgdGhpcy5wYXlQYXJhbXMuY291cnNlTnVtXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgIH0sXHJcbiAgICAgIGFzeW5jIHBheSgpIHtcclxuICAgICAgICBpZiAoIXRoaXMuY2hpbGRzLmxlbmd0aCB8fCB0aGlzLmNoaWxkcy5sZW5ndGggIT0gdGhpcy5wYXlQYXJhbXMuY291cnNlTnVtKSB7XHJcbiAgICAgICAgICBUaXBzLnRvYXN0KCF0aGlzLmNoaWxkcy5sZW5ndGggPyBcIuivt+WFiOmAieaLqeWHuuihjOS6ulwiIDogXCLotK3kubDmlbDph4/kuI7lh7rooYzkurrmlbDph4/kuI3ljLnphY1cIiwgcmVzID0+IHt9LCAnbm9uZScpO1xyXG4gICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGxldCBpZHMgPSB0aGlzLmNoaWxkcy5tYXAoZSA9PiB7XHJcbiAgICAgICAgICByZXR1cm4gZS5pZFxyXG4gICAgICAgIH0pXHJcbiAgICAgICAgdGhpcy5wYXlQYXJhbXMuY2hpbGRJZHMgPSBpZHMuam9pbignLCcpXHJcbiAgICAgICAgdGhpcy5jYW5wYXkgPSBmYWxzZVxyXG4gICAgICAgIGNvbmZpZy5vcmRlcmNvbW1pdCh0aGlzLnBheVBhcmFtcykudGhlbiggYXN5bmMgcmVzID0+IHtcclxuICAgICAgICAgIGlmIChyZXMuZXJyY29kZSA9PSAyMDApIHtcclxuICAgICAgICAgICAgbGV0IF9jb2RlID0gYXdhaXQgY29uZmlnLnd4cGF5dG9wYXkoe1xyXG4gICAgICAgICAgICAgIG9yZGVyUGF5U246IHJlcy5kYXRhLnBheVNuLFxyXG4gICAgICAgICAgICAgIGRlc2NyaWJlOiAn5o+P6L+wJyxcclxuICAgICAgICAgICAgICBtb25leTogcGFyc2VJbnQocmVzLmRhdGEucGF5QW1vdW50ICogMTAwKVxyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICBXeFV0aWxzLnd4UGF5KF9jb2RlLmRhdGEpLnRoZW4ociA9PiB7XHJcbiAgICAgICAgICAgICAgbGV0IHVybCA9IGBgXHJcbiAgICAgICAgICAgICAgaWYgKHJlcy5kYXRhLm9yZGVyVHlwZSA9PSAxKSB1cmwgPSBgL3BhZ2VzL215L29yZGVyP2lkPWAgKyByZXMuZGF0YS5vcmRlcklkXHJcbiAgICAgICAgICAgICAgaWYgKHJlcy5kYXRhLm9yZGVyVHlwZSA9PSAyKSB1cmwgPSAnL3BhZ2VzL2FjdGl2aXR5L2JhcmdhaW4/aWQ9JyArIHJlcy5kYXRhLmFjdElkXHJcbiAgICAgICAgICAgICAgaWYgKHJlcy5kYXRhLm9yZGVyVHlwZSA9PSAzKSB1cmwgPSAnL3BhZ2VzL2FjdGl2aXR5L3BpbnR1YW4/aWQ9JyArIHJlcy5kYXRhLmFjdElkXHJcbiAgICAgICAgICAgICAgVGlwcy50b2FzdChcIuaUr+S7mOaIkOWKn1wiLCByZSA9PiB7XHJcbiAgICAgICAgICAgICAgICB3eC5yZUxhdW5jaCh7XHJcbiAgICAgICAgICAgICAgICAgIHVybFxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH0pLmNhdGNoKGVyciA9PiB7XHJcbiAgICAgICAgICAgICAgd3gucmVMYXVuY2goe1xyXG4gICAgICAgICAgICAgICAgdXJsOiBgL3BhZ2VzL215L29yZGVyP2lkPWAgKyByZXMuZGF0YS5vcmRlcklkXHJcbiAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSkuY2F0Y2goZXJyPT57XHJcbiAgICAgICAgICB0aGlzLmNhbnBheSA9IHRydWVcclxuICAgICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgICB9KVxyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gIH1cclxuIl19