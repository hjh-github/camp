"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

var _WxUtils = require('./../../utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

var _coupon = require('./../api/coupon.js');

var _coupon2 = _interopRequireDefault(_coupon);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Cpt2My = function (_wepy$page) {
    _inherits(Cpt2My, _wepy$page);

    function Cpt2My() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Cpt2My);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Cpt2My.__proto__ || Object.getPrototypeOf(Cpt2My)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
            navigationBarTitleText: "优惠券"
        }, _this.data = {
            coupons: [],
            isloading: true,
            bg_img: {
                cou_bg_1: 'https://images.kuan1.cn/kuan1/upload/image/20201227/20201227141029_82067.png',
                cou_bg_0: 'https://images.kuan1.cn/kuan1/upload/image/20201227/20201227141101_21176.png'
            }
        }, _this.components = {}, _this.methods = {
            todetail: function () {
                var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(id) {
                    var res;
                    return regeneratorRuntime.wrap(function _callee$(_context) {
                        while (1) {
                            switch (_context.prev = _context.next) {
                                case 0:
                                    _context.next = 2;
                                    return _coupon2.default.reveivecoupon(id);

                                case 2:
                                    res = _context.sent;

                                    if (res.errcode == 200) {
                                        _Tips2.default.toast("领取成功！", function (res) {}, 'none');
                                    } else {
                                        _Tips2.default.toast("请稍后重试", function (res) {}, 'none');
                                    }
                                    this.load();

                                case 5:
                                case "end":
                                    return _context.stop();
                            }
                        }
                    }, _callee, this);
                }));

                function todetail(_x) {
                    return _ref2.apply(this, arguments);
                }

                return todetail;
            }(),
            touse: function touse() {
                _wepy2.default.switchTab({ url: '/pages/home/index' });
            },
            tomy: function tomy() {
                _WxUtils2.default.backOrNavigate('/coupons/pages/myCoupons');
            }
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(Cpt2My, [{
        key: "onLoad",
        value: function () {
            var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
                return regeneratorRuntime.wrap(function _callee2$(_context2) {
                    while (1) {
                        switch (_context2.prev = _context2.next) {
                            case 0:
                                _context2.next = 2;
                                return _auth2.default.login();

                            case 2:
                                _context2.next = 4;
                                return this.load();

                            case 4:
                            case "end":
                                return _context2.stop();
                        }
                    }
                }, _callee2, this);
            }));

            function onLoad() {
                return _ref3.apply(this, arguments);
            }

            return onLoad;
        }()
    }, {
        key: "load",
        value: function () {
            var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
                var _ref5, couponList;

                return regeneratorRuntime.wrap(function _callee3$(_context3) {
                    while (1) {
                        switch (_context3.prev = _context3.next) {
                            case 0:
                                this.isloading = true;
                                _context3.next = 3;
                                return _coupon2.default.getcoupons();

                            case 3:
                                _ref5 = _context3.sent;
                                couponList = _ref5.couponList;

                                if (couponList.length > 0) {
                                    this.coupons = couponList;
                                    this.isloading = false;
                                }
                                this.$apply();

                            case 7:
                            case "end":
                                return _context3.stop();
                        }
                    }
                }, _callee3, this);
            }));

            function load() {
                return _ref4.apply(this, arguments);
            }

            return load;
        }()
    }]);

    return Cpt2My;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Cpt2My , 'coupons/pages/cangets'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNhbmdldHMuanMiXSwibmFtZXMiOlsiQ3B0Mk15IiwiY29uZmlnIiwibmF2aWdhdGlvbkJhclRpdGxlVGV4dCIsImRhdGEiLCJjb3Vwb25zIiwiaXNsb2FkaW5nIiwiYmdfaW1nIiwiY291X2JnXzEiLCJjb3VfYmdfMCIsImNvbXBvbmVudHMiLCJtZXRob2RzIiwidG9kZXRhaWwiLCJpZCIsImNvdXBvbiIsInJldmVpdmVjb3Vwb24iLCJyZXMiLCJlcnJjb2RlIiwiVGlwcyIsInRvYXN0IiwibG9hZCIsInRvdXNlIiwid2VweSIsInN3aXRjaFRhYiIsInVybCIsInRvbXkiLCJXeFV0aWxzIiwiYmFja09yTmF2aWdhdGUiLCJBdXRoIiwibG9naW4iLCJnZXRjb3Vwb25zIiwiY291cG9uTGlzdCIsImxlbmd0aCIsIiRhcHBseSIsInBhZ2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUNJOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7Ozs7Ozs7Ozs7O0lBQ3FCQSxNOzs7Ozs7Ozs7Ozs7OzswTEFDakJDLE0sR0FBUztBQUNMQyxvQ0FBd0I7QUFEbkIsUyxRQUdUQyxJLEdBQU87QUFDSEMscUJBQVMsRUFETjtBQUVIQyx1QkFBVyxJQUZSO0FBR0hDLG9CQUFRO0FBQ0pDLDBCQUFVLDhFQUROO0FBRUpDLDBCQUFVO0FBRk47QUFITCxTLFFBUVBDLFUsR0FBYSxFLFFBZ0JiQyxPLEdBQVU7QUFDRkMsb0JBREU7QUFBQSxxR0FDT0MsRUFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJDQUVhQyxpQkFBT0MsYUFBUCxDQUFxQkYsRUFBckIsQ0FGYjs7QUFBQTtBQUVBRyx1Q0FGQTs7QUFHSix3Q0FBR0EsSUFBSUMsT0FBSixJQUFlLEdBQWxCLEVBQXNCO0FBQ2xCQyx1REFBS0MsS0FBTCxDQUFXLE9BQVgsRUFBb0IsZUFBTyxDQUFFLENBQTdCLEVBQStCLE1BQS9CO0FBQ0gscUNBRkQsTUFFSztBQUNERCx1REFBS0MsS0FBTCxDQUFXLE9BQVgsRUFBb0IsZUFBTyxDQUFFLENBQTdCLEVBQStCLE1BQS9CO0FBQ0g7QUFDRCx5Q0FBS0MsSUFBTDs7QUFSSTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQVVOQyxpQkFWTSxtQkFVQztBQUNIQywrQkFBS0MsU0FBTCxDQUFlLEVBQUVDLEtBQUssbUJBQVAsRUFBZjtBQUNILGFBWks7QUFhTkMsZ0JBYk0sa0JBYUE7QUFDRkMsa0NBQVFDLGNBQVIsQ0FBdUIsMEJBQXZCO0FBQ0g7QUFmSyxTOzs7Ozs7Ozs7Ozs7dUNBZEFDLGVBQUtDLEtBQUwsRTs7Ozt1Q0FDQSxLQUFLVCxJQUFMLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBR04scUNBQUtkLFNBQUwsR0FBaUIsSUFBakI7O3VDQUdVUSxpQkFBT2dCLFVBQVAsRTs7OztBQUROQywwQyxTQUFBQSxVOztBQUVKLG9DQUFJQSxXQUFXQyxNQUFYLEdBQW9CLENBQXhCLEVBQTJCO0FBQ3ZCLHlDQUFLM0IsT0FBTCxHQUFlMEIsVUFBZjtBQUNBLHlDQUFLekIsU0FBTCxHQUFpQixLQUFqQjtBQUNIO0FBQ0QscUNBQUsyQixNQUFMOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBMUI0QlgsZUFBS1ksSTs7a0JBQXBCakMsTSIsImZpbGUiOiJjYW5nZXRzLmpzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbiAgICBpbXBvcnQgd2VweSBmcm9tIFwid2VweVwiO1xyXG4gICAgaW1wb3J0IFRpcHMgZnJvbSBcIkAvdXRpbHMvVGlwc1wiO1xyXG4gICAgaW1wb3J0IFd4VXRpbHMgZnJvbSBcIkAvdXRpbHMvV3hVdGlsc1wiO1xyXG4gICAgaW1wb3J0IEF1dGggZnJvbSBcIkAvYXBpL2F1dGhcIjtcclxuICAgIGltcG9ydCBjb3Vwb24gZnJvbSBcIi4uL2FwaS9jb3Vwb25cIjtcclxuICAgIGV4cG9ydCBkZWZhdWx0IGNsYXNzIENwdDJNeSBleHRlbmRzIHdlcHkucGFnZSB7XHJcbiAgICAgICAgY29uZmlnID0ge1xyXG4gICAgICAgICAgICBuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0OiBcIuS8mOaDoOWIuFwiXHJcbiAgICAgICAgfTtcclxuICAgICAgICBkYXRhID0ge1xyXG4gICAgICAgICAgICBjb3Vwb25zOiBbXSxcclxuICAgICAgICAgICAgaXNsb2FkaW5nOiB0cnVlLFxyXG4gICAgICAgICAgICBiZ19pbWc6IHtcclxuICAgICAgICAgICAgICAgIGNvdV9iZ18xOiAnaHR0cHM6Ly9pbWFnZXMua3VhbjEuY24va3VhbjEvdXBsb2FkL2ltYWdlLzIwMjAxMjI3LzIwMjAxMjI3MTQxMDI5XzgyMDY3LnBuZycsXHJcbiAgICAgICAgICAgICAgICBjb3VfYmdfMDogJ2h0dHBzOi8vaW1hZ2VzLmt1YW4xLmNuL2t1YW4xL3VwbG9hZC9pbWFnZS8yMDIwMTIyNy8yMDIwMTIyNzE0MTEwMV8yMTE3Ni5wbmcnLFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbXBvbmVudHMgPSB7fVxyXG4gICAgICAgIGFzeW5jIG9uTG9hZCgpIHtcclxuICAgICAgICAgICAgYXdhaXQgQXV0aC5sb2dpbigpXHJcbiAgICAgICAgICAgIGF3YWl0IHRoaXMubG9hZCgpXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGFzeW5jIGxvYWQoKSB7XHJcbiAgICAgICAgICAgIHRoaXMuaXNsb2FkaW5nID0gdHJ1ZVxyXG4gICAgICAgICAgICBsZXQge1xyXG4gICAgICAgICAgICAgICAgY291cG9uTGlzdFxyXG4gICAgICAgICAgICB9ID0gYXdhaXQgY291cG9uLmdldGNvdXBvbnMoKVxyXG4gICAgICAgICAgICBpZiAoY291cG9uTGlzdC5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNvdXBvbnMgPSBjb3Vwb25MaXN0XHJcbiAgICAgICAgICAgICAgICB0aGlzLmlzbG9hZGluZyA9IGZhbHNlXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgICAgIH1cclxuICAgICAgICBtZXRob2RzID0ge1xyXG4gICAgICAgICAgYXN5bmMgdG9kZXRhaWwoaWQpIHtcclxuICAgICAgICAgICAgICBsZXQgcmVzID0gIGF3YWl0IGNvdXBvbi5yZXZlaXZlY291cG9uKGlkKVxyXG4gICAgICAgICAgICAgIGlmKHJlcy5lcnJjb2RlID09IDIwMCl7XHJcbiAgICAgICAgICAgICAgICAgIFRpcHMudG9hc3QoXCLpooblj5bmiJDlip/vvIFcIiwgcmVzID0+IHt9LCAnbm9uZScpXHJcbiAgICAgICAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgICAgICAgICAgIFRpcHMudG9hc3QoXCLor7fnqI3lkI7ph43or5VcIiwgcmVzID0+IHt9LCAnbm9uZScpXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIHRoaXMubG9hZCgpXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHRvdXNlKCl7XHJcbiAgICAgICAgICAgICAgICB3ZXB5LnN3aXRjaFRhYih7IHVybDogJy9wYWdlcy9ob21lL2luZGV4JyB9KTtcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgdG9teSgpe1xyXG4gICAgICAgICAgICAgICAgV3hVdGlscy5iYWNrT3JOYXZpZ2F0ZSgnL2NvdXBvbnMvcGFnZXMvbXlDb3Vwb25zJykgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbiJdfQ==