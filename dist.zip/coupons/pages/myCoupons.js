"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

var _WxUtils = require('./../../utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

var _coupon = require('./../api/coupon.js');

var _coupon2 = _interopRequireDefault(_coupon);

var _utils = require('./../../store/utils.js');

var _utils2 = _interopRequireDefault(_utils);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Cpt2My = function (_wepy$page) {
    _inherits(Cpt2My, _wepy$page);

    function Cpt2My() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Cpt2My);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Cpt2My.__proto__ || Object.getPrototypeOf(Cpt2My)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
            navigationBarTitleText: "优惠券"
        }, _this.data = {
            TabCur: '1',
            navs: [{
                name: '未使用',
                id: '1'
            }, {
                name: '已使用',
                id: '2'
            }, {
                name: '已过期',
                id: '3'
            }],
            coupons: [],
            isloading: true,
            bg_img: {
                cou_bg_1: 'https://images.kuan1.cn/kuan1/upload/image/20201227/20201227141029_82067.png',
                cou_bg_2: 'https://images.kuan1.cn/kuan1/upload/image/20201227/20201227141048_58392.png',
                cou_bg_3: 'https://images.kuan1.cn/kuan1/upload/image/20201227/20201227141113_92973.png'
            }
        }, _this.components = {}, _this.methods = {
            tabSelect: function tabSelect(e) {
                this.TabCur = e.currentTarget.dataset.id;
                this.coupons = [];
                this.load();
            },
            todetail: function todetail(e) {
                _wepy2.default.navigateTo({
                    url: "./cousDetaile?coupon_code=" + e.coupon_id + "&favor_type=" + e.favor_type
                });
            },
            touse: function touse() {
                _wepy2.default.switchTab({
                    url: '/pages/home/index'
                });
            },
            tomy: function tomy() {
                _WxUtils2.default.backOrNavigate('/coupons/pages/cangets');
            }
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(Cpt2My, [{
        key: "onLoad",
        value: function () {
            var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
                return regeneratorRuntime.wrap(function _callee$(_context) {
                    while (1) {
                        switch (_context.prev = _context.next) {
                            case 0:
                                _context.next = 2;
                                return _auth2.default.login();

                            case 2:
                                _context.next = 4;
                                return this.load();

                            case 4:
                            case "end":
                                return _context.stop();
                        }
                    }
                }, _callee, this);
            }));

            function onLoad() {
                return _ref2.apply(this, arguments);
            }

            return onLoad;
        }()
    }, {
        key: "load",
        value: function () {
            var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
                var res;
                return regeneratorRuntime.wrap(function _callee2$(_context2) {
                    while (1) {
                        switch (_context2.prev = _context2.next) {
                            case 0:
                                this.isloading = true;
                                _context2.next = 3;
                                return _coupon2.default.memberCoups(this.TabCur);

                            case 3:
                                res = _context2.sent;

                                if (res.errcode == 200) {
                                    this.coupons = res.data.couponUsers;
                                    this.isloading = false;
                                }
                                this.$apply();

                            case 6:
                            case "end":
                                return _context2.stop();
                        }
                    }
                }, _callee2, this);
            }));

            function load() {
                return _ref3.apply(this, arguments);
            }

            return load;
        }()
    }]);

    return Cpt2My;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Cpt2My , 'coupons/pages/myCoupons'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm15Q291cG9ucy5qcyJdLCJuYW1lcyI6WyJDcHQyTXkiLCJjb25maWciLCJuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0IiwiZGF0YSIsIlRhYkN1ciIsIm5hdnMiLCJuYW1lIiwiaWQiLCJjb3Vwb25zIiwiaXNsb2FkaW5nIiwiYmdfaW1nIiwiY291X2JnXzEiLCJjb3VfYmdfMiIsImNvdV9iZ18zIiwiY29tcG9uZW50cyIsIm1ldGhvZHMiLCJ0YWJTZWxlY3QiLCJlIiwiY3VycmVudFRhcmdldCIsImRhdGFzZXQiLCJsb2FkIiwidG9kZXRhaWwiLCJ3ZXB5IiwibmF2aWdhdGVUbyIsInVybCIsImNvdXBvbl9pZCIsImZhdm9yX3R5cGUiLCJ0b3VzZSIsInN3aXRjaFRhYiIsInRvbXkiLCJXeFV0aWxzIiwiYmFja09yTmF2aWdhdGUiLCJBdXRoIiwibG9naW4iLCJjb3Vwb24iLCJtZW1iZXJDb3VwcyIsInJlcyIsImVycmNvZGUiLCJjb3Vwb25Vc2VycyIsIiRhcHBseSIsInBhZ2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUNJOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7Ozs7Ozs7Ozs7Ozs7SUFDcUJBLE07Ozs7Ozs7Ozs7Ozs7OzBMQUNqQkMsTSxHQUFTO0FBQ0xDLG9DQUF3QjtBQURuQixTLFFBR1RDLEksR0FBTztBQUNIQyxvQkFBUSxHQURMO0FBRUhDLGtCQUFNLENBQUM7QUFDSEMsc0JBQU0sS0FESDtBQUVIQyxvQkFBSTtBQUZELGFBQUQsRUFHSDtBQUNDRCxzQkFBTSxLQURQO0FBRUNDLG9CQUFJO0FBRkwsYUFIRyxFQU1IO0FBQ0NELHNCQUFNLEtBRFA7QUFFQ0Msb0JBQUk7QUFGTCxhQU5HLENBRkg7QUFZSEMscUJBQVMsRUFaTjtBQWFIQyx1QkFBVyxJQWJSO0FBY0hDLG9CQUFRO0FBQ0pDLDBCQUFVLDhFQUROO0FBRUpDLDBCQUFVLDhFQUZOO0FBR0pDLDBCQUFVO0FBSE47QUFkTCxTLFFBb0JQQyxVLEdBQWEsRSxRQWNiQyxPLEdBQVU7QUFDTkMscUJBRE0scUJBQ0lDLENBREosRUFDTztBQUNULHFCQUFLYixNQUFMLEdBQWNhLEVBQUVDLGFBQUYsQ0FBZ0JDLE9BQWhCLENBQXdCWixFQUF0QztBQUNBLHFCQUFLQyxPQUFMLEdBQWUsRUFBZjtBQUNBLHFCQUFLWSxJQUFMO0FBQ0gsYUFMSztBQU1OQyxvQkFOTSxvQkFNR0osQ0FOSCxFQU1NO0FBQ1JLLCtCQUFLQyxVQUFMLENBQWdCO0FBQ1pDLHdEQUFrQ1AsRUFBRVEsU0FBcEMsb0JBQTREUixFQUFFUztBQURsRCxpQkFBaEI7QUFHSCxhQVZLO0FBV05DLGlCQVhNLG1CQVdFO0FBQ0pMLCtCQUFLTSxTQUFMLENBQWU7QUFDWEoseUJBQUs7QUFETSxpQkFBZjtBQUdILGFBZks7QUFnQk5LLGdCQWhCTSxrQkFnQkM7QUFDSEMsa0NBQVFDLGNBQVIsQ0FBdUIsd0JBQXZCO0FBQ0g7QUFsQkssUzs7Ozs7Ozs7Ozs7O3VDQVpBQyxlQUFLQyxLQUFMLEU7Ozs7dUNBQ0EsS0FBS2IsSUFBTCxFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBR04scUNBQUtYLFNBQUwsR0FBaUIsSUFBakI7O3VDQUNnQnlCLGlCQUFPQyxXQUFQLENBQW1CLEtBQUsvQixNQUF4QixDOzs7QUFBWmdDLG1DOztBQUNKLG9DQUFJQSxJQUFJQyxPQUFKLElBQWUsR0FBbkIsRUFBd0I7QUFDcEIseUNBQUs3QixPQUFMLEdBQWU0QixJQUFJakMsSUFBSixDQUFTbUMsV0FBeEI7QUFDQSx5Q0FBSzdCLFNBQUwsR0FBaUIsS0FBakI7QUFDSDtBQUNELHFDQUFLOEIsTUFBTDs7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQXBDNEJqQixlQUFLa0IsSTs7a0JBQXBCeEMsTSIsImZpbGUiOiJteUNvdXBvbnMuanMiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuICAgIGltcG9ydCB3ZXB5IGZyb20gXCJ3ZXB5XCI7XHJcbiAgICBpbXBvcnQgVGlwcyBmcm9tIFwiQC91dGlscy9UaXBzXCI7XHJcbiAgICBpbXBvcnQgQXV0aCBmcm9tIFwiQC9hcGkvYXV0aFwiO1xyXG4gICAgaW1wb3J0IFd4VXRpbHMgZnJvbSBcIkAvdXRpbHMvV3hVdGlsc1wiO1xyXG4gICAgaW1wb3J0IGNvdXBvbiBmcm9tIFwiLi4vYXBpL2NvdXBvblwiO1xyXG4gICAgaW1wb3J0IHN0b3JlIGZyb20gXCJAL3N0b3JlL3V0aWxzXCI7XHJcbiAgICBleHBvcnQgZGVmYXVsdCBjbGFzcyBDcHQyTXkgZXh0ZW5kcyB3ZXB5LnBhZ2Uge1xyXG4gICAgICAgIGNvbmZpZyA9IHtcclxuICAgICAgICAgICAgbmF2aWdhdGlvbkJhclRpdGxlVGV4dDogXCLkvJjmg6DliLhcIlxyXG4gICAgICAgIH07XHJcbiAgICAgICAgZGF0YSA9IHtcclxuICAgICAgICAgICAgVGFiQ3VyOiAnMScsXHJcbiAgICAgICAgICAgIG5hdnM6IFt7XHJcbiAgICAgICAgICAgICAgICBuYW1lOiAn5pyq5L2/55SoJyxcclxuICAgICAgICAgICAgICAgIGlkOiAnMSdcclxuICAgICAgICAgICAgfSwge1xyXG4gICAgICAgICAgICAgICAgbmFtZTogJ+W3suS9v+eUqCcsXHJcbiAgICAgICAgICAgICAgICBpZDogJzInXHJcbiAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgIG5hbWU6ICflt7Lov4fmnJ8nLFxyXG4gICAgICAgICAgICAgICAgaWQ6ICczJ1xyXG4gICAgICAgICAgICB9XSxcclxuICAgICAgICAgICAgY291cG9uczogW10sXHJcbiAgICAgICAgICAgIGlzbG9hZGluZzogdHJ1ZSxcclxuICAgICAgICAgICAgYmdfaW1nOiB7XHJcbiAgICAgICAgICAgICAgICBjb3VfYmdfMTogJ2h0dHBzOi8vaW1hZ2VzLmt1YW4xLmNuL2t1YW4xL3VwbG9hZC9pbWFnZS8yMDIwMTIyNy8yMDIwMTIyNzE0MTAyOV84MjA2Ny5wbmcnLFxyXG4gICAgICAgICAgICAgICAgY291X2JnXzI6ICdodHRwczovL2ltYWdlcy5rdWFuMS5jbi9rdWFuMS91cGxvYWQvaW1hZ2UvMjAyMDEyMjcvMjAyMDEyMjcxNDEwNDhfNTgzOTIucG5nJyxcclxuICAgICAgICAgICAgICAgIGNvdV9iZ18zOiAnaHR0cHM6Ly9pbWFnZXMua3VhbjEuY24va3VhbjEvdXBsb2FkL2ltYWdlLzIwMjAxMjI3LzIwMjAxMjI3MTQxMTEzXzkyOTczLnBuZycsXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgY29tcG9uZW50cyA9IHt9XHJcbiAgICAgICAgYXN5bmMgb25Mb2FkKCkge1xyXG4gICAgICAgICAgICBhd2FpdCBBdXRoLmxvZ2luKClcclxuICAgICAgICAgICAgYXdhaXQgdGhpcy5sb2FkKClcclxuICAgICAgICB9XHJcbiAgICAgICAgYXN5bmMgbG9hZCgpIHtcclxuICAgICAgICAgICAgdGhpcy5pc2xvYWRpbmcgPSB0cnVlXHJcbiAgICAgICAgICAgIGxldCByZXMgPSBhd2FpdCBjb3Vwb24ubWVtYmVyQ291cHModGhpcy5UYWJDdXIpXHJcbiAgICAgICAgICAgIGlmIChyZXMuZXJyY29kZSA9PSAyMDApIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuY291cG9ucyA9IHJlcy5kYXRhLmNvdXBvblVzZXJzXHJcbiAgICAgICAgICAgICAgICB0aGlzLmlzbG9hZGluZyA9IGZhbHNlXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgICAgIH1cclxuICAgICAgICBtZXRob2RzID0ge1xyXG4gICAgICAgICAgICB0YWJTZWxlY3QoZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5UYWJDdXIgPSBlLmN1cnJlbnRUYXJnZXQuZGF0YXNldC5pZFxyXG4gICAgICAgICAgICAgICAgdGhpcy5jb3Vwb25zID0gW11cclxuICAgICAgICAgICAgICAgIHRoaXMubG9hZCgpXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHRvZGV0YWlsKGUpIHtcclxuICAgICAgICAgICAgICAgIHdlcHkubmF2aWdhdGVUbyh7XHJcbiAgICAgICAgICAgICAgICAgICAgdXJsOiBgLi9jb3VzRGV0YWlsZT9jb3Vwb25fY29kZT0ke2UuY291cG9uX2lkfSZmYXZvcl90eXBlPSR7ZS5mYXZvcl90eXBlfWBcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB0b3VzZSgpIHtcclxuICAgICAgICAgICAgICAgIHdlcHkuc3dpdGNoVGFiKHtcclxuICAgICAgICAgICAgICAgICAgICB1cmw6ICcvcGFnZXMvaG9tZS9pbmRleCdcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB0b215KCkge1xyXG4gICAgICAgICAgICAgICAgV3hVdGlscy5iYWNrT3JOYXZpZ2F0ZSgnL2NvdXBvbnMvcGFnZXMvY2FuZ2V0cycpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbiJdfQ==