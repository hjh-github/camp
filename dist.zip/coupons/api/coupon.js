'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _base2 = require('./../../api/base.js');

var _base3 = _interopRequireDefault(_base2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var config = function (_base) {
    _inherits(config, _base);

    function config() {
        _classCallCheck(this, config);

        return _possibleConstructorReturn(this, (config.__proto__ || Object.getPrototypeOf(config)).apply(this, arguments));
    }

    _createClass(config, null, [{
        key: 'getcoupons',

        // 可以领取的列表
        value: function getcoupons(opt) {
            var url = this.baseUrl + '/coupon/list';
            var params = {
                sessionId: _wepy2.default.$instance.globalData.sessionId
            };
            return this.post(url, params, true).then(function (res) {
                return res;
            });
        }
        // 领取优惠券

    }, {
        key: 'reveivecoupon',
        value: function reveivecoupon(couponId) {
            var url = this.baseUrl + '/member/coupon/reveivecoupon';
            var params = {
                sessionId: _wepy2.default.$instance.globalData.sessionId,
                couponId: couponId
            };
            return this.post(url, params, true, true).then(function (res) {
                return res;
            });
        }
        // 我的优惠券列表

    }, {
        key: 'memberCoups',
        value: function memberCoups(state) {
            var url = this.baseUrl + '/member/coupon/list';
            var params = {
                sessionId: _wepy2.default.$instance.globalData.sessionId,
                state: state
            };
            return this.post(url, params, true, true).then(function (res) {
                return res;
            });
        }
    }]);

    return config;
}(_base3.default);

exports.default = config;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvdXBvbi5qcyJdLCJuYW1lcyI6WyJjb25maWciLCJvcHQiLCJ1cmwiLCJiYXNlVXJsIiwicGFyYW1zIiwic2Vzc2lvbklkIiwid2VweSIsIiRpbnN0YW5jZSIsImdsb2JhbERhdGEiLCJwb3N0IiwidGhlbiIsInJlcyIsImNvdXBvbklkIiwic3RhdGUiLCJiYXNlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBQTs7OztBQUNBOzs7Ozs7Ozs7Ozs7SUFFcUJBLE07Ozs7Ozs7Ozs7OztBQUNqQjttQ0FDbUJDLEcsRUFBSztBQUNwQixnQkFBSUMsTUFBUyxLQUFLQyxPQUFkLGlCQUFKO0FBQ0EsZ0JBQUlDLFNBQVM7QUFDVEMsMkJBQVdDLGVBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQkg7QUFENUIsYUFBYjtBQUdBLG1CQUFPLEtBQUtJLElBQUwsQ0FBVVAsR0FBVixFQUFlRSxNQUFmLEVBQXVCLElBQXZCLEVBQTZCTSxJQUE3QixDQUFrQyxlQUFPO0FBQzVDLHVCQUFPQyxHQUFQO0FBQ0gsYUFGTSxDQUFQO0FBR0g7QUFDRDs7OztzQ0FDc0JDLFEsRUFBVTtBQUM1QixnQkFBSVYsTUFBUyxLQUFLQyxPQUFkLGlDQUFKO0FBQ0EsZ0JBQUlDLFNBQVM7QUFDVEMsMkJBQVdDLGVBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQkgsU0FENUI7QUFFVE87QUFGUyxhQUFiO0FBSUEsbUJBQU8sS0FBS0gsSUFBTCxDQUFVUCxHQUFWLEVBQWVFLE1BQWYsRUFBdUIsSUFBdkIsRUFBNEIsSUFBNUIsRUFBa0NNLElBQWxDLENBQXVDLGVBQU87QUFDakQsdUJBQU9DLEdBQVA7QUFDSCxhQUZNLENBQVA7QUFHSDtBQUNBOzs7O29DQUNvQkUsSyxFQUFPO0FBQ3hCLGdCQUFJWCxNQUFTLEtBQUtDLE9BQWQsd0JBQUo7QUFDQSxnQkFBSUMsU0FBUztBQUNUQywyQkFBV0MsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCSCxTQUQ1QjtBQUVUUTtBQUZTLGFBQWI7QUFJQSxtQkFBTyxLQUFLSixJQUFMLENBQVVQLEdBQVYsRUFBZUUsTUFBZixFQUF1QixJQUF2QixFQUE0QixJQUE1QixFQUFrQ00sSUFBbEMsQ0FBdUMsZUFBTztBQUNqRCx1QkFBT0MsR0FBUDtBQUNILGFBRk0sQ0FBUDtBQUdIOzs7O0VBaEMrQkcsYzs7a0JBQWZkLE0iLCJmaWxlIjoiY291cG9uLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHdlcHkgZnJvbSAnd2VweSdcclxuaW1wb3J0IGJhc2UgZnJvbSAnQC9hcGkvYmFzZSdcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIGNvbmZpZyBleHRlbmRzIGJhc2Uge1xyXG4gICAgLy8g5Y+v5Lul6aKG5Y+W55qE5YiX6KGoXHJcbiAgICBzdGF0aWMgZ2V0Y291cG9ucyAob3B0KSB7XHJcbiAgICAgICAgbGV0IHVybCA9IGAke3RoaXMuYmFzZVVybH0vY291cG9uL2xpc3RgO1xyXG4gICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgIHNlc3Npb25JZDogd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5zZXNzaW9uSWQsXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB0aGlzLnBvc3QodXJsLCBwYXJhbXMsIHRydWUpLnRoZW4ocmVzID0+IHtcclxuICAgICAgICAgICAgcmV0dXJuIHJlcztcclxuICAgICAgICB9KVxyXG4gICAgfVxyXG4gICAgLy8g6aKG5Y+W5LyY5oOg5Yi4XHJcbiAgICBzdGF0aWMgcmV2ZWl2ZWNvdXBvbiAoY291cG9uSWQpIHtcclxuICAgICAgICBsZXQgdXJsID0gYCR7dGhpcy5iYXNlVXJsfS9tZW1iZXIvY291cG9uL3JldmVpdmVjb3Vwb25gO1xyXG4gICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgIHNlc3Npb25JZDogd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5zZXNzaW9uSWQsXHJcbiAgICAgICAgICAgIGNvdXBvbklkXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB0aGlzLnBvc3QodXJsLCBwYXJhbXMsIHRydWUsdHJ1ZSkudGhlbihyZXMgPT4ge1xyXG4gICAgICAgICAgICByZXR1cm4gcmVzO1xyXG4gICAgICAgIH0pXHJcbiAgICB9XHJcbiAgICAgLy8g5oiR55qE5LyY5oOg5Yi45YiX6KGoXHJcbiAgICAgc3RhdGljIG1lbWJlckNvdXBzIChzdGF0ZSkge1xyXG4gICAgICAgIGxldCB1cmwgPSBgJHt0aGlzLmJhc2VVcmx9L21lbWJlci9jb3Vwb24vbGlzdGA7XHJcbiAgICAgICAgbGV0IHBhcmFtcyA9IHtcclxuICAgICAgICAgICAgc2Vzc2lvbklkOiB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnNlc3Npb25JZCxcclxuICAgICAgICAgICAgc3RhdGVcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHRoaXMucG9zdCh1cmwsIHBhcmFtcywgdHJ1ZSx0cnVlKS50aGVuKHJlcyA9PiB7XHJcbiAgICAgICAgICAgIHJldHVybiByZXM7XHJcbiAgICAgICAgfSlcclxuICAgIH1cclxufSJdfQ==