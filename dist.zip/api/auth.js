'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _base2 = require('./base.js');

var _base3 = _interopRequireDefault(_base2);

var _wepy = require('./../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var auth = function (_base) {
  _inherits(auth, _base);

  function auth() {
    _classCallCheck(this, auth);

    return _possibleConstructorReturn(this, (auth.__proto__ || Object.getPrototypeOf(auth)).apply(this, arguments));
  }

  _createClass(auth, null, [{
    key: 'login',

    // /**
    //  * 一键登录
    //  */
    value: function () {
      var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
        var _this2 = this;

        var self;
        return regeneratorRuntime.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                self = this;

                if (_wepy2.default.$instance.globalData.sessionId) {
                  _context3.next = 6;
                  break;
                }

                console.log('sessionId都没有，肯定要重新登录遍的啦');
                _context3.next = 5;
                return self.toLogin();

              case 5:
                return _context3.abrupt('return', false);

              case 6:
                _context3.next = 8;
                return _wepy2.default.checkSession().then(function () {
                  var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(res) {
                    return regeneratorRuntime.wrap(function _callee$(_context) {
                      while (1) {
                        switch (_context.prev = _context.next) {
                          case 0:
                            console.log('还在登录状态下');
                            // await self.toLogin()

                          case 1:
                          case 'end':
                            return _context.stop();
                        }
                      }
                    }, _callee, _this2);
                  }));

                  return function (_x) {
                    return _ref2.apply(this, arguments);
                  };
                }()).catch(function () {
                  var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(err) {
                    return regeneratorRuntime.wrap(function _callee2$(_context2) {
                      while (1) {
                        switch (_context2.prev = _context2.next) {
                          case 0:
                            console.log('重新登录');
                            _context2.next = 3;
                            return self.toLogin();

                          case 3:
                          case 'end':
                            return _context2.stop();
                        }
                      }
                    }, _callee2, _this2);
                  }));

                  return function (_x2) {
                    return _ref3.apply(this, arguments);
                  };
                }());

              case 8:
              case 'end':
                return _context3.stop();
            }
          }
        }, _callee3, this);
      }));

      function login() {
        return _ref.apply(this, arguments);
      }

      return login;
    }()

    // 解析手机号

  }, {
    key: 'getPhone',
    value: function () {
      var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4(codes) {
        var params, url;
        return regeneratorRuntime.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                _context4.next = 2;
                return this.login();

              case 2:
                params = {
                  encryptedData: codes.encryptedData,
                  iv: codes.iv,
                  sessionId: _wepy2.default.$instance.globalData.sessionId
                };
                url = this.baseUrl + '/member/getPhone.html';
                _context4.next = 6;
                return this.post(url, params, false);

              case 6:
                return _context4.abrupt('return', _context4.sent);

              case 7:
              case 'end':
                return _context4.stop();
            }
          }
        }, _callee4, this);
      }));

      function getPhone(_x3) {
        return _ref4.apply(this, arguments);
      }

      return getPhone;
    }()
    // 解析用户信息

  }, {
    key: 'getUserinfo',
    value: function () {
      var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5(codes) {
        var params, url;
        return regeneratorRuntime.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                _context5.next = 2;
                return this.login();

              case 2:
                params = {
                  encryptedData: codes.encryptedData,
                  iv: codes.iv,
                  sessionId: _wepy2.default.$instance.globalData.sessionId
                };
                url = this.baseUrl + '/member/getUserinfo.html';
                _context5.next = 6;
                return this.post(url, params, false);

              case 6:
                return _context5.abrupt('return', _context5.sent);

              case 7:
              case 'end':
                return _context5.stop();
            }
          }
        }, _callee5, this);
      }));

      function getUserinfo(_x4) {
        return _ref5.apply(this, arguments);
      }

      return getUserinfo;
    }()
    // 获取验证码

  }, {
    key: 'sendCode',
    value: function () {
      var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee6(phone) {
        var url;
        return regeneratorRuntime.wrap(function _callee6$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                url = this.baseUrl + '/seller/web/index.php?r=init/send';
                return _context6.abrupt('return', this.post(url, { phone: phone }, true).then(function (res) {
                  return res;
                }));

              case 2:
              case 'end':
                return _context6.stop();
            }
          }
        }, _callee6, this);
      }));

      function sendCode(_x5) {
        return _ref6.apply(this, arguments);
      }

      return sendCode;
    }()
    // 登录

  }, {
    key: 'toLogin',
    value: function () {
      var _ref7 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee7() {
        var shopCode, _ref8, code, params, url, _code;

        return regeneratorRuntime.wrap(function _callee7$(_context7) {
          while (1) {
            switch (_context7.prev = _context7.next) {
              case 0:
                shopCode = _wepy2.default.$instance.globalData.appCode;
                _context7.next = 3;
                return _wepy2.default.login();

              case 3:
                _ref8 = _context7.sent;
                code = _ref8.code;

                _wepy2.default.$instance.globalData.code = code;
                params = {
                  appid: shopCode,
                  code: code
                };
                url = this.baseUrl + '/wxlogin';
                _context7.next = 10;
                return this.post(url, params, true, true);

              case 10:
                _code = _context7.sent;

                console.log(code);
                _wepy2.default.setStorageSync('mobile', _code.data.mobile);
                _wepy2.default.setStorageSync('isFans', _code.data.isFans);
                // wepy.setStorageSync('sessionId',_code.data.sessionId);
                _wepy2.default.$instance.globalData.sessionId = _code.data.sessionId;

              case 15:
              case 'end':
                return _context7.stop();
            }
          }
        }, _callee7, this);
      }));

      function toLogin() {
        return _ref7.apply(this, arguments);
      }

      return toLogin;
    }()

    /**
       * 检查是否存在权限制
       */

  }, {
    key: 'hasConfig',
    value: function hasConfig(key) {
      var value = this.getConfig(key);
      return value != null && value != '';
    }
    /**
     * 读取权限值
     */

  }, {
    key: 'getConfig',
    value: function getConfig(key) {
      return _wepy2.default.$instance.globalData.auth[key];
    }
  }, {
    key: 'getStorage',
    value: function getStorage(key) {
      return new Promise(function (resolve, resject) {
        wx.getStorage({
          key: key,
          success: function success(res) {
            resolve(res);
          }
        });
      });
    }
    /**
    * 设置权限值
    */

  }, {
    key: 'setConfig',
    value: function () {
      var _ref9 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee8(key, value) {
        return regeneratorRuntime.wrap(function _callee8$(_context8) {
          while (1) {
            switch (_context8.prev = _context8.next) {
              case 0:
                _context8.next = 2;
                return _wepy2.default.setStorage({ key: key, data: value });

              case 2:
                _wepy2.default.$instance.globalData.auth[key] = value;

              case 3:
              case 'end':
                return _context8.stop();
            }
          }
        }, _callee8, this);
      }));

      function setConfig(_x6, _x7) {
        return _ref9.apply(this, arguments);
      }

      return setConfig;
    }()

    /**
     * 删除权限值
     */

  }, {
    key: 'removeConfig',
    value: function () {
      var _ref10 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee9(key) {
        return regeneratorRuntime.wrap(function _callee9$(_context9) {
          while (1) {
            switch (_context9.prev = _context9.next) {
              case 0:
                _wepy2.default.$instance.globalData.auth[key] = null;
                _context9.next = 3;
                return _wepy2.default.removeStorage({ key: key });

              case 3:
              case 'end':
                return _context9.stop();
            }
          }
        }, _callee9, this);
      }));

      function removeConfig(_x8) {
        return _ref10.apply(this, arguments);
      }

      return removeConfig;
    }()
  }]);

  return auth;
}(_base3.default);

exports.default = auth;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImF1dGguanMiXSwibmFtZXMiOlsiYXV0aCIsInNlbGYiLCJ3ZXB5IiwiJGluc3RhbmNlIiwiZ2xvYmFsRGF0YSIsInNlc3Npb25JZCIsImNvbnNvbGUiLCJsb2ciLCJ0b0xvZ2luIiwiY2hlY2tTZXNzaW9uIiwidGhlbiIsInJlcyIsImNhdGNoIiwiZXJyIiwiY29kZXMiLCJsb2dpbiIsInBhcmFtcyIsImVuY3J5cHRlZERhdGEiLCJpdiIsInVybCIsImJhc2VVcmwiLCJwb3N0IiwicGhvbmUiLCJzaG9wQ29kZSIsImFwcENvZGUiLCJjb2RlIiwiYXBwaWQiLCJfY29kZSIsInNldFN0b3JhZ2VTeW5jIiwiZGF0YSIsIm1vYmlsZSIsImlzRmFucyIsImtleSIsInZhbHVlIiwiZ2V0Q29uZmlnIiwiUHJvbWlzZSIsInJlc29sdmUiLCJyZXNqZWN0Iiwid3giLCJnZXRTdG9yYWdlIiwic3VjY2VzcyIsInNldFN0b3JhZ2UiLCJyZW1vdmVTdG9yYWdlIiwiYmFzZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQUE7Ozs7QUFDQTs7Ozs7Ozs7Ozs7Ozs7SUFFcUJBLEk7Ozs7Ozs7Ozs7OztBQUNuQjtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7QUFFTUMsb0IsR0FBTyxJOztvQkFDUEMsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCQyxTOzs7OztBQUM1QkMsd0JBQVFDLEdBQVIsQ0FBWSx5QkFBWjs7dUJBQ01OLEtBQUtPLE9BQUwsRTs7O2tEQUNDLEs7Ozs7dUJBRUpOLGVBQUtPLFlBQUwsR0FBb0JDLElBQXBCO0FBQUEsc0ZBQXlCLGlCQUFNQyxHQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDNUJMLG9DQUFRQyxHQUFSLENBQVksU0FBWjtBQUNBOztBQUY0QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBekI7O0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0ZLLEtBSEU7QUFBQSxzRkFHSSxrQkFBTUMsR0FBTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ1BQLG9DQUFRQyxHQUFSLENBQVksTUFBWjtBQURPO0FBQUEsbUNBRUROLEtBQUtPLE9BQUwsRUFGQzs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFISjs7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFxQlA7Ozs7OzRGQUNzQk0sSzs7Ozs7Ozt1QkFDZCxLQUFLQyxLQUFMLEU7OztBQUNGQyxzQixHQUFTO0FBQ1hDLGlDQUFjSCxNQUFNRyxhQURUO0FBRVhDLHNCQUFHSixNQUFNSSxFQUZFO0FBR1hiLDZCQUFVSCxlQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJDO0FBSHpCLGlCO0FBS1BjLG1CLEdBQVMsS0FBS0MsTzs7dUJBQ1AsS0FBS0MsSUFBTCxDQUFVRixHQUFWLEVBQWVILE1BQWYsRUFBdUIsS0FBdkIsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUVmOzs7Ozs0RkFDeUJGLEs7Ozs7Ozs7dUJBQ2pCLEtBQUtDLEtBQUwsRTs7O0FBQ0ZDLHNCLEdBQVM7QUFDWEMsaUNBQWNILE1BQU1HLGFBRFQ7QUFFWEMsc0JBQUdKLE1BQU1JLEVBRkU7QUFHWGIsNkJBQVVILGVBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQkM7QUFIekIsaUI7QUFLUGMsbUIsR0FBUyxLQUFLQyxPOzt1QkFDUCxLQUFLQyxJQUFMLENBQVVGLEdBQVYsRUFBZUgsTUFBZixFQUF1QixLQUF2QixDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBRWY7Ozs7OzRGQUNzQk0sSzs7Ozs7O0FBQ2RILG1CLEdBQVMsS0FBS0MsTztrREFDYixLQUFLQyxJQUFMLENBQVVGLEdBQVYsRUFBZSxFQUFFRyxZQUFGLEVBQWYsRUFBMEIsSUFBMUIsRUFBZ0NaLElBQWhDLENBQXFDLGVBQU87QUFDakQseUJBQU9DLEdBQVA7QUFDRCxpQkFGTSxDOzs7Ozs7Ozs7Ozs7Ozs7O0FBSVQ7Ozs7Ozs7Ozs7OztBQUVRWSx3QixHQUFXckIsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCb0IsTzs7dUJBQ3hCdEIsZUFBS2EsS0FBTCxFOzs7O0FBQWRVLG9CLFNBQUFBLEk7O0FBQ0x2QiwrQkFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCcUIsSUFBMUIsR0FBaUNBLElBQWpDO0FBQ0lULHNCLEdBQVM7QUFDWFUseUJBQU9ILFFBREk7QUFFWEU7QUFGVyxpQjtBQUlQTixtQixHQUFTLEtBQUtDLE87O3VCQUNGLEtBQUtDLElBQUwsQ0FBVUYsR0FBVixFQUFlSCxNQUFmLEVBQXVCLElBQXZCLEVBQTZCLElBQTdCLEM7OztBQUFkVyxxQjs7QUFDSnJCLHdCQUFRQyxHQUFSLENBQVlrQixJQUFaO0FBQ0F2QiwrQkFBSzBCLGNBQUwsQ0FBb0IsUUFBcEIsRUFBNkJELE1BQU1FLElBQU4sQ0FBV0MsTUFBeEM7QUFDQTVCLCtCQUFLMEIsY0FBTCxDQUFvQixRQUFwQixFQUE2QkQsTUFBTUUsSUFBTixDQUFXRSxNQUF4QztBQUNBO0FBQ0E3QiwrQkFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCQyxTQUExQixHQUFzQ3NCLE1BQU1FLElBQU4sQ0FBV3hCLFNBQWpEOzs7Ozs7Ozs7Ozs7Ozs7OztBQUdGOzs7Ozs7OEJBR2lCMkIsRyxFQUFLO0FBQ3BCLFVBQU1DLFFBQVEsS0FBS0MsU0FBTCxDQUFlRixHQUFmLENBQWQ7QUFDQSxhQUFPQyxTQUFTLElBQVQsSUFBaUJBLFNBQVMsRUFBakM7QUFDRDtBQUNEOzs7Ozs7OEJBR2lCRCxHLEVBQUs7QUFDcEIsYUFBTzlCLGVBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQkosSUFBMUIsQ0FBK0JnQyxHQUEvQixDQUFQO0FBQ0Q7OzsrQkFDaUJBLEcsRUFBSztBQUNyQixhQUFPLElBQUlHLE9BQUosQ0FBWSxVQUFDQyxPQUFELEVBQVVDLE9BQVYsRUFBc0I7QUFDdkNDLFdBQUdDLFVBQUgsQ0FBYztBQUNaUCxlQUFLQSxHQURPO0FBRVpRLG1CQUFTLGlCQUFVN0IsR0FBVixFQUFlO0FBQ3RCeUIsb0JBQVF6QixHQUFSO0FBQ0Q7QUFKVyxTQUFkO0FBTUQsT0FQTSxDQUFQO0FBUUQ7QUFDRDs7Ozs7Ozs0RkFHdUJxQixHLEVBQUtDLEs7Ozs7Ozt1QkFDcEIvQixlQUFLdUMsVUFBTCxDQUFnQixFQUFFVCxLQUFLQSxHQUFQLEVBQVlILE1BQU1JLEtBQWxCLEVBQWhCLEM7OztBQUNOL0IsK0JBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQkosSUFBMUIsQ0FBK0JnQyxHQUEvQixJQUFzQ0MsS0FBdEM7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBR0Y7Ozs7Ozs7NkZBRzBCRCxHOzs7OztBQUN4QjlCLCtCQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJKLElBQTFCLENBQStCZ0MsR0FBL0IsSUFBc0MsSUFBdEM7O3VCQUNNOUIsZUFBS3dDLGFBQUwsQ0FBbUIsRUFBRVYsS0FBS0EsR0FBUCxFQUFuQixDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBbkh3QlcsYzs7a0JBQWIzQyxJIiwiZmlsZSI6ImF1dGguanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgYmFzZSBmcm9tICcuL2Jhc2UnXHJcbmltcG9ydCB3ZXB5IGZyb20gJ3dlcHknO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgYXV0aCBleHRlbmRzIGJhc2Uge1xyXG4gIC8vIC8qKlxyXG4gIC8vICAqIOS4gOmUrueZu+W9lVxyXG4gIC8vICAqL1xyXG4gIHN0YXRpYyBhc3luYyBsb2dpbigpIHtcclxuICAgIGxldCBzZWxmID0gdGhpc1xyXG4gICAgaWYoIXdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuc2Vzc2lvbklkKXtcclxuICAgICAgY29uc29sZS5sb2coJ3Nlc3Npb25JZOmDveayoeacie+8jOiCr+WumuimgemHjeaWsOeZu+W9lemBjeeahOWVpicpXHJcbiAgICAgIGF3YWl0IHNlbGYudG9Mb2dpbigpXHJcbiAgICAgIHJldHVybiBmYWxzZVxyXG4gICAgfVxyXG4gICBhd2FpdCB3ZXB5LmNoZWNrU2Vzc2lvbigpLnRoZW4oYXN5bmMgcmVzPT57XHJcbiAgICAgIGNvbnNvbGUubG9nKCfov5jlnKjnmbvlvZXnirbmgIHkuIsnKVxyXG4gICAgICAvLyBhd2FpdCBzZWxmLnRvTG9naW4oKVxyXG4gICAgfSkuY2F0Y2goYXN5bmMgZXJyPT57XHJcbiAgICAgIGNvbnNvbGUubG9nKCfph43mlrDnmbvlvZUnKVxyXG4gICAgICBhd2FpdCBzZWxmLnRvTG9naW4oKVxyXG4gICAgfSk7XHJcbiAgICBcclxuICAgIC8vIHd4LmNoZWNrU2Vzc2lvbih7XHJcbiAgICAvLyAgIHN1Y2Nlc3MocmVzKSB7XHJcbiAgICAvLyAgICAgY29uc29sZS5sb2coJ+i/mOWcqOeZu+W9leeKtuaAgeS4iycpXHJcbiAgICAvLyAgICAgcmV0dXJuXHJcbiAgICAvLyAgIH0sXHJcbiAgICAvLyAgIGZhaWw6IGFzeW5jIGZ1bmN0aW9uIChyZXMpIHtcclxuICAgIC8vICAgICBjb25zb2xlLmxvZygn6YeN5paw55m75b2VJylcclxuICAgIC8vICAgICBhd2FpdCBzZWxmLnRvTG9naW4oKVxyXG4gICAgLy8gICB9XHJcbiAgICAvLyB9KVxyXG5cclxuICB9XHJcbiAgXHJcbiAgLy8g6Kej5p6Q5omL5py65Y+3XHJcbiAgc3RhdGljIGFzeW5jIGdldFBob25lKGNvZGVzKSB7XHJcbiAgICBhd2FpdCB0aGlzLmxvZ2luKClcclxuICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgIGVuY3J5cHRlZERhdGE6Y29kZXMuZW5jcnlwdGVkRGF0YSxcclxuICAgICAgaXY6Y29kZXMuaXYsXHJcbiAgICAgIHNlc3Npb25JZDp3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnNlc3Npb25JZFxyXG4gICAgfVxyXG4gICAgY29uc3QgdXJsID0gYCR7dGhpcy5iYXNlVXJsfS9tZW1iZXIvZ2V0UGhvbmUuaHRtbGA7XHJcbiAgICByZXR1cm4gYXdhaXQgdGhpcy5wb3N0KHVybCwgcGFyYW1zLCBmYWxzZSk7XHJcbiAgfVxyXG4gIC8vIOino+aekOeUqOaIt+S/oeaBr1xyXG4gIHN0YXRpYyBhc3luYyBnZXRVc2VyaW5mbyhjb2Rlcykge1xyXG4gICAgYXdhaXQgdGhpcy5sb2dpbigpXHJcbiAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICBlbmNyeXB0ZWREYXRhOmNvZGVzLmVuY3J5cHRlZERhdGEsXHJcbiAgICAgIGl2OmNvZGVzLml2LFxyXG4gICAgICBzZXNzaW9uSWQ6d2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5zZXNzaW9uSWRcclxuICAgIH1cclxuICAgIGNvbnN0IHVybCA9IGAke3RoaXMuYmFzZVVybH0vbWVtYmVyL2dldFVzZXJpbmZvLmh0bWxgO1xyXG4gICAgcmV0dXJuIGF3YWl0IHRoaXMucG9zdCh1cmwsIHBhcmFtcywgZmFsc2UpO1xyXG4gIH1cclxuICAvLyDojrflj5bpqozor4HnoIFcclxuICBzdGF0aWMgYXN5bmMgc2VuZENvZGUocGhvbmUpIHtcclxuICAgIGNvbnN0IHVybCA9IGAke3RoaXMuYmFzZVVybH0vc2VsbGVyL3dlYi9pbmRleC5waHA/cj1pbml0L3NlbmRgO1xyXG4gICAgcmV0dXJuIHRoaXMucG9zdCh1cmwsIHsgcGhvbmUgfSwgdHJ1ZSkudGhlbihyZXMgPT4ge1xyXG4gICAgICByZXR1cm4gcmVzO1xyXG4gICAgfSlcclxuICB9XHJcbiAgLy8g55m75b2VXHJcbiAgc3RhdGljIGFzeW5jIHRvTG9naW4oKSB7XHJcbiAgICBjb25zdCBzaG9wQ29kZSA9IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuYXBwQ29kZTtcclxuICAgIGxldCB7Y29kZX0gPSBhd2FpdCB3ZXB5LmxvZ2luKClcclxuICAgIHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuY29kZSA9IGNvZGVcclxuICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgIGFwcGlkOiBzaG9wQ29kZSxcclxuICAgICAgY29kZVxyXG4gICAgfVxyXG4gICAgY29uc3QgdXJsID0gYCR7dGhpcy5iYXNlVXJsfS93eGxvZ2luYDtcclxuICAgIGxldCBfY29kZSA9IGF3YWl0IHRoaXMucG9zdCh1cmwsIHBhcmFtcywgdHJ1ZSwgdHJ1ZSk7XHJcbiAgICBjb25zb2xlLmxvZyhjb2RlKVxyXG4gICAgd2VweS5zZXRTdG9yYWdlU3luYygnbW9iaWxlJyxfY29kZS5kYXRhLm1vYmlsZSk7XHJcbiAgICB3ZXB5LnNldFN0b3JhZ2VTeW5jKCdpc0ZhbnMnLF9jb2RlLmRhdGEuaXNGYW5zKTtcclxuICAgIC8vIHdlcHkuc2V0U3RvcmFnZVN5bmMoJ3Nlc3Npb25JZCcsX2NvZGUuZGF0YS5zZXNzaW9uSWQpO1xyXG4gICAgd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5zZXNzaW9uSWQgPSBfY29kZS5kYXRhLnNlc3Npb25JZFxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICAgKiDmo4Dmn6XmmK/lkKblrZjlnKjmnYPpmZDliLZcclxuICAgICAqL1xyXG4gIHN0YXRpYyBoYXNDb25maWcoa2V5KSB7XHJcbiAgICBjb25zdCB2YWx1ZSA9IHRoaXMuZ2V0Q29uZmlnKGtleSk7XHJcbiAgICByZXR1cm4gdmFsdWUgIT0gbnVsbCAmJiB2YWx1ZSAhPSAnJztcclxuICB9XHJcbiAgLyoqXHJcbiAgICog6K+75Y+W5p2D6ZmQ5YC8XHJcbiAgICovXHJcbiAgc3RhdGljIGdldENvbmZpZyhrZXkpIHtcclxuICAgIHJldHVybiB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLmF1dGhba2V5XTtcclxuICB9XHJcbiAgc3RhdGljIGdldFN0b3JhZ2Uoa2V5KSB7XHJcbiAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlc2plY3QpID0+IHtcclxuICAgICAgd3guZ2V0U3RvcmFnZSh7XHJcbiAgICAgICAga2V5OiBrZXksXHJcbiAgICAgICAgc3VjY2VzczogZnVuY3Rpb24gKHJlcykge1xyXG4gICAgICAgICAgcmVzb2x2ZShyZXMpXHJcbiAgICAgICAgfVxyXG4gICAgICB9KVxyXG4gICAgfSlcclxuICB9XHJcbiAgLyoqXHJcbiAgKiDorr7nva7mnYPpmZDlgLxcclxuICAqL1xyXG4gIHN0YXRpYyBhc3luYyBzZXRDb25maWcoa2V5LCB2YWx1ZSkge1xyXG4gICAgYXdhaXQgd2VweS5zZXRTdG9yYWdlKHsga2V5OiBrZXksIGRhdGE6IHZhbHVlIH0pO1xyXG4gICAgd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5hdXRoW2tleV0gPSB2YWx1ZTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIOWIoOmZpOadg+mZkOWAvFxyXG4gICAqL1xyXG4gIHN0YXRpYyBhc3luYyByZW1vdmVDb25maWcoa2V5KSB7XHJcbiAgICB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLmF1dGhba2V5XSA9IG51bGw7XHJcbiAgICBhd2FpdCB3ZXB5LnJlbW92ZVN0b3JhZ2UoeyBrZXk6IGtleSB9KTtcclxuICB9XHJcblxyXG59XHJcbiJdfQ==