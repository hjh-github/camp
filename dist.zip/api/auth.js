'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _base2 = require('./base.js');

var _base3 = _interopRequireDefault(_base2);

var _wepy = require('./../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var auth = function (_base) {
  _inherits(auth, _base);

  function auth() {
    _classCallCheck(this, auth);

    return _possibleConstructorReturn(this, (auth.__proto__ || Object.getPrototypeOf(auth)).apply(this, arguments));
  }

  _createClass(auth, null, [{
    key: 'login',

    // /**
    //  * 一键登录
    //  */
    value: function () {
      var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
        var _this2 = this;

        var self;
        return regeneratorRuntime.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                self = this;

                if (_wepy2.default.$instance.globalData.sessionId) {
                  _context3.next = 6;
                  break;
                }

                console.log('sessionId都没有，肯定要重新登录遍的啦');
                _context3.next = 5;
                return self.toLogin();

              case 5:
                return _context3.abrupt('return', false);

              case 6:
                _context3.next = 8;
                return _wepy2.default.checkSession().then(function () {
                  var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(res) {
                    return regeneratorRuntime.wrap(function _callee$(_context) {
                      while (1) {
                        switch (_context.prev = _context.next) {
                          case 0:
                            console.log('还在登录状态下');
                            // await self.toLogin()

                          case 1:
                          case 'end':
                            return _context.stop();
                        }
                      }
                    }, _callee, _this2);
                  }));

                  return function (_x) {
                    return _ref2.apply(this, arguments);
                  };
                }()).catch(function () {
                  var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(err) {
                    return regeneratorRuntime.wrap(function _callee2$(_context2) {
                      while (1) {
                        switch (_context2.prev = _context2.next) {
                          case 0:
                            console.log('重新登录');
                            _context2.next = 3;
                            return self.toLogin();

                          case 3:
                          case 'end':
                            return _context2.stop();
                        }
                      }
                    }, _callee2, _this2);
                  }));

                  return function (_x2) {
                    return _ref3.apply(this, arguments);
                  };
                }());

              case 8:
              case 'end':
                return _context3.stop();
            }
          }
        }, _callee3, this);
      }));

      function login() {
        return _ref.apply(this, arguments);
      }

      return login;
    }()

    // 解析手机号

  }, {
    key: 'getPhone',
    value: function () {
      var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4(codes) {
        var params, url;
        return regeneratorRuntime.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                _context4.next = 2;
                return this.login();

              case 2:
                params = {
                  encryptedData: codes.encryptedData,
                  iv: codes.iv,
                  sessionId: _wepy2.default.$instance.globalData.sessionId
                };
                url = this.baseUrl + '/member/getPhone.html';
                _context4.next = 6;
                return this.post(url, params, false);

              case 6:
                return _context4.abrupt('return', _context4.sent);

              case 7:
              case 'end':
                return _context4.stop();
            }
          }
        }, _callee4, this);
      }));

      function getPhone(_x3) {
        return _ref4.apply(this, arguments);
      }

      return getPhone;
    }()
    // 解析用户信息

  }, {
    key: 'getUserinfo',
    value: function () {
      var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5(codes) {
        var params, url;
        return regeneratorRuntime.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                _context5.next = 2;
                return this.login();

              case 2:
                params = {
                  encryptedData: codes.encryptedData,
                  iv: codes.iv,
                  sessionId: _wepy2.default.$instance.globalData.sessionId
                };
                url = this.baseUrl + '/member/getUserinfo.html';
                _context5.next = 6;
                return this.post(url, params, false);

              case 6:
                return _context5.abrupt('return', _context5.sent);

              case 7:
              case 'end':
                return _context5.stop();
            }
          }
        }, _callee5, this);
      }));

      function getUserinfo(_x4) {
        return _ref5.apply(this, arguments);
      }

      return getUserinfo;
    }()
    // 获取验证码

  }, {
    key: 'sendCode',
    value: function () {
      var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee6(phone) {
        var url;
        return regeneratorRuntime.wrap(function _callee6$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                url = this.baseUrl + '/seller/web/index.php?r=init/send';
                return _context6.abrupt('return', this.post(url, { phone: phone }, true).then(function (res) {
                  return res;
                }));

              case 2:
              case 'end':
                return _context6.stop();
            }
          }
        }, _callee6, this);
      }));

      function sendCode(_x5) {
        return _ref6.apply(this, arguments);
      }

      return sendCode;
    }()
    // 登录

  }, {
    key: 'toLogin',
    value: function () {
      var _ref7 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee7() {
        var shopCode, _ref8, code, params, url, _code;

        return regeneratorRuntime.wrap(function _callee7$(_context7) {
          while (1) {
            switch (_context7.prev = _context7.next) {
              case 0:
                shopCode = _wepy2.default.$instance.globalData.appCode;
                _context7.next = 3;
                return _wepy2.default.login();

              case 3:
                _ref8 = _context7.sent;
                code = _ref8.code;

                _wepy2.default.$instance.globalData.code = code;
                params = {
                  appid: shopCode,
                  code: code
                  // 是否扫代理码进来
                };
                if (_wepy2.default.$instance.globalData.query.agentId) params.agentId = _wepy2.default.$instance.globalData.query.agentId;
                url = this.baseUrl + '/wxlogin';
                _context7.next = 11;
                return this.post(url, params, true, true);

              case 11:
                _code = _context7.sent;

                console.log(code);
                _wepy2.default.setStorageSync('mobile', _code.data.mobile);
                _wepy2.default.setStorageSync('isFans', _code.data.isFans);
                _wepy2.default.setStorageSync('member', _code.data.member);
                _wepy2.default.$instance.globalData.sessionId = _code.data.sessionId;

              case 17:
              case 'end':
                return _context7.stop();
            }
          }
        }, _callee7, this);
      }));

      function toLogin() {
        return _ref7.apply(this, arguments);
      }

      return toLogin;
    }()

    /**
       * 检查是否存在权限制
       */

  }, {
    key: 'hasConfig',
    value: function hasConfig(key) {
      var value = this.getConfig(key);
      return value != null && value != '';
    }
    /**
     * 读取权限值
     */

  }, {
    key: 'getConfig',
    value: function getConfig(key) {
      return _wepy2.default.$instance.globalData.auth[key];
    }
  }, {
    key: 'getStorage',
    value: function getStorage(key) {
      return new Promise(function (resolve, resject) {
        wx.getStorage({
          key: key,
          success: function success(res) {
            resolve(res);
          }
        });
      });
    }
    /**
    * 设置权限值
    */

  }, {
    key: 'setConfig',
    value: function () {
      var _ref9 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee8(key, value) {
        return regeneratorRuntime.wrap(function _callee8$(_context8) {
          while (1) {
            switch (_context8.prev = _context8.next) {
              case 0:
                _context8.next = 2;
                return _wepy2.default.setStorage({ key: key, data: value });

              case 2:
                _wepy2.default.$instance.globalData.auth[key] = value;

              case 3:
              case 'end':
                return _context8.stop();
            }
          }
        }, _callee8, this);
      }));

      function setConfig(_x6, _x7) {
        return _ref9.apply(this, arguments);
      }

      return setConfig;
    }()

    /**
     * 删除权限值
     */

  }, {
    key: 'removeConfig',
    value: function () {
      var _ref10 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee9(key) {
        return regeneratorRuntime.wrap(function _callee9$(_context9) {
          while (1) {
            switch (_context9.prev = _context9.next) {
              case 0:
                _wepy2.default.$instance.globalData.auth[key] = null;
                _context9.next = 3;
                return _wepy2.default.removeStorage({ key: key });

              case 3:
              case 'end':
                return _context9.stop();
            }
          }
        }, _callee9, this);
      }));

      function removeConfig(_x8) {
        return _ref10.apply(this, arguments);
      }

      return removeConfig;
    }()
  }]);

  return auth;
}(_base3.default);

exports.default = auth;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImF1dGguanMiXSwibmFtZXMiOlsiYXV0aCIsInNlbGYiLCJ3ZXB5IiwiJGluc3RhbmNlIiwiZ2xvYmFsRGF0YSIsInNlc3Npb25JZCIsImNvbnNvbGUiLCJsb2ciLCJ0b0xvZ2luIiwiY2hlY2tTZXNzaW9uIiwidGhlbiIsInJlcyIsImNhdGNoIiwiZXJyIiwiY29kZXMiLCJsb2dpbiIsInBhcmFtcyIsImVuY3J5cHRlZERhdGEiLCJpdiIsInVybCIsImJhc2VVcmwiLCJwb3N0IiwicGhvbmUiLCJzaG9wQ29kZSIsImFwcENvZGUiLCJjb2RlIiwiYXBwaWQiLCJxdWVyeSIsImFnZW50SWQiLCJfY29kZSIsInNldFN0b3JhZ2VTeW5jIiwiZGF0YSIsIm1vYmlsZSIsImlzRmFucyIsIm1lbWJlciIsImtleSIsInZhbHVlIiwiZ2V0Q29uZmlnIiwiUHJvbWlzZSIsInJlc29sdmUiLCJyZXNqZWN0Iiwid3giLCJnZXRTdG9yYWdlIiwic3VjY2VzcyIsInNldFN0b3JhZ2UiLCJyZW1vdmVTdG9yYWdlIiwiYmFzZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQUE7Ozs7QUFDQTs7Ozs7Ozs7Ozs7Ozs7SUFFcUJBLEk7Ozs7Ozs7Ozs7OztBQUNuQjtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7QUFFTUMsb0IsR0FBTyxJOztvQkFDUEMsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCQyxTOzs7OztBQUM1QkMsd0JBQVFDLEdBQVIsQ0FBWSx5QkFBWjs7dUJBQ01OLEtBQUtPLE9BQUwsRTs7O2tEQUNDLEs7Ozs7dUJBRUpOLGVBQUtPLFlBQUwsR0FBb0JDLElBQXBCO0FBQUEsc0ZBQXlCLGlCQUFNQyxHQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDNUJMLG9DQUFRQyxHQUFSLENBQVksU0FBWjtBQUNBOztBQUY0QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBekI7O0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0ZLLEtBSEU7QUFBQSxzRkFHSSxrQkFBTUMsR0FBTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ1BQLG9DQUFRQyxHQUFSLENBQVksTUFBWjtBQURPO0FBQUEsbUNBRUROLEtBQUtPLE9BQUwsRUFGQzs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFISjs7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFxQlA7Ozs7OzRGQUNzQk0sSzs7Ozs7Ozt1QkFDZCxLQUFLQyxLQUFMLEU7OztBQUNGQyxzQixHQUFTO0FBQ1hDLGlDQUFjSCxNQUFNRyxhQURUO0FBRVhDLHNCQUFHSixNQUFNSSxFQUZFO0FBR1hiLDZCQUFVSCxlQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJDO0FBSHpCLGlCO0FBS1BjLG1CLEdBQVMsS0FBS0MsTzs7dUJBQ1AsS0FBS0MsSUFBTCxDQUFVRixHQUFWLEVBQWVILE1BQWYsRUFBdUIsS0FBdkIsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUVmOzs7Ozs0RkFDeUJGLEs7Ozs7Ozs7dUJBQ2pCLEtBQUtDLEtBQUwsRTs7O0FBQ0ZDLHNCLEdBQVM7QUFDWEMsaUNBQWNILE1BQU1HLGFBRFQ7QUFFWEMsc0JBQUdKLE1BQU1JLEVBRkU7QUFHWGIsNkJBQVVILGVBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQkM7QUFIekIsaUI7QUFLUGMsbUIsR0FBUyxLQUFLQyxPOzt1QkFDUCxLQUFLQyxJQUFMLENBQVVGLEdBQVYsRUFBZUgsTUFBZixFQUF1QixLQUF2QixDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBRWY7Ozs7OzRGQUNzQk0sSzs7Ozs7O0FBQ2RILG1CLEdBQVMsS0FBS0MsTztrREFDYixLQUFLQyxJQUFMLENBQVVGLEdBQVYsRUFBZSxFQUFFRyxZQUFGLEVBQWYsRUFBMEIsSUFBMUIsRUFBZ0NaLElBQWhDLENBQXFDLGVBQU87QUFDakQseUJBQU9DLEdBQVA7QUFDRCxpQkFGTSxDOzs7Ozs7Ozs7Ozs7Ozs7O0FBSVQ7Ozs7Ozs7Ozs7OztBQUVRWSx3QixHQUFXckIsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCb0IsTzs7dUJBQ3hCdEIsZUFBS2EsS0FBTCxFOzs7O0FBQWRVLG9CLFNBQUFBLEk7O0FBQ0x2QiwrQkFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCcUIsSUFBMUIsR0FBaUNBLElBQWpDO0FBQ0lULHNCLEdBQVM7QUFDWFUseUJBQU9ILFFBREk7QUFFWEU7QUFHRjtBQUxhLGlCO0FBTWIsb0JBQUd2QixlQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJ1QixLQUExQixDQUFnQ0MsT0FBbkMsRUFBNENaLE9BQU9ZLE9BQVAsR0FBaUIxQixlQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJ1QixLQUExQixDQUFnQ0MsT0FBakQ7QUFDdENULG1CLEdBQVMsS0FBS0MsTzs7dUJBQ0YsS0FBS0MsSUFBTCxDQUFVRixHQUFWLEVBQWVILE1BQWYsRUFBdUIsSUFBdkIsRUFBNkIsSUFBN0IsQzs7O0FBQWRhLHFCOztBQUNKdkIsd0JBQVFDLEdBQVIsQ0FBWWtCLElBQVo7QUFDQXZCLCtCQUFLNEIsY0FBTCxDQUFvQixRQUFwQixFQUE2QkQsTUFBTUUsSUFBTixDQUFXQyxNQUF4QztBQUNBOUIsK0JBQUs0QixjQUFMLENBQW9CLFFBQXBCLEVBQTZCRCxNQUFNRSxJQUFOLENBQVdFLE1BQXhDO0FBQ0EvQiwrQkFBSzRCLGNBQUwsQ0FBb0IsUUFBcEIsRUFBNkJELE1BQU1FLElBQU4sQ0FBV0csTUFBeEM7QUFDQWhDLCtCQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJDLFNBQTFCLEdBQXNDd0IsTUFBTUUsSUFBTixDQUFXMUIsU0FBakQ7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBR0Y7Ozs7Ozs4QkFHaUI4QixHLEVBQUs7QUFDcEIsVUFBTUMsUUFBUSxLQUFLQyxTQUFMLENBQWVGLEdBQWYsQ0FBZDtBQUNBLGFBQU9DLFNBQVMsSUFBVCxJQUFpQkEsU0FBUyxFQUFqQztBQUNEO0FBQ0Q7Ozs7Ozs4QkFHaUJELEcsRUFBSztBQUNwQixhQUFPakMsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCSixJQUExQixDQUErQm1DLEdBQS9CLENBQVA7QUFDRDs7OytCQUNpQkEsRyxFQUFLO0FBQ3JCLGFBQU8sSUFBSUcsT0FBSixDQUFZLFVBQUNDLE9BQUQsRUFBVUMsT0FBVixFQUFzQjtBQUN2Q0MsV0FBR0MsVUFBSCxDQUFjO0FBQ1pQLGVBQUtBLEdBRE87QUFFWlEsbUJBQVMsaUJBQVVoQyxHQUFWLEVBQWU7QUFDdEI0QixvQkFBUTVCLEdBQVI7QUFDRDtBQUpXLFNBQWQ7QUFNRCxPQVBNLENBQVA7QUFRRDtBQUNEOzs7Ozs7OzRGQUd1QndCLEcsRUFBS0MsSzs7Ozs7O3VCQUNwQmxDLGVBQUswQyxVQUFMLENBQWdCLEVBQUVULEtBQUtBLEdBQVAsRUFBWUosTUFBTUssS0FBbEIsRUFBaEIsQzs7O0FBQ05sQywrQkFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCSixJQUExQixDQUErQm1DLEdBQS9CLElBQXNDQyxLQUF0Qzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFHRjs7Ozs7Ozs2RkFHMEJELEc7Ozs7O0FBQ3hCakMsK0JBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQkosSUFBMUIsQ0FBK0JtQyxHQUEvQixJQUFzQyxJQUF0Qzs7dUJBQ01qQyxlQUFLMkMsYUFBTCxDQUFtQixFQUFFVixLQUFLQSxHQUFQLEVBQW5CLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUF0SHdCVyxjOztrQkFBYjlDLEkiLCJmaWxlIjoiYXV0aC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBiYXNlIGZyb20gJy4vYmFzZSdcclxuaW1wb3J0IHdlcHkgZnJvbSAnd2VweSc7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBhdXRoIGV4dGVuZHMgYmFzZSB7XHJcbiAgLy8gLyoqXHJcbiAgLy8gICog5LiA6ZSu55m75b2VXHJcbiAgLy8gICovXHJcbiAgc3RhdGljIGFzeW5jIGxvZ2luKCkge1xyXG4gICAgbGV0IHNlbGYgPSB0aGlzXHJcbiAgICBpZighd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5zZXNzaW9uSWQpe1xyXG4gICAgICBjb25zb2xlLmxvZygnc2Vzc2lvbklk6YO95rKh5pyJ77yM6IKv5a6a6KaB6YeN5paw55m75b2V6YGN55qE5ZWmJylcclxuICAgICAgYXdhaXQgc2VsZi50b0xvZ2luKClcclxuICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICB9XHJcbiAgIGF3YWl0IHdlcHkuY2hlY2tTZXNzaW9uKCkudGhlbihhc3luYyByZXM9PntcclxuICAgICAgY29uc29sZS5sb2coJ+i/mOWcqOeZu+W9leeKtuaAgeS4iycpXHJcbiAgICAgIC8vIGF3YWl0IHNlbGYudG9Mb2dpbigpXHJcbiAgICB9KS5jYXRjaChhc3luYyBlcnI9PntcclxuICAgICAgY29uc29sZS5sb2coJ+mHjeaWsOeZu+W9lScpXHJcbiAgICAgIGF3YWl0IHNlbGYudG9Mb2dpbigpXHJcbiAgICB9KTtcclxuICAgIFxyXG4gICAgLy8gd3guY2hlY2tTZXNzaW9uKHtcclxuICAgIC8vICAgc3VjY2VzcyhyZXMpIHtcclxuICAgIC8vICAgICBjb25zb2xlLmxvZygn6L+Y5Zyo55m75b2V54q25oCB5LiLJylcclxuICAgIC8vICAgICByZXR1cm5cclxuICAgIC8vICAgfSxcclxuICAgIC8vICAgZmFpbDogYXN5bmMgZnVuY3Rpb24gKHJlcykge1xyXG4gICAgLy8gICAgIGNvbnNvbGUubG9nKCfph43mlrDnmbvlvZUnKVxyXG4gICAgLy8gICAgIGF3YWl0IHNlbGYudG9Mb2dpbigpXHJcbiAgICAvLyAgIH1cclxuICAgIC8vIH0pXHJcblxyXG4gIH1cclxuICBcclxuICAvLyDop6PmnpDmiYvmnLrlj7dcclxuICBzdGF0aWMgYXN5bmMgZ2V0UGhvbmUoY29kZXMpIHtcclxuICAgIGF3YWl0IHRoaXMubG9naW4oKVxyXG4gICAgbGV0IHBhcmFtcyA9IHtcclxuICAgICAgZW5jcnlwdGVkRGF0YTpjb2Rlcy5lbmNyeXB0ZWREYXRhLFxyXG4gICAgICBpdjpjb2Rlcy5pdixcclxuICAgICAgc2Vzc2lvbklkOndlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuc2Vzc2lvbklkXHJcbiAgICB9XHJcbiAgICBjb25zdCB1cmwgPSBgJHt0aGlzLmJhc2VVcmx9L21lbWJlci9nZXRQaG9uZS5odG1sYDtcclxuICAgIHJldHVybiBhd2FpdCB0aGlzLnBvc3QodXJsLCBwYXJhbXMsIGZhbHNlKTtcclxuICB9XHJcbiAgLy8g6Kej5p6Q55So5oi35L+h5oGvXHJcbiAgc3RhdGljIGFzeW5jIGdldFVzZXJpbmZvKGNvZGVzKSB7XHJcbiAgICBhd2FpdCB0aGlzLmxvZ2luKClcclxuICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgIGVuY3J5cHRlZERhdGE6Y29kZXMuZW5jcnlwdGVkRGF0YSxcclxuICAgICAgaXY6Y29kZXMuaXYsXHJcbiAgICAgIHNlc3Npb25JZDp3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnNlc3Npb25JZFxyXG4gICAgfVxyXG4gICAgY29uc3QgdXJsID0gYCR7dGhpcy5iYXNlVXJsfS9tZW1iZXIvZ2V0VXNlcmluZm8uaHRtbGA7XHJcbiAgICByZXR1cm4gYXdhaXQgdGhpcy5wb3N0KHVybCwgcGFyYW1zLCBmYWxzZSk7XHJcbiAgfVxyXG4gIC8vIOiOt+WPlumqjOivgeeggVxyXG4gIHN0YXRpYyBhc3luYyBzZW5kQ29kZShwaG9uZSkge1xyXG4gICAgY29uc3QgdXJsID0gYCR7dGhpcy5iYXNlVXJsfS9zZWxsZXIvd2ViL2luZGV4LnBocD9yPWluaXQvc2VuZGA7XHJcbiAgICByZXR1cm4gdGhpcy5wb3N0KHVybCwgeyBwaG9uZSB9LCB0cnVlKS50aGVuKHJlcyA9PiB7XHJcbiAgICAgIHJldHVybiByZXM7XHJcbiAgICB9KVxyXG4gIH1cclxuICAvLyDnmbvlvZVcclxuICBzdGF0aWMgYXN5bmMgdG9Mb2dpbigpIHtcclxuICAgIGNvbnN0IHNob3BDb2RlID0gd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5hcHBDb2RlO1xyXG4gICAgbGV0IHtjb2RlfSA9IGF3YWl0IHdlcHkubG9naW4oKVxyXG4gICAgd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5jb2RlID0gY29kZVxyXG4gICAgbGV0IHBhcmFtcyA9IHtcclxuICAgICAgYXBwaWQ6IHNob3BDb2RlLFxyXG4gICAgICBjb2RlLFxyXG4gICAgICBcclxuICAgIH1cclxuICAgIC8vIOaYr+WQpuaJq+S7o+eQhueggei/m+adpVxyXG4gICAgaWYod2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5xdWVyeS5hZ2VudElkKSBwYXJhbXMuYWdlbnRJZCA9IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEucXVlcnkuYWdlbnRJZFxyXG4gICAgY29uc3QgdXJsID0gYCR7dGhpcy5iYXNlVXJsfS93eGxvZ2luYDtcclxuICAgIGxldCBfY29kZSA9IGF3YWl0IHRoaXMucG9zdCh1cmwsIHBhcmFtcywgdHJ1ZSwgdHJ1ZSk7XHJcbiAgICBjb25zb2xlLmxvZyhjb2RlKVxyXG4gICAgd2VweS5zZXRTdG9yYWdlU3luYygnbW9iaWxlJyxfY29kZS5kYXRhLm1vYmlsZSk7XHJcbiAgICB3ZXB5LnNldFN0b3JhZ2VTeW5jKCdpc0ZhbnMnLF9jb2RlLmRhdGEuaXNGYW5zKTtcclxuICAgIHdlcHkuc2V0U3RvcmFnZVN5bmMoJ21lbWJlcicsX2NvZGUuZGF0YS5tZW1iZXIpO1xyXG4gICAgd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5zZXNzaW9uSWQgPSBfY29kZS5kYXRhLnNlc3Npb25JZFxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICAgKiDmo4Dmn6XmmK/lkKblrZjlnKjmnYPpmZDliLZcclxuICAgICAqL1xyXG4gIHN0YXRpYyBoYXNDb25maWcoa2V5KSB7XHJcbiAgICBjb25zdCB2YWx1ZSA9IHRoaXMuZ2V0Q29uZmlnKGtleSk7XHJcbiAgICByZXR1cm4gdmFsdWUgIT0gbnVsbCAmJiB2YWx1ZSAhPSAnJztcclxuICB9XHJcbiAgLyoqXHJcbiAgICog6K+75Y+W5p2D6ZmQ5YC8XHJcbiAgICovXHJcbiAgc3RhdGljIGdldENvbmZpZyhrZXkpIHtcclxuICAgIHJldHVybiB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLmF1dGhba2V5XTtcclxuICB9XHJcbiAgc3RhdGljIGdldFN0b3JhZ2Uoa2V5KSB7XHJcbiAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlc2plY3QpID0+IHtcclxuICAgICAgd3guZ2V0U3RvcmFnZSh7XHJcbiAgICAgICAga2V5OiBrZXksXHJcbiAgICAgICAgc3VjY2VzczogZnVuY3Rpb24gKHJlcykge1xyXG4gICAgICAgICAgcmVzb2x2ZShyZXMpXHJcbiAgICAgICAgfVxyXG4gICAgICB9KVxyXG4gICAgfSlcclxuICB9XHJcbiAgLyoqXHJcbiAgKiDorr7nva7mnYPpmZDlgLxcclxuICAqL1xyXG4gIHN0YXRpYyBhc3luYyBzZXRDb25maWcoa2V5LCB2YWx1ZSkge1xyXG4gICAgYXdhaXQgd2VweS5zZXRTdG9yYWdlKHsga2V5OiBrZXksIGRhdGE6IHZhbHVlIH0pO1xyXG4gICAgd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5hdXRoW2tleV0gPSB2YWx1ZTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIOWIoOmZpOadg+mZkOWAvFxyXG4gICAqL1xyXG4gIHN0YXRpYyBhc3luYyByZW1vdmVDb25maWcoa2V5KSB7XHJcbiAgICB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLmF1dGhba2V5XSA9IG51bGw7XHJcbiAgICBhd2FpdCB3ZXB5LnJlbW92ZVN0b3JhZ2UoeyBrZXk6IGtleSB9KTtcclxuICB9XHJcblxyXG59XHJcbiJdfQ==