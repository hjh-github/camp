'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = undefined;

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _base2 = require('./base.js');

var _base3 = _interopRequireDefault(_base2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var config = function (_base) {
    _inherits(config, _base);

    function config() {
        _classCallCheck(this, config);

        return _possibleConstructorReturn(this, (config.__proto__ || Object.getPrototypeOf(config)).apply(this, arguments));
    }

    _createClass(config, null, [{
        key: 'getIndex',

        // 获取首页数据
        value: function () {
            var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(opt) {
                var location, url, params;
                return regeneratorRuntime.wrap(function _callee$(_context) {
                    while (1) {
                        switch (_context.prev = _context.next) {
                            case 0:
                                _context.next = 2;
                                return this.getLocation();

                            case 2:
                                location = _context.sent;

                                if (!(!location && !_wepy2.default.$instance.globalData.cityCode)) {
                                    _context.next = 6;
                                    break;
                                }

                                _wepy2.default.redirectTo({ url: './address' });
                                return _context.abrupt('return');

                            case 6:
                                url = this.baseUrl + '/index';
                                params = _extends({
                                    sessionId: _wepy2.default.$instance.globalData.sessionId,
                                    location: location,
                                    cityCode: _wepy2.default.$instance.globalData.cityCode
                                }, opt);
                                return _context.abrupt('return', this.post(url, params, true).then(function (res) {
                                    return res;
                                }));

                            case 9:
                            case 'end':
                                return _context.stop();
                        }
                    }
                }, _callee, this);
            }));

            function getIndex(_x) {
                return _ref.apply(this, arguments);
            }

            return getIndex;
        }()
    }, {
        key: 'citys',
        value: function () {
            var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
                var url, params;
                return regeneratorRuntime.wrap(function _callee2$(_context2) {
                    while (1) {
                        switch (_context2.prev = _context2.next) {
                            case 0:
                                url = this.baseUrl + '/citys';
                                params = {};
                                return _context2.abrupt('return', this.get(url, params, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context2.stop();
                        }
                    }
                }, _callee2, this);
            }));

            function citys() {
                return _ref2.apply(this, arguments);
            }

            return citys;
        }()
    }, {
        key: 'getCourses',
        value: function () {
            var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(opt) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee3$(_context3) {
                    while (1) {
                        switch (_context3.prev = _context3.next) {
                            case 0:
                                url = this.baseUrl + '/course/getCourses';
                                params = _extends({
                                    cityCode: _wepy2.default.$instance.globalData.cityCode
                                }, opt);
                                return _context3.abrupt('return', this.get(url, params, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context3.stop();
                        }
                    }
                }, _callee3, this);
            }));

            function getCourses(_x2) {
                return _ref3.apply(this, arguments);
            }

            return getCourses;
        }()
    }, {
        key: 'getCompanions',
        value: function () {
            var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4(courseId) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee4$(_context4) {
                    while (1) {
                        switch (_context4.prev = _context4.next) {
                            case 0:
                                url = this.baseUrl + '/course/getCompanions';
                                params = {
                                    courseId: courseId
                                };
                                return _context4.abrupt('return', this.get(url, params, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context4.stop();
                        }
                    }
                }, _callee4, this);
            }));

            function getCompanions(_x3) {
                return _ref4.apply(this, arguments);
            }

            return getCompanions;
        }()
    }, {
        key: 'getCourseInfo',
        value: function () {
            var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5(id) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee5$(_context5) {
                    while (1) {
                        switch (_context5.prev = _context5.next) {
                            case 0:
                                url = this.baseUrl + '/course/getInfo';
                                params = {
                                    id: id
                                };
                                return _context5.abrupt('return', this.get(url, params, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context5.stop();
                        }
                    }
                }, _callee5, this);
            }));

            function getCourseInfo(_x4) {
                return _ref5.apply(this, arguments);
            }

            return getCourseInfo;
        }()
        // 搜索

    }, {
        key: 'search',
        value: function () {
            var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee6(opt) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee6$(_context6) {
                    while (1) {
                        switch (_context6.prev = _context6.next) {
                            case 0:
                                url = this.baseUrl + '/course/search';
                                params = _extends({}, opt);
                                return _context6.abrupt('return', this.get(url, params, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context6.stop();
                        }
                    }
                }, _callee6, this);
            }));

            function search(_x5) {
                return _ref6.apply(this, arguments);
            }

            return search;
        }()
        // 获取评论列表

    }, {
        key: 'comments',
        value: function () {
            var _ref7 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee7(opt) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee7$(_context7) {
                    while (1) {
                        switch (_context7.prev = _context7.next) {
                            case 0:
                                url = this.baseUrl + '/comment/list';
                                params = _extends({}, opt);
                                return _context7.abrupt('return', this.get(url, params, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context7.stop();
                        }
                    }
                }, _callee7, this);
            }));

            function comments(_x6) {
                return _ref7.apply(this, arguments);
            }

            return comments;
        }()
        // 发起砍价

    }, {
        key: 'regBargain',
        value: function () {
            var _ref8 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee8(opt) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee8$(_context8) {
                    while (1) {
                        switch (_context8.prev = _context8.next) {
                            case 0:
                                url = this.baseUrl + '/bargain/regBargain';
                                params = _extends({
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                }, opt);
                                return _context8.abrupt('return', this.post(url, params, true, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context8.stop();
                        }
                    }
                }, _callee8, this);
            }));

            function regBargain(_x7) {
                return _ref8.apply(this, arguments);
            }

            return regBargain;
        }()
        // 帮砍价

    }, {
        key: 'helpBargain',
        value: function () {
            var _ref9 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee9(regId) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee9$(_context9) {
                    while (1) {
                        switch (_context9.prev = _context9.next) {
                            case 0:
                                url = this.baseUrl + '/bargain/helpBargain';
                                params = {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId,
                                    regId: regId
                                };
                                return _context9.abrupt('return', this.post(url, params, true, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context9.stop();
                        }
                    }
                }, _callee9, this);
            }));

            function helpBargain(_x8) {
                return _ref9.apply(this, arguments);
            }

            return helpBargain;
        }()
        // 砍价详情

    }, {
        key: 'toCutDetai',
        value: function () {
            var _ref10 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee10(regId) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee10$(_context10) {
                    while (1) {
                        switch (_context10.prev = _context10.next) {
                            case 0:
                                url = this.baseUrl + '/bargain/toCutDetai';
                                params = {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId,
                                    regId: regId
                                };
                                return _context10.abrupt('return', this.get(url, params, true, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context10.stop();
                        }
                    }
                }, _callee10, this);
            }));

            function toCutDetai(_x9) {
                return _ref10.apply(this, arguments);
            }

            return toCutDetai;
        }()
        // 拼团详情

    }, {
        key: 'pintuanDetai',
        value: function () {
            var _ref11 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee11(activityId) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee11$(_context11) {
                    while (1) {
                        switch (_context11.prev = _context11.next) {
                            case 0:
                                url = this.baseUrl + '/pintuan/share/detai';
                                params = {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId,
                                    activityId: activityId
                                };
                                return _context11.abrupt('return', this.get(url, params, true, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context11.stop();
                        }
                    }
                }, _callee11, this);
            }));

            function pintuanDetai(_x10) {
                return _ref11.apply(this, arguments);
            }

            return pintuanDetai;
        }()
        // ########################  人员信息管理  ###################
        // 获取儿童列表

    }, {
        key: 'getChildList',
        value: function () {
            var _ref12 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee12() {
                var url, params;
                return regeneratorRuntime.wrap(function _callee12$(_context12) {
                    while (1) {
                        switch (_context12.prev = _context12.next) {
                            case 0:
                                url = this.baseUrl + '/member/getChildList';
                                params = {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                };
                                return _context12.abrupt('return', this.get(url, params, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context12.stop();
                        }
                    }
                }, _callee12, this);
            }));

            function getChildList() {
                return _ref12.apply(this, arguments);
            }

            return getChildList;
        }()
        // 获取监护人列表

    }, {
        key: 'getGuaList',
        value: function () {
            var _ref13 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee13() {
                var url, params;
                return regeneratorRuntime.wrap(function _callee13$(_context13) {
                    while (1) {
                        switch (_context13.prev = _context13.next) {
                            case 0:
                                url = this.baseUrl + '/member/getGuaList';
                                params = {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                };
                                return _context13.abrupt('return', this.get(url, params, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context13.stop();
                        }
                    }
                }, _callee13, this);
            }));

            function getGuaList() {
                return _ref13.apply(this, arguments);
            }

            return getGuaList;
        }()
        // 活动儿童详情

    }, {
        key: 'getChild',
        value: function () {
            var _ref14 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee14(id) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee14$(_context14) {
                    while (1) {
                        switch (_context14.prev = _context14.next) {
                            case 0:
                                url = this.baseUrl + '/member/getChild';
                                params = {
                                    id: id,
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                };
                                return _context14.abrupt('return', this.get(url, params, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context14.stop();
                        }
                    }
                }, _callee14, this);
            }));

            function getChild(_x11) {
                return _ref14.apply(this, arguments);
            }

            return getChild;
        }()
        // 活动监护人详情

    }, {
        key: 'getGua',
        value: function () {
            var _ref15 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee15(id) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee15$(_context15) {
                    while (1) {
                        switch (_context15.prev = _context15.next) {
                            case 0:
                                url = this.baseUrl + '/member/getGua';
                                params = {
                                    id: id,
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                };
                                return _context15.abrupt('return', this.get(url, params, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context15.stop();
                        }
                    }
                }, _callee15, this);
            }));

            function getGua(_x12) {
                return _ref15.apply(this, arguments);
            }

            return getGua;
        }()
        // 保存监护人

    }, {
        key: 'updateGua',
        value: function () {
            var _ref16 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee16(opt) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee16$(_context16) {
                    while (1) {
                        switch (_context16.prev = _context16.next) {
                            case 0:
                                url = this.baseUrl + '/member/updateGua';
                                params = _extends({}, opt, {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                });
                                return _context16.abrupt('return', this.post(url, params, true, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context16.stop();
                        }
                    }
                }, _callee16, this);
            }));

            function updateGua(_x13) {
                return _ref16.apply(this, arguments);
            }

            return updateGua;
        }()
        // 保存儿童

    }, {
        key: 'updateChild',
        value: function () {
            var _ref17 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee17(opt) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee17$(_context17) {
                    while (1) {
                        switch (_context17.prev = _context17.next) {
                            case 0:
                                url = this.baseUrl + '/member/updateChild';
                                params = _extends({}, opt, {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                });
                                return _context17.abrupt('return', this.post(url, params, true, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context17.stop();
                        }
                    }
                }, _callee17, this);
            }));

            function updateChild(_x14) {
                return _ref17.apply(this, arguments);
            }

            return updateChild;
        }()
        // 删除监护人

    }, {
        key: 'delGua',
        value: function () {
            var _ref18 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee18(id) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee18$(_context18) {
                    while (1) {
                        switch (_context18.prev = _context18.next) {
                            case 0:
                                url = this.baseUrl + '/member/delGua';
                                params = {
                                    id: id,
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                };
                                return _context18.abrupt('return', this.post(url, params, true, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context18.stop();
                        }
                    }
                }, _callee18, this);
            }));

            function delGua(_x15) {
                return _ref18.apply(this, arguments);
            }

            return delGua;
        }()
        // 删除儿童信息

    }, {
        key: 'delChild',
        value: function () {
            var _ref19 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee19(id) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee19$(_context19) {
                    while (1) {
                        switch (_context19.prev = _context19.next) {
                            case 0:
                                url = this.baseUrl + '/member/delChild';
                                params = {
                                    id: id,
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                };
                                return _context19.abrupt('return', this.post(url, params, true, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context19.stop();
                        }
                    }
                }, _callee19, this);
            }));

            function delChild(_x16) {
                return _ref19.apply(this, arguments);
            }

            return delChild;
        }()
        // ########################  订单管理  ###################
        // 生成支付订单信息 

    }, {
        key: 'orderInfo',
        value: function () {
            var _ref20 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee20(opt) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee20$(_context20) {
                    while (1) {
                        switch (_context20.prev = _context20.next) {
                            case 0:
                                url = this.baseUrl + '/order/info';
                                params = _extends({}, opt, {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                });
                                return _context20.abrupt('return', this.post(url, params, true, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context20.stop();
                        }
                    }
                }, _callee20, this);
            }));

            function orderInfo(_x17) {
                return _ref20.apply(this, arguments);
            }

            return orderInfo;
        }()
        // 下单 

    }, {
        key: 'ordercommit',
        value: function () {
            var _ref21 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee21(opt) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee21$(_context21) {
                    while (1) {
                        switch (_context21.prev = _context21.next) {
                            case 0:
                                url = this.baseUrl + '/order/ordercommit';
                                params = _extends({}, opt, {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                });
                                return _context21.abrupt('return', this.post(url, params, true, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context21.stop();
                        }
                    }
                }, _callee21, this);
            }));

            function ordercommit(_x18) {
                return _ref21.apply(this, arguments);
            }

            return ordercommit;
        }()
        // 支付 

    }, {
        key: 'wxpaytopay',
        value: function () {
            var _ref22 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee22(opt) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee22$(_context22) {
                    while (1) {
                        switch (_context22.prev = _context22.next) {
                            case 0:
                                url = this.baseUrl + '/wxpay/topay';
                                params = _extends({}, opt, {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                });
                                return _context22.abrupt('return', this.post(url, params, true, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context22.stop();
                        }
                    }
                }, _callee22, this);
            }));

            function wxpaytopay(_x19) {
                return _ref22.apply(this, arguments);
            }

            return wxpaytopay;
        }()
        // 获取订单列表

    }, {
        key: 'orders',
        value: function () {
            var _ref23 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee23(opt) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee23$(_context23) {
                    while (1) {
                        switch (_context23.prev = _context23.next) {
                            case 0:
                                url = this.baseUrl + '/member/order';
                                params = _extends({}, opt, {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                });
                                return _context23.abrupt('return', this.get(url, params, true, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context23.stop();
                        }
                    }
                }, _callee23, this);
            }));

            function orders(_x20) {
                return _ref23.apply(this, arguments);
            }

            return orders;
        }()
        // 获取订单详情

    }, {
        key: 'orderdetail',
        value: function () {
            var _ref24 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee24(id) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee24$(_context24) {
                    while (1) {
                        switch (_context24.prev = _context24.next) {
                            case 0:
                                url = this.baseUrl + '/member/orderdetail';
                                params = {
                                    id: id,
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                };
                                return _context24.abrupt('return', this.get(url, params, true, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context24.stop();
                        }
                    }
                }, _callee24, this);
            }));

            function orderdetail(_x21) {
                return _ref24.apply(this, arguments);
            }

            return orderdetail;
        }()
        // 我的砍价

    }, {
        key: 'bargains',
        value: function () {
            var _ref25 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee25(opt) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee25$(_context25) {
                    while (1) {
                        switch (_context25.prev = _context25.next) {
                            case 0:
                                url = this.baseUrl + '/member/bargain/list';
                                params = _extends({}, opt, {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                });
                                return _context25.abrupt('return', this.get(url, params, true, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context25.stop();
                        }
                    }
                }, _callee25, this);
            }));

            function bargains(_x22) {
                return _ref25.apply(this, arguments);
            }

            return bargains;
        }()
        // 我的拼团

    }, {
        key: 'pintuans',
        value: function () {
            var _ref26 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee26(opt) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee26$(_context26) {
                    while (1) {
                        switch (_context26.prev = _context26.next) {
                            case 0:
                                url = this.baseUrl + '/member/pintuan/list';
                                params = _extends({}, opt, {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                });
                                return _context26.abrupt('return', this.get(url, params, true, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context26.stop();
                        }
                    }
                }, _callee26, this);
            }));

            function pintuans(_x23) {
                return _ref26.apply(this, arguments);
            }

            return pintuans;
        }()
        // 取消订单

    }, {
        key: 'cancalorder',
        value: function () {
            var _ref27 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee27(id) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee27$(_context27) {
                    while (1) {
                        switch (_context27.prev = _context27.next) {
                            case 0:
                                url = this.baseUrl + '/member/cancalorder';
                                params = {
                                    id: id,
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                };
                                return _context27.abrupt('return', this.get(url, params, true, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context27.stop();
                        }
                    }
                }, _callee27, this);
            }));

            function cancalorder(_x24) {
                return _ref27.apply(this, arguments);
            }

            return cancalorder;
        }()
        // 取消订单

    }, {
        key: 'center',
        value: function () {
            var _ref28 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee28() {
                var url, params;
                return regeneratorRuntime.wrap(function _callee28$(_context28) {
                    while (1) {
                        switch (_context28.prev = _context28.next) {
                            case 0:
                                url = this.baseUrl + '/member/center';
                                params = {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                };
                                return _context28.abrupt('return', this.get(url, params, true, false).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context28.stop();
                        }
                    }
                }, _callee28, this);
            }));

            function center() {
                return _ref28.apply(this, arguments);
            }

            return center;
        }()

        // ### 评论
        // 上传图片 

    }, {
        key: 'uploadFile',
        value: function uploadFile(image_url) {
            var _this2 = this;

            return new Promise(function (resolve, reject) {
                // 上传图片
                wx.uploadFile({
                    url: _this2.baseUrl + '/member/uploadFiles?sessionId=' + _wepy2.default.$instance.globalData.sessionId, // 仅为示例，非真实的接口地址
                    filePath: image_url,
                    name: 'imgFile',
                    success: function success(res) {
                        var data = JSON.parse(res.data);
                        if (data.errcode == 200) {
                            resolve(data.data);
                        } else {
                            reject(data.errmsg);
                        }
                    },
                    fail: function fail(err) {
                        reject(err);
                    }
                });
            });
        }
        // 获取tag

    }, {
        key: 'commentTag',
        value: function () {
            var _ref29 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee29() {
                var url, params;
                return regeneratorRuntime.wrap(function _callee29$(_context29) {
                    while (1) {
                        switch (_context29.prev = _context29.next) {
                            case 0:
                                url = this.baseUrl + '/member/commentTag';
                                params = {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                };
                                return _context29.abrupt('return', this.get(url, params, true, false).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context29.stop();
                        }
                    }
                }, _callee29, this);
            }));

            function commentTag() {
                return _ref29.apply(this, arguments);
            }

            return commentTag;
        }()
        //更新评论关注

    }, {
        key: 'dolike',
        value: function () {
            var _ref30 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee30(opt) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee30$(_context30) {
                    while (1) {
                        switch (_context30.prev = _context30.next) {
                            case 0:
                                url = this.baseUrl + '/member/dolike';
                                params = _extends({
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                }, opt);
                                return _context30.abrupt('return', this.get(url, params, true, false).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context30.stop();
                        }
                    }
                }, _callee30, this);
            }));

            function dolike(_x25) {
                return _ref30.apply(this, arguments);
            }

            return dolike;
        }()
        // 提交评论

    }, {
        key: 'savecommen',
        value: function () {
            var _ref31 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee31(opt) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee31$(_context31) {
                    while (1) {
                        switch (_context31.prev = _context31.next) {
                            case 0:
                                url = this.baseUrl + '/member/savecomment';
                                params = _extends({}, opt, {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                });
                                return _context31.abrupt('return', this.post(url, params, true, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context31.stop();
                        }
                    }
                }, _callee31, this);
            }));

            function savecommen(_x26) {
                return _ref31.apply(this, arguments);
            }

            return savecommen;
        }()
        // 获取家长心声

    }, {
        key: 'aspirations',
        value: function () {
            var _ref32 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee32(opt) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee32$(_context32) {
                    while (1) {
                        switch (_context32.prev = _context32.next) {
                            case 0:
                                url = this.baseUrl + '/comment/aspirations';
                                params = _extends({}, opt, {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                });
                                return _context32.abrupt('return', this.get(url, params, true, false).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context32.stop();
                        }
                    }
                }, _callee32, this);
            }));

            function aspirations(_x27) {
                return _ref32.apply(this, arguments);
            }

            return aspirations;
        }()
        // 获取分享小程序码

    }, {
        key: 'getPoster',
        value: function () {
            var _ref33 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee33(opt) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee33$(_context33) {
                    while (1) {
                        switch (_context33.prev = _context33.next) {
                            case 0:
                                url = this.baseUrl + '/poster/getPoster';
                                params = _extends({}, opt, {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                });
                                return _context33.abrupt('return', this.post(url, params, true, false).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context33.stop();
                        }
                    }
                }, _callee33, this);
            }));

            function getPoster(_x28) {
                return _ref33.apply(this, arguments);
            }

            return getPoster;
        }()
    }]);

    return config;
}(_base3.default);

exports.default = config;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbmZpZy5qcyJdLCJuYW1lcyI6WyJjb25maWciLCJvcHQiLCJnZXRMb2NhdGlvbiIsImxvY2F0aW9uIiwid2VweSIsIiRpbnN0YW5jZSIsImdsb2JhbERhdGEiLCJjaXR5Q29kZSIsInJlZGlyZWN0VG8iLCJ1cmwiLCJiYXNlVXJsIiwicGFyYW1zIiwic2Vzc2lvbklkIiwicG9zdCIsInRoZW4iLCJyZXMiLCJnZXQiLCJjb3Vyc2VJZCIsImlkIiwicmVnSWQiLCJhY3Rpdml0eUlkIiwiaW1hZ2VfdXJsIiwiUHJvbWlzZSIsInJlc29sdmUiLCJyZWplY3QiLCJ3eCIsInVwbG9hZEZpbGUiLCJmaWxlUGF0aCIsIm5hbWUiLCJzdWNjZXNzIiwiZGF0YSIsIkpTT04iLCJwYXJzZSIsImVycmNvZGUiLCJlcnJtc2ciLCJmYWlsIiwiZXJyIiwiYmFzZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7QUFBQTs7OztBQUNBOzs7Ozs7Ozs7Ozs7OztJQUVxQkEsTTs7Ozs7Ozs7Ozs7O0FBQ2pCOztnR0FDc0JDLEc7Ozs7Ozs7dUNBQ0csS0FBS0MsV0FBTCxFOzs7QUFBakJDLHdDOztzQ0FFQSxDQUFDQSxRQUFELElBQWEsQ0FBQ0MsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCQyxROzs7OztBQUN4Q0gsK0NBQUtJLFVBQUwsQ0FBZ0IsRUFBRUMsS0FBSyxXQUFQLEVBQWhCOzs7O0FBR0FBLG1DLEdBQVMsS0FBS0MsTztBQUNkQyxzQztBQUNBQywrQ0FBV1IsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCTSxTO0FBQ3JDVCxzRDtBQUNBSSw4Q0FBVUgsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCQzttQ0FDakNOLEc7aUVBRUEsS0FBS1ksSUFBTCxDQUFVSixHQUFWLEVBQWVFLE1BQWYsRUFBdUIsSUFBdkIsRUFBNkJHLElBQTdCLENBQWtDLGVBQU87QUFDNUMsMkNBQU9DLEdBQVA7QUFDSCxpQ0FGTSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBS0hOLG1DLEdBQVMsS0FBS0MsTztBQUNkQyxzQyxHQUFTLEU7a0VBQ04sS0FBS0ssR0FBTCxDQUFTUCxHQUFULEVBQWNFLE1BQWQsRUFBc0IsSUFBdEIsRUFBNEJHLElBQTVCLENBQWlDLGVBQU87QUFDM0MsMkNBQU9DLEdBQVA7QUFDSCxpQ0FGTSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O2tHQUlhZCxHOzs7Ozs7QUFDaEJRLG1DLEdBQVMsS0FBS0MsTztBQUNkQyxzQztBQUNBSiw4Q0FBVUgsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCQzttQ0FDakNOLEc7a0VBRUEsS0FBS2UsR0FBTCxDQUFTUCxHQUFULEVBQWNFLE1BQWQsRUFBc0IsSUFBdEIsRUFBNEJHLElBQTVCLENBQWlDLGVBQU87QUFDM0MsMkNBQU9DLEdBQVA7QUFDSCxpQ0FGTSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O2tHQUtnQkUsUTs7Ozs7O0FBQ25CUixtQyxHQUFTLEtBQUtDLE87QUFDZEMsc0MsR0FBUztBQUNUTTtBQURTLGlDO2tFQUdOLEtBQUtELEdBQUwsQ0FBU1AsR0FBVCxFQUFjRSxNQUFkLEVBQXNCLElBQXRCLEVBQTRCRyxJQUE1QixDQUFpQyxlQUFPO0FBQzNDLDJDQUFPQyxHQUFQO0FBQ0gsaUNBRk0sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztrR0FLZ0JHLEU7Ozs7OztBQUNmVCxtQyxHQUFTLEtBQUtDLE87QUFDZEMsc0MsR0FBUztBQUNUTztBQURTLGlDO2tFQUdOLEtBQUtGLEdBQUwsQ0FBU1AsR0FBVCxFQUFjRSxNQUFkLEVBQXNCLElBQXRCLEVBQTRCRyxJQUE1QixDQUFpQyxlQUFPO0FBQzNDLDJDQUFPQyxHQUFQO0FBQ0gsaUNBRk0sQzs7Ozs7Ozs7Ozs7Ozs7OztBQUlYOzs7OztrR0FDZ0JkLEc7Ozs7OztBQUNSUSxtQyxHQUFTLEtBQUtDLE87QUFDZEMsc0MsZ0JBQ0dWLEc7a0VBRUEsS0FBS2UsR0FBTCxDQUFTUCxHQUFULEVBQWNFLE1BQWQsRUFBc0IsSUFBdEIsRUFBNEJHLElBQTVCLENBQWlDLGVBQU87QUFDM0MsMkNBQU9DLEdBQVA7QUFDSCxpQ0FGTSxDOzs7Ozs7Ozs7Ozs7Ozs7O0FBSVg7Ozs7O2tHQUNrQmQsRzs7Ozs7O0FBQ1ZRLG1DLEdBQVMsS0FBS0MsTztBQUNkQyxzQyxnQkFDR1YsRztrRUFFQSxLQUFLZSxHQUFMLENBQVNQLEdBQVQsRUFBY0UsTUFBZCxFQUFzQixJQUF0QixFQUE0QkcsSUFBNUIsQ0FBaUMsZUFBTztBQUMzQywyQ0FBT0MsR0FBUDtBQUNILGlDQUZNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJWDs7Ozs7a0dBQ29CZCxHOzs7Ozs7QUFDWlEsbUMsR0FBUyxLQUFLQyxPO0FBQ2RDLHNDO0FBQ0FDLCtDQUFXUixlQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJNO21DQUNsQ1gsRztrRUFFQSxLQUFLWSxJQUFMLENBQVVKLEdBQVYsRUFBZUUsTUFBZixFQUF1QixJQUF2QixFQUE2QixJQUE3QixFQUFtQ0csSUFBbkMsQ0FBd0MsZUFBTztBQUNsRCwyQ0FBT0MsR0FBUDtBQUNILGlDQUZNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJWDs7Ozs7a0dBQ3FCSSxLOzs7Ozs7QUFDYlYsbUMsR0FBUyxLQUFLQyxPO0FBQ2RDLHNDLEdBQVM7QUFDVEMsK0NBQVdSLGVBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQk0sU0FENUI7QUFFVE87QUFGUyxpQztrRUFJTixLQUFLTixJQUFMLENBQVVKLEdBQVYsRUFBZUUsTUFBZixFQUF1QixJQUF2QixFQUE2QixJQUE3QixFQUFtQ0csSUFBbkMsQ0FBd0MsZUFBTztBQUNsRCwyQ0FBT0MsR0FBUDtBQUNILGlDQUZNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJWDs7Ozs7b0dBQ29CSSxLOzs7Ozs7QUFDWlYsbUMsR0FBUyxLQUFLQyxPO0FBQ2RDLHNDLEdBQVM7QUFDVEMsK0NBQVdSLGVBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQk0sU0FENUI7QUFFVE87QUFGUyxpQzttRUFJTixLQUFLSCxHQUFMLENBQVNQLEdBQVQsRUFBY0UsTUFBZCxFQUFzQixJQUF0QixFQUE0QixJQUE1QixFQUFrQ0csSUFBbEMsQ0FBdUMsZUFBTztBQUNqRCwyQ0FBT0MsR0FBUDtBQUNILGlDQUZNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJWDs7Ozs7b0dBQ3NCSyxVOzs7Ozs7QUFDZFgsbUMsR0FBUyxLQUFLQyxPO0FBQ2RDLHNDLEdBQVM7QUFDVEMsK0NBQVdSLGVBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQk0sU0FENUI7QUFFVFE7QUFGUyxpQzttRUFJTixLQUFLSixHQUFMLENBQVNQLEdBQVQsRUFBY0UsTUFBZCxFQUFzQixJQUF0QixFQUE0QixJQUE1QixFQUFrQ0csSUFBbEMsQ0FBdUMsZUFBTztBQUNqRCwyQ0FBT0MsR0FBUDtBQUNILGlDQUZNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJWDtBQUNBOzs7Ozs7Ozs7OztBQUVRTixtQyxHQUFTLEtBQUtDLE87QUFDZEMsc0MsR0FBUztBQUNUQywrQ0FBV1IsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCTTtBQUQ1QixpQzttRUFHTixLQUFLSSxHQUFMLENBQVNQLEdBQVQsRUFBY0UsTUFBZCxFQUFzQixJQUF0QixFQUE0QkcsSUFBNUIsQ0FBaUMsZUFBTztBQUMzQywyQ0FBT0MsR0FBUDtBQUNILGlDQUZNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJWDs7Ozs7Ozs7Ozs7QUFFUU4sbUMsR0FBUyxLQUFLQyxPO0FBQ2RDLHNDLEdBQVM7QUFDVEMsK0NBQVdSLGVBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQk07QUFENUIsaUM7bUVBR04sS0FBS0ksR0FBTCxDQUFTUCxHQUFULEVBQWNFLE1BQWQsRUFBc0IsSUFBdEIsRUFBNEJHLElBQTVCLENBQWlDLGVBQU87QUFDM0MsMkNBQU9DLEdBQVA7QUFDSCxpQ0FGTSxDOzs7Ozs7Ozs7Ozs7Ozs7O0FBSVg7Ozs7O29HQUNrQkcsRTs7Ozs7O0FBQ1ZULG1DLEdBQVMsS0FBS0MsTztBQUNkQyxzQyxHQUFTO0FBQ1RPLDBDQURTO0FBRVROLCtDQUFXUixlQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJNO0FBRjVCLGlDO21FQUlOLEtBQUtJLEdBQUwsQ0FBU1AsR0FBVCxFQUFjRSxNQUFkLEVBQXNCLElBQXRCLEVBQTRCRyxJQUE1QixDQUFpQyxlQUFPO0FBQzNDLDJDQUFPQyxHQUFQO0FBQ0gsaUNBRk0sQzs7Ozs7Ozs7Ozs7Ozs7OztBQUlYOzs7OztvR0FDZ0JHLEU7Ozs7OztBQUNSVCxtQyxHQUFTLEtBQUtDLE87QUFDZEMsc0MsR0FBUztBQUNUTywwQ0FEUztBQUVUTiwrQ0FBV1IsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCTTtBQUY1QixpQzttRUFJTixLQUFLSSxHQUFMLENBQVNQLEdBQVQsRUFBY0UsTUFBZCxFQUFzQixJQUF0QixFQUE0QkcsSUFBNUIsQ0FBaUMsZUFBTztBQUMzQywyQ0FBT0MsR0FBUDtBQUNILGlDQUZNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJWDs7Ozs7b0dBQ21CZCxHOzs7Ozs7QUFDWFEsbUMsR0FBUyxLQUFLQyxPO0FBQ2RDLHNDLGdCQUNHVixHO0FBQ0hXLCtDQUFXUixlQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJNOzttRUFFbEMsS0FBS0MsSUFBTCxDQUFVSixHQUFWLEVBQWVFLE1BQWYsRUFBdUIsSUFBdkIsRUFBNkIsSUFBN0IsRUFBbUNHLElBQW5DLENBQXdDLGVBQU87QUFDbEQsMkNBQU9DLEdBQVA7QUFDSCxpQ0FGTSxDOzs7Ozs7Ozs7Ozs7Ozs7O0FBSVg7Ozs7O29HQUNxQmQsRzs7Ozs7O0FBQ2JRLG1DLEdBQVMsS0FBS0MsTztBQUNkQyxzQyxnQkFDR1YsRztBQUNIVywrQ0FBV1IsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCTTs7bUVBRWxDLEtBQUtDLElBQUwsQ0FBVUosR0FBVixFQUFlRSxNQUFmLEVBQXVCLElBQXZCLEVBQTZCLElBQTdCLEVBQW1DRyxJQUFuQyxDQUF3QyxlQUFPO0FBQ2xELDJDQUFPQyxHQUFQO0FBQ0gsaUNBRk0sQzs7Ozs7Ozs7Ozs7Ozs7OztBQUlYOzs7OztvR0FDZ0JHLEU7Ozs7OztBQUNSVCxtQyxHQUFTLEtBQUtDLE87QUFDZEMsc0MsR0FBUztBQUNUTywwQ0FEUztBQUVUTiwrQ0FBV1IsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCTTtBQUY1QixpQzttRUFJTixLQUFLQyxJQUFMLENBQVVKLEdBQVYsRUFBZUUsTUFBZixFQUF1QixJQUF2QixFQUE2QixJQUE3QixFQUFtQ0csSUFBbkMsQ0FBd0MsZUFBTztBQUNsRCwyQ0FBT0MsR0FBUDtBQUNILGlDQUZNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJWDs7Ozs7b0dBQ2tCRyxFOzs7Ozs7QUFDVlQsbUMsR0FBUyxLQUFLQyxPO0FBQ2RDLHNDLEdBQVM7QUFDVE8sMENBRFM7QUFFVE4sK0NBQVdSLGVBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQk07QUFGNUIsaUM7bUVBSU4sS0FBS0MsSUFBTCxDQUFVSixHQUFWLEVBQWVFLE1BQWYsRUFBdUIsSUFBdkIsRUFBNkIsSUFBN0IsRUFBbUNHLElBQW5DLENBQXdDLGVBQU87QUFDbEQsMkNBQU9DLEdBQVA7QUFDSCxpQ0FGTSxDOzs7Ozs7Ozs7Ozs7Ozs7O0FBSVg7QUFDQTs7Ozs7b0dBQ21CZCxHOzs7Ozs7QUFDWFEsbUMsR0FBUyxLQUFLQyxPO0FBQ2RDLHNDLGdCQUNHVixHO0FBQ0hXLCtDQUFXUixlQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJNOzttRUFFbEMsS0FBS0MsSUFBTCxDQUFVSixHQUFWLEVBQWVFLE1BQWYsRUFBdUIsSUFBdkIsRUFBNkIsSUFBN0IsRUFBbUNHLElBQW5DLENBQXdDLGVBQU87QUFDbEQsMkNBQU9DLEdBQVA7QUFDSCxpQ0FGTSxDOzs7Ozs7Ozs7Ozs7Ozs7O0FBSVg7Ozs7O29HQUNxQmQsRzs7Ozs7O0FBQ2JRLG1DLEdBQVMsS0FBS0MsTztBQUNkQyxzQyxnQkFDR1YsRztBQUNIVywrQ0FBV1IsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCTTs7bUVBRWxDLEtBQUtDLElBQUwsQ0FBVUosR0FBVixFQUFlRSxNQUFmLEVBQXVCLElBQXZCLEVBQTZCLElBQTdCLEVBQW1DRyxJQUFuQyxDQUF3QyxlQUFPO0FBQ2xELDJDQUFPQyxHQUFQO0FBQ0gsaUNBRk0sQzs7Ozs7Ozs7Ozs7Ozs7OztBQUlYOzs7OztvR0FDb0JkLEc7Ozs7OztBQUNaUSxtQyxHQUFTLEtBQUtDLE87QUFDZEMsc0MsZ0JBQ0dWLEc7QUFDSFcsK0NBQVdSLGVBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQk07O21FQUVsQyxLQUFLQyxJQUFMLENBQVVKLEdBQVYsRUFBZUUsTUFBZixFQUF1QixJQUF2QixFQUE2QixJQUE3QixFQUFtQ0csSUFBbkMsQ0FBd0MsZUFBTztBQUNsRCwyQ0FBT0MsR0FBUDtBQUNILGlDQUZNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJWDs7Ozs7b0dBQ2dCZCxHOzs7Ozs7QUFDUlEsbUMsR0FBUyxLQUFLQyxPO0FBQ2RDLHNDLGdCQUNHVixHO0FBQ0hXLCtDQUFXUixlQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJNOzttRUFFbEMsS0FBS0ksR0FBTCxDQUFTUCxHQUFULEVBQWNFLE1BQWQsRUFBc0IsSUFBdEIsRUFBNEIsSUFBNUIsRUFBa0NHLElBQWxDLENBQXVDLGVBQU87QUFDakQsMkNBQU9DLEdBQVA7QUFDSCxpQ0FGTSxDOzs7Ozs7Ozs7Ozs7Ozs7O0FBSVg7Ozs7O29HQUNxQkcsRTs7Ozs7O0FBQ2JULG1DLEdBQVMsS0FBS0MsTztBQUNkQyxzQyxHQUFTO0FBQ1RPLDBDQURTO0FBRVROLCtDQUFXUixlQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJNO0FBRjVCLGlDO21FQUlOLEtBQUtJLEdBQUwsQ0FBU1AsR0FBVCxFQUFjRSxNQUFkLEVBQXNCLElBQXRCLEVBQTRCLElBQTVCLEVBQWtDRyxJQUFsQyxDQUF1QyxlQUFPO0FBQ2pELDJDQUFPQyxHQUFQO0FBQ0gsaUNBRk0sQzs7Ozs7Ozs7Ozs7Ozs7OztBQUlYOzs7OztvR0FDa0JkLEc7Ozs7OztBQUNWUSxtQyxHQUFTLEtBQUtDLE87QUFDZEMsc0MsZ0JBQ0dWLEc7QUFDSFcsK0NBQVdSLGVBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQk07O21FQUVsQyxLQUFLSSxHQUFMLENBQVNQLEdBQVQsRUFBY0UsTUFBZCxFQUFzQixJQUF0QixFQUE0QixJQUE1QixFQUFrQ0csSUFBbEMsQ0FBdUMsZUFBTztBQUNqRCwyQ0FBT0MsR0FBUDtBQUNILGlDQUZNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJWDs7Ozs7b0dBQ2tCZCxHOzs7Ozs7QUFDVlEsbUMsR0FBUyxLQUFLQyxPO0FBQ2RDLHNDLGdCQUNHVixHO0FBQ0hXLCtDQUFXUixlQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJNOzttRUFFbEMsS0FBS0ksR0FBTCxDQUFTUCxHQUFULEVBQWNFLE1BQWQsRUFBc0IsSUFBdEIsRUFBNEIsSUFBNUIsRUFBa0NHLElBQWxDLENBQXVDLGVBQU87QUFDakQsMkNBQU9DLEdBQVA7QUFDSCxpQ0FGTSxDOzs7Ozs7Ozs7Ozs7Ozs7O0FBSVg7Ozs7O29HQUNxQkcsRTs7Ozs7O0FBQ2JULG1DLEdBQVMsS0FBS0MsTztBQUNkQyxzQyxHQUFTO0FBQ1RPLDBDQURTO0FBRVROLCtDQUFXUixlQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJNO0FBRjVCLGlDO21FQUlOLEtBQUtJLEdBQUwsQ0FBU1AsR0FBVCxFQUFjRSxNQUFkLEVBQXNCLElBQXRCLEVBQTRCLElBQTVCLEVBQWtDRyxJQUFsQyxDQUF1QyxlQUFPO0FBQ2pELDJDQUFPQyxHQUFQO0FBQ0gsaUNBRk0sQzs7Ozs7Ozs7Ozs7Ozs7OztBQUlYOzs7Ozs7Ozs7OztBQUVJTixtQyxHQUFTLEtBQUtDLE87QUFDZEMsc0MsR0FBUztBQUNUQywrQ0FBV1IsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCTTtBQUQ1QixpQzttRUFHTixLQUFLSSxHQUFMLENBQVNQLEdBQVQsRUFBY0UsTUFBZCxFQUFzQixJQUF0QixFQUE0QixLQUE1QixFQUFtQ0csSUFBbkMsQ0FBd0MsZUFBTztBQUNsRCwyQ0FBT0MsR0FBUDtBQUNILGlDQUZNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBS1g7QUFDQTs7OzttQ0FDa0JNLFMsRUFBVztBQUFBOztBQUNyQixtQkFBTyxJQUFJQyxPQUFKLENBQVksVUFBQ0MsT0FBRCxFQUFVQyxNQUFWLEVBQXFCO0FBQ3BDO0FBQ0FDLG1CQUFHQyxVQUFILENBQWM7QUFDVmpCLHlCQUFRLE9BQUtDLE9BQWIsc0NBQXFETixlQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJNLFNBRHJFLEVBQ2tGO0FBQzVGZSw4QkFBVU4sU0FGQTtBQUdWTywwQkFBTSxTQUhJO0FBSVZDLDZCQUFTLGlCQUFTZCxHQUFULEVBQWM7QUFDbkIsNEJBQUllLE9BQU9DLEtBQUtDLEtBQUwsQ0FBV2pCLElBQUllLElBQWYsQ0FBWDtBQUNBLDRCQUFJQSxLQUFLRyxPQUFMLElBQWdCLEdBQXBCLEVBQXlCO0FBQ3JCVixvQ0FBUU8sS0FBS0EsSUFBYjtBQUNILHlCQUZELE1BRU87QUFDSE4sbUNBQU9NLEtBQUtJLE1BQVo7QUFDSDtBQUNKLHFCQVhTO0FBWVZDLHdCQVpVLGdCQVlMQyxHQVpLLEVBWUE7QUFDTlosK0JBQU9ZLEdBQVA7QUFDSDtBQWRTLGlCQUFkO0FBZ0JILGFBbEJNLENBQVA7QUFtQkg7QUFDRDs7Ozs7Ozs7Ozs7QUFFUTNCLG1DLEdBQVMsS0FBS0MsTztBQUNkQyxzQyxHQUFTO0FBQ1RDLCtDQUFXUixlQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJNO0FBRDVCLGlDO21FQUdOLEtBQUtJLEdBQUwsQ0FBU1AsR0FBVCxFQUFjRSxNQUFkLEVBQXNCLElBQXRCLEVBQTRCLEtBQTVCLEVBQW1DRyxJQUFuQyxDQUF3QyxlQUFPO0FBQ2xELDJDQUFPQyxHQUFQO0FBQ0gsaUNBRk0sQzs7Ozs7Ozs7Ozs7Ozs7OztBQUlYOzs7OztvR0FDZ0JkLEc7Ozs7OztBQUNSUSxtQyxHQUFTLEtBQUtDLE87QUFDZEMsc0M7QUFDQUMsK0NBQVdSLGVBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQk07bUNBQ2xDWCxHO21FQUVBLEtBQUtlLEdBQUwsQ0FBU1AsR0FBVCxFQUFjRSxNQUFkLEVBQXNCLElBQXRCLEVBQTRCLEtBQTVCLEVBQW1DRyxJQUFuQyxDQUF3QyxlQUFPO0FBQ2xELDJDQUFPQyxHQUFQO0FBQ0gsaUNBRk0sQzs7Ozs7Ozs7Ozs7Ozs7OztBQUlYOzs7OztvR0FDb0JkLEc7Ozs7OztBQUNaUSxtQyxHQUFTLEtBQUtDLE87QUFDZEMsc0MsZ0JBQ0dWLEc7QUFDSFcsK0NBQVdSLGVBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQk07O21FQUVsQyxLQUFLQyxJQUFMLENBQVVKLEdBQVYsRUFBZUUsTUFBZixFQUF1QixJQUF2QixFQUE2QixJQUE3QixFQUFtQ0csSUFBbkMsQ0FBd0MsZUFBTztBQUNsRCwyQ0FBT0MsR0FBUDtBQUNILGlDQUZNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJWDs7Ozs7b0dBQ3FCZCxHOzs7Ozs7QUFDYlEsbUMsR0FBUyxLQUFLQyxPO0FBQ2RDLHNDLGdCQUNHVixHO0FBQ0hXLCtDQUFXUixlQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJNOzttRUFFbEMsS0FBS0ksR0FBTCxDQUFTUCxHQUFULEVBQWNFLE1BQWQsRUFBc0IsSUFBdEIsRUFBNEIsS0FBNUIsRUFBbUNHLElBQW5DLENBQXdDLGVBQU87QUFDbEQsMkNBQU9DLEdBQVA7QUFDSCxpQ0FGTSxDOzs7Ozs7Ozs7Ozs7Ozs7O0FBSVg7Ozs7O29HQUNtQmQsRzs7Ozs7O0FBQ2ZRLG1DLEdBQVMsS0FBS0MsTztBQUNkQyxzQyxnQkFDR1YsRztBQUNIVywrQ0FBV1IsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCTTs7bUVBRWxDLEtBQUtDLElBQUwsQ0FBVUosR0FBVixFQUFlRSxNQUFmLEVBQXVCLElBQXZCLEVBQTZCLEtBQTdCLEVBQW9DRyxJQUFwQyxDQUF5QyxlQUFPO0FBQ25ELDJDQUFPQyxHQUFQO0FBQ0gsaUNBRk0sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQTdYcUJzQixjOztrQkFBZnJDLE0iLCJmaWxlIjoiY29uZmlnLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHdlcHkgZnJvbSAnd2VweSdcclxuaW1wb3J0IGJhc2UgZnJvbSAnLi9iYXNlJ1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgY29uZmlnIGV4dGVuZHMgYmFzZSB7XHJcbiAgICAvLyDojrflj5bpppbpobXmlbDmja5cclxuICAgIHN0YXRpYyBhc3luYyBnZXRJbmRleChvcHQpIHtcclxuICAgICAgICBsZXQgbG9jYXRpb24gPSBhd2FpdCB0aGlzLmdldExvY2F0aW9uKClcclxuICAgICAgICAgICAgLy8gICDlvZPnlKjmiLfmi5Lnu53mjojmnYPlubbkuJTmsqHmnInmiYvliqjpgInmi6nln47luILml7bvvIzot7PovazliLDpgInmi6nlnLDlnYDpobVcclxuICAgICAgICBpZiAoIWxvY2F0aW9uICYmICF3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLmNpdHlDb2RlKSB7XHJcbiAgICAgICAgICAgIHdlcHkucmVkaXJlY3RUbyh7IHVybDogJy4vYWRkcmVzcycgfSk7XHJcbiAgICAgICAgICAgIHJldHVyblxyXG4gICAgICAgIH1cclxuICAgICAgICBsZXQgdXJsID0gYCR7dGhpcy5iYXNlVXJsfS9pbmRleGA7XHJcbiAgICAgICAgbGV0IHBhcmFtcyA9IHtcclxuICAgICAgICAgICAgc2Vzc2lvbklkOiB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnNlc3Npb25JZCxcclxuICAgICAgICAgICAgbG9jYXRpb24sXHJcbiAgICAgICAgICAgIGNpdHlDb2RlOiB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLmNpdHlDb2RlLFxyXG4gICAgICAgICAgICAuLi5vcHRcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHRoaXMucG9zdCh1cmwsIHBhcmFtcywgdHJ1ZSkudGhlbihyZXMgPT4ge1xyXG4gICAgICAgICAgICByZXR1cm4gcmVzO1xyXG4gICAgICAgIH0pXHJcbiAgICB9XHJcbiAgICBzdGF0aWMgYXN5bmMgY2l0eXMoKSB7XHJcbiAgICAgICAgbGV0IHVybCA9IGAke3RoaXMuYmFzZVVybH0vY2l0eXNgO1xyXG4gICAgICAgIGxldCBwYXJhbXMgPSB7fVxyXG4gICAgICAgIHJldHVybiB0aGlzLmdldCh1cmwsIHBhcmFtcywgdHJ1ZSkudGhlbihyZXMgPT4ge1xyXG4gICAgICAgICAgICByZXR1cm4gcmVzO1xyXG4gICAgICAgIH0pXHJcbiAgICB9XHJcbiAgICBzdGF0aWMgYXN5bmMgZ2V0Q291cnNlcyhvcHQpIHtcclxuICAgICAgICBsZXQgdXJsID0gYCR7dGhpcy5iYXNlVXJsfS9jb3Vyc2UvZ2V0Q291cnNlc2A7XHJcbiAgICAgICAgbGV0IHBhcmFtcyA9IHtcclxuICAgICAgICAgICAgY2l0eUNvZGU6IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuY2l0eUNvZGUsXHJcbiAgICAgICAgICAgIC4uLm9wdFxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdGhpcy5nZXQodXJsLCBwYXJhbXMsIHRydWUpLnRoZW4ocmVzID0+IHtcclxuICAgICAgICAgICAgcmV0dXJuIHJlcztcclxuICAgICAgICB9KVxyXG4gICAgfVxyXG5cclxuICAgIHN0YXRpYyBhc3luYyBnZXRDb21wYW5pb25zKGNvdXJzZUlkKSB7XHJcbiAgICAgICAgbGV0IHVybCA9IGAke3RoaXMuYmFzZVVybH0vY291cnNlL2dldENvbXBhbmlvbnNgO1xyXG4gICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgIGNvdXJzZUlkXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB0aGlzLmdldCh1cmwsIHBhcmFtcywgdHJ1ZSkudGhlbihyZXMgPT4ge1xyXG4gICAgICAgICAgICByZXR1cm4gcmVzO1xyXG4gICAgICAgIH0pXHJcbiAgICB9XHJcblxyXG4gICAgc3RhdGljIGFzeW5jIGdldENvdXJzZUluZm8oaWQpIHtcclxuICAgICAgICAgICAgbGV0IHVybCA9IGAke3RoaXMuYmFzZVVybH0vY291cnNlL2dldEluZm9gO1xyXG4gICAgICAgICAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICAgICAgICAgICAgaWRcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5nZXQodXJsLCBwYXJhbXMsIHRydWUpLnRoZW4ocmVzID0+IHtcclxuICAgICAgICAgICAgICAgIHJldHVybiByZXM7XHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vIOaQnOe0olxyXG4gICAgc3RhdGljIGFzeW5jIHNlYXJjaChvcHQpIHtcclxuICAgICAgICAgICAgbGV0IHVybCA9IGAke3RoaXMuYmFzZVVybH0vY291cnNlL3NlYXJjaGA7XHJcbiAgICAgICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgICAgICAuLi5vcHRcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5nZXQodXJsLCBwYXJhbXMsIHRydWUpLnRoZW4ocmVzID0+IHtcclxuICAgICAgICAgICAgICAgIHJldHVybiByZXM7XHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vIOiOt+WPluivhOiuuuWIl+ihqFxyXG4gICAgc3RhdGljIGFzeW5jIGNvbW1lbnRzKG9wdCkge1xyXG4gICAgICAgICAgICBsZXQgdXJsID0gYCR7dGhpcy5iYXNlVXJsfS9jb21tZW50L2xpc3RgO1xyXG4gICAgICAgICAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICAgICAgICAgICAgLi4ub3B0XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuZ2V0KHVybCwgcGFyYW1zLCB0cnVlKS50aGVuKHJlcyA9PiB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gcmVzO1xyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgIH1cclxuICAgICAgICAvLyDlj5HotbfnoI3ku7dcclxuICAgIHN0YXRpYyBhc3luYyByZWdCYXJnYWluKG9wdCkge1xyXG4gICAgICAgICAgICBsZXQgdXJsID0gYCR7dGhpcy5iYXNlVXJsfS9iYXJnYWluL3JlZ0JhcmdhaW5gO1xyXG4gICAgICAgICAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICAgICAgICAgICAgc2Vzc2lvbklkOiB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnNlc3Npb25JZCxcclxuICAgICAgICAgICAgICAgIC4uLm9wdFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLnBvc3QodXJsLCBwYXJhbXMsIHRydWUsIHRydWUpLnRoZW4ocmVzID0+IHtcclxuICAgICAgICAgICAgICAgIHJldHVybiByZXM7XHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vIOW4ruegjeS7t1xyXG4gICAgc3RhdGljIGFzeW5jIGhlbHBCYXJnYWluKHJlZ0lkKSB7XHJcbiAgICAgICAgICAgIGxldCB1cmwgPSBgJHt0aGlzLmJhc2VVcmx9L2JhcmdhaW4vaGVscEJhcmdhaW5gO1xyXG4gICAgICAgICAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICAgICAgICAgICAgc2Vzc2lvbklkOiB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnNlc3Npb25JZCxcclxuICAgICAgICAgICAgICAgIHJlZ0lkXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMucG9zdCh1cmwsIHBhcmFtcywgdHJ1ZSwgdHJ1ZSkudGhlbihyZXMgPT4ge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHJlcztcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICB9XHJcbiAgICAgICAgLy8g56CN5Lu36K+m5oOFXHJcbiAgICBzdGF0aWMgYXN5bmMgdG9DdXREZXRhaShyZWdJZCkge1xyXG4gICAgICAgICAgICBsZXQgdXJsID0gYCR7dGhpcy5iYXNlVXJsfS9iYXJnYWluL3RvQ3V0RGV0YWlgO1xyXG4gICAgICAgICAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICAgICAgICAgICAgc2Vzc2lvbklkOiB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnNlc3Npb25JZCxcclxuICAgICAgICAgICAgICAgIHJlZ0lkXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuZ2V0KHVybCwgcGFyYW1zLCB0cnVlLCB0cnVlKS50aGVuKHJlcyA9PiB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gcmVzO1xyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgIH1cclxuICAgICAgICAvLyDmi7zlm6Lor6bmg4VcclxuICAgIHN0YXRpYyBhc3luYyBwaW50dWFuRGV0YWkoYWN0aXZpdHlJZCkge1xyXG4gICAgICAgICAgICBsZXQgdXJsID0gYCR7dGhpcy5iYXNlVXJsfS9waW50dWFuL3NoYXJlL2RldGFpYDtcclxuICAgICAgICAgICAgbGV0IHBhcmFtcyA9IHtcclxuICAgICAgICAgICAgICAgIHNlc3Npb25JZDogd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5zZXNzaW9uSWQsXHJcbiAgICAgICAgICAgICAgICBhY3Rpdml0eUlkXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuZ2V0KHVybCwgcGFyYW1zLCB0cnVlLCB0cnVlKS50aGVuKHJlcyA9PiB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gcmVzO1xyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgIH1cclxuICAgICAgICAvLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMgIOS6uuWRmOS/oeaBr+euoeeQhiAgIyMjIyMjIyMjIyMjIyMjIyMjI1xyXG4gICAgICAgIC8vIOiOt+WPluWEv+erpeWIl+ihqFxyXG4gICAgc3RhdGljIGFzeW5jIGdldENoaWxkTGlzdCgpIHtcclxuICAgICAgICAgICAgbGV0IHVybCA9IGAke3RoaXMuYmFzZVVybH0vbWVtYmVyL2dldENoaWxkTGlzdGA7XHJcbiAgICAgICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgICAgICBzZXNzaW9uSWQ6IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuc2Vzc2lvbklkXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuZ2V0KHVybCwgcGFyYW1zLCB0cnVlKS50aGVuKHJlcyA9PiB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gcmVzO1xyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgIH1cclxuICAgICAgICAvLyDojrflj5bnm5HmiqTkurrliJfooahcclxuICAgIHN0YXRpYyBhc3luYyBnZXRHdWFMaXN0KCkge1xyXG4gICAgICAgICAgICBsZXQgdXJsID0gYCR7dGhpcy5iYXNlVXJsfS9tZW1iZXIvZ2V0R3VhTGlzdGA7XHJcbiAgICAgICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgICAgICBzZXNzaW9uSWQ6IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuc2Vzc2lvbklkXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuZ2V0KHVybCwgcGFyYW1zLCB0cnVlKS50aGVuKHJlcyA9PiB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gcmVzO1xyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgIH1cclxuICAgICAgICAvLyDmtLvliqjlhL/nq6Xor6bmg4VcclxuICAgIHN0YXRpYyBhc3luYyBnZXRDaGlsZChpZCkge1xyXG4gICAgICAgICAgICBsZXQgdXJsID0gYCR7dGhpcy5iYXNlVXJsfS9tZW1iZXIvZ2V0Q2hpbGRgO1xyXG4gICAgICAgICAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICAgICAgICAgICAgaWQsXHJcbiAgICAgICAgICAgICAgICBzZXNzaW9uSWQ6IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuc2Vzc2lvbklkXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuZ2V0KHVybCwgcGFyYW1zLCB0cnVlKS50aGVuKHJlcyA9PiB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gcmVzO1xyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgIH1cclxuICAgICAgICAvLyDmtLvliqjnm5HmiqTkurror6bmg4VcclxuICAgIHN0YXRpYyBhc3luYyBnZXRHdWEoaWQpIHtcclxuICAgICAgICAgICAgbGV0IHVybCA9IGAke3RoaXMuYmFzZVVybH0vbWVtYmVyL2dldEd1YWA7XHJcbiAgICAgICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgICAgICBpZCxcclxuICAgICAgICAgICAgICAgIHNlc3Npb25JZDogd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5zZXNzaW9uSWRcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5nZXQodXJsLCBwYXJhbXMsIHRydWUpLnRoZW4ocmVzID0+IHtcclxuICAgICAgICAgICAgICAgIHJldHVybiByZXM7XHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vIOS/neWtmOebkeaKpOS6ulxyXG4gICAgc3RhdGljIGFzeW5jIHVwZGF0ZUd1YShvcHQpIHtcclxuICAgICAgICAgICAgbGV0IHVybCA9IGAke3RoaXMuYmFzZVVybH0vbWVtYmVyL3VwZGF0ZUd1YWA7XHJcbiAgICAgICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgICAgICAuLi5vcHQsXHJcbiAgICAgICAgICAgICAgICBzZXNzaW9uSWQ6IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuc2Vzc2lvbklkXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMucG9zdCh1cmwsIHBhcmFtcywgdHJ1ZSwgdHJ1ZSkudGhlbihyZXMgPT4ge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHJlcztcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICB9XHJcbiAgICAgICAgLy8g5L+d5a2Y5YS/56ulXHJcbiAgICBzdGF0aWMgYXN5bmMgdXBkYXRlQ2hpbGQob3B0KSB7XHJcbiAgICAgICAgICAgIGxldCB1cmwgPSBgJHt0aGlzLmJhc2VVcmx9L21lbWJlci91cGRhdGVDaGlsZGA7XHJcbiAgICAgICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgICAgICAuLi5vcHQsXHJcbiAgICAgICAgICAgICAgICBzZXNzaW9uSWQ6IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuc2Vzc2lvbklkXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMucG9zdCh1cmwsIHBhcmFtcywgdHJ1ZSwgdHJ1ZSkudGhlbihyZXMgPT4ge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHJlcztcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICB9XHJcbiAgICAgICAgLy8g5Yig6Zmk55uR5oqk5Lq6XHJcbiAgICBzdGF0aWMgYXN5bmMgZGVsR3VhKGlkKSB7XHJcbiAgICAgICAgICAgIGxldCB1cmwgPSBgJHt0aGlzLmJhc2VVcmx9L21lbWJlci9kZWxHdWFgO1xyXG4gICAgICAgICAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICAgICAgICAgICAgaWQsXHJcbiAgICAgICAgICAgICAgICBzZXNzaW9uSWQ6IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuc2Vzc2lvbklkXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMucG9zdCh1cmwsIHBhcmFtcywgdHJ1ZSwgdHJ1ZSkudGhlbihyZXMgPT4ge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHJlcztcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICB9XHJcbiAgICAgICAgLy8g5Yig6Zmk5YS/56ul5L+h5oGvXHJcbiAgICBzdGF0aWMgYXN5bmMgZGVsQ2hpbGQoaWQpIHtcclxuICAgICAgICAgICAgbGV0IHVybCA9IGAke3RoaXMuYmFzZVVybH0vbWVtYmVyL2RlbENoaWxkYDtcclxuICAgICAgICAgICAgbGV0IHBhcmFtcyA9IHtcclxuICAgICAgICAgICAgICAgIGlkLFxyXG4gICAgICAgICAgICAgICAgc2Vzc2lvbklkOiB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnNlc3Npb25JZFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLnBvc3QodXJsLCBwYXJhbXMsIHRydWUsIHRydWUpLnRoZW4ocmVzID0+IHtcclxuICAgICAgICAgICAgICAgIHJldHVybiByZXM7XHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vICMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyAg6K6i5Y2V566h55CGICAjIyMjIyMjIyMjIyMjIyMjIyMjXHJcbiAgICAgICAgLy8g55Sf5oiQ5pSv5LuY6K6i5Y2V5L+h5oGvIFxyXG4gICAgc3RhdGljIGFzeW5jIG9yZGVySW5mbyhvcHQpIHtcclxuICAgICAgICAgICAgbGV0IHVybCA9IGAke3RoaXMuYmFzZVVybH0vb3JkZXIvaW5mb2A7XHJcbiAgICAgICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgICAgICAuLi5vcHQsXHJcbiAgICAgICAgICAgICAgICBzZXNzaW9uSWQ6IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuc2Vzc2lvbklkXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMucG9zdCh1cmwsIHBhcmFtcywgdHJ1ZSwgdHJ1ZSkudGhlbihyZXMgPT4ge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHJlcztcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICB9XHJcbiAgICAgICAgLy8g5LiL5Y2VIFxyXG4gICAgc3RhdGljIGFzeW5jIG9yZGVyY29tbWl0KG9wdCkge1xyXG4gICAgICAgICAgICBsZXQgdXJsID0gYCR7dGhpcy5iYXNlVXJsfS9vcmRlci9vcmRlcmNvbW1pdGA7XHJcbiAgICAgICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgICAgICAuLi5vcHQsXHJcbiAgICAgICAgICAgICAgICBzZXNzaW9uSWQ6IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuc2Vzc2lvbklkXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMucG9zdCh1cmwsIHBhcmFtcywgdHJ1ZSwgdHJ1ZSkudGhlbihyZXMgPT4ge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHJlcztcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICB9XHJcbiAgICAgICAgLy8g5pSv5LuYIFxyXG4gICAgc3RhdGljIGFzeW5jIHd4cGF5dG9wYXkob3B0KSB7XHJcbiAgICAgICAgICAgIGxldCB1cmwgPSBgJHt0aGlzLmJhc2VVcmx9L3d4cGF5L3RvcGF5YDtcclxuICAgICAgICAgICAgbGV0IHBhcmFtcyA9IHtcclxuICAgICAgICAgICAgICAgIC4uLm9wdCxcclxuICAgICAgICAgICAgICAgIHNlc3Npb25JZDogd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5zZXNzaW9uSWRcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5wb3N0KHVybCwgcGFyYW1zLCB0cnVlLCB0cnVlKS50aGVuKHJlcyA9PiB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gcmVzO1xyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgIH1cclxuICAgICAgICAvLyDojrflj5borqLljZXliJfooahcclxuICAgIHN0YXRpYyBhc3luYyBvcmRlcnMob3B0KSB7XHJcbiAgICAgICAgICAgIGxldCB1cmwgPSBgJHt0aGlzLmJhc2VVcmx9L21lbWJlci9vcmRlcmA7XHJcbiAgICAgICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgICAgICAuLi5vcHQsXHJcbiAgICAgICAgICAgICAgICBzZXNzaW9uSWQ6IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuc2Vzc2lvbklkXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuZ2V0KHVybCwgcGFyYW1zLCB0cnVlLCB0cnVlKS50aGVuKHJlcyA9PiB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gcmVzO1xyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgIH1cclxuICAgICAgICAvLyDojrflj5borqLljZXor6bmg4VcclxuICAgIHN0YXRpYyBhc3luYyBvcmRlcmRldGFpbChpZCkge1xyXG4gICAgICAgICAgICBsZXQgdXJsID0gYCR7dGhpcy5iYXNlVXJsfS9tZW1iZXIvb3JkZXJkZXRhaWxgO1xyXG4gICAgICAgICAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICAgICAgICAgICAgaWQsXHJcbiAgICAgICAgICAgICAgICBzZXNzaW9uSWQ6IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuc2Vzc2lvbklkXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuZ2V0KHVybCwgcGFyYW1zLCB0cnVlLCB0cnVlKS50aGVuKHJlcyA9PiB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gcmVzO1xyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgIH1cclxuICAgICAgICAvLyDmiJHnmoTnoI3ku7dcclxuICAgIHN0YXRpYyBhc3luYyBiYXJnYWlucyhvcHQpIHtcclxuICAgICAgICAgICAgbGV0IHVybCA9IGAke3RoaXMuYmFzZVVybH0vbWVtYmVyL2JhcmdhaW4vbGlzdGA7XHJcbiAgICAgICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgICAgICAuLi5vcHQsXHJcbiAgICAgICAgICAgICAgICBzZXNzaW9uSWQ6IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuc2Vzc2lvbklkXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuZ2V0KHVybCwgcGFyYW1zLCB0cnVlLCB0cnVlKS50aGVuKHJlcyA9PiB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gcmVzO1xyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgIH1cclxuICAgICAgICAvLyDmiJHnmoTmi7zlm6JcclxuICAgIHN0YXRpYyBhc3luYyBwaW50dWFucyhvcHQpIHtcclxuICAgICAgICAgICAgbGV0IHVybCA9IGAke3RoaXMuYmFzZVVybH0vbWVtYmVyL3BpbnR1YW4vbGlzdGA7XHJcbiAgICAgICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgICAgICAuLi5vcHQsXHJcbiAgICAgICAgICAgICAgICBzZXNzaW9uSWQ6IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuc2Vzc2lvbklkXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuZ2V0KHVybCwgcGFyYW1zLCB0cnVlLCB0cnVlKS50aGVuKHJlcyA9PiB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gcmVzO1xyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgIH1cclxuICAgICAgICAvLyDlj5bmtojorqLljZVcclxuICAgIHN0YXRpYyBhc3luYyBjYW5jYWxvcmRlcihpZCkge1xyXG4gICAgICAgICAgICBsZXQgdXJsID0gYCR7dGhpcy5iYXNlVXJsfS9tZW1iZXIvY2FuY2Fsb3JkZXJgO1xyXG4gICAgICAgICAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICAgICAgICAgICAgaWQsXHJcbiAgICAgICAgICAgICAgICBzZXNzaW9uSWQ6IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuc2Vzc2lvbklkXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuZ2V0KHVybCwgcGFyYW1zLCB0cnVlLCB0cnVlKS50aGVuKHJlcyA9PiB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gcmVzO1xyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgIH1cclxuICAgICAgICAvLyDlj5bmtojorqLljZVcclxuICAgIHN0YXRpYyBhc3luYyBjZW50ZXIoKSB7XHJcbiAgICAgICAgbGV0IHVybCA9IGAke3RoaXMuYmFzZVVybH0vbWVtYmVyL2NlbnRlcmA7XHJcbiAgICAgICAgbGV0IHBhcmFtcyA9IHtcclxuICAgICAgICAgICAgc2Vzc2lvbklkOiB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnNlc3Npb25JZFxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdGhpcy5nZXQodXJsLCBwYXJhbXMsIHRydWUsIGZhbHNlKS50aGVuKHJlcyA9PiB7XHJcbiAgICAgICAgICAgIHJldHVybiByZXM7XHJcbiAgICAgICAgfSlcclxuICAgIH1cclxuXHJcbiAgICAvLyAjIyMg6K+E6K66XHJcbiAgICAvLyDkuIrkvKDlm77niYcgXHJcbiAgICBzdGF0aWMgdXBsb2FkRmlsZShpbWFnZV91cmwpIHtcclxuICAgICAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgICAgICAgICAgIC8vIOS4iuS8oOWbvueJh1xyXG4gICAgICAgICAgICAgICAgd3gudXBsb2FkRmlsZSh7XHJcbiAgICAgICAgICAgICAgICAgICAgdXJsOiBgJHt0aGlzLmJhc2VVcmx9L21lbWJlci91cGxvYWRGaWxlcz9zZXNzaW9uSWQ9JHt3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnNlc3Npb25JZH1gLCAvLyDku4XkuLrnpLrkvovvvIzpnZ7nnJ/lrp7nmoTmjqXlj6PlnLDlnYBcclxuICAgICAgICAgICAgICAgICAgICBmaWxlUGF0aDogaW1hZ2VfdXJsLFxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU6ICdpbWdGaWxlJyxcclxuICAgICAgICAgICAgICAgICAgICBzdWNjZXNzOiBmdW5jdGlvbihyZXMpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGRhdGEgPSBKU09OLnBhcnNlKHJlcy5kYXRhKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGRhdGEuZXJyY29kZSA9PSAyMDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmUoZGF0YS5kYXRhKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVqZWN0KGRhdGEuZXJybXNnKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICBmYWlsKGVycikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZWplY3QoZXJyKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vIOiOt+WPlnRhZ1xyXG4gICAgc3RhdGljIGFzeW5jIGNvbW1lbnRUYWcoKSB7XHJcbiAgICAgICAgICAgIGxldCB1cmwgPSBgJHt0aGlzLmJhc2VVcmx9L21lbWJlci9jb21tZW50VGFnYDtcclxuICAgICAgICAgICAgbGV0IHBhcmFtcyA9IHtcclxuICAgICAgICAgICAgICAgIHNlc3Npb25JZDogd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5zZXNzaW9uSWRcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5nZXQodXJsLCBwYXJhbXMsIHRydWUsIGZhbHNlKS50aGVuKHJlcyA9PiB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gcmVzO1xyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgIH1cclxuICAgICAgICAvL+abtOaWsOivhOiuuuWFs+azqFxyXG4gICAgc3RhdGljIGFzeW5jIGRvbGlrZShvcHQpIHtcclxuICAgICAgICAgICAgbGV0IHVybCA9IGAke3RoaXMuYmFzZVVybH0vbWVtYmVyL2RvbGlrZWA7XHJcbiAgICAgICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgICAgICBzZXNzaW9uSWQ6IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuc2Vzc2lvbklkLFxyXG4gICAgICAgICAgICAgICAgLi4ub3B0XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuZ2V0KHVybCwgcGFyYW1zLCB0cnVlLCBmYWxzZSkudGhlbihyZXMgPT4ge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHJlcztcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICB9XHJcbiAgICAgICAgLy8g5o+Q5Lqk6K+E6K66XHJcbiAgICBzdGF0aWMgYXN5bmMgc2F2ZWNvbW1lbihvcHQpIHtcclxuICAgICAgICAgICAgbGV0IHVybCA9IGAke3RoaXMuYmFzZVVybH0vbWVtYmVyL3NhdmVjb21tZW50YDtcclxuICAgICAgICAgICAgbGV0IHBhcmFtcyA9IHtcclxuICAgICAgICAgICAgICAgIC4uLm9wdCxcclxuICAgICAgICAgICAgICAgIHNlc3Npb25JZDogd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5zZXNzaW9uSWRcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5wb3N0KHVybCwgcGFyYW1zLCB0cnVlLCB0cnVlKS50aGVuKHJlcyA9PiB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gcmVzO1xyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgIH1cclxuICAgICAgICAvLyDojrflj5blrrbplb/lv4Plo7BcclxuICAgIHN0YXRpYyBhc3luYyBhc3BpcmF0aW9ucyhvcHQpIHtcclxuICAgICAgICAgICAgbGV0IHVybCA9IGAke3RoaXMuYmFzZVVybH0vY29tbWVudC9hc3BpcmF0aW9uc2A7XHJcbiAgICAgICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgICAgICAuLi5vcHQsXHJcbiAgICAgICAgICAgICAgICBzZXNzaW9uSWQ6IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuc2Vzc2lvbklkXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuZ2V0KHVybCwgcGFyYW1zLCB0cnVlLCBmYWxzZSkudGhlbihyZXMgPT4ge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHJlcztcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICB9XHJcbiAgICAgICAgLy8g6I635Y+W5YiG5Lqr5bCP56iL5bqP56CBXHJcbiAgICBzdGF0aWMgYXN5bmMgZ2V0UG9zdGVyKG9wdCkge1xyXG4gICAgICAgIGxldCB1cmwgPSBgJHt0aGlzLmJhc2VVcmx9L3Bvc3Rlci9nZXRQb3N0ZXJgO1xyXG4gICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgIC4uLm9wdCxcclxuICAgICAgICAgICAgc2Vzc2lvbklkOiB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnNlc3Npb25JZFxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdGhpcy5wb3N0KHVybCwgcGFyYW1zLCB0cnVlLCBmYWxzZSkudGhlbihyZXMgPT4ge1xyXG4gICAgICAgICAgICByZXR1cm4gcmVzO1xyXG4gICAgICAgIH0pXHJcbiAgICB9XHJcbn0iXX0=