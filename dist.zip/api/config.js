'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = undefined;

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _base2 = require('./base.js');

var _base3 = _interopRequireDefault(_base2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var config = function (_base) {
    _inherits(config, _base);

    function config() {
        _classCallCheck(this, config);

        return _possibleConstructorReturn(this, (config.__proto__ || Object.getPrototypeOf(config)).apply(this, arguments));
    }

    _createClass(config, null, [{
        key: 'getIndex',

        // 获取首页数据
        value: function () {
            var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(opt) {
                var location, url, params;
                return regeneratorRuntime.wrap(function _callee$(_context) {
                    while (1) {
                        switch (_context.prev = _context.next) {
                            case 0:
                                _context.next = 2;
                                return this.getLocation();

                            case 2:
                                location = _context.sent;

                                if (!(!location && !_wepy2.default.$instance.globalData.cityCode)) {
                                    _context.next = 6;
                                    break;
                                }

                                _wepy2.default.redirectTo({ url: './address' });
                                return _context.abrupt('return');

                            case 6:
                                url = this.baseUrl + '/index';
                                params = _extends({
                                    location: location,
                                    cityCode: _wepy2.default.$instance.globalData.cityCode
                                }, opt);
                                return _context.abrupt('return', this.post(url, params, true).then(function (res) {
                                    return res;
                                }));

                            case 9:
                            case 'end':
                                return _context.stop();
                        }
                    }
                }, _callee, this);
            }));

            function getIndex(_x) {
                return _ref.apply(this, arguments);
            }

            return getIndex;
        }()
    }, {
        key: 'citys',
        value: function () {
            var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
                var url, params;
                return regeneratorRuntime.wrap(function _callee2$(_context2) {
                    while (1) {
                        switch (_context2.prev = _context2.next) {
                            case 0:
                                url = this.baseUrl + '/citys';
                                params = {};
                                return _context2.abrupt('return', this.get(url, params, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context2.stop();
                        }
                    }
                }, _callee2, this);
            }));

            function citys() {
                return _ref2.apply(this, arguments);
            }

            return citys;
        }()
    }, {
        key: 'getCourses',
        value: function () {
            var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(opt) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee3$(_context3) {
                    while (1) {
                        switch (_context3.prev = _context3.next) {
                            case 0:
                                url = this.baseUrl + '/course/getCourses';
                                params = _extends({
                                    cityCode: _wepy2.default.$instance.globalData.cityCode
                                }, opt);
                                return _context3.abrupt('return', this.get(url, params, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context3.stop();
                        }
                    }
                }, _callee3, this);
            }));

            function getCourses(_x2) {
                return _ref3.apply(this, arguments);
            }

            return getCourses;
        }()
    }, {
        key: 'getCompanions',
        value: function () {
            var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4(courseId) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee4$(_context4) {
                    while (1) {
                        switch (_context4.prev = _context4.next) {
                            case 0:
                                url = this.baseUrl + '/course/getCompanions';
                                params = {
                                    courseId: courseId,
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                };
                                return _context4.abrupt('return', this.get(url, params, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context4.stop();
                        }
                    }
                }, _callee4, this);
            }));

            function getCompanions(_x3) {
                return _ref4.apply(this, arguments);
            }

            return getCompanions;
        }()
    }, {
        key: 'getCourseInfo',
        value: function () {
            var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5(id) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee5$(_context5) {
                    while (1) {
                        switch (_context5.prev = _context5.next) {
                            case 0:
                                url = this.baseUrl + '/course/getInfo';
                                params = {
                                    id: id
                                };
                                return _context5.abrupt('return', this.get(url, params, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context5.stop();
                        }
                    }
                }, _callee5, this);
            }));

            function getCourseInfo(_x4) {
                return _ref5.apply(this, arguments);
            }

            return getCourseInfo;
        }()
        // 搜索

    }, {
        key: 'search',
        value: function () {
            var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee6(opt) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee6$(_context6) {
                    while (1) {
                        switch (_context6.prev = _context6.next) {
                            case 0:
                                url = this.baseUrl + '/course/search';
                                params = _extends({}, opt);
                                return _context6.abrupt('return', this.get(url, params, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context6.stop();
                        }
                    }
                }, _callee6, this);
            }));

            function search(_x5) {
                return _ref6.apply(this, arguments);
            }

            return search;
        }()
        // 获取评论列表

    }, {
        key: 'comments',
        value: function () {
            var _ref7 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee7(opt) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee7$(_context7) {
                    while (1) {
                        switch (_context7.prev = _context7.next) {
                            case 0:
                                url = this.baseUrl + '/comment/list';
                                params = _extends({}, opt);
                                return _context7.abrupt('return', this.get(url, params, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context7.stop();
                        }
                    }
                }, _callee7, this);
            }));

            function comments(_x6) {
                return _ref7.apply(this, arguments);
            }

            return comments;
        }()
        // 发起砍价

    }, {
        key: 'regBargain',
        value: function () {
            var _ref8 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee8(opt) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee8$(_context8) {
                    while (1) {
                        switch (_context8.prev = _context8.next) {
                            case 0:
                                url = this.baseUrl + '/bargain/regBargain';
                                params = _extends({
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                }, opt);
                                return _context8.abrupt('return', this.post(url, params, true, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context8.stop();
                        }
                    }
                }, _callee8, this);
            }));

            function regBargain(_x7) {
                return _ref8.apply(this, arguments);
            }

            return regBargain;
        }()
        // 帮砍价

    }, {
        key: 'helpBargain',
        value: function () {
            var _ref9 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee9(regId) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee9$(_context9) {
                    while (1) {
                        switch (_context9.prev = _context9.next) {
                            case 0:
                                url = this.baseUrl + '/bargain/helpBargain';
                                params = {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId,
                                    regId: regId
                                };
                                return _context9.abrupt('return', this.post(url, params, true, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context9.stop();
                        }
                    }
                }, _callee9, this);
            }));

            function helpBargain(_x8) {
                return _ref9.apply(this, arguments);
            }

            return helpBargain;
        }()
        // 砍价详情

    }, {
        key: 'toCutDetai',
        value: function () {
            var _ref10 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee10(regId) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee10$(_context10) {
                    while (1) {
                        switch (_context10.prev = _context10.next) {
                            case 0:
                                url = this.baseUrl + '/bargain/toCutDetai';
                                params = {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId,
                                    regId: regId
                                };
                                return _context10.abrupt('return', this.get(url, params, true, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context10.stop();
                        }
                    }
                }, _callee10, this);
            }));

            function toCutDetai(_x9) {
                return _ref10.apply(this, arguments);
            }

            return toCutDetai;
        }()
        // 拼团详情

    }, {
        key: 'pintuanDetai',
        value: function () {
            var _ref11 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee11(activityId) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee11$(_context11) {
                    while (1) {
                        switch (_context11.prev = _context11.next) {
                            case 0:
                                url = this.baseUrl + '/pintuan/share/detai';
                                params = {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId,
                                    activityId: activityId
                                };
                                return _context11.abrupt('return', this.get(url, params, true, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context11.stop();
                        }
                    }
                }, _callee11, this);
            }));

            function pintuanDetai(_x10) {
                return _ref11.apply(this, arguments);
            }

            return pintuanDetai;
        }()
        // ########################  人员信息管理  ###################
        // 获取儿童列表

    }, {
        key: 'getChildList',
        value: function () {
            var _ref12 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee12() {
                var url, params;
                return regeneratorRuntime.wrap(function _callee12$(_context12) {
                    while (1) {
                        switch (_context12.prev = _context12.next) {
                            case 0:
                                url = this.baseUrl + '/member/getChildList';
                                params = {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                };
                                return _context12.abrupt('return', this.get(url, params, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context12.stop();
                        }
                    }
                }, _callee12, this);
            }));

            function getChildList() {
                return _ref12.apply(this, arguments);
            }

            return getChildList;
        }()
        // 获取监护人列表

    }, {
        key: 'getGuaList',
        value: function () {
            var _ref13 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee13() {
                var url, params;
                return regeneratorRuntime.wrap(function _callee13$(_context13) {
                    while (1) {
                        switch (_context13.prev = _context13.next) {
                            case 0:
                                url = this.baseUrl + '/member/getGuaList';
                                params = {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                };
                                return _context13.abrupt('return', this.get(url, params, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context13.stop();
                        }
                    }
                }, _callee13, this);
            }));

            function getGuaList() {
                return _ref13.apply(this, arguments);
            }

            return getGuaList;
        }()
        // 活动儿童详情

    }, {
        key: 'getChild',
        value: function () {
            var _ref14 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee14(id) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee14$(_context14) {
                    while (1) {
                        switch (_context14.prev = _context14.next) {
                            case 0:
                                url = this.baseUrl + '/member/getChild';
                                params = {
                                    id: id,
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                };
                                return _context14.abrupt('return', this.get(url, params, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context14.stop();
                        }
                    }
                }, _callee14, this);
            }));

            function getChild(_x11) {
                return _ref14.apply(this, arguments);
            }

            return getChild;
        }()
        // 活动监护人详情

    }, {
        key: 'getGua',
        value: function () {
            var _ref15 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee15(id) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee15$(_context15) {
                    while (1) {
                        switch (_context15.prev = _context15.next) {
                            case 0:
                                url = this.baseUrl + '/member/getGua';
                                params = {
                                    id: id,
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                };
                                return _context15.abrupt('return', this.get(url, params, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context15.stop();
                        }
                    }
                }, _callee15, this);
            }));

            function getGua(_x12) {
                return _ref15.apply(this, arguments);
            }

            return getGua;
        }()
        // 保存监护人

    }, {
        key: 'updateGua',
        value: function () {
            var _ref16 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee16(opt) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee16$(_context16) {
                    while (1) {
                        switch (_context16.prev = _context16.next) {
                            case 0:
                                url = this.baseUrl + '/member/updateGua';
                                params = _extends({}, opt, {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                });
                                return _context16.abrupt('return', this.post(url, params, true, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context16.stop();
                        }
                    }
                }, _callee16, this);
            }));

            function updateGua(_x13) {
                return _ref16.apply(this, arguments);
            }

            return updateGua;
        }()
        // 保存儿童

    }, {
        key: 'updateChild',
        value: function () {
            var _ref17 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee17(opt) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee17$(_context17) {
                    while (1) {
                        switch (_context17.prev = _context17.next) {
                            case 0:
                                url = this.baseUrl + '/member/updateChild';
                                params = _extends({}, opt, {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                });
                                return _context17.abrupt('return', this.post(url, params, true, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context17.stop();
                        }
                    }
                }, _callee17, this);
            }));

            function updateChild(_x14) {
                return _ref17.apply(this, arguments);
            }

            return updateChild;
        }()
        // 删除监护人

    }, {
        key: 'delGua',
        value: function () {
            var _ref18 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee18(id) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee18$(_context18) {
                    while (1) {
                        switch (_context18.prev = _context18.next) {
                            case 0:
                                url = this.baseUrl + '/member/delGua';
                                params = {
                                    id: id,
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                };
                                return _context18.abrupt('return', this.post(url, params, true, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context18.stop();
                        }
                    }
                }, _callee18, this);
            }));

            function delGua(_x15) {
                return _ref18.apply(this, arguments);
            }

            return delGua;
        }()
        // 删除儿童信息

    }, {
        key: 'delChild',
        value: function () {
            var _ref19 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee19(id) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee19$(_context19) {
                    while (1) {
                        switch (_context19.prev = _context19.next) {
                            case 0:
                                url = this.baseUrl + '/member/delChild';
                                params = {
                                    id: id,
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                };
                                return _context19.abrupt('return', this.post(url, params, true, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context19.stop();
                        }
                    }
                }, _callee19, this);
            }));

            function delChild(_x16) {
                return _ref19.apply(this, arguments);
            }

            return delChild;
        }()
        // ########################  订单管理  ###################
        // 生成支付订单信息 

    }, {
        key: 'orderInfo',
        value: function () {
            var _ref20 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee20(opt) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee20$(_context20) {
                    while (1) {
                        switch (_context20.prev = _context20.next) {
                            case 0:
                                url = this.baseUrl + '/order/info';
                                params = _extends({}, opt, {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                });
                                return _context20.abrupt('return', this.post(url, params, true, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context20.stop();
                        }
                    }
                }, _callee20, this);
            }));

            function orderInfo(_x17) {
                return _ref20.apply(this, arguments);
            }

            return orderInfo;
        }()
        // 下单 

    }, {
        key: 'ordercommit',
        value: function () {
            var _ref21 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee21(opt) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee21$(_context21) {
                    while (1) {
                        switch (_context21.prev = _context21.next) {
                            case 0:
                                url = this.baseUrl + '/order/ordercommit';
                                params = _extends({}, opt, {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                });
                                return _context21.abrupt('return', this.post(url, params, true, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context21.stop();
                        }
                    }
                }, _callee21, this);
            }));

            function ordercommit(_x18) {
                return _ref21.apply(this, arguments);
            }

            return ordercommit;
        }()
        // 支付 

    }, {
        key: 'wxpaytopay',
        value: function () {
            var _ref22 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee22(opt) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee22$(_context22) {
                    while (1) {
                        switch (_context22.prev = _context22.next) {
                            case 0:
                                url = this.baseUrl + '/wxpay/topay';
                                params = _extends({}, opt, {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                });
                                return _context22.abrupt('return', this.post(url, params, true, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context22.stop();
                        }
                    }
                }, _callee22, this);
            }));

            function wxpaytopay(_x19) {
                return _ref22.apply(this, arguments);
            }

            return wxpaytopay;
        }()
        // 获取订单列表

    }, {
        key: 'orders',
        value: function () {
            var _ref23 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee23(opt) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee23$(_context23) {
                    while (1) {
                        switch (_context23.prev = _context23.next) {
                            case 0:
                                url = this.baseUrl + '/member/order';
                                params = _extends({}, opt, {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                });
                                return _context23.abrupt('return', this.get(url, params, true, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context23.stop();
                        }
                    }
                }, _callee23, this);
            }));

            function orders(_x20) {
                return _ref23.apply(this, arguments);
            }

            return orders;
        }()
        // 获取订单详情

    }, {
        key: 'orderdetail',
        value: function () {
            var _ref24 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee24(id) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee24$(_context24) {
                    while (1) {
                        switch (_context24.prev = _context24.next) {
                            case 0:
                                url = this.baseUrl + '/member/orderdetail';
                                params = {
                                    id: id,
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                };
                                return _context24.abrupt('return', this.get(url, params, true, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context24.stop();
                        }
                    }
                }, _callee24, this);
            }));

            function orderdetail(_x21) {
                return _ref24.apply(this, arguments);
            }

            return orderdetail;
        }()
        // 我的砍价

    }, {
        key: 'bargains',
        value: function () {
            var _ref25 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee25(opt) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee25$(_context25) {
                    while (1) {
                        switch (_context25.prev = _context25.next) {
                            case 0:
                                url = this.baseUrl + '/member/bargain/list';
                                params = _extends({}, opt, {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                });
                                return _context25.abrupt('return', this.get(url, params, true, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context25.stop();
                        }
                    }
                }, _callee25, this);
            }));

            function bargains(_x22) {
                return _ref25.apply(this, arguments);
            }

            return bargains;
        }()
        // 我的拼团

    }, {
        key: 'pintuans',
        value: function () {
            var _ref26 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee26(opt) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee26$(_context26) {
                    while (1) {
                        switch (_context26.prev = _context26.next) {
                            case 0:
                                url = this.baseUrl + '/member/pintuan/list';
                                params = _extends({}, opt, {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                });
                                return _context26.abrupt('return', this.get(url, params, true, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context26.stop();
                        }
                    }
                }, _callee26, this);
            }));

            function pintuans(_x23) {
                return _ref26.apply(this, arguments);
            }

            return pintuans;
        }()
        // 取消订单

    }, {
        key: 'cancalorder',
        value: function () {
            var _ref27 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee27(id) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee27$(_context27) {
                    while (1) {
                        switch (_context27.prev = _context27.next) {
                            case 0:
                                url = this.baseUrl + '/member/cancalorder';
                                params = {
                                    id: id,
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                };
                                return _context27.abrupt('return', this.get(url, params, true, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context27.stop();
                        }
                    }
                }, _callee27, this);
            }));

            function cancalorder(_x24) {
                return _ref27.apply(this, arguments);
            }

            return cancalorder;
        }()
        // 取消订单

    }, {
        key: 'center',
        value: function () {
            var _ref28 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee28() {
                var url, params;
                return regeneratorRuntime.wrap(function _callee28$(_context28) {
                    while (1) {
                        switch (_context28.prev = _context28.next) {
                            case 0:
                                url = this.baseUrl + '/member/center';
                                params = {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                };
                                return _context28.abrupt('return', this.get(url, params, true, false).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context28.stop();
                        }
                    }
                }, _callee28, this);
            }));

            function center() {
                return _ref28.apply(this, arguments);
            }

            return center;
        }()

        // ### 评论
        // 上传图片 

    }, {
        key: 'uploadFile',
        value: function uploadFile(image_url) {
            var _this2 = this;

            return new Promise(function (resolve, reject) {
                // 上传图片
                wx.uploadFile({
                    url: _this2.baseUrl + '/member/uploadFiles?sessionId=' + _wepy2.default.$instance.globalData.sessionId, // 仅为示例，非真实的接口地址
                    filePath: image_url,
                    name: 'imgFile',
                    success: function success(res) {
                        var data = JSON.parse(res.data);
                        if (data.errcode == 200) {
                            resolve(data.data);
                        } else {
                            reject(data.errmsg);
                        }
                    },
                    fail: function fail(err) {
                        reject(err);
                    }
                });
            });
        }
        // 获取tag

    }, {
        key: 'commentTag',
        value: function () {
            var _ref29 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee29() {
                var url, params;
                return regeneratorRuntime.wrap(function _callee29$(_context29) {
                    while (1) {
                        switch (_context29.prev = _context29.next) {
                            case 0:
                                url = this.baseUrl + '/member/commentTag';
                                params = {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                };
                                return _context29.abrupt('return', this.get(url, params, true, false).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context29.stop();
                        }
                    }
                }, _callee29, this);
            }));

            function commentTag() {
                return _ref29.apply(this, arguments);
            }

            return commentTag;
        }()
        //更新评论关注

    }, {
        key: 'dolike',
        value: function () {
            var _ref30 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee30(opt) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee30$(_context30) {
                    while (1) {
                        switch (_context30.prev = _context30.next) {
                            case 0:
                                url = this.baseUrl + '/member/dolike';
                                params = _extends({
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                }, opt);
                                return _context30.abrupt('return', this.get(url, params, true, false).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context30.stop();
                        }
                    }
                }, _callee30, this);
            }));

            function dolike(_x25) {
                return _ref30.apply(this, arguments);
            }

            return dolike;
        }()
        // 提交评论

    }, {
        key: 'savecommen',
        value: function () {
            var _ref31 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee31(opt) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee31$(_context31) {
                    while (1) {
                        switch (_context31.prev = _context31.next) {
                            case 0:
                                url = this.baseUrl + '/member/savecomment';
                                params = _extends({}, opt, {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                });
                                return _context31.abrupt('return', this.post(url, params, true, true).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context31.stop();
                        }
                    }
                }, _callee31, this);
            }));

            function savecommen(_x26) {
                return _ref31.apply(this, arguments);
            }

            return savecommen;
        }()
        // 获取家长心声

    }, {
        key: 'aspirations',
        value: function () {
            var _ref32 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee32(opt) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee32$(_context32) {
                    while (1) {
                        switch (_context32.prev = _context32.next) {
                            case 0:
                                url = this.baseUrl + '/comment/aspirations';
                                params = _extends({}, opt, {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                });
                                return _context32.abrupt('return', this.get(url, params, true, false).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context32.stop();
                        }
                    }
                }, _callee32, this);
            }));

            function aspirations(_x27) {
                return _ref32.apply(this, arguments);
            }

            return aspirations;
        }()
        // 获取分享小程序码

    }, {
        key: 'getUnlimited',
        value: function () {
            var _ref33 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee33(opt) {
                var url, params;
                return regeneratorRuntime.wrap(function _callee33$(_context33) {
                    while (1) {
                        switch (_context33.prev = _context33.next) {
                            case 0:
                                url = this.baseUrl + '/qr/getUnlimited';
                                params = _extends({}, opt, {
                                    sessionId: _wepy2.default.$instance.globalData.sessionId
                                });
                                return _context33.abrupt('return', this.get(url, params, true, false).then(function (res) {
                                    return res;
                                }));

                            case 3:
                            case 'end':
                                return _context33.stop();
                        }
                    }
                }, _callee33, this);
            }));

            function getUnlimited(_x28) {
                return _ref33.apply(this, arguments);
            }

            return getUnlimited;
        }()
    }]);

    return config;
}(_base3.default);

exports.default = config;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbmZpZy5qcyJdLCJuYW1lcyI6WyJjb25maWciLCJvcHQiLCJnZXRMb2NhdGlvbiIsImxvY2F0aW9uIiwid2VweSIsIiRpbnN0YW5jZSIsImdsb2JhbERhdGEiLCJjaXR5Q29kZSIsInJlZGlyZWN0VG8iLCJ1cmwiLCJiYXNlVXJsIiwicGFyYW1zIiwicG9zdCIsInRoZW4iLCJyZXMiLCJnZXQiLCJjb3Vyc2VJZCIsInNlc3Npb25JZCIsImlkIiwicmVnSWQiLCJhY3Rpdml0eUlkIiwiaW1hZ2VfdXJsIiwiUHJvbWlzZSIsInJlc29sdmUiLCJyZWplY3QiLCJ3eCIsInVwbG9hZEZpbGUiLCJmaWxlUGF0aCIsIm5hbWUiLCJzdWNjZXNzIiwiZGF0YSIsIkpTT04iLCJwYXJzZSIsImVycmNvZGUiLCJlcnJtc2ciLCJmYWlsIiwiZXJyIiwiYmFzZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7QUFBQTs7OztBQUNBOzs7Ozs7Ozs7Ozs7OztJQUVxQkEsTTs7Ozs7Ozs7Ozs7O0FBQ2pCOztnR0FDc0JDLEc7Ozs7Ozs7dUNBQ0csS0FBS0MsV0FBTCxFOzs7QUFBakJDLHdDOztzQ0FFQSxDQUFDQSxRQUFELElBQWEsQ0FBQ0MsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCQyxROzs7OztBQUN4Q0gsK0NBQUtJLFVBQUwsQ0FBZ0IsRUFBRUMsS0FBSyxXQUFQLEVBQWhCOzs7O0FBR0FBLG1DLEdBQVMsS0FBS0MsTztBQUNkQyxzQztBQUNBUixzRDtBQUNBSSw4Q0FBVUgsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCQzttQ0FDakNOLEc7aUVBRUEsS0FBS1csSUFBTCxDQUFVSCxHQUFWLEVBQWVFLE1BQWYsRUFBdUIsSUFBdkIsRUFBNkJFLElBQTdCLENBQWtDLGVBQU87QUFDNUMsMkNBQU9DLEdBQVA7QUFDSCxpQ0FGTSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBS0hMLG1DLEdBQVMsS0FBS0MsTztBQUNkQyxzQyxHQUFTLEU7a0VBQ04sS0FBS0ksR0FBTCxDQUFTTixHQUFULEVBQWNFLE1BQWQsRUFBc0IsSUFBdEIsRUFBNEJFLElBQTVCLENBQWlDLGVBQU87QUFDM0MsMkNBQU9DLEdBQVA7QUFDSCxpQ0FGTSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O2tHQUlhYixHOzs7Ozs7QUFDaEJRLG1DLEdBQVMsS0FBS0MsTztBQUNkQyxzQztBQUNBSiw4Q0FBVUgsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCQzttQ0FDakNOLEc7a0VBRUEsS0FBS2MsR0FBTCxDQUFTTixHQUFULEVBQWNFLE1BQWQsRUFBc0IsSUFBdEIsRUFBNEJFLElBQTVCLENBQWlDLGVBQU87QUFDM0MsMkNBQU9DLEdBQVA7QUFDSCxpQ0FGTSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O2tHQUtnQkUsUTs7Ozs7O0FBQ25CUCxtQyxHQUFTLEtBQUtDLE87QUFDZEMsc0MsR0FBUztBQUNUSyxzREFEUztBQUVUQywrQ0FBV2IsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCVztBQUY1QixpQztrRUFJTixLQUFLRixHQUFMLENBQVNOLEdBQVQsRUFBY0UsTUFBZCxFQUFzQixJQUF0QixFQUE0QkUsSUFBNUIsQ0FBaUMsZUFBTztBQUMzQywyQ0FBT0MsR0FBUDtBQUNILGlDQUZNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7a0dBS2dCSSxFOzs7Ozs7QUFDbkJULG1DLEdBQVMsS0FBS0MsTztBQUNkQyxzQyxHQUFTO0FBQ1RPO0FBRFMsaUM7a0VBR04sS0FBS0gsR0FBTCxDQUFTTixHQUFULEVBQWNFLE1BQWQsRUFBc0IsSUFBdEIsRUFBNEJFLElBQTVCLENBQWlDLGVBQU87QUFDM0MsMkNBQU9DLEdBQVA7QUFDSCxpQ0FGTSxDOzs7Ozs7Ozs7Ozs7Ozs7O0FBSVg7Ozs7O2tHQUNvQmIsRzs7Ozs7O0FBQ1pRLG1DLEdBQVMsS0FBS0MsTztBQUNkQyxzQyxnQkFDR1YsRztrRUFFQSxLQUFLYyxHQUFMLENBQVNOLEdBQVQsRUFBY0UsTUFBZCxFQUFzQixJQUF0QixFQUE0QkUsSUFBNUIsQ0FBaUMsZUFBTztBQUMzQywyQ0FBT0MsR0FBUDtBQUNILGlDQUZNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJWDs7Ozs7a0dBQ3NCYixHOzs7Ozs7QUFDZFEsbUMsR0FBUyxLQUFLQyxPO0FBQ2RDLHNDLGdCQUNHVixHO2tFQUVBLEtBQUtjLEdBQUwsQ0FBU04sR0FBVCxFQUFjRSxNQUFkLEVBQXNCLElBQXRCLEVBQTRCRSxJQUE1QixDQUFpQyxlQUFPO0FBQzNDLDJDQUFPQyxHQUFQO0FBQ0gsaUNBRk0sQzs7Ozs7Ozs7Ozs7Ozs7OztBQUlYOzs7OztrR0FDd0JiLEc7Ozs7OztBQUNoQlEsbUMsR0FBUyxLQUFLQyxPO0FBQ2RDLHNDO0FBQ0FNLCtDQUFXYixlQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJXO21DQUNsQ2hCLEc7a0VBRUEsS0FBS1csSUFBTCxDQUFVSCxHQUFWLEVBQWVFLE1BQWYsRUFBdUIsSUFBdkIsRUFBNEIsSUFBNUIsRUFBa0NFLElBQWxDLENBQXVDLGVBQU87QUFDakQsMkNBQU9DLEdBQVA7QUFDSCxpQ0FGTSxDOzs7Ozs7Ozs7Ozs7Ozs7O0FBSVg7Ozs7O2tHQUN5QkssSzs7Ozs7O0FBQ2pCVixtQyxHQUFTLEtBQUtDLE87QUFDZEMsc0MsR0FBUztBQUNUTSwrQ0FBV2IsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCVyxTQUQ1QjtBQUVURTtBQUZTLGlDO2tFQUlOLEtBQUtQLElBQUwsQ0FBVUgsR0FBVixFQUFlRSxNQUFmLEVBQXVCLElBQXZCLEVBQTRCLElBQTVCLEVBQWtDRSxJQUFsQyxDQUF1QyxlQUFPO0FBQ2pELDJDQUFPQyxHQUFQO0FBQ0gsaUNBRk0sQzs7Ozs7Ozs7Ozs7Ozs7OztBQUlYOzs7OztvR0FDd0JLLEs7Ozs7OztBQUNoQlYsbUMsR0FBUyxLQUFLQyxPO0FBQ2RDLHNDLEdBQVM7QUFDVE0sK0NBQVdiLGVBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQlcsU0FENUI7QUFFVEU7QUFGUyxpQzttRUFJTixLQUFLSixHQUFMLENBQVNOLEdBQVQsRUFBY0UsTUFBZCxFQUFzQixJQUF0QixFQUEyQixJQUEzQixFQUFpQ0UsSUFBakMsQ0FBc0MsZUFBTztBQUNoRCwyQ0FBT0MsR0FBUDtBQUNILGlDQUZNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJWDs7Ozs7b0dBQzBCTSxVOzs7Ozs7QUFDbEJYLG1DLEdBQVMsS0FBS0MsTztBQUNkQyxzQyxHQUFTO0FBQ1RNLCtDQUFXYixlQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJXLFNBRDVCO0FBRVRHO0FBRlMsaUM7bUVBSU4sS0FBS0wsR0FBTCxDQUFTTixHQUFULEVBQWNFLE1BQWQsRUFBc0IsSUFBdEIsRUFBMkIsSUFBM0IsRUFBaUNFLElBQWpDLENBQXNDLGVBQU87QUFDaEQsMkNBQU9DLEdBQVA7QUFDSCxpQ0FGTSxDOzs7Ozs7Ozs7Ozs7Ozs7O0FBSVg7QUFDQTs7Ozs7Ozs7Ozs7QUFFUUwsbUMsR0FBUyxLQUFLQyxPO0FBQ2RDLHNDLEdBQVM7QUFDVE0sK0NBQVdiLGVBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQlc7QUFENUIsaUM7bUVBR04sS0FBS0YsR0FBTCxDQUFTTixHQUFULEVBQWNFLE1BQWQsRUFBc0IsSUFBdEIsRUFBNEJFLElBQTVCLENBQWlDLGVBQU87QUFDM0MsMkNBQU9DLEdBQVA7QUFDSCxpQ0FGTSxDOzs7Ozs7Ozs7Ozs7Ozs7O0FBSVg7Ozs7Ozs7Ozs7O0FBRVFMLG1DLEdBQVMsS0FBS0MsTztBQUNkQyxzQyxHQUFTO0FBQ1RNLCtDQUFXYixlQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJXO0FBRDVCLGlDO21FQUdOLEtBQUtGLEdBQUwsQ0FBU04sR0FBVCxFQUFjRSxNQUFkLEVBQXNCLElBQXRCLEVBQTRCRSxJQUE1QixDQUFpQyxlQUFPO0FBQzNDLDJDQUFPQyxHQUFQO0FBQ0gsaUNBRk0sQzs7Ozs7Ozs7Ozs7Ozs7OztBQUlYOzs7OztvR0FDc0JJLEU7Ozs7OztBQUNkVCxtQyxHQUFTLEtBQUtDLE87QUFDZEMsc0MsR0FBUztBQUNUTywwQ0FEUztBQUVURCwrQ0FBV2IsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCVztBQUY1QixpQzttRUFJTixLQUFLRixHQUFMLENBQVNOLEdBQVQsRUFBY0UsTUFBZCxFQUFzQixJQUF0QixFQUE0QkUsSUFBNUIsQ0FBaUMsZUFBTztBQUMzQywyQ0FBT0MsR0FBUDtBQUNILGlDQUZNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJWDs7Ozs7b0dBQ29CSSxFOzs7Ozs7QUFDWlQsbUMsR0FBUyxLQUFLQyxPO0FBQ2RDLHNDLEdBQVM7QUFDVE8sMENBRFM7QUFFVEQsK0NBQVdiLGVBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQlc7QUFGNUIsaUM7bUVBSU4sS0FBS0YsR0FBTCxDQUFTTixHQUFULEVBQWNFLE1BQWQsRUFBc0IsSUFBdEIsRUFBNEJFLElBQTVCLENBQWlDLGVBQU87QUFDM0MsMkNBQU9DLEdBQVA7QUFDSCxpQ0FGTSxDOzs7Ozs7Ozs7Ozs7Ozs7O0FBSVg7Ozs7O29HQUN1QmIsRzs7Ozs7O0FBQ2ZRLG1DLEdBQVMsS0FBS0MsTztBQUNkQyxzQyxnQkFDR1YsRztBQUNIZ0IsK0NBQVdiLGVBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQlc7O21FQUVsQyxLQUFLTCxJQUFMLENBQVVILEdBQVYsRUFBZUUsTUFBZixFQUF1QixJQUF2QixFQUE2QixJQUE3QixFQUFtQ0UsSUFBbkMsQ0FBd0MsZUFBTztBQUNsRCwyQ0FBT0MsR0FBUDtBQUNILGlDQUZNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJWDs7Ozs7b0dBQ3lCYixHOzs7Ozs7QUFDakJRLG1DLEdBQVMsS0FBS0MsTztBQUNkQyxzQyxnQkFDR1YsRztBQUNIZ0IsK0NBQVdiLGVBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQlc7O21FQUVsQyxLQUFLTCxJQUFMLENBQVVILEdBQVYsRUFBZUUsTUFBZixFQUF1QixJQUF2QixFQUE2QixJQUE3QixFQUFtQ0UsSUFBbkMsQ0FBd0MsZUFBTztBQUNsRCwyQ0FBT0MsR0FBUDtBQUNILGlDQUZNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJWDs7Ozs7b0dBQ29CSSxFOzs7Ozs7QUFDWlQsbUMsR0FBUyxLQUFLQyxPO0FBQ2RDLHNDLEdBQVM7QUFDVE8sMENBRFM7QUFFVEQsK0NBQVdiLGVBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQlc7QUFGNUIsaUM7bUVBSU4sS0FBS0wsSUFBTCxDQUFVSCxHQUFWLEVBQWVFLE1BQWYsRUFBdUIsSUFBdkIsRUFBNkIsSUFBN0IsRUFBbUNFLElBQW5DLENBQXdDLGVBQU87QUFDbEQsMkNBQU9DLEdBQVA7QUFDSCxpQ0FGTSxDOzs7Ozs7Ozs7Ozs7Ozs7O0FBSVg7Ozs7O29HQUNzQkksRTs7Ozs7O0FBQ2RULG1DLEdBQVMsS0FBS0MsTztBQUNkQyxzQyxHQUFTO0FBQ1RPLDBDQURTO0FBRVRELCtDQUFXYixlQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJXO0FBRjVCLGlDO21FQUlOLEtBQUtMLElBQUwsQ0FBVUgsR0FBVixFQUFlRSxNQUFmLEVBQXVCLElBQXZCLEVBQTZCLElBQTdCLEVBQW1DRSxJQUFuQyxDQUF3QyxlQUFPO0FBQ2xELDJDQUFPQyxHQUFQO0FBQ0gsaUNBRk0sQzs7Ozs7Ozs7Ozs7Ozs7OztBQUlYO0FBQ0E7Ozs7O29HQUN1QmIsRzs7Ozs7O0FBQ2ZRLG1DLEdBQVMsS0FBS0MsTztBQUNkQyxzQyxnQkFDR1YsRztBQUNIZ0IsK0NBQVdiLGVBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQlc7O21FQUVsQyxLQUFLTCxJQUFMLENBQVVILEdBQVYsRUFBZUUsTUFBZixFQUF1QixJQUF2QixFQUE2QixJQUE3QixFQUFtQ0UsSUFBbkMsQ0FBd0MsZUFBTztBQUNsRCwyQ0FBT0MsR0FBUDtBQUNILGlDQUZNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJWDs7Ozs7b0dBQ3lCYixHOzs7Ozs7QUFDakJRLG1DLEdBQVMsS0FBS0MsTztBQUNkQyxzQyxnQkFDR1YsRztBQUNIZ0IsK0NBQVdiLGVBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQlc7O21FQUVsQyxLQUFLTCxJQUFMLENBQVVILEdBQVYsRUFBZUUsTUFBZixFQUF1QixJQUF2QixFQUE2QixJQUE3QixFQUFtQ0UsSUFBbkMsQ0FBd0MsZUFBTztBQUNsRCwyQ0FBT0MsR0FBUDtBQUNILGlDQUZNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJWDs7Ozs7b0dBQ3dCYixHOzs7Ozs7QUFDaEJRLG1DLEdBQVMsS0FBS0MsTztBQUNkQyxzQyxnQkFDR1YsRztBQUNIZ0IsK0NBQVdiLGVBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQlc7O21FQUVsQyxLQUFLTCxJQUFMLENBQVVILEdBQVYsRUFBZUUsTUFBZixFQUF1QixJQUF2QixFQUE2QixJQUE3QixFQUFtQ0UsSUFBbkMsQ0FBd0MsZUFBTztBQUNsRCwyQ0FBT0MsR0FBUDtBQUNILGlDQUZNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJWDs7Ozs7b0dBQ29CYixHOzs7Ozs7QUFDWlEsbUMsR0FBUyxLQUFLQyxPO0FBQ2RDLHNDLGdCQUNHVixHO0FBQ0hnQiwrQ0FBV2IsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCVzs7bUVBRWxDLEtBQUtGLEdBQUwsQ0FBU04sR0FBVCxFQUFjRSxNQUFkLEVBQXNCLElBQXRCLEVBQTRCLElBQTVCLEVBQWtDRSxJQUFsQyxDQUF1QyxlQUFPO0FBQ2pELDJDQUFPQyxHQUFQO0FBQ0gsaUNBRk0sQzs7Ozs7Ozs7Ozs7Ozs7OztBQUlYOzs7OztvR0FDeUJJLEU7Ozs7OztBQUNqQlQsbUMsR0FBUyxLQUFLQyxPO0FBQ2RDLHNDLEdBQVM7QUFDVE8sMENBRFM7QUFFVEQsK0NBQVdiLGVBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQlc7QUFGNUIsaUM7bUVBSU4sS0FBS0YsR0FBTCxDQUFTTixHQUFULEVBQWNFLE1BQWQsRUFBc0IsSUFBdEIsRUFBNEIsSUFBNUIsRUFBa0NFLElBQWxDLENBQXVDLGVBQU87QUFDakQsMkNBQU9DLEdBQVA7QUFDSCxpQ0FGTSxDOzs7Ozs7Ozs7Ozs7Ozs7O0FBSVg7Ozs7O29HQUNzQmIsRzs7Ozs7O0FBQ2RRLG1DLEdBQVMsS0FBS0MsTztBQUNkQyxzQyxnQkFDR1YsRztBQUNIZ0IsK0NBQVdiLGVBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQlc7O21FQUVsQyxLQUFLRixHQUFMLENBQVNOLEdBQVQsRUFBY0UsTUFBZCxFQUFzQixJQUF0QixFQUE0QixJQUE1QixFQUFrQ0UsSUFBbEMsQ0FBdUMsZUFBTztBQUNqRCwyQ0FBT0MsR0FBUDtBQUNILGlDQUZNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJWDs7Ozs7b0dBQ3NCYixHOzs7Ozs7QUFDZFEsbUMsR0FBUyxLQUFLQyxPO0FBQ2RDLHNDLGdCQUNHVixHO0FBQ0hnQiwrQ0FBV2IsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCVzs7bUVBRWxDLEtBQUtGLEdBQUwsQ0FBU04sR0FBVCxFQUFjRSxNQUFkLEVBQXNCLElBQXRCLEVBQTRCLElBQTVCLEVBQWtDRSxJQUFsQyxDQUF1QyxlQUFPO0FBQ2pELDJDQUFPQyxHQUFQO0FBQ0gsaUNBRk0sQzs7Ozs7Ozs7Ozs7Ozs7OztBQUlYOzs7OztvR0FDeUJJLEU7Ozs7OztBQUNqQlQsbUMsR0FBUyxLQUFLQyxPO0FBQ2RDLHNDLEdBQVM7QUFDVE8sMENBRFM7QUFFVEQsK0NBQVdiLGVBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQlc7QUFGNUIsaUM7bUVBSU4sS0FBS0YsR0FBTCxDQUFTTixHQUFULEVBQWNFLE1BQWQsRUFBc0IsSUFBdEIsRUFBNEIsSUFBNUIsRUFBa0NFLElBQWxDLENBQXVDLGVBQU87QUFDakQsMkNBQU9DLEdBQVA7QUFDSCxpQ0FGTSxDOzs7Ozs7Ozs7Ozs7Ozs7O0FBSVg7Ozs7Ozs7Ozs7O0FBRVFMLG1DLEdBQVMsS0FBS0MsTztBQUNkQyxzQyxHQUFTO0FBQ1RNLCtDQUFXYixlQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJXO0FBRDVCLGlDO21FQUdOLEtBQUtGLEdBQUwsQ0FBU04sR0FBVCxFQUFjRSxNQUFkLEVBQXNCLElBQXRCLEVBQTRCLEtBQTVCLEVBQW1DRSxJQUFuQyxDQUF3QyxlQUFPO0FBQ2xELDJDQUFPQyxHQUFQO0FBQ0gsaUNBRk0sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFLWDtBQUNBOzs7O21DQUNrQk8sUyxFQUFXO0FBQUE7O0FBQ3pCLG1CQUFPLElBQUlDLE9BQUosQ0FBWSxVQUFDQyxPQUFELEVBQVVDLE1BQVYsRUFBcUI7QUFDcEM7QUFDQUMsbUJBQUdDLFVBQUgsQ0FBYztBQUNWakIseUJBQVEsT0FBS0MsT0FBYixzQ0FBcUROLGVBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQlcsU0FEckUsRUFDa0Y7QUFDNUZVLDhCQUFVTixTQUZBO0FBR1ZPLDBCQUFNLFNBSEk7QUFJVkMsNkJBQVMsaUJBQVVmLEdBQVYsRUFBZTtBQUNwQiw0QkFBSWdCLE9BQU9DLEtBQUtDLEtBQUwsQ0FBV2xCLElBQUlnQixJQUFmLENBQVg7QUFDQSw0QkFBSUEsS0FBS0csT0FBTCxJQUFnQixHQUFwQixFQUF5QjtBQUNyQlYsb0NBQVFPLEtBQUtBLElBQWI7QUFDSCx5QkFGRCxNQUVPO0FBQ0hOLG1DQUFPTSxLQUFLSSxNQUFaO0FBQ0g7QUFDSixxQkFYUztBQVlWQyx3QkFaVSxnQkFZTEMsR0FaSyxFQVlEO0FBQ0xaLCtCQUFPWSxHQUFQO0FBQ0g7QUFkUyxpQkFBZDtBQWdCSCxhQWxCTSxDQUFQO0FBbUJIO0FBQ0Q7Ozs7Ozs7Ozs7O0FBRVEzQixtQyxHQUFTLEtBQUtDLE87QUFDZEMsc0MsR0FBUztBQUNUTSwrQ0FBV2IsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCVztBQUQ1QixpQzttRUFHTixLQUFLRixHQUFMLENBQVNOLEdBQVQsRUFBY0UsTUFBZCxFQUFzQixJQUF0QixFQUE0QixLQUE1QixFQUFtQ0UsSUFBbkMsQ0FBd0MsZUFBTztBQUNsRCwyQ0FBT0MsR0FBUDtBQUNILGlDQUZNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJWDs7Ozs7b0dBQ29CYixHOzs7Ozs7QUFDWlEsbUMsR0FBUyxLQUFLQyxPO0FBQ2RDLHNDO0FBQ0FNLCtDQUFXYixlQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJXO21DQUNsQ2hCLEc7bUVBRUEsS0FBS2MsR0FBTCxDQUFTTixHQUFULEVBQWNFLE1BQWQsRUFBc0IsSUFBdEIsRUFBNEIsS0FBNUIsRUFBbUNFLElBQW5DLENBQXdDLGVBQU87QUFDbEQsMkNBQU9DLEdBQVA7QUFDSCxpQ0FGTSxDOzs7Ozs7Ozs7Ozs7Ozs7O0FBSVg7Ozs7O29HQUN3QmIsRzs7Ozs7O0FBQ2hCUSxtQyxHQUFTLEtBQUtDLE87QUFDZEMsc0MsZ0JBQ0dWLEc7QUFDSGdCLCtDQUFXYixlQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJXOzttRUFFbEMsS0FBS0wsSUFBTCxDQUFVSCxHQUFWLEVBQWVFLE1BQWYsRUFBdUIsSUFBdkIsRUFBNkIsSUFBN0IsRUFBbUNFLElBQW5DLENBQXdDLGVBQU87QUFDbEQsMkNBQU9DLEdBQVA7QUFDSCxpQ0FGTSxDOzs7Ozs7Ozs7Ozs7Ozs7O0FBSVg7Ozs7O29HQUN5QmIsRzs7Ozs7O0FBQ2pCUSxtQyxHQUFTLEtBQUtDLE87QUFDZEMsc0MsZ0JBQ0dWLEc7QUFDSGdCLCtDQUFXYixlQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJXOzttRUFFbEMsS0FBS0YsR0FBTCxDQUFTTixHQUFULEVBQWNFLE1BQWQsRUFBc0IsSUFBdEIsRUFBNEIsS0FBNUIsRUFBbUNFLElBQW5DLENBQXdDLGVBQU87QUFDbEQsMkNBQU9DLEdBQVA7QUFDSCxpQ0FGTSxDOzs7Ozs7Ozs7Ozs7Ozs7O0FBSVg7Ozs7O29HQUMwQmIsRzs7Ozs7O0FBQ2xCUSxtQyxHQUFTLEtBQUtDLE87QUFDZEMsc0MsZ0JBQ0dWLEc7QUFDSGdCLCtDQUFXYixlQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJXOzttRUFFbEMsS0FBS0YsR0FBTCxDQUFTTixHQUFULEVBQWNFLE1BQWQsRUFBc0IsSUFBdEIsRUFBNEIsS0FBNUIsRUFBbUNFLElBQW5DLENBQXdDLGVBQU87QUFDbEQsMkNBQU9DLEdBQVA7QUFDSCxpQ0FGTSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBN1hxQnVCLGM7O2tCQUFmckMsTSIsImZpbGUiOiJjb25maWcuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgd2VweSBmcm9tICd3ZXB5J1xyXG5pbXBvcnQgYmFzZSBmcm9tICcuL2Jhc2UnXHJcblxyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBjb25maWcgZXh0ZW5kcyBiYXNlIHtcclxuICAgIC8vIOiOt+WPlummlumhteaVsOaNrlxyXG4gICAgc3RhdGljIGFzeW5jIGdldEluZGV4KG9wdCkge1xyXG4gICAgICAgIGxldCBsb2NhdGlvbiA9IGF3YWl0IHRoaXMuZ2V0TG9jYXRpb24oKVxyXG4gICAgICAgIC8vICAg5b2T55So5oi35ouS57ud5o6I5p2D5bm25LiU5rKh5pyJ5omL5Yqo6YCJ5oup5Z+O5biC5pe277yM6Lez6L2s5Yiw6YCJ5oup5Zyw5Z2A6aG1XHJcbiAgICAgICAgaWYgKCFsb2NhdGlvbiAmJiAhd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5jaXR5Q29kZSkge1xyXG4gICAgICAgICAgICB3ZXB5LnJlZGlyZWN0VG8oeyB1cmw6ICcuL2FkZHJlc3MnIH0pO1xyXG4gICAgICAgICAgICByZXR1cm5cclxuICAgICAgICB9XHJcbiAgICAgICAgbGV0IHVybCA9IGAke3RoaXMuYmFzZVVybH0vaW5kZXhgO1xyXG4gICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgIGxvY2F0aW9uLFxyXG4gICAgICAgICAgICBjaXR5Q29kZTogd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5jaXR5Q29kZSxcclxuICAgICAgICAgICAgLi4ub3B0XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB0aGlzLnBvc3QodXJsLCBwYXJhbXMsIHRydWUpLnRoZW4ocmVzID0+IHtcclxuICAgICAgICAgICAgcmV0dXJuIHJlcztcclxuICAgICAgICB9KVxyXG4gICAgfVxyXG4gICAgc3RhdGljIGFzeW5jIGNpdHlzKCkge1xyXG4gICAgICAgIGxldCB1cmwgPSBgJHt0aGlzLmJhc2VVcmx9L2NpdHlzYDtcclxuICAgICAgICBsZXQgcGFyYW1zID0ge31cclxuICAgICAgICByZXR1cm4gdGhpcy5nZXQodXJsLCBwYXJhbXMsIHRydWUpLnRoZW4ocmVzID0+IHtcclxuICAgICAgICAgICAgcmV0dXJuIHJlcztcclxuICAgICAgICB9KVxyXG4gICAgfVxyXG4gICAgc3RhdGljIGFzeW5jIGdldENvdXJzZXMob3B0KSB7XHJcbiAgICAgICAgbGV0IHVybCA9IGAke3RoaXMuYmFzZVVybH0vY291cnNlL2dldENvdXJzZXNgO1xyXG4gICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgIGNpdHlDb2RlOiB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLmNpdHlDb2RlLFxyXG4gICAgICAgICAgICAuLi5vcHRcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuZ2V0KHVybCwgcGFyYW1zLCB0cnVlKS50aGVuKHJlcyA9PiB7XHJcbiAgICAgICAgICAgIHJldHVybiByZXM7XHJcbiAgICAgICAgfSlcclxuICAgIH1cclxuXHJcbiAgICBzdGF0aWMgYXN5bmMgZ2V0Q29tcGFuaW9ucyhjb3Vyc2VJZCkge1xyXG4gICAgICAgIGxldCB1cmwgPSBgJHt0aGlzLmJhc2VVcmx9L2NvdXJzZS9nZXRDb21wYW5pb25zYDtcclxuICAgICAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICAgICAgICBjb3Vyc2VJZCxcclxuICAgICAgICAgICAgc2Vzc2lvbklkOiB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnNlc3Npb25JZFxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdGhpcy5nZXQodXJsLCBwYXJhbXMsIHRydWUpLnRoZW4ocmVzID0+IHtcclxuICAgICAgICAgICAgcmV0dXJuIHJlcztcclxuICAgICAgICB9KVxyXG4gICAgfVxyXG5cclxuICAgIHN0YXRpYyBhc3luYyBnZXRDb3Vyc2VJbmZvKGlkKSB7XHJcbiAgICAgICAgbGV0IHVybCA9IGAke3RoaXMuYmFzZVVybH0vY291cnNlL2dldEluZm9gO1xyXG4gICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgIGlkXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB0aGlzLmdldCh1cmwsIHBhcmFtcywgdHJ1ZSkudGhlbihyZXMgPT4ge1xyXG4gICAgICAgICAgICByZXR1cm4gcmVzO1xyXG4gICAgICAgIH0pXHJcbiAgICB9XHJcbiAgICAvLyDmkJzntKJcclxuICAgIHN0YXRpYyBhc3luYyBzZWFyY2gob3B0KSB7XHJcbiAgICAgICAgbGV0IHVybCA9IGAke3RoaXMuYmFzZVVybH0vY291cnNlL3NlYXJjaGA7XHJcbiAgICAgICAgbGV0IHBhcmFtcyA9IHtcclxuICAgICAgICAgICAgLi4ub3B0XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB0aGlzLmdldCh1cmwsIHBhcmFtcywgdHJ1ZSkudGhlbihyZXMgPT4ge1xyXG4gICAgICAgICAgICByZXR1cm4gcmVzO1xyXG4gICAgICAgIH0pXHJcbiAgICB9XHJcbiAgICAvLyDojrflj5bor4TorrrliJfooahcclxuICAgIHN0YXRpYyBhc3luYyBjb21tZW50cyhvcHQpIHtcclxuICAgICAgICBsZXQgdXJsID0gYCR7dGhpcy5iYXNlVXJsfS9jb21tZW50L2xpc3RgO1xyXG4gICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgIC4uLm9wdFxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdGhpcy5nZXQodXJsLCBwYXJhbXMsIHRydWUpLnRoZW4ocmVzID0+IHtcclxuICAgICAgICAgICAgcmV0dXJuIHJlcztcclxuICAgICAgICB9KVxyXG4gICAgfVxyXG4gICAgLy8g5Y+R6LW356CN5Lu3XHJcbiAgICBzdGF0aWMgYXN5bmMgcmVnQmFyZ2FpbihvcHQpIHtcclxuICAgICAgICBsZXQgdXJsID0gYCR7dGhpcy5iYXNlVXJsfS9iYXJnYWluL3JlZ0JhcmdhaW5gO1xyXG4gICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgIHNlc3Npb25JZDogd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5zZXNzaW9uSWQsXHJcbiAgICAgICAgICAgIC4uLm9wdFxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdGhpcy5wb3N0KHVybCwgcGFyYW1zLCB0cnVlLHRydWUpLnRoZW4ocmVzID0+IHtcclxuICAgICAgICAgICAgcmV0dXJuIHJlcztcclxuICAgICAgICB9KVxyXG4gICAgfVxyXG4gICAgLy8g5biu56CN5Lu3XHJcbiAgICBzdGF0aWMgYXN5bmMgaGVscEJhcmdhaW4ocmVnSWQpIHtcclxuICAgICAgICBsZXQgdXJsID0gYCR7dGhpcy5iYXNlVXJsfS9iYXJnYWluL2hlbHBCYXJnYWluYDtcclxuICAgICAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICAgICAgICBzZXNzaW9uSWQ6IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuc2Vzc2lvbklkLFxyXG4gICAgICAgICAgICByZWdJZFxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdGhpcy5wb3N0KHVybCwgcGFyYW1zLCB0cnVlLHRydWUpLnRoZW4ocmVzID0+IHtcclxuICAgICAgICAgICAgcmV0dXJuIHJlcztcclxuICAgICAgICB9KVxyXG4gICAgfVxyXG4gICAgLy8g56CN5Lu36K+m5oOFXHJcbiAgICBzdGF0aWMgYXN5bmMgdG9DdXREZXRhaShyZWdJZCkge1xyXG4gICAgICAgIGxldCB1cmwgPSBgJHt0aGlzLmJhc2VVcmx9L2JhcmdhaW4vdG9DdXREZXRhaWA7XHJcbiAgICAgICAgbGV0IHBhcmFtcyA9IHtcclxuICAgICAgICAgICAgc2Vzc2lvbklkOiB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnNlc3Npb25JZCxcclxuICAgICAgICAgICAgcmVnSWRcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuZ2V0KHVybCwgcGFyYW1zLCB0cnVlLHRydWUpLnRoZW4ocmVzID0+IHtcclxuICAgICAgICAgICAgcmV0dXJuIHJlcztcclxuICAgICAgICB9KVxyXG4gICAgfVxyXG4gICAgLy8g5ou85Zui6K+m5oOFXHJcbiAgICBzdGF0aWMgYXN5bmMgcGludHVhbkRldGFpKGFjdGl2aXR5SWQpIHtcclxuICAgICAgICBsZXQgdXJsID0gYCR7dGhpcy5iYXNlVXJsfS9waW50dWFuL3NoYXJlL2RldGFpYDtcclxuICAgICAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICAgICAgICBzZXNzaW9uSWQ6IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuc2Vzc2lvbklkLFxyXG4gICAgICAgICAgICBhY3Rpdml0eUlkXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB0aGlzLmdldCh1cmwsIHBhcmFtcywgdHJ1ZSx0cnVlKS50aGVuKHJlcyA9PiB7XHJcbiAgICAgICAgICAgIHJldHVybiByZXM7XHJcbiAgICAgICAgfSlcclxuICAgIH1cclxuICAgIC8vICMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyAg5Lq65ZGY5L+h5oGv566h55CGICAjIyMjIyMjIyMjIyMjIyMjIyMjXHJcbiAgICAvLyDojrflj5blhL/nq6XliJfooahcclxuICAgIHN0YXRpYyBhc3luYyBnZXRDaGlsZExpc3QoKSB7XHJcbiAgICAgICAgbGV0IHVybCA9IGAke3RoaXMuYmFzZVVybH0vbWVtYmVyL2dldENoaWxkTGlzdGA7XHJcbiAgICAgICAgbGV0IHBhcmFtcyA9IHtcclxuICAgICAgICAgICAgc2Vzc2lvbklkOiB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnNlc3Npb25JZFxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdGhpcy5nZXQodXJsLCBwYXJhbXMsIHRydWUpLnRoZW4ocmVzID0+IHtcclxuICAgICAgICAgICAgcmV0dXJuIHJlcztcclxuICAgICAgICB9KVxyXG4gICAgfVxyXG4gICAgLy8g6I635Y+W55uR5oqk5Lq65YiX6KGoXHJcbiAgICBzdGF0aWMgYXN5bmMgZ2V0R3VhTGlzdCgpIHtcclxuICAgICAgICBsZXQgdXJsID0gYCR7dGhpcy5iYXNlVXJsfS9tZW1iZXIvZ2V0R3VhTGlzdGA7XHJcbiAgICAgICAgbGV0IHBhcmFtcyA9IHtcclxuICAgICAgICAgICAgc2Vzc2lvbklkOiB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnNlc3Npb25JZFxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdGhpcy5nZXQodXJsLCBwYXJhbXMsIHRydWUpLnRoZW4ocmVzID0+IHtcclxuICAgICAgICAgICAgcmV0dXJuIHJlcztcclxuICAgICAgICB9KVxyXG4gICAgfVxyXG4gICAgLy8g5rS75Yqo5YS/56ul6K+m5oOFXHJcbiAgICBzdGF0aWMgYXN5bmMgZ2V0Q2hpbGQoaWQpIHtcclxuICAgICAgICBsZXQgdXJsID0gYCR7dGhpcy5iYXNlVXJsfS9tZW1iZXIvZ2V0Q2hpbGRgO1xyXG4gICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgIGlkLFxyXG4gICAgICAgICAgICBzZXNzaW9uSWQ6IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuc2Vzc2lvbklkXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB0aGlzLmdldCh1cmwsIHBhcmFtcywgdHJ1ZSkudGhlbihyZXMgPT4ge1xyXG4gICAgICAgICAgICByZXR1cm4gcmVzO1xyXG4gICAgICAgIH0pXHJcbiAgICB9XHJcbiAgICAvLyDmtLvliqjnm5HmiqTkurror6bmg4VcclxuICAgIHN0YXRpYyBhc3luYyBnZXRHdWEoaWQpIHtcclxuICAgICAgICBsZXQgdXJsID0gYCR7dGhpcy5iYXNlVXJsfS9tZW1iZXIvZ2V0R3VhYDtcclxuICAgICAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICAgICAgICBpZCxcclxuICAgICAgICAgICAgc2Vzc2lvbklkOiB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnNlc3Npb25JZFxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdGhpcy5nZXQodXJsLCBwYXJhbXMsIHRydWUpLnRoZW4ocmVzID0+IHtcclxuICAgICAgICAgICAgcmV0dXJuIHJlcztcclxuICAgICAgICB9KVxyXG4gICAgfVxyXG4gICAgLy8g5L+d5a2Y55uR5oqk5Lq6XHJcbiAgICBzdGF0aWMgYXN5bmMgdXBkYXRlR3VhKG9wdCkge1xyXG4gICAgICAgIGxldCB1cmwgPSBgJHt0aGlzLmJhc2VVcmx9L21lbWJlci91cGRhdGVHdWFgO1xyXG4gICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgIC4uLm9wdCxcclxuICAgICAgICAgICAgc2Vzc2lvbklkOiB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnNlc3Npb25JZFxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdGhpcy5wb3N0KHVybCwgcGFyYW1zLCB0cnVlLCB0cnVlKS50aGVuKHJlcyA9PiB7XHJcbiAgICAgICAgICAgIHJldHVybiByZXM7XHJcbiAgICAgICAgfSlcclxuICAgIH1cclxuICAgIC8vIOS/neWtmOWEv+erpVxyXG4gICAgc3RhdGljIGFzeW5jIHVwZGF0ZUNoaWxkKG9wdCkge1xyXG4gICAgICAgIGxldCB1cmwgPSBgJHt0aGlzLmJhc2VVcmx9L21lbWJlci91cGRhdGVDaGlsZGA7XHJcbiAgICAgICAgbGV0IHBhcmFtcyA9IHtcclxuICAgICAgICAgICAgLi4ub3B0LFxyXG4gICAgICAgICAgICBzZXNzaW9uSWQ6IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuc2Vzc2lvbklkXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB0aGlzLnBvc3QodXJsLCBwYXJhbXMsIHRydWUsIHRydWUpLnRoZW4ocmVzID0+IHtcclxuICAgICAgICAgICAgcmV0dXJuIHJlcztcclxuICAgICAgICB9KVxyXG4gICAgfVxyXG4gICAgLy8g5Yig6Zmk55uR5oqk5Lq6XHJcbiAgICBzdGF0aWMgYXN5bmMgZGVsR3VhKGlkKSB7XHJcbiAgICAgICAgbGV0IHVybCA9IGAke3RoaXMuYmFzZVVybH0vbWVtYmVyL2RlbEd1YWA7XHJcbiAgICAgICAgbGV0IHBhcmFtcyA9IHtcclxuICAgICAgICAgICAgaWQsXHJcbiAgICAgICAgICAgIHNlc3Npb25JZDogd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5zZXNzaW9uSWRcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHRoaXMucG9zdCh1cmwsIHBhcmFtcywgdHJ1ZSwgdHJ1ZSkudGhlbihyZXMgPT4ge1xyXG4gICAgICAgICAgICByZXR1cm4gcmVzO1xyXG4gICAgICAgIH0pXHJcbiAgICB9XHJcbiAgICAvLyDliKDpmaTlhL/nq6Xkv6Hmga9cclxuICAgIHN0YXRpYyBhc3luYyBkZWxDaGlsZChpZCkge1xyXG4gICAgICAgIGxldCB1cmwgPSBgJHt0aGlzLmJhc2VVcmx9L21lbWJlci9kZWxDaGlsZGA7XHJcbiAgICAgICAgbGV0IHBhcmFtcyA9IHtcclxuICAgICAgICAgICAgaWQsXHJcbiAgICAgICAgICAgIHNlc3Npb25JZDogd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5zZXNzaW9uSWRcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHRoaXMucG9zdCh1cmwsIHBhcmFtcywgdHJ1ZSwgdHJ1ZSkudGhlbihyZXMgPT4ge1xyXG4gICAgICAgICAgICByZXR1cm4gcmVzO1xyXG4gICAgICAgIH0pXHJcbiAgICB9XHJcbiAgICAvLyAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMgIOiuouWNleeuoeeQhiAgIyMjIyMjIyMjIyMjIyMjIyMjI1xyXG4gICAgLy8g55Sf5oiQ5pSv5LuY6K6i5Y2V5L+h5oGvIFxyXG4gICAgc3RhdGljIGFzeW5jIG9yZGVySW5mbyhvcHQpIHtcclxuICAgICAgICBsZXQgdXJsID0gYCR7dGhpcy5iYXNlVXJsfS9vcmRlci9pbmZvYDtcclxuICAgICAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICAgICAgICAuLi5vcHQsXHJcbiAgICAgICAgICAgIHNlc3Npb25JZDogd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5zZXNzaW9uSWRcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHRoaXMucG9zdCh1cmwsIHBhcmFtcywgdHJ1ZSwgdHJ1ZSkudGhlbihyZXMgPT4ge1xyXG4gICAgICAgICAgICByZXR1cm4gcmVzO1xyXG4gICAgICAgIH0pXHJcbiAgICB9XHJcbiAgICAvLyDkuIvljZUgXHJcbiAgICBzdGF0aWMgYXN5bmMgb3JkZXJjb21taXQob3B0KSB7XHJcbiAgICAgICAgbGV0IHVybCA9IGAke3RoaXMuYmFzZVVybH0vb3JkZXIvb3JkZXJjb21taXRgO1xyXG4gICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgIC4uLm9wdCxcclxuICAgICAgICAgICAgc2Vzc2lvbklkOiB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnNlc3Npb25JZFxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdGhpcy5wb3N0KHVybCwgcGFyYW1zLCB0cnVlLCB0cnVlKS50aGVuKHJlcyA9PiB7XHJcbiAgICAgICAgICAgIHJldHVybiByZXM7XHJcbiAgICAgICAgfSlcclxuICAgIH1cclxuICAgIC8vIOaUr+S7mCBcclxuICAgIHN0YXRpYyBhc3luYyB3eHBheXRvcGF5KG9wdCkge1xyXG4gICAgICAgIGxldCB1cmwgPSBgJHt0aGlzLmJhc2VVcmx9L3d4cGF5L3RvcGF5YDtcclxuICAgICAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICAgICAgICAuLi5vcHQsXHJcbiAgICAgICAgICAgIHNlc3Npb25JZDogd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5zZXNzaW9uSWRcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHRoaXMucG9zdCh1cmwsIHBhcmFtcywgdHJ1ZSwgdHJ1ZSkudGhlbihyZXMgPT4ge1xyXG4gICAgICAgICAgICByZXR1cm4gcmVzO1xyXG4gICAgICAgIH0pXHJcbiAgICB9XHJcbiAgICAvLyDojrflj5borqLljZXliJfooahcclxuICAgIHN0YXRpYyBhc3luYyBvcmRlcnMob3B0KSB7XHJcbiAgICAgICAgbGV0IHVybCA9IGAke3RoaXMuYmFzZVVybH0vbWVtYmVyL29yZGVyYDtcclxuICAgICAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICAgICAgICAuLi5vcHQsXHJcbiAgICAgICAgICAgIHNlc3Npb25JZDogd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5zZXNzaW9uSWRcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuZ2V0KHVybCwgcGFyYW1zLCB0cnVlLCB0cnVlKS50aGVuKHJlcyA9PiB7XHJcbiAgICAgICAgICAgIHJldHVybiByZXM7XHJcbiAgICAgICAgfSlcclxuICAgIH1cclxuICAgIC8vIOiOt+WPluiuouWNleivpuaDhVxyXG4gICAgc3RhdGljIGFzeW5jIG9yZGVyZGV0YWlsKGlkKSB7XHJcbiAgICAgICAgbGV0IHVybCA9IGAke3RoaXMuYmFzZVVybH0vbWVtYmVyL29yZGVyZGV0YWlsYDtcclxuICAgICAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICAgICAgICBpZCxcclxuICAgICAgICAgICAgc2Vzc2lvbklkOiB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnNlc3Npb25JZFxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdGhpcy5nZXQodXJsLCBwYXJhbXMsIHRydWUsIHRydWUpLnRoZW4ocmVzID0+IHtcclxuICAgICAgICAgICAgcmV0dXJuIHJlcztcclxuICAgICAgICB9KVxyXG4gICAgfVxyXG4gICAgLy8g5oiR55qE56CN5Lu3XHJcbiAgICBzdGF0aWMgYXN5bmMgYmFyZ2FpbnMob3B0KSB7XHJcbiAgICAgICAgbGV0IHVybCA9IGAke3RoaXMuYmFzZVVybH0vbWVtYmVyL2JhcmdhaW4vbGlzdGA7XHJcbiAgICAgICAgbGV0IHBhcmFtcyA9IHtcclxuICAgICAgICAgICAgLi4ub3B0LFxyXG4gICAgICAgICAgICBzZXNzaW9uSWQ6IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuc2Vzc2lvbklkXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB0aGlzLmdldCh1cmwsIHBhcmFtcywgdHJ1ZSwgdHJ1ZSkudGhlbihyZXMgPT4ge1xyXG4gICAgICAgICAgICByZXR1cm4gcmVzO1xyXG4gICAgICAgIH0pXHJcbiAgICB9XHJcbiAgICAvLyDmiJHnmoTmi7zlm6JcclxuICAgIHN0YXRpYyBhc3luYyBwaW50dWFucyhvcHQpIHtcclxuICAgICAgICBsZXQgdXJsID0gYCR7dGhpcy5iYXNlVXJsfS9tZW1iZXIvcGludHVhbi9saXN0YDtcclxuICAgICAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICAgICAgICAuLi5vcHQsXHJcbiAgICAgICAgICAgIHNlc3Npb25JZDogd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5zZXNzaW9uSWRcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuZ2V0KHVybCwgcGFyYW1zLCB0cnVlLCB0cnVlKS50aGVuKHJlcyA9PiB7XHJcbiAgICAgICAgICAgIHJldHVybiByZXM7XHJcbiAgICAgICAgfSlcclxuICAgIH1cclxuICAgIC8vIOWPlua2iOiuouWNlVxyXG4gICAgc3RhdGljIGFzeW5jIGNhbmNhbG9yZGVyKGlkKSB7XHJcbiAgICAgICAgbGV0IHVybCA9IGAke3RoaXMuYmFzZVVybH0vbWVtYmVyL2NhbmNhbG9yZGVyYDtcclxuICAgICAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICAgICAgICBpZCxcclxuICAgICAgICAgICAgc2Vzc2lvbklkOiB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnNlc3Npb25JZFxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdGhpcy5nZXQodXJsLCBwYXJhbXMsIHRydWUsIHRydWUpLnRoZW4ocmVzID0+IHtcclxuICAgICAgICAgICAgcmV0dXJuIHJlcztcclxuICAgICAgICB9KVxyXG4gICAgfVxyXG4gICAgLy8g5Y+W5raI6K6i5Y2VXHJcbiAgICBzdGF0aWMgYXN5bmMgY2VudGVyKCkge1xyXG4gICAgICAgIGxldCB1cmwgPSBgJHt0aGlzLmJhc2VVcmx9L21lbWJlci9jZW50ZXJgO1xyXG4gICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgIHNlc3Npb25JZDogd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5zZXNzaW9uSWRcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuZ2V0KHVybCwgcGFyYW1zLCB0cnVlLCBmYWxzZSkudGhlbihyZXMgPT4ge1xyXG4gICAgICAgICAgICByZXR1cm4gcmVzO1xyXG4gICAgICAgIH0pXHJcbiAgICB9XHJcblxyXG4gICAgLy8gIyMjIOivhOiuulxyXG4gICAgLy8g5LiK5Lyg5Zu+54mHIFxyXG4gICAgc3RhdGljIHVwbG9hZEZpbGUoaW1hZ2VfdXJsKSB7XHJcbiAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgICAgICAgLy8g5LiK5Lyg5Zu+54mHXHJcbiAgICAgICAgICAgIHd4LnVwbG9hZEZpbGUoe1xyXG4gICAgICAgICAgICAgICAgdXJsOiBgJHt0aGlzLmJhc2VVcmx9L21lbWJlci91cGxvYWRGaWxlcz9zZXNzaW9uSWQ9JHt3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnNlc3Npb25JZH1gLCAvLyDku4XkuLrnpLrkvovvvIzpnZ7nnJ/lrp7nmoTmjqXlj6PlnLDlnYBcclxuICAgICAgICAgICAgICAgIGZpbGVQYXRoOiBpbWFnZV91cmwsXHJcbiAgICAgICAgICAgICAgICBuYW1lOiAnaW1nRmlsZScsXHJcbiAgICAgICAgICAgICAgICBzdWNjZXNzOiBmdW5jdGlvbiAocmVzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGRhdGEgPSBKU09OLnBhcnNlKHJlcy5kYXRhKTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoZGF0YS5lcnJjb2RlID09IDIwMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXNvbHZlKGRhdGEuZGF0YSlcclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZWplY3QoZGF0YS5lcnJtc2cpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIGZhaWwoZXJyKXtcclxuICAgICAgICAgICAgICAgICAgICByZWplY3QoZXJyKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgIH0pXHJcbiAgICB9XHJcbiAgICAvLyDojrflj5Z0YWdcclxuICAgIHN0YXRpYyBhc3luYyBjb21tZW50VGFnKCkge1xyXG4gICAgICAgIGxldCB1cmwgPSBgJHt0aGlzLmJhc2VVcmx9L21lbWJlci9jb21tZW50VGFnYDtcclxuICAgICAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICAgICAgICBzZXNzaW9uSWQ6IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuc2Vzc2lvbklkXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB0aGlzLmdldCh1cmwsIHBhcmFtcywgdHJ1ZSwgZmFsc2UpLnRoZW4ocmVzID0+IHtcclxuICAgICAgICAgICAgcmV0dXJuIHJlcztcclxuICAgICAgICB9KVxyXG4gICAgfVxyXG4gICAgLy/mm7TmlrDor4TorrrlhbPms6hcclxuICAgIHN0YXRpYyBhc3luYyBkb2xpa2Uob3B0KSB7XHJcbiAgICAgICAgbGV0IHVybCA9IGAke3RoaXMuYmFzZVVybH0vbWVtYmVyL2RvbGlrZWA7XHJcbiAgICAgICAgbGV0IHBhcmFtcyA9IHtcclxuICAgICAgICAgICAgc2Vzc2lvbklkOiB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnNlc3Npb25JZCxcclxuICAgICAgICAgICAgLi4ub3B0XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB0aGlzLmdldCh1cmwsIHBhcmFtcywgdHJ1ZSwgZmFsc2UpLnRoZW4ocmVzID0+IHtcclxuICAgICAgICAgICAgcmV0dXJuIHJlcztcclxuICAgICAgICB9KVxyXG4gICAgfVxyXG4gICAgLy8g5o+Q5Lqk6K+E6K66XHJcbiAgICBzdGF0aWMgYXN5bmMgc2F2ZWNvbW1lbihvcHQpIHtcclxuICAgICAgICBsZXQgdXJsID0gYCR7dGhpcy5iYXNlVXJsfS9tZW1iZXIvc2F2ZWNvbW1lbnRgO1xyXG4gICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgIC4uLm9wdCxcclxuICAgICAgICAgICAgc2Vzc2lvbklkOiB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnNlc3Npb25JZFxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdGhpcy5wb3N0KHVybCwgcGFyYW1zLCB0cnVlLCB0cnVlKS50aGVuKHJlcyA9PiB7XHJcbiAgICAgICAgICAgIHJldHVybiByZXM7XHJcbiAgICAgICAgfSlcclxuICAgIH1cclxuICAgIC8vIOiOt+WPluWutumVv+W/g+WjsFxyXG4gICAgc3RhdGljIGFzeW5jIGFzcGlyYXRpb25zKG9wdCkge1xyXG4gICAgICAgIGxldCB1cmwgPSBgJHt0aGlzLmJhc2VVcmx9L2NvbW1lbnQvYXNwaXJhdGlvbnNgO1xyXG4gICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgIC4uLm9wdCxcclxuICAgICAgICAgICAgc2Vzc2lvbklkOiB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnNlc3Npb25JZFxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdGhpcy5nZXQodXJsLCBwYXJhbXMsIHRydWUsIGZhbHNlKS50aGVuKHJlcyA9PiB7XHJcbiAgICAgICAgICAgIHJldHVybiByZXM7XHJcbiAgICAgICAgfSlcclxuICAgIH1cclxuICAgIC8vIOiOt+WPluWIhuS6q+Wwj+eoi+W6j+eggVxyXG4gICAgc3RhdGljIGFzeW5jIGdldFVubGltaXRlZChvcHQpIHtcclxuICAgICAgICBsZXQgdXJsID0gYCR7dGhpcy5iYXNlVXJsfS9xci9nZXRVbmxpbWl0ZWRgO1xyXG4gICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgIC4uLm9wdCxcclxuICAgICAgICAgICAgc2Vzc2lvbklkOiB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnNlc3Npb25JZFxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdGhpcy5nZXQodXJsLCBwYXJhbXMsIHRydWUsIGZhbHNlKS50aGVuKHJlcyA9PiB7XHJcbiAgICAgICAgICAgIHJldHVybiByZXM7XHJcbiAgICAgICAgfSlcclxuICAgIH1cclxufVxyXG5cclxuIl19