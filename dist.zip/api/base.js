'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _Http = require('./../utils/Http.js');

var _Http2 = _interopRequireDefault(_Http);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var base = function () {
  function base() {
    _classCallCheck(this, base);
  }

  _createClass(base, null, [{
    key: 'getLocation',

    // 截取经纬度
    value: function () {
      var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                return _context.abrupt('return', _wepy2.default.getLocation({
                  type: 'gcj02'
                }).then(function (res) {
                  return res.latitude + ',' + res.longitude;
                }).catch(function (err) {
                  console.log(err);
                  return '';
                }));

              case 1:
              case 'end':
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function getLocation() {
        return _ref.apply(this, arguments);
      }

      return getLocation;
    }()
  }]);

  return base;
}();

base.baseUrl = _wepy2.default.$instance.globalData.baseUrl;
base.kdsUrl = _wepy2.default.$instance.globalData.kdsUrl;
base.fuUrl = _wepy2.default.$instance.globalData.fuUrl;
base.get = _Http2.default.get.bind(_Http2.default);
base.put = _Http2.default.put.bind(_Http2.default);
base.post = _Http2.default.post.bind(_Http2.default);
base.delete = _Http2.default.delete.bind(_Http2.default);
exports.default = base;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImJhc2UuanMiXSwibmFtZXMiOlsiYmFzZSIsIndlcHkiLCJnZXRMb2NhdGlvbiIsInR5cGUiLCJ0aGVuIiwicmVzIiwibGF0aXR1ZGUiLCJsb25naXR1ZGUiLCJjYXRjaCIsImNvbnNvbGUiLCJsb2ciLCJlcnIiLCJiYXNlVXJsIiwiJGluc3RhbmNlIiwiZ2xvYmFsRGF0YSIsImtkc1VybCIsImZ1VXJsIiwiZ2V0IiwiaHR0cCIsImJpbmQiLCJwdXQiLCJwb3N0IiwiZGVsZXRlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBQTs7OztBQUNBOzs7Ozs7Ozs7O0lBRXFCQSxJOzs7Ozs7OztBQVFuQjs7Ozs7OztpREFFU0MsZUFBS0MsV0FBTCxDQUFpQjtBQUN0QkMsd0JBQU07QUFEZ0IsaUJBQWpCLEVBRUpDLElBRkksQ0FFQyxlQUFPO0FBQ2IseUJBQVVDLElBQUlDLFFBQWQsU0FBMEJELElBQUlFLFNBQTlCO0FBQ0QsaUJBSk0sRUFJSkMsS0FKSSxDQUlFLGVBQU87QUFDZEMsMEJBQVFDLEdBQVIsQ0FBWUMsR0FBWjtBQUNBLHlCQUFRLEVBQVI7QUFDRCxpQkFQTSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFWVVgsSSxDQUNaWSxPLEdBQVVYLGVBQUtZLFNBQUwsQ0FBZUMsVUFBZixDQUEwQkYsTztBQUR4QlosSSxDQUVaZSxNLEdBQVNkLGVBQUtZLFNBQUwsQ0FBZUMsVUFBZixDQUEwQkMsTTtBQUZ2QmYsSSxDQUdaZ0IsSyxHQUFRZixlQUFLWSxTQUFMLENBQWVDLFVBQWYsQ0FBMEJFLEs7QUFIdEJoQixJLENBSVppQixHLEdBQU1DLGVBQUtELEdBQUwsQ0FBU0UsSUFBVCxDQUFjRCxjQUFkLEM7QUFKTWxCLEksQ0FLWm9CLEcsR0FBTUYsZUFBS0UsR0FBTCxDQUFTRCxJQUFULENBQWNELGNBQWQsQztBQUxNbEIsSSxDQU1acUIsSSxHQUFPSCxlQUFLRyxJQUFMLENBQVVGLElBQVYsQ0FBZUQsY0FBZixDO0FBTktsQixJLENBT1pzQixNLEdBQVNKLGVBQUtJLE1BQUwsQ0FBWUgsSUFBWixDQUFpQkQsY0FBakIsQztrQkFQR2xCLEkiLCJmaWxlIjoiYmFzZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB3ZXB5IGZyb20gJ3dlcHknO1xyXG5pbXBvcnQgaHR0cCBmcm9tICcuLi91dGlscy9IdHRwJ1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgYmFzZSB7XHJcbiAgc3RhdGljIGJhc2VVcmwgPSB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLmJhc2VVcmw7XHJcbiAgc3RhdGljIGtkc1VybCA9IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEua2RzVXJsO1xyXG4gIHN0YXRpYyBmdVVybCA9IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuZnVVcmw7XHJcbiAgc3RhdGljIGdldCA9IGh0dHAuZ2V0LmJpbmQoaHR0cCk7XHJcbiAgc3RhdGljIHB1dCA9IGh0dHAucHV0LmJpbmQoaHR0cCk7XHJcbiAgc3RhdGljIHBvc3QgPSBodHRwLnBvc3QuYmluZChodHRwKTtcclxuICBzdGF0aWMgZGVsZXRlID0gaHR0cC5kZWxldGUuYmluZChodHRwKTtcclxuICAvLyDmiKrlj5bnu4/nuqzluqZcclxuICBzdGF0aWMgYXN5bmMgZ2V0TG9jYXRpb24oKSB7XHJcbiAgICByZXR1cm4gd2VweS5nZXRMb2NhdGlvbih7XHJcbiAgICAgIHR5cGU6ICdnY2owMidcclxuICAgIH0pLnRoZW4ocmVzID0+IHtcclxuICAgICAgcmV0dXJuIGAke3Jlcy5sYXRpdHVkZX0sJHtyZXMubG9uZ2l0dWRlfWBcclxuICAgIH0pLmNhdGNoKGVyciA9PiB7XHJcbiAgICAgIGNvbnNvbGUubG9nKGVycilcclxuICAgICAgcmV0dXJuICAnJ1xyXG4gICAgfSk7XHJcbiAgfVxyXG59XHJcblxyXG5cclxuIl19