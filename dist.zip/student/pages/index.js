"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

var _api = require('./../api.js');

var _api2 = _interopRequireDefault(_api);

var _WxUtils = require('./../../utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

var _contact = require('./../../components/common/contact.js');

var _contact2 = _interopRequireDefault(_contact);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var My = function (_wepy$page) {
  _inherits(My, _wepy$page);

  function My() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, My);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = My.__proto__ || Object.getPrototypeOf(My)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
      navigationBarTitleText: "我的学籍"
    }, _this.components = {
      contact: _contact2.default
    }, _this.data = {
      // 学籍系统
      bookItems: [{
        name: '录取通知书',
        icon: 'cuIcon-profilefill',
        path: '/pages/home/picView',
        type: 'admissionLetter'
      }, {
        name: '电子协议',
        icon: 'cuIcon-picfill',
        path: '',
        type: 'agreementId'
      }, {
        name: '入营须知',
        icon: 'cuIcon-picfill',
        path: '/pages/home/picView',
        type: 'notice'
      }, {
        name: '毕业证书',
        icon: 'cuIcon-picfill',
        path: '/pages/home/picView',
        type: 'diploma'
      }],

      myInfo: {},
      childId: ''
    }, _this.methods = {
      navi: function navi(e) {
        var url = e.currentTarget.dataset.url || e.target.dataset.url;
        if (url) {
          _WxUtils2.default.backOrNavigate(url);
        }
      },
      navi2auth: function navi2auth(e) {
        var url = e.currentTarget.dataset.url || e.target.dataset.url,
            index = e.currentTarget.dataset.inx,
            type = e.currentTarget.dataset.type || e.target.dataset.type;
        if (!url) {
          _Tips2.default.toast('功能即将上线，敬请期待', function () {}, 'none');
          return;
        }
        var value = this.myInfo.status[index][type];
        if (url == '/pages/home/picView') {
          _wepy2.default.$instance.globalData.picView = value;
        }
        if (url != '/pages/home/picView') {
          url = url + '?id=' + value;
        }
        if (url) {
          _WxUtils2.default.backOrNavigate(url);
        }
      },
      bargaining: function bargaining() {
        _wepy2.default.navigateTo({
          url: './bargaining'
        });
      },
      agent: function agent() {
        _wepy2.default.navigateTo({
          url: '/agent/pages/index'
        });
      },
      pintuan: function pintuan() {
        _wepy2.default.navigateTo({
          url: './pintuan'
        });
      },
      childs: function childs() {
        if (_wepy2.default.getStorageSync('mobile')) {
          _wepy2.default.navigateTo({
            url: '/pages/meet/childs'
          });
        } else {
          _Tips2.default.toast('需要先绑定手机号哦~', function () {
            _wepy2.default.switchTab({
              url: '/pages/meet/meet'
            });
          }, 'none');
        }
      },
      toOrder: function toOrder(id) {
        _wepy2.default.navigateTo({
          url: './orders?id=' + id
        });
      }
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(My, [{
    key: "onLoad",
    value: function () {
      var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(opt) {
        var res;
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                this.childId = opt.childId;
                _context.next = 3;
                return _api2.default.getbychild(this.childId);

              case 3:
                res = _context.sent;

                this.myInfo = res;
                console.log(this.myInfo);
                this.$apply();

              case 7:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function onLoad(_x) {
        return _ref2.apply(this, arguments);
      }

      return onLoad;
    }()
  }]);

  return My;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(My , 'student/pages/index'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LmpzIl0sIm5hbWVzIjpbIk15IiwiY29uZmlnIiwibmF2aWdhdGlvbkJhclRpdGxlVGV4dCIsImNvbXBvbmVudHMiLCJjb250YWN0IiwiZGF0YSIsImJvb2tJdGVtcyIsIm5hbWUiLCJpY29uIiwicGF0aCIsInR5cGUiLCJteUluZm8iLCJjaGlsZElkIiwibWV0aG9kcyIsIm5hdmkiLCJlIiwidXJsIiwiY3VycmVudFRhcmdldCIsImRhdGFzZXQiLCJ0YXJnZXQiLCJXeFV0aWxzIiwiYmFja09yTmF2aWdhdGUiLCJuYXZpMmF1dGgiLCJpbmRleCIsImlueCIsIlRpcHMiLCJ0b2FzdCIsInZhbHVlIiwic3RhdHVzIiwid2VweSIsIiRpbnN0YW5jZSIsImdsb2JhbERhdGEiLCJwaWNWaWV3IiwiYmFyZ2FpbmluZyIsIm5hdmlnYXRlVG8iLCJhZ2VudCIsInBpbnR1YW4iLCJjaGlsZHMiLCJnZXRTdG9yYWdlU3luYyIsInN3aXRjaFRhYiIsInRvT3JkZXIiLCJpZCIsIm9wdCIsImdldGJ5Y2hpbGQiLCJyZXMiLCJjb25zb2xlIiwibG9nIiwiJGFwcGx5IiwicGFnZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQ0U7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7Ozs7Ozs7Ozs7Ozs7SUFDcUJBLEU7Ozs7Ozs7Ozs7Ozs7OzhLQUNuQkMsTSxHQUFTO0FBQ1BDLDhCQUF3QjtBQURqQixLLFFBR1RDLFUsR0FBYTtBQUNYQztBQURXLEssUUFHYkMsSSxHQUFPO0FBQ0w7QUFDQUMsaUJBQVcsQ0FBQztBQUNWQyxjQUFNLE9BREk7QUFFVkMsY0FBTSxvQkFGSTtBQUdWQyxjQUFNLHFCQUhJO0FBSVZDLGNBQU07QUFKSSxPQUFELEVBS1I7QUFDREgsY0FBTSxNQURMO0FBRURDLGNBQU0sZ0JBRkw7QUFHREMsY0FBTSxFQUhMO0FBSURDLGNBQU07QUFKTCxPQUxRLEVBVVI7QUFDREgsY0FBTSxNQURMO0FBRURDLGNBQU0sZ0JBRkw7QUFHREMsY0FBTSxxQkFITDtBQUlEQyxjQUFNO0FBSkwsT0FWUSxFQWVSO0FBQ0RILGNBQU0sTUFETDtBQUVEQyxjQUFNLGdCQUZMO0FBR0RDLGNBQU0scUJBSEw7QUFJREMsY0FBTTtBQUpMLE9BZlEsQ0FGTjs7QUF3QkxDLGNBQVEsRUF4Qkg7QUF5QkxDLGVBQVM7QUF6QkosSyxRQWtDUEMsTyxHQUFVO0FBQ1JDLFVBRFEsZ0JBQ0hDLENBREcsRUFDQTtBQUNOLFlBQUlDLE1BQU1ELEVBQUVFLGFBQUYsQ0FBZ0JDLE9BQWhCLENBQXdCRixHQUF4QixJQUErQkQsRUFBRUksTUFBRixDQUFTRCxPQUFULENBQWlCRixHQUExRDtBQUNBLFlBQUlBLEdBQUosRUFBUztBQUNQSSw0QkFBUUMsY0FBUixDQUF1QkwsR0FBdkI7QUFDRDtBQUNGLE9BTk87QUFRUk0sZUFSUSxxQkFRRVAsQ0FSRixFQVFLO0FBQ1gsWUFBSUMsTUFBTUQsRUFBRUUsYUFBRixDQUFnQkMsT0FBaEIsQ0FBd0JGLEdBQXhCLElBQStCRCxFQUFFSSxNQUFGLENBQVNELE9BQVQsQ0FBaUJGLEdBQTFEO0FBQUEsWUFDRU8sUUFBUVIsRUFBRUUsYUFBRixDQUFnQkMsT0FBaEIsQ0FBd0JNLEdBRGxDO0FBQUEsWUFFRWQsT0FBT0ssRUFBRUUsYUFBRixDQUFnQkMsT0FBaEIsQ0FBd0JSLElBQXhCLElBQWdDSyxFQUFFSSxNQUFGLENBQVNELE9BQVQsQ0FBaUJSLElBRjFEO0FBR0EsWUFBSSxDQUFDTSxHQUFMLEVBQVU7QUFDUlMseUJBQUtDLEtBQUwsQ0FBVyxhQUFYLEVBQTBCLFlBQU0sQ0FBRSxDQUFsQyxFQUFvQyxNQUFwQztBQUNBO0FBQ0Q7QUFDRCxZQUFJQyxRQUFRLEtBQUtoQixNQUFMLENBQVlpQixNQUFaLENBQW1CTCxLQUFuQixFQUEwQmIsSUFBMUIsQ0FBWjtBQUNBLFlBQUlNLE9BQU8scUJBQVgsRUFBa0M7QUFDaENhLHlCQUFLQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJDLE9BQTFCLEdBQW9DTCxLQUFwQztBQUNEO0FBQ0QsWUFBSVgsT0FBTyxxQkFBWCxFQUFrQztBQUNoQ0EsZ0JBQU1BLE1BQU0sTUFBTixHQUFlVyxLQUFyQjtBQUNEO0FBQ0QsWUFBSVgsR0FBSixFQUFTO0FBQ1BJLDRCQUFRQyxjQUFSLENBQXVCTCxHQUF2QjtBQUNEO0FBRUYsT0EzQk87QUE0QlJpQixnQkE1QlEsd0JBNEJLO0FBQ1hKLHVCQUFLSyxVQUFMLENBQWdCO0FBQ2RsQixlQUFLO0FBRFMsU0FBaEI7QUFHRCxPQWhDTztBQWlDUm1CLFdBakNRLG1CQWlDQTtBQUNOTix1QkFBS0ssVUFBTCxDQUFnQjtBQUNkbEIsZUFBSztBQURTLFNBQWhCO0FBR0QsT0FyQ087QUFzQ1JvQixhQXRDUSxxQkFzQ0U7QUFDUlAsdUJBQUtLLFVBQUwsQ0FBZ0I7QUFDZGxCLGVBQUs7QUFEUyxTQUFoQjtBQUdELE9BMUNPO0FBMkNScUIsWUEzQ1Esb0JBMkNDO0FBQ1AsWUFBSVIsZUFBS1MsY0FBTCxDQUFvQixRQUFwQixDQUFKLEVBQW1DO0FBQ2pDVCx5QkFBS0ssVUFBTCxDQUFnQjtBQUNkbEIsaUJBQUs7QUFEUyxXQUFoQjtBQUdELFNBSkQsTUFJTztBQUNMUyx5QkFBS0MsS0FBTCxDQUFXLFlBQVgsRUFBeUIsWUFBTTtBQUM3QkcsMkJBQUtVLFNBQUwsQ0FBZTtBQUNidkIsbUJBQUs7QUFEUSxhQUFmO0FBR0QsV0FKRCxFQUlHLE1BSkg7QUFLRDtBQUNGLE9BdkRPO0FBd0RSd0IsYUF4RFEsbUJBd0RBQyxFQXhEQSxFQXdESTtBQUNWWix1QkFBS0ssVUFBTCxDQUFnQjtBQUNkbEIsZUFBSyxpQkFBaUJ5QjtBQURSLFNBQWhCO0FBR0Q7QUE1RE8sSzs7Ozs7OzJGQVBHQyxHOzs7Ozs7QUFDWCxxQkFBSzlCLE9BQUwsR0FBZThCLElBQUk5QixPQUFuQjs7dUJBQ2dCWCxjQUFPMEMsVUFBUCxDQUFrQixLQUFLL0IsT0FBdkIsQzs7O0FBQVpnQyxtQjs7QUFDSixxQkFBS2pDLE1BQUwsR0FBY2lDLEdBQWQ7QUFDQUMsd0JBQVFDLEdBQVIsQ0FBWSxLQUFLbkMsTUFBakI7QUFDQSxxQkFBS29DLE1BQUw7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUF2QzRCbEIsZUFBS21CLEk7O2tCQUFoQmhELEUiLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuICBpbXBvcnQgd2VweSBmcm9tIFwid2VweVwiO1xyXG4gIGltcG9ydCBUaXBzIGZyb20gXCJAL3V0aWxzL1RpcHNcIlxyXG4gIGltcG9ydCBjb25maWcgZnJvbSBcIi4uL2FwaVwiXHJcbiAgaW1wb3J0IFd4VXRpbHMgZnJvbSBcIkAvdXRpbHMvV3hVdGlsc1wiXHJcbiAgaW1wb3J0IGNvbnRhY3QgZnJvbSBcIkAvY29tcG9uZW50cy9jb21tb24vY29udGFjdFwiXHJcbiAgZXhwb3J0IGRlZmF1bHQgY2xhc3MgTXkgZXh0ZW5kcyB3ZXB5LnBhZ2Uge1xyXG4gICAgY29uZmlnID0ge1xyXG4gICAgICBuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0OiBcIuaIkeeahOWtpuexjVwiXHJcbiAgICB9O1xyXG4gICAgY29tcG9uZW50cyA9IHtcclxuICAgICAgY29udGFjdFxyXG4gICAgfVxyXG4gICAgZGF0YSA9IHtcclxuICAgICAgLy8g5a2m57GN57O757ufXHJcbiAgICAgIGJvb2tJdGVtczogW3tcclxuICAgICAgICBuYW1lOiAn5b2V5Y+W6YCa55+l5LmmJyxcclxuICAgICAgICBpY29uOiAnY3VJY29uLXByb2ZpbGVmaWxsJyxcclxuICAgICAgICBwYXRoOiAnL3BhZ2VzL2hvbWUvcGljVmlldycsXHJcbiAgICAgICAgdHlwZTogJ2FkbWlzc2lvbkxldHRlcidcclxuICAgICAgfSwge1xyXG4gICAgICAgIG5hbWU6ICfnlLXlrZDljY/orq4nLFxyXG4gICAgICAgIGljb246ICdjdUljb24tcGljZmlsbCcsXHJcbiAgICAgICAgcGF0aDogJycsXHJcbiAgICAgICAgdHlwZTogJ2FncmVlbWVudElkJ1xyXG4gICAgICB9LCB7XHJcbiAgICAgICAgbmFtZTogJ+WFpeiQpemhu+efpScsXHJcbiAgICAgICAgaWNvbjogJ2N1SWNvbi1waWNmaWxsJyxcclxuICAgICAgICBwYXRoOiAnL3BhZ2VzL2hvbWUvcGljVmlldycsXHJcbiAgICAgICAgdHlwZTogJ25vdGljZSdcclxuICAgICAgfSwge1xyXG4gICAgICAgIG5hbWU6ICfmr5XkuJror4HkuaYnLFxyXG4gICAgICAgIGljb246ICdjdUljb24tcGljZmlsbCcsXHJcbiAgICAgICAgcGF0aDogJy9wYWdlcy9ob21lL3BpY1ZpZXcnLFxyXG4gICAgICAgIHR5cGU6ICdkaXBsb21hJ1xyXG4gICAgICB9XSxcclxuXHJcbiAgICAgIG15SW5mbzoge30sXHJcbiAgICAgIGNoaWxkSWQ6ICcnXHJcbiAgICB9O1xyXG4gICAgYXN5bmMgb25Mb2FkKG9wdCkge1xyXG4gICAgICB0aGlzLmNoaWxkSWQgPSBvcHQuY2hpbGRJZFxyXG4gICAgICBsZXQgcmVzID0gYXdhaXQgY29uZmlnLmdldGJ5Y2hpbGQodGhpcy5jaGlsZElkKVxyXG4gICAgICB0aGlzLm15SW5mbyA9IHJlc1xyXG4gICAgICBjb25zb2xlLmxvZyh0aGlzLm15SW5mbylcclxuICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgfVxyXG4gICAgbWV0aG9kcyA9IHtcclxuICAgICAgbmF2aShlKSB7XHJcbiAgICAgICAgbGV0IHVybCA9IGUuY3VycmVudFRhcmdldC5kYXRhc2V0LnVybCB8fCBlLnRhcmdldC5kYXRhc2V0LnVybFxyXG4gICAgICAgIGlmICh1cmwpIHtcclxuICAgICAgICAgIFd4VXRpbHMuYmFja09yTmF2aWdhdGUodXJsKVxyXG4gICAgICAgIH1cclxuICAgICAgfSxcclxuXHJcbiAgICAgIG5hdmkyYXV0aChlKSB7XHJcbiAgICAgICAgbGV0IHVybCA9IGUuY3VycmVudFRhcmdldC5kYXRhc2V0LnVybCB8fCBlLnRhcmdldC5kYXRhc2V0LnVybCxcclxuICAgICAgICAgIGluZGV4ID0gZS5jdXJyZW50VGFyZ2V0LmRhdGFzZXQuaW54LFxyXG4gICAgICAgICAgdHlwZSA9IGUuY3VycmVudFRhcmdldC5kYXRhc2V0LnR5cGUgfHwgZS50YXJnZXQuZGF0YXNldC50eXBlXHJcbiAgICAgICAgaWYgKCF1cmwpIHtcclxuICAgICAgICAgIFRpcHMudG9hc3QoJ+WKn+iDveWNs+WwhuS4iue6v++8jOaVrOivt+acn+W+hScsICgpID0+IHt9LCAnbm9uZScpXHJcbiAgICAgICAgICByZXR1cm5cclxuICAgICAgICB9XHJcbiAgICAgICAgbGV0IHZhbHVlID0gdGhpcy5teUluZm8uc3RhdHVzW2luZGV4XVt0eXBlXVxyXG4gICAgICAgIGlmICh1cmwgPT0gJy9wYWdlcy9ob21lL3BpY1ZpZXcnKSB7XHJcbiAgICAgICAgICB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnBpY1ZpZXcgPSB2YWx1ZVxyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodXJsICE9ICcvcGFnZXMvaG9tZS9waWNWaWV3Jykge1xyXG4gICAgICAgICAgdXJsID0gdXJsICsgJz9pZD0nICsgdmFsdWVcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKHVybCkge1xyXG4gICAgICAgICAgV3hVdGlscy5iYWNrT3JOYXZpZ2F0ZSh1cmwpXHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgfSxcclxuICAgICAgYmFyZ2FpbmluZygpIHtcclxuICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgdXJsOiAnLi9iYXJnYWluaW5nJ1xyXG4gICAgICAgIH0pO1xyXG4gICAgICB9LFxyXG4gICAgICBhZ2VudCgpIHtcclxuICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgdXJsOiAnL2FnZW50L3BhZ2VzL2luZGV4J1xyXG4gICAgICAgIH0pO1xyXG4gICAgICB9LFxyXG4gICAgICBwaW50dWFuKCkge1xyXG4gICAgICAgIHdlcHkubmF2aWdhdGVUbyh7XHJcbiAgICAgICAgICB1cmw6ICcuL3BpbnR1YW4nXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0sXHJcbiAgICAgIGNoaWxkcygpIHtcclxuICAgICAgICBpZiAod2VweS5nZXRTdG9yYWdlU3luYygnbW9iaWxlJykpIHtcclxuICAgICAgICAgIHdlcHkubmF2aWdhdGVUbyh7XHJcbiAgICAgICAgICAgIHVybDogJy9wYWdlcy9tZWV0L2NoaWxkcydcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBUaXBzLnRvYXN0KCfpnIDopoHlhYjnu5HlrprmiYvmnLrlj7flk6Z+JywgKCkgPT4ge1xyXG4gICAgICAgICAgICB3ZXB5LnN3aXRjaFRhYih7XHJcbiAgICAgICAgICAgICAgdXJsOiAnL3BhZ2VzL21lZXQvbWVldCdcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICB9LCAnbm9uZScpXHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG4gICAgICB0b09yZGVyKGlkKSB7XHJcbiAgICAgICAgd2VweS5uYXZpZ2F0ZVRvKHtcclxuICAgICAgICAgIHVybDogJy4vb3JkZXJzP2lkPScgKyBpZFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gIH1cclxuIl19