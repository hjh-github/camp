'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _base2 = require('./../api/base.js');

var _base3 = _interopRequireDefault(_base2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var config = function (_base) {
  _inherits(config, _base);

  function config() {
    _classCallCheck(this, config);

    return _possibleConstructorReturn(this, (config.__proto__ || Object.getPrototypeOf(config)).apply(this, arguments));
  }

  _createClass(config, null, [{
    key: 'getbychild',

    // 获取首页数据
    value: function () {
      var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(childId) {
        var url, params;
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                url = this.baseUrl + '/student/getbychild';
                params = {
                  childId: childId,
                  sessionId: _wepy2.default.$instance.globalData.sessionId
                };
                return _context.abrupt('return', this.post(url, params, true).then(function (res) {
                  return res;
                }));

              case 3:
              case 'end':
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function getbychild(_x) {
        return _ref.apply(this, arguments);
      }

      return getbychild;
    }()
    // 获取更多视频数据
    // static async videoList(opt) {
    //   let url = `${this.baseUrl}/video/list`;
    //   let params = {
    //     ...opt,
    //     sessionId: wepy.$instance.globalData.sessionId
    //   }
    //   return this.post(url, params, true).then(res => {
    //     return res;
    //   })
    // }

  }]);

  return config;
}(_base3.default);

exports.default = config;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwaS5qcyJdLCJuYW1lcyI6WyJjb25maWciLCJjaGlsZElkIiwidXJsIiwiYmFzZVVybCIsInBhcmFtcyIsInNlc3Npb25JZCIsIndlcHkiLCIkaW5zdGFuY2UiLCJnbG9iYWxEYXRhIiwicG9zdCIsInRoZW4iLCJyZXMiLCJiYXNlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBQTs7OztBQUNBOzs7Ozs7Ozs7Ozs7OztJQUVxQkEsTTs7Ozs7Ozs7Ozs7O0FBQ25COzswRkFDd0JDLE87Ozs7OztBQUNsQkMsbUIsR0FBUyxLQUFLQyxPO0FBQ2RDLHNCLEdBQVM7QUFDWEgsa0NBRFc7QUFFWEksNkJBQVdDLGVBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQkg7QUFGMUIsaUI7aURBSU4sS0FBS0ksSUFBTCxDQUFVUCxHQUFWLEVBQWVFLE1BQWYsRUFBdUIsSUFBdkIsRUFBNkJNLElBQTdCLENBQWtDLGVBQU87QUFDOUMseUJBQU9DLEdBQVA7QUFDRCxpQkFGTSxDOzs7Ozs7Ozs7Ozs7Ozs7O0FBSVQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7RUF0QmtDQyxjOztrQkFBZlosTSIsImZpbGUiOiJhcGkuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgd2VweSBmcm9tICd3ZXB5J1xyXG5pbXBvcnQgYmFzZSBmcm9tICdAL2FwaS9iYXNlJ1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgY29uZmlnIGV4dGVuZHMgYmFzZSB7XHJcbiAgLy8g6I635Y+W6aaW6aG15pWw5o2uXHJcbiAgc3RhdGljIGFzeW5jIGdldGJ5Y2hpbGQoY2hpbGRJZCkge1xyXG4gICAgbGV0IHVybCA9IGAke3RoaXMuYmFzZVVybH0vc3R1ZGVudC9nZXRieWNoaWxkYDtcclxuICAgIGxldCBwYXJhbXMgPSB7XG4gICAgICBjaGlsZElkLFxyXG4gICAgICBzZXNzaW9uSWQ6IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuc2Vzc2lvbklkXHJcbiAgICB9XHJcbiAgICByZXR1cm4gdGhpcy5wb3N0KHVybCwgcGFyYW1zLCB0cnVlKS50aGVuKHJlcyA9PiB7XHJcbiAgICAgIHJldHVybiByZXM7XHJcbiAgICB9KVxyXG4gIH1cbiAgLy8g6I635Y+W5pu05aSa6KeG6aKR5pWw5o2uXG4gIC8vIHN0YXRpYyBhc3luYyB2aWRlb0xpc3Qob3B0KSB7XG4gIC8vICAgbGV0IHVybCA9IGAke3RoaXMuYmFzZVVybH0vdmlkZW8vbGlzdGA7XG4gIC8vICAgbGV0IHBhcmFtcyA9IHtcbiAgLy8gICAgIC4uLm9wdCxcbiAgLy8gICAgIHNlc3Npb25JZDogd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5zZXNzaW9uSWRcbiAgLy8gICB9XG4gIC8vICAgcmV0dXJuIHRoaXMucG9zdCh1cmwsIHBhcmFtcywgdHJ1ZSkudGhlbihyZXMgPT4ge1xuICAvLyAgICAgcmV0dXJuIHJlcztcbiAgLy8gICB9KVxuICAvLyB9XHJcbn1cbiJdfQ==