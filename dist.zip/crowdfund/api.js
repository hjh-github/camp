'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = undefined;

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _base2 = require('./../api/base.js');

var _base3 = _interopRequireDefault(_base2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var config = function (_base) {
  _inherits(config, _base);

  function config() {
    _classCallCheck(this, config);

    return _possibleConstructorReturn(this, (config.__proto__ || Object.getPrototypeOf(config)).apply(this, arguments));
  }

  _createClass(config, null, [{
    key: 'videoIndex',

    // 获取首页数据
    value: function () {
      var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(opt) {
        var url, params;
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                url = this.baseUrl + '/video';
                params = {
                  sessionId: _wepy2.default.$instance.globalData.sessionId
                };
                return _context.abrupt('return', this.post(url, params, true).then(function (res) {
                  return res;
                }));

              case 3:
              case 'end':
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function videoIndex(_x) {
        return _ref.apply(this, arguments);
      }

      return videoIndex;
    }()
    // 获取众筹详情

  }, {
    key: 'getSupportDetai',
    value: function () {
      var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(regId) {
        var url, params;
        return regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                url = this.baseUrl + '/crowdfunding/getSupportDetai';
                params = {
                  regId: regId,
                  sessionId: _wepy2.default.$instance.globalData.sessionId
                };
                return _context2.abrupt('return', this.get(url, params, true, true, true).then(function (res) {
                  return res;
                }));

              case 3:
              case 'end':
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));

      function getSupportDetai(_x2) {
        return _ref2.apply(this, arguments);
      }

      return getSupportDetai;
    }()
    // 发起众筹

  }, {
    key: 'toCrowdfunding',
    value: function () {
      var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(opt) {
        var url, params;
        return regeneratorRuntime.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                url = this.baseUrl + '/crowdfunding/toCrowdfunding';
                params = _extends({}, opt, {
                  sessionId: _wepy2.default.$instance.globalData.sessionId
                });
                return _context3.abrupt('return', this.post(url, params, true, true, true).then(function (res) {
                  return res;
                }));

              case 3:
              case 'end':
                return _context3.stop();
            }
          }
        }, _callee3, this);
      }));

      function toCrowdfunding(_x3) {
        return _ref3.apply(this, arguments);
      }

      return toCrowdfunding;
    }()
    // 初始化可支持金额

  }, {
    key: 'toSupport',
    value: function () {
      var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4(regId) {
        var url, params;
        return regeneratorRuntime.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                url = this.baseUrl + '/crowdfunding/toSupport';
                params = {
                  regId: regId,
                  sessionId: _wepy2.default.$instance.globalData.sessionId
                };
                return _context4.abrupt('return', this.post(url, params, true, true, true).then(function (res) {
                  return res;
                }));

              case 3:
              case 'end':
                return _context4.stop();
            }
          }
        }, _callee4, this);
      }));

      function toSupport(_x4) {
        return _ref4.apply(this, arguments);
      }

      return toSupport;
    }()
    // 提交支持订单

  }, {
    key: 'commit',
    value: function () {
      var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5(opt) {
        var url, params;
        return regeneratorRuntime.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                url = this.baseUrl + '/crowdfunding/commit';
                params = _extends({}, opt, {
                  sessionId: _wepy2.default.$instance.globalData.sessionId
                });
                return _context5.abrupt('return', this.post(url, params, true, true, true).then(function (res) {
                  return res;
                }));

              case 3:
              case 'end':
                return _context5.stop();
            }
          }
        }, _callee5, this);
      }));

      function commit(_x5) {
        return _ref5.apply(this, arguments);
      }

      return commit;
    }()
    // 提交支持订单

  }, {
    key: 'crowdfunds',
    value: function () {
      var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
        var url, params;
        return regeneratorRuntime.wrap(function _callee6$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                url = this.baseUrl + '/member/crowdfunding/list';
                params = {
                  sessionId: _wepy2.default.$instance.globalData.sessionId
                };
                return _context6.abrupt('return', this.post(url, params, true, true, true).then(function (res) {
                  return res;
                }));

              case 3:
              case 'end':
                return _context6.stop();
            }
          }
        }, _callee6, this);
      }));

      function crowdfunds() {
        return _ref6.apply(this, arguments);
      }

      return crowdfunds;
    }()
  }]);

  return config;
}(_base3.default);

exports.default = config;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwaS5qcyJdLCJuYW1lcyI6WyJjb25maWciLCJvcHQiLCJ1cmwiLCJiYXNlVXJsIiwicGFyYW1zIiwic2Vzc2lvbklkIiwid2VweSIsIiRpbnN0YW5jZSIsImdsb2JhbERhdGEiLCJwb3N0IiwidGhlbiIsInJlcyIsInJlZ0lkIiwiZ2V0IiwiYmFzZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7QUFBQTs7OztBQUNBOzs7Ozs7Ozs7Ozs7OztJQUVxQkEsTTs7Ozs7Ozs7Ozs7O0FBQ25COzswRkFDd0JDLEc7Ozs7OztBQUNsQkMsbUIsR0FBUyxLQUFLQyxPO0FBQ2RDLHNCLEdBQVM7QUFDWEMsNkJBQVdDLGVBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQkg7QUFEMUIsaUI7aURBR04sS0FBS0ksSUFBTCxDQUFVUCxHQUFWLEVBQWVFLE1BQWYsRUFBdUIsSUFBdkIsRUFBNkJNLElBQTdCLENBQWtDLGVBQU87QUFDOUMseUJBQU9DLEdBQVA7QUFDRCxpQkFGTSxDOzs7Ozs7Ozs7Ozs7Ozs7O0FBSVQ7Ozs7OzRGQUM2QkMsSzs7Ozs7O0FBQ3ZCVixtQixHQUFTLEtBQUtDLE87QUFDZEMsc0IsR0FBUztBQUNYUSw4QkFEVztBQUVYUCw2QkFBV0MsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCSDtBQUYxQixpQjtrREFJTixLQUFLUSxHQUFMLENBQVNYLEdBQVQsRUFBY0UsTUFBZCxFQUFzQixJQUF0QixFQUEyQixJQUEzQixFQUFnQyxJQUFoQyxFQUFzQ00sSUFBdEMsQ0FBMkMsZUFBTztBQUN2RCx5QkFBT0MsR0FBUDtBQUNELGlCQUZNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJVDs7Ozs7NEZBQzRCVixHOzs7Ozs7QUFDdEJDLG1CLEdBQVMsS0FBS0MsTztBQUNkQyxzQixnQkFDQ0gsRztBQUNISSw2QkFBV0MsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCSDs7a0RBRWhDLEtBQUtJLElBQUwsQ0FBVVAsR0FBVixFQUFlRSxNQUFmLEVBQXVCLElBQXZCLEVBQTRCLElBQTVCLEVBQWlDLElBQWpDLEVBQXVDTSxJQUF2QyxDQUE0QyxlQUFPO0FBQ3hELHlCQUFPQyxHQUFQO0FBQ0QsaUJBRk0sQzs7Ozs7Ozs7Ozs7Ozs7OztBQUlSOzs7Ozs0RkFDdUJDLEs7Ozs7OztBQUNsQlYsbUIsR0FBUyxLQUFLQyxPO0FBQ2RDLHNCLEdBQVM7QUFDWFEsOEJBRFc7QUFFWFAsNkJBQVdDLGVBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQkg7QUFGMUIsaUI7a0RBSU4sS0FBS0ksSUFBTCxDQUFVUCxHQUFWLEVBQWVFLE1BQWYsRUFBdUIsSUFBdkIsRUFBNEIsSUFBNUIsRUFBaUMsSUFBakMsRUFBdUNNLElBQXZDLENBQTRDLGVBQU87QUFDeEQseUJBQU9DLEdBQVA7QUFDRCxpQkFGTSxDOzs7Ozs7Ozs7Ozs7Ozs7O0FBSVI7Ozs7OzRGQUNvQlYsRzs7Ozs7O0FBQ2ZDLG1CLEdBQVMsS0FBS0MsTztBQUNkQyxzQixnQkFDQ0gsRztBQUNISSw2QkFBV0MsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCSDs7a0RBRWhDLEtBQUtJLElBQUwsQ0FBVVAsR0FBVixFQUFlRSxNQUFmLEVBQXVCLElBQXZCLEVBQTRCLElBQTVCLEVBQWlDLElBQWpDLEVBQXVDTSxJQUF2QyxDQUE0QyxlQUFPO0FBQ3hELHlCQUFPQyxHQUFQO0FBQ0QsaUJBRk0sQzs7Ozs7Ozs7Ozs7Ozs7OztBQUlUOzs7Ozs7Ozs7OztBQUVNVCxtQixHQUFTLEtBQUtDLE87QUFDZEMsc0IsR0FBUztBQUNYQyw2QkFBV0MsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCSDtBQUQxQixpQjtrREFHTixLQUFLSSxJQUFMLENBQVVQLEdBQVYsRUFBZUUsTUFBZixFQUF1QixJQUF2QixFQUE0QixJQUE1QixFQUFpQyxJQUFqQyxFQUF1Q00sSUFBdkMsQ0FBNEMsZUFBTztBQUN4RCx5QkFBT0MsR0FBUDtBQUNELGlCQUZNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUE3RHlCRyxjOztrQkFBZmQsTSIsImZpbGUiOiJhcGkuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgd2VweSBmcm9tICd3ZXB5J1xyXG5pbXBvcnQgYmFzZSBmcm9tICdAL2FwaS9iYXNlJ1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgY29uZmlnIGV4dGVuZHMgYmFzZSB7XHJcbiAgLy8g6I635Y+W6aaW6aG15pWw5o2uXHJcbiAgc3RhdGljIGFzeW5jIHZpZGVvSW5kZXgob3B0KSB7XHJcbiAgICBsZXQgdXJsID0gYCR7dGhpcy5iYXNlVXJsfS92aWRlb2A7XHJcbiAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICBzZXNzaW9uSWQ6IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuc2Vzc2lvbklkXHJcbiAgICB9XHJcbiAgICByZXR1cm4gdGhpcy5wb3N0KHVybCwgcGFyYW1zLCB0cnVlKS50aGVuKHJlcyA9PiB7XHJcbiAgICAgIHJldHVybiByZXM7XHJcbiAgICB9KVxyXG4gIH1cclxuICAvLyDojrflj5bkvJfnrbnor6bmg4VcclxuICBzdGF0aWMgYXN5bmMgZ2V0U3VwcG9ydERldGFpKHJlZ0lkKSB7XHJcbiAgICBsZXQgdXJsID0gYCR7dGhpcy5iYXNlVXJsfS9jcm93ZGZ1bmRpbmcvZ2V0U3VwcG9ydERldGFpYDtcclxuICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgIHJlZ0lkLFxyXG4gICAgICBzZXNzaW9uSWQ6IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuc2Vzc2lvbklkXHJcbiAgICB9XHJcbiAgICByZXR1cm4gdGhpcy5nZXQodXJsLCBwYXJhbXMsIHRydWUsdHJ1ZSx0cnVlKS50aGVuKHJlcyA9PiB7XHJcbiAgICAgIHJldHVybiByZXM7XHJcbiAgICB9KVxyXG4gIH1cclxuICAvLyDlj5HotbfkvJfnrblcclxuICBzdGF0aWMgYXN5bmMgdG9Dcm93ZGZ1bmRpbmcob3B0KSB7XHJcbiAgICBsZXQgdXJsID0gYCR7dGhpcy5iYXNlVXJsfS9jcm93ZGZ1bmRpbmcvdG9Dcm93ZGZ1bmRpbmdgO1xyXG4gICAgbGV0IHBhcmFtcyA9IHtcclxuICAgICAgLi4ub3B0LFxyXG4gICAgICBzZXNzaW9uSWQ6IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuc2Vzc2lvbklkXHJcbiAgICB9XHJcbiAgICByZXR1cm4gdGhpcy5wb3N0KHVybCwgcGFyYW1zLCB0cnVlLHRydWUsdHJ1ZSkudGhlbihyZXMgPT4ge1xyXG4gICAgICByZXR1cm4gcmVzO1xyXG4gICAgfSlcclxuICB9XHJcbiAgIC8vIOWIneWni+WMluWPr+aUr+aMgemHkeminVxyXG4gICBzdGF0aWMgYXN5bmMgdG9TdXBwb3J0KHJlZ0lkKSB7XHJcbiAgICBsZXQgdXJsID0gYCR7dGhpcy5iYXNlVXJsfS9jcm93ZGZ1bmRpbmcvdG9TdXBwb3J0YDtcclxuICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgIHJlZ0lkLFxyXG4gICAgICBzZXNzaW9uSWQ6IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuc2Vzc2lvbklkXHJcbiAgICB9XHJcbiAgICByZXR1cm4gdGhpcy5wb3N0KHVybCwgcGFyYW1zLCB0cnVlLHRydWUsdHJ1ZSkudGhlbihyZXMgPT4ge1xyXG4gICAgICByZXR1cm4gcmVzO1xyXG4gICAgfSlcclxuICB9XHJcbiAgIC8vIOaPkOS6pOaUr+aMgeiuouWNlVxyXG4gICBzdGF0aWMgYXN5bmMgY29tbWl0KG9wdCkge1xyXG4gICAgbGV0IHVybCA9IGAke3RoaXMuYmFzZVVybH0vY3Jvd2RmdW5kaW5nL2NvbW1pdGA7XHJcbiAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICAuLi5vcHQsXHJcbiAgICAgIHNlc3Npb25JZDogd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5zZXNzaW9uSWRcclxuICAgIH1cclxuICAgIHJldHVybiB0aGlzLnBvc3QodXJsLCBwYXJhbXMsIHRydWUsdHJ1ZSx0cnVlKS50aGVuKHJlcyA9PiB7XHJcbiAgICAgIHJldHVybiByZXM7XHJcbiAgICB9KVxyXG4gIH1cclxuICAvLyDmj5DkuqTmlK/mjIHorqLljZVcclxuICBzdGF0aWMgYXN5bmMgY3Jvd2RmdW5kcygpIHtcclxuICAgIGxldCB1cmwgPSBgJHt0aGlzLmJhc2VVcmx9L21lbWJlci9jcm93ZGZ1bmRpbmcvbGlzdGA7XHJcbiAgICBsZXQgcGFyYW1zID0ge1xyXG4gICAgICBzZXNzaW9uSWQ6IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuc2Vzc2lvbklkXHJcbiAgICB9XHJcbiAgICByZXR1cm4gdGhpcy5wb3N0KHVybCwgcGFyYW1zLCB0cnVlLHRydWUsdHJ1ZSkudGhlbihyZXMgPT4ge1xyXG4gICAgICByZXR1cm4gcmVzO1xyXG4gICAgfSlcclxuICB9XHJcbn1cclxuIl19