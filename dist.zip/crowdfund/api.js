'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = undefined;

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _base2 = require('./../api/base.js');

var _base3 = _interopRequireDefault(_base2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var config = function (_base) {
  _inherits(config, _base);

  function config() {
    _classCallCheck(this, config);

    return _possibleConstructorReturn(this, (config.__proto__ || Object.getPrototypeOf(config)).apply(this, arguments));
  }

  _createClass(config, null, [{
    key: 'videoIndex',

    // 获取首页数据
    value: function () {
      var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(opt) {
        var url, params;
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                url = this.baseUrl + '/video';
                params = {
                  sessionId: _wepy2.default.$instance.globalData.sessionId
                };
                return _context.abrupt('return', this.post(url, params, true).then(function (res) {
                  return res;
                }));

              case 3:
              case 'end':
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function videoIndex(_x) {
        return _ref.apply(this, arguments);
      }

      return videoIndex;
    }()
    // 获取众筹详情

  }, {
    key: 'getSupportDetai',
    value: function () {
      var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(regId) {
        var url, params;
        return regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                url = this.baseUrl + '/crowdfunding/getSupportDetai';
                params = {
                  regId: regId,
                  sessionId: _wepy2.default.$instance.globalData.sessionId
                };
                return _context2.abrupt('return', this.get(url, params, true, true, true).then(function (res) {
                  return res;
                }));

              case 3:
              case 'end':
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));

      function getSupportDetai(_x2) {
        return _ref2.apply(this, arguments);
      }

      return getSupportDetai;
    }()
    // 发起众筹

  }, {
    key: 'toCrowdfunding',
    value: function () {
      var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(opt) {
        var url, params;
        return regeneratorRuntime.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                url = this.baseUrl + '/crowdfunding/toCrowdfunding';
                params = _extends({}, opt, {
                  sessionId: _wepy2.default.$instance.globalData.sessionId
                });
                return _context3.abrupt('return', this.post(url, params, true, true, true).then(function (res) {
                  return res;
                }));

              case 3:
              case 'end':
                return _context3.stop();
            }
          }
        }, _callee3, this);
      }));

      function toCrowdfunding(_x3) {
        return _ref3.apply(this, arguments);
      }

      return toCrowdfunding;
    }()
  }]);

  return config;
}(_base3.default);

exports.default = config;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwaS5qcyJdLCJuYW1lcyI6WyJjb25maWciLCJvcHQiLCJ1cmwiLCJiYXNlVXJsIiwicGFyYW1zIiwic2Vzc2lvbklkIiwid2VweSIsIiRpbnN0YW5jZSIsImdsb2JhbERhdGEiLCJwb3N0IiwidGhlbiIsInJlcyIsInJlZ0lkIiwiZ2V0IiwiYmFzZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7QUFBQTs7OztBQUNBOzs7Ozs7Ozs7Ozs7OztJQUVxQkEsTTs7Ozs7Ozs7Ozs7O0FBQ25COzswRkFDd0JDLEc7Ozs7OztBQUNsQkMsbUIsR0FBUyxLQUFLQyxPO0FBQ2RDLHNCLEdBQVM7QUFDWEMsNkJBQVdDLGVBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQkg7QUFEMUIsaUI7aURBR04sS0FBS0ksSUFBTCxDQUFVUCxHQUFWLEVBQWVFLE1BQWYsRUFBdUIsSUFBdkIsRUFBNkJNLElBQTdCLENBQWtDLGVBQU87QUFDOUMseUJBQU9DLEdBQVA7QUFDRCxpQkFGTSxDOzs7Ozs7Ozs7Ozs7Ozs7O0FBSVQ7Ozs7OzRGQUM2QkMsSzs7Ozs7O0FBQ3ZCVixtQixHQUFTLEtBQUtDLE87QUFDZEMsc0IsR0FBUztBQUNYUSw4QkFEVztBQUVYUCw2QkFBV0MsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCSDtBQUYxQixpQjtrREFJTixLQUFLUSxHQUFMLENBQVNYLEdBQVQsRUFBY0UsTUFBZCxFQUFzQixJQUF0QixFQUEyQixJQUEzQixFQUFnQyxJQUFoQyxFQUFzQ00sSUFBdEMsQ0FBMkMsZUFBTztBQUN2RCx5QkFBT0MsR0FBUDtBQUNELGlCQUZNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJVDs7Ozs7NEZBQzRCVixHOzs7Ozs7QUFDdEJDLG1CLEdBQVMsS0FBS0MsTztBQUNkQyxzQixnQkFDQ0gsRztBQUNISSw2QkFBV0MsZUFBS0MsU0FBTCxDQUFlQyxVQUFmLENBQTBCSDs7a0RBRWhDLEtBQUtJLElBQUwsQ0FBVVAsR0FBVixFQUFlRSxNQUFmLEVBQXVCLElBQXZCLEVBQTRCLElBQTVCLEVBQWlDLElBQWpDLEVBQXVDTSxJQUF2QyxDQUE0QyxlQUFPO0FBQ3hELHlCQUFPQyxHQUFQO0FBQ0QsaUJBRk0sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQTdCeUJHLGM7O2tCQUFmZCxNIiwiZmlsZSI6ImFwaS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB3ZXB5IGZyb20gJ3dlcHknXHJcbmltcG9ydCBiYXNlIGZyb20gJ0AvYXBpL2Jhc2UnXHJcblxyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBjb25maWcgZXh0ZW5kcyBiYXNlIHtcclxuICAvLyDojrflj5bpppbpobXmlbDmja5cclxuICBzdGF0aWMgYXN5bmMgdmlkZW9JbmRleChvcHQpIHtcclxuICAgIGxldCB1cmwgPSBgJHt0aGlzLmJhc2VVcmx9L3ZpZGVvYDtcclxuICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgIHNlc3Npb25JZDogd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5zZXNzaW9uSWRcclxuICAgIH1cclxuICAgIHJldHVybiB0aGlzLnBvc3QodXJsLCBwYXJhbXMsIHRydWUpLnRoZW4ocmVzID0+IHtcclxuICAgICAgcmV0dXJuIHJlcztcclxuICAgIH0pXHJcbiAgfVxuICAvLyDojrflj5bkvJfnrbnor6bmg4VcbiAgc3RhdGljIGFzeW5jIGdldFN1cHBvcnREZXRhaShyZWdJZCkge1xuICAgIGxldCB1cmwgPSBgJHt0aGlzLmJhc2VVcmx9L2Nyb3dkZnVuZGluZy9nZXRTdXBwb3J0RGV0YWlgO1xuICAgIGxldCBwYXJhbXMgPSB7XG4gICAgICByZWdJZCxcbiAgICAgIHNlc3Npb25JZDogd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5zZXNzaW9uSWRcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuZ2V0KHVybCwgcGFyYW1zLCB0cnVlLHRydWUsdHJ1ZSkudGhlbihyZXMgPT4ge1xuICAgICAgcmV0dXJuIHJlcztcbiAgICB9KVxuICB9XG4gIC8vIOWPkei1t+S8l+etuVxuICBzdGF0aWMgYXN5bmMgdG9Dcm93ZGZ1bmRpbmcob3B0KSB7XG4gICAgbGV0IHVybCA9IGAke3RoaXMuYmFzZVVybH0vY3Jvd2RmdW5kaW5nL3RvQ3Jvd2RmdW5kaW5nYDtcbiAgICBsZXQgcGFyYW1zID0ge1xuICAgICAgLi4ub3B0LFxuICAgICAgc2Vzc2lvbklkOiB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLnNlc3Npb25JZFxuICAgIH1cbiAgICByZXR1cm4gdGhpcy5wb3N0KHVybCwgcGFyYW1zLCB0cnVlLHRydWUsdHJ1ZSkudGhlbihyZXMgPT4ge1xuICAgICAgcmV0dXJuIHJlcztcbiAgICB9KVxuICB9XHJcbn1cbiJdfQ==