"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _api = require('./../api.js');

var _api2 = _interopRequireDefault(_api);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

var _Lang = require('./../../utils/Lang.js');

var _Lang2 = _interopRequireDefault(_Lang);

var _utils = require('./../../store/utils.js');

var _utils2 = _interopRequireDefault(_utils);

var _contact = require('./../../components/common/contact.js');

var _contact2 = _interopRequireDefault(_contact);

var _info = require('./../../components/detaile/info.js');

var _info2 = _interopRequireDefault(_info);

var _WxUtils = require('./../../utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
  _inherits(Dialog, _wepy$page);

  function Dialog() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, Dialog);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.data = {
      close: "/static/images/close.png",
      TabCur: 0,
      active: true,
      routes: 0,
      regId: '',
      courseInfo: {},
      ActBargainReg: {
        invalidTime: ''
      },
      bargainRecords: [],
      dj: 3000,
      percent: 0,
      info: {},
      modalName: '',
      member: null,
      status: {
        0: {
          a: '砍价中',
          b: ''
        },
        1: {
          a: '砍价完成',
          b: '待支付'
        },
        2: {
          a: '砍价完成',
          b: '已支付'
        },
        3: {
          a: '已过期',
          b: '砍价结束'
        }
      }
    }, _this.config = {
      navigationBarBackgroundColor: '#215E21',
      navigationBarTitleText: '众筹',
      "usingComponents": {
        "l-countdown": "../../components/countdown/index"
      }
    }, _this.components = {
      contact: _contact2.default,
      cInfo: _info2.default
    }, _this.computed = {
      cutPrice: function cutPrice() {
        if (this.ActBargainReg) {
          var act = this.ActBargainReg;
          var _p = act.supportedAmounts * 1,
              _sp = act.coursePrice * 1;
          this.percent = parseInt(_p / _sp * 100);
          return _p;
        }
      }
    }, _this.methods = {
      hideModal: function hideModal() {
        this.modalName = '';
      },
      createImg: function () {
        var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(e) {
          return regeneratorRuntime.wrap(function _callee$(_context) {
            while (1) {
              switch (_context.prev = _context.next) {
                case 0:
                  if (!(e.detail.errMsg == "getUserInfo:ok")) {
                    _context.next = 5;
                    break;
                  }

                  _context.next = 3;
                  return _auth2.default.getUserinfo(e.detail);

                case 3:
                  _utils2.default.save('shareInfo', {
                    course: this.courseInfo,
                    path: 'crowdfund/pages/page',
                    id: this.ActBargainReg.id,
                    type: 4,
                    courseId: this.courseInfo.id
                  });
                  _wepy2.default.navigateTo({
                    url: '/pages/home/share'
                  });

                case 5:
                case "end":
                  return _context.stop();
              }
            }
          }, _callee, this);
        }));

        function createImg(_x) {
          return _ref2.apply(this, arguments);
        }

        return createImg;
      }(),
      toshare: function toshare() {
        this.modalName = 'share';
      },
      tosupport: function tosupport() {
        if (_wepy2.default.getStorageSync('isFans') != 1) {
          _wepy2.default.navigateTo({
            url: "/pages/home/auth?mobile=1"
          });
        } else {
          _wepy2.default.navigateTo({
            url: "/crowdfund/pages/help?id=" + this.info.regId
          });
        }
      },
      toOpen: function toOpen() {
        _WxUtils2.default.backOrRedirect("/pages/detaile/detaile?id=" + this.info.courseInfo.id);
      },
      tabSelect: function tabSelect(e) {
        this.TabCur = e.currentTarget.dataset.id || e.detail.current;
      },
      buy: function buy() {
        _wepy2.default.navigateTo({
          url: "/pages/detaile/sureOrder?type=2&pid=" + this.info.reg.periodId + "&cid=" + this.info.reg.courseId + "&num=1&aid=" + this.info.regId + "&actpid=0"
        });
      },
      topay: function topay() {
        _wepy2.default.navigateTo({
          url: "/pages/my/order?id=" + this.info.orderId
        });
      }
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(Dialog, [{
    key: "onShareAppMessage",
    value: function onShareAppMessage(res) {
      if (res.from === 'button') {
        // 来自页面内转发按钮
        // console.log(res.target)
      }
      return {
        title: this.courseInfo.courseTittle,
        imageUrl: this.courseInfo.image,
        path: '/crowdfund/pages/page?id=' + this.ActBargainReg.id + '&agentId=' + this.member.agentId
      };
    }
  }, {
    key: "onLoad",
    value: function () {
      var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(opt) {
        return regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                this.regId = opt.id || _wepy2.default.$instance.globalData.query.id;
                this.routes = getCurrentPages();
                _context2.next = 4;
                return _auth2.default.login();

              case 4:
                this.member = _wepy2.default.getStorageSync('member');
                _context2.next = 7;
                return this.load();

              case 7:
                this.$apply();

              case 8:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));

      function onLoad(_x2) {
        return _ref3.apply(this, arguments);
      }

      return onLoad;
    }()
  }, {
    key: "onShow",
    value: function () {
      var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
        return regeneratorRuntime.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                if (!this.member) {
                  _context3.next = 4;
                  break;
                }

                _context3.next = 3;
                return this.load();

              case 3:
                this.$apply();

              case 4:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this);
      }));

      function onShow() {
        return _ref4.apply(this, arguments);
      }

      return onShow;
    }()
  }, {
    key: "helpBargain",
    value: function () {
      var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
        var res;
        return regeneratorRuntime.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                _context4.next = 2;
                return _config2.default.helpBargain(this.regId);

              case 2:
                res = _context4.sent;

              case 3:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, this);
      }));

      function helpBargain() {
        return _ref5.apply(this, arguments);
      }

      return helpBargain;
    }()
  }, {
    key: "load",
    value: function () {
      var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
        var _ref7, errcode, data;

        return regeneratorRuntime.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                _context5.next = 2;
                return _api2.default.getSupportDetai(this.regId);

              case 2:
                _ref7 = _context5.sent;
                errcode = _ref7.errcode;
                data = _ref7.data;

                if (errcode == 200) {
                  this.info = data;
                  this.courseInfo = data.courseInfo;
                  this.ActBargainReg = data.reg;
                  console.log(this.ActBargainReg.invalidTime);
                  this.bargainRecords = data.bargainRecords;
                }

              case 6:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5, this);
      }));

      function load() {
        return _ref6.apply(this, arguments);
      }

      return load;
    }()
  }]);

  return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'crowdfund/pages/page'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBhZ2UuanMiXSwibmFtZXMiOlsiRGlhbG9nIiwiZGF0YSIsImNsb3NlIiwiVGFiQ3VyIiwiYWN0aXZlIiwicm91dGVzIiwicmVnSWQiLCJjb3Vyc2VJbmZvIiwiQWN0QmFyZ2FpblJlZyIsImludmFsaWRUaW1lIiwiYmFyZ2FpblJlY29yZHMiLCJkaiIsInBlcmNlbnQiLCJpbmZvIiwibW9kYWxOYW1lIiwibWVtYmVyIiwic3RhdHVzIiwiYSIsImIiLCJjb25maWciLCJuYXZpZ2F0aW9uQmFyQmFja2dyb3VuZENvbG9yIiwibmF2aWdhdGlvbkJhclRpdGxlVGV4dCIsImNvbXBvbmVudHMiLCJjb250YWN0IiwiY0luZm8iLCJjb21wdXRlZCIsImN1dFByaWNlIiwiYWN0IiwiX3AiLCJzdXBwb3J0ZWRBbW91bnRzIiwiX3NwIiwiY291cnNlUHJpY2UiLCJwYXJzZUludCIsIm1ldGhvZHMiLCJoaWRlTW9kYWwiLCJjcmVhdGVJbWciLCJlIiwiZGV0YWlsIiwiZXJyTXNnIiwiYXV0aCIsImdldFVzZXJpbmZvIiwic3RvcmUiLCJzYXZlIiwiY291cnNlIiwicGF0aCIsImlkIiwidHlwZSIsImNvdXJzZUlkIiwid2VweSIsIm5hdmlnYXRlVG8iLCJ1cmwiLCJ0b3NoYXJlIiwidG9zdXBwb3J0IiwiZ2V0U3RvcmFnZVN5bmMiLCJ0b09wZW4iLCJXeFV0aWxzIiwiYmFja09yUmVkaXJlY3QiLCJ0YWJTZWxlY3QiLCJjdXJyZW50VGFyZ2V0IiwiZGF0YXNldCIsImN1cnJlbnQiLCJidXkiLCJyZWciLCJwZXJpb2RJZCIsInRvcGF5Iiwib3JkZXJJZCIsInJlcyIsImZyb20iLCJ0aXRsZSIsImNvdXJzZVRpdHRsZSIsImltYWdlVXJsIiwiaW1hZ2UiLCJhZ2VudElkIiwib3B0IiwiJGluc3RhbmNlIiwiZ2xvYmFsRGF0YSIsInF1ZXJ5IiwiZ2V0Q3VycmVudFBhZ2VzIiwibG9naW4iLCJsb2FkIiwiJGFwcGx5IiwiaGVscEJhcmdhaW4iLCJhcGkiLCJnZXRTdXBwb3J0RGV0YWkiLCJlcnJjb2RlIiwiY29uc29sZSIsImxvZyIsInBhZ2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUNFOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7Ozs7Ozs7Ozs7Ozs7SUFFcUJBLE07Ozs7Ozs7Ozs7Ozs7O3NMQUNuQkMsSSxHQUFPO0FBQ0xDLGFBQU8sMEJBREY7QUFFTEMsY0FBUSxDQUZIO0FBR0xDLGNBQVEsSUFISDtBQUlMQyxjQUFRLENBSkg7QUFLTEMsYUFBTyxFQUxGO0FBTUxDLGtCQUFZLEVBTlA7QUFPTEMscUJBQWU7QUFDYkMscUJBQWE7QUFEQSxPQVBWO0FBVUxDLHNCQUFnQixFQVZYO0FBV0xDLFVBQUksSUFYQztBQVlMQyxlQUFTLENBWko7QUFhTEMsWUFBTSxFQWJEO0FBY0xDLGlCQUFXLEVBZE47QUFlTEMsY0FBUSxJQWZIO0FBZ0JMQyxjQUFRO0FBQ04sV0FBRztBQUNEQyxhQUFHLEtBREY7QUFFREMsYUFBRztBQUZGLFNBREc7QUFLTixXQUFHO0FBQ0RELGFBQUcsTUFERjtBQUVEQyxhQUFHO0FBRkYsU0FMRztBQVNOLFdBQUc7QUFDREQsYUFBRyxNQURGO0FBRURDLGFBQUc7QUFGRixTQVRHO0FBYU4sV0FBRztBQUNERCxhQUFHLEtBREY7QUFFREMsYUFBRztBQUZGO0FBYkc7QUFoQkgsSyxRQW1DUEMsTSxHQUFTO0FBQ1BDLG9DQUE4QixTQUR2QjtBQUVQQyw4QkFBd0IsSUFGakI7QUFHUCx5QkFBbUI7QUFDakIsdUJBQWU7QUFERTtBQUhaLEssUUFPVEMsVSxHQUFhO0FBQ1hDLGdDQURXO0FBRVhDO0FBRlcsSyxRQUliQyxRLEdBQVc7QUFDVEMsY0FEUyxzQkFDRTtBQUNULFlBQUksS0FBS2xCLGFBQVQsRUFBd0I7QUFDdEIsY0FBSW1CLE1BQU0sS0FBS25CLGFBQWY7QUFDQSxjQUFJb0IsS0FBS0QsSUFBSUUsZ0JBQUosR0FBdUIsQ0FBaEM7QUFBQSxjQUNFQyxNQUFNSCxJQUFJSSxXQUFKLEdBQWtCLENBRDFCO0FBRUEsZUFBS25CLE9BQUwsR0FBZW9CLFNBQVNKLEtBQUtFLEdBQUwsR0FBVyxHQUFwQixDQUFmO0FBQ0EsaUJBQU9GLEVBQVA7QUFDRDtBQUNGO0FBVFEsSyxRQW9DWEssTyxHQUFVO0FBQ1JDLGVBRFEsdUJBQ0k7QUFDVixhQUFLcEIsU0FBTCxHQUFpQixFQUFqQjtBQUNELE9BSE87QUFJRnFCLGVBSkU7QUFBQSw2RkFJUUMsQ0FKUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBS0ZBLEVBQUVDLE1BQUYsQ0FBU0MsTUFBVCxJQUFtQixnQkFMakI7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQSx5QkFNRUMsZUFBS0MsV0FBTCxDQUFpQkosRUFBRUMsTUFBbkIsQ0FORjs7QUFBQTtBQU9KSSxrQ0FBTUMsSUFBTixDQUFXLFdBQVgsRUFBd0I7QUFDdEJDLDRCQUFRLEtBQUtwQyxVQURTO0FBRXRCcUMsMEJBQU0sc0JBRmdCO0FBR3RCQyx3QkFBSSxLQUFLckMsYUFBTCxDQUFtQnFDLEVBSEQ7QUFJdEJDLDBCQUFNLENBSmdCO0FBS3RCQyw4QkFBVSxLQUFLeEMsVUFBTCxDQUFnQnNDO0FBTEosbUJBQXhCO0FBT0FHLGlDQUFLQyxVQUFMLENBQWdCO0FBQ2RDLHlCQUFLO0FBRFMsbUJBQWhCOztBQWRJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBbUJSQyxhQW5CUSxxQkFtQkU7QUFDUixhQUFLckMsU0FBTCxHQUFpQixPQUFqQjtBQUNELE9BckJPO0FBc0JSc0MsZUF0QlEsdUJBc0JJO0FBQ1YsWUFBSUosZUFBS0ssY0FBTCxDQUFvQixRQUFwQixLQUFpQyxDQUFyQyxFQUF3QztBQUN0Q0wseUJBQUtDLFVBQUwsQ0FBZ0I7QUFDZEM7QUFEYyxXQUFoQjtBQUdELFNBSkQsTUFJTztBQUNMRix5QkFBS0MsVUFBTCxDQUFnQjtBQUNkQywrQ0FBaUMsS0FBS3JDLElBQUwsQ0FBVVA7QUFEN0IsV0FBaEI7QUFHRDtBQUNGLE9BaENPO0FBaUNSZ0QsWUFqQ1Esb0JBaUNDO0FBQ1BDLDBCQUFRQyxjQUFSLGdDQUFvRCxLQUFLM0MsSUFBTCxDQUFVTixVQUFWLENBQXFCc0MsRUFBekU7QUFDRCxPQW5DTztBQW9DUlksZUFwQ1EscUJBb0NFckIsQ0FwQ0YsRUFvQ0s7QUFDWCxhQUFLakMsTUFBTCxHQUFjaUMsRUFBRXNCLGFBQUYsQ0FBZ0JDLE9BQWhCLENBQXdCZCxFQUF4QixJQUE4QlQsRUFBRUMsTUFBRixDQUFTdUIsT0FBckQ7QUFDRCxPQXRDTztBQXVDUkMsU0F2Q1EsaUJBdUNGO0FBQ0piLHVCQUFLQyxVQUFMLENBQWdCO0FBQ2RDLHdEQUE0QyxLQUFLckMsSUFBTCxDQUFVaUQsR0FBVixDQUFjQyxRQUExRCxhQUEwRSxLQUFLbEQsSUFBTCxDQUFVaUQsR0FBVixDQUFjZixRQUF4RixtQkFBOEcsS0FBS2xDLElBQUwsQ0FBVVAsS0FBeEg7QUFEYyxTQUFoQjtBQUdELE9BM0NPO0FBNENSMEQsV0E1Q1EsbUJBNENBO0FBQ05oQix1QkFBS0MsVUFBTCxDQUFnQjtBQUNkQyx1Q0FBMkIsS0FBS3JDLElBQUwsQ0FBVW9EO0FBRHZCLFNBQWhCO0FBR0Q7QUFoRE8sSzs7Ozs7c0NBekJRQyxHLEVBQUs7QUFDckIsVUFBSUEsSUFBSUMsSUFBSixLQUFhLFFBQWpCLEVBQTJCO0FBQ3pCO0FBQ0E7QUFDRDtBQUNELGFBQU87QUFDTEMsZUFBTyxLQUFLN0QsVUFBTCxDQUFnQjhELFlBRGxCO0FBRUxDLGtCQUFVLEtBQUsvRCxVQUFMLENBQWdCZ0UsS0FGckI7QUFHTDNCLGNBQU0sOEJBQThCLEtBQUtwQyxhQUFMLENBQW1CcUMsRUFBakQsR0FBc0QsV0FBdEQsR0FBb0UsS0FBSzlCLE1BQUwsQ0FBWXlEO0FBSGpGLE9BQVA7QUFLRDs7Ozs0RkFDWUMsRzs7Ozs7QUFDWCxxQkFBS25FLEtBQUwsR0FBYW1FLElBQUk1QixFQUFKLElBQVdHLGVBQUswQixTQUFMLENBQWVDLFVBQWYsQ0FBMEJDLEtBQTFCLENBQWdDL0IsRUFBeEQ7QUFDQSxxQkFBS3hDLE1BQUwsR0FBY3dFLGlCQUFkOzt1QkFDTXRDLGVBQUt1QyxLQUFMLEU7OztBQUNOLHFCQUFLL0QsTUFBTCxHQUFjaUMsZUFBS0ssY0FBTCxDQUFvQixRQUFwQixDQUFkOzt1QkFDTSxLQUFLMEIsSUFBTCxFOzs7QUFDTixxQkFBS0MsTUFBTDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3FCQUdJLEtBQUtqRSxNOzs7Ozs7dUJBQ0QsS0FBS2dFLElBQUwsRTs7O0FBQ04scUJBQUtDLE1BQUw7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3VCQXNEYzdELGlCQUFPOEQsV0FBUCxDQUFtQixLQUFLM0UsS0FBeEIsQzs7O0FBQVo0RCxtQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3VCQU1NZ0IsY0FBSUMsZUFBSixDQUFvQixLQUFLN0UsS0FBekIsQzs7OztBQUZSOEUsdUIsU0FBQUEsTztBQUNBbkYsb0IsU0FBQUEsSTs7QUFFRixvQkFBSW1GLFdBQVcsR0FBZixFQUFvQjtBQUNsQix1QkFBS3ZFLElBQUwsR0FBWVosSUFBWjtBQUNBLHVCQUFLTSxVQUFMLEdBQWtCTixLQUFLTSxVQUF2QjtBQUNBLHVCQUFLQyxhQUFMLEdBQXFCUCxLQUFLNkQsR0FBMUI7QUFDQXVCLDBCQUFRQyxHQUFSLENBQVksS0FBSzlFLGFBQUwsQ0FBbUJDLFdBQS9CO0FBQ0EsdUJBQUtDLGNBQUwsR0FBc0JULEtBQUtTLGNBQTNCO0FBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUFuSitCc0MsZUFBS3VDLEk7O2tCQUFwQnZGLE0iLCJmaWxlIjoicGFnZS5qcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4gIGltcG9ydCB3ZXB5IGZyb20gXCJ3ZXB5XCJcclxuICBpbXBvcnQgY29uZmlnIGZyb20gXCJAL2FwaS9jb25maWdcIlxyXG4gIGltcG9ydCBhcGkgZnJvbSBcIi4uL2FwaVwiXHJcbiAgaW1wb3J0IGF1dGggZnJvbSBcIkAvYXBpL2F1dGhcIlxyXG4gIGltcG9ydCBMYW5nIGZyb20gXCJAL3V0aWxzL0xhbmdcIlxyXG4gIGltcG9ydCBzdG9yZSBmcm9tIFwiQC9zdG9yZS91dGlsc1wiXHJcbiAgaW1wb3J0IGNvbnRhY3QgZnJvbSBcIkAvY29tcG9uZW50cy9jb21tb24vY29udGFjdFwiXHJcbiAgaW1wb3J0IGNJbmZvIGZyb20gXCJAL2NvbXBvbmVudHMvZGV0YWlsZS9pbmZvXCI7XHJcbiAgaW1wb3J0IFd4VXRpbHMgZnJvbSBcIkAvdXRpbHMvV3hVdGlsc1wiXHJcblxyXG4gIGV4cG9ydCBkZWZhdWx0IGNsYXNzIERpYWxvZyBleHRlbmRzIHdlcHkucGFnZSB7XHJcbiAgICBkYXRhID0ge1xyXG4gICAgICBjbG9zZTogXCIvc3RhdGljL2ltYWdlcy9jbG9zZS5wbmdcIixcclxuICAgICAgVGFiQ3VyOiAwLFxyXG4gICAgICBhY3RpdmU6IHRydWUsXHJcbiAgICAgIHJvdXRlczogMCxcclxuICAgICAgcmVnSWQ6ICcnLFxyXG4gICAgICBjb3Vyc2VJbmZvOiB7fSxcclxuICAgICAgQWN0QmFyZ2FpblJlZzoge1xyXG4gICAgICAgIGludmFsaWRUaW1lOiAnJ1xyXG4gICAgICB9LFxyXG4gICAgICBiYXJnYWluUmVjb3JkczogW10sXHJcbiAgICAgIGRqOiAzMDAwLFxyXG4gICAgICBwZXJjZW50OiAwLFxyXG4gICAgICBpbmZvOiB7fSxcclxuICAgICAgbW9kYWxOYW1lOiAnJyxcclxuICAgICAgbWVtYmVyOiBudWxsLFxyXG4gICAgICBzdGF0dXM6IHtcclxuICAgICAgICAwOiB7XHJcbiAgICAgICAgICBhOiAn56CN5Lu35LitJyxcclxuICAgICAgICAgIGI6ICcnXHJcbiAgICAgICAgfSxcclxuICAgICAgICAxOiB7XHJcbiAgICAgICAgICBhOiAn56CN5Lu35a6M5oiQJyxcclxuICAgICAgICAgIGI6ICflvoXmlK/ku5gnXHJcbiAgICAgICAgfSxcclxuICAgICAgICAyOiB7XHJcbiAgICAgICAgICBhOiAn56CN5Lu35a6M5oiQJyxcclxuICAgICAgICAgIGI6ICflt7LmlK/ku5gnXHJcbiAgICAgICAgfSxcclxuICAgICAgICAzOiB7XHJcbiAgICAgICAgICBhOiAn5bey6L+H5pyfJyxcclxuICAgICAgICAgIGI6ICfnoI3ku7fnu5PmnZ8nXHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgY29uZmlnID0ge1xyXG4gICAgICBuYXZpZ2F0aW9uQmFyQmFja2dyb3VuZENvbG9yOiAnIzIxNUUyMScsXHJcbiAgICAgIG5hdmlnYXRpb25CYXJUaXRsZVRleHQ6ICfkvJfnrbknLFxyXG4gICAgICBcInVzaW5nQ29tcG9uZW50c1wiOiB7XHJcbiAgICAgICAgXCJsLWNvdW50ZG93blwiOiBcIi4uLy4uL2NvbXBvbmVudHMvY291bnRkb3duL2luZGV4XCJcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgY29tcG9uZW50cyA9IHtcclxuICAgICAgY29udGFjdCxcclxuICAgICAgY0luZm9cclxuICAgIH1cclxuICAgIGNvbXB1dGVkID0ge1xyXG4gICAgICBjdXRQcmljZSgpIHtcclxuICAgICAgICBpZiAodGhpcy5BY3RCYXJnYWluUmVnKSB7XHJcbiAgICAgICAgICBsZXQgYWN0ID0gdGhpcy5BY3RCYXJnYWluUmVnXHJcbiAgICAgICAgICBsZXQgX3AgPSBhY3Quc3VwcG9ydGVkQW1vdW50cyAqIDEsXHJcbiAgICAgICAgICAgIF9zcCA9IGFjdC5jb3Vyc2VQcmljZSAqIDFcclxuICAgICAgICAgIHRoaXMucGVyY2VudCA9IHBhcnNlSW50KF9wIC8gX3NwICogMTAwKVxyXG4gICAgICAgICAgcmV0dXJuIF9wXHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBvblNoYXJlQXBwTWVzc2FnZShyZXMpIHtcclxuICAgICAgaWYgKHJlcy5mcm9tID09PSAnYnV0dG9uJykge1xyXG4gICAgICAgIC8vIOadpeiHqumhtemdouWGhei9rOWPkeaMiemSrlxyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKHJlcy50YXJnZXQpXHJcbiAgICAgIH1cclxuICAgICAgcmV0dXJuIHtcclxuICAgICAgICB0aXRsZTogdGhpcy5jb3Vyc2VJbmZvLmNvdXJzZVRpdHRsZSxcclxuICAgICAgICBpbWFnZVVybDogdGhpcy5jb3Vyc2VJbmZvLmltYWdlLFxyXG4gICAgICAgIHBhdGg6ICcvY3Jvd2RmdW5kL3BhZ2VzL3BhZ2U/aWQ9JyArIHRoaXMuQWN0QmFyZ2FpblJlZy5pZCArICcmYWdlbnRJZD0nICsgdGhpcy5tZW1iZXIuYWdlbnRJZFxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBhc3luYyBvbkxvYWQob3B0KSB7XHJcbiAgICAgIHRoaXMucmVnSWQgPSBvcHQuaWQgfHwgIHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEucXVlcnkuaWRcclxuICAgICAgdGhpcy5yb3V0ZXMgPSBnZXRDdXJyZW50UGFnZXMoKVxyXG4gICAgICBhd2FpdCBhdXRoLmxvZ2luKClcclxuICAgICAgdGhpcy5tZW1iZXIgPSB3ZXB5LmdldFN0b3JhZ2VTeW5jKCdtZW1iZXInKTtcclxuICAgICAgYXdhaXQgdGhpcy5sb2FkKClcclxuICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgfVxyXG4gICAgYXN5bmMgb25TaG93KCkge1xyXG4gICAgICBpZiAodGhpcy5tZW1iZXIpIHtcclxuICAgICAgICBhd2FpdCB0aGlzLmxvYWQoKVxyXG4gICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgbWV0aG9kcyA9IHtcclxuICAgICAgaGlkZU1vZGFsKCkge1xyXG4gICAgICAgIHRoaXMubW9kYWxOYW1lID0gJydcclxuICAgICAgfSxcclxuICAgICAgYXN5bmMgY3JlYXRlSW1nKGUpIHtcclxuICAgICAgICBpZiAoZS5kZXRhaWwuZXJyTXNnID09IFwiZ2V0VXNlckluZm86b2tcIikge1xyXG4gICAgICAgICAgYXdhaXQgYXV0aC5nZXRVc2VyaW5mbyhlLmRldGFpbClcclxuICAgICAgICAgIHN0b3JlLnNhdmUoJ3NoYXJlSW5mbycsIHtcclxuICAgICAgICAgICAgY291cnNlOiB0aGlzLmNvdXJzZUluZm8sXHJcbiAgICAgICAgICAgIHBhdGg6ICdjcm93ZGZ1bmQvcGFnZXMvcGFnZScsXHJcbiAgICAgICAgICAgIGlkOiB0aGlzLkFjdEJhcmdhaW5SZWcuaWQsXHJcbiAgICAgICAgICAgIHR5cGU6IDQsXHJcbiAgICAgICAgICAgIGNvdXJzZUlkOiB0aGlzLmNvdXJzZUluZm8uaWRcclxuICAgICAgICAgIH0pXHJcbiAgICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICB1cmw6ICcvcGFnZXMvaG9tZS9zaGFyZSdcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgfSxcclxuICAgICAgdG9zaGFyZSgpIHtcclxuICAgICAgICB0aGlzLm1vZGFsTmFtZSA9ICdzaGFyZSdcclxuICAgICAgfSxcclxuICAgICAgdG9zdXBwb3J0KCkge1xyXG4gICAgICAgIGlmICh3ZXB5LmdldFN0b3JhZ2VTeW5jKCdpc0ZhbnMnKSAhPSAxKSB7XHJcbiAgICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICB1cmw6IGAvcGFnZXMvaG9tZS9hdXRoP21vYmlsZT0xYFxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHdlcHkubmF2aWdhdGVUbyh7XHJcbiAgICAgICAgICAgIHVybDogYC9jcm93ZGZ1bmQvcGFnZXMvaGVscD9pZD0ke3RoaXMuaW5mby5yZWdJZH1gXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgIH0sXHJcbiAgICAgIHRvT3BlbigpIHtcclxuICAgICAgICBXeFV0aWxzLmJhY2tPclJlZGlyZWN0KGAvcGFnZXMvZGV0YWlsZS9kZXRhaWxlP2lkPSR7dGhpcy5pbmZvLmNvdXJzZUluZm8uaWR9YClcclxuICAgICAgfSxcclxuICAgICAgdGFiU2VsZWN0KGUpIHtcclxuICAgICAgICB0aGlzLlRhYkN1ciA9IGUuY3VycmVudFRhcmdldC5kYXRhc2V0LmlkIHx8IGUuZGV0YWlsLmN1cnJlbnQ7XHJcbiAgICAgIH0sXHJcbiAgICAgIGJ1eSgpIHtcclxuICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgdXJsOiBgL3BhZ2VzL2RldGFpbGUvc3VyZU9yZGVyP3R5cGU9MiZwaWQ9JHt0aGlzLmluZm8ucmVnLnBlcmlvZElkfSZjaWQ9JHt0aGlzLmluZm8ucmVnLmNvdXJzZUlkfSZudW09MSZhaWQ9JHt0aGlzLmluZm8ucmVnSWR9JmFjdHBpZD0wYFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9LFxyXG4gICAgICB0b3BheSgpIHtcclxuICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgdXJsOiBgL3BhZ2VzL215L29yZGVyP2lkPSR7dGhpcy5pbmZvLm9yZGVySWR9YFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9LFxyXG4gICAgfTtcclxuICAgIGFzeW5jIGhlbHBCYXJnYWluKCkge1xyXG4gICAgICBsZXQgcmVzID0gYXdhaXQgY29uZmlnLmhlbHBCYXJnYWluKHRoaXMucmVnSWQpXHJcbiAgICB9XHJcbiAgICBhc3luYyBsb2FkKCkge1xyXG4gICAgICBsZXQge1xyXG4gICAgICAgIGVycmNvZGUsXHJcbiAgICAgICAgZGF0YVxyXG4gICAgICB9ID0gYXdhaXQgYXBpLmdldFN1cHBvcnREZXRhaSh0aGlzLnJlZ0lkKVxyXG4gICAgICBpZiAoZXJyY29kZSA9PSAyMDApIHtcclxuICAgICAgICB0aGlzLmluZm8gPSBkYXRhXHJcbiAgICAgICAgdGhpcy5jb3Vyc2VJbmZvID0gZGF0YS5jb3Vyc2VJbmZvXHJcbiAgICAgICAgdGhpcy5BY3RCYXJnYWluUmVnID0gZGF0YS5yZWdcclxuICAgICAgICBjb25zb2xlLmxvZyh0aGlzLkFjdEJhcmdhaW5SZWcuaW52YWxpZFRpbWUpXHJcbiAgICAgICAgdGhpcy5iYXJnYWluUmVjb3JkcyA9IGRhdGEuYmFyZ2FpblJlY29yZHNcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuIl19