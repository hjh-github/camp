"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _api = require('./../api.js');

var _api2 = _interopRequireDefault(_api);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

var _Lang = require('./../../utils/Lang.js');

var _Lang2 = _interopRequireDefault(_Lang);

var _utils = require('./../../store/utils.js');

var _utils2 = _interopRequireDefault(_utils);

var _contact = require('./../../components/common/contact.js');

var _contact2 = _interopRequireDefault(_contact);

var _info = require('./../../components/detaile/info.js');

var _info2 = _interopRequireDefault(_info);

var _WxUtils = require('./../../utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
  _inherits(Dialog, _wepy$page);

  function Dialog() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, Dialog);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.data = {
      close: "/static/images/close.png",
      TabCur: 0,
      active: true,
      routes: 0,
      regId: '',
      courseInfo: {},
      ActBargainReg: {
        invalidTime: ''
      },
      bargainRecords: [],
      dj: 3000,
      percent: 0,
      info: {},
      modalName: '',
      member: null,
      status: {
        0: {
          a: '砍价中',
          b: ''
        },
        1: {
          a: '砍价完成',
          b: '待支付'
        },
        2: {
          a: '砍价完成',
          b: '已支付'
        },
        3: {
          a: '已过期',
          b: '砍价结束'
        }
      }
    }, _this.config = {
      navigationBarBackgroundColor: '#215E21',
      navigationBarTitleText: '众筹',
      "usingComponents": {
        "l-countdown": "../../components/countdown/index"
      }
    }, _this.components = {
      contact: _contact2.default,
      cInfo: _info2.default
    }, _this.computed = {
      cutPrice: function cutPrice() {
        if (this.ActBargainReg) {
          var act = this.ActBargainReg;
          var _p = act.supportedAmounts * 1,
              _sp = act.coursePrice * 1;
          this.percent = parseInt(_p / _sp * 100);
          return _p;
        }
      }
    }, _this.methods = {
      hideModal: function hideModal() {
        this.modalName = '';
      },
      createImg: function () {
        var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(e) {
          return regeneratorRuntime.wrap(function _callee$(_context) {
            while (1) {
              switch (_context.prev = _context.next) {
                case 0:
                  if (!(e.detail.errMsg == "getUserInfo:ok")) {
                    _context.next = 5;
                    break;
                  }

                  _context.next = 3;
                  return _auth2.default.getUserinfo(e.detail);

                case 3:
                  _utils2.default.save('shareInfo', {
                    course: this.courseInfo,
                    path: 'crowdfund/pages/page',
                    id: this.ActBargainReg.id,
                    type: 4,
                    courseId: this.courseInfo.id
                  });
                  _wepy2.default.navigateTo({
                    url: '/pages/home/share'
                  });

                case 5:
                case "end":
                  return _context.stop();
              }
            }
          }, _callee, this);
        }));

        function createImg(_x) {
          return _ref2.apply(this, arguments);
        }

        return createImg;
      }(),
      toshare: function toshare() {
        this.modalName = 'share';
      },
      tosupport: function tosupport() {
        _wepy2.default.navigateTo({
          url: "/crowdfund/pages/help?id=" + this.info.regId
        });
      },
      toOpen: function toOpen() {
        _WxUtils2.default.backOrRedirect("/pages/detaile/detaile?id=" + this.info.courseInfo.id);
      },
      tabSelect: function tabSelect(e) {
        this.TabCur = e.currentTarget.dataset.id || e.detail.current;
      },
      buy: function buy() {
        _wepy2.default.navigateTo({
          url: "/pages/detaile/sureOrder?type=2&pid=" + this.info.reg.periodId + "&cid=" + this.info.reg.courseId + "&num=1&aid=" + this.info.regId + "&actpid=0"
        });
      },
      topay: function topay() {
        _wepy2.default.navigateTo({
          url: "/pages/my/order?id=" + this.info.orderId
        });
      },
      onGotUserInfo: function () {
        var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(e) {
          return regeneratorRuntime.wrap(function _callee2$(_context2) {
            while (1) {
              switch (_context2.prev = _context2.next) {
                case 0:
                  if (!(_wepy2.default.getStorageSync('mobile') == '' || !_wepy2.default.getStorageSync('mobile') || _wepy2.default.getStorageSync('isFans') != 1)) {
                    _context2.next = 4;
                    break;
                  }

                  _wepy2.default.navigateTo({
                    url: "/pages/home/auth"
                  });
                  _context2.next = 9;
                  break;

                case 4:
                  _context2.next = 6;
                  return this.helpBargain();

                case 6:
                  _context2.next = 8;
                  return this.load();

                case 8:
                  this.$apply();

                case 9:
                case "end":
                  return _context2.stop();
              }
            }
          }, _callee2, this);
        }));

        function onGotUserInfo(_x2) {
          return _ref3.apply(this, arguments);
        }

        return onGotUserInfo;
      }()
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(Dialog, [{
    key: "onShareAppMessage",
    value: function onShareAppMessage(res) {
      if (res.from === 'button') {
        // 来自页面内转发按钮
        // console.log(res.target)
      }
      return {
        title: this.courseInfo.courseTittle,
        imageUrl: this.courseInfo.image,
        path: '/crowdfund/pages/page?id=' + this.ActBargainReg.id + '&agentId=' + this.member.agentId
      };
    }
  }, {
    key: "onLoad",
    value: function () {
      var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(opt) {
        return regeneratorRuntime.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                this.regId = opt.id || opt.scene;
                this.routes = getCurrentPages();
                _context3.next = 4;
                return _auth2.default.login();

              case 4:
                this.member = _wepy2.default.getStorageSync('member');
                _context3.next = 7;
                return this.load();

              case 7:
                this.$apply();

              case 8:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this);
      }));

      function onLoad(_x3) {
        return _ref4.apply(this, arguments);
      }

      return onLoad;
    }()
  }, {
    key: "onShow",
    value: function () {
      var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
        return regeneratorRuntime.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                if (!this.member) {
                  _context4.next = 4;
                  break;
                }

                _context4.next = 3;
                return this.load();

              case 3:
                this.$apply();

              case 4:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, this);
      }));

      function onShow() {
        return _ref5.apply(this, arguments);
      }

      return onShow;
    }()
  }, {
    key: "helpBargain",
    value: function () {
      var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
        var res;
        return regeneratorRuntime.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                _context5.next = 2;
                return _config2.default.helpBargain(this.regId);

              case 2:
                res = _context5.sent;

              case 3:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5, this);
      }));

      function helpBargain() {
        return _ref6.apply(this, arguments);
      }

      return helpBargain;
    }()
  }, {
    key: "load",
    value: function () {
      var _ref7 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
        var _ref8, errcode, data;

        return regeneratorRuntime.wrap(function _callee6$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                _context6.next = 2;
                return _api2.default.getSupportDetai(this.regId);

              case 2:
                _ref8 = _context6.sent;
                errcode = _ref8.errcode;
                data = _ref8.data;

                if (errcode == 200) {
                  this.info = data;
                  this.courseInfo = data.courseInfo;
                  this.ActBargainReg = data.reg;
                  console.log(this.ActBargainReg.invalidTime);
                  this.bargainRecords = data.bargainRecords;
                }

              case 6:
              case "end":
                return _context6.stop();
            }
          }
        }, _callee6, this);
      }));

      function load() {
        return _ref7.apply(this, arguments);
      }

      return load;
    }()
  }]);

  return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'crowdfund/pages/page'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBhZ2UuanMiXSwibmFtZXMiOlsiRGlhbG9nIiwiZGF0YSIsImNsb3NlIiwiVGFiQ3VyIiwiYWN0aXZlIiwicm91dGVzIiwicmVnSWQiLCJjb3Vyc2VJbmZvIiwiQWN0QmFyZ2FpblJlZyIsImludmFsaWRUaW1lIiwiYmFyZ2FpblJlY29yZHMiLCJkaiIsInBlcmNlbnQiLCJpbmZvIiwibW9kYWxOYW1lIiwibWVtYmVyIiwic3RhdHVzIiwiYSIsImIiLCJjb25maWciLCJuYXZpZ2F0aW9uQmFyQmFja2dyb3VuZENvbG9yIiwibmF2aWdhdGlvbkJhclRpdGxlVGV4dCIsImNvbXBvbmVudHMiLCJjb250YWN0IiwiY0luZm8iLCJjb21wdXRlZCIsImN1dFByaWNlIiwiYWN0IiwiX3AiLCJzdXBwb3J0ZWRBbW91bnRzIiwiX3NwIiwiY291cnNlUHJpY2UiLCJwYXJzZUludCIsIm1ldGhvZHMiLCJoaWRlTW9kYWwiLCJjcmVhdGVJbWciLCJlIiwiZGV0YWlsIiwiZXJyTXNnIiwiYXV0aCIsImdldFVzZXJpbmZvIiwic3RvcmUiLCJzYXZlIiwiY291cnNlIiwicGF0aCIsImlkIiwidHlwZSIsImNvdXJzZUlkIiwid2VweSIsIm5hdmlnYXRlVG8iLCJ1cmwiLCJ0b3NoYXJlIiwidG9zdXBwb3J0IiwidG9PcGVuIiwiV3hVdGlscyIsImJhY2tPclJlZGlyZWN0IiwidGFiU2VsZWN0IiwiY3VycmVudFRhcmdldCIsImRhdGFzZXQiLCJjdXJyZW50IiwiYnV5IiwicmVnIiwicGVyaW9kSWQiLCJ0b3BheSIsIm9yZGVySWQiLCJvbkdvdFVzZXJJbmZvIiwiZ2V0U3RvcmFnZVN5bmMiLCJoZWxwQmFyZ2FpbiIsImxvYWQiLCIkYXBwbHkiLCJyZXMiLCJmcm9tIiwidGl0bGUiLCJjb3Vyc2VUaXR0bGUiLCJpbWFnZVVybCIsImltYWdlIiwiYWdlbnRJZCIsIm9wdCIsInNjZW5lIiwiZ2V0Q3VycmVudFBhZ2VzIiwibG9naW4iLCJhcGkiLCJnZXRTdXBwb3J0RGV0YWkiLCJlcnJjb2RlIiwiY29uc29sZSIsImxvZyIsInBhZ2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUNFOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7Ozs7Ozs7Ozs7Ozs7SUFFcUJBLE07Ozs7Ozs7Ozs7Ozs7O3NMQUNuQkMsSSxHQUFPO0FBQ0xDLGFBQU8sMEJBREY7QUFFTEMsY0FBUSxDQUZIO0FBR0xDLGNBQVEsSUFISDtBQUlMQyxjQUFRLENBSkg7QUFLTEMsYUFBTyxFQUxGO0FBTUxDLGtCQUFZLEVBTlA7QUFPTEMscUJBQWU7QUFDYkMscUJBQWE7QUFEQSxPQVBWO0FBVUxDLHNCQUFnQixFQVZYO0FBV0xDLFVBQUksSUFYQztBQVlMQyxlQUFTLENBWko7QUFhTEMsWUFBTSxFQWJEO0FBY0xDLGlCQUFXLEVBZE47QUFlTEMsY0FBTyxJQWZGO0FBZ0JMQyxjQUFRO0FBQ04sV0FBRztBQUNEQyxhQUFHLEtBREY7QUFFREMsYUFBRztBQUZGLFNBREc7QUFLTixXQUFHO0FBQ0RELGFBQUcsTUFERjtBQUVEQyxhQUFHO0FBRkYsU0FMRztBQVNOLFdBQUc7QUFDREQsYUFBRyxNQURGO0FBRURDLGFBQUc7QUFGRixTQVRHO0FBYU4sV0FBRztBQUNERCxhQUFHLEtBREY7QUFFREMsYUFBRztBQUZGO0FBYkc7QUFoQkgsSyxRQW1DUEMsTSxHQUFTO0FBQ1BDLG9DQUE4QixTQUR2QjtBQUVQQyw4QkFBd0IsSUFGakI7QUFHUCx5QkFBbUI7QUFDakIsdUJBQWU7QUFERTtBQUhaLEssUUFPVEMsVSxHQUFhO0FBQ1hDLGdDQURXO0FBRVhDO0FBRlcsSyxRQUliQyxRLEdBQVc7QUFDVEMsY0FEUyxzQkFDRTtBQUNULFlBQUksS0FBS2xCLGFBQVQsRUFBd0I7QUFDdEIsY0FBSW1CLE1BQU0sS0FBS25CLGFBQWY7QUFDQSxjQUFJb0IsS0FBS0QsSUFBSUUsZ0JBQUosR0FBdUIsQ0FBaEM7QUFBQSxjQUNFQyxNQUFNSCxJQUFJSSxXQUFKLEdBQWtCLENBRDFCO0FBRUEsZUFBS25CLE9BQUwsR0FBZW9CLFNBQVNKLEtBQUtFLEdBQUwsR0FBVyxHQUFwQixDQUFmO0FBQ0EsaUJBQU9GLEVBQVA7QUFDRDtBQUNGO0FBVFEsSyxRQW9DWEssTyxHQUFVO0FBQ1JDLGVBRFEsdUJBQ0k7QUFDVixhQUFLcEIsU0FBTCxHQUFpQixFQUFqQjtBQUNELE9BSE87QUFJRnFCLGVBSkU7QUFBQSw2RkFJUUMsQ0FKUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBS0ZBLEVBQUVDLE1BQUYsQ0FBU0MsTUFBVCxJQUFtQixnQkFMakI7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQSx5QkFNRUMsZUFBS0MsV0FBTCxDQUFpQkosRUFBRUMsTUFBbkIsQ0FORjs7QUFBQTtBQU9KSSxrQ0FBTUMsSUFBTixDQUFXLFdBQVgsRUFBd0I7QUFDdEJDLDRCQUFRLEtBQUtwQyxVQURTO0FBRXRCcUMsMEJBQU0sc0JBRmdCO0FBR3RCQyx3QkFBSSxLQUFLckMsYUFBTCxDQUFtQnFDLEVBSEQ7QUFJdEJDLDBCQUFNLENBSmdCO0FBS3RCQyw4QkFBVSxLQUFLeEMsVUFBTCxDQUFnQnNDO0FBTEosbUJBQXhCO0FBT0FHLGlDQUFLQyxVQUFMLENBQWdCO0FBQ2RDLHlCQUFLO0FBRFMsbUJBQWhCOztBQWRJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBbUJSQyxhQW5CUSxxQkFtQkU7QUFDUixhQUFLckMsU0FBTCxHQUFpQixPQUFqQjtBQUNELE9BckJPO0FBc0JSc0MsZUF0QlEsdUJBc0JJO0FBQ1ZKLHVCQUFLQyxVQUFMLENBQWdCO0FBQ2RDLDZDQUFpQyxLQUFLckMsSUFBTCxDQUFVUDtBQUQ3QixTQUFoQjtBQUdELE9BMUJPO0FBMkJSK0MsWUEzQlEsb0JBMkJBO0FBQ05DLDBCQUFRQyxjQUFSLGdDQUFvRCxLQUFLMUMsSUFBTCxDQUFVTixVQUFWLENBQXFCc0MsRUFBekU7QUFDRCxPQTdCTztBQThCUlcsZUE5QlEscUJBOEJFcEIsQ0E5QkYsRUE4Qks7QUFDWCxhQUFLakMsTUFBTCxHQUFjaUMsRUFBRXFCLGFBQUYsQ0FBZ0JDLE9BQWhCLENBQXdCYixFQUF4QixJQUE4QlQsRUFBRUMsTUFBRixDQUFTc0IsT0FBckQ7QUFDRCxPQWhDTztBQWlDUkMsU0FqQ1EsaUJBaUNGO0FBQ0paLHVCQUFLQyxVQUFMLENBQWdCO0FBQ2RDLHdEQUE0QyxLQUFLckMsSUFBTCxDQUFVZ0QsR0FBVixDQUFjQyxRQUExRCxhQUEwRSxLQUFLakQsSUFBTCxDQUFVZ0QsR0FBVixDQUFjZCxRQUF4RixtQkFBOEcsS0FBS2xDLElBQUwsQ0FBVVAsS0FBeEg7QUFEYyxTQUFoQjtBQUdELE9BckNPO0FBc0NSeUQsV0F0Q1EsbUJBc0NBO0FBQ05mLHVCQUFLQyxVQUFMLENBQWdCO0FBQ2RDLHVDQUEyQixLQUFLckMsSUFBTCxDQUFVbUQ7QUFEdkIsU0FBaEI7QUFHRCxPQTFDTztBQTJDRkMsbUJBM0NFO0FBQUEsOEZBMkNZN0IsQ0EzQ1o7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQTRDRlksZUFBS2tCLGNBQUwsQ0FBb0IsUUFBcEIsS0FBaUMsRUFBakMsSUFBdUMsQ0FBQ2xCLGVBQUtrQixjQUFMLENBQW9CLFFBQXBCLENBQXhDLElBQXlFbEIsZUFBS2tCLGNBQUwsQ0FDekUsUUFEeUUsS0FDNUQsQ0E3Q1g7QUFBQTtBQUFBO0FBQUE7O0FBOENKbEIsaUNBQUtDLFVBQUwsQ0FBZ0I7QUFDZEM7QUFEYyxtQkFBaEI7QUE5Q0k7QUFBQTs7QUFBQTtBQUFBO0FBQUEseUJBa0RFLEtBQUtpQixXQUFMLEVBbERGOztBQUFBO0FBQUE7QUFBQSx5QkFtREUsS0FBS0MsSUFBTCxFQW5ERjs7QUFBQTtBQW9ESix1QkFBS0MsTUFBTDs7QUFwREk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQSxLOzs7OztzQ0F6QlFDLEcsRUFBSztBQUNyQixVQUFJQSxJQUFJQyxJQUFKLEtBQWEsUUFBakIsRUFBMkI7QUFDekI7QUFDQTtBQUNEO0FBQ0QsYUFBTztBQUNMQyxlQUFPLEtBQUtqRSxVQUFMLENBQWdCa0UsWUFEbEI7QUFFTEMsa0JBQVUsS0FBS25FLFVBQUwsQ0FBZ0JvRSxLQUZyQjtBQUdML0IsY0FBTSw4QkFBOEIsS0FBS3BDLGFBQUwsQ0FBbUJxQyxFQUFqRCxHQUFzRCxXQUF0RCxHQUFvRSxLQUFLOUIsTUFBTCxDQUFZNkQ7QUFIakYsT0FBUDtBQUtEOzs7OzRGQUNZQyxHOzs7OztBQUNYLHFCQUFLdkUsS0FBTCxHQUFhdUUsSUFBSWhDLEVBQUosSUFBVWdDLElBQUlDLEtBQTNCO0FBQ0EscUJBQUt6RSxNQUFMLEdBQWMwRSxpQkFBZDs7dUJBQ014QyxlQUFLeUMsS0FBTCxFOzs7QUFDTixxQkFBS2pFLE1BQUwsR0FBY2lDLGVBQUtrQixjQUFMLENBQW9CLFFBQXBCLENBQWQ7O3VCQUNNLEtBQUtFLElBQUwsRTs7O0FBQ04scUJBQUtDLE1BQUw7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztxQkFHSSxLQUFLdEQsTTs7Ozs7O3VCQUNELEtBQUtxRCxJQUFMLEU7OztBQUNOLHFCQUFLQyxNQUFMOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozt1QkE0RGNsRCxpQkFBT2dELFdBQVAsQ0FBbUIsS0FBSzdELEtBQXhCLEM7OztBQUFaZ0UsbUI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozt1QkFNTVcsY0FBSUMsZUFBSixDQUFvQixLQUFLNUUsS0FBekIsQzs7OztBQUZSNkUsdUIsU0FBQUEsTztBQUNBbEYsb0IsU0FBQUEsSTs7QUFFRixvQkFBSWtGLFdBQVcsR0FBZixFQUFvQjtBQUNsQix1QkFBS3RFLElBQUwsR0FBWVosSUFBWjtBQUNBLHVCQUFLTSxVQUFMLEdBQWtCTixLQUFLTSxVQUF2QjtBQUNBLHVCQUFLQyxhQUFMLEdBQXFCUCxLQUFLNEQsR0FBMUI7QUFDQXVCLDBCQUFRQyxHQUFSLENBQVksS0FBSzdFLGFBQUwsQ0FBbUJDLFdBQS9CO0FBQ0EsdUJBQUtDLGNBQUwsR0FBc0JULEtBQUtTLGNBQTNCO0FBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUF6SitCc0MsZUFBS3NDLEk7O2tCQUFwQnRGLE0iLCJmaWxlIjoicGFnZS5qcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4gIGltcG9ydCB3ZXB5IGZyb20gXCJ3ZXB5XCJcclxuICBpbXBvcnQgY29uZmlnIGZyb20gXCJAL2FwaS9jb25maWdcIlxyXG4gIGltcG9ydCBhcGkgZnJvbSBcIi4uL2FwaVwiXHJcbiAgaW1wb3J0IGF1dGggZnJvbSBcIkAvYXBpL2F1dGhcIlxyXG4gIGltcG9ydCBMYW5nIGZyb20gXCJAL3V0aWxzL0xhbmdcIlxyXG4gIGltcG9ydCBzdG9yZSBmcm9tIFwiQC9zdG9yZS91dGlsc1wiXHJcbiAgaW1wb3J0IGNvbnRhY3QgZnJvbSBcIkAvY29tcG9uZW50cy9jb21tb24vY29udGFjdFwiXHJcbiAgaW1wb3J0IGNJbmZvIGZyb20gXCJAL2NvbXBvbmVudHMvZGV0YWlsZS9pbmZvXCI7XHJcbiAgaW1wb3J0IFd4VXRpbHMgZnJvbSBcIkAvdXRpbHMvV3hVdGlsc1wiXHJcblxyXG4gIGV4cG9ydCBkZWZhdWx0IGNsYXNzIERpYWxvZyBleHRlbmRzIHdlcHkucGFnZSB7XHJcbiAgICBkYXRhID0ge1xyXG4gICAgICBjbG9zZTogXCIvc3RhdGljL2ltYWdlcy9jbG9zZS5wbmdcIixcclxuICAgICAgVGFiQ3VyOiAwLFxyXG4gICAgICBhY3RpdmU6IHRydWUsXHJcbiAgICAgIHJvdXRlczogMCxcclxuICAgICAgcmVnSWQ6ICcnLFxyXG4gICAgICBjb3Vyc2VJbmZvOiB7fSxcclxuICAgICAgQWN0QmFyZ2FpblJlZzoge1xyXG4gICAgICAgIGludmFsaWRUaW1lOiAnJ1xyXG4gICAgICB9LFxyXG4gICAgICBiYXJnYWluUmVjb3JkczogW10sXHJcbiAgICAgIGRqOiAzMDAwLFxyXG4gICAgICBwZXJjZW50OiAwLFxyXG4gICAgICBpbmZvOiB7fSxcclxuICAgICAgbW9kYWxOYW1lOiAnJyxcclxuICAgICAgbWVtYmVyOm51bGwsXHJcbiAgICAgIHN0YXR1czoge1xyXG4gICAgICAgIDA6IHtcclxuICAgICAgICAgIGE6ICfnoI3ku7fkuK0nLFxyXG4gICAgICAgICAgYjogJydcclxuICAgICAgICB9LFxyXG4gICAgICAgIDE6IHtcclxuICAgICAgICAgIGE6ICfnoI3ku7flrozmiJAnLFxyXG4gICAgICAgICAgYjogJ+W+heaUr+S7mCdcclxuICAgICAgICB9LFxyXG4gICAgICAgIDI6IHtcclxuICAgICAgICAgIGE6ICfnoI3ku7flrozmiJAnLFxyXG4gICAgICAgICAgYjogJ+W3suaUr+S7mCdcclxuICAgICAgICB9LFxyXG4gICAgICAgIDM6IHtcclxuICAgICAgICAgIGE6ICflt7Lov4fmnJ8nLFxyXG4gICAgICAgICAgYjogJ+egjeS7t+e7k+adnydcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBjb25maWcgPSB7XHJcbiAgICAgIG5hdmlnYXRpb25CYXJCYWNrZ3JvdW5kQ29sb3I6ICcjMjE1RTIxJyxcclxuICAgICAgbmF2aWdhdGlvbkJhclRpdGxlVGV4dDogJ+S8l+etuScsXHJcbiAgICAgIFwidXNpbmdDb21wb25lbnRzXCI6IHtcclxuICAgICAgICBcImwtY291bnRkb3duXCI6IFwiLi4vLi4vY29tcG9uZW50cy9jb3VudGRvd24vaW5kZXhcIlxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBjb21wb25lbnRzID0ge1xyXG4gICAgICBjb250YWN0LFxyXG4gICAgICBjSW5mb1xyXG4gICAgfVxyXG4gICAgY29tcHV0ZWQgPSB7XHJcbiAgICAgIGN1dFByaWNlKCkge1xyXG4gICAgICAgIGlmICh0aGlzLkFjdEJhcmdhaW5SZWcpIHtcclxuICAgICAgICAgIGxldCBhY3QgPSB0aGlzLkFjdEJhcmdhaW5SZWdcclxuICAgICAgICAgIGxldCBfcCA9IGFjdC5zdXBwb3J0ZWRBbW91bnRzICogMSxcclxuICAgICAgICAgICAgX3NwID0gYWN0LmNvdXJzZVByaWNlICogMVxyXG4gICAgICAgICAgdGhpcy5wZXJjZW50ID0gcGFyc2VJbnQoX3AgLyBfc3AgKiAxMDApXHJcbiAgICAgICAgICByZXR1cm4gX3BcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIG9uU2hhcmVBcHBNZXNzYWdlKHJlcykge1xyXG4gICAgICBpZiAocmVzLmZyb20gPT09ICdidXR0b24nKSB7XHJcbiAgICAgICAgLy8g5p2l6Ieq6aG16Z2i5YaF6L2s5Y+R5oyJ6ZKuXHJcbiAgICAgICAgLy8gY29uc29sZS5sb2cocmVzLnRhcmdldClcclxuICAgICAgfVxyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIHRpdGxlOiB0aGlzLmNvdXJzZUluZm8uY291cnNlVGl0dGxlLFxyXG4gICAgICAgIGltYWdlVXJsOiB0aGlzLmNvdXJzZUluZm8uaW1hZ2UsXHJcbiAgICAgICAgcGF0aDogJy9jcm93ZGZ1bmQvcGFnZXMvcGFnZT9pZD0nICsgdGhpcy5BY3RCYXJnYWluUmVnLmlkICsgJyZhZ2VudElkPScgKyB0aGlzLm1lbWJlci5hZ2VudElkXHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIGFzeW5jIG9uTG9hZChvcHQpIHtcclxuICAgICAgdGhpcy5yZWdJZCA9IG9wdC5pZCB8fCBvcHQuc2NlbmVcclxuICAgICAgdGhpcy5yb3V0ZXMgPSBnZXRDdXJyZW50UGFnZXMoKVxyXG4gICAgICBhd2FpdCBhdXRoLmxvZ2luKClcclxuICAgICAgdGhpcy5tZW1iZXIgPSB3ZXB5LmdldFN0b3JhZ2VTeW5jKCdtZW1iZXInKTtcclxuICAgICAgYXdhaXQgdGhpcy5sb2FkKClcclxuICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgfVxyXG4gICAgYXN5bmMgb25TaG93KCkge1xyXG4gICAgICBpZiAodGhpcy5tZW1iZXIpIHtcclxuICAgICAgICBhd2FpdCB0aGlzLmxvYWQoKVxyXG4gICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgbWV0aG9kcyA9IHtcclxuICAgICAgaGlkZU1vZGFsKCkge1xyXG4gICAgICAgIHRoaXMubW9kYWxOYW1lID0gJydcclxuICAgICAgfSxcclxuICAgICAgYXN5bmMgY3JlYXRlSW1nKGUpIHtcclxuICAgICAgICBpZiAoZS5kZXRhaWwuZXJyTXNnID09IFwiZ2V0VXNlckluZm86b2tcIikge1xyXG4gICAgICAgICAgYXdhaXQgYXV0aC5nZXRVc2VyaW5mbyhlLmRldGFpbClcclxuICAgICAgICAgIHN0b3JlLnNhdmUoJ3NoYXJlSW5mbycsIHtcclxuICAgICAgICAgICAgY291cnNlOiB0aGlzLmNvdXJzZUluZm8sXHJcbiAgICAgICAgICAgIHBhdGg6ICdjcm93ZGZ1bmQvcGFnZXMvcGFnZScsXHJcbiAgICAgICAgICAgIGlkOiB0aGlzLkFjdEJhcmdhaW5SZWcuaWQsXHJcbiAgICAgICAgICAgIHR5cGU6IDQsXHJcbiAgICAgICAgICAgIGNvdXJzZUlkOiB0aGlzLmNvdXJzZUluZm8uaWRcclxuICAgICAgICAgIH0pXHJcbiAgICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICB1cmw6ICcvcGFnZXMvaG9tZS9zaGFyZSdcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgfSxcclxuICAgICAgdG9zaGFyZSgpIHtcclxuICAgICAgICB0aGlzLm1vZGFsTmFtZSA9ICdzaGFyZSdcclxuICAgICAgfSxcclxuICAgICAgdG9zdXBwb3J0KCkge1xyXG4gICAgICAgIHdlcHkubmF2aWdhdGVUbyh7XHJcbiAgICAgICAgICB1cmw6IGAvY3Jvd2RmdW5kL3BhZ2VzL2hlbHA/aWQ9JHt0aGlzLmluZm8ucmVnSWR9YFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9LFxyXG4gICAgICB0b09wZW4oKXtcclxuICAgICAgICBXeFV0aWxzLmJhY2tPclJlZGlyZWN0KGAvcGFnZXMvZGV0YWlsZS9kZXRhaWxlP2lkPSR7dGhpcy5pbmZvLmNvdXJzZUluZm8uaWR9YClcclxuICAgICAgfSxcclxuICAgICAgdGFiU2VsZWN0KGUpIHtcclxuICAgICAgICB0aGlzLlRhYkN1ciA9IGUuY3VycmVudFRhcmdldC5kYXRhc2V0LmlkIHx8IGUuZGV0YWlsLmN1cnJlbnQ7XHJcbiAgICAgIH0sXHJcbiAgICAgIGJ1eSgpIHtcclxuICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgdXJsOiBgL3BhZ2VzL2RldGFpbGUvc3VyZU9yZGVyP3R5cGU9MiZwaWQ9JHt0aGlzLmluZm8ucmVnLnBlcmlvZElkfSZjaWQ9JHt0aGlzLmluZm8ucmVnLmNvdXJzZUlkfSZudW09MSZhaWQ9JHt0aGlzLmluZm8ucmVnSWR9JmFjdHBpZD0wYFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9LFxyXG4gICAgICB0b3BheSgpIHtcclxuICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgdXJsOiBgL3BhZ2VzL215L29yZGVyP2lkPSR7dGhpcy5pbmZvLm9yZGVySWR9YFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9LFxyXG4gICAgICBhc3luYyBvbkdvdFVzZXJJbmZvKGUpIHtcclxuICAgICAgICBpZiAod2VweS5nZXRTdG9yYWdlU3luYygnbW9iaWxlJykgPT0gJycgfHwgIXdlcHkuZ2V0U3RvcmFnZVN5bmMoJ21vYmlsZScpIHx8IHdlcHkuZ2V0U3RvcmFnZVN5bmMoXHJcbiAgICAgICAgICAgICdpc0ZhbnMnKSAhPSAxKSB7XHJcbiAgICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICB1cmw6IGAvcGFnZXMvaG9tZS9hdXRoYFxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIGF3YWl0IHRoaXMuaGVscEJhcmdhaW4oKVxyXG4gICAgICAgICAgYXdhaXQgdGhpcy5sb2FkKClcclxuICAgICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgICB9XHJcbiAgICAgIH0sXHJcbiAgICB9O1xyXG4gICAgYXN5bmMgaGVscEJhcmdhaW4oKSB7XHJcbiAgICAgIGxldCByZXMgPSBhd2FpdCBjb25maWcuaGVscEJhcmdhaW4odGhpcy5yZWdJZClcclxuICAgIH1cclxuICAgIGFzeW5jIGxvYWQoKSB7XHJcbiAgICAgIGxldCB7XHJcbiAgICAgICAgZXJyY29kZSxcclxuICAgICAgICBkYXRhXHJcbiAgICAgIH0gPSBhd2FpdCBhcGkuZ2V0U3VwcG9ydERldGFpKHRoaXMucmVnSWQpXHJcbiAgICAgIGlmIChlcnJjb2RlID09IDIwMCkge1xyXG4gICAgICAgIHRoaXMuaW5mbyA9IGRhdGFcclxuICAgICAgICB0aGlzLmNvdXJzZUluZm8gPSBkYXRhLmNvdXJzZUluZm9cclxuICAgICAgICB0aGlzLkFjdEJhcmdhaW5SZWcgPSBkYXRhLnJlZ1xyXG4gICAgICAgIGNvbnNvbGUubG9nKHRoaXMuQWN0QmFyZ2FpblJlZy5pbnZhbGlkVGltZSlcclxuICAgICAgICB0aGlzLmJhcmdhaW5SZWNvcmRzID0gZGF0YS5iYXJnYWluUmVjb3Jkc1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG4iXX0=