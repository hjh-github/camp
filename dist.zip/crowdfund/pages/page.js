"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _api = require('./../api.js');

var _api2 = _interopRequireDefault(_api);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

var _Lang = require('./../../utils/Lang.js');

var _Lang2 = _interopRequireDefault(_Lang);

var _utils = require('./../../store/utils.js');

var _utils2 = _interopRequireDefault(_utils);

var _contact = require('./../../components/common/contact.js');

var _contact2 = _interopRequireDefault(_contact);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
    _inherits(Dialog, _wepy$page);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.data = {
            close: "/static/images/close.png",
            active: true,
            routes: 0,
            regId: '',
            courseInfo: {},
            ActBargainReg: {
                invalidTime: ''
            },
            bargainRecords: [],
            dj: 3000,
            percent: 0,
            info: {},
            modalName: '',
            status: {
                0: {
                    a: '砍价中',
                    b: ''
                },
                1: {
                    a: '砍价完成',
                    b: '待支付'
                },
                2: {
                    a: '砍价完成',
                    b: '已支付'
                },
                3: {
                    a: '已过期',
                    b: '砍价结束'
                }
            }
        }, _this.config = {
            navigationBarBackgroundColor: '#ed1c24',
            navigationBarTitleText: '砍价',
            "usingComponents": {
                "l-countdown": "../../components/countdown/index"
            }
        }, _this.components = {
            contact: _contact2.default
        }, _this.computed = {
            cutPrice: function cutPrice() {
                if (this.ActBargainReg) {
                    var act = this.ActBargainReg;
                    var _p = act.supportedAmounts * 1,
                        _sp = act.coursePrice * 1;
                    this.percent = parseInt(_p / _sp * 100);
                    return _p;
                }
            }
        }, _this.methods = {
            hideModal: function hideModal() {
                this.modalName = '';
            },
            createImg: function () {
                var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(e) {
                    return regeneratorRuntime.wrap(function _callee$(_context) {
                        while (1) {
                            switch (_context.prev = _context.next) {
                                case 0:
                                    if (!(e.detail.errMsg == "getUserInfo:ok")) {
                                        _context.next = 5;
                                        break;
                                    }

                                    _context.next = 3;
                                    return _auth2.default.getUserinfo(e.detail);

                                case 3:
                                    _utils2.default.save('shareInfo', {
                                        course: this.courseInfo,
                                        path: 'pages/activity/bargain',
                                        id: this.ActBargainReg.id,
                                        type: 3,
                                        courseId: this.courseInfo.id
                                    });
                                    _wepy2.default.navigateTo({
                                        url: '/pages/home/share'
                                    });

                                case 5:
                                case "end":
                                    return _context.stop();
                            }
                        }
                    }, _callee, this);
                }));

                function createImg(_x) {
                    return _ref2.apply(this, arguments);
                }

                return createImg;
            }(),
            toshare: function toshare() {
                this.modalName = 'share';
            },
            tocut: function () {
                var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(e) {
                    return regeneratorRuntime.wrap(function _callee2$(_context2) {
                        while (1) {
                            switch (_context2.prev = _context2.next) {
                                case 0:
                                    if (!(e.detail.errMsg == "getUserInfo:ok")) {
                                        _context2.next = 4;
                                        break;
                                    }

                                    _context2.next = 3;
                                    return _auth2.default.getUserinfo(e.detail);

                                case 3:
                                    _wepy2.default.navigateTo({
                                        url: "/pages/detaile/detaile?id=" + this.courseInfo.id
                                    });

                                case 4:
                                case "end":
                                    return _context2.stop();
                            }
                        }
                    }, _callee2, this);
                }));

                function tocut(_x2) {
                    return _ref3.apply(this, arguments);
                }

                return tocut;
            }(),
            buy: function buy() {
                _wepy2.default.navigateTo({
                    url: "/pages/detaile/sureOrder?type=2&pid=" + this.info.reg.periodId + "&cid=" + this.info.reg.courseId + "&num=1&aid=" + this.info.regId + "&actpid=0"
                });
            },
            topay: function topay() {
                _wepy2.default.navigateTo({
                    url: "/pages/my/order?id=" + this.info.orderId
                });
            },
            onGotUserInfo: function () {
                var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(e) {
                    return regeneratorRuntime.wrap(function _callee3$(_context3) {
                        while (1) {
                            switch (_context3.prev = _context3.next) {
                                case 0:
                                    if (!(_wepy2.default.getStorageSync('mobile') == '' || !_wepy2.default.getStorageSync('mobile') || _wepy2.default.getStorageSync('isFans') != 1)) {
                                        _context3.next = 4;
                                        break;
                                    }

                                    _wepy2.default.navigateTo({
                                        url: "/pages/home/auth"
                                    });
                                    _context3.next = 9;
                                    break;

                                case 4:
                                    _context3.next = 6;
                                    return this.helpBargain();

                                case 6:
                                    _context3.next = 8;
                                    return this.load();

                                case 8:
                                    this.$apply();

                                case 9:
                                case "end":
                                    return _context3.stop();
                            }
                        }
                    }, _callee3, this);
                }));

                function onGotUserInfo(_x3) {
                    return _ref4.apply(this, arguments);
                }

                return onGotUserInfo;
            }()
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(Dialog, [{
        key: "onShareAppMessage",
        value: function onShareAppMessage(res) {
            if (res.from === 'button') {
                // 来自页面内转发按钮
                // console.log(res.target)
            }

            return {
                title: this.courseInfo.courseTittle,
                imageUrl: this.courseInfo.image,
                path: '/pages/activity/bargain?id=' + this.ActBargainReg.id + '&agentId=' + this.member.agentId
            };
        }
    }, {
        key: "onLoad",
        value: function () {
            var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4(opt) {
                return regeneratorRuntime.wrap(function _callee4$(_context4) {
                    while (1) {
                        switch (_context4.prev = _context4.next) {
                            case 0:
                                this.regId = opt.id || opt.scene;
                                this.routes = getCurrentPages();
                                _context4.next = 4;
                                return _auth2.default.login();

                            case 4:
                                this.member = _wepy2.default.getStorageSync('member');
                                _context4.next = 7;
                                return this.load();

                            case 7:
                                this.$apply();

                            case 8:
                            case "end":
                                return _context4.stop();
                        }
                    }
                }, _callee4, this);
            }));

            function onLoad(_x4) {
                return _ref5.apply(this, arguments);
            }

            return onLoad;
        }()
    }, {
        key: "helpBargain",
        value: function () {
            var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
                var res;
                return regeneratorRuntime.wrap(function _callee5$(_context5) {
                    while (1) {
                        switch (_context5.prev = _context5.next) {
                            case 0:
                                _context5.next = 2;
                                return _config2.default.helpBargain(this.regId);

                            case 2:
                                res = _context5.sent;

                            case 3:
                            case "end":
                                return _context5.stop();
                        }
                    }
                }, _callee5, this);
            }));

            function helpBargain() {
                return _ref6.apply(this, arguments);
            }

            return helpBargain;
        }()
    }, {
        key: "load",
        value: function () {
            var _ref7 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
                var _ref8, errcode, data;

                return regeneratorRuntime.wrap(function _callee6$(_context6) {
                    while (1) {
                        switch (_context6.prev = _context6.next) {
                            case 0:
                                _context6.next = 2;
                                return _api2.default.getSupportDetai(this.regId);

                            case 2:
                                _ref8 = _context6.sent;
                                errcode = _ref8.errcode;
                                data = _ref8.data;

                                if (errcode == 200) {
                                    this.info = data;
                                    this.courseInfo = data.courseInfo;
                                    this.ActBargainReg = data.reg;
                                    console.log(this.ActBargainReg.invalidTime);
                                    this.bargainRecords = data.bargainRecords;
                                }

                            case 6:
                            case "end":
                                return _context6.stop();
                        }
                    }
                }, _callee6, this);
            }));

            function load() {
                return _ref7.apply(this, arguments);
            }

            return load;
        }()
    }]);

    return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'crowdfund/pages/page'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBhZ2UuanMiXSwibmFtZXMiOlsiRGlhbG9nIiwiZGF0YSIsImNsb3NlIiwiYWN0aXZlIiwicm91dGVzIiwicmVnSWQiLCJjb3Vyc2VJbmZvIiwiQWN0QmFyZ2FpblJlZyIsImludmFsaWRUaW1lIiwiYmFyZ2FpblJlY29yZHMiLCJkaiIsInBlcmNlbnQiLCJpbmZvIiwibW9kYWxOYW1lIiwic3RhdHVzIiwiYSIsImIiLCJjb25maWciLCJuYXZpZ2F0aW9uQmFyQmFja2dyb3VuZENvbG9yIiwibmF2aWdhdGlvbkJhclRpdGxlVGV4dCIsImNvbXBvbmVudHMiLCJjb250YWN0IiwiY29tcHV0ZWQiLCJjdXRQcmljZSIsImFjdCIsIl9wIiwic3VwcG9ydGVkQW1vdW50cyIsIl9zcCIsImNvdXJzZVByaWNlIiwicGFyc2VJbnQiLCJtZXRob2RzIiwiaGlkZU1vZGFsIiwiY3JlYXRlSW1nIiwiZSIsImRldGFpbCIsImVyck1zZyIsImF1dGgiLCJnZXRVc2VyaW5mbyIsInN0b3JlIiwic2F2ZSIsImNvdXJzZSIsInBhdGgiLCJpZCIsInR5cGUiLCJjb3Vyc2VJZCIsIndlcHkiLCJuYXZpZ2F0ZVRvIiwidXJsIiwidG9zaGFyZSIsInRvY3V0IiwiYnV5IiwicmVnIiwicGVyaW9kSWQiLCJ0b3BheSIsIm9yZGVySWQiLCJvbkdvdFVzZXJJbmZvIiwiZ2V0U3RvcmFnZVN5bmMiLCJoZWxwQmFyZ2FpbiIsImxvYWQiLCIkYXBwbHkiLCJyZXMiLCJmcm9tIiwidGl0bGUiLCJjb3Vyc2VUaXR0bGUiLCJpbWFnZVVybCIsImltYWdlIiwibWVtYmVyIiwiYWdlbnRJZCIsIm9wdCIsInNjZW5lIiwiZ2V0Q3VycmVudFBhZ2VzIiwibG9naW4iLCJhcGkiLCJnZXRTdXBwb3J0RGV0YWkiLCJlcnJjb2RlIiwiY29uc29sZSIsImxvZyIsInBhZ2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUNJOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7Ozs7Ozs7Ozs7OztJQUNxQkEsTTs7Ozs7Ozs7Ozs7Ozs7MExBQ2pCQyxJLEdBQU87QUFDSEMsbUJBQU8sMEJBREo7QUFFSEMsb0JBQVEsSUFGTDtBQUdIQyxvQkFBUSxDQUhMO0FBSUhDLG1CQUFPLEVBSko7QUFLSEMsd0JBQVksRUFMVDtBQU1IQywyQkFBZTtBQUNYQyw2QkFBYTtBQURGLGFBTlo7QUFTSEMsNEJBQWdCLEVBVGI7QUFVSEMsZ0JBQUksSUFWRDtBQVdIQyxxQkFBUyxDQVhOO0FBWUhDLGtCQUFNLEVBWkg7QUFhSEMsdUJBQVcsRUFiUjtBQWNIQyxvQkFBUTtBQUNKLG1CQUFHO0FBQ0NDLHVCQUFHLEtBREo7QUFFQ0MsdUJBQUc7QUFGSixpQkFEQztBQUtKLG1CQUFHO0FBQ0NELHVCQUFHLE1BREo7QUFFQ0MsdUJBQUc7QUFGSixpQkFMQztBQVNKLG1CQUFHO0FBQ0NELHVCQUFHLE1BREo7QUFFQ0MsdUJBQUc7QUFGSixpQkFUQztBQWFKLG1CQUFHO0FBQ0NELHVCQUFHLEtBREo7QUFFQ0MsdUJBQUc7QUFGSjtBQWJDO0FBZEwsUyxRQWlDUEMsTSxHQUFTO0FBQ0xDLDBDQUE4QixTQUR6QjtBQUVMQyxvQ0FBd0IsSUFGbkI7QUFHTCwrQkFBbUI7QUFDZiwrQkFBZTtBQURBO0FBSGQsUyxRQU9UQyxVLEdBQWE7QUFDVEM7QUFEUyxTLFFBR2JDLFEsR0FBVztBQUNQQyxvQkFETyxzQkFDSTtBQUNQLG9CQUFJLEtBQUtoQixhQUFULEVBQXdCO0FBQ3BCLHdCQUFJaUIsTUFBTSxLQUFLakIsYUFBZjtBQUNBLHdCQUFJa0IsS0FBTUQsSUFBSUUsZ0JBQUosR0FBdUIsQ0FBakM7QUFBQSx3QkFDSUMsTUFBTUgsSUFBSUksV0FBSixHQUFrQixDQUQ1QjtBQUVBLHlCQUFLakIsT0FBTCxHQUFla0IsU0FBU0osS0FBS0UsR0FBTCxHQUFXLEdBQXBCLENBQWY7QUFDQSwyQkFBT0YsRUFBUDtBQUNIO0FBQ0o7QUFUTSxTLFFBK0JYSyxPLEdBQVU7QUFDTkMscUJBRE0sdUJBQ007QUFDUixxQkFBS2xCLFNBQUwsR0FBaUIsRUFBakI7QUFDSCxhQUhLO0FBSUFtQixxQkFKQTtBQUFBLHFHQUlVQyxDQUpWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQ0FLRUEsRUFBRUMsTUFBRixDQUFTQyxNQUFULElBQW1CLGdCQUxyQjtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBLDJDQU1RQyxlQUFLQyxXQUFMLENBQWlCSixFQUFFQyxNQUFuQixDQU5SOztBQUFBO0FBT0VJLG9EQUFNQyxJQUFOLENBQVcsV0FBWCxFQUF3QjtBQUNwQkMsZ0RBQVEsS0FBS2xDLFVBRE87QUFFcEJtQyw4Q0FBTSx3QkFGYztBQUdwQkMsNENBQUksS0FBS25DLGFBQUwsQ0FBbUJtQyxFQUhIO0FBSXBCQyw4Q0FBSyxDQUplO0FBS3BCQyxrREFBUyxLQUFLdEMsVUFBTCxDQUFnQm9DO0FBTEwscUNBQXhCO0FBT0FHLG1EQUFLQyxVQUFMLENBQWdCO0FBQ1pDLDZDQUFLO0FBRE8scUNBQWhCOztBQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBbUJOQyxtQkFuQk0scUJBbUJJO0FBQ04scUJBQUtuQyxTQUFMLEdBQWlCLE9BQWpCO0FBQ0gsYUFyQks7QUFzQkFvQyxpQkF0QkE7QUFBQSxzR0FzQk1oQixDQXRCTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMENBdUJFQSxFQUFFQyxNQUFGLENBQVNDLE1BQVQsSUFBbUIsZ0JBdkJyQjtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBLDJDQXdCUUMsZUFBS0MsV0FBTCxDQUFpQkosRUFBRUMsTUFBbkIsQ0F4QlI7O0FBQUE7QUF5QkVXLG1EQUFLQyxVQUFMLENBQWdCO0FBQ1pDLDRFQUFrQyxLQUFLekMsVUFBTCxDQUFnQm9DO0FBRHRDLHFDQUFoQjs7QUF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUE4Qk5RLGVBOUJNLGlCQThCQTtBQUNGTCwrQkFBS0MsVUFBTCxDQUFnQjtBQUNaQyxrRUFBNEMsS0FBS25DLElBQUwsQ0FBVXVDLEdBQVYsQ0FBY0MsUUFBMUQsYUFBMEUsS0FBS3hDLElBQUwsQ0FBVXVDLEdBQVYsQ0FBY1AsUUFBeEYsbUJBQThHLEtBQUtoQyxJQUFMLENBQVVQLEtBQXhIO0FBRFksaUJBQWhCO0FBR0gsYUFsQ0s7QUFtQ05nRCxpQkFuQ00sbUJBbUNFO0FBQ0pSLCtCQUFLQyxVQUFMLENBQWdCO0FBQ1pDLGlEQUEyQixLQUFLbkMsSUFBTCxDQUFVMEM7QUFEekIsaUJBQWhCO0FBR0gsYUF2Q0s7QUF3Q0FDLHlCQXhDQTtBQUFBLHNHQXdDY3RCLENBeENkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQ0F5Q0VZLGVBQUtXLGNBQUwsQ0FBb0IsUUFBcEIsS0FBaUMsRUFBakMsSUFBdUMsQ0FBQ1gsZUFBS1csY0FBTCxDQUFvQixRQUFwQixDQUF4QyxJQUF5RVgsZUFBS1csY0FBTCxDQUFvQixRQUFwQixLQUFpQyxDQXpDNUc7QUFBQTtBQUFBO0FBQUE7O0FBMENFWCxtREFBS0MsVUFBTCxDQUFnQjtBQUNaQztBQURZLHFDQUFoQjtBQTFDRjtBQUFBOztBQUFBO0FBQUE7QUFBQSwyQ0E4Q1EsS0FBS1UsV0FBTCxFQTlDUjs7QUFBQTtBQUFBO0FBQUEsMkNBK0NRLEtBQUtDLElBQUwsRUEvQ1I7O0FBQUE7QUFnREUseUNBQUtDLE1BQUw7O0FBaERGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUEsUzs7Ozs7MENBcEJRQyxHLEVBQUs7QUFDbkIsZ0JBQUlBLElBQUlDLElBQUosS0FBYSxRQUFqQixFQUEyQjtBQUN2QjtBQUNBO0FBQ0g7O0FBRUQsbUJBQU87QUFDSEMsdUJBQU8sS0FBS3hELFVBQUwsQ0FBZ0J5RCxZQURwQjtBQUVIQywwQkFBVSxLQUFLMUQsVUFBTCxDQUFnQjJELEtBRnZCO0FBR0h4QixzQkFBTSxnQ0FBZ0MsS0FBS2xDLGFBQUwsQ0FBbUJtQyxFQUFuRCxHQUF3RCxXQUF4RCxHQUFzRSxLQUFLd0IsTUFBTCxDQUFZQztBQUhyRixhQUFQO0FBS0g7Ozs7a0dBQ1lDLEc7Ozs7O0FBQ1QscUNBQUsvRCxLQUFMLEdBQWErRCxJQUFJMUIsRUFBSixJQUFVMEIsSUFBSUMsS0FBM0I7QUFDQSxxQ0FBS2pFLE1BQUwsR0FBY2tFLGlCQUFkOzt1Q0FDTWxDLGVBQUttQyxLQUFMLEU7OztBQUNOLHFDQUFLTCxNQUFMLEdBQWNyQixlQUFLVyxjQUFMLENBQW9CLFFBQXBCLENBQWQ7O3VDQUNNLEtBQUtFLElBQUwsRTs7O0FBQ04scUNBQUtDLE1BQUw7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3VDQXVEZ0IxQyxpQkFBT3dDLFdBQVAsQ0FBbUIsS0FBS3BELEtBQXhCLEM7OztBQUFadUQsbUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozt1Q0FNTVksY0FBSUMsZUFBSixDQUFvQixLQUFLcEUsS0FBekIsQzs7OztBQUZOcUUsdUMsU0FBQUEsTztBQUNBekUsb0MsU0FBQUEsSTs7QUFFSixvQ0FBSXlFLFdBQVcsR0FBZixFQUFvQjtBQUNoQix5Q0FBSzlELElBQUwsR0FBWVgsSUFBWjtBQUNBLHlDQUFLSyxVQUFMLEdBQWtCTCxLQUFLSyxVQUF2QjtBQUNBLHlDQUFLQyxhQUFMLEdBQXFCTixLQUFLa0QsR0FBMUI7QUFDQXdCLDRDQUFRQyxHQUFSLENBQVksS0FBS3JFLGFBQUwsQ0FBbUJDLFdBQS9CO0FBQ0EseUNBQUtDLGNBQUwsR0FBc0JSLEtBQUtRLGNBQTNCO0FBQ0g7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUE3STJCb0MsZUFBS2dDLEk7O2tCQUFwQjdFLE0iLCJmaWxlIjoicGFnZS5qcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4gICAgaW1wb3J0IHdlcHkgZnJvbSBcIndlcHlcIlxyXG4gICAgaW1wb3J0IGNvbmZpZyBmcm9tIFwiQC9hcGkvY29uZmlnXCJcbiAgICBpbXBvcnQgYXBpIGZyb20gXCIuLi9hcGlcIlxyXG4gICAgaW1wb3J0IGF1dGggZnJvbSBcIkAvYXBpL2F1dGhcIlxyXG4gICAgaW1wb3J0IExhbmcgZnJvbSBcIkAvdXRpbHMvTGFuZ1wiXHJcbiAgICBpbXBvcnQgc3RvcmUgZnJvbSBcIkAvc3RvcmUvdXRpbHNcIlxyXG4gICAgaW1wb3J0IGNvbnRhY3QgZnJvbSBcIkAvY29tcG9uZW50cy9jb21tb24vY29udGFjdFwiXHJcbiAgICBleHBvcnQgZGVmYXVsdCBjbGFzcyBEaWFsb2cgZXh0ZW5kcyB3ZXB5LnBhZ2Uge1xyXG4gICAgICAgIGRhdGEgPSB7XHJcbiAgICAgICAgICAgIGNsb3NlOiBcIi9zdGF0aWMvaW1hZ2VzL2Nsb3NlLnBuZ1wiLFxyXG4gICAgICAgICAgICBhY3RpdmU6IHRydWUsXHJcbiAgICAgICAgICAgIHJvdXRlczogMCxcclxuICAgICAgICAgICAgcmVnSWQ6ICcnLFxyXG4gICAgICAgICAgICBjb3Vyc2VJbmZvOiB7fSxcclxuICAgICAgICAgICAgQWN0QmFyZ2FpblJlZzoge1xyXG4gICAgICAgICAgICAgICAgaW52YWxpZFRpbWU6ICcnXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGJhcmdhaW5SZWNvcmRzOiBbXSxcclxuICAgICAgICAgICAgZGo6IDMwMDAsXHJcbiAgICAgICAgICAgIHBlcmNlbnQ6IDAsXHJcbiAgICAgICAgICAgIGluZm86IHt9LFxyXG4gICAgICAgICAgICBtb2RhbE5hbWU6ICcnLFxyXG4gICAgICAgICAgICBzdGF0dXM6IHtcclxuICAgICAgICAgICAgICAgIDA6IHtcclxuICAgICAgICAgICAgICAgICAgICBhOiAn56CN5Lu35LitJyxcclxuICAgICAgICAgICAgICAgICAgICBiOiAnJ1xyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIDE6IHtcclxuICAgICAgICAgICAgICAgICAgICBhOiAn56CN5Lu35a6M5oiQJyxcclxuICAgICAgICAgICAgICAgICAgICBiOiAn5b6F5pSv5LuYJ1xyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIDI6IHtcclxuICAgICAgICAgICAgICAgICAgICBhOiAn56CN5Lu35a6M5oiQJyxcclxuICAgICAgICAgICAgICAgICAgICBiOiAn5bey5pSv5LuYJ1xyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIDM6IHtcclxuICAgICAgICAgICAgICAgICAgICBhOiAn5bey6L+H5pyfJyxcclxuICAgICAgICAgICAgICAgICAgICBiOiAn56CN5Lu357uT5p2fJ1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuICAgICAgICBjb25maWcgPSB7XHJcbiAgICAgICAgICAgIG5hdmlnYXRpb25CYXJCYWNrZ3JvdW5kQ29sb3I6ICcjZWQxYzI0JyxcclxuICAgICAgICAgICAgbmF2aWdhdGlvbkJhclRpdGxlVGV4dDogJ+egjeS7tycsXHJcbiAgICAgICAgICAgIFwidXNpbmdDb21wb25lbnRzXCI6IHtcclxuICAgICAgICAgICAgICAgIFwibC1jb3VudGRvd25cIjogXCIuLi8uLi9jb21wb25lbnRzL2NvdW50ZG93bi9pbmRleFwiXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgY29tcG9uZW50cyA9IHtcclxuICAgICAgICAgICAgY29udGFjdFxyXG4gICAgICAgIH1cclxuICAgICAgICBjb21wdXRlZCA9IHtcclxuICAgICAgICAgICAgY3V0UHJpY2UoKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5BY3RCYXJnYWluUmVnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGFjdCA9IHRoaXMuQWN0QmFyZ2FpblJlZ1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBfcCA9ICBhY3Quc3VwcG9ydGVkQW1vdW50cyAqIDEgLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBfc3AgPSBhY3QuY291cnNlUHJpY2UgKiAxXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5wZXJjZW50ID0gcGFyc2VJbnQoX3AgLyBfc3AgKiAxMDApXHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIF9wXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgb25TaGFyZUFwcE1lc3NhZ2UocmVzKSB7XHJcbiAgICAgICAgICAgIGlmIChyZXMuZnJvbSA9PT0gJ2J1dHRvbicpIHtcclxuICAgICAgICAgICAgICAgIC8vIOadpeiHqumhtemdouWGhei9rOWPkeaMiemSrlxyXG4gICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2cocmVzLnRhcmdldClcclxuICAgICAgICAgICAgfVxuXHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICB0aXRsZTogdGhpcy5jb3Vyc2VJbmZvLmNvdXJzZVRpdHRsZSxcclxuICAgICAgICAgICAgICAgIGltYWdlVXJsOiB0aGlzLmNvdXJzZUluZm8uaW1hZ2UsXHJcbiAgICAgICAgICAgICAgICBwYXRoOiAnL3BhZ2VzL2FjdGl2aXR5L2JhcmdhaW4/aWQ9JyArIHRoaXMuQWN0QmFyZ2FpblJlZy5pZCArICcmYWdlbnRJZD0nICsgdGhpcy5tZW1iZXIuYWdlbnRJZFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGFzeW5jIG9uTG9hZChvcHQpIHtcclxuICAgICAgICAgICAgdGhpcy5yZWdJZCA9IG9wdC5pZCB8fCBvcHQuc2NlbmVcclxuICAgICAgICAgICAgdGhpcy5yb3V0ZXMgPSBnZXRDdXJyZW50UGFnZXMoKVxyXG4gICAgICAgICAgICBhd2FpdCBhdXRoLmxvZ2luKClcclxuICAgICAgICAgICAgdGhpcy5tZW1iZXIgPSB3ZXB5LmdldFN0b3JhZ2VTeW5jKCdtZW1iZXInKTtcclxuICAgICAgICAgICAgYXdhaXQgdGhpcy5sb2FkKClcclxuICAgICAgICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgICAgIH1cclxuICAgICAgICBtZXRob2RzID0ge1xyXG4gICAgICAgICAgICBoaWRlTW9kYWwoKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vZGFsTmFtZSA9ICcnXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGFzeW5jIGNyZWF0ZUltZyhlKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoZS5kZXRhaWwuZXJyTXNnID09IFwiZ2V0VXNlckluZm86b2tcIikge1xyXG4gICAgICAgICAgICAgICAgICAgIGF3YWl0IGF1dGguZ2V0VXNlcmluZm8oZS5kZXRhaWwpXHJcbiAgICAgICAgICAgICAgICAgICAgc3RvcmUuc2F2ZSgnc2hhcmVJbmZvJywge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb3Vyc2U6IHRoaXMuY291cnNlSW5mbyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGF0aDogJ3BhZ2VzL2FjdGl2aXR5L2JhcmdhaW4nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZDogdGhpcy5BY3RCYXJnYWluUmVnLmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTozLFxuICAgICAgICAgICAgICAgICAgICAgICAgY291cnNlSWQ6dGhpcy5jb3Vyc2VJbmZvLmlkXHJcbiAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB1cmw6ICcvcGFnZXMvaG9tZS9zaGFyZSdcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgdG9zaGFyZSgpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMubW9kYWxOYW1lID0gJ3NoYXJlJ1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBhc3luYyB0b2N1dChlKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoZS5kZXRhaWwuZXJyTXNnID09IFwiZ2V0VXNlckluZm86b2tcIikge1xyXG4gICAgICAgICAgICAgICAgICAgIGF3YWl0IGF1dGguZ2V0VXNlcmluZm8oZS5kZXRhaWwpXHJcbiAgICAgICAgICAgICAgICAgICAgd2VweS5uYXZpZ2F0ZVRvKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdXJsOiBgL3BhZ2VzL2RldGFpbGUvZGV0YWlsZT9pZD0ke3RoaXMuY291cnNlSW5mby5pZH1gXHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGJ1eSgpIHtcclxuICAgICAgICAgICAgICAgIHdlcHkubmF2aWdhdGVUbyh7XHJcbiAgICAgICAgICAgICAgICAgICAgdXJsOiBgL3BhZ2VzL2RldGFpbGUvc3VyZU9yZGVyP3R5cGU9MiZwaWQ9JHt0aGlzLmluZm8ucmVnLnBlcmlvZElkfSZjaWQ9JHt0aGlzLmluZm8ucmVnLmNvdXJzZUlkfSZudW09MSZhaWQ9JHt0aGlzLmluZm8ucmVnSWR9JmFjdHBpZD0wYFxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHRvcGF5KCkge1xyXG4gICAgICAgICAgICAgICAgd2VweS5uYXZpZ2F0ZVRvKHtcclxuICAgICAgICAgICAgICAgICAgICB1cmw6IGAvcGFnZXMvbXkvb3JkZXI/aWQ9JHt0aGlzLmluZm8ub3JkZXJJZH1gXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgYXN5bmMgb25Hb3RVc2VySW5mbyhlKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAod2VweS5nZXRTdG9yYWdlU3luYygnbW9iaWxlJykgPT0gJycgfHwgIXdlcHkuZ2V0U3RvcmFnZVN5bmMoJ21vYmlsZScpIHx8IHdlcHkuZ2V0U3RvcmFnZVN5bmMoJ2lzRmFucycpICE9IDEpIHtcclxuICAgICAgICAgICAgICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB1cmw6IGAvcGFnZXMvaG9tZS9hdXRoYFxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBhd2FpdCB0aGlzLmhlbHBCYXJnYWluKClcclxuICAgICAgICAgICAgICAgICAgICBhd2FpdCB0aGlzLmxvYWQoKVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICB9O1xyXG4gICAgICAgIGFzeW5jIGhlbHBCYXJnYWluKCkge1xyXG4gICAgICAgICAgICBsZXQgcmVzID0gYXdhaXQgY29uZmlnLmhlbHBCYXJnYWluKHRoaXMucmVnSWQpXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGFzeW5jIGxvYWQoKSB7XHJcbiAgICAgICAgICAgIGxldCB7XHJcbiAgICAgICAgICAgICAgICBlcnJjb2RlLFxyXG4gICAgICAgICAgICAgICAgZGF0YVxyXG4gICAgICAgICAgICB9ID0gYXdhaXQgYXBpLmdldFN1cHBvcnREZXRhaSh0aGlzLnJlZ0lkKVxyXG4gICAgICAgICAgICBpZiAoZXJyY29kZSA9PSAyMDApIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuaW5mbyA9IGRhdGFcclxuICAgICAgICAgICAgICAgIHRoaXMuY291cnNlSW5mbyA9IGRhdGEuY291cnNlSW5mb1xyXG4gICAgICAgICAgICAgICAgdGhpcy5BY3RCYXJnYWluUmVnID0gZGF0YS5yZWdcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKHRoaXMuQWN0QmFyZ2FpblJlZy5pbnZhbGlkVGltZSlcclxuICAgICAgICAgICAgICAgIHRoaXMuYmFyZ2FpblJlY29yZHMgPSBkYXRhLmJhcmdhaW5SZWNvcmRzXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbiJdfQ==