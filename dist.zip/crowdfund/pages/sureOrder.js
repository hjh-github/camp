"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _api = require('./../api.js');

var _api2 = _interopRequireDefault(_api);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

var _WxUtils = require('./../../utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
  _inherits(Dialog, _wepy$page);

  function Dialog() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, Dialog);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
      navigationBarTitleText: "选择出行人"
    }, _this.data = {
      modalName: '',
      orderInfo: {},
      payParams: {},
      childs: [],
      mobile: '',
      canpay: true,
      paymentType: 1,
      coupons: [],
      couponUser: {
        id: ''
      },
      opt: {},
      bg_img: {
        cou_bg_1: 'https://images.kuan1.cn/kuan1/upload/image/20201227/20201227141029_82067.png',
        cou_bg_0: 'https://images.kuan1.cn/kuan1/upload/image/20201227/20201227141101_21176.png'
      }
    }, _this.methods = {
      touse: function touse(coupon) {
        this.couponUser = coupon;
        this.modalName = '';
        this.getorderInfo();
      },
      hideModal: function hideModal() {
        this.modalName = '';
      },
      openCoupons: function openCoupons() {
        this.modalName = 'coupons';
      },
      bindgetphonenumber: function () {
        var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(e) {
          var mobile;
          return regeneratorRuntime.wrap(function _callee$(_context) {
            while (1) {
              switch (_context.prev = _context.next) {
                case 0:
                  if (!(e.detail.errMsg == "getPhoneNumber:ok")) {
                    _context.next = 6;
                    break;
                  }

                  _context.next = 3;
                  return _auth2.default.getPhone(e.detail);

                case 3:
                  mobile = _context.sent;

                  if (mobile) {
                    _wepy2.default.setStorageSync('mobile', mobile);
                    this.mobile = mobile;
                  }
                  this.$apply();

                case 6:
                case "end":
                  return _context.stop();
              }
            }
          }, _callee, this);
        }));

        function bindgetphonenumber(_x) {
          return _ref2.apply(this, arguments);
        }

        return bindgetphonenumber;
      }(),
      textareaBInput: function textareaBInput(e) {
        this.payParams.remark = e.detail.value;
      },
      paymentType: function paymentType(type) {
        this.paymentType = type;
        this.getorderInfo();
      },
      plus: function plus() {
        wx.vibrateShort();
        // this.payParams.courseNum = this.payParams.courseNum + 1
        this.opt.num = parseInt(this.opt.num) + 1;
        this.childs = [];
        this.getorderInfo();
      },
      minus: function minus() {
        if (this.opt.num > 1) {
          wx.vibrateShort();
          this.opt.num = parseInt(this.opt.num) - 1;
          this.childs = [];
          this.getorderInfo();
        }
      },
      getChilds: function () {
        var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(e) {
          return regeneratorRuntime.wrap(function _callee2$(_context2) {
            while (1) {
              switch (_context2.prev = _context2.next) {
                case 0:
                  if (this.mobile) {
                    _context2.next = 2;
                    break;
                  }

                  return _context2.abrupt("return", false);

                case 2:
                  if (!(e.detail.errMsg == "getUserInfo:ok")) {
                    _context2.next = 6;
                    break;
                  }

                  _context2.next = 5;
                  return _auth2.default.getUserinfo(e.detail);

                case 5:
                  _wepy2.default.navigateTo({
                    url: '/pages/meet/childs?type=1&len=' + this.payParams.courseNum
                  });

                case 6:
                case "end":
                  return _context2.stop();
              }
            }
          }, _callee2, this);
        }));

        function getChilds(_x2) {
          return _ref3.apply(this, arguments);
        }

        return getChilds;
      }(),
      pay: function () {
        var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
          var _this2 = this;

          var ids, params;
          return regeneratorRuntime.wrap(function _callee3$(_context3) {
            while (1) {
              switch (_context3.prev = _context3.next) {
                case 0:
                  if (this.childs.length) {
                    _context3.next = 3;
                    break;
                  }

                  _Tips2.default.toast("请先选择出行人", function (res) {}, 'none');
                  return _context3.abrupt("return", false);

                case 3:
                  ids = this.childs.map(function (e) {
                    return e.id;
                  });
                  params = {
                    crowdfundingId: 2,
                    courseId: this.payParams.courseId,
                    periodId: this.payParams.periodId,
                    copywriting: this.payParams.remark,
                    childId: ids.join(',')
                  };

                  this.canpay = false;
                  _api2.default.toCrowdfunding(params).then(function (res) {
                    if (res.errcode == 200) {
                      _Tips2.default.toast("发起成功！正在跳转…", function (r) {}, 'none');
                    } else {
                      _Tips2.default.toast(res.errmsg, function (r) {}, 'none');
                    }
                    wx.redirectTo({
                      url: './page?id=' + res.data.regId
                    });
                  }).catch(function (err) {
                    _this2.canpay = true;
                    _this2.$apply();
                  });

                case 7:
                case "end":
                  return _context3.stop();
              }
            }
          }, _callee3, this);
        }));

        function pay() {
          return _ref4.apply(this, arguments);
        }

        return pay;
      }()
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(Dialog, [{
    key: "onLoad",
    value: function () {
      var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4(opt) {
        return regeneratorRuntime.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                this.opt = opt;
                this.paymentType = this.opt.pt;
                this.mobile = _wepy2.default.getStorageSync('mobile');
                // this.payParams = wepy.$instance.globalData.orderInfo
                // this.orderInfo = wepy.$instance.globalData.courseInfo
                _context4.next = 5;
                return this.getorderInfo();

              case 5:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, this);
      }));

      function onLoad(_x3) {
        return _ref5.apply(this, arguments);
      }

      return onLoad;
    }()
  }, {
    key: "onShow",
    value: function onShow() {
      this.childs = _wepy2.default.$instance.globalData.childs;
    }
  }, {
    key: "onUnload",
    value: function onUnload() {
      this.childs = _wepy2.default.$instance.globalData.childs = [];
    }
    // 根据课程详情参数，生成支付订单信息

  }, {
    key: "getorderInfo",
    value: function () {
      var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
        var params, _ref7, errcode, data, _data;

        return regeneratorRuntime.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                /*
                  params ={
                    orderType: ${opt.type}, // 订单类型
                    courseId: ${opt.cid}, // 课程id
                    periodId: ${opt.pid}, // 营期id
                    num: ${opt.num}, // 数量
                    actId: ${opt.aId}, // 活动id
                  }
                */
                params = {
                  orderType: this.opt.type,
                  courseId: this.opt.cid,
                  periodId: this.opt.pid,
                  num: this.opt.num,
                  actId: this.opt.aid,
                  couponUserId: this.couponUser.id,
                  paymentType: this.paymentType
                };
                _context5.next = 3;
                return _config2.default.orderInfo(params);

              case 3:
                _ref7 = _context5.sent;
                errcode = _ref7.errcode;
                data = _ref7.data;

                if (errcode == 200) {
                  this.orderInfo = data.course;
                  _data = data;
                  // 有可用券 并选中

                  if (data.couponUser) {
                    this.couponUser = data.couponUser;
                  } else {
                    this.couponUser = {
                      id: ''
                    };
                  }
                  // 有可用券
                  if (data.couponUserList) {
                    this.coupons = data.couponUserList;
                  } else {
                    this.coupons = [];
                  }

                  this.payParams = {
                    childIds: '',
                    courseId: _data.courseId,
                    courseNum: _data.num,
                    periodId: _data.periodId,
                    remark: '',
                    orderType: _data.orderType,
                    periodName: _data.period,
                    actId: _data.actId,
                    price: _data.totalPrice,
                    actPintuanId: this.opt.actpid,
                    paymentType: this.paymentType,
                    couponUserId: this.couponUser.id
                  };
                }
                this.$apply();

              case 8:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5, this);
      }));

      function getorderInfo() {
        return _ref6.apply(this, arguments);
      }

      return getorderInfo;
    }()
  }]);

  return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'crowdfund/pages/sureOrder'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN1cmVPcmRlci5qcyJdLCJuYW1lcyI6WyJEaWFsb2ciLCJjb25maWciLCJuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0IiwiZGF0YSIsIm1vZGFsTmFtZSIsIm9yZGVySW5mbyIsInBheVBhcmFtcyIsImNoaWxkcyIsIm1vYmlsZSIsImNhbnBheSIsInBheW1lbnRUeXBlIiwiY291cG9ucyIsImNvdXBvblVzZXIiLCJpZCIsIm9wdCIsImJnX2ltZyIsImNvdV9iZ18xIiwiY291X2JnXzAiLCJtZXRob2RzIiwidG91c2UiLCJjb3Vwb24iLCJnZXRvcmRlckluZm8iLCJoaWRlTW9kYWwiLCJvcGVuQ291cG9ucyIsImJpbmRnZXRwaG9uZW51bWJlciIsImUiLCJkZXRhaWwiLCJlcnJNc2ciLCJhdXRoIiwiZ2V0UGhvbmUiLCJ3ZXB5Iiwic2V0U3RvcmFnZVN5bmMiLCIkYXBwbHkiLCJ0ZXh0YXJlYUJJbnB1dCIsInJlbWFyayIsInZhbHVlIiwidHlwZSIsInBsdXMiLCJ3eCIsInZpYnJhdGVTaG9ydCIsIm51bSIsInBhcnNlSW50IiwibWludXMiLCJnZXRDaGlsZHMiLCJnZXRVc2VyaW5mbyIsIm5hdmlnYXRlVG8iLCJ1cmwiLCJjb3Vyc2VOdW0iLCJwYXkiLCJsZW5ndGgiLCJUaXBzIiwidG9hc3QiLCJpZHMiLCJtYXAiLCJwYXJhbXMiLCJjcm93ZGZ1bmRpbmdJZCIsImNvdXJzZUlkIiwicGVyaW9kSWQiLCJjb3B5d3JpdGluZyIsImNoaWxkSWQiLCJqb2luIiwiYXBpIiwidG9Dcm93ZGZ1bmRpbmciLCJ0aGVuIiwicmVzIiwiZXJyY29kZSIsImVycm1zZyIsInJlZGlyZWN0VG8iLCJyZWdJZCIsImNhdGNoIiwicHQiLCJnZXRTdG9yYWdlU3luYyIsIiRpbnN0YW5jZSIsImdsb2JhbERhdGEiLCJvcmRlclR5cGUiLCJjaWQiLCJwaWQiLCJhY3RJZCIsImFpZCIsImNvdXBvblVzZXJJZCIsImNvdXJzZSIsIl9kYXRhIiwiY291cG9uVXNlckxpc3QiLCJjaGlsZElkcyIsInBlcmlvZE5hbWUiLCJwZXJpb2QiLCJwcmljZSIsInRvdGFsUHJpY2UiLCJhY3RQaW50dWFuSWQiLCJhY3RwaWQiLCJwYWdlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFDRTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7Ozs7Ozs7Ozs7O0lBQ3FCQSxNOzs7Ozs7Ozs7Ozs7OztzTEFDbkJDLE0sR0FBUztBQUNQQyw4QkFBd0I7QUFEakIsSyxRQUdUQyxJLEdBQU87QUFDTEMsaUJBQVcsRUFETjtBQUVMQyxpQkFBVyxFQUZOO0FBR0xDLGlCQUFXLEVBSE47QUFJTEMsY0FBUSxFQUpIO0FBS0xDLGNBQVEsRUFMSDtBQU1MQyxjQUFRLElBTkg7QUFPTEMsbUJBQWEsQ0FQUjtBQVFMQyxlQUFTLEVBUko7QUFTTEMsa0JBQVk7QUFDVkMsWUFBSTtBQURNLE9BVFA7QUFZTEMsV0FBSyxFQVpBO0FBYUxDLGNBQVE7QUFDTkMsa0JBQVUsOEVBREo7QUFFTkMsa0JBQVU7QUFGSjtBQWJILEssUUEyRlBDLE8sR0FBVTtBQUNSQyxXQURRLGlCQUNGQyxNQURFLEVBQ007QUFDWixhQUFLUixVQUFMLEdBQWtCUSxNQUFsQjtBQUNBLGFBQUtoQixTQUFMLEdBQWlCLEVBQWpCO0FBQ0EsYUFBS2lCLFlBQUw7QUFDRCxPQUxPO0FBTVJDLGVBTlEsdUJBTUk7QUFDVixhQUFLbEIsU0FBTCxHQUFpQixFQUFqQjtBQUNELE9BUk87QUFTUm1CLGlCQVRRLHlCQVNNO0FBQ1osYUFBS25CLFNBQUwsR0FBaUIsU0FBakI7QUFDRCxPQVhPO0FBWUZvQix3QkFaRTtBQUFBLDZGQVlpQkMsQ0FaakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBYUZBLEVBQUVDLE1BQUYsQ0FBU0MsTUFBVCxJQUFtQixtQkFiakI7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQSx5QkFjZUMsZUFBS0MsUUFBTCxDQUFjSixFQUFFQyxNQUFoQixDQWRmOztBQUFBO0FBY0FsQix3QkFkQTs7QUFlSixzQkFBSUEsTUFBSixFQUFZO0FBQ1ZzQixtQ0FBS0MsY0FBTCxDQUFvQixRQUFwQixFQUE4QnZCLE1BQTlCO0FBQ0EseUJBQUtBLE1BQUwsR0FBY0EsTUFBZDtBQUNEO0FBQ0QsdUJBQUt3QixNQUFMOztBQW5CSTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQXNCUkMsb0JBdEJRLDBCQXNCT1IsQ0F0QlAsRUFzQlU7QUFDaEIsYUFBS25CLFNBQUwsQ0FBZTRCLE1BQWYsR0FBd0JULEVBQUVDLE1BQUYsQ0FBU1MsS0FBakM7QUFDRCxPQXhCTztBQXlCUnpCLGlCQXpCUSx1QkF5QkkwQixJQXpCSixFQXlCVTtBQUNoQixhQUFLMUIsV0FBTCxHQUFtQjBCLElBQW5CO0FBQ0EsYUFBS2YsWUFBTDtBQUNELE9BNUJPO0FBNkJSZ0IsVUE3QlEsa0JBNkJEO0FBQ0xDLFdBQUdDLFlBQUg7QUFDQTtBQUNBLGFBQUt6QixHQUFMLENBQVMwQixHQUFULEdBQWVDLFNBQVMsS0FBSzNCLEdBQUwsQ0FBUzBCLEdBQWxCLElBQXlCLENBQXhDO0FBQ0EsYUFBS2pDLE1BQUwsR0FBYyxFQUFkO0FBQ0EsYUFBS2MsWUFBTDtBQUNELE9BbkNPO0FBb0NScUIsV0FwQ1EsbUJBb0NBO0FBQ04sWUFBSSxLQUFLNUIsR0FBTCxDQUFTMEIsR0FBVCxHQUFlLENBQW5CLEVBQXNCO0FBQ3BCRixhQUFHQyxZQUFIO0FBQ0EsZUFBS3pCLEdBQUwsQ0FBUzBCLEdBQVQsR0FBZUMsU0FBUyxLQUFLM0IsR0FBTCxDQUFTMEIsR0FBbEIsSUFBeUIsQ0FBeEM7QUFDQSxlQUFLakMsTUFBTCxHQUFjLEVBQWQ7QUFDQSxlQUFLYyxZQUFMO0FBQ0Q7QUFDRixPQTNDTztBQTRDRnNCLGVBNUNFO0FBQUEsOEZBNENRbEIsQ0E1Q1I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQTZDRCxLQUFLakIsTUE3Q0o7QUFBQTtBQUFBO0FBQUE7O0FBQUEsb0RBOENHLEtBOUNIOztBQUFBO0FBQUEsd0JBZ0RGaUIsRUFBRUMsTUFBRixDQUFTQyxNQUFULElBQW1CLGdCQWhEakI7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQSx5QkFpREVDLGVBQUtnQixXQUFMLENBQWlCbkIsRUFBRUMsTUFBbkIsQ0FqREY7O0FBQUE7QUFrREpJLGlDQUFLZSxVQUFMLENBQWdCO0FBQ2RDLHlCQUFLLG1DQUFtQyxLQUFLeEMsU0FBTCxDQUFleUM7QUFEekMsbUJBQWhCOztBQWxESTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQXVERkMsU0F2REU7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkF3REQsS0FBS3pDLE1BQUwsQ0FBWTBDLE1BeERYO0FBQUE7QUFBQTtBQUFBOztBQXlESkMsaUNBQUtDLEtBQUwsQ0FBVyxTQUFYLEVBQXNCLGVBQU8sQ0FBRSxDQUEvQixFQUFpQyxNQUFqQztBQXpESSxvREEwREcsS0ExREg7O0FBQUE7QUE0REZDLHFCQTVERSxHQTRESSxLQUFLN0MsTUFBTCxDQUFZOEMsR0FBWixDQUFnQixhQUFLO0FBQzdCLDJCQUFPNUIsRUFBRVosRUFBVDtBQUNELG1CQUZTLENBNURKO0FBK0RGeUMsd0JBL0RFLEdBK0RPO0FBQ1hDLG9DQUFnQixDQURMO0FBRVhDLDhCQUFVLEtBQUtsRCxTQUFMLENBQWVrRCxRQUZkO0FBR1hDLDhCQUFVLEtBQUtuRCxTQUFMLENBQWVtRCxRQUhkO0FBSVhDLGlDQUFhLEtBQUtwRCxTQUFMLENBQWU0QixNQUpqQjtBQUtYeUIsNkJBQVNQLElBQUlRLElBQUosQ0FBUyxHQUFUO0FBTEUsbUJBL0RQOztBQXNFTix1QkFBS25ELE1BQUwsR0FBYyxLQUFkO0FBQ0FvRCxnQ0FBSUMsY0FBSixDQUFtQlIsTUFBbkIsRUFBMkJTLElBQTNCLENBQWdDLGVBQU87QUFDckMsd0JBQUlDLElBQUlDLE9BQUosSUFBZSxHQUFuQixFQUF3QjtBQUN0QmYscUNBQUtDLEtBQUwsQ0FBWSxZQUFaLEVBQTBCLGFBQUssQ0FFOUIsQ0FGRCxFQUVHLE1BRkg7QUFHRCxxQkFKRCxNQUlLO0FBQ0hELHFDQUFLQyxLQUFMLENBQVlhLElBQUlFLE1BQWhCLEVBQXdCLGFBQUssQ0FFNUIsQ0FGRCxFQUVHLE1BRkg7QUFHRDtBQUNENUIsdUJBQUc2QixVQUFILENBQWM7QUFDWnJCLDJCQUFLLGVBQWVrQixJQUFJN0QsSUFBSixDQUFTaUU7QUFEakIscUJBQWQ7QUFHRCxtQkFiRCxFQWFHQyxLQWJILENBYVMsZUFBTztBQUNkLDJCQUFLNUQsTUFBTCxHQUFjLElBQWQ7QUFDQSwyQkFBS3VCLE1BQUw7QUFDRCxtQkFoQkQ7O0FBdkVNO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUEsSzs7Ozs7OzRGQXpFR2xCLEc7Ozs7O0FBQ1gscUJBQUtBLEdBQUwsR0FBV0EsR0FBWDtBQUNBLHFCQUFLSixXQUFMLEdBQW1CLEtBQUtJLEdBQUwsQ0FBU3dELEVBQTVCO0FBQ0EscUJBQUs5RCxNQUFMLEdBQWNzQixlQUFLeUMsY0FBTCxDQUFvQixRQUFwQixDQUFkO0FBQ0E7QUFDQTs7dUJBQ00sS0FBS2xELFlBQUwsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7OzZCQUVDO0FBQ1AsV0FBS2QsTUFBTCxHQUFjdUIsZUFBSzBDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQmxFLE1BQXhDO0FBQ0Q7OzsrQkFDVTtBQUNULFdBQUtBLE1BQUwsR0FBY3VCLGVBQUswQyxTQUFMLENBQWVDLFVBQWYsQ0FBMEJsRSxNQUExQixHQUFtQyxFQUFqRDtBQUNEO0FBQ0Q7Ozs7Ozs7Ozs7OztBQUVFOzs7Ozs7Ozs7QUFTSStDLHNCLEdBQVM7QUFDWG9CLDZCQUFXLEtBQUs1RCxHQUFMLENBQVNzQixJQURUO0FBRVhvQiw0QkFBVSxLQUFLMUMsR0FBTCxDQUFTNkQsR0FGUjtBQUdYbEIsNEJBQVUsS0FBSzNDLEdBQUwsQ0FBUzhELEdBSFI7QUFJWHBDLHVCQUFLLEtBQUsxQixHQUFMLENBQVMwQixHQUpIO0FBS1hxQyx5QkFBTyxLQUFLL0QsR0FBTCxDQUFTZ0UsR0FMTDtBQU1YQyxnQ0FBYyxLQUFLbkUsVUFBTCxDQUFnQkMsRUFObkI7QUFPWEgsK0JBQWEsS0FBS0E7QUFQUCxpQjs7dUJBWUhULGlCQUFPSSxTQUFQLENBQWlCaUQsTUFBakIsQzs7OztBQUZSVyx1QixTQUFBQSxPO0FBQ0E5RCxvQixTQUFBQSxJOztBQUVGLG9CQUFJOEQsV0FBVyxHQUFmLEVBQW9CO0FBQ2xCLHVCQUFLNUQsU0FBTCxHQUFpQkYsS0FBSzZFLE1BQXRCO0FBQ0lDLHVCQUZjLEdBRU45RSxJQUZNO0FBR2xCOztBQUNBLHNCQUFJQSxLQUFLUyxVQUFULEVBQXFCO0FBQ25CLHlCQUFLQSxVQUFMLEdBQWtCVCxLQUFLUyxVQUF2QjtBQUNELG1CQUZELE1BRU87QUFDTCx5QkFBS0EsVUFBTCxHQUFrQjtBQUNoQkMsMEJBQUk7QUFEWSxxQkFBbEI7QUFHRDtBQUNEO0FBQ0Esc0JBQUlWLEtBQUsrRSxjQUFULEVBQXlCO0FBQ3ZCLHlCQUFLdkUsT0FBTCxHQUFlUixLQUFLK0UsY0FBcEI7QUFDRCxtQkFGRCxNQUVPO0FBQ0wseUJBQUt2RSxPQUFMLEdBQWUsRUFBZjtBQUNEOztBQUVELHVCQUFLTCxTQUFMLEdBQWlCO0FBQ2Y2RSw4QkFBVSxFQURLO0FBRWYzQiw4QkFBVXlCLE1BQU16QixRQUZEO0FBR2ZULCtCQUFXa0MsTUFBTXpDLEdBSEY7QUFJZmlCLDhCQUFVd0IsTUFBTXhCLFFBSkQ7QUFLZnZCLDRCQUFRLEVBTE87QUFNZndDLCtCQUFXTyxNQUFNUCxTQU5GO0FBT2ZVLGdDQUFZSCxNQUFNSSxNQVBIO0FBUWZSLDJCQUFPSSxNQUFNSixLQVJFO0FBU2ZTLDJCQUFPTCxNQUFNTSxVQVRFO0FBVWZDLGtDQUFjLEtBQUsxRSxHQUFMLENBQVMyRSxNQVZSO0FBV2YvRSxpQ0FBYSxLQUFLQSxXQVhIO0FBWWZxRSxrQ0FBYyxLQUFLbkUsVUFBTCxDQUFnQkM7QUFaZixtQkFBakI7QUFjRDtBQUNELHFCQUFLbUIsTUFBTDs7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQTdGZ0NGLGVBQUs0RCxJOztrQkFBcEIxRixNIiwiZmlsZSI6InN1cmVPcmRlci5qcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4gIGltcG9ydCB3ZXB5IGZyb20gXCJ3ZXB5XCI7XHJcbiAgaW1wb3J0IGNvbmZpZyBmcm9tIFwiQC9hcGkvY29uZmlnXCJcclxuICBpbXBvcnQgYXBpIGZyb20gXCIuLi9hcGkuanNcIlxyXG4gIGltcG9ydCBUaXBzIGZyb20gXCJAL3V0aWxzL1RpcHNcIlxyXG4gIGltcG9ydCBXeFV0aWxzIGZyb20gXCJAL3V0aWxzL1d4VXRpbHNcIlxyXG4gIGltcG9ydCBhdXRoIGZyb20gXCJAL2FwaS9hdXRoXCJcclxuICBleHBvcnQgZGVmYXVsdCBjbGFzcyBEaWFsb2cgZXh0ZW5kcyB3ZXB5LnBhZ2Uge1xyXG4gICAgY29uZmlnID0ge1xyXG4gICAgICBuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0OiBcIumAieaLqeWHuuihjOS6ulwiXHJcbiAgICB9O1xyXG4gICAgZGF0YSA9IHtcclxuICAgICAgbW9kYWxOYW1lOiAnJyxcclxuICAgICAgb3JkZXJJbmZvOiB7fSxcclxuICAgICAgcGF5UGFyYW1zOiB7fSxcclxuICAgICAgY2hpbGRzOiBbXSxcclxuICAgICAgbW9iaWxlOiAnJyxcclxuICAgICAgY2FucGF5OiB0cnVlLFxyXG4gICAgICBwYXltZW50VHlwZTogMSxcclxuICAgICAgY291cG9uczogW10sXHJcbiAgICAgIGNvdXBvblVzZXI6IHtcclxuICAgICAgICBpZDogJydcclxuICAgICAgfSxcclxuICAgICAgb3B0OiB7fSxcclxuICAgICAgYmdfaW1nOiB7XHJcbiAgICAgICAgY291X2JnXzE6ICdodHRwczovL2ltYWdlcy5rdWFuMS5jbi9rdWFuMS91cGxvYWQvaW1hZ2UvMjAyMDEyMjcvMjAyMDEyMjcxNDEwMjlfODIwNjcucG5nJyxcclxuICAgICAgICBjb3VfYmdfMDogJ2h0dHBzOi8vaW1hZ2VzLmt1YW4xLmNuL2t1YW4xL3VwbG9hZC9pbWFnZS8yMDIwMTIyNy8yMDIwMTIyNzE0MTEwMV8yMTE3Ni5wbmcnLFxyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgYXN5bmMgb25Mb2FkKG9wdCkge1xyXG4gICAgICB0aGlzLm9wdCA9IG9wdFxyXG4gICAgICB0aGlzLnBheW1lbnRUeXBlID0gdGhpcy5vcHQucHRcclxuICAgICAgdGhpcy5tb2JpbGUgPSB3ZXB5LmdldFN0b3JhZ2VTeW5jKCdtb2JpbGUnKTtcclxuICAgICAgLy8gdGhpcy5wYXlQYXJhbXMgPSB3ZXB5LiRpbnN0YW5jZS5nbG9iYWxEYXRhLm9yZGVySW5mb1xyXG4gICAgICAvLyB0aGlzLm9yZGVySW5mbyA9IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuY291cnNlSW5mb1xyXG4gICAgICBhd2FpdCB0aGlzLmdldG9yZGVySW5mbygpXHJcbiAgICB9XHJcbiAgICBvblNob3coKSB7XHJcbiAgICAgIHRoaXMuY2hpbGRzID0gd2VweS4kaW5zdGFuY2UuZ2xvYmFsRGF0YS5jaGlsZHNcclxuICAgIH1cclxuICAgIG9uVW5sb2FkKCkge1xyXG4gICAgICB0aGlzLmNoaWxkcyA9IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEuY2hpbGRzID0gW11cclxuICAgIH1cclxuICAgIC8vIOagueaNruivvueoi+ivpuaDheWPguaVsO+8jOeUn+aIkOaUr+S7mOiuouWNleS/oeaBr1xyXG4gICAgYXN5bmMgZ2V0b3JkZXJJbmZvKCkge1xyXG4gICAgICAvKlxyXG4gICAgICAgIHBhcmFtcyA9e1xyXG4gICAgICAgICAgb3JkZXJUeXBlOiAke29wdC50eXBlfSwgLy8g6K6i5Y2V57G75Z6LXHJcbiAgICAgICAgICBjb3Vyc2VJZDogJHtvcHQuY2lkfSwgLy8g6K++56iLaWRcclxuICAgICAgICAgIHBlcmlvZElkOiAke29wdC5waWR9LCAvLyDokKXmnJ9pZFxyXG4gICAgICAgICAgbnVtOiAke29wdC5udW19LCAvLyDmlbDph49cclxuICAgICAgICAgIGFjdElkOiAke29wdC5hSWR9LCAvLyDmtLvliqhpZFxyXG4gICAgICAgIH1cclxuICAgICAgKi9cclxuICAgICAgbGV0IHBhcmFtcyA9IHtcclxuICAgICAgICBvcmRlclR5cGU6IHRoaXMub3B0LnR5cGUsXHJcbiAgICAgICAgY291cnNlSWQ6IHRoaXMub3B0LmNpZCxcclxuICAgICAgICBwZXJpb2RJZDogdGhpcy5vcHQucGlkLFxyXG4gICAgICAgIG51bTogdGhpcy5vcHQubnVtLFxyXG4gICAgICAgIGFjdElkOiB0aGlzLm9wdC5haWQsXHJcbiAgICAgICAgY291cG9uVXNlcklkOiB0aGlzLmNvdXBvblVzZXIuaWQsXHJcbiAgICAgICAgcGF5bWVudFR5cGU6IHRoaXMucGF5bWVudFR5cGVcclxuICAgICAgfVxyXG4gICAgICBsZXQge1xyXG4gICAgICAgIGVycmNvZGUsXHJcbiAgICAgICAgZGF0YVxyXG4gICAgICB9ID0gYXdhaXQgY29uZmlnLm9yZGVySW5mbyhwYXJhbXMpXHJcbiAgICAgIGlmIChlcnJjb2RlID09IDIwMCkge1xyXG4gICAgICAgIHRoaXMub3JkZXJJbmZvID0gZGF0YS5jb3Vyc2VcclxuICAgICAgICBsZXQgX2RhdGEgPSBkYXRhXHJcbiAgICAgICAgLy8g5pyJ5Y+v55So5Yi4IOW5tumAieS4rVxyXG4gICAgICAgIGlmIChkYXRhLmNvdXBvblVzZXIpIHtcclxuICAgICAgICAgIHRoaXMuY291cG9uVXNlciA9IGRhdGEuY291cG9uVXNlclxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICB0aGlzLmNvdXBvblVzZXIgPSB7XHJcbiAgICAgICAgICAgIGlkOiAnJ1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICAvLyDmnInlj6/nlKjliLhcclxuICAgICAgICBpZiAoZGF0YS5jb3Vwb25Vc2VyTGlzdCkge1xyXG4gICAgICAgICAgdGhpcy5jb3Vwb25zID0gZGF0YS5jb3Vwb25Vc2VyTGlzdFxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICB0aGlzLmNvdXBvbnMgPSBbXVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdGhpcy5wYXlQYXJhbXMgPSB7XHJcbiAgICAgICAgICBjaGlsZElkczogJycsXHJcbiAgICAgICAgICBjb3Vyc2VJZDogX2RhdGEuY291cnNlSWQsXHJcbiAgICAgICAgICBjb3Vyc2VOdW06IF9kYXRhLm51bSxcclxuICAgICAgICAgIHBlcmlvZElkOiBfZGF0YS5wZXJpb2RJZCxcclxuICAgICAgICAgIHJlbWFyazogJycsXHJcbiAgICAgICAgICBvcmRlclR5cGU6IF9kYXRhLm9yZGVyVHlwZSxcclxuICAgICAgICAgIHBlcmlvZE5hbWU6IF9kYXRhLnBlcmlvZCxcclxuICAgICAgICAgIGFjdElkOiBfZGF0YS5hY3RJZCxcclxuICAgICAgICAgIHByaWNlOiBfZGF0YS50b3RhbFByaWNlLFxyXG4gICAgICAgICAgYWN0UGludHVhbklkOiB0aGlzLm9wdC5hY3RwaWQsXHJcbiAgICAgICAgICBwYXltZW50VHlwZTogdGhpcy5wYXltZW50VHlwZSxcclxuICAgICAgICAgIGNvdXBvblVzZXJJZDogdGhpcy5jb3Vwb25Vc2VyLmlkXHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgIH1cclxuICAgIG1ldGhvZHMgPSB7XHJcbiAgICAgIHRvdXNlKGNvdXBvbikge1xyXG4gICAgICAgIHRoaXMuY291cG9uVXNlciA9IGNvdXBvblxyXG4gICAgICAgIHRoaXMubW9kYWxOYW1lID0gJydcclxuICAgICAgICB0aGlzLmdldG9yZGVySW5mbygpXHJcbiAgICAgIH0sXHJcbiAgICAgIGhpZGVNb2RhbCgpIHtcclxuICAgICAgICB0aGlzLm1vZGFsTmFtZSA9ICcnXHJcbiAgICAgIH0sXHJcbiAgICAgIG9wZW5Db3Vwb25zKCkge1xyXG4gICAgICAgIHRoaXMubW9kYWxOYW1lID0gJ2NvdXBvbnMnXHJcbiAgICAgIH0sXHJcbiAgICAgIGFzeW5jIGJpbmRnZXRwaG9uZW51bWJlcihlKSB7XHJcbiAgICAgICAgaWYgKGUuZGV0YWlsLmVyck1zZyA9PSBcImdldFBob25lTnVtYmVyOm9rXCIpIHtcclxuICAgICAgICAgIGxldCBtb2JpbGUgPSBhd2FpdCBhdXRoLmdldFBob25lKGUuZGV0YWlsKVxyXG4gICAgICAgICAgaWYgKG1vYmlsZSkge1xyXG4gICAgICAgICAgICB3ZXB5LnNldFN0b3JhZ2VTeW5jKCdtb2JpbGUnLCBtb2JpbGUpO1xyXG4gICAgICAgICAgICB0aGlzLm1vYmlsZSA9IG1vYmlsZVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgICAgIH1cclxuICAgICAgfSxcclxuICAgICAgdGV4dGFyZWFCSW5wdXQoZSkge1xyXG4gICAgICAgIHRoaXMucGF5UGFyYW1zLnJlbWFyayA9IGUuZGV0YWlsLnZhbHVlXHJcbiAgICAgIH0sXHJcbiAgICAgIHBheW1lbnRUeXBlKHR5cGUpIHtcclxuICAgICAgICB0aGlzLnBheW1lbnRUeXBlID0gdHlwZVxyXG4gICAgICAgIHRoaXMuZ2V0b3JkZXJJbmZvKClcclxuICAgICAgfSxcclxuICAgICAgcGx1cygpIHtcclxuICAgICAgICB3eC52aWJyYXRlU2hvcnQoKVxyXG4gICAgICAgIC8vIHRoaXMucGF5UGFyYW1zLmNvdXJzZU51bSA9IHRoaXMucGF5UGFyYW1zLmNvdXJzZU51bSArIDFcclxuICAgICAgICB0aGlzLm9wdC5udW0gPSBwYXJzZUludCh0aGlzLm9wdC5udW0pICsgMVxyXG4gICAgICAgIHRoaXMuY2hpbGRzID0gW11cclxuICAgICAgICB0aGlzLmdldG9yZGVySW5mbygpXHJcbiAgICAgIH0sXHJcbiAgICAgIG1pbnVzKCkge1xyXG4gICAgICAgIGlmICh0aGlzLm9wdC5udW0gPiAxKSB7XHJcbiAgICAgICAgICB3eC52aWJyYXRlU2hvcnQoKVxyXG4gICAgICAgICAgdGhpcy5vcHQubnVtID0gcGFyc2VJbnQodGhpcy5vcHQubnVtKSAtIDFcclxuICAgICAgICAgIHRoaXMuY2hpbGRzID0gW11cclxuICAgICAgICAgIHRoaXMuZ2V0b3JkZXJJbmZvKClcclxuICAgICAgICB9XHJcbiAgICAgIH0sXHJcbiAgICAgIGFzeW5jIGdldENoaWxkcyhlKSB7XHJcbiAgICAgICAgaWYgKCF0aGlzLm1vYmlsZSkge1xyXG4gICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChlLmRldGFpbC5lcnJNc2cgPT0gXCJnZXRVc2VySW5mbzpva1wiKSB7XHJcbiAgICAgICAgICBhd2FpdCBhdXRoLmdldFVzZXJpbmZvKGUuZGV0YWlsKVxyXG4gICAgICAgICAgd2VweS5uYXZpZ2F0ZVRvKHtcclxuICAgICAgICAgICAgdXJsOiAnL3BhZ2VzL21lZXQvY2hpbGRzP3R5cGU9MSZsZW49JyArIHRoaXMucGF5UGFyYW1zLmNvdXJzZU51bVxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG4gICAgICBhc3luYyBwYXkoKSB7XHJcbiAgICAgICAgaWYgKCF0aGlzLmNoaWxkcy5sZW5ndGgpIHtcclxuICAgICAgICAgIFRpcHMudG9hc3QoXCLor7flhYjpgInmi6nlh7rooYzkurpcIiwgcmVzID0+IHt9LCAnbm9uZScpO1xyXG4gICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGxldCBpZHMgPSB0aGlzLmNoaWxkcy5tYXAoZSA9PiB7XHJcbiAgICAgICAgICByZXR1cm4gZS5pZFxyXG4gICAgICAgIH0pXHJcbiAgICAgICAgbGV0IHBhcmFtcyA9IHtcclxuICAgICAgICAgIGNyb3dkZnVuZGluZ0lkOiAyLFxyXG4gICAgICAgICAgY291cnNlSWQ6IHRoaXMucGF5UGFyYW1zLmNvdXJzZUlkLFxyXG4gICAgICAgICAgcGVyaW9kSWQ6IHRoaXMucGF5UGFyYW1zLnBlcmlvZElkLFxyXG4gICAgICAgICAgY29weXdyaXRpbmc6IHRoaXMucGF5UGFyYW1zLnJlbWFyayxcclxuICAgICAgICAgIGNoaWxkSWQ6IGlkcy5qb2luKCcsJylcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5jYW5wYXkgPSBmYWxzZVxyXG4gICAgICAgIGFwaS50b0Nyb3dkZnVuZGluZyhwYXJhbXMpLnRoZW4ocmVzID0+IHtcclxuICAgICAgICAgIGlmIChyZXMuZXJyY29kZSA9PSAyMDApIHtcclxuICAgICAgICAgICAgVGlwcy50b2FzdCggXCLlj5HotbfmiJDlip/vvIHmraPlnKjot7PovazigKZcIiwgciA9PiB7XHJcbiAgICAgICAgICAgICBcclxuICAgICAgICAgICAgfSwgJ25vbmUnKTtcclxuICAgICAgICAgIH1lbHNle1xuICAgICAgICAgICAgVGlwcy50b2FzdCggcmVzLmVycm1zZywgciA9PiB7XG4gICAgICAgICAgICAgIFxuICAgICAgICAgICAgfSwgJ25vbmUnKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgd3gucmVkaXJlY3RUbyh7XG4gICAgICAgICAgICB1cmw6ICcuL3BhZ2U/aWQ9JyArIHJlcy5kYXRhLnJlZ0lkXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfSkuY2F0Y2goZXJyID0+IHtcclxuICAgICAgICAgIHRoaXMuY2FucGF5ID0gdHJ1ZVxyXG4gICAgICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgICAgIH0pXHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgfVxyXG4iXX0=