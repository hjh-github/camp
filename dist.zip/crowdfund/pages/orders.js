"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _api = require('./../api.js');

var _api2 = _interopRequireDefault(_api);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

var _WxUtils = require('./../../utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

var _auth = require('./../../api/auth.js');

var _auth2 = _interopRequireDefault(_auth);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
    _inherits(Dialog, _wepy$page);

    function Dialog() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Dialog);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
            navigationBarTitleText: "我的众筹",
            "usingComponents": {
                "l-countdown": "../../components/countdown/index"
            }
        }, _this.data = {
            theme: _wepy2.default.$instance.globalData.themeColor,
            orderState: {
                0: '众筹中',
                1: '待付款',
                2: '已完成',
                3: '已过期'
            },
            orderStats: {},
            scrollLeft: 0,
            pageIndex: 1,
            orders: [],
            toload: false,
            isload: true,
            loadmoring: false
        }, _this.methods = {
            tocut: function tocut(e) {
                _wepy2.default.navigateTo({
                    url: './page?id=' + e.id
                });
            }
        }, _temp), _possibleConstructorReturn(_this, _ret);
    }

    _createClass(Dialog, [{
        key: "onLoad",
        value: function () {
            var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(opt) {
                return regeneratorRuntime.wrap(function _callee$(_context) {
                    while (1) {
                        switch (_context.prev = _context.next) {
                            case 0:
                                _context.next = 2;
                                return _auth2.default.login();

                            case 2:
                                _context.next = 4;
                                return this.loadData();

                            case 4:
                                this.isload = false;

                            case 5:
                            case "end":
                                return _context.stop();
                        }
                    }
                }, _callee, this);
            }));

            function onLoad(_x) {
                return _ref2.apply(this, arguments);
            }

            return onLoad;
        }()
    }, {
        key: "loadData",
        value: function () {
            var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(pageIndex) {
                var params, res, ordersList;
                return regeneratorRuntime.wrap(function _callee2$(_context2) {
                    while (1) {
                        switch (_context2.prev = _context2.next) {
                            case 0:
                                params = {
                                    pageIndex: pageIndex || this.pageIndex,
                                    pageSize: 10
                                };
                                _context2.next = 3;
                                return _api2.default.crowdfunds(params);

                            case 3:
                                res = _context2.sent;

                                if (!(res.errcode == 200)) {
                                    _context2.next = 19;
                                    break;
                                }

                                ordersList = res.data.reg;

                                if (ordersList.length) {
                                    _context2.next = 15;
                                    break;
                                }

                                if (pageIndex == 1) {
                                    this.orders = ordersList;
                                }
                                this.pageIndex = pageIndex;
                                this.toload = true;
                                this.loadmoring = true;
                                this.$apply();
                                return _context2.abrupt("return", false);

                            case 15:
                                if (pageIndex > 1) this.pageIndex = pageIndex;
                                if (pageIndex == 1) {
                                    this.orders = ordersList;
                                } else {
                                    this.orders = this.orders.concat(ordersList);
                                }
                                this.loadmoring = false;

                            case 18:
                                this.$apply();

                            case 19:
                            case "end":
                                return _context2.stop();
                        }
                    }
                }, _callee2, this);
            }));

            function loadData(_x2) {
                return _ref3.apply(this, arguments);
            }

            return loadData;
        }()
    }, {
        key: "onShareAppMessage",
        value: function onShareAppMessage(res) {
            var id = '';
            if (res.from === 'button') {
                // 来自页面内转发按钮
                console.log(res.target);
                id = res.target.dataset.id;
            }
            return {
                title: '帮我一把，让我的成长路程更精彩！',
                path: '/crowdfund/pages/page?id=' + id
            };
        }
    }, {
        key: "onReachBottom",
        value: function () {
            var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
                return regeneratorRuntime.wrap(function _callee3$(_context3) {
                    while (1) {
                        switch (_context3.prev = _context3.next) {
                            case 0:
                                _context3.next = 2;
                                return this.getMore();

                            case 2:
                            case "end":
                                return _context3.stop();
                        }
                    }
                }, _callee3, this);
            }));

            function onReachBottom() {
                return _ref4.apply(this, arguments);
            }

            return onReachBottom;
        }()
    }, {
        key: "getMore",
        value: function () {
            var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
                return regeneratorRuntime.wrap(function _callee4$(_context4) {
                    while (1) {
                        switch (_context4.prev = _context4.next) {
                            case 0:
                                if (!this.loadmoring) {
                                    _context4.next = 2;
                                    break;
                                }

                                return _context4.abrupt("return", false);

                            case 2:
                                this.loadmoring = true;
                                this.toload = false;
                                _context4.next = 6;
                                return this.loadData(this.pageIndex + 1);

                            case 6:
                                this.$apply();

                            case 7:
                            case "end":
                                return _context4.stop();
                        }
                    }
                }, _callee4, this);
            }));

            function getMore() {
                return _ref5.apply(this, arguments);
            }

            return getMore;
        }()
    }]);

    return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'crowdfund/pages/orders'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm9yZGVycy5qcyJdLCJuYW1lcyI6WyJEaWFsb2ciLCJjb25maWciLCJuYXZpZ2F0aW9uQmFyVGl0bGVUZXh0IiwiZGF0YSIsInRoZW1lIiwid2VweSIsIiRpbnN0YW5jZSIsImdsb2JhbERhdGEiLCJ0aGVtZUNvbG9yIiwib3JkZXJTdGF0ZSIsIm9yZGVyU3RhdHMiLCJzY3JvbGxMZWZ0IiwicGFnZUluZGV4Iiwib3JkZXJzIiwidG9sb2FkIiwiaXNsb2FkIiwibG9hZG1vcmluZyIsIm1ldGhvZHMiLCJ0b2N1dCIsImUiLCJuYXZpZ2F0ZVRvIiwidXJsIiwiaWQiLCJvcHQiLCJhdXRoIiwibG9naW4iLCJsb2FkRGF0YSIsInBhcmFtcyIsInBhZ2VTaXplIiwiY3Jvd2RmdW5kcyIsInJlcyIsImVycmNvZGUiLCJvcmRlcnNMaXN0IiwicmVnIiwibGVuZ3RoIiwiJGFwcGx5IiwiY29uY2F0IiwiZnJvbSIsImNvbnNvbGUiLCJsb2ciLCJ0YXJnZXQiLCJkYXRhc2V0IiwidGl0bGUiLCJwYXRoIiwiZ2V0TW9yZSIsInBhZ2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUNJOzs7O0FBQ0E7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7Ozs7Ozs7Ozs7O0lBRXFCQSxNOzs7Ozs7Ozs7Ozs7OzswTEFDakJDLE0sR0FBUztBQUNMQyxvQ0FBd0IsTUFEbkI7QUFFTCwrQkFBbUI7QUFDZiwrQkFBZTtBQURBO0FBRmQsUyxRQU1UQyxJLEdBQU87QUFDSEMsbUJBQU9DLGVBQUtDLFNBQUwsQ0FBZUMsVUFBZixDQUEwQkMsVUFEOUI7QUFFSEMsd0JBQVk7QUFDUixtQkFBRyxLQURLO0FBRVIsbUJBQUcsS0FGSztBQUdSLG1CQUFHLEtBSEs7QUFJUixtQkFBRztBQUpLLGFBRlQ7QUFRSEMsd0JBQVksRUFSVDtBQVNIQyx3QkFBWSxDQVRUO0FBVUhDLHVCQUFXLENBVlI7QUFXSEMsb0JBQVEsRUFYTDtBQVlIQyxvQkFBUSxLQVpMO0FBYUhDLG9CQUFRLElBYkw7QUFjSEMsd0JBQVk7QUFkVCxTLFFBMEVQQyxPLEdBQVU7QUFDTkMsaUJBRE0saUJBQ0FDLENBREEsRUFDRztBQUNMZCwrQkFBS2UsVUFBTCxDQUFnQjtBQUNaQyx5QkFBSyxlQUFlRixFQUFFRztBQURWLGlCQUFoQjtBQUdIO0FBTEssUzs7Ozs7O2lHQTFER0MsRzs7Ozs7O3VDQUNMQyxlQUFLQyxLQUFMLEU7Ozs7dUNBQ0UsS0FBS0MsUUFBTCxFOzs7QUFDTixxQ0FBS1gsTUFBTCxHQUFjLEtBQWQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7a0dBRVdILFM7Ozs7OztBQUNQZSxzQyxHQUFTO0FBQ1RmLCtDQUFXQSxhQUFhLEtBQUtBLFNBRHBCO0FBRVRnQiw4Q0FBVTtBQUZELGlDOzt1Q0FJRzNCLGNBQU80QixVQUFQLENBQWtCRixNQUFsQixDOzs7QUFBWkcsbUM7O3NDQUNBQSxJQUFJQyxPQUFKLElBQWUsRzs7Ozs7QUFDWEMsMEMsR0FBYUYsSUFBSTNCLElBQUosQ0FBUzhCLEc7O29DQUNyQkQsV0FBV0UsTTs7Ozs7QUFDWixvQ0FBSXRCLGFBQWEsQ0FBakIsRUFBb0I7QUFDaEIseUNBQUtDLE1BQUwsR0FBY21CLFVBQWQ7QUFDSDtBQUNELHFDQUFLcEIsU0FBTCxHQUFpQkEsU0FBakI7QUFDQSxxQ0FBS0UsTUFBTCxHQUFjLElBQWQ7QUFDQSxxQ0FBS0UsVUFBTCxHQUFrQixJQUFsQjtBQUNBLHFDQUFLbUIsTUFBTDtrRUFDTyxLOzs7QUFFUCxvQ0FBSXZCLFlBQVksQ0FBaEIsRUFBbUIsS0FBS0EsU0FBTCxHQUFpQkEsU0FBakI7QUFDbkIsb0NBQUlBLGFBQWEsQ0FBakIsRUFBb0I7QUFDaEIseUNBQUtDLE1BQUwsR0FBY21CLFVBQWQ7QUFDSCxpQ0FGRCxNQUVPO0FBQ0gseUNBQUtuQixNQUFMLEdBQWMsS0FBS0EsTUFBTCxDQUFZdUIsTUFBWixDQUFtQkosVUFBbkIsQ0FBZDtBQUNIO0FBQ0QscUNBQUtoQixVQUFMLEdBQWtCLEtBQWxCOzs7QUFFSixxQ0FBS21CLE1BQUw7Ozs7Ozs7Ozs7Ozs7Ozs7OzswQ0FHVUwsRyxFQUFLO0FBQ25CLGdCQUFJUixLQUFLLEVBQVQ7QUFDQSxnQkFBSVEsSUFBSU8sSUFBSixLQUFhLFFBQWpCLEVBQTJCO0FBQ3ZCO0FBQ0FDLHdCQUFRQyxHQUFSLENBQVlULElBQUlVLE1BQWhCO0FBQ0FsQixxQkFBS1EsSUFBSVUsTUFBSixDQUFXQyxPQUFYLENBQW1CbkIsRUFBeEI7QUFDSDtBQUNELG1CQUFPO0FBQ0hvQix1QkFBTyxrQkFESjtBQUVIQyxzQkFBTSw4QkFBOEJyQjtBQUZqQyxhQUFQO0FBSUg7Ozs7Ozs7Ozs7dUNBRVMsS0FBS3NCLE9BQUwsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3FDQUdGLEtBQUs1QixVOzs7OztrRUFDRSxLOzs7QUFFWCxxQ0FBS0EsVUFBTCxHQUFrQixJQUFsQjtBQUNBLHFDQUFLRixNQUFMLEdBQWMsS0FBZDs7dUNBQ00sS0FBS1ksUUFBTCxDQUFjLEtBQUtkLFNBQUwsR0FBaUIsQ0FBL0IsQzs7O0FBQ04scUNBQUt1QixNQUFMOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBL0U0QjlCLGVBQUt3QyxJOztrQkFBcEI3QyxNIiwiZmlsZSI6Im9yZGVycy5qcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4gICAgaW1wb3J0IHdlcHkgZnJvbSBcIndlcHlcIlxyXG4gICAgaW1wb3J0IGNvbmZpZyBmcm9tIFwiLi4vYXBpXCJcclxuICAgIGltcG9ydCBUaXBzIGZyb20gXCJAL3V0aWxzL1RpcHNcIlxyXG4gICAgaW1wb3J0IFd4VXRpbHMgZnJvbSBcIkAvdXRpbHMvV3hVdGlsc1wiXG4gICAgaW1wb3J0IGF1dGggZnJvbSBcIkAvYXBpL2F1dGhcIlxuXHJcbiAgICBleHBvcnQgZGVmYXVsdCBjbGFzcyBEaWFsb2cgZXh0ZW5kcyB3ZXB5LnBhZ2Uge1xyXG4gICAgICAgIGNvbmZpZyA9IHtcclxuICAgICAgICAgICAgbmF2aWdhdGlvbkJhclRpdGxlVGV4dDogXCLmiJHnmoTkvJfnrblcIixcclxuICAgICAgICAgICAgXCJ1c2luZ0NvbXBvbmVudHNcIjoge1xyXG4gICAgICAgICAgICAgICAgXCJsLWNvdW50ZG93blwiOiBcIi4uLy4uL2NvbXBvbmVudHMvY291bnRkb3duL2luZGV4XCJcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH07XHJcbiAgICAgICAgZGF0YSA9IHtcclxuICAgICAgICAgICAgdGhlbWU6IHdlcHkuJGluc3RhbmNlLmdsb2JhbERhdGEudGhlbWVDb2xvcixcclxuICAgICAgICAgICAgb3JkZXJTdGF0ZToge1xyXG4gICAgICAgICAgICAgICAgMDogJ+S8l+etueS4rScsXHJcbiAgICAgICAgICAgICAgICAxOiAn5b6F5LuY5qy+JyxcclxuICAgICAgICAgICAgICAgIDI6ICflt7LlrozmiJAnLFxyXG4gICAgICAgICAgICAgICAgMzogJ+W3sui/h+acnydcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgb3JkZXJTdGF0czoge30sXHJcbiAgICAgICAgICAgIHNjcm9sbExlZnQ6IDAsXHJcbiAgICAgICAgICAgIHBhZ2VJbmRleDogMSxcclxuICAgICAgICAgICAgb3JkZXJzOiBbXSxcclxuICAgICAgICAgICAgdG9sb2FkOiBmYWxzZSxcclxuICAgICAgICAgICAgaXNsb2FkOiB0cnVlLFxyXG4gICAgICAgICAgICBsb2FkbW9yaW5nOiBmYWxzZSxcclxuICAgICAgICB9O1xyXG4gICAgICAgIGFzeW5jIG9uTG9hZChvcHQpIHtcbiAgICAgICAgICBhd2FpdCBhdXRoLmxvZ2luKClcclxuICAgICAgICAgICAgYXdhaXQgdGhpcy5sb2FkRGF0YSgpXHJcbiAgICAgICAgICAgIHRoaXMuaXNsb2FkID0gZmFsc2VcclxuICAgICAgICB9XHJcbiAgICAgICAgYXN5bmMgbG9hZERhdGEocGFnZUluZGV4KSB7XHJcbiAgICAgICAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgICAgICAgICBwYWdlSW5kZXg6IHBhZ2VJbmRleCB8fCB0aGlzLnBhZ2VJbmRleCxcclxuICAgICAgICAgICAgICAgIHBhZ2VTaXplOiAxMFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGxldCByZXMgPSBhd2FpdCBjb25maWcuY3Jvd2RmdW5kcyhwYXJhbXMpXHJcbiAgICAgICAgICAgIGlmIChyZXMuZXJyY29kZSA9PSAyMDApIHtcclxuICAgICAgICAgICAgICAgIGxldCBvcmRlcnNMaXN0ID0gcmVzLmRhdGEucmVnXHJcbiAgICAgICAgICAgICAgICBpZiAoIW9yZGVyc0xpc3QubGVuZ3RoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHBhZ2VJbmRleCA9PSAxKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMub3JkZXJzID0gb3JkZXJzTGlzdFxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnBhZ2VJbmRleCA9IHBhZ2VJbmRleFxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMudG9sb2FkID0gdHJ1ZVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubG9hZG1vcmluZyA9IHRydWVcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLiRhcHBseSgpXHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChwYWdlSW5kZXggPiAxKSB0aGlzLnBhZ2VJbmRleCA9IHBhZ2VJbmRleFxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChwYWdlSW5kZXggPT0gMSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm9yZGVycyA9IG9yZGVyc0xpc3RcclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm9yZGVycyA9IHRoaXMub3JkZXJzLmNvbmNhdChvcmRlcnNMaXN0KVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmxvYWRtb3JpbmcgPSBmYWxzZVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIG9uU2hhcmVBcHBNZXNzYWdlKHJlcykge1xyXG4gICAgICAgICAgICBsZXQgaWQgPSAnJ1xyXG4gICAgICAgICAgICBpZiAocmVzLmZyb20gPT09ICdidXR0b24nKSB7XHJcbiAgICAgICAgICAgICAgICAvLyDmnaXoh6rpobXpnaLlhoXovazlj5HmjInpkq5cclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKHJlcy50YXJnZXQpXHJcbiAgICAgICAgICAgICAgICBpZCA9IHJlcy50YXJnZXQuZGF0YXNldC5pZFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICB0aXRsZTogJ+W4ruaIkeS4gOaKiu+8jOiuqeaIkeeahOaIkOmVv+i3r+eoi+abtOeyvuW9qe+8gScsXHJcbiAgICAgICAgICAgICAgICBwYXRoOiAnL2Nyb3dkZnVuZC9wYWdlcy9wYWdlP2lkPScgKyBpZFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGFzeW5jIG9uUmVhY2hCb3R0b20oKSB7XHJcbiAgICAgICAgICAgIGF3YWl0IHRoaXMuZ2V0TW9yZSgpXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGFzeW5jIGdldE1vcmUoKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmxvYWRtb3JpbmcpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRoaXMubG9hZG1vcmluZyA9IHRydWVcclxuICAgICAgICAgICAgdGhpcy50b2xvYWQgPSBmYWxzZVxyXG4gICAgICAgICAgICBhd2FpdCB0aGlzLmxvYWREYXRhKHRoaXMucGFnZUluZGV4ICsgMSlcclxuICAgICAgICAgICAgdGhpcy4kYXBwbHkoKVxyXG4gICAgICAgIH1cclxuICAgICAgICBtZXRob2RzID0ge1xyXG4gICAgICAgICAgICB0b2N1dChlKSB7XHJcbiAgICAgICAgICAgICAgICB3ZXB5Lm5hdmlnYXRlVG8oe1xyXG4gICAgICAgICAgICAgICAgICAgIHVybDogJy4vcGFnZT9pZD0nICsgZS5pZFxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9O1xyXG4gICAgfVxyXG4iXX0=