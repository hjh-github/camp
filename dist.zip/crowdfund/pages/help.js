"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _wepy = require('./../../npm/wepy/lib/wepy.js');

var _wepy2 = _interopRequireDefault(_wepy);

var _api = require('./../api.js');

var _api2 = _interopRequireDefault(_api);

var _config = require('./../../api/config.js');

var _config2 = _interopRequireDefault(_config);

var _Tips = require('./../../utils/Tips.js');

var _Tips2 = _interopRequireDefault(_Tips);

var _WxUtils = require('./../../utils/WxUtils.js');

var _WxUtils2 = _interopRequireDefault(_WxUtils);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dialog = function (_wepy$page) {
  _inherits(Dialog, _wepy$page);

  function Dialog() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, Dialog);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Dialog.__proto__ || Object.getPrototypeOf(Dialog)).call.apply(_ref, [this].concat(args))), _this), _this.config = {
      navigationBarTitleText: "支持他"
    }, _this.data = {
      moneyOrder: "",
      copywriting: "",
      info: {}
    }, _this.methods = {
      textareaAInput: function textareaAInput(e) {
        this.copywriting = e.detail.value;
      },
      clickItem: function clickItem(value) {
        this.moneyOrder = value;
      },
      input: function input(e) {
        this.moneyOrder = e.detail.value;
      },
      topay: function () {
        var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
          var res;
          return regeneratorRuntime.wrap(function _callee$(_context) {
            while (1) {
              switch (_context.prev = _context.next) {
                case 0:
                  if (!(!this.moneyOrder || this.moneyOrder == 0)) {
                    _context.next = 3;
                    break;
                  }

                  _Tips2.default.toast("请选择或输入正确的金额", function (res) {}, 'none');
                  return _context.abrupt("return");

                case 3:
                  _context.next = 5;
                  return _api2.default.commit({
                    regId: this.info.regId,
                    moneyOrder: this.moneyOrder,
                    copywriting: this.copywriting
                  });

                case 5:
                  res = _context.sent;

                  console.log(res);
                  if (res.errcode == 200) {
                    _WxUtils2.default.wxPay(res.data).then(function (r) {
                      _Tips2.default.toast('支付成功', function () {
                        _WxUtils2.default.backOrRedirect('/crowdfund/pages/page');
                      }, 'none');
                    });
                  }

                case 8:
                case "end":
                  return _context.stop();
              }
            }
          }, _callee, this);
        }));

        function topay() {
          return _ref2.apply(this, arguments);
        }

        return topay;
      }()
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(Dialog, [{
    key: "onLoad",
    value: function () {
      var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(opt) {
        var res;
        return regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _context2.next = 2;
                return _api2.default.toSupport(opt.id || 6);

              case 2:
                res = _context2.sent;

                this.info = res.data;
                console.log(this.info);
                if (this.info.amountList.length > 0) {
                  this.moneyOrder = this.info.amountList[0];
                }
                this.$apply();

              case 7:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));

      function onLoad(_x) {
        return _ref3.apply(this, arguments);
      }

      return onLoad;
    }()
  }]);

  return Dialog;
}(_wepy2.default.page);


Page(require('./../../npm/wepy/lib/wepy.js').default.$createPage(Dialog , 'crowdfund/pages/help'));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhlbHAuanMiXSwibmFtZXMiOlsiRGlhbG9nIiwiY29uZmlnIiwibmF2aWdhdGlvbkJhclRpdGxlVGV4dCIsImRhdGEiLCJtb25leU9yZGVyIiwiY29weXdyaXRpbmciLCJpbmZvIiwibWV0aG9kcyIsInRleHRhcmVhQUlucHV0IiwiZSIsImRldGFpbCIsInZhbHVlIiwiY2xpY2tJdGVtIiwiaW5wdXQiLCJ0b3BheSIsIlRpcHMiLCJ0b2FzdCIsImFwaSIsImNvbW1pdCIsInJlZ0lkIiwicmVzIiwiY29uc29sZSIsImxvZyIsImVycmNvZGUiLCJXeFV0aWxzIiwid3hQYXkiLCJ0aGVuIiwiYmFja09yUmVkaXJlY3QiLCJvcHQiLCJ0b1N1cHBvcnQiLCJpZCIsImFtb3VudExpc3QiLCJsZW5ndGgiLCIkYXBwbHkiLCJ3ZXB5IiwicGFnZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQ0U7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7QUFDQTs7Ozs7Ozs7Ozs7Ozs7SUFDcUJBLE07Ozs7Ozs7Ozs7Ozs7O3NMQUNuQkMsTSxHQUFTO0FBQ1BDLDhCQUF3QjtBQURqQixLLFFBR1RDLEksR0FBTztBQUNMQyxrQkFBWSxFQURQO0FBRUxDLG1CQUFhLEVBRlI7QUFHTEMsWUFBTTtBQUhELEssUUFjUEMsTyxHQUFVO0FBQ1JDLG9CQURRLDBCQUNPQyxDQURQLEVBQ1U7QUFDaEIsYUFBS0osV0FBTCxHQUFtQkksRUFBRUMsTUFBRixDQUFTQyxLQUE1QjtBQUNELE9BSE87QUFJUkMsZUFKUSxxQkFJRUQsS0FKRixFQUlTO0FBQ2YsYUFBS1AsVUFBTCxHQUFrQk8sS0FBbEI7QUFDRCxPQU5PO0FBT1JFLFdBUFEsaUJBT0ZKLENBUEUsRUFPQztBQUNQLGFBQUtMLFVBQUwsR0FBa0JLLEVBQUVDLE1BQUYsQ0FBU0MsS0FBM0I7QUFDRCxPQVRPO0FBVUZHLFdBVkU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFXRixDQUFDLEtBQUtWLFVBQU4sSUFBb0IsS0FBS0EsVUFBTCxJQUFtQixDQVhyQztBQUFBO0FBQUE7QUFBQTs7QUFZSlcsaUNBQUtDLEtBQUwsQ0FBVyxhQUFYLEVBQTBCLGVBQU8sQ0FBRSxDQUFuQyxFQUFxQyxNQUFyQztBQVpJOztBQUFBO0FBQUE7QUFBQSx5QkFlVUMsY0FBSUMsTUFBSixDQUFXO0FBQ3pCQywyQkFBTyxLQUFLYixJQUFMLENBQVVhLEtBRFE7QUFFekJmLGdDQUFZLEtBQUtBLFVBRlE7QUFHekJDLGlDQUFhLEtBQUtBO0FBSE8sbUJBQVgsQ0FmVjs7QUFBQTtBQWVGZSxxQkFmRTs7QUFvQk5DLDBCQUFRQyxHQUFSLENBQVlGLEdBQVo7QUFDQSxzQkFBSUEsSUFBSUcsT0FBSixJQUFlLEdBQW5CLEVBQXdCO0FBQ3RCQyxzQ0FBUUMsS0FBUixDQUFjTCxJQUFJakIsSUFBbEIsRUFBd0J1QixJQUF4QixDQUE2QixhQUFLO0FBQ2hDWCxxQ0FBS0MsS0FBTCxDQUFXLE1BQVgsRUFBbUIsWUFBTTtBQUN2QlEsMENBQVFHLGNBQVIsQ0FBdUIsdUJBQXZCO0FBQ0QsdUJBRkQsRUFFRyxNQUZIO0FBR0QscUJBSkQ7QUFLRDs7QUEzQks7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQSxLOzs7Ozs7NEZBVEdDLEc7Ozs7Ozs7dUJBQ0tYLGNBQUlZLFNBQUosQ0FBY0QsSUFBSUUsRUFBSixJQUFVLENBQXhCLEM7OztBQUFaVixtQjs7QUFDSixxQkFBS2QsSUFBTCxHQUFZYyxJQUFJakIsSUFBaEI7QUFDQWtCLHdCQUFRQyxHQUFSLENBQVksS0FBS2hCLElBQWpCO0FBQ0Esb0JBQUksS0FBS0EsSUFBTCxDQUFVeUIsVUFBVixDQUFxQkMsTUFBckIsR0FBOEIsQ0FBbEMsRUFBcUM7QUFDbkMsdUJBQUs1QixVQUFMLEdBQWtCLEtBQUtFLElBQUwsQ0FBVXlCLFVBQVYsQ0FBcUIsQ0FBckIsQ0FBbEI7QUFDRDtBQUNELHFCQUFLRSxNQUFMOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBaEJnQ0MsZUFBS0MsSTs7a0JBQXBCbkMsTSIsImZpbGUiOiJoZWxwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbiAgaW1wb3J0IHdlcHkgZnJvbSBcIndlcHlcIlxyXG4gIGltcG9ydCBhcGkgZnJvbSBcIi4uL2FwaVwiXHJcbiAgaW1wb3J0IGNvbmZpZyBmcm9tICdAL2FwaS9jb25maWcnXHJcbiAgaW1wb3J0IFRpcHMgZnJvbSBcIkAvdXRpbHMvVGlwc1wiXHJcbiAgaW1wb3J0IFd4VXRpbHMgZnJvbSBcIkAvdXRpbHMvV3hVdGlsc1wiXHJcbiAgZXhwb3J0IGRlZmF1bHQgY2xhc3MgRGlhbG9nIGV4dGVuZHMgd2VweS5wYWdlIHtcclxuICAgIGNvbmZpZyA9IHtcclxuICAgICAgbmF2aWdhdGlvbkJhclRpdGxlVGV4dDogXCLmlK/mjIHku5ZcIlxyXG4gICAgfTtcclxuICAgIGRhdGEgPSB7XHJcbiAgICAgIG1vbmV5T3JkZXI6IFwiXCIsXHJcbiAgICAgIGNvcHl3cml0aW5nOiBcIlwiLFxyXG4gICAgICBpbmZvOiB7fVxyXG4gICAgfTtcclxuICAgIGFzeW5jIG9uTG9hZChvcHQpIHtcclxuICAgICAgbGV0IHJlcyA9IGF3YWl0IGFwaS50b1N1cHBvcnQob3B0LmlkIHx8IDYpXHJcbiAgICAgIHRoaXMuaW5mbyA9IHJlcy5kYXRhXHJcbiAgICAgIGNvbnNvbGUubG9nKHRoaXMuaW5mbylcclxuICAgICAgaWYgKHRoaXMuaW5mby5hbW91bnRMaXN0Lmxlbmd0aCA+IDApIHtcclxuICAgICAgICB0aGlzLm1vbmV5T3JkZXIgPSB0aGlzLmluZm8uYW1vdW50TGlzdFswXVxyXG4gICAgICB9XHJcbiAgICAgIHRoaXMuJGFwcGx5KClcclxuICAgIH1cclxuICAgIG1ldGhvZHMgPSB7XHJcbiAgICAgIHRleHRhcmVhQUlucHV0KGUpIHtcclxuICAgICAgICB0aGlzLmNvcHl3cml0aW5nID0gZS5kZXRhaWwudmFsdWU7XHJcbiAgICAgIH0sXHJcbiAgICAgIGNsaWNrSXRlbSh2YWx1ZSkge1xyXG4gICAgICAgIHRoaXMubW9uZXlPcmRlciA9IHZhbHVlO1xyXG4gICAgICB9LFxyXG4gICAgICBpbnB1dChlKSB7XHJcbiAgICAgICAgdGhpcy5tb25leU9yZGVyID0gZS5kZXRhaWwudmFsdWU7XHJcbiAgICAgIH0sXHJcbiAgICAgIGFzeW5jIHRvcGF5KCkge1xyXG4gICAgICAgIGlmICghdGhpcy5tb25leU9yZGVyIHx8IHRoaXMubW9uZXlPcmRlciA9PSAwKSB7XHJcbiAgICAgICAgICBUaXBzLnRvYXN0KFwi6K+36YCJ5oup5oiW6L6T5YWl5q2j56Gu55qE6YeR6aKdXCIsIHJlcyA9PiB7fSwgJ25vbmUnKTtcclxuICAgICAgICAgIHJldHVyblxyXG4gICAgICAgIH1cclxuICAgICAgICBsZXQgcmVzID0gYXdhaXQgYXBpLmNvbW1pdCh7XHJcbiAgICAgICAgICByZWdJZDogdGhpcy5pbmZvLnJlZ0lkLFxyXG4gICAgICAgICAgbW9uZXlPcmRlcjogdGhpcy5tb25leU9yZGVyLFxyXG4gICAgICAgICAgY29weXdyaXRpbmc6IHRoaXMuY29weXdyaXRpbmdcclxuICAgICAgICB9KVxyXG4gICAgICAgIGNvbnNvbGUubG9nKHJlcylcclxuICAgICAgICBpZiAocmVzLmVycmNvZGUgPT0gMjAwKSB7XHJcbiAgICAgICAgICBXeFV0aWxzLnd4UGF5KHJlcy5kYXRhKS50aGVuKHIgPT4ge1xuICAgICAgICAgICAgVGlwcy50b2FzdCgn5pSv5LuY5oiQ5YqfJywgKCkgPT4ge1xuICAgICAgICAgICAgICBXeFV0aWxzLmJhY2tPclJlZGlyZWN0KCcvY3Jvd2RmdW5kL3BhZ2VzL3BhZ2UnKVxuICAgICAgICAgICAgfSwgJ25vbmUnKVxuICAgICAgICAgIH0pXHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gIH1cclxuIl19